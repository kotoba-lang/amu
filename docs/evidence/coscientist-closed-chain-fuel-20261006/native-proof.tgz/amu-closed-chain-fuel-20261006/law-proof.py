from pathlib import Path
import z3,json
w=Path(__file__).resolve().parent;u=z3.BitVec('fuel',64);orig=z3.If(u==0,z3.BitVecVal(0,64),u-1);carry=u-1;exhaust=u==0;published=z3.If(exhaust,z3.BitVecVal(0,64),carry);stored=z3.BitVec('stored',64);next_u=z3.BitVec('nextFuel',64)
laws={'oneChargeIncludingZero':orig!=published,'successfulChargeRegisterEquality':z3.And(u!=0,carry!=orig),'coldTrapPublishesCurrentOriginalFuel':z3.And(u!=0,published!=orig),'twoPrivateChargesPreserveOriginalFuel':z3.And(z3.UGT(u,z3.BitVecVal(1,64)),(carry-1)!=(u-2))};rows=[]
for name,claim in laws.items():
 s=z3.Solver();s.add(claim);got=s.check();assert got==z3.unsat;rows.append({'law':name,'negation':s.to_smt2(),'result':str(got)})
bad={'missingColdPublication':z3.And(u!=0,stored!=carry),'reloadStalePrivateEntry':z3.And(u!=0,stored!=carry,next_u==stored,next_u!=carry),'wrapZeroExhaustionWithoutPublication':z3.And(u==0,carry!=orig)};controls=[]
for name,claim in bad.items():
 s=z3.Solver();s.add(claim);got=s.check();assert got==z3.sat;controls.append({'law':name,'formula':s.to_smt2(),'result':str(got),'counterexample':str(s.model())})
(w/'law-proof.json').write_text(json.dumps({'status':'complete-abstract-64bit-closed-charge-law-and-unsafe-controls','z3Version':z3.get_version_string(),'laws':rows,'unsafeControls':controls,'limits':'These equations do not prove ABI admission, CFG, metadata safety or machine emission. Native machine/state controls provide separate evidence.'},indent=2)+'\n');print('PASS',len(rows),'abstract laws UNSAT and',len(controls),'unsafe controls SAT')
