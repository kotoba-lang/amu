from pathlib import Path
import json,os,re,subprocess,struct,hashlib
w=Path('/private/tmp/amu-closed-chain-fuel-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');ns={};exec((w/'fixture-proof.py').read_text().split('env=dict(')[0],ns);m=ns['m'];initial=len(m.FIX);base_types=ns['typeform'];specs=[('BIN',x) for x in ['BOP-ADD','BOP-SUB','BOP-MUL','BOP-QUOT','BOP-AND','BOP-OR','BOP-XOR','BOP-SHL','BOP-USHR','BOP-SSHR']]+[('CMP',x) for x in ['CC-EQ','CC-LT','CC-GT','CC-LE','CC-GE']]+[('UN',x) for x in ['UOP-NOT','UOP-BITNOT']]
fns,labels,lits,sir,frec=m.layout_tables();typeform='(defn- t-scratch-types [M :vector-i64] :vector-i64 M)\n';env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');images={};parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba']
for arm,g,l in [('baseline','baseline-41-a64gen.kotoba','baseline-42-layout.kotoba'),('candidate','41-a64gen-prototype.kotoba','42-layout-prototype.kotoba')]:
 text=m.kotoba(True).replace('(defn- seed-main [] :i64',base_types+typeform+'(defn- seed-main [] :i64').replace('        M1 (gn-run (t-vector-chain-types (t-small-types M0)))','        M1 (gn-run (t-scratch-types (t-lv-types (t-vector-chain-types (t-small-types M0)))))');src=w/(arm+'-scratch.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/g).read_text()+'\n'+(w/l).read_text()+'\n'+text)
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(arm+'-scratch.kseed'))]),('extract',['extract-native',str(w/(arm+'-scratch.kseed')),'--symbol','main','--output',str(w/(arm+'-scratch-generator.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(arm+'-scratch-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(arm,stage,q.stdout[-500:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(arm+'-scratch-generator.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0,(arm,q.stdout[-500:],q.stderr);(w/(arm+'-scratch.stdout')).write_text(q.stdout+q.stderr);blob,offs=m.blob_from(q.stdout);p=w/(arm+'-scratch.bin');p.write_bytes(blob);images[arm]=(p,offs)
wrap=lambda x:((x+(1<<63))%(1<<64))-(1<<63)
def value(op,a,b):
 if op=='BOP-QUOT':return None if b==0 or (a==m.MIN and b==-1) else (abs(a)//abs(b))*(-1 if (a<0)!=(b<0) else 1)
 f={'BOP-ADD':lambda:a+b,'BOP-SUB':lambda:a-b,'BOP-MUL':lambda:a*b,'BOP-AND':lambda:a&b,'BOP-OR':lambda:a|b,'BOP-XOR':lambda:a^b,'BOP-SHL':lambda:a<<(b&63),'BOP-USHR':lambda:(a&((1<<64)-1))>>(b&63),'BOP-SSHR':lambda:a>>(b&63),'CC-EQ':lambda:int(a==b),'CC-LT':lambda:int(a<b),'CC-GT':lambda:int(a>b),'CC-LE':lambda:int(a<=b),'CC-GE':lambda:int(a>=b),'UOP-NOT':lambda:a^1,'UOP-BITNOT':lambda:~a};return wrap(f[op]())
pairs=[(0,0),(0,1),(1,1),(-1,1),(m.MIN,-1),(m.MIN,m.MAX),(m.MAX,m.MIN),(m.MAX,2),(m.MIN,2),(7,3),(-7,3),(7,-3),(-7,-3),(1,63),(m.MIN,64),(-1,65),(m.MAX,-64)];rows=[]
for kind,op in specs:
 name='scratch_'+op.lower().replace('-','_')+'_driver'
 for a,b in pairs:
  v=value(op,a,b)
  for fuel in [1,2,3,4,(1<<53)-1]:
   items=[13,17,19,23,0,0,a,b,0,0,1];result=None;remaining=max(fuel-2,0)
   if fuel>=2 and v is not None:
    items[9]=v;remaining=max(fuel-3,0)
    if fuel>=3:items[4]=1;result=v
   obs={}
   for arm,(p,offs) in images.items():
    env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');q=subprocess.run([str(w/'full-state-loader'),str(p),str(offs[fns[name]]),'2','aarch64','-',str(a),str(b)],env=env,capture_output=True,text=True);lines=re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M);obs[arm]={'exit':q.returncode,'report':q.stdout.strip(),'items':lines,'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)};assert (q.returncode==0)==(result is not None),(op,a,b,fuel,result,arm,q.stdout,q.stderr);assert ':remaining '+str(remaining)+'}' in q.stdout,(op,a,b,fuel,remaining,q.stdout);assert lines==['DIAG_VECTOR_ITEMS 11 '+' '.join(map(str,items))],(op,a,b,fuel,arm,lines,items)
    if result is not None:assert ':result '+str(result)+' ' in q.stdout,(op,a,b,fuel,result,q.stdout)
   assert obs['baseline']==obs['candidate'],(op,a,b,fuel,obs);rows.append({'operator':op,'args':[a,b],'fuel':fuel,'expectedResult':result,'expectedRemaining':remaining,'expectedItems':items,**obs})
 print('PASS independently modeled live-cache integer operation',op,flush=True)
(w/'scratch-proof.json').write_text(json.dumps({'status':'complete-native-spare-register-integer-bin-cmp-un-live-cache-and-private-tail-oracles','comparisons':len(rows),'operators':len(specs),'newFixtures':len(m.FIX)-initial,'observations':rows},indent=2)+'\n');print('PASS',len(rows),'independent all-supported-integer scratch/cache/partial-state oracles')
