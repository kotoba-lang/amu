from pathlib import Path
import json,os,subprocess,re
w=Path('/private/tmp/amu-closed-chain-fuel-20261006');b=Path('/private/tmp/amu-static-vector-chain-20261006');p=json.loads((w/'ports-correctness.json').read_text());old=json.loads((b/'ports-correctness.json').read_text());rows=[]
for e in p['entries']:
 name=e['workload'];o=next(x for x in old['entries'] if x['workload']==name)
 for key in ['KEXE_VECTORS','KEXE_VECTOR_ITEMS']:
  obs={}
  for label,root,offset in [('baseline',b,o['offset']),('candidate',w,e['offset'])]:
   env=dict(os.environ,KEXE_FUEL='16777216',KEXE_STRUCTURED_REPORT='1');env[key]='1';env.pop('KEXE_COMMAND',None)
   q=subprocess.run([str(w/'full-state-loader'),str(root/'ports-2'/name/'native.bin'),str(offset),'1','aarch64','-','1'],env=env,capture_output=True,text=True);assert ':fuel ' in q.stdout,(name,key,label,q.stdout,q.stderr)
   obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
  assert obs['baseline']==obs['candidate'],(name,key,obs);rows.append({'workload':name,'budget':key,'capacity':1,**obs})
 print('PASS actual original resource and partial-state controls',name,flush=True)
(w/'resource-proof.json').write_text(json.dumps({'status':'complete-native-original19-low-resource-full-state-parity','comparisons':len(rows),'runs':rows},indent=2)+'\n')
