from pathlib import Path
import json,hashlib,shutil,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path(__file__).resolve().parent;b=Path('/private/tmp/amu-static-vector-chain-20261006');g=(r/'seed/41-a64gen.kotoba').read_text();l=(r/'seed/42-layout.kotoba').read_text();assert g==(b/'41-a64gen-prototype.kotoba').read_text();(w/'baseline-41-a64gen.kotoba').write_text(g);(w/'baseline-42-layout.kotoba').write_text(l)
h=json.loads((r/'docs/evidence/coscientist-statemate-fuel-census-20261006/next-hypothesis.json').read_text());h.update(status='registered-before-native-build',sourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),authoringException='One-off new optimizer ABI and independent tests outside product path; not mechanical product refactor.');(w/'hypothesis.json').write_text(json.dumps(h,indent=2)+'\n')
def rep(a,b):
 global g
 assert g.count(a)==1,(a,g.count(a));g=g.replace(a,b)
anchor='(defn- gn-chain-base ['
helper=''';; Experimental closed mode2 fuel ABI. 2 differs from leaf transaction1:
;; every cold synchronous trap exposes the current original published fuel.
(defn- gn-cf-skip [M :vector-i64 words :i64] :i64
 (+ words (if (= (gn-g M gn-f-freg) 2) 1 0)))
(defn- gn-cf-trap [M :vector-i64 word :i64] :vector-i64
 (-> M (cond-> (= (gn-g M gn-f-freg) 2) (gn-emit (enc-str 8 7 CTX-FUEL))) (gn-emit word)))
(defn- gn-cf-private [M :vector-i64 f :i64 t :i64 n :i64] :bool
 (and (= (gn-g M gn-f-freg) 2) (= n 1) (> (gn-g M gn-f-vslot) 0)
      (gn-isk M t gn-k-local) (= (gn-dv M t) (gn-g M gn-f-vslot)) (gn-chain-target M f)))
''';rep(anchor,helper+anchor)
# All descriptor-hit skips now include the conditional cold publication word.
g=g.replace('(enc-cbnz 5 13)','(enc-cbnz 5 (gn-cf-skip M 13))').replace('(enc-bcond (enc-cond-eq) 13)','(enc-bcond (enc-cond-eq) (gn-cf-skip M 13))')
# Bounds/handle cold branches; exact scope includes mode2 helpers and generic
# inline paths, while other modes retain the identical words.
g=g.replace('(enc-bcond (enc-cond-lo) 2)','(enc-bcond (enc-cond-lo) (gn-cf-skip M 2))').replace('(gn-emit (gn-e-udf))','(gn-cf-trap (gn-e-udf))')
rep('(if private (gn-put M1 (+ MM-FIX-BASE (* at MM-FIX-W) XF-AUX) 1) M1)', '(if private (gn-put M1 (+ MM-FIX-BASE (* at MM-FIX-W) XF-AUX) (if (= (gn-g M gn-f-freg) 2) 2 1)) M1)')
rep('(gn-gs gn-f-h 0) (gn-vclear) (gn-gs gn-f-vslot', '(gn-gs gn-f-h 0) (gn-vclear)\n                  (cond-> (= (gn-g M2 gn-f-vmode) 2) (-> (gn-emit (enc-ldr 8 7 CTX-FUEL)) (gn-gs gn-f-freg 2)))\n                  (gn-gs gn-f-vslot')
rep('(cond-> (= (gn-g M gn-f-freg) 1) (gn-emit (enc-str 8 7 CTX-FUEL)))','(cond-> (> (gn-g M gn-f-freg) 0) (gn-emit (enc-str 8 7 CTX-FUEL)))')
rep('(if (= (gn-g M gn-f-freg) 1)\n    (-> M (gn-emit (enc-subs-i 8 8 1))','(if (> (gn-g M gn-f-freg) 0)\n    (-> M (gn-emit (enc-subs-i 8 8 1))')
rep('(let [restored (-> M (gn-args t 0 n) (gn-ctx) (gn-epilogue))', '(let [private (gn-cf-private M f t n)\n        base (-> M (gn-args t 0 n) (gn-ctx))\n        restored (if private (-> base (gn-emit (enc-ret)) (gn-gs gn-f-dead 1)) (gn-epilogue base))')
start=g.index('(defn- gn-quot [');end=g.index('(defn- gn-bin-word [',start)
s=g[start:end];s=s.replace('(enc-cbnz y 2)','(enc-cbnz y (gn-cf-skip M 2))').replace('(enc-bcond (enc-cond-ne) 4)','(enc-bcond (enc-cond-ne) (gn-cf-skip M 4))').replace('(enc-bcond (enc-cond-vc) 2)','(enc-bcond (enc-cond-vc) (gn-cf-skip M 2))').replace('(gn-emit (enc-brk 0))','(gn-cf-trap (enc-brk 0))');g=g[:start]+s+g[end:]
rep('OP-TRAP (-> M (gn-emit (enc-brk a))','OP-TRAP (-> M (gn-cf-trap (enc-brk a))');rep('OP-END (-> M (gn-emit (enc-brk 1))','OP-END (-> M (gn-cf-trap (enc-brk 1))')
a='(if (and (= aux 1) (= kind FX-BL26) (> t0 0)';assert l.count(a)==1;l=l.replace(a,'(if (and (or (= aux 1) (= aux 2)) (= kind FX-BL26) (> t0 0)')
a='(= (vector-at M (+ MM-CODE-BASE t0)) 0xd2800005))\n                (inc t0) -1))';assert l.count(a)==1;l=l.replace(a,'(= (vector-at M (+ MM-CODE-BASE t0)) 0xd2800005)\n                     (or (= aux 1) (and (< (+ t0 2) (vector-at M MM-CODE-N))\n                        (= (vector-at M (+ MM-CODE-BASE t0 1)) (enc-ldr 8 7 CTX-FUEL)))))\n                (+ t0 aux) -1))')
(w/'41-a64gen-prototype.kotoba').write_text(g);(w/'42-layout-prototype.kotoba').write_text(l)
parts=[z.strip() for z in (r/'seed/MANIFEST').read_text().splitlines() if z.strip() and not z.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join(g if p=='seed/41-a64gen.kotoba' else l if p=='seed/42-layout.kotoba' else (r/p).read_text() for p in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader'),('full-state-loader','full-state-loader')]:shutil.copy2(b/src,w/dst)
(w/'internal-abi.json').write_text(json.dumps({'status':'experimental-not-promoted','freg':2,'fuelRegister':8,'publicPrefix':['MOVZ x5,#0','LDR x8,[x7,#CTX-FUEL]'],'privateEntryWords':2,'trapPublication':'Current x8 published only on cold mode2 synchronous failure; exhaustion publishes zero.','returnPublication':'Original current x8 on every public escape. Only proved positive-witness closed private tail skips publication and reload.','ordinaryLeafTransaction':1,'sourceModeAdmission':'Existing original closed mode2 typed Vec-to-Vec proof; no new runtime operations, returning calls, allocation, capability, floating or unknown effects.'},indent=2)+'\n')
print('PASS experimental closed-chain fuel sources and guarded layout prepared')
