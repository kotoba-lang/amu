from pathlib import Path
import importlib.util,json,os,re,subprocess,struct,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-closed-chain-fuel-20261006');raw=(r/'scripts/seed/a64gen-fixtures.py').read_text().replace("R = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))","R = '/Users/junkawasaki/github/wt/amu-seed17'",1);(w/'frozen-fixtures.py').write_text(raw);sp=importlib.util.spec_from_file_location('fx',w/'frozen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
# Current authoritative593 already includes the old lv fixture family.
# Reuse it; never append duplicate names or change its semantic expectations.
assert len({x[0] for x in m.FIX})==len(m.FIX)
fns,labels,lits,sir,frec=m.layout_tables();typeform='(defn- t-lv-types [M :vector-i64] :vector-i64 M)\n'
env=dict()
