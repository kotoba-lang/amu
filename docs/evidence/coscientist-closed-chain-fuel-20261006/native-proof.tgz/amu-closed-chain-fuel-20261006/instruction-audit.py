from pathlib import Path
import json,struct,re,collections
w=Path(__file__).resolve().parent;b=Path('/private/tmp/amu-static-vector-chain-20261006');pc=json.loads((w/'ports-correctness.json').read_text());pb=json.loads((b/'ports-correctness.json').read_text());rows=[];tot=collections.Counter();C={}
for name in ['SIR','HEADS','MEMORY-MAP']:
 for z in re.finditer(r'\[:c (\S+) (-?\d+)',(Path('/Users/junkawasaki/github/wt/amu-seed17/seed')/name).read_text()):C[z[1]]=int(z[2])
def br(z):
 if z&0x7c000000==0x14000000:
  imm=z&0x3ffffff;return z&0xfc000000,imm-(1<<26) if imm&(1<<25) else imm
 if z&0xff000010==0x54000000:
  imm=(z>>5)&0x7ffff;return z&0xff00001f,imm-(1<<19) if imm&(1<<18) else imm
 if z&0x7e000000==0x34000000:
  imm=(z>>5)&0x7ffff;return z&0xff00001f,imm-(1<<19) if imm&(1<<18) else imm
 return None
for ent in pc['entries']:
 name=ent['workload'];old=next(x for x in pb['entries'] if x['workload']==name);c=json.loads((w/'observer/meta-ports'/name/'census.json').read_text());d=json.loads((b/'observer/meta-ports'/name/'census.json').read_text());assert c['sirCount']==d['sirCount'];assert (w/'observer/meta-ports'/name/'native.bin').read_bytes()==(w/'ports-2'/name/'native.bin').read_bytes()
 def records(root):return {int(z.split()[1]):list(map(int,z.split()[2:])) for z in (root/'compile.log').read_text().splitlines() if z.startswith('SIR ')}
 assert records(w/'observer/meta-ports'/name)==records(b/'observer/meta-ports'/name);closed={x['fn'] for x in json.loads((b/'instruction-audit.json').read_text())['mode2Functions'] if x['workload']==name}
 for f,info in c['functions'].items():
  before=d['functions'][f]
  for k in ['start','end','frameBytes','locals','depth','localCalleeRegisters','leaf']:assert info[k]==before[k],(name,f,k)
 if name!='statemate':assert ent['nativeSha256']==old['nativeSha256'];rows.append({'workload':name,'nativeByteExact':True});continue
 def normalized(census,arm):
  stream=[];positions={};branches=[];charges=0;stores=0;loads=0
  for ev in census['events']:
   start=ev['firstWord'];ww=[int(v,16) for v in ev['words']];cf=ev['fn'] in closed;j=0
   if arm=='candidate' and cf and ev['op']=='OP-FN':assert ww[:2]==[0xd2800005,0xf94004e8]
   while j<len(ww):
    at=start+j;z=ww[j];key=(ev['sir'],len(stream))
    if cf and arm=='baseline' and ww[j:j+5]==[0xf94004f0,0xf1000610,0x54000042,0xd4200000,0xf90004f0]:positions[at]=len(stream);stream.append(('CHARGE',));charges+=1;j+=5;continue
    if cf and arm=='candidate' and ww[j:j+4]==[0xf1000508,0x54000062,0xf90004ff,0xd4200000]:positions[at]=len(stream);stream.append(('CHARGE',));charges+=1;j+=4;continue
    if cf and arm=='candidate' and z==0xf94004e8:assert ev['op']=='OP-FN' and j==1;loads+=1;j+=1;continue
    if cf and arm=='candidate' and z==0xf90004e8:
     assert j+1<len(ww) and (ww[j+1]==0 or ww[j+1]&0xffe0001f==0xd4200000 or ww[j+1]==0xd65f03c0 or ww[j+1]&0xfc000000==0x14000000),(ev,j)
     # Targets entering a cold store correspond to the original trap node.
     positions[at]=len(stream);stores+=1;j+=1;continue
    positions[at]=len(stream);q=br(z)
    if q:stream.append(('BRANCH',q[0]));branches.append((len(stream)-1,at+q[1],ev['sir']))
    else:stream.append(('WORD',z))
    j+=1
  return stream,positions,branches,{'charges':charges,'stores':stores,'loads':loads}
 a,pa,ba,ma=normalized(d,'baseline');z,pz,bz,mz=normalized(c,'candidate');assert a==z,next(((i,x,y) for i,(x,y) in enumerate(zip(a,z)) if x!=y),(len(a),len(z)))
 assert ma['charges']==mz['charges'];assert len(ba)==len(bz)
 for x,y in zip(ba,bz):assert x[0]==y[0] and pa[x[1]]==pz[y[1]],(x,y,pa.get(x[1]),pz.get(y[1]))
 fixes=[list(map(int,line.split()[1:])) for line in (w/'observer/meta-ports'/name/'compile.log').read_text().splitlines() if line.startswith('FIX ')];code=[v[0] for v in struct.iter_unpack('<I',(w/'ports-2'/name/'native.bin').read_bytes())];private=0
 for ix,at,kind,target,aux in fixes:
  if aux==0:continue
  assert aux==2 and kind==C['FX-BL26'];entry=c['functions'][str(target)]['codeWordStart'];assert code[entry-1:entry+1]==[0xd2800005,0xf94004e8];q=br(code[at-1]);assert q and q[0]==0x14000000 and at+q[1]==entry+2;private+=1
 assert private==289 and mz['loads']==390;tot.update(mz);tot['privateTransfers']+=private;tot['normalizedBranchTargets']+=len(ba);rows.append({'workload':name,'originalSirFrameAndSemanticsNormalizedExact':True,'publicLoads':mz['loads'],'coldTrapAndPublicEscapeStores':mz['stores'],'closedCharges':mz['charges'],'privateTransfers':private,'normalizedBranchTargets':len(ba),'baselineWords':d['codeWords'],'candidateWords':c['codeWords']})
out={'status':'complete-all19-native-normalized-instruction-and-CFG-fuel-publication-private-entry-audit','counts':dict(tot),'rows':rows,'limits':'Explicit original5-word versus candidate4-word charge contracts normalized; only public-entry LDR8 and cold-trap/public-escape STR8 are removed from comparison. Every remaining actual word/opcode and every normalized branch target agrees. Assumes valid supervisor metadata and typed admitted SIR.'};(w/'instruction-audit.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS independent actual instruction/CFG/publication audit',dict(tot))
