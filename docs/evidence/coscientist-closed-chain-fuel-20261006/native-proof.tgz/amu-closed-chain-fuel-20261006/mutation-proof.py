from pathlib import Path
import json,subprocess,re,os
w=Path('/private/tmp/amu-closed-chain-fuel-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');ns={};exec((w/'fixture-proof.py').read_text().split('env=dict(')[0],ns);m=ns['m'];fns=ns['fns'];sir=ns['sir'];typeform=ns['typeform'];f=fns['lv_branch'];finish=fns['lv_finish'];p=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==f);end=next(i for i in range(p,len(sir)+1) if sir[i-1][0]==m.C['OP-END']);sb=m.C['MM-SIR-BASE'];sw=m.C['MM-SIR-W'];fb=m.C['MM-FN-BASE']+f*m.C['MM-FN-W'];cases=[]
def add(i,field,value):cases.append((sb+i*sw+field,value))
for field,value in [('FF-SIR',0),('FF-SIR',len(sir)),('FF-NPARAMS',0),('FF-NPARAMS',2),('FF-NSLOTS',0),('FF-NSLOTS',2),('FF-NSLOTS',4),('FF-DEPTH',0),('FF-DEPTH',2),('FF-DEPTH',4),('FF-RTYPE',m.C['TY-I64']),('FF-PT0',m.C['TY-I64'])]:cases.append((fb+m.C[field],value))
for field,value in [(0,m.C['OP-END']),(1,0),(2,2),(3,4)]:add(p,field,value)
for i in range(p+1,end):
 op,a,b,c=sir[i-1]
 if op==m.C['OP-FUEL']:
  for field in [1,2,3]:add(i,field,1)
 elif op==m.C['OP-LGET']:
  for field,value in [(1,-1),(1,3),(2,0),(2,4),(3,1)]:add(i,field,value)
 elif op==m.C['OP-LSET']:
  for field,value in [(1,0),(1,4),(2,-1),(2,3),(3,1)]:add(i,field,value)
 elif op==m.C['OP-CONST']:
  for field,value in [(1,-1),(1,3),(3,1)]:add(i,field,value)
 elif op==m.C['OP-BIN']:
  for field,value in [(1,m.C['BOP-F64-ADD']),(2,-1),(2,2),(3,1)]:add(i,field,value)
 elif op==m.C['OP-LABEL']:
  label=a;labeli=i
  for field,value in [(1,0),(2,1),(3,1)]:add(i,field,value)
 elif op==m.C['OP-BR']:
  for field,value in [(1,0),(2,1),(3,1)]:add(i,field,value)
 elif op==m.C['OP-CALL']:
  for field,value in [(2,-1),(3,0),(3,4)]:add(i,field,value)
  if a==finish:add(i,0,m.C['OP-RET']);add(i,2,1)
 elif op==m.C['OP-RT']:
  add(i,1,m.C['RT-VECTOR-ALLOC']);add(i,2,-1);add(i,3,0)
 elif op==m.C['OP-RET']:
  for field,value in [(1,-1),(1,3),(2,1),(3,1)]:add(i,field,value)
for field,value in [(1,0),(2,1),(3,1)]:add(end,field,value)
for op in ['OP-CAP','OP-VEC','OP-STR','OP-CALLI','OP-RES2','OP-RET2','OP-TRAP']:add(p+1,0,m.C[op])
foreign=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==fns['lv_sink'])+1
probe=f'''(defn- t-chain-check [M :vector-i64] :bool (gn-chain-target M {f}))
(defn- t-chain-mut [M :vector-i64 at :i64 value :i64] :bool
 (let [old (vector-at M at) set (t-put M at value) got (t-chain-check set) restore (t-put set at old)] (not got)))
(defn- t-chain-open [M :vector-i64] :bool
 (let [old (gn-g M gn-g-open) old_n (gn-g M gn-g-open-n)
       set (-> M (gn-gs gn-g-open {f}) (gn-gs gn-g-open-n 1)) got (t-chain-check set)
       restore (-> set (gn-gs gn-g-open old) (gn-gs gn-g-open-n old_n))] (not got)))
(defn- t-chain-duplicate [M :vector-i64] :bool
 (let [at (+ MM-SIR-BASE (* {foreign} MM-SIR-W)) old_op (vector-at M at) old_a (vector-at M (+ at 1))
       set (-> M (t-put at OP-LABEL) (t-put (+ at 1) {label})) got (t-chain-check set)
       restore (-> set (t-put at old_op) (t-put (+ at 1) old_a))] (not got)))
(defn- t-chain-find-fix [M :vector-i64 k :i64] :i64
 (if (>= k (vector-at M MM-FIX-N)) 0
  (let [b (+ MM-FIX-BASE (* k MM-FIX-W))]
   (if (and (= (vector-at M (+ b XF-AUX)) 2) (= (vector-at M (+ b XF-TARGET)) {finish})) k (t-chain-find-fix M (inc k))))))
(defn- t-chain-layout-mut [M :vector-i64 k :i64 at :i64 value :i64] :bool
 (let [base (+ MM-FIX-BASE (* k MM-FIX-W)) code (+ MM-CODE-BASE (vector-at M (+ base XF-AT)))
       old (vector-at M at) word (vector-at M code) ep (vector-at M MM-ERR-POS) en (vector-at M MM-ERR-N)
       set (t-put M at value) run (ly-fix-one set k) refused (not= (vector-at run MM-ERR) 0)
       restore (-> run (t-put at old) (t-put code word) (t-put MM-ERR 0) (t-put MM-ERR-POS ep) (t-put MM-ERR-N en))] refused))
(defn- t-chain-layout-guards [M :vector-i64] :bool
 (let [k (t-chain-find-fix M 1) b (+ MM-FIX-BASE (* k MM-FIX-W))
       at (+ MM-CODE-BASE (vector-at M (+ b XF-AT)))
       entry (+ MM-CODE-BASE (gn-fnf M {finish} FF-CODE))]
  (and (> k 0) (= (vector-at M entry) 0xd2800005)
       (t-chain-layout-mut M k (+ b XF-AUX) 3)
       (t-chain-layout-mut M k (inc entry) (enc-ldr 8 7 (+ CTX-FUEL 8)))
       (t-chain-layout-mut M k (+ b XF-AUX) -1)
       (t-chain-layout-mut M k entry 0xd2800025)
       (t-chain-layout-mut M k at 0x94000000)
       (t-chain-layout-mut M k (+ b XF-KIND) FX-B26))))
(defn- t-chain-guards [M :vector-i64] :bool
 (and (t-chain-check M) (gn-chain-target M {finish})
 {' '.join(f'(t-chain-mut M {at} {v})' for at,v in cases)}
 (t-chain-open M) (t-chain-duplicate M)
 (not (gn-chain-target M 0)) (not (gn-chain-target M (vector-at M MM-FN-N)))
 (not (gn-chain-target M {fns['lv_sink']}))
 (not (gn-chain-target M {fns['lv_writer']}))
 (t-chain-layout-guards M)))
'''
text=m.kotoba(True).replace('(defn- seed-main [] :i64',typeform+probe+'(defn- seed-main [] :i64').replace('        M1 (gn-run (t-vector-chain-types (t-small-types M0)))','        M1 (gn-run (t-lv-types (t-vector-chain-types (t-small-types M0))))').replace('(if (and mask_shared','(if (and (t-chain-guards M1) mask_shared')
parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];src=w/'mutation-probe.kotoba';src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+(w/'42-layout-prototype.kotoba').read_text()+'\n'+text);env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/'mutation-probe.kseed')]),('extract',['extract-native',str(w/'mutation-probe.kseed'),'--symbol','main','--output',str(w/'mutation-probe.bin')])]:
 q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/('mutation-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(stage,q.stdout[-300:],q.stderr)
 if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
q=subprocess.run([str(w/'kexe-loader'),str(w/'mutation-probe.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/'mutation-probe.stdout').write_text(q.stdout+q.stderr);assert q.returncode==0,(q.stdout[-300:],q.stderr);(w/'mutation-proof.json').write_text(json.dumps({'status':'complete-native-chain-source-and-layout-refusals','sourceFieldMutations':len(cases),'layoutRefusals':6,'openRefusals':1,'duplicateLabelRefusal':True,'invalidOrIncompatibleCalleeControls':4,'positiveTargetControls':2,'mutations':cases},indent=2)+'\n');print('PASS',len(cases),'native chain source mutations and5 actual private-layout marker/opcode/aux refusals')
