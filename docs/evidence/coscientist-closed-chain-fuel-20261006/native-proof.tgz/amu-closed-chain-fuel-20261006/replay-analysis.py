from pathlib import Path
import json,ast,types,re
w=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());wrap=lambda x:((x+(1<<63))%(1<<64))-(1<<63)
def model(script,name):
 tree=ast.parse((w/script).read_text());node=next(z for z in tree.body if isinstance(z,ast.FunctionDef) and z.name==name);ns={'wrap':wrap,'m':types.SimpleNamespace(MIN=-(1<<63),MAX=(1<<63)-1)};exec(compile(ast.Module(body=[node],type_ignores=[]),script,'exec'),ns);return ns[name]
def state(row,result,remaining,items):
 assert row['baseline']==row['candidate'];q=row['candidate'];assert (q['exit']==0)==(result is not None);assert ':remaining '+str(remaining)+'}' in q['report'];assert q['items']==['DIAG_VECTOR_ITEMS '+str(len(items))+' '+' '.join(map(str,items))]
 if result is not None:assert ':result '+str(result)+' ' in q['report']
fo=model('fact-proof.py','oracle');fx=load(w/'fact-proof.json');assert len(fx['observations'])==9120
for z in fx['observations']:
 out=fo(z['variant'],*z['args'],z['fuel']);assert out==(z['expectedResult'],z['expectedRemaining'],z['expectedItems']);state(z,*out)
value=model('scratch-proof.py','value');sc=load(w/'scratch-proof.json');assert len(sc['observations'])==1445
for z in sc['observations']:
 a,b=z['args'];fuel=z['fuel'];v=value(z['operator'],a,b);items=[13,17,19,23,0,0,a,b,0,0,1];result=None;remaining=max(fuel-2,0)
 if fuel>=2 and v is not None:
  items[9]=v;remaining=max(fuel-3,0)
  if fuel>=3:items[4]=1;result=v
 assert (result,remaining,items)==(z['expectedResult'],z['expectedRemaining'],z['expectedItems']);state(z,result,remaining,items)
br=load(w/'branch-proof.json');assert len(br['observations'])==240
for z in br['observations']:
 kind=z['variant'];flag=z['flag'];fuel=z['fuel'];other=[13,17,19,23];inp=[flag,0,-(1<<63),(1<<63)-1,-1,42,1];charge=4 if kind in ['no_read','warm_cold'] else 3;remaining=max(0,fuel-charge);result=None
 if fuel>=charge and kind!='invalid_root':
  target=other if kind.startswith('diamond') and flag!=0 else inp;target[0]=wrap(target[0]+1);result=target[0]
 items=other+inp;assert (result,remaining,items)==(z['expectedResult'],z['expectedRemaining'],z['expectedItems']);state(z,result,remaining,items)
for name,count in [('ports-state.json',209),('resource-proof.json',38)]:
 x=load(w/name);assert x['comparisons']==len(x['runs'])==count
 for z in x['runs']:assert z['baseline']==z['candidate']
neg=load(w/'native-negative-proof.json');assert neg['controls']==3
for z in neg['rows']:assert z['baseline']==z['candidate'] and z['mutant']!=z['baseline']
per=load(w/'permanent-regression-proof.json');assert per['fixtures']==593 and per['runs']==25658 and len(per['observations'])==25658
out={'status':'complete-independent-retained-hand-oracle-and-translation-state-replay','fullStateGroups':11052,'actualNativeMutationsRefused':3,'permanentFixtures':593,'permanentNativeRunsRetained':25658,'freshNativeRunsInReplay':0,'oracleInputs':'Archived original fact, integer and branch models recomputed from source; no native execution or timing repeated.'};(w/'state-replay.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
