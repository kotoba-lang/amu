from pathlib import Path
import hashlib,json,shutil,subprocess,os,re
w=Path('/private/tmp/amu-static-vector-chain-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');b=w/'gate-build';old=Path('/private/tmp/amu-small-tail-frame-20261006/gate-build');b.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];unity=b/'seed-unity.kotoba';unity.write_text(''.join((r/p).read_text()+'\n' for p in parts));h=sha(unity);env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for stage,args in [('compile',['compile',str(unity),'--target','aarch64-macos','--output',str(b/'verified-unity.kseed')]),('extract',['extract-native',str(b/'verified-unity.kseed'),'--symbol','main','--output',str(b/'verified-unity.bin')])]:
 q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),(w/'seed-4.offset').read_text().strip(),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/('gate-unity-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(stage,q.stdout,q.stderr)
assert (b/'verified-unity.bin').read_bytes()==(w/'seed-4.bin').read_bytes()
for name in ['kexe-loader','kexe-benchmark']:shutil.copy2(old/name,b/name)
for k,g in enumerate([2,3,4]):
 for ext in ['bin','offset']:shutil.copy2(w/f'seed-{g}.{ext}',b/f'seed-{k}.{ext}')
 (b/f'seed-{k}.info').write_text(f'label LINEAGE native-generation-{g}; current MANIFEST unity independently rebuilt to exact bytes; not stage0\nunity-sha256 {h}\nseed-sha256 {sha(w/f"seed-{g}.bin")}\n')
(b/'seed-unity.kotoba.sha256').write_text(h+'\n');(w/'gate-build-lineage.json').write_text(json.dumps({'unitySha256':h,'currentManifestUnityIndependentlyRebuiltExact':True,'seed0IsBootstrapStage0':False,'generations':[{'gateCompiler':k,'actualNativeGeneration':g,'sha256':sha(w/f'seed-{g}.bin')} for k,g in enumerate([2,3,4])]},indent=2)+'\n');print('PASS current normalized MANIFEST unity emits exact fixed point')
