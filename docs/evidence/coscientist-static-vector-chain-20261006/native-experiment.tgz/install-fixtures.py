from pathlib import Path
import json,importlib.util,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-static-vector-chain-20261006');p=r/'scripts/seed/a64gen-fixtures.py';old=p.read_text();(w/'original-permanent-a64gen-fixtures.py').write_text(old)
# These are independently authored SIR/oracle fixtures already executed against
# both compilers. Promote their source to the authoritative generator, not its
# generated Kotoba or golden. No compiler pattern is mirrored in the oracle.
main=(w/'fixture-proof.py').read_text();scratch=(w/'scratch-proof.py').read_text();branch=(w/'branch-proof.py').read_text()
blocks=[main[main.index('writer='):main.index('fns,labels,lits,sir,frec=')],scratch[scratch.index('specs='):scratch.index('fns,labels,lits,sir,frec=')],branch[branch.index('read='):branch.index('fns,labels,lits,sir,frec=')]]
# scratch specs declaration shares a setup line; remove host setup before specs.
blocks[1]=blocks[1].split(';env=dict(')[0]
blocks=[z.replace('m.fx(', 'fx(').replace('m.MIN','MIN').replace('m.MAX','MAX') for z in blocks]
logic=main[main.index('wrap=lambda'):main.index('rows=[]')];logic=logic.replace('wrap=lambda x:((x+(1<<63))%(1<<64))-(1<<63)','wrap=s64').replace('m.MIN','MIN').replace('m.MAX','MAX')
value=scratch[scratch.index('wrap=lambda'):scratch.index('rows=[]')].replace('wrap=lambda x:((x+(1<<63))%(1<<64))-(1<<63)','wrap=s64').replace('m.MIN','MIN').replace('m.MAX','MAX')
body='\n'.join(blocks)+'\n'+logic+'\nfor kind,_,_ in variants_chain:\n pass\n'
# Preserve the chain variant list before branch fixture authoring rebinds variants.
blocks[0]+='\nvariants_chain=variants\n'
# Return independently predicted results and remaining fuel through normal native
# supervisor reports. Full item snapshots remain in the separate state proof.
body='\n'.join(blocks)+'\n'+logic+'''
for kind,_,_ in variants_chain:
 for a,b in pairs:
  for probe in [0,2,6,-1,7]:
   for fuel in [1,2,3,4,5,(1<<53)-1]:
    want,remaining,items=oracle(kind,a,b,probe,fuel)
    run('lv_'+kind+'_driver',[a,b,probe],want,fuel=fuel,fuel_remaining=remaining)
'''+value+'''
for kind,op in specs:
 name='scratch_'+op.lower().replace('-','_')+'_driver'
 for a,b in pairs:
  v=value(op,a,b)
  for fuel in [1,2,3,4,(1<<53)-1]:
   result='trap';remaining=max(fuel-2,0)
   if fuel>=2 and v is not None:
    remaining=max(fuel-3,0)
    if fuel>=3:result=v
   run(name,[a,b],result,fuel=fuel,fuel_remaining=remaining)
for kind in variants:
 for flag in [-1,0,1,MIN,MAX]:
  for fuel in [1,2,3,4,5,(1<<53)-1]:
   charge=4 if kind in ['no_read','warm_cold'] else 3
   result='trap'
   if fuel>=charge and kind!='invalid_root':result=14 if kind.startswith('diamond') and flag!=0 else s64(flag+1)
   run('sv_'+kind+'_driver',[flag],result,fuel=fuel,fuel_remaining=max(0,fuel-charge))
'''
# Helper has no machine-code/layout knowledge and cannot consult compiler output.
helper='''"""Independent SIR cases for closed vector descriptor chains (bootstrap tests)."""

def add_fixtures(fx, run, MIN, MAX, s64):
'''+''.join('    '+z+'\n' for z in body.splitlines())
# Check helper is executable before installing it; inspect expected fixture/runs.
compile(helper,'a64gen_vector_chain_fixtures.py','exec');(r/'scripts/seed/a64gen_vector_chain_fixtures.py').write_text(helper)
insertion='''# Native private vector chains: preserve the original fixture/run prefixes.
VECTOR_CHAIN_START=len(FIX)
from a64gen_vector_chain_fixtures import add_fixtures as _add_vector_chain_fixtures
_add_vector_chain_fixtures(fx,run,MIN,MAX,s64)

'''
needle='def kotoba(real_layout=False):';assert old.count(needle)==1;s=old.replace(needle,insertion+needle)
a="          '        M1 (gn-run (t-small-types M0))',";assert s.count(a)==1;s=s.replace(a,"          '        M1 (gn-run (t-vector-chain-types (t-small-types M0)))',")
a="    o += ['(defn- t-small-types [M :vector-i64] :vector-i64',";assert s.count(a)==1
z="""    o += ['(defn- t-vector-chain-types [M :vector-i64] :vector-i64',
          ' (-> M '+' '.join('(t-put '+str(C['MM-FN-BASE']+fns[name]*C['MM-FN-W']+fld)+' '+ty+')' for name,np,ns,dp,body in FIX[VECTOR_CHAIN_START:] for fld,ty in [(C['FF-RTYPE'],'TY-I64' if name.endswith('_driver') else 'TY-VEC')]+[(C['FF-PT0']+j,'TY-I64' if name.endswith('_driver') or j>0 else 'TY-VEC') for j in range(np)])+'))']
"""+a;s=s.replace(a,z)
a="         '        fnc (vector-at M (+ MM-FN-BASE (* g MM-FN-W) FF-CODE))',";assert s.count(a)==1;s=s.replace(a,"""         '        fn0 (vector-at M (+ MM-FN-BASE (* g MM-FN-W) FF-CODE))',
         '        aux (t-fixf M i XF-AUX)',
         '        fnc (if (= aux 0) fn0 (if (and (= aux 1) (= k FX-BL26) (= (bit-and w 0xfc000000) 0x14000000) (= (t-code M fn0) 0xd2800005)) (inc fn0) -1))',""")
a="         '          (= k FX-BL26) (t-patch1 M at (enc-patch-imm26 w (- fnc at)))',";s=s.replace(a,"         '          (= k FX-BL26) (if (< fnc 0) (t-put M MM-ERR 9999) (t-patch1 M at (enc-patch-imm26 w (- fnc at))))',")
a="        if 'fuel' in o: e['KEXE_FUEL'] = str(o['fuel'])";assert s.count(a)==1;s=s.replace(a,a+"\n        if 'fuel_remaining' in o: e['KEXE_STRUCTURED_REPORT'] = '1'")
a="        if good and 'stdout' in o:";assert s.count(a)==1;z="""        if 'fuel_remaining' in o:
            import re
            left=re.search(r':remaining (-?\\d+)',so)
            result=re.search(r':result (-?\\d+)',so)
            good=(p.returncode != 0 and b'KEXE_TRAP' in p.stderr) if expect=='trap' else (p.returncode==0 and result is not None and int(result[1])==expect)
            good=good and left is not None and int(left[1])==o['fuel_remaining']
"""+a;s=s.replace(a,z);p.write_text(s)
print('PASS authoritative fixture source installed; generated files not edited')
