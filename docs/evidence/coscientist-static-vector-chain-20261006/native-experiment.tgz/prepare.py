from pathlib import Path
import json,shutil,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');p=Path('/private/tmp/amu-private-vector-chain-20261006');w=Path('/private/tmp/amu-static-vector-chain-20261006');b=Path('/private/tmp/amu-small-tail-frame-20261006')
h=json.loads((p/'next-hypothesis.json').read_text());h['registration']='Before static-witness implementation and timing; product remains B';h['authoringException']='New one-off private-entry witness algorithm in temporary prototype; not mechanical product refactor.';(w/'hypothesis.json').write_text(json.dumps(h,indent=2)+'\n')
g=(p/'41-a64gen-prototype.kotoba').read_text();layout=(p/'42-layout-prototype.kotoba').read_text()
def rep(a,z):
 global g
 assert g.count(a)==1,(a,g.count(a));g=g.replace(a,z)
start=g.index('(defn- gn-chain-store ');end=g.index('\n(defn- gn-chain-fix ',start)
g=g[:start]+'''(defn- gn-chain-base [M :vector-i64 rv :i64 slot :i64] :vector-i64
 (let [known (gn-g M gn-f-vslot)
       hit (and (> slot 0) (= slot known))
       conditional (and (= known -1) (= slot 1))
       M1 (cond hit M
            conditional (gn-emit M (enc-cbnz 5 13))
            :else (-> M (gn-emit (enc-cbz 5 3)) (gn-emit (enc-cmp-r rv 5)) (gn-emit (enc-bcond (enc-cond-eq) 13))))
       M2 (if hit M1
          (-> M1 (gn-mov 5 rv) (gn-hchk 5 312 320)
           (gn-emit (enc-ldp 17 3 16 0)) (gn-emit (enc-ldr 4 7 328)) (gn-emit (gn-e-addsl 4 4 17 3))))]
  (gn-gs M2 gn-f-vslot slot)))
(defn- gn-chain-read [M :vector-i64 rv :i64 ri :i64 d :i64 slot :i64] :vector-i64
 (if (not= (gn-g M gn-f-vmode) 2) (gn-vread M rv ri d)
  (-> M (gn-chain-base rv slot)
   (gn-emit (enc-cmp-r ri 3)) (gn-emit (enc-bcond (enc-cond-lo) 2)) (gn-emit (gn-e-udf))
   (gn-emit (gn-e-ldrr d 4 ri 1)))))
(defn- gn-chain-store [M :vector-i64 rv :i64 ri :i64 rx :i64 slot :i64] :vector-i64
 (if (not= (gn-g M gn-f-vmode) 2)
  (-> M (gn-hchk rv 312 320) (gn-vidx ri) (gn-emit (gn-e-strr3 rx 16 17)))
  (-> M (gn-chain-base rv slot)
      (gn-emit (enc-cmp-r ri 3)) (gn-emit (enc-bcond (enc-cond-lo) 2)) (gn-emit (gn-e-udf))
      (gn-emit (gn-e-strr3 rx 4 ri)))))
''' +g[end:]
rep('(defn- gn-chain-fix [M :vector-i64 f :i64 n :i64]', '(defn- gn-chain-fix [M :vector-i64 f :i64 t :i64 n :i64]')
rep('(and (= (gn-g M gn-f-vmode) 2) (= n 1) (gn-chain-target M f))','(and (= (gn-g M gn-f-vmode) 2) (= n 1) (> (gn-g M gn-f-vslot) 0)\n                    (gn-isk M t gn-k-local) (= (gn-dv M t) (gn-g M gn-f-vslot)) (gn-chain-target M f))')
rep('(gn-chain-fix f n)', '(gn-chain-fix f t n)')
rep('(if (and (> s 0) (= s (gn-g M gn-f-vslot)))', '(if (and (> s 0) (or (= s (gn-g M gn-f-vslot)) (and (= s 1) (= (gn-g M gn-f-vslot) -1))))')
rep('(gn-gs gn-f-h 0) (gn-vclear) (gn-tree-entry f)', '(gn-gs gn-f-h 0) (gn-vclear) (gn-gs gn-f-vslot (if (= (gn-g M2 gn-f-vmode) 2) -1 0)) (gn-tree-entry f)')
rep('(let [M1 (gn-pin M (inc t))\n        ri', '(let [slot (if (gn-isk M t gn-k-local) (gn-dv M t) 0)\n        M1 (gn-pin M (inc t))\n        ri')
rep('(gn-ldt t 17 0) (gn-vread rv ri d)', '(gn-ldt t 17 0) (gn-chain-read rv ri d slot)')
rep('(defn- gn-rt-set [M :vector-i64 t :i64] :vector-i64\n  (let [M1 (-> M (gn-pin t) (gn-pin (inc t)))', '(defn- gn-rt-set [M :vector-i64 t :i64] :vector-i64\n  (let [slot (if (gn-isk M t gn-k-local) (gn-dv M t) 0)\n        M1 (-> M (gn-pin t) (gn-pin (inc t)))')
rep('(gn-chain-store rv ri rx)', '(gn-chain-store rv ri rx slot)')
helper=''';; -1 means key0 OR the unchanged entry-root handle; positive slot means
;; every reaching path completed that slot's original checked access. Entry
;; does no speculative validation. Only such a positive witness crosses a tail.
(defn- gn-chain-step [M :vector-i64 i :i64 op :i64 a :i64] :vector-i64
 (if (not= (gn-g M gn-f-vmode) 2) (gn-vstep M op a)
  (cond (or (= op OP-CONST) (= op OP-LGET) (= op OP-FUEL)) M
        (and (= op OP-BIN) (< a BOP-F64-ADD)) M
        (and (= op OP-CMP) (< a CC-F64-EQ)) M
        (and (= op OP-UN) (< a UOP-F64-NEG)) M
        (= op OP-LSET) (gn-vdrop M a)
        (= op OP-CALL) (let [w (gn-call-wrapper M i a (gn-sir M i IF-B) (gn-sir M i IF-C))]
          (if (or (> w 0) (and (= (gn-op M (inc i)) OP-RET) (= (gn-sir M (inc i) IF-A) (gn-sir M i IF-B)))) M (gn-gs M gn-f-vslot 0)))
        (= op OP-RT) (if (or (= a RT-VECTOR-AT) (= a RT-VECTOR-ASSOC-IN-PLACE)) M (gn-gs M gn-f-vslot 0))
        :else (gn-gs M gn-f-vslot 0))))
'''
rep('(defn- gn-ins [',helper+'(defn- gn-ins [')
rep('(gn-ins-quiet (gn-vstep M op (gn-sir M i IF-A)) i op)', '(gn-ins-quiet (gn-chain-step M i op (gn-sir M i IF-A)) i op)')
(w/'41-a64gen-prototype.kotoba').write_text(g);(w/'42-layout-prototype.kotoba').write_text(layout)
parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join(g if x=='seed/41-a64gen.kotoba' else layout if x=='seed/42-layout.kotoba' else (r/x).read_text() for x in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader'),('full-state-loader','full-state-loader')]:shutil.copy2(b/src,w/dst)
for n in ['build.py','check-ports.py','ports-state.py','resource-proof.py','permanent-regression.py','fixture-proof.py','scratch-proof.py','new-resource-proof.py','mutation-proof.py']:
 s=(p/n).read_text().replace(str(p),str(w));(w/n).write_text(s)
abi=json.loads((p/'internal-abi.json').read_text());abi['schema']='amu.closed-mode2-statically-witnessed-vector-private-entry/v2';abi['privateTailFix']='XF-AUX1 only if positive completed-access witness and actual argument descriptor matches unchanged witness slot; conditional key at target0-or-entryroot';abi['sourcePins']={n:hashlib.sha256((w/n).read_bytes()).hexdigest() for n in ['41-a64gen-prototype.kotoba','42-layout-prototype.kotoba']};(w/'internal-abi.json').write_text(json.dumps(abi,indent=2)+'\n');print('PASS prospective static-witness candidate prepared')
