from pathlib import Path
import json,re,subprocess,sys
w=Path(__file__).resolve().parent;load=lambda n:json.loads((w/(n+'.json')).read_text());total=0
for name,key,count in [('fixture-proof','observations',9450),('branch-proof','observations',240),('scratch-proof','observations',1445),('new-resource-proof','rows',90),('ports-state','runs',209),('resource-proof','runs',38)]:
 d=load(name);assert d['comparisons']==len(d[key])==count
 for row in d[key]:
  a=row['baseline'];assert a==row['candidate']
  if key=='observations':
   assert int(re.search(r':remaining (-?\d+)',a['report'])[1])==row['expectedRemaining'];vals=list(map(int,a['items'][0].split()[1:]));assert vals[0]==len(vals)-1 and vals[1:]==row['expectedItems'];res=row['expectedResult']
   if isinstance(res,int):assert a['exit']==0 and int(re.search(r':result (-?\d+)',a['report'])[1])==res
   else:assert a['exit']==120
 total+=count
assert total==11472
q=subprocess.run([sys.executable,str(w/'replay-timing.py')]);assert q.returncode==0
print('PASS offline 11472 stored full-state comparisons/oracles plus raw30 timing/source/native/C/fuel audit; not a fresh native rerun')
