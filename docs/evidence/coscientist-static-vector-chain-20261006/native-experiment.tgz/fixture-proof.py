from pathlib import Path
import importlib.util,json,os,re,subprocess,struct,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-static-vector-chain-20261006');raw=(r/'scripts/seed/a64gen-fixtures.py').read_text().replace("R = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))","R = '/Users/junkawasaki/github/wt/amu-seed17'",1);(w/'frozen-fixtures.py').write_text(raw);sp=importlib.util.spec_from_file_location('fx',w/'frozen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);old=len(m.FIX)
writer=[('LABEL','lv_w_entry'),('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('RET',0)]
m.fx('lv_writer',3,3,writer)
m.fx('lv_charged_writer',3,3,[('FUEL',)]+[tuple('lv_cw_entry' if a=='lv_w_entry' else a for a in op) for op in writer])
m.fx('lv_sink',1,1,[('LGET',0,1),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('LGET',0,1),('RET',0)])
m.fx('lv_finish',1,2,[('FUEL',),('LGET',0,1),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('CONST',1,1),('BIN','BOP-ADD',0),('LSET',2,0),('LGET',0,1),('CONST',1,0),('LGET',2,2),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('LGET',0,1),('CALL','lv_sink',0,1),('RET',0)])
prefix=[('FUEL',),('LGET',0,1),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('LSET',2,0),('LGET',0,1),('CONST',1,1),('RT','RT-VECTOR-AT',0,2),('LSET',3,0),('LGET',0,1),('LGET',1,2),('RT','RT-VECTOR-AT',0,2)]
loadwrite=[('LSET',2,0),('LGET',0,1),('LGET',1,3),('LGET',2,2)]
variants=[('normal','lv_writer',[]),('zero','lv_writer',[]),('direct',None,[]),('branch','lv_writer',[('BR','lv_branch_join'),('LABEL','lv_branch_join')]),('charged','lv_charged_writer',[]),('changed','lv_writer',[('LGET',0,1),('CONST',1,6),('RT','RT-VECTOR-AT',0,2),('LSET',1,0)]),('ns4','lv_writer',[('CONST',0,91),('LSET',4,0)]),('dp4','lv_writer',[]),('quot0','lv_writer',[]),('quotneg','lv_writer',[]),('quot3','lv_writer',[]),('twice','lv_writer',[]),('transfer_new','lv_writer',[]),('transfer_invalid','lv_writer',[]),('write_first','lv_writer',[])]
for kind,target,extra in variants:
 arith=[('CONST',1,0 if kind=='quot0' else -1 if kind=='quotneg' else 3 if kind=='quot3' else 7),('BIN','BOP-QUOT' if kind.startswith('quot') else 'BOP-ADD',0)]
 head=prefix+[('CONST',3,17)] if kind=='dp4' else prefix
 if kind=='ns4':extra=[('CONST',2,91),('LSET',4,2)]
 ops=head+arith+loadwrite
 if kind=='zero':ops[-1]=('CONST',2,0)
 if kind=='changed':ops +=extra+[('LGET',0,1),('LGET',1,3),('LGET',2,2)]
 else:ops +=extra+([('LGET',2,2)] if kind=='ns4' else [])
 ops += [('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3)] if target is None else [('CALL',target,0,3)]
 if kind=='twice':ops += [('LGET',0,1),('CONST',1,0),('CONST',2,-99),('CALL','lv_writer',0,3)]
 if kind in ['transfer_new','transfer_invalid']:ops += [('LGET',0,1),('CONST',1,6 if kind=='transfer_new' else 4),('RT','RT-VECTOR-AT',0,2)]
 if kind=='write_first':ops=[('FUEL',),('LGET',0,1),('CONST',1,2),('CONST',2,7),('CALL','lv_writer',0,3)]
 ops += [('CALL','lv_finish',0,1),('RET',0)];m.fx('lv_'+kind,1,4 if kind=='ns4' else 3,ops)
 driver=[('FUEL',),('CONST',0,13),('CONST',1,17),('CONST',2,19),('CONST',3,23),('VEC',0,4),('LSET',4,0),('LGET',0,1),('LGET',1,2),('CONST',2,m.MIN),('CONST',3,m.MAX),('CONST',4,-1),('CONST',5,42),('LGET',6,4),('VEC',0,7),('CALL','lv_'+kind,0,1),('LGET',1,3),('RT','RT-VECTOR-AT',0,2),('RET',0)]
 m.fx('lv_'+kind+'_driver',3,4,driver)
fns,labels,lits,sir,frec=m.layout_tables();typeform='(defn- t-lv-types [M :vector-i64] :vector-i64 (-> M '+' '.join('(t-put '+str(m.C['MM-FN-BASE']+fns[name]*m.C['MM-FN-W']+field)+' '+ty+')' for name,np,ns,dp,b in m.FIX[old:] for field,ty in [(m.C['FF-RTYPE'],'TY-I64' if name.endswith('_driver') else 'TY-VEC')]+[(m.C['FF-PT0']+j,'TY-I64' if name.endswith('_driver') or j>0 else 'TY-VEC') for j in range(np)])+'))\n'
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];images={}
for label,g in [('baseline','baseline-41-a64gen.kotoba'),('candidate','41-a64gen-prototype.kotoba')]:
 text=m.kotoba(True).replace('(defn- seed-main [] :i64',typeform+'(defn- seed-main [] :i64').replace('        M1 (gn-run (t-small-types M0))','        M1 (gn-run (t-lv-types (t-small-types M0)))');src=w/(label+'-fixture.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/g).read_text()+'\n'+(w/'42-layout-prototype.kotoba').read_text()+'\n'+text)
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'-fixture.kseed'))]),('extract',['extract-native',str(w/(label+'-fixture.kseed')),'--symbol','main','--output',str(w/(label+'-fixture-generator.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-fixture-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-400:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'-fixture-generator.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'-fixture.stdout')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout[-500:],q.stderr);blob,offsets=m.blob_from(q.stdout);p=w/(label+'-fixture.bin');p.write_bytes(blob);images[label]=(p,offsets);print('PASS native fixture',label,len(blob),flush=True)
wrap=lambda x:((x+(1<<63))%(1<<64))-(1<<63)
def oracle(kind,a,b,probe,fuel):
 other=[13,17,19,23];inp=[a,b,m.MIN,m.MAX,-1,42,1];result='trap';remaining=max(fuel-2,0)
 arith_ok=True;read_ok=kind=='write_first' or 0<=a<7
 if fuel>=2 and read_ok:
  if kind=='write_first':v=7;wi=2
  else:
   v=inp[a];wi=b
   if kind=='quot0':arith_ok=False
   elif kind=='quotneg':arith_ok=v!=m.MIN;v=wrap(-v)
   elif kind=='quot3':v=(abs(v)//3)*(-1 if v<0 else 1)
   else:v=0 if kind=='zero' else wrap(v+7)
  if arith_ok:
   charges=3 if kind=='charged' else 2;remaining=max(fuel-charges,0);dest=other if kind=='changed' else inp
   if fuel>=charges and 0<=wi<len(dest):
    dest[wi]=v
    if kind=='twice':dest[0]=-99
    # Final parameter fetch occurs before the finish charge. transfer_new
    # index6 is valid, transfer_invalid index4 is valid; loaded -1 traps
    # at finish's original checked read after its charge.
    handle=inp[6] if kind=='transfer_new' else inp[4] if kind=='transfer_invalid' else (1 if dest is other else 2)
    target=other if handle==1 else inp if handle==2 else None
    remaining=max(fuel-charges-1,0)
    if fuel>=charges+1 and target is not None:
     target[0]=wrap(target[0]+1)
     if 0<=probe<len(target):result=target[probe]
 return result,remaining,other+inp
pairs=[(0,0),(0,1),(1,1),(2,2),(2,3),(3,2),(4,0),(5,6),(6,5),(2,6),(6,6),(-1,0),(7,0),(m.MIN,0),(m.MAX,0),(2,-1),(2,7),(2,m.MIN),(2,m.MAX),(2,4),(2,5)]
rows=[]
for kind,_,_ in variants:
 for a,b in pairs:
  for probe in [0,2,6,-1,7]:
   for fuel in [1,2,3,4,5,(1<<53)-1]:
    name='lv_'+kind+'_driver';want,remaining,items=oracle(kind,a,b,probe,fuel);obs={}
    for label,(path,offsets) in images.items():
     env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');env.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'full-state-loader'),str(path),str(offsets[fns[name]]),'3','aarch64','-',str(a),str(b),str(probe)],env=env,capture_output=True,text=True);lines=re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':lines,'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)};assert (q.returncode==0)==(want!='trap'),(kind,a,b,probe,fuel,want,label,q.stdout,q.stderr)
     assert ':remaining '+str(remaining)+'}' in q.stdout and ':vectors {:capacity 4096 :used 2}' in q.stdout and ':vector-items {:capacity 65536 :used 11}' in q.stdout,(kind,a,b,probe,fuel,remaining,label,q.stdout)
     assert lines==['DIAG_VECTOR_ITEMS 11 '+' '.join(map(str,items))],(kind,a,b,probe,fuel,label,lines,items)
     if want!='trap':assert ':result '+str(want)+' ' in q.stdout,(kind,a,b,probe,fuel,want,label,q.stdout)
    assert obs['baseline']==obs['candidate'],(kind,a,b,probe,fuel,obs);rows.append({'variant':kind,'args':[a,b,probe],'fuel':fuel,'expectedResult':want,'expectedRemaining':remaining,'expectedItems':items,**obs})
 print('PASS independent fullstate read/write model',kind,flush=True)
regions=[]
for kind,_,_ in variants:
 name='lv_'+kind;words={label:[z[0] for z in struct.iter_unpack('<I',path.read_bytes()[offs[fns[name]]:offs[fns[name]+1]])] for label,(path,offs) in images.items()};regions.append({'variant':kind,'baselineWords':len(words['baseline']),'candidateWords':len(words['candidate'])})
(w/'fixture-proof.json').write_text(json.dumps({'status':'complete-independent-native-public-private-cold-changed-invalid-alias-read-write-partial-fuel-state','comparisons':len(rows),'originalFixtures':old,'newFixtures':len(m.FIX)-old,'regions':regions,'images':{label:{'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} for label,(path,_) in images.items()},'observations':rows},indent=2)+'\n');print('PASS all',len(rows),'independent exact vector-state oracles',flush=True)
