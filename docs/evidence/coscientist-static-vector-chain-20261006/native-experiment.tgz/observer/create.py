from pathlib import Path
import json,hashlib,subprocess,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-static-vector-chain-20261006/observer');b=Path('/private/tmp/amu-static-vector-chain-20261006');g=Path('/private/tmp/amu-static-vector-chain-20261006/41-a64gen-prototype.kotoba').read_text();(w/'baseline-41-a64gen.kotoba').write_text(g)
def rep(a,z):
 global g
 assert g.count(a)==1,(a,g.count(a));g=g.replace(a,z,1)
def out(prefix,fields):
 s='"\\n"'
 for x in reversed(fields):s=f'(string-concat (string-from-i64 {x}) (string-concat " " {s}))'
 return f'(io-out (string-concat "{prefix} " {s}))'
snap=''';; One-off observation only: no generator-state writes.
(defn- gn-census-snapshot [M :vector-i64 i :i64] :i64
 (if (>= i (vector-at M MM-SIR-N)) 0
  (let [printed '''+out('SIR',['i','(gn-op M i)','(gn-sir M i IF-A)','(gn-sir M i IF-B)','(gn-sir M i IF-C)'])+'''] (gn-census-snapshot M (inc i)))))
'''
rep('(defn- gn-run-open [',snap+'(defn- gn-run-open [')
rep('        M1 (mem-alloc M0 (+ gn-a-lp MM-LABEL-CAP 2))','        printed (gn-census-snapshot M0 1)\n        M1 (mem-alloc M0 (+ gn-a-lp MM-LABEL-CAP 2))')
rep('                leaf (gn-g M2 gn-f-leaf)]','                leaf (gn-g M2 gn-f-leaf)\n                printed '+out('FN',['f','i','F','ns','dp','(gn-g M2 gn-f-nsv)','leaf','(vector-at M2 MM-CODE-N)'])+']')
rep('    (let [M1 (gn-ins M i (gn-op M i))\n          k (gn-g M1 gn-f-skip)]','    (let [start (vector-at M MM-CODE-N)\n          before_slot (gn-g M gn-f-vslot)\n          before_mode (gn-g M gn-f-vmode)\n          M1 (gn-ins M i (gn-op M i))\n          k (gn-g M1 gn-f-skip)\n          cacheprinted '+out('CACHE',['i','before_mode','before_slot','(gn-g M1 gn-f-vmode)','(gn-g M1 gn-f-vslot)'])+'\n          printed '+out('EMIT',['i','k','start','(vector-at M1 MM-CODE-N)'])+']')
(w/'observer-41-a64gen.kotoba').write_text(g)
parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')]
(w/'observer-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (b/'42-layout-prototype.kotoba').read_text() if x=='seed/42-layout.kotoba' else (r/x).read_text())+'\n' for x in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader')]:shutil.copy2(b/src,w/dst)
s=Path('/private/tmp/amu-unsigned-less-20261006/observer/observe.py').read_text().replace('amu-unsigned-less-20261006','amu-static-vector-chain-20261006')
(w/'observe.py').write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'status':'registered-before-observation','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'hypothesis':'Complete native SIR/emission regions identify repeated cost in bounded read-only affine multiply-accumulate loops; inspect actual current product and unchanged C before implementing guarded loop composition.','observationOnly':True,'generatorStateUnmodified':True,'productChanged':False,'notRuntimeTimeShares':True,'notPerformanceMeasurement':True,'seedSha256':hashlib.sha256((w/'seed-0.bin').read_bytes()).hexdigest(),'sourceSha256':hashlib.sha256((r/'seed/41-a64gen.kotoba').read_bytes()).hexdigest(),'authoringException':'New one-off read-only diagnostic event schema; no existing AST refactor rule; temporary only, not product code.','goal':'C-or-better all19 original aligned workloads; not official Embench score.'},indent=2)+'\n')
print('PASS registered read-only native census; state13/14 untouched')
