from pathlib import Path
import json,shutil,subprocess,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-affine-chain-20261006');b=Path('/private/tmp/amu-loop-high-temp-20261006');g=(r/'seed/41-a64gen.kotoba').read_text();(w/'baseline-41-a64gen.kotoba').write_text(g)
helper=''';; Closed affine chain in an actual loop; integer wrap semantics unchanged.
;; Intermediate high temps must die before any subsequent read. Keep original
;; frame/locals and final result placement; no callee-register allocation.
(defn- gn-affine-chain? [M :vector-i64 i :i64 t :i64] :bool
 (let [a (gn-sir M i IF-B) b (gn-sir M (+ i 3) IF-B)
       factor (gn-sir M (inc i) IF-B) prefix (gn-dv M (dec t))]
  (and (>= t 7) (< (inc t) (gn-g M gn-f-dp)) (< (+ i 5) (vector-at M MM-SIR-N))
       (> a 0) (<= a (gn-g M gn-f-ns)) (> b 0) (<= b (gn-g M gn-f-ns))
       (>= (gn-sreg M a) 0) (>= (gn-sreg M b) 0)
       (gn-isk M (dec t) gn-k-const) (>= prefix -4095) (<= prefix 4095)
       (not= factor 0) (not= factor 1) (not= factor -1)
       (= (gn-sir M i IF-C) 0)
       (= (gn-op M (inc i)) OP-CONST) (= (gn-sir M (inc i) IF-A) (inc t)) (= (gn-sir M (inc i) IF-C) 0)
       (= (gn-op M (+ i 2)) OP-BIN) (= (gn-sir M (+ i 2) IF-A) BOP-MUL) (= (gn-sir M (+ i 2) IF-B) t) (= (gn-sir M (+ i 2) IF-C) 0)
       (= (gn-op M (+ i 3)) OP-LGET) (= (gn-sir M (+ i 3) IF-A) (inc t)) (= (gn-sir M (+ i 3) IF-C) 0)
       (= (gn-op M (+ i 4)) OP-BIN) (= (gn-sir M (+ i 4) IF-A) BOP-ADD) (= (gn-sir M (+ i 4) IF-B) t) (= (gn-sir M (+ i 4) IF-C) 0)
       (= (gn-op M (+ i 5)) OP-BIN) (= (gn-sir M (+ i 5) IF-A) BOP-ADD) (= (gn-sir M (+ i 5) IF-B) (dec t)) (= (gn-sir M (+ i 5) IF-C) 0)
       (gn-high-loop M i) (gn-kills M (+ i 6) t 16) (gn-kills M (+ i 6) (inc t) 16))))
(defn- gn-affine-chain [M :vector-i64 i :i64 t :i64] :vector-i64
 (let [out (dec t) s (gn-co M (+ i 5) out) d (gn-dreg M out s)
       a (gn-sreg M (gn-sir M i IF-B)) b (gn-sreg M (gn-sir M (+ i 3) IF-B))
       factor (gn-sir M (inc i) IF-B) prefix (gn-dv M out)
       M1 (-> M (gn-protect out s) (gn-mov-imm 16 factor)
              (gn-emit (enc-madd d a 16 b)) (gn-bin-imm BOP-ADD d d prefix)
              (gn-fin out s d))]
  (gn-gs M1 gn-f-skip (+ 5 (gn-g M1 gn-f-skip)))))
'''
needle=';; one SIR instruction (unreachable ones';assert g.count(needle)==1;g=g.replace(needle,helper+'\n'+needle,1);needle='OP-LGET (gn-def M a gn-k-local b)';assert g.count(needle)==1;g=g.replace(needle,'OP-LGET (if (gn-affine-chain? M i a) (gn-affine-chain M i a) (gn-def M a gn-k-local b))',1);(w/'41-a64gen-prototype.kotoba').write_text(g)
parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader'),('clobber-full-state-loader','clobber-full-state-loader')]:shutil.copy2(b/src,w/dst)
for n in ['build.py','check-ports.py','permanent-regression.py','ports-state.py']:
 s=Path('/private/tmp/amu-callee-temp-20261006',n).read_text().replace('amu-callee-temp-20261006','amu-affine-chain-20261006');(w/n).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'status':'registered-before-native-build-and-measurement','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'hypothesis':'Compose exact dynamic high-depth affine chain with MADD+known small prefix, original frame/locals/final placement and bounded dead-temp/loop proof.','priorRegistration':json.loads((r/'docs/evidence/coscientist-loop-temp-registers-20261006/next-hypothesis.json').read_text()),'authoringException':'One-off new experimental Kotoba code-generation algorithm, not a mechanical source rewrite. Product untouched pending semantics/performance/full gates.','baselineSeedSha256':hashlib.sha256((w/'seed-0.bin').read_bytes()).hexdigest(),'timingRule':'Every changed original guest fresh30triples; load<=4 idle>=90 RSD<=10 ratio>=1.05 and meanGap>sumSD; no identical-code retiming.','goal':'C-or-better across all19 original unchanged aligned workloads, native selfhost; not officialscore.'},indent=2)+'\n');print('PASS registered affine-chain prototype before native build')
