from pathlib import Path
import importlib.util,subprocess,os,json,re,hashlib,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-affine-chain-20261006');sp=importlib.util.spec_from_file_location('fx',w/'permanent-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);baseFIX=list(m.FIX);cases=[]
for t in [7,8,10,17,31,63]:
 for factor in [2,20,-3,m.MIN,m.MAX,65537]:
  for prefix in [-4095,0,4095]:
   for mode in ['plain','coalesced','alias']:
    name=f'ac_{len(cases)}';out=t-1;label=name+'_loop';body=[('FUEL',),('CONST',0,1),('LSET',3,0),('LABEL',label)]+[('LGET',j,1) for j in range(out)]+[('CONST',out,prefix),('LGET',t,1),('CONST',t+1,factor),('BIN','BOP-MUL',t),('LGET',t+1,2),('BIN','BOP-ADD',t),('BIN','BOP-ADD',out)]
    if mode!='plain':body += [('LSET',1 if mode=='alias' else 5,out),('LGET',out,1 if mode=='alias' else 5)]
    body += [('BIN','BOP-ADD',j) for j in range(out-1,-1,-1)]+[('LSET',5,0),('LGET',0,3),('CONST',1,1),('BIN','BOP-SUB',0),('LSET',3,0),('FUEL',),('BRNZ',0,label),('LGET',0,5),('RET',0)];m.fx(name,3,5,body);cases.append({'name':name,'t':t,'factor':factor,'prefix':prefix,'mode':mode,'admit':True})
# Refusal: an immediately observed intermediate is part of the original contract.
for mode in ['future-ret2','cold','large-prefix','zero-factor','one-factor','minusone-factor']:
 name='ac_refuse_'+mode;t=7;out=6;factor=0 if mode=='zero-factor' else 1 if mode=='one-factor' else -1 if mode=='minusone-factor' else 20;prefix=4096 if mode=='large-prefix' else 800;label=name+'_loop';body=[('FUEL',),('CONST',0,1),('LSET',3,0),('LABEL',label),('CONST',out,prefix),('LGET',t,1),('CONST',t+1,factor),('BIN','BOP-MUL',t),('LGET',t+1,2),('BIN','BOP-ADD',t),('BIN','BOP-ADD',out)]
 if mode=='future-ret2':body += [('RET2',out),('FUEL',),('BR',label)]
 else:
  body += [('LSET',5,out),('LGET',0,3),('CONST',1,1),('BIN','BOP-SUB',0),('LSET',3,0),('FUEL',)]
  if mode!='cold':body += [('BRNZ',0,label)]
  body += [('LGET',0,5),('RET',0)]
 m.fx(name,3,5,body);entry=name
 if mode=='future-ret2':
  entry=name+'_call';m.fx(entry,3,3,[('FUEL',),('LGET',0,1),('LGET',1,2),('LGET',2,3),('CALL',name,0,3),('RES2',1),('BIN','BOP-ADD',0),('RET',0)])
 cases.append({'name':name,'entry':entry,'t':t,'factor':factor,'prefix':prefix,'mode':mode,'admit':False})
authored=[f for f in m.FIX if f not in baseFIX];allAudits=[];rows=[]
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for batchN,begin in enumerate(range(0,len(cases),24)):
 batch=cases[begin:begin+24];names={c['name'] for c in batch}|{c.get('entry',c['name']) for c in batch};m.FIX=baseFIX+[f for f in authored if f[0] in names];sentinel=next(f for f in baseFIX if f[0]=='ht_cold_control');m.FIX.append(('ac_fixture_sentinel',*sentinel[1:]));ids={f[0]:j+1 for j,f in enumerate(m.FIX)};droot=w/('batch-'+str(batchN));droot.mkdir(exist_ok=True);images={}
 for label,gen in [('baseline-chain','baseline-41-a64gen.kotoba'),('candidate-chain','41-a64gen-prototype.kotoba')]:
  src=droot/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in ['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'])+'\n'+(w/gen).read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+m.kotoba(True))
  for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(droot/(label+'.kseed'))]),('extract',['extract-native',str(droot/(label+'.kseed')),'--symbol','main','--output',str(droot/(label+'.bin'))])]:
   q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(droot/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-300:],q.stderr)
   if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
  q=subprocess.run([str(w/'kexe-loader'),str(droot/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0,(label,q.stdout[-300:],q.stderr);(droot/(label+'.stdout')).write_text(q.stdout);blob,fc=m.blob_from(q.stdout);bp=droot/(label+'-fixture.bin');bp.write_bytes(blob);images[label]=(bp,fc)
  for c in batch:
   k=ids[c['name']];chunk=blob[fc[k]:fc.get(k+1,len(blob))];ws=struct.unpack('<'+'I'*(len(chunk)//4),chunk);dr=0 if c['mode']=='alias' else 4 if c['mode']=='coalesced' else 15 if c['t']==7 else 16;word=0x9b100400+dr;count=ws.count(word);want=1 if label=='candidate-chain' and c['admit'] else 0;assert count==want,(label,c,hex(word),count,want);allAudits.append({'batch':batchN,'compiler':label,'case':c,'expectedMaddWord':hex(word),'maddCount':count})
 for c in batch:
  for a,b in [(m.MIN,m.MAX),(m.MAX,m.MIN),(-19,37),(0,0),(99,-101)]:
   for fuel in [1,2,16777216]:
    affine=m.s64(m.s64(a*c['factor'])+b);answer=m.s64(affine+c['prefix'])
    if c['admit']:answer=m.s64(answer+(c['t']-1)*a)
    if c['mode']=='future-ret2':answer=m.s64(answer+affine)
    valid=fuel>=2;obs={}
    for label,(bp,fc) in images.items():
     e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'clobber-full-state-loader'),str(bp),str(fc[ids[c.get('entry',c['name'])]]),'3','aarch64','-',str(a),str(b),'0'],env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
     assert (q.returncode==0)==valid,(label,c,a,b,fuel,q.stdout,q.stderr)
     if valid:assert re.search(r':result '+str(answer)+r'(?:\s|})',q.stdout),(label,c,a,b,fuel,answer,q.stdout)
     assert f':remaining {max(0,fuel-2)}' in q.stdout,(label,c,a,b,fuel,q.stdout)
    assert obs['baseline-chain']==obs['candidate-chain'],(c,a,b,fuel,obs);rows.append({'case':c,'a':a,'b':b,'fuel':fuel,'expected':answer if valid else 'trap',**obs})
 print('PASS chain batch',batchN,'cases',len(batch),'total states',len(rows),flush=True)
(w/'chain-cases.json').write_text(json.dumps(cases,indent=2)+'\n');(w/'chain-proof.json').write_text(json.dumps({'status':'complete-independent-native-affine-chain-overflow-alias-coalescing-liveness-refusal-fuel-state-proof','comparisons':len(rows),'cases':len(cases),'batches':batchN+1,'instructionAudit':allAudits,'observations':rows},indent=2)+'\n');print('PASS',len(rows),'independent affine-chain state comparisons',flush=True)
