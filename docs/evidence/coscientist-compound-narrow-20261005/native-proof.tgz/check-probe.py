from pathlib import Path
import subprocess,os,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-compound-narrow-20261005'); base=Path('/private/tmp/amu-sign-wrapper-20261005')
loader=w/'kexe-loader';runner=Path('/private/tmp/amu-embench-compare-20261004/runner');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
report={'hypothesis':'compound narrowing multiply shift specialization','rows':[]};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def compile(seed,src,d,symbols):
 d.mkdir(exist_ok=True,parents=True);out=d/'image.kseed'
 p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--','compile',str(src),'--target','aarch64-macos','--output',str(out)],env=env,capture_output=True,text=True);(d/'compile.log').write_text(p.stdout+p.stderr);assert p.returncode==0,(src,p.stdout,p.stderr)
 offsets={}
 for symbol in symbols:
  p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--','extract-native',str(out),'--symbol',symbol,'--output',str(d/'native.bin')],env=env,capture_output=True,text=True);(d/(symbol+'.extract.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(symbol,p.stderr);offsets[symbol]=int(re.search(r':offset (\d+)',p.stdout).group(1))
 return offsets
def run(d,off,n,fuel=16777216):
 e=dict(env,KEXE_FUEL=str(fuel));e.pop('KEXE_COMMAND',None)
 p=subprocess.run([str(loader),str(d/'native.bin'),str(off),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True)
 if p.returncode==0:
  value={'result':int(p.stdout.splitlines()[-1]),'contextFuelConsumed':None}
 else:
  assert 'KEXE_TRAP' in p.stderr,(n,fuel,p.returncode,p.stdout,p.stderr)
  value=None
 return {'exit':p.returncode,'value':value}
values=[-(1<<63),-(1<<63)+1,-65537,-65536,-32769,-32768,-32767,-257,-256,-255,-129,-128,-127,-2,-1,0,1,2,127,128,255,256,257,32767,32768,65535,65536,(1<<63)-1]
factors=[-4096,-4095,-669,-362,-1,0,1,196,277,362,669,4095,4096,(1<<63)-1]
symbols=['f'+str(i) for i in range(len(factors))]+['constant','high','alias','dynamic','nonmatch']
forms=['(defn- i16 [x :i64] :i64 (let [n (bit-and x 65535)] (if (>= n 32768) (- n 65536) n)))','(defn- floor-quot [x :i64 divisor :i64] :i64 (if (< x 0) (- 0 (quot (+ (- 0 x) (- divisor 1)) divisor)) (quot x divisor)))','(defn- transform [x :i64 factor :i64] :i64 (i16 (floor-quot (+ (* (i16 x) factor) 128) 256)))','(defn- almost [x :i64 factor :i64] :i64 (i16 (floor-quot (+ (* (i16 x) factor) 129) 256)))']
forms += [f'(defn f{i} [x :i64] :i64 (transform x {k}))' for i,k in enumerate(factors)]
forms+=['(defn constant [x :i64] :i64 (transform -9223372036854775808 362))','(defn high [x :i64] :i64 '+ '(+ x '*9+'(transform x 362)'+')'*9+')','(defn alias [x :i64] :i64 (let [a x b (transform x 362)] (+ a b)))','(defn dynamic [x :i64] :i64 (transform x (+ (bit-and x 7) 1)))','(defn nonmatch [x :i64] :i64 (almost x 362))']
src=w/'probe.kotoba';src.write_text('(ns probe (:export ['+' '.join(symbols)+']))\n'+'\n'.join(forms)+'\n')
def signed(x):
 x&=(1<<64)-1
 return x-(1<<64) if x>>63 else x
def i16(x):
 x&=65535
 return x-65536 if x>=32768 else x
def hand(x,k,bias=128):
 v=signed(signed(i16(x)*k)+bias)
 a=signed(signed(-v)+255) if v<0 else v;q=abs(a)//256;q=-q if a<0 else q
 return i16(signed(-q) if v<0 else q)
a=w/'probe-baseline';b=w/'probe-candidate';oa=compile(base/'seed-4.bin',src,a,symbols);ob=compile(w/'seed-4.bin',src,b,symbols)
for s in symbols:
 for n in values:
  for fuel in [16777216,1,2,3,4,5,6]:
   x=run(a,oa[s],n,fuel);y=run(b,ob[s],n,fuel)
   assert x==y,(s,n,fuel,x,y)
   if fuel==16777216:
    expected=hand(n,factors[int(s[1:])]) if s[0]=='f' else hand(-(1<<63),362) if s=='constant' else signed(9*n+hand(n,362)) if s=='high' else signed(n+hand(n,362)) if s=='alias' else hand(n,(n&7)+1) if s=='dynamic' else hand(n,362,129)
    assert x['exit']==0 and x['value']['result']==expected,(s,n,x,expected)
   report['rows'].append({'symbol':s,'input':n,'fuel':fuel,'exit':x['exit'],'result':None if x['value'] is None else x['value']['result']})
 print('PASS',s,flush=True)
 report['status']='in-progress';(w/'correctness.json').write_text(json.dumps(report,indent=2)+'\n')
report['status']='complete-signed-result-and-positive-fuel-budget-parity';report['executionAdapter']='Signed native loader; exact consumed counters unavailable here, separately checked on canonical workloads';report['sourceSha256']=sha(src);report['baselineBytes']=(a/'native.bin').stat().st_size;report['candidateBytes']=(b/'native.bin').stat().st_size
(w/'correctness.json').write_text(json.dumps(report,indent=2)+'\n')
