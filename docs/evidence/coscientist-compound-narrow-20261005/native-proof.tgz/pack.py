from pathlib import Path
import json,hashlib,tarfile,difflib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-compound-narrow-20261005');e=r/'docs/evidence/coscientist-compound-narrow-20261005';e.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((w/n).read_text())
proof=read('fixture-proof.json');ports=read('ports-correctness.json');gen=read('generations.json');tim=read('timing/results.json');s=tim['summary'];base=s['baseline'];cand=s['candidate'];gap=base['meanNsPerBody']-cand['meanNsPerBody'];spread=base['sdNs']+cand['sdNs'];assert len({x['sha256'] for x in gen[1:]})==1 and len(ports['entries'])==19
prior=json.loads(Path('/private/tmp/amu-sign-wrapper-20261005/ports-correctness.json').read_text());changed=[x['workload'] for x in ports['entries'] if x['nativeSha256']!=next(y for y in prior['entries'] if y['workload']==x['workload'])['nativeSha256']];assert changed==['picojpeg'] and not s['candidateImprovesBaseline']
summary={'status':'native-qualified-candidate-performance-promotion-rejected','hypothesis':read('hypothesis.json'),'generations':gen,'canonical':{'workloads':19,'exactResultsAndFuel':True,'exhaustionParity':True,'changedBinaries':changed},'bulk':read('bulk-state.json'),'fixtures':proof,'signedSourceGuestComparisons':len(read('correctness.json')['rows']),'nearMatchingDependencyGuestComparisons':len(read('dependency-correctness.json')['rows']),'sourceProbeFuel':'Positive fuel-budget result/trap parity only; native loader consumed counter unavailable. Canonical runner separately proves exact fuel.','performance':s,'meanGapNs':gap,'summedSdNs':spread,'fractionLessTime':1-cand['meanNsPerBody']/base['meanNsPerBody'],'decision':'reject; less than 5% speedup and gap less than summed SD','canonicalSourceSha256':sha(r/'bench/embench/picojpeg-full.kotoba'),'nativeCodeBytes':(w/'candidate/native.bin').stat().st_size,'baselineCodeBytes':45092,'prototypeOnly':True,'officialEmbenchScore':False,'formalPerfgateQualified':False,'COrBetterAchieved':False,'nextHypothesis':'Use native dynamic function/fuel counts to locate the dominant cost, preserving full canonical workload. A body consumes 222003 fuel units; local scalar transformations have not separated from variation. Do not weaken fuel semantics or compare memoized results against fresh C execution.'}
(e/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(e/'prototype.diff').write_text(''.join(difflib.unified_diff((r/'seed/41-a64gen.kotoba').read_text().splitlines(True),(w/'41-a64gen-prototype.kotoba').read_text().splitlines(True),fromfile='seed/41-a64gen.kotoba',tofile='prototype/41-a64gen.kotoba',n=0)))
exclude={'timing','baseline-lineage.json','candidate','ports-2','seed-0.bin','seed-0.offset','fixture-run'}
with tarfile.open(e/'native-proof.tgz','w:gz') as t:
 for p in sorted(w.iterdir()):
  if p.name not in exclude:t.add(p,arcname=p.name)
with tarfile.open(e/'timing.tgz','w:gz') as t:
 for name in ['timing','baseline-lineage.json','candidate','remote.py','hypothesis.json']:t.add(w/name,arcname=name)
print(json.dumps({k:summary[k] for k in ['signedSourceGuestComparisons','nearMatchingDependencyGuestComparisons','meanGapNs','summedSdNs','fractionLessTime']},indent=2));print([(p.name,p.stat().st_size) for p in e.iterdir()])
