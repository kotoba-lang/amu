from pathlib import Path
w=Path('/private/tmp/amu-compound-narrow-20261005');old=Path('/private/tmp/amu-floor-specialize-20261005/fixture-proof.py').read_text();prefix=old[:old.index('# Exact hand-written')].replace('/private/tmp/amu-floor-specialize-20261005','/private/tmp/amu-compound-narrow-20261005');tail=old[old.index('env=dict('):old.index('for name in [\'call_fq')]
body='''# Independently constructed scalar dependencies and compound chain.
sign=[('LGET',0,1),('CONST',1,65535),('BIN','BOP-AND',0),('LSET',2,0),('LGET',0,2),('CONST',1,32768),('CMP','CC-GE',0),('BRZ',0,'sg_else'),('LGET',0,2),('CONST',1,65536),('BIN','BOP-SUB',0),('BR','sg_exit'),('LABEL','sg_else'),('LGET',0,2),('LABEL','sg_exit'),('RET',0)]
floor=[('LGET',0,1),('CONST',1,0),('CMP','CC-LT',0),('BRZ',0,'fq_else'),('CONST',0,0),('CONST',1,0),('LGET',2,1),('BIN','BOP-SUB',1),('LGET',2,2),('CONST',3,1),('BIN','BOP-SUB',2),('BIN','BOP-ADD',1),('LGET',2,2),('BIN','BOP-QUOT',1),('BIN','BOP-SUB',0),('BR','fq_exit'),('LABEL','fq_else'),('LGET',0,1),('LGET',1,2),('BIN','BOP-QUOT',0),('LABEL','fq_exit'),('RET',0)]
def rename(name,rows):return [tuple(name+'_'+x if isinstance(x,str) and x.startswith(('sg_','fq_')) else x for x in row) for row in rows]
for fuel in [0,1]:
 m.fx('sg'+str(fuel),1,2,([('FUEL',)] if fuel else [])+rename('sg'+str(fuel),sign))
 m.fx('fq'+str(fuel),2,2,([('FUEL',)] if fuel else [])+rename('fq'+str(fuel),floor))
values=[m.MIN,m.MIN+1,-65537,-65536,-32769,-32768,-32767,-257,-256,-255,-129,-128,-127,-2,-1,0,1,2,127,128,255,256,257,32767,32768,65535,65536,m.MAX]
def narrow(x):
 x&=65535
 return x-65536 if x>=32768 else x
for c in [0,1]:
 for s in [0,1]:
  for f in [0,1]:
   name=f'tr{c}{s}{f}';charges=c+2*s+f
   chain=[('LGET',0,1),('CALL','sg'+str(s),0,1),('LGET',1,2),('BIN','BOP-MUL',0),('CONST',1,128),('BIN','BOP-ADD',0),('CONST',1,256),('CALL','fq'+str(f),0,2),('CALL','sg'+str(s),0,1),('RET',0)]
   m.fx(name,2,2,([('FUEL',)] if c else [])+chain)
   for k in [-4095,-362,0,362,4095]:
    caller=f'call_{name}_{k}';m.fx(caller,1,1,[('FUEL',),('FUEL',),('LGET',0,1),('CONST',1,k),('CALL',name,0,2),('RET',0)])
    for x in values:m.run(caller,[x],narrow((narrow(x)*k+128)>>8),fuel=2+charges)
    for budget in range(1,2+charges):m.run(caller,[1],'trap',fuel=budget)
   for k in [-4096,4096]:
    caller=f'fallback_{name}_{k}';m.fx(caller,1,1,[('FUEL',),('FUEL',),('LGET',0,1),('CONST',1,k),('CALL',name,0,2),('RET',0)])
    for x in values:m.run(caller,[x],narrow((narrow(x)*k+128)>>8),fuel=2+charges)
   caller='high_'+name;m.fx(caller,1,1,[('FUEL',),('FUEL',),('LGET',8,1),('CONST',9,362),('CALL',name,8,2),('RET',8)])
   for x in values:m.run(caller,[x],narrow((narrow(x)*362+128)>>8),fuel=2+charges)
   caller='const_'+name;m.fx(caller,0,0,[('FUEL',),('FUEL',),('CONST',0,m.MIN),('CONST',1,362),('CALL',name,0,2),('RET',0)]);m.run(caller,[],0,fuel=2+charges)
'''
audit='''for name in ['call_tr000_362','call_tr111_-4095','high_tr101','const_tr111','fallback_tr000_4096']:
 f=names.index(name)+1;end=fns.get(f+1,int(re.search(r'words (\\d+)',chunks[1]).group(1))*4);words=struct.unpack('<'+'I'*((end-fns[f])//4),blob[fns[f]:end]);bl=sum((x&0xfc000000)==0x94000000 for x in words);b=sum((x&0xfc000000)==0x14000000 for x in words);sdiv=sum((x&0xffe0fc00)==0x9ac00c00 for x in words)
 if name.startswith('fallback'):assert bl+b>0,(name,bl,b)
 else:assert bl==b==sdiv==0,(name,bl,b,sdiv)
 audit[name]={'directBL':bl,'directB':b,'SDIV':sdiv,'bytes':end-fns[f]}
(w/'fixture-proof.json').write_text(json.dumps({'runs':len(m.RUNS),'fixtures':len(m.FIX),'realTestLayoutIdentical':True,'instructionAudit':audit},indent=2)+'\\n');print('PASS compound instruction and fallback audits',flush=True)
'''
(w/'fixture-proof.py').write_text(prefix+body+tail+audit)
