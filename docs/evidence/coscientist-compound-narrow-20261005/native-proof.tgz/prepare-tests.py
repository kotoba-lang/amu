from pathlib import Path
w=Path('/private/tmp/amu-compound-narrow-20261005');old=Path('/private/tmp/amu-floor-specialize-20261005/check-probe.py').read_text();prefix=old[:old.index('values=')].replace('/private/tmp/amu-floor-specialize-20261005','/private/tmp/amu-compound-narrow-20261005').replace('wrapped quotient helper specialization','compound narrowing multiply shift specialization')
rest='''values=[-(1<<63),-(1<<63)+1,-65537,-65536,-32769,-32768,-32767,-257,-256,-255,-129,-128,-127,-2,-1,0,1,2,127,128,255,256,257,32767,32768,65535,65536,(1<<63)-1]
factors=[-4096,-4095,-669,-362,-1,0,1,196,277,362,669,4095,4096,(1<<63)-1]
symbols=['f'+str(i) for i in range(len(factors))]+['constant','high','alias','dynamic','nonmatch']
forms=['(defn- i16 [x :i64] :i64 (let [n (bit-and x 65535)] (if (>= n 32768) (- n 65536) n)))','(defn- floor-quot [x :i64 divisor :i64] :i64 (if (< x 0) (- 0 (quot (+ (- 0 x) (- divisor 1)) divisor)) (quot x divisor)))','(defn- transform [x :i64 factor :i64] :i64 (i16 (floor-quot (+ (* (i16 x) factor) 128) 256)))','(defn- almost [x :i64 factor :i64] :i64 (i16 (floor-quot (+ (* (i16 x) factor) 129) 256)))']
forms += [f'(defn f{i} [x :i64] :i64 (transform x {k}))' for i,k in enumerate(factors)]
forms+=['(defn constant [x :i64] :i64 (transform -9223372036854775808 362))','(defn high [x :i64] :i64 '+ '(+ x '*9+'(transform x 362)'+')'*9+')','(defn alias [x :i64] :i64 (let [a x b (transform x 362)] (+ a b)))','(defn dynamic [x :i64] :i64 (transform x (+ (bit-and x 7) 1)))','(defn nonmatch [x :i64] :i64 (almost x 362))']
src=w/'probe.kotoba';src.write_text('(ns probe (:export ['+' '.join(symbols)+']))\\n'+'\\n'.join(forms)+'\\n')
def signed(x):
 x&=(1<<64)-1
 return x-(1<<64) if x>>63 else x
def i16(x):
 x&=65535
 return x-65536 if x>=32768 else x
def hand(x,k,bias=128):
 v=signed(signed(i16(x)*k)+bias)
 a=signed(signed(-v)+255) if v<0 else v;q=abs(a)//256;q=-q if a<0 else q
 return i16(signed(-q) if v<0 else q)
a=w/'probe-baseline';b=w/'probe-candidate';oa=compile(base/'seed-4.bin',src,a,symbols);ob=compile(w/'seed-4.bin',src,b,symbols)
for s in symbols:
 for n in values:
  for fuel in [16777216,1,2,3,4,5,6]:
   x=run(a,oa[s],n,fuel);y=run(b,ob[s],n,fuel)
   assert x==y,(s,n,fuel,x,y)
   if fuel==16777216:
    expected=hand(n,factors[int(s[1:])]) if s[0]=='f' else hand(-(1<<63),362) if s=='constant' else signed(9*n+hand(n,362)) if s=='high' else signed(n+hand(n,362)) if s=='alias' else hand(n,(n&7)+1) if s=='dynamic' else hand(n,362,129)
    assert x['exit']==0 and x['value']['result']==expected,(s,n,x,expected)
   report['rows'].append({'symbol':s,'input':n,'fuel':fuel,'exit':x['exit'],'result':None if x['value'] is None else x['value']['result']})
 print('PASS',s,flush=True)
 report['status']='in-progress';(w/'correctness.json').write_text(json.dumps(report,indent=2)+'\\n')
report['status']='complete-signed-result-and-positive-fuel-budget-parity';report['executionAdapter']='Signed native loader; exact consumed counters unavailable here, separately checked on canonical workloads';report['sourceSha256']=sha(src);report['baselineBytes']=(a/'native.bin').stat().st_size;report['candidateBytes']=(b/'native.bin').stat().st_size
(w/'correctness.json').write_text(json.dumps(report,indent=2)+'\\n')
'''
(w/'check-probe.py').write_text(prefix+rest)
