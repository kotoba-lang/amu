from pathlib import Path
import subprocess,os,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-compound-narrow-20261005'); base=Path('/private/tmp/amu-sign-wrapper-20261005')
loader=w/'kexe-loader';runner=Path('/private/tmp/amu-embench-compare-20261004/runner');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
report={'hypothesis':'compound narrowing multiply shift specialization','rows':[]};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def compile(seed,src,d,symbols):
 d.mkdir(exist_ok=True,parents=True);out=d/'image.kseed'
 p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--','compile',str(src),'--target','aarch64-macos','--output',str(out)],env=env,capture_output=True,text=True);(d/'compile.log').write_text(p.stdout+p.stderr);assert p.returncode==0,(src,p.stdout,p.stderr)
 offsets={}
 for symbol in symbols:
  p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--','extract-native',str(out),'--symbol',symbol,'--output',str(d/'native.bin')],env=env,capture_output=True,text=True);(d/(symbol+'.extract.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(symbol,p.stderr);offsets[symbol]=int(re.search(r':offset (\d+)',p.stdout).group(1))
 return offsets
def run(d,off,n,fuel=16777216):
 e=dict(env,KEXE_FUEL=str(fuel));e.pop('KEXE_COMMAND',None)
 p=subprocess.run([str(loader),str(d/'native.bin'),str(off),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True)
 if p.returncode==0:
  value={'result':int(p.stdout.splitlines()[-1]),'contextFuelConsumed':None}
 else:
  assert 'KEXE_TRAP' in p.stderr,(n,fuel,p.returncode,p.stdout,p.stderr)
  value=None
 return {'exit':p.returncode,'value':value}

forms=['(defn- wrong-sign [x :i64] :i64 (let [n (bit-and x 65534)] (if (>= n 32768) (- n 65536) n)))','(defn- i16 [x :i64] :i64 (let [n (bit-and x 65535)] (if (>= n 32768) (- n 65536) n)))','(defn- wrong-floor [x :i64 divisor :i64] :i64 (if (< x 0) (- 0 (quot (+ (- 0 x) (- divisor 2)) divisor)) (quot x divisor)))','(defn- floor-quot [x :i64 divisor :i64] :i64 (if (< x 0) (- 0 (quot (+ (- 0 x) (- divisor 1)) divisor)) (quot x divisor)))','(defn- changed-sign [x :i64 factor :i64] :i64 (wrong-sign (floor-quot (+ (* (wrong-sign x) factor) 128) 256)))','(defn- changed-floor [x :i64 factor :i64] :i64 (i16 (wrong-floor (+ (* (i16 x) factor) 128) 256)))','(defn sign-probe [x :i64] :i64 (changed-sign x 362))','(defn floor-probe [x :i64] :i64 (changed-floor x 362))']
symbols=['sign-probe','floor-probe'];src=w/'dependency-probes.kotoba';src.write_text('(ns deps (:export [sign-probe floor-probe]))\n'+'\n'.join(forms)+'\n');a=w/'deps-baseline';b=w/'deps-candidate';oa=compile(base/'seed-4.bin',src,a,symbols);ob=compile(w/'seed-4.bin',src,b,symbols);rows=[]
def narrow(x,mask=65535):
 x&=mask
 return x-65536 if x>=32768 else x
def hand(x,sign=False):
 mask=65534 if sign else 65535;v=narrow(x,mask)*362+128;z=-v+255 if sign else -v+254;q=z//256 if z>=0 else -((-z)//256);r=-q if v<0 else v//256
 return narrow(r,mask)
for symbol in symbols:
 for n in [-(1<<63),-(1<<63)+1,-32769,-32768,-257,-255,-129,-128,-3,-2,-1,0,1,2,3,127,128,129,255,256,32767,32768,(1<<63)-1]:
  for fuel in [16777216,1,2,3,4,5,6]:
   x=run(a,oa[symbol],n,fuel);y=run(b,ob[symbol],n,fuel);assert x==y,(symbol,n,fuel,x,y)
   if fuel==16777216:assert x['exit']==0 and x['value']['result']==hand(n,symbol=='sign-probe'),(symbol,n,x,hand(n,symbol=='sign-probe'))
   rows.append({'symbol':symbol,'input':n,'fuel':fuel,**x})
(w/'dependency-correctness.json').write_text(json.dumps({'status':'complete-near-matching-dependency-refusal-parity','rows':rows,'baselineBytes':(a/'native.bin').stat().st_size,'candidateBytes':(b/'native.bin').stat().st_size},indent=2)+'\n');print('PASS',len(rows),'dependency guest comparisons')
