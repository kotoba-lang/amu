from pathlib import Path
import json,shutil,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-compound-narrow-20261005');old=(r/'seed/41-a64gen.kotoba').read_text();g=old

def match(shape):
 return '\n                 '.join(f'(and (= (gn-op M (+ q {j})) {op}) (= (gn-sir M (+ q {j}) IF-A) {a}) (= (gn-sir M (+ q {j}) IF-B) {b}) (= (gn-sir M (+ q {j}) IF-C) {c}))' for j,(op,a,b,c) in enumerate(shape))
fs=[('OP-LGET',0,1,0),('OP-CONST',1,0,0),('OP-CMP','CC-LT',0,0),('OP-BRZ',0,'le',0),('OP-CONST',0,0,0),('OP-CONST',1,0,0),('OP-LGET',2,1,0),('OP-BIN','BOP-SUB',1,0),('OP-LGET',2,2,0),('OP-CONST',3,1,0),('OP-BIN','BOP-SUB',2,0),('OP-BIN','BOP-ADD',1,0),('OP-LGET',2,2,0),('OP-BIN','BOP-QUOT',1,0),('OP-BIN','BOP-SUB',0,0),('OP-BR','lx',0,0),('OP-LABEL','le',0,0),('OP-LGET',0,1,0),('OP-LGET',1,2,0),('OP-BIN','BOP-QUOT',0,0),('OP-LABEL','lx',0,0),('OP-RET',0,0,0),('OP-END','f',0,0)]
ss=[('OP-LGET',0,1,0),('OP-CONST',1,65535,0),('OP-BIN','BOP-AND',0,0),('OP-LSET','slot',0,0),('OP-LGET',0,'slot',0),('OP-CONST',1,32768,0),('OP-CMP','CC-GE',0,0),('OP-BRZ',0,'le',0),('OP-LGET',0,'slot',0),('OP-CONST',1,65536,0),('OP-BIN','BOP-SUB',0,0),('OP-BR','lx',0,0),('OP-LABEL','le',0,0),('OP-LGET',0,'slot',0),('OP-LABEL','lx',0,0),('OP-RET',0,0,0),('OP-END','f',0,0)]
cs=[('OP-LGET',0,1,0),('OP-CALL','sf',0,1),('OP-LGET',1,2,0),('OP-BIN','BOP-MUL',0,0),('OP-CONST',1,128,0),('OP-BIN','BOP-ADD',0,0),('OP-CONST',1,256,0),('OP-CALL','ff',0,2),('OP-CALL','sf',0,1),('OP-RET',0,0,0),('OP-END','f',0,0)]
helper=''';; Compound pure scalar proof. Tokens 4096+total original entry charges.
;; Every admitted dependency and operand is checked; no source name admission.
(defn- gn-comp-fuel [M :vector-i64 p :i64] :bool
  (or (not= (gn-op M (inc p)) OP-FUEL)
      (and (= (gn-sir M (inc p) IF-A) 0) (= (gn-sir M (inc p) IF-B) 0) (= (gn-sir M (inc p) IF-C) 0))))
(defn- gn-comp-sign [M :vector-i64 f :i64] :i64
  (let [p (gn-fnf M f FF-SIR)]
    (if (or (< p 1) (not= (gn-op M p) OP-FN) (not= (gn-sir M p IF-A) f)
            (not= (gn-sir M p IF-B) 1) (not (gn-comp-fuel M p))) 0
      (let [fuel (if (= (gn-op M (inc p)) OP-FUEL) 1 0) q (gn-skiplab M (+ p 1 fuel))
            slot (gn-sir M (+ q 3) IF-A) le (gn-sir M (+ q 7) IF-B) lx (gn-sir M (+ q 11) IF-A)]
        (if (and (> slot 1) (> le 0) (> lx 0) (not= le lx)
                 SIGNCHECKS) (inc fuel) 0)))))
(defn- gn-comp-floor [M :vector-i64 f :i64] :i64
  (let [p (gn-fnf M f FF-SIR)]
    (if (or (< p 1) (not= (gn-op M p) OP-FN) (not= (gn-sir M p IF-A) f)
            (not= (gn-sir M p IF-B) 2) (not (gn-comp-fuel M p))) 0
      (let [fuel (if (= (gn-op M (inc p)) OP-FUEL) 1 0) q (gn-skiplab M (+ p 1 fuel))
            le (gn-sir M (+ q 3) IF-B) lx (gn-sir M (+ q 15) IF-A)]
        (if (and (> le 0) (> lx 0) (not= le lx)
                 FLOORCHECKS) (inc fuel) 0)))))
(defn- gn-comp-wrapper [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :i64
  (let [p (gn-fnf M f FF-SIR) k (gn-sir M (dec i) IF-B)]
    (if (or (< p 1) (not= n 2) (not= (gn-op M p) OP-FN) (not= (gn-sir M p IF-A) f)
            (not= (gn-sir M p IF-B) 2) (not (gn-comp-fuel M p))
            (not= (gn-op M (dec i)) OP-CONST) (not= (gn-sir M (dec i) IF-A) (inc t))
            (< k -4095) (> k 4095)) 0
      (let [fuel (if (= (gn-op M (inc p)) OP-FUEL) 1 0) q (gn-skiplab M (+ p 1 fuel))
            sf (gn-sir M (inc q) IF-A) ff (gn-sir M (+ q 7) IF-A)]
        (if (and (> sf 0) (> ff 0) (not= f sf) (not= f ff) (not= sf ff)
                 COMPCHECKS)
          (let [s (gn-comp-sign M sf) z (gn-comp-floor M ff)]
            (if (and (> s 0) (> z 0)) (+ 4096 fuel (* 2 (dec s)) (dec z)) 0)) 0)))))
'''.replace('SIGNCHECKS',match(ss)).replace('FLOORCHECKS',match(fs)).replace('COMPCHECKS',match(cs))
a='(defn- gn-call-wrapper [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :i64\n  (if (= (gn-op M (inc i)) OP-RES2) 0\n      (let [w (gn-wrapper M f t n)] (if (> w 0) w (gn-sign-wrapper M f n)))))'
b=helper+'''(defn- gn-call-wrapper [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :i64
  (if (= (gn-op M (inc i)) OP-RES2) 0
    (let [w (gn-wrapper M f t n) s (if (> w 0) w (gn-sign-wrapper M f n))]
      (if (> s 0) s (gn-comp-wrapper M i f t n)))))''';assert g.count(a)==1;g=g.replace(a,b)
a='(if (>= w 1024) (>= w 1536) (>= w 256))';b='(if (>= w 4096) (> w 4096) (if (>= w 1024) (>= w 1536) (>= w 256)))';assert g.count(a)==1;g=g.replace(a,b)
a='(defn- gn-op-call [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :vector-i64'
b=''';; The admitted chain is total: signed16(x)*k+128 is within +/-134M.
;; All original fuel checks can precede its private arithmetic without changing
;; any observable effect, trap or allocation. Each charge retains its own check.
(defn- gn-comp-charges [M :vector-i64 n :i64] :vector-i64
  (if (= n 0) M (gn-comp-charges (gn-op-fuel M) (dec n))))
(defn- gn-call-comp [M :vector-i64 i :i64 t :i64 w :i64] :vector-i64
  (let [k (gn-sir M (dec i) IF-B) M1 (gn-comp-charges M (- w 4096))]
    (if (gn-isk M1 t gn-k-const)
      (let [x (bit-and (gn-dv M1 t) 65535) a (if (>= x 32768) (- x 65536) x)
            v (bit-and (i64-shift-right (+ (* a k) 128) 8) 65535)]
        (gn-def M1 t gn-k-const (if (>= v 32768) (- v 65536) v)))
      (let [s (gn-co M1 i t) d (gn-dreg M1 t s) x (gn-src M1 t 16 1)]
        (-> M1 (gn-protect t s) (gn-ldt t 16 1)
            (gn-emit (gn-e-bf 0x93400000 16 x 0 15)) (gn-mov-imm 17 k)
            (gn-emit (enc-mul 16 16 17)) (gn-emit (enc-add-i 16 16 128))
            (gn-emit (gn-e-bf 0x93400000 16 16 8 63))
            (gn-emit (gn-e-bf 0x93400000 d 16 0 15)) (gn-fin t s d))))))
'''+a;assert g.count(a)==1;g=g.replace(a,b)
a='(cond (>= w 1024) (gn-call-sign M i t w)';b='(cond (>= w 4096) (gn-call-comp M i t w)\n         (>= w 1024) (gn-call-sign M i t w)';assert g.count(a)==1;g=g.replace(a,b)
(w/'41-a64gen-prototype.kotoba').write_text(g)
files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];u=''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files);(w/'seed-unity.kotoba').write_text(u)
for ext in ['bin','offset']:shutil.copyfile(Path('/private/tmp/amu-sign-wrapper-20261005')/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile('/private/tmp/amu-sign-wrapper-20261005/kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['check-ports.py','bulk-state.py','remote.py']:
 s=Path('/private/tmp/amu-floor-specialize-20261005',name).read_text().replace('/private/tmp/amu-floor-specialize-20261005','/private/tmp/amu-compound-narrow-20261005').replace('/private/tmp/amu-zebulun-floor-specialize-20261005','/private/tmp/amu-zebulun-compound-narrow-20261005');(w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'hypothesis':'Exact pure scalar dependency chain signed16(x), multiply by adjacent constant |factor|<=4095, +128, exact wrapped-floor divisor256, signed16, can replace all calls with six arithmetic instructions, because narrowed product cannot overflow. Preserve every entry fuel charge.','promotion':'30 fresh rotating quiet baseline/candidate/C triples; >=5% speedup and gap>sumSD; unchanged canonical workload, native correctness and fixedpoint.','sourceHead':'4feb0fa773f98f55c25625fdc19419e5711efc9b','exception':'One-off new compiler algorithm authoring, not mechanical refactoring'},indent=2)+'\n')
