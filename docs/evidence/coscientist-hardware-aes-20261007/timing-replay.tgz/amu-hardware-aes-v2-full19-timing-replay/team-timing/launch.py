from pathlib import Path
import subprocess,json,hashlib
W=Path(__file__).resolve().parent;remote='/private/tmp/amu-zebulun-hardware-aes-v2-20261006-run';host='zebulun@100.66.28.79';key='/Users/junkawasaki/.ssh/murakumo';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
required=['timing-package.tgz','remote-timing.py','root-GO.json','root-final-proof.json'];go=json.loads((W/'root-GO.json').read_text());assert go['rootGO'] and sha(W/'root-final-proof.json')==go['rootFinalProofSha256'] and sha(W/'preflight.json')==go['preflightSha256']
for p,h in json.loads((W/'input-pins.json').read_text()).items():assert sha(Path(p))==h
for p,h in json.loads((W/'preflight.json').read_text())['proofPins'].items():assert sha(W/'timing-package'/p)==h
subprocess.run(['ssh','-i',key,'-o','BatchMode=yes',host,'mkdir '+remote],check=True)
subprocess.run(['scp','-i',key,*[str(W/p) for p in required],host+':'+remote+'/'],check=True)
pins={p:sha(W/p) for p in required};(W/'transfer-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
code='''from pathlib import Path
import json,hashlib,tarfile,subprocess,datetime,sys
r=Path(REMOTE);pins=PINS
for name,h in pins.items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==h
with tarfile.open(r/'timing-package.tgz','r:gz') as t:
 for m in t.getmembers():
  p=Path(m.name);assert not p.is_absolute() and '..' not in p.parts and (m.isfile() or m.isdir()) and not m.issym() and not m.islnk()
 t.extractall(r)
ref=Path('/private/tmp/amu-zebulun-paired-20261005');src=ref/'measurement-2/results.json';o=json.loads(src.read_text());spec=json.loads((r/'timing-package/paired-timing-spec.json').read_text());assert hashlib.sha256((ref/'environment/runner').read_bytes()).hexdigest()==o['runnerSha256']
for e in o['entries']:assert hashlib.sha256((ref/'measurement-2'/e['workload']/'c.dylib').read_bytes()).hexdigest()==e['cDylibSha256']
(r/'original-C-reference-provenance.json').write_bytes(src.read_bytes())
info={'timeUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uname':subprocess.check_output(['uname','-a'],text=True),'load':subprocess.check_output(['sysctl','-n','vm.loadavg'],text=True),'model':subprocess.check_output(['sysctl','-n','hw.model'],text=True),'cpu':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True),'logicalCPUs':subprocess.check_output(['sysctl','-n','hw.logicalcpu'],text=True)};(r/'remote-environment.json').write_text(json.dumps(info,indent=2)+'\\n')
feature=subprocess.run(['/usr/sbin/sysctl','-n','hw.optional.arm.FEAT_AES'],capture_output=True,text=True);assert feature.returncode==0 and feature.stdout.strip()=='1','FAIL_CLOSED unsupported AES feature before candidate guest'
(r/'launch-feature-recheck.json').write_text(json.dumps({'exit':feature.returncode,'stdout':feature.stdout,'stderr':feature.stderr,'beforeCandidateGuest':True,'externalExplicitOptIn':True},indent=2)+'\\n')
p=subprocess.run(['python3',str(r/'remote-timing.py')]);(r/'campaign-exit.json').write_text(json.dumps({'exit':p.returncode,'timeUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\\n');sys.exit(p.returncode)
'''.replace('REMOTE',repr(remote)).replace('PINS',repr(pins))
q=subprocess.run(['ssh','-i',key,'-o','BatchMode=yes',host,'python3 -'],input=code,text=True);raise SystemExit(q.returncode)
