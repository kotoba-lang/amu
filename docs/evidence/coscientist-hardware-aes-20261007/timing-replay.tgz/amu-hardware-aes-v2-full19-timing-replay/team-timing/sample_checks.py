"""Independent accepted/rejected raw-sample rule replay (no measurements)."""
import math

def close(a,b):return math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-9)
def check_samples(x,spec,n,expected_fuel):
 assert x['performanceMeasured'] is True and x['officialEmbenchScore'] is False
 assert x['host'].split('.')[0]==spec['host']
 assert 30==x['acceptedTriples']==spec['samplesPerArm']
 assert len(x['rows'])==3*x['attemptedTriples'] and x['attemptedTriples']<=spec['maximumPairAttempts']
 groups={};cal={}
 for z in x['calibrationRows']:
  arm=z['arm'];assert arm in ['baseline','candidate','C'];cal.setdefault(arm,[]).append(z)
  assert z['result']==1 and z['calls']>0 and z['elapsedNanoseconds']>0 and z['warmupCalls']==spec['warmupCalls']
  if arm!='C':assert z['contextFuelConsumed']==expected_fuel
 for arm in ['baseline','candidate','C']:
  zs=cal[arm];assert 1<=len(zs)<=5 and [z['calibrationAttempt'] for z in zs]==list(range(len(zs)))
  assert zs[0]['calls']==3 and x['callsByArm'][arm]==zs[-1]['calls']
  for i,z in enumerate(zs):
   elapsed=z['elapsedNanoseconds'];target=spec['targetIntervalNs'];hit=.75*target<=elapsed<=1.5*target
   assert hit==(i==len(zs)-1)
   if not hit:assert zs[i+1]['calls']==max(1,min(100000000,round(z['calls']*target/elapsed)))
 for z in x['rows']:
  arm=z['arm'];assert z['calls']==x['callsByArm'][arm] and z['calls']>0 and z['warmupCalls']==spec['warmupCalls'] and z['result']==1
  assert isinstance(z['accepted'],bool)
  if arm!='C':
   assert z['artifactKind']=='raw' and z['contextFuelConsumed']==expected_fuel and z['contextFuelBefore']-z['contextFuelAfter']==expected_fuel
  else:assert z['artifactKind']=='dylib'
  c=z['cpuActivityEnvelope'];before=c['before'];after=c['after'];delta=[b-a for a,b in zip(before['ticks'],after['ticks'])];assert delta==c['deltaTicks'] and len(delta)==4 and min(delta)>=0
  assert before['api']==after['api']=='host_processor_info/PROCESSOR_CPU_LOAD_INFO'
  assert before['processors']==after['processors']==c['logicalCpuCount']==10
  assert c['envelopeNs']==after['monotonicNs']-before['monotonicNs'] and c['envelopeNs']>=z['elapsedNanoseconds']>0 and c['childCpuNs']>=0
  idle=100*delta[2]/sum(delta);assert close(idle,c['idlePercent'])
  background=min(100.0,idle+100*c['childCpuNs']/(c['envelopeNs']*c['logicalCpuCount']));assert close(background,c['estimatedBackgroundIdlePercent'])
  reasons=[]
  if max(z['loadBefore'],z['loadAfter'])>spec['maximumLoad']:reasons.append('host-load')
  if z['elapsedNanoseconds']<spec['minimumIntervalNs']:reasons.append('short-interval')
  if background<spec['minimumBackgroundIdlePercent']:reasons.append('background-cpu')
  assert reasons==z['rejectionReasons']
  groups.setdefault(z['attempt'],[]).append(z)
 assert list(groups)==list(range(x['attemptedTriples']))
 accepted=0;arms=['baseline','candidate','C']
 for i,g in groups.items():
  assert [z['arm'] for z in g]==arms[i%3:]+arms[:i%3]
  good=all(not z['rejectionReasons'] for z in g);assert all(z['accepted']==good for z in g)
  accepted+=good
  if accepted==30:assert i==x['attemptedTriples']-1
 assert accepted==30
 return {'acceptedTriples':accepted,'rejectedTriples':len(groups)-accepted,'rawSamples':len(x['rows'])}


def check_baseline_descriptor(b):
 assert b['status']=='complete-provisional-timing'
 assert b['derivation'].startswith('Legacy measurement-input status label;')
 assert b['officialEmbenchScore'] is False
 assert set(b)=={'status','runnerSha256','matrixSpecSha256','entries','derivation','nativePreflightSha256','officialEmbenchScore'}
 assert len(b['entries'])==1
 assert set(b['entries'][0])=={'workload','iterationsPerCall','cSymbol','cDylibSha256','offset','nativeSha256'}
 return True
