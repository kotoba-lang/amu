from pathlib import Path
import json,copy
from sample_checks import check_samples,check_baseline_descriptor
D=Path(__file__).resolve().parent;P=D/'remote-evidence/timing-package';s=json.loads((P/'paired-timing-spec.json').read_text());x=json.loads((P/'aha-mont64/timing/results.json').read_text());n=json.loads((P/'aha-mont64/baseline/results.json').read_text())['entries'][0]['iterationsPerCall'];fuel=x['manifest']['expectedFuelPerCall'];rows=[]
rejected=next((i for i,z in enumerate(x['rows']) if not z['accepted'] and z['rejectionReasons']),None)
idle=next(i for i,z in enumerate(x['rows']) if z['cpuActivityEnvelope']['estimatedBackgroundIdlePercent']<100)
native=next(i for i,z in enumerate(x['rows']) if z['arm']!='C' and z['accepted'])
def fault(name,edit):
 z=copy.deepcopy(x);edit(z)
 try:check_samples(z,s,n,fuel)
 except (AssertionError,KeyError,ValueError) as e:rows.append({'fault':name,'detected':True})
 else:raise AssertionError('accepted '+name)
fault('wrong-order',lambda z:z['rows'].reverse())
fault('drop-rejected-triple',lambda z:z['rows'].__delitem__(slice(0,3)))
if rejected is not None:fault('accept-rejected-row',lambda z:z['rows'][rejected].__setitem__('accepted',True))
else:fault('false-rejected-row',lambda z:z['rows'][0].__setitem__('accepted',False))
fault('fake-cpu-idle',lambda z:z['rows'][idle]['cpuActivityEnvelope'].__setitem__('estimatedBackgroundIdlePercent',100))
fault('wrong-fuel',lambda z:z['rows'][native].__setitem__('contextFuelConsumed',fuel+1))
fault('wrong-calls',lambda z:z['rows'][3].__setitem__('calls',1))
fault('ignored-warmup',lambda z:z['rows'][3].__setitem__('warmupCalls',0))
fault('wrong-processor-count',lambda z:z['rows'][3]['cpuActivityEnvelope'].__setitem__('logicalCpuCount',12))
fault('premature-calibration',lambda z:z['calibrationRows'][0].__setitem__('elapsedNanoseconds',s['targetIntervalNs']))
baseline=json.loads((P/'aha-mont64/baseline/results.json').read_text());assert check_baseline_descriptor(baseline)
for name,edit in [('historical-statistics-in-descriptor',lambda b:b['entries'][0].__setitem__('meanNs',1)),('unmarked-legacy-input-status',lambda b:b.__setitem__('derivation','current completed measurement'))]:
 b=copy.deepcopy(baseline);edit(b)
 try:check_baseline_descriptor(b)
 except AssertionError:rows.append({'fault':name,'detected':True})
 else:raise AssertionError('accepted '+name)
(D/'checker-mutations.json').write_text(json.dumps({'status':'PASS independent raw audit checker fault calibration','controlsOnlyNotNewMeasurements':True,'rows':rows},indent=2)+'\n');print('PASS',len(rows),'audit fault controls')
