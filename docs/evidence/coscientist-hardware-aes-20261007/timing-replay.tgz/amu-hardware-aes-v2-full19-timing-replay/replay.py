from pathlib import Path
import hashlib,json,subprocess
R=Path(__file__).resolve().parent
for name,digest in json.loads((R/'payload-pins.json').read_text()).items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==digest,name
for name in ['timing-audit.py','checker-calibrate.py']:subprocess.run(['python3',str(R/'team-timing'/name)],check=True)
print('PASS complete retained raw campaign replay; nativeExecutions=0 newMeasurements=0')
