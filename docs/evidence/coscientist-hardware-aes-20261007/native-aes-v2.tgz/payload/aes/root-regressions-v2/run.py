from pathlib import Path
import subprocess,json
D=Path(__file__).resolve().parent;I=D.parent/'implementation-v2';S=Path('/private/tmp/amu-vector-shape-specialize-20261006/team-adoption-gates-v4/source')
rows=[]
for label,argv in [('readonly',['python3',str(S/'scripts/seed/a64gen_stable_vector_fixtures.py'),'--seed',str(I/'seed-4.bin'),'--loader',str(I/'kexe-loader'),'--out',str(D/'readonly')]),('scalar',['python3',str(S/'scripts/seed/a64gen_scalar_dag_fixtures.py'),'--seed',str(I/'seed-4.bin'),'--loader',str(I/'kexe-loader'),'--output',str(D/'scalar')]),('permanent',['python3',str(D/'permanent.py')])]:
 with (D/(label+'.stdout')).open('w') as so,(D/(label+'.stderr')).open('w') as se:
  p=subprocess.Popen(argv,stdout=so,stderr=se);(D/'live.json').write_text(json.dumps({'label':label,'pid':p.pid,'argv':argv})+'\n');rc=p.wait()
 rows.append({'label':label,'exit':rc,'argv':argv});(D/'execution-status.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,rc,flush=True);assert rc==0,(label,rc)
print('TERMINAL PASS all three regression suites',flush=True)
