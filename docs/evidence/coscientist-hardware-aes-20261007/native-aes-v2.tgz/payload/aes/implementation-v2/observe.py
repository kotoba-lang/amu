from pathlib import Path
import subprocess,os,re,json,hashlib
I=Path(__file__).resolve().parent;B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation');R=Path('/Users/junkawasaki/github/wt/amu-seed17');O=I/'observer';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def form(s,name):
 a=s.index('(defn- '+name+' ');depth=0;quoted=False;escaped=False
 for j in range(a,len(s)):
  c=s[j]
  if quoted:
   if escaped:escaped=False
   elif c=='\\':escaped=True
   elif c=='"':quoted=False
  elif c=='"':quoted=True
  elif c=='(':depth+=1
  elif c==')':
   depth-=1
   if depth==0:return s[a:j+1]
 raise ValueError(name)
def out(tag,fields):
 s='"\\n"'
 for x in reversed(fields):s=f'(string-concat (string-from-i64 {x}) (string-concat " " {s}))'
 return f'(io-out (string-concat "{tag} " {s}))'
g=(I/'41-a64gen-prototype.kotoba').read_text();b=(B/'observer/41.kotoba').read_text()
for name in ['gn-op-fn','gn-op-fn2','gn-loop']:g=g.replace(form(g,name),form(b,name))
extra='\n'.join(form(b,n) for n in ['gn-census-snapshot','gn-census-fixes'])
extra+='\n(defn- as-observe-args [M :vector-i64 t :i64 n :i64] :i64 (if (= n 0) 0 (let [printed '+out('ASARG',['t','(gn-dk M t)','(gn-dv M t)','(gn-sr M t 1)','(gn-home M t)','(gn-soff M (gn-home M t))'])+'] (as-observe-args M (inc t) (dec n)))))\n'
g=g.replace('(defn- as-call [',extra+'\n(defn- as-call [')
g=g.replace('(let [start (vector-at M MM-CODE-N) m0','(let [observed (as-observe-args M t 6) start (vector-at M MM-CODE-N) pre '+out('ASPRE',['i','f','t','start','(vector-at M MM-FIX-N)','(gn-g M gn-f-fb)','(gn-g M gn-f-h)','(gn-g M gn-f-ctx)','(gn-g M gn-f-vmode)'])+' m0')
needle='words (- (vector-at m4 MM-CODE-N) start)]';assert g.count(needle)==1
g=g.replace(needle,'words (- (vector-at m4 MM-CODE-N) start) post '+out('ASPOST',['i','guard','jump','fallback','after','(vector-at m4 MM-CODE-N)','words','(vector-at m4 MM-FIX-N)'])+']')
g=g.replace('m1 (mem-alloc m0 (+ gn-a-lp MM-LABEL-CAP 82))','observed_sir (gn-census-snapshot m0 1) m1 (mem-alloc m0 (+ gn-a-lp MM-LABEL-CAP 82))')
g=g.replace('m3 (gn-loop m2 1)]','m3 (gn-loop m2 1) observed_fix (gn-census-fixes m3 1)]')
(O/'41.kotoba').write_text(g);parts=[p.strip() for p in (I/'source-snapshot/seed/MANIFEST').read_text().splitlines() if p.strip() and not p.lstrip().startswith('#')]
(O/'unity.kotoba').write_text('\n'.join(g if p=='seed/41-a64gen.kotoba' else (I/'source-snapshot'/p).read_text() for p in parts))
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
def run(seed,args,log):
 q=subprocess.run([str(I/'kexe-loader'),str(seed),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);log.write_text(q.stdout+q.stderr);assert q.returncode==0,(args,q.stdout[-1000:],q.stderr[-1000:]);return q.stdout
run(I/'seed-4.bin',['compile',str(O/'unity.kotoba'),'--target','aarch64-macos','--output',str(O/'image.kseed')],O/'compile.log')
s=run(I/'seed-4.bin',['extract-native',str(O/'image.kseed'),'--symbol','main','--output',str(O/'seed.bin')],O/'extract.log');assert int(re.search(r':offset (\d+)',s)[1])==0
rows=[];base=json.loads((I/'ports-build.json').read_text())['entries']
for e in json.loads((I/'source-snapshot/bench/embench/comparison-matrix.json').read_text())['entries']:
 d=O/'ports'/e['workload'];d.mkdir(parents=True,exist_ok=True)
 run(O/'seed.bin',['compile',str(R/e['source']),'--target','aarch64-macos','--output',str(d/'image.kseed')],d/'compile.log')
 s=run(O/'seed.bin',['extract-native',str(d/'image.kseed'),'--symbol',e['symbol'],'--output',str(d/'native.bin')],d/'extract.log');offset=int(re.search(r':offset (\d+)',s)[1]);expected=next(x for x in base if x['workload']==e['workload']);assert sha(d/'native.bin')==expected['nativeSha256'] and offset==expected['offset']
 records={tag:[list(map(int,l.split()[1:])) for l in (d/'compile.log').read_text().splitlines() if l.startswith(tag+' ')] for tag in ['ASPRE','ASPOST','ASARG']};rows.append({'workload':e['workload'],'nativeSha256':sha(d/'native.bin'),'offset':offset,**records});print('PASS byteexact observer',e['workload'],len(records['ASPRE']),flush=True)
(O/'report.json').write_text(json.dumps({'status':'PASS readonly observer all19 byte+offset exact','sourceSha256':sha(O/'41.kotoba'),'nativeSha256':sha(O/'seed.bin'),'schemas':{'ASARG':'temp descriptorKind descriptorValue actualRegister home frameOffset','ASPRE':'sir target temp firstWord fixBefore frame height ctx vmode','ASPOST':'sir guardWord jumpWord fallbackWord afterCallWord finalWord completeWords fixAfter'},'entries':rows},indent=2)+'\n')
