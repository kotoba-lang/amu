from pathlib import Path
import subprocess,os,re,json,hashlib
I=Path(__file__).parent;D=I/'typed-controls';D.mkdir(exist_ok=True);R=Path('/Users/junkawasaki/github/wt/amu-seed17');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=(R/'bench/embench/batch-ports/nettle-aes.kotoba').read_text().split('(defn- last-round')[0]
names=re.findall(r'\(defn?-? ([^\s\[()]+)',s)
for name in sorted(names,key=len,reverse=True):s=re.sub(r'(?<![\w-])'+re.escape(name)+r'(?![\w-])','z-'+name,s)
s=re.sub(r'^\(ns[^\n]+','(ns controls.aes-column (:export [forward reverse modes run]))',s)
s+='''
(defn forward [a :i64 b :i64 c :i64 d :i64 key :i64] :i64 (bit-xor (z-table-round 0 a b c d key) 17))
(defn reverse [a :i64 b :i64 c :i64 d :i64 key :i64] :i64 (bit-xor (z-table-round 1 a b c d key) 17))
(defn modes [mode :i64 a :i64 b :i64 c :i64 key :i64] :i64 (bit-xor (z-table-round mode a b c -1 key) 17))
(defn run [n :i64] :i64 (forward n -1 -9223372036854775808 9223372036854775807 n))
'''
cases={'positive':s,'wrong-table':s.replace('(def z-enc-t0-0 [3328402341','(def z-enc-t0-0 [3328402340'),'wrong-byte':s.replace('(u64-shift-right x n) 255','(u64-shift-right x n) 254'),'wrong-lane':s.replace('(z-enc-t2 (z-byte-at c 16))','(z-enc-t2 (z-byte-at c 8))')}
# exact actual first table value, avoiding an ineffective source mutant
m=re.search(r'\(def z-enc-t0-0 \[(-?\d+)',s);v=int(m[1]);cases['wrong-table']=s[:m.start(1)]+str(v^1)+s[m.end(1):]
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
def command(seed,args,log):
 q=subprocess.run([str(I/'kexe-loader'),str(seed),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);log.write_text(q.stdout+q.stderr);assert q.returncode==0,(args,q.stdout[-1500:],q.stderr);return q.stdout
q=subprocess.run(['/usr/sbin/sysctl','-n','hw.optional.arm.FEAT_AES'],capture_output=True,text=True);(D/'local-feature.json').write_text(json.dumps({'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}));assert q.returncode==0 and q.stdout.strip()=='1'
values=[[0,0,0,0,0],[-1,-1,-1,-1,-1],[-9223372036854775808,9223372036854775807,-1,0,-9223372036854775808],[0x1234567812345678,-6066930332557189376,-8680820740569200767,-81985529216486896,9223372036854775807]]
rows=[]
for name,source in cases.items():
 d=D/name;d.mkdir(exist_ok=True);(d/'source.kotoba').write_text(source);offsets={};admissions=[]
 for label,seed in [('baseline',I/'seed-0.bin'),('candidate',I/'seed-4.bin'),('observer',I/'observer/seed.bin')]:
  command(seed,['compile',str(d/'source.kotoba'),'--target','aarch64-macos','--output',str(d/(label+'.kseed'))],d/(label+'-compile.log'))
  offsets[label]={}
  for symbol in ['forward','reverse','modes','run']:
   out=command(seed,['extract-native',str(d/(label+'.kseed')),'--symbol',symbol,'--output',str(d/(label+'-'+symbol+'.bin'))],d/(label+'-'+symbol+'-extract.log'));offsets[label][symbol]=int(re.search(r':offset (\d+)',out)[1])
 for symbol in offsets['candidate']:assert sha(d/('candidate-'+symbol+'.bin'))==sha(d/('observer-'+symbol+'.bin')) and offsets['candidate'][symbol]==offsets['observer'][symbol]
 admissions=[list(map(int,l.split()[1:])) for l in (d/'observer-compile.log').read_text().splitlines() if l.startswith('ASPRE ')]
 assert len(admissions)==(3 if name=='positive' else 0),(name,admissions)
 if not admissions:
  for symbol in offsets['candidate']:assert sha(d/('candidate-'+symbol+'.bin'))==sha(d/('baseline-'+symbol+'.bin')) and offsets['candidate'][symbol]==offsets['baseline'][symbol]
 pairs=[]
 for symbol,argslist in [('forward',values),('reverse',values),('modes',[[mode,*a[:3],a[4]] for mode in [0,1,-1,9223372036854775807] for a in values]),('run',[[x] for x in [0,1,-1,9223372036854775807,-9223372036854775808]])]:
  for index,args in enumerate(argslist):
   for fuel in [1,2,3,4,5,6,7,8,1048576]:
    outcomes=[]
    for label in ['baseline','candidate']:
     q=subprocess.run([str(I/'kexe-loader'),str(d/(label+'-'+symbol+'.bin')),str(offsets[label][symbol]),str(len(args)),'aarch64','-',*map(str,args)],env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1'),capture_output=True,text=True)
     outcomes.append({'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr});(d/f'{label}-{symbol}-{index}-f{fuel}.json').write_text(json.dumps(outcomes[-1]))
    assert outcomes[0]==outcomes[1],(name,symbol,args,fuel,outcomes)
    pairs.append({'symbol':symbol,'args':args,'fuel':fuel,'outcome':outcomes[1]})
 rows.append({'case':name,'sourceSha256':sha(d/'source.kotoba'),'admissions':admissions,'offsets':offsets,'pairs':pairs});print('PASS typedAES',name,len(admissions),len(pairs),flush=True)
(D/'report.json').write_text(json.dumps({'status':'PASS renamed typed whole-group admission/refusals and exact product native result/fuel/resource/status','pairs':sum(len(x['pairs']) for x in rows),'entries':rows,'fuelBoundary':'Product returns at remaining0 successfully; diagnostic zero-as-trap classifier not used.','timingRuns':0},indent=2)+'\n')
