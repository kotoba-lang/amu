from pathlib import Path
import subprocess,struct,json,re,os,hashlib
I=Path(__file__).parent;D=I/'isa-controls';D.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
q=subprocess.run(['/usr/sbin/sysctl','-n','hw.optional.arm.FEAT_AES'],capture_output=True,text=True);(D/'local-feature.json').write_text(json.dumps({'command':'sysctl -n hw.optional.arm.FEAT_AES','exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}));assert q.returncode==0 and q.stdout.strip()=='1'
# Exact assembler-bound body with reverse ordered pure register ABI shim:
# loader a,b,c,d,key inx0..4 -> compiler group mode,a,b,c,d,key inx0..5.
shim=[0xaa0403e5,0xaa0303e4,0xaa0203e3,0xaa0103e2,0xaa0003e1]
body=[0x4f00e401,0x1e270020,0x4e0c1c40,0x4e141c60,0x4e1c1c80,0x4e284820,0x4e286800,0x0e043c10,0xca050200,0xd65f03c0]
(D/'instruction.bin').write_bytes(struct.pack('<'+'I'*15,*(shim+body)))
src=Path('/Users/junkawasaki/github/wt/amu-seed17/bench/embench/batch-ports/nettle-aes.kotoba').read_text();tables=[]
for k in range(4):
 tables.append(sum([list(map(int,re.search(r'\(def enc-t'+str(k)+'-'+str(j)+r' \[([^]]+)\]',src)[1].split()))for j in range(2)],[]))
def expected(args):
 a,b,c,d,key=args;r=tables[0][a&255]^tables[1][(b>>8)&255]^tables[2][(c>>16)&255]^tables[3][(d>>24)&255]^ (key&((1<<64)-1));return r-(1<<64)if r>>63 else r
cases=[[0,0,0,0,0]]
for k in range(4):
 for b in range(32):
  a=[0]*5;a[k]=1<<b;cases.append(a)
cases += [[-1,-1,-1,-1,-1],[-9223372036854775808,9223372036854775807,-1,0,-9223372036854775808],[0x1234567812345678,0xabcdef00abcdef00- (1<<64),0x8765432187654321-(1<<64),0xfedcba98fedcba98-(1<<64),0x7fffffffffffffff]]
rows=[]
for a in cases:
 q=subprocess.run([str(I/'kexe-loader'),str(D/'instruction.bin'),'0','5','aarch64','-',*map(str,a)],env=dict(os.environ,KEXE_STRUCTURED_REPORT='1'),capture_output=True,text=True);want=expected(a);assert q.returncode==0,(a,q.stdout,q.stderr);got=int(re.search(r':result (-?\d+)',q.stdout)[1]);assert got==want,(a,got,want);rows.append({'args':a,'result':got,'status':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
# Wrong key phase uses key instead of zero lane, mutation must change result.
w=shim+body;w[10]=0x4e284800 # AESEv0,v0 instead of v1=zero
(D/'wrong-keyphase.bin').write_bytes(struct.pack('<'+'I'*len(w),*w));a=[1,2,3,4,5];q=subprocess.run([str(I/'kexe-loader'),str(D/'wrong-keyphase.bin'),'0','5','aarch64','-',*map(str,a)],env=dict(os.environ,KEXE_STRUCTURED_REPORT='1'),capture_output=True,text=True);got=int(re.search(r':result (-?\d+)',q.stdout)[1]);assert got!=expected(a)
(D/'report.json').write_text(json.dumps({'status':'PASS actual native AES lane/table value binding','cases':rows,'count':len(rows),'mutation':{'name':'AESEinput insteadzero key','expected':expected(a),'actual':got,'status':'DETECTED'},'officialSource':'https://documentation-service.arm.com/static/6023d61995978b529036da45','officialPages':[603,605],'semantics':'AESEkeybeforeSubBytes+ShiftRows, thereforezero key thenAESMC thenfulli64XOR; nativeencoding independentlyassembled. Not compiler/fuel proof, no timing.'},indent=2)+'\n');print('PASS nativeAESISA',len(rows))
