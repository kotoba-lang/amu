from pathlib import Path
import subprocess,os,re,json
I=Path(__file__).parent;D=I/'type-controls';D.mkdir(exist_ok=True);parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];s='\n'.join((I/'source-snapshot'/p).read_text()for p in parts)+'\n'+(I/'41-a64gen-prototype.kotoba').read_text()
s=s.replace('(ns seed (:export [main]))','(ns seed (:export [main probe]))')
s+='''
(defn seed-main [] :i64 0)
(defn- t-aes-node [M :vector-i64 n :i64 field :i64 value :i64] :vector-i64 (vector-assoc! M (+ MM-NODE-BASE (* n MM-NODE-W) field) value))
(defn- t-aes-types [M :vector-i64 k :i64] :vector-i64
 (if (= k 5) (vector-assoc! M (+ MM-FN-BASE MM-FN-W FF-NODE) 1)
  (t-aes-types (vector-assoc! M (+ MM-FN-BASE MM-FN-W FF-PT0 k) TY-I64) (inc k))))
(defn- t-aes-chain [M :vector-i64 n :i64] :vector-i64
 (if (= n 16) (t-aes-node M 16 NF-TYPE TY-I64)
  (t-aes-chain (t-aes-node M n NF-NEXT (inc n)) (inc n))))
(defn probe [which :i64] :i64
 (let [m0 (vector-alloc MM-WORDS) m1 (-> m0 (vector-assoc! MM-FN-N 2) (vector-assoc! MM-NODE-N 17)
  (t-aes-types 0) (t-aes-node 1 NF-FIRST 2) (t-aes-node 2 NF-NEXT 3) (t-aes-node 3 NF-NEXT 4)
  (t-aes-node 4 NF-FIRST 5) (t-aes-chain 5))
  m2 (cond (= which 1) (vector-assoc! m1 (+ MM-FN-BASE MM-FN-W FF-NODE) 0)
   (= which 2) (vector-assoc! m1 (+ MM-FN-BASE MM-FN-W FF-NODE) MM-NODE-CAP)
   (= which 3) (vector-assoc! m1 MM-NODE-N 1)
   (= which 4) (t-aes-node m1 1 NF-FIRST MM-NODE-CAP)
   (= which 5) (t-aes-node m1 2 NF-NEXT 2)
   (= which 6) (t-aes-node m1 10 NF-NEXT 10)
   (= which 7) (t-aes-node m1 16 NF-TYPE TY-F64)
   (= which 8) (t-aes-node m1 10 NF-NEXT MM-NODE-CAP)
   (= which 9) (t-aes-node m1 10 NF-NEXT 0)
   :else m1)
  f (if (= which 12) 0 1) k (cond (= which 10) 16 (= which 11) -1 :else 5)]
  (+ (as-pt m2 f k) (if (as-params m2 f 0 6) 100 0))))
'''
(D/'unit.kotoba').write_text(s);env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for label,args in [('compile',['compile',str(D/'unit.kotoba'),'--target','aarch64-macos','--output',str(D/'image.kseed')]),('extract',['extract-native',str(D/'image.kseed'),'--symbol','probe','--output',str(D/'guest.bin')])]:
 q=subprocess.run([str(I/'kexe-loader'),str(I/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(D/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout[-1000:],q.stderr)
 if label=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1])
# TY-F64 from exact shared contract, not an arbitrary test guess.
ctype=(I/'source-snapshot/seed/00-ns.kotoba').read_text();tyf=int(re.search(r'\(def TY-F64 (\d+)\)',ctype)[1]);want=[101,0,0,0,0,0,0,tyf,0,0,100,100,0];rows=[]
for which,value in enumerate(want):
 q=subprocess.run([str(I/'kexe-loader'),str(D/'guest.bin'),str(off),'1','aarch64','-',str(which)],env=dict(os.environ,KEXE_STRUCTURED_REPORT='1',KEXE_VECTOR_ITEMS='16777216'),capture_output=True,text=True);(D/f'case-{which}.stdout').write_text(q.stdout);(D/f'case-{which}.stderr').write_text(q.stderr);assert q.returncode==0,(which,q.stdout,q.stderr);got=int(re.search(r':result (-?\d+)',q.stdout)[1]);assert got==value,(which,got,value);rows.append({'case':which,'expected':value,'actual':got});print('PASS native checkedNFcontrol',which,got,flush=True)
(D/'report.json').write_text(json.dumps({'status':'PASS actual native checkedNF valid/sixthtype/wrongtype/zero/cap/count/outofrange/undefined/cycle/fn/k controls','cases':rows,'source':'Originalisolated00/01/02/40/41 closure, no checker stub/injection','finite':'32 steps eachas-nth plusboundedpriornodecyclecheck, nodefield reads guardcount/cap','timingRuns':0},indent=2)+'\n')
