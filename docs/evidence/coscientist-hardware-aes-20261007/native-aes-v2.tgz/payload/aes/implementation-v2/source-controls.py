from pathlib import Path
import subprocess,os,re,json,hashlib
I=Path(__file__).parent;D=I/'source-controls';D.mkdir(exist_ok=True);R=Path('/Users/junkawasaki/github/wt/amu-seed17');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
def command(seed,args,path):
 q=subprocess.run([str(I/'kexe-loader'),str(seed),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);path.write_text(q.stdout+q.stderr);assert q.returncode==0,(args,q.stdout[-1000:],q.stderr[-500:]);return q.stdout

def execute(p,off,args,fuel):
 q=subprocess.run([str(I/'kexe-loader'),str(p),str(off),str(len(args)),'aarch64','-',*map(str,args)],env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1'),capture_output=True,text=True);return {'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
q=subprocess.run(['/usr/sbin/sysctl','-n','hw.optional.arm.FEAT_AES'],capture_output=True,text=True);(D/'local-feature.json').write_text(json.dumps({'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}));assert q.returncode==0 and q.stdout.strip()=='1'
mutants=[('unsafe-table','(= (as-lit-word M (+ b (* 8 (- k lo)))) (as-table-word k role))','true','wrong-table','forward',[0,0,0,0,0],1048576),('key-before-AES','(gn-emit 0x4e284820)','(gn-emit 0x4e284800)','positive','forward',[1,2,3,4,5],1048576),('omitted-charge','(as-charges 6)','(as-charges 5)','positive','forward',[0,0,0,0,0],6),('unsafe-mode','(enc-cbnz 0 (- fallback guard))','(enc-cbnz 31 (- fallback guard))','positive','modes',[1,1,2,3,5],1048576),('site-budget-refusal','(< (gn-g M as-sites) 64)','(< (gn-g M as-sites) 0)','positive','forward',[1,2,3,4,5],1048576),('word-budget-refusal','(<= (+ (gn-g M as-used) 96) 4096)','(<= (+ (gn-g M as-used) 96) 1)','positive','forward',[1,2,3,4,5],1048576)]
base=json.loads((I/'typed-controls/report.json').read_text());rows=[]
for name,before,after,case,symbol,args,fuel in mutants:
 d=D/name;d.mkdir(exist_ok=True);s=(I/'unity.kotoba').read_text();assert s.count(before)==1;s=s.replace(before,after);(d/'unity.kotoba').write_text(s)
 command(I/'seed-0.bin',['compile',str(d/'unity.kotoba'),'--target','aarch64-macos','--output',str(d/'compiler.kseed')],d/'compiler-compile.log')
 out=command(I/'seed-0.bin',['extract-native',str(d/'compiler.kseed'),'--symbol','main','--output',str(d/'compiler.bin')],d/'compiler-extract.log');assert int(re.search(r':offset (\d+)',out)[1])==0
 src=I/'typed-controls'/case/'source.kotoba';command(d/'compiler.bin',['compile',str(src),'--target','aarch64-macos','--output',str(d/'guest.kseed')],d/'guest-compile.log')
 out=command(d/'compiler.bin',['extract-native',str(d/'guest.kseed'),'--symbol',symbol,'--output',str(d/'guest.bin')],d/'guest-extract.log');off=int(re.search(r':offset (\d+)',out)[1]);rec=next(x for x in base['entries'] if x['case']==case)
 old=execute(I/'typed-controls'/case/('baseline-'+symbol+'.bin'),rec['offsets']['baseline'][symbol],args,fuel);new=execute(d/'guest.bin',off,args,fuel)
 if 'refusal' in name:
  assert old==new and off==rec['offsets']['baseline'][symbol] and sha(d/'guest.bin')==sha(I/'typed-controls'/case/('baseline-'+symbol+'.bin'));status='PASS generic exact budget refusal'
 else:assert old!=new,(name,old,new);status='DETECTED actual native difference'
 rows.append({'name':name,'status':status,'sourceSha256':sha(d/'unity.kotoba'),'compilerSha256':sha(d/'compiler.bin'),'guestSha256':sha(d/'guest.bin'),'baseline':old,'mutant':new,'case':case,'symbol':symbol,'args':args,'fuel':fuel,'offset':off});print(status,name,flush=True)
(D/'report.json').write_text(json.dumps({'status':'PASS four actual source mutation controls and two exact fallback budget controls','entries':rows,'timingRuns':0},indent=2)+'\n')
