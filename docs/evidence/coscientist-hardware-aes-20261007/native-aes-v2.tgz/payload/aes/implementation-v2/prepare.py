from pathlib import Path
import subprocess,hashlib,json,shutil
I=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17');B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
commit='44bfaa28ccb70252bf763e20de5321ced848f0e4'
def original(rel):return subprocess.check_output(['git','show',commit+':'+rel],cwd=R).decode()
helper=(I/'aes-native.kotoba').read_text();g=original('seed/41-a64gen.kotoba');assert hashlib.sha256(g.encode()).hexdigest()=='4ed9b5600505c33013c966d266a977a3d4ccd56ad3cdc425b1805acf390b95f3'
needle='(defn- gn-op-call [';assert g.count(needle)==1;g=g.replace(needle,helper+'\n'+needle)
needle='dag (di-admit M i f t n)]';assert g.count(needle)==1;g=g.replace(needle,'dag (di-admit M i f t n) aes (as-admit M i f t n)]')
needle='   (cond (> reader 0)';assert g.count(needle)==1;g=g.replace(needle,'   (cond aes (as-call M i f t) (> reader 0)')
g=g.replace('(mem-alloc M0 (+ gn-a-lp MM-LABEL-CAP 80))','(mem-alloc M0 (+ gn-a-lp MM-LABEL-CAP 82))')
g=g.replace('(gn-gs di-used 0) (gn-gs di-sites 0))','(gn-gs di-used 0) (gn-gs di-sites 0) (gn-gs as-used 0) (gn-gs as-sites 0))')
start=g.index('(defn- gn-run-open [');end=g.index(';; Unity compilation',start)
g=g[:start]+'''(defn- gn-run-open [M :vector-i64 first :i64 count :i64] :vector-i64
 (let [top (vector-at M MM-HEAP-TOP) m0 (if (< top MM-HEAP-BASE) (gn-put M MM-HEAP-TOP MM-HEAP-BASE) M)
       m1 (mem-alloc m0 (+ gn-a-lp MM-LABEL-CAP 82))]
  (if (not= (vector-at m1 MM-ERR) 0) m1
   (let [m2 (-> (gn-put m1 gn-cell (vector-at m1 MM-R0)) (gn-gs gn-g-open first) (gn-gs gn-g-open-n count)
                  (gn-gs di-used 0) (gn-gs di-sites 0) (gn-gs as-used 0) (gn-gs as-sites 0))
         m3 (gn-loop m2 1)] (gn-put m3 MM-R0 (- (vector-at m3 MM-CODE-N) 1))))))

'''+g[end:]
(I/'41-a64gen-prototype.kotoba').write_text(g);manifest=original('seed/MANIFEST');parts=[p.strip() for p in manifest.splitlines() if p.strip() and not p.lstrip().startswith('#')]
(I/'unity.kotoba').write_text('\n'.join(g if p=='seed/41-a64gen.kotoba' else original(p) for p in parts))
for rel in parts+['seed/MANIFEST','seed/SIR','seed/HEADS','seed/MEMORY-MAP','bench/embench/comparison-matrix.json']:
 p=I/'source-snapshot'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(original(rel))
(I/'42-layout-prototype.kotoba').write_text(original('seed/42-layout.kotoba'))
for dest,src in [('seed-0.bin','seed-4.bin'),('seed-0.offset','seed-4.offset'),('kexe-loader','kexe-loader')]:
 if not (I/dest).exists():shutil.copy2(B/src,I/dest)
assert sha(I/'seed-0.bin')=='761856bb455de5d36021e177be8f3a0bbf65772dd66cbdf29c8e114f8cbe3d93'
(I/'input-pins.json').write_text(json.dumps({str(p):sha(p) for p in [I/'seed-0.bin',I/'kexe-loader',I.parent/'hypothesis.json',I.parent/'hypothesis-v2-extension.json']},indent=2)+'\n')
(I/'source-pins.json').write_text(json.dumps({p.name:sha(p) for p in [I/'aes-native.kotoba',I/'41-a64gen-prototype.kotoba',I/'unity.kotoba',I/'42-layout-prototype.kotoba']},indent=2)+'\n')
print('AES source prepared',sha(I/'41-a64gen-prototype.kotoba'))
