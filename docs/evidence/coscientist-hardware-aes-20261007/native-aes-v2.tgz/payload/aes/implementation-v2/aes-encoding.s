.text
.globl _aes_group
_aes_group:
 movi v1.16b,#0
 fmov s0,w1
 ins v0.s[1],w2
 ins v0.s[2],w3
 ins v0.s[3],w4
 aese v0.16b,v1.16b
 aesmc v0.16b,v0.16b
 umov w16,v0.s[0]
 eor x0,x16,x5
 ret
