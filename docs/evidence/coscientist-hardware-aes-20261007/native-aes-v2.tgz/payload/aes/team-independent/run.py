from pathlib import Path
import json,hashlib,subprocess,os,re,struct
D=Path(__file__).resolve().parent;I=D.parent/'implementation';B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation');L=Path('/private/tmp/amu-private-length-clones-20261006/full-state-loader');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());p=load(D/'preregistration.json')
for n,h in load(D/'input-pins.json').items():assert sha(Path(n))==h
feature=subprocess.run(['/usr/sbin/sysctl','-n','hw.optional.arm.FEAT_AES'],capture_output=True,text=True);(D/'fresh-local-feature.json').write_text(json.dumps({'exit':feature.returncode,'stdout':feature.stdout,'stderr':feature.stderr,'externalExplicitOptInOnly':True}));assert feature.returncode==0 and feature.stdout.strip()=='1'
compilerEnv=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[];entries=[]
def command(seed,args,prefix):
 q=subprocess.run([str(I/'kexe-loader'),str(seed),'0','0','aarch64','35,37,38,39','--',*args],env=compilerEnv,capture_output=True,text=True);prefix.with_suffix('.stdout').write_text(q.stdout);prefix.with_suffix('.stderr').write_text(q.stderr);assert q.returncode==0,(args,q.stdout[-800:],q.stderr);return q.stdout

def execute(binary,off,args,fuel,prefix,caps=None):
 env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');env.pop('KEXE_COMMAND',None)
 if caps:env.update({k:str(v) for k,v in caps.items()})
 q=subprocess.run([str(L),str(binary),str(off),str(len(args)),'aarch64','-',*map(str,args)],env=env,capture_output=True,text=True);out={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};prefix.with_suffix('.stdout').write_text(q.stdout);prefix.with_suffix('.stderr').write_text(q.stderr);return out

def integer(v):return (v+(1<<63))%(1<<64)-(1<<63)
def tables(source):
 out={}
 for mode in ['enc','dec']:
  for k in range(4):
   nums=[]
   for bank in range(2):
    z=re.search(r'\(def z-'+mode+'-t'+str(k)+'-'+str(bank)+r' \[([^]]+)\]\)',source);assert z;nums+=list(map(int,z[1].split()))
   assert len(nums)==256;out[mode,k]=nums
 return out

def oracle(symbol,args,t):
 if symbol=='run':return oracle('forward',[args[0],-1,-9223372036854775808,9223372036854775807,args[0]],t)
 if symbol=='modes':mode,*v,key=args;states=v+[-1]
 else:mode=0 if symbol=='forward' else 1;states=args[:4];key=args[4]
 value=key^17
 for k in range(4):value^=t['enc' if mode==0 else 'dec',k][((states[k]%(1<<64))>>(8*k))&255]
 return integer(value)
for case in ['positive','wrong-table']:
 F=D/case;F.mkdir();src=D/(case+'-source.kotoba');assert sha(src)==p['typedSources'][case];offsets={}
 for label,seed in [('baseline',B/'seed-4.bin'),('candidate',I/'seed-4.bin'),('observer',I/'observer/seed.bin')]:
  command(seed,['compile',str(src),'--target','aarch64-macos','--output',str(F/(label+'.kseed'))],F/(label+'-compile'))
  for symbol in ['forward','reverse','modes','run']:
   out=command(seed,['extract-native',str(F/(label+'.kseed')),'--symbol',symbol,'--output',str(F/(label+'-'+symbol+'.bin'))],F/(label+'-'+symbol+'-extract'));offsets[label,symbol]=int(re.search(r':offset (\d+)',out)[1])
 for symbol in ['forward','reverse','modes','run']:assert sha(F/('candidate-'+symbol+'.bin'))==sha(F/('observer-'+symbol+'.bin')) and offsets['candidate',symbol]==offsets['observer',symbol]
 log=(F/'observer-compile.stdout').read_text();admit=[list(map(int,z.split()[1:])) for z in log.splitlines() if z.startswith('ASPRE ')];assert len(admit)==(3 if case=='positive' else 0)
 if not admit:assert all(sha(F/('candidate-'+s+'.bin'))==sha(F/('baseline-'+s+'.bin')) and offsets['candidate',s]==offsets['baseline',s] for s in ['forward','reverse','modes','run'])
 else:assert sha(F/'candidate-forward.bin')!=sha(F/'baseline-forward.bin')
 t=tables(src.read_text());cases=[]
 if case=='positive':
  for symbol in ['forward','reverse']:
   for states in p['stateValues']:
    for key in p['keyValues']:cases.append((symbol,[*states,key]))
  for mode in p['modeValues']:
   for key in p['keyValues']:cases.append(('modes',[mode,*p['stateValues'][2][:3],key]))
  cases+=[('run',[n]) for n in [0,1,-1,9223372036854775807,-9223372036854775808]]
 else:cases=[('forward',[0,0,0,0,0]),('forward',[-1,-1,-1,-1,-1]),('modes',[1,1,2,3,9223372036854775807])]
 pairs=[]
 for k,(symbol,args) in enumerate(cases):
  for fuel in p['typedFuelPrefixes']:
   obs={label:execute(F/(label+'-'+symbol+'.bin'),offsets[label,symbol],args,fuel,F/(f'case{k}-fuel{fuel}-'+label)) for label in ['baseline','candidate']};assert obs['baseline']==obs['candidate'],(case,symbol,args,fuel,obs)
   if obs['baseline']['exit']==0:assert int(re.search(r':result (-?\d+)',obs['baseline']['stdout'])[1])==oracle(symbol,args,t),(case,symbol,args,fuel,obs)
   z={'case':case,'symbol':symbol,'args':args,'fuel':fuel,'caps':None,**obs};pairs.append(z);rows.append(z)
 entries.append({'case':case,'admissions':admit,'offsets':{k+':'+s:v for (k,s),v in offsets.items()},'nativePins':{k+':'+s:sha(F/(k+'-'+s+'.bin')) for k in ['baseline','candidate','observer'] for s in ['forward','reverse','modes','run']},'pairs':len(pairs),'sourceSha256':sha(src)});print('PASS independent typedAES',case,len(pairs),len(admit),flush=True)
# Original public batch: actual prefixes and complete shared accounting/partial vector content.
base=p['baselinePublicMetadata'];candidate=next(e for e in load(I/'ports-build.json')['entries'] if e['workload']=='nettle-aes');F=D/'public';F.mkdir();public=[]
for n in p['publicInputs']:
 for fuel in p['publicFuelPrefixes']:
  obs={label:execute(path,off,[n],fuel,F/(f'n{n}-fuel{fuel}-'+label)) for label,path,off in [('baseline',B/'ports/nettle-aes/native.bin',base['offset']),('candidate',I/'ports/nettle-aes/native.bin',candidate['offset'])]};assert obs['baseline']==obs['candidate'],(n,fuel,obs);z={'case':'original-public','symbol':'batch','args':[n],'fuel':fuel,'caps':None,**obs};public.append(z);rows.append(z)
nominal=next(z['baseline'] for z in public if z['args']==[1] and z['fuel']==16777216);resource=[]
for envkey,name in [('KEXE_VECTORS','vectors'),('KEXE_VECTOR_ITEMS','vector-items'),('KEXE_PAIRS','heap'),('KEXE_STRING_POOL','string-pool')]:
 used=int(re.search(':'+name+r' \{:capacity \d+ :used (\d+)\}',nominal['stdout'])[1]);caps=sorted({1,*[max(1,used+x) for x in p['capacityOffsets']]})
 for cap in caps:
  obs={label:execute(path,off,[1],16777216,F/(f'{envkey}-cap{cap}-'+label),{envkey:cap}) for label,path,off in [('baseline',B/'ports/nettle-aes/native.bin',base['offset']),('candidate',I/'ports/nettle-aes/native.bin',candidate['offset'])]};assert obs['baseline']==obs['candidate'],(envkey,cap,obs);z={'case':'resource-boundary','args':[1],'fuel':16777216,'caps':{envkey:cap},'nominalUsed':used,**obs};resource.append(z);rows.append(z)
print('PASS public',len(public),'resource',len(resource),flush=True)
# All public typed returned paths retain caller-saved banks x19..28.
ns={'struct':struct};text=Path('/private/tmp/amu-stable-vector-cfg-20261006/team-resource/callee.py').read_text().split('def wrap(raw,off):',1)[1].split('rows=[]',1)[0];exec('def wrap(raw,off):'+text,ns);wrap=ns['wrap'];sentinels=[];entry=entries[0]
for symbol,argslist in [('forward',[[*s,k] for s,k in zip(p['stateValues'],p['keyValues'])]),('reverse',[[*p['stateValues'][2],-9223372036854775808]]),('modes',[[mode,*p['stateValues'][2][:3],9223372036854775807] for mode in p['modeValues']]),('run',[[0],[1],[-1]])]:
 raw=D/'positive'/('candidate-'+symbol+'.bin');blob,off=wrap(raw.read_bytes(),entry['offsets']['candidate:'+symbol]);wrapped=D/'positive'/(symbol+'-sentinels.bin');wrapped.write_bytes(blob)
 for k,args in enumerate(argslist):
  old=execute(raw,entry['offsets']['candidate:'+symbol],args,1048576,D/'positive'/(symbol+f'-sentinel{k}-direct'));new=execute(wrapped,off,args,1048576,D/'positive'/(symbol+f'-sentinel{k}-wrapped'));assert old==new and old['exit']==0,(symbol,args,old,new);sentinels.append({'symbol':symbol,'args':args,'offset':off,'wrapperSha256':sha(wrapped),'direct':old,'sentinels':new})
(D/'full-state-pairs.json').write_text(json.dumps(rows,indent=2)+'\n');(D/'native-report.json').write_text(json.dumps({'status':'PASS independent typed/public fuel+fullstate/resource+actualx19..28ABI controls','candidateSeedSha256':p['candidateSeedSha256'],'baselineSeedSha256':p['baselineSeedSha256'],'typedPairs':sum(e['pairs'] for e in entries),'publicPairs':len(public),'resourcePairs':len(resource),'totalFullStatePairs':len(rows),'trappedPairs':sum(z['baseline']['exit']!=0 for z in rows),'successfulZeroRemaining':sum(z['baseline']['exit']==0 and ':remaining 0}' in z['baseline']['stdout'] for z in rows),'entries':entries,'sentinelPairs':len(sentinels),'sentinels':sentinels,'runtimeContextBoundary':'Equivalence under existing valid product-loader context; no invalid/null/version-context guarantee.','timingRuns':0},indent=2)+'\n');print('FINAL',len(rows),'fullstates',len(sentinels),'sentinels',flush=True)
