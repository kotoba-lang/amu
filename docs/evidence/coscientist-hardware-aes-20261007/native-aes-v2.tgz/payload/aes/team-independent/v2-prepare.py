from pathlib import Path
import hashlib,json,re
D=Path(__file__).resolve().parent;I=D.parent/'implementation-v2';B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
files=[p for p in D.rglob('*') if p.is_file() and 'v2-' not in p.name];write(D/'v1-local-pins.json',{str(p.relative_to(D)):sha(p) for p in files});write(D/'v1-local-closeout.json',{'status':'PASS local executable controls; holistic candidate FAIL ck-pt E2101','native':json.loads((D/'native-report.json').read_text()),'machineReportSha256':sha(D/'machine-view/machine-audit.json'),'noProductAdoption':True,'timingRuns':0})
V=D/'v2';V.mkdir(exist_ok=True)
s=(I/'unity.kotoba').read_text();assert s.count('(defn main [] :i64 (seed-main))')==1
ex='''
(defn- ex-init [m :vector-i64 err :i64] :vector-i64
 (-> m (mem-set 256 77) (mem-set 500000 81) (mem-set gn-cell 0) (mem-set MM-ERR err) (mem-set MM-FN-N 1) (mem-set MM-SIR-N 1) (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1) (mem-set MM-HEAP-TOP (- MM-HEAP-END 1))))
(defn- ex-compare [a :vector-i64 b :vector-i64 i :i64 diffs :i64] :i64
 (if (= i MM-WORDS) diffs (ex-compare a b (inc i) (+ diffs (if (= (vector-at a i) (vector-at b i)) 0 1)))))
(defn main [] :i64
 (let [a0 (ex-init (mem-new) 0) b0 (ex-init (mem-new) 0)
       a1 (gn-run-open a0 61 1) b1 (mem-alloc b0 (+ gn-a-lp MM-LABEL-CAP 82)) x (ex-compare a1 b1 0 0)
       c0 (ex-init (mem-new) 777) d0 (ex-init (mem-new) 777)
       c1 (gn-run-open c0 61 1) d1 (mem-alloc d0 (+ gn-a-lp MM-LABEL-CAP 82)) y (ex-compare c1 d1 0 0)] (+ (* 1000 x) y)))
'''
(V/'exhaustion-source.kotoba').write_text(s.replace('(defn main [] :i64 (seed-main))','')+ex)
log=(D/'positive/observer-compile.stdout').read_text();fn={int(a):int(b) for a,b in re.findall(r'^FN (\d+) (\d+) .*$',log,re.M)};sir={int(i):(int(op),int(a),int(b),int(c)) for i,op,a,b,c in re.findall(r'^SIR (\d+) (\d+) (-?\d+) (-?\d+) (-?\d+) ',log,re.M)};root=int(re.search(r'^ASPRE \d+ (\d+)',log,re.M)[1]);p=fn[root];targets={'root':root,'byte':sir[p+10][1],'table':sir[p+11][1],'xor5':sir[p+64][1]};assert all(sir[p+n][0]==13 for n in [10,11,64])
# Compiler wrapper changes only drv-c5's choice of gn-run-open; original optimizer untouched.
for name,target in targets.items():
 for label,owner in [('baseline',B),('candidate',I)]:
  txt=(owner/'unity.kotoba').read_text();old='(drv-c6 (gn-run M) S path out)';assert txt.count(old)==1; (V/(name+'-'+label+'-compiler.kotoba')).write_text(txt.replace(old,f'(drv-c6 (gn-run-open M {target} 1) S path out)'))
# same-M closed/open/closed: immutable SIR plus emitted FN/CODE/FIX preserved on closed return.
reuse='''
(defn- ai-copy [M :vector-i64 V :vector-i64 base :i64 i :i64 n :i64] :vector-i64
 (if (= i n) V (ai-copy M (mem-set V i (vector-at M (+ base i))) base (inc i) n)))
(defn- ai-eq [M :vector-i64 V :vector-i64 base :i64 i :i64 n :i64] :bool
 (if (= i n) true (and (= (vector-at V i) (vector-at M (+ base i))) (ai-eq M V base (inc i) n))))
(defn- ai-run [M :vector-i64] :vector-i64
 (let [a (gn-run M) n (vector-at a MM-CODE-N) f (* (vector-at a MM-FN-N) MM-FN-W) s (* (vector-at a MM-SIR-N) 4) k (* (vector-at a MM-FIX-N) 4)
       V (ai-copy a (vector-alloc n) MM-CODE-BASE 0 n) F (ai-copy a (vector-alloc f) MM-FN-BASE 0 f) S (ai-copy a (vector-alloc s) MM-SIR-BASE 0 s) K (ai-copy a (vector-alloc k) MM-FIX-BASE 0 k) sites (gn-g a as-sites)
       opn (gn-run-open (-> a (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1)) 61 1) openSites (gn-g opn as-sites)
       z (gn-run (-> opn (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1)))
       ok (and (= sites 3) (= openSites 0) (= (gn-g z as-sites) 3) (= (vector-at z MM-CODE-N) n) (ai-eq z V MM-CODE-BASE 0 n) (ai-eq z F MM-FN-BASE 0 f) (ai-eq z S MM-SIR-BASE 0 s) (ai-eq z K MM-FIX-BASE 0 k))]
 (if ok z (mem-set z MM-ERR 999))))
'''
old='(drv-c6 (gn-run M) S path out)';(V/'reuse-compiler.kotoba').write_text(s.replace(old,'(drv-c6 (ai-run M) S path out)')+reuse)
pins={str(p):sha(p) for p in [I/'seed-4.bin',I/'unity.kotoba',I/'41-a64gen-prototype.kotoba',I/'aes-native.kotoba',I/'source-pins.json',I/'kexe-loader',B/'seed-4.bin',B/'unity.kotoba',D/'positive-source.kotoba',D/'wrong-table-source.kotoba',*V.glob('*.kotoba')]}
write(V/'preregistration.json',{'candidateVersion':'v2','candidateSeedSha256':sha(I/'seed-4.bin'),'inputs':pins,'typedBridge':'Compile exact unchanged positive/wrong-table and compare all four exported image bytes+offset to v1; prior native observations reused only upon equality.','original19Bridge':'All19 exact bytes and offsets comparison to v1, same original public inputs and fuel/caps; no rerun after exact equality.','compilerAllocation':'Actual frozen gn-run-open with first61,count1 vs independent mem-alloc reference over all MM-WORDS, err0/777 exhausted allocation; expected result0.','contextTargets':targets,'contextExpected':'Each nonzero first,count1 denies AES admission; exact candidate-vs-baseline context generated bytes/offset required.','reuseExpected':'actual same M closed/open/closed admissions3/0/3, all closed FN/SIR/CODE/FIX cells exact; native image equals fresh v2 closed compilation.','runtimeBoundary':'Valid product-loader ctx only. No null/version-invalid context assertion.','timingRuns':0})
print('PREREG v2',sha(V/'preregistration.json'),targets,sha(I/'seed-4.bin'))
