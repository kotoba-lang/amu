from pathlib import Path
import hashlib,json,subprocess,os,re
D=Path(__file__).resolve().parent;V=D/'v2';I=D.parent/'implementation-v2';Old=D.parent/'implementation';B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');pr=load(V/'preregistration.json')
for p,h in pr['inputs'].items():assert sha(Path(p))==h
feat=subprocess.run(['/usr/sbin/sysctl','-n','hw.optional.arm.FEAT_AES'],capture_output=True,text=True);write(V/'fresh-feature.json',{'exit':feat.returncode,'stdout':feat.stdout,'stderr':feat.stderr,'externalOptInOnly':True});assert feat.returncode==0 and feat.stdout.strip()=='1'
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
def cmd(seed,off,args,prefix):
 q=subprocess.run([str(I/'kexe-loader'),str(seed),str(off),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);prefix.with_suffix('.stdout').write_text(q.stdout);prefix.with_suffix('.stderr').write_text(q.stderr);write(prefix.with_suffix('.status.json'),{'exit':q.returncode});assert q.returncode==0,(prefix,q.stdout[-1000:],q.stderr[-1000:]);return q.stdout
def compile(src,seed,name,off=0):
 k=V/(name+'.kseed');cmd(seed,off,['compile',str(src),'--target','aarch64-macos','--output',str(k)],V/(name+'-compile'));return k
def extract(k,seed,name,symbol):
 b=V/(name+'-'+symbol+'.bin');out=cmd(seed,0,['extract-native',str(k),'--symbol',symbol,'--output',str(b)],V/(name+'-'+symbol+'-extract'));return b,int(re.search(r':offset (\d+)',out)[1])
bridge=[]
for case in ['positive','wrong-table']:
 k=compile(D/(case+'-source.kotoba'),I/'seed-4.bin','bridge-'+case)
 old=next(e for e in load(D/'native-report.json')['entries'] if e['case']==case)
 for sym in ['forward','reverse','modes','run']:
  b,off=extract(k,I/'seed-4.bin','bridge-'+case,sym);assert sha(b)==old['nativePins']['candidate:'+sym] and off==old['offsets']['candidate:'+sym];bridge.append({'case':case,'symbol':sym,'sha256':sha(b),'offset':off,'oldPath':str(D/case/('candidate-'+sym+'.bin'))})
 print('PASS v2 exact typed emission bridge',case,flush=True)
oldports={e['workload']:e for e in load(Old/'ports-build.json')['entries']};public=[]
for e in load(I/'ports-build.json')['entries']:
 n=e['workload'];a=Old/'ports'/n/'native.bin';b=I/'ports'/n/'native.bin';assert sha(a)==sha(b) and oldports[n]['offset']==e['offset'];public.append({'workload':n,'sha256':sha(b),'offset':e['offset']})
assert len(public)==19;write(V/'exact-input-bridge.json',{'typed':bridge,'original19':public,'reusedObservations':1242,'reusedSentinels':14,'condition':'Same exact executable bytes, offsets, sources, inputs, loader, fuel and capacities. This does not establish new compiler internal state equivalence.'});print('PASS original19 exact emission bridge',flush=True)
k=compile(V/'exhaustion-source.kotoba',I/'seed-4.bin','exhaustion');b,off=extract(k,I/'seed-4.bin','exhaustion','main');runenv=dict(env);runenv.pop('KEXE_COMMAND');q=subprocess.run([str(I/'kexe-loader'),str(b),str(off),'0','aarch64','-'],env=runenv,capture_output=True,text=True);write(V/'exhaustion-run.json',{'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr});assert q.returncode==0 and q.stdout.strip()=='0',(q.returncode,q.stdout,q.stderr);print('PASS v2 wholeM exhaustion err0/777 first61,count1',flush=True)
contexts=[]
for name,target in pr['contextTargets'].items():
 images={}
 for label in ['baseline','candidate']:
  seed=B/'seed-4.bin' if label=='baseline' else I/'seed-4.bin';k=compile(V/(name+'-'+label+'-compiler.kotoba'),seed,name+'-'+label+'-compiler');compiler,coff=extract(k,seed,name+'-'+label+'-compiler','main');typed=compile(D/'positive-source.kotoba',compiler,name+'-'+label+'-typed',coff);images[label]={}
  for sym in ['forward','reverse','modes','run']:images[label][sym]=extract(typed,I/'seed-4.bin',name+'-'+label+'-typed',sym)
 for sym in images['baseline']:
  a,ao=images['baseline'][sym];b,bo=images['candidate'][sym];assert sha(a)==sha(b) and ao==bo,(name,sym,sha(a),sha(b),ao,bo)
 contexts.append({'name':name,'first':target,'count':1,'nativeExports':{sym:{'sha256':sha(b),'offset':off} for sym,(b,off) in images['candidate'].items()},'candidateBaselineContextByteExact':True});print('PASS v2 compiler opencontext',name,target,flush=True)
# A wrapper only inserts the preregistered same-M closed/open/closed check in driver; frozen optimizer untouched.
k=compile(V/'reuse-compiler.kotoba',I/'seed-4.bin','reuse-compiler');compiler,off=extract(k,I/'seed-4.bin','reuse-compiler','main');k=compile(D/'positive-source.kotoba',compiler,'reuse-typed',off)
for sym in ['forward','reverse','modes','run']:
 b,off=extract(k,I/'seed-4.bin','reuse-typed',sym);row=next(z for z in bridge if z['case']=='positive' and z['symbol']==sym);assert sha(b)==row['sha256'] and off==row['offset'],('reuse',sym)
print('PASS v2 sameM closed/open/closed3/0/3 and all FN/SIR/CODE/FIX',flush=True)
write(V/'report.json',{'status':'PASS independent v2 exact executable bridge + fullM allocator failure + four open compiler contexts + sameM closed/open/closed','candidateVersion':'v2','candidateSeedSha256':pr['candidateSeedSha256'],'preregistrationSha256':sha(V/'preregistration.json'),'typedBridgeExports':8,'original19Bridge':19,'reusedFullStatePairs':1242,'reusedABISentinels':14,'compilerFullMAllocationCases':2,'contexts':contexts,'sameMReuse':{'closedSites':3,'openSites':0,'againSites':3,'segmentsCompared':['FN','SIR','CODE','FIX'],'fullMEqualityNotClaimed':'Normal successful allocation grows compiler heap across runs.'},'runtimeContextBoundary':'Existing valid product-loader ctx only; compiler open-context controls are separate from runtime ctx validity.','timingRuns':0})
