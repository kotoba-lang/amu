from pathlib import Path
import subprocess,os,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-index-write-20261005'); base=Path('/private/tmp/amu-sign-wrapper-20261005')
loader=w/'kexe-loader';runner=Path('/private/tmp/amu-embench-compare-20261004/runner');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
report={'hypothesis':'checked index-write fusion','rows':[]};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def compile(seed,src,d,symbols):
 d.mkdir(exist_ok=True,parents=True);out=d/'image.kseed'
 p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--','compile',str(src),'--target','aarch64-macos','--output',str(out)],env=env,capture_output=True,text=True);(d/'compile.log').write_text(p.stdout+p.stderr);assert p.returncode==0,(src,p.stdout,p.stderr)
 offsets={}
 for symbol in symbols:
  p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--','extract-native',str(out),'--symbol',symbol,'--output',str(d/'native.bin')],env=env,capture_output=True,text=True);(d/(symbol+'.extract.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(symbol,p.stderr);offsets[symbol]=int(re.search(r':offset (\d+)',p.stdout).group(1))
 return offsets
def run(d,off,n,fuel=16777216):
 e=dict(env,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
 p=subprocess.run([str(loader),str(d/'native.bin'),str(off),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True)
 if p.returncode==0:
  m=re.search(r':result (-?\d+)',p.stdout);assert m,(n,fuel,p.stdout);value={'result':int(m.group(1))}
 else:
  assert 'KEXE_TRAP' in p.stderr,(n,fuel,p.returncode,p.stdout,p.stderr)
  value=None
 m=re.search(r':fuel \{:initial (\d+) :remaining (\d+)\}',p.stdout);assert m,(n,fuel,p.stdout,p.stderr);consumed=int(m.group(1))-int(m.group(2));return {'exit':p.returncode,'value':value,'fuelConsumed':consumed,'structuredReport':p.stdout.strip(),'traps':re.findall(r'^KEXE_TRAP.*$',p.stderr,re.M)}

forms=['(defn- i16 [x :i64] :i64 (let [n (bit-and x 65535)] (if (>= n 32768) (- n 65536) n)))','(defn- i8 [x :i64] :i64 (let [n (bit-and x 255)] (if (>= n 128) (- n 256) n)))','(defn- put [v :vector-i64 i :i64 x :i64] :vector-i64 (vector-assoc! v i x))','(defn- copy-put [v :vector-i64 i :i64 x :i64] :vector-i64 (vector-assoc v i x))','(defn- write [v :vector-i64 base :i64 stride :i64 k :i64 x :i64] :vector-i64 (put v (+ base (* stride k)) (i16 x)))','(defn- wrong-index [v :vector-i64 base :i64 stride :i64 k :i64 x :i64] :vector-i64 (put v (- base (* stride k)) (i16 x)))','(defn- wrong-sign [v :vector-i64 base :i64 stride :i64 k :i64 x :i64] :vector-i64 (put v (+ base (* stride k)) (i8 x)))','(defn- wrong-write [v :vector-i64 base :i64 stride :i64 k :i64 x :i64] :vector-i64 (copy-put v (+ base (* stride k)) (i16 x)))']
entries=[]
for name,basev,stride,k,idx in [('direct',0,2,1,2),('positive',1,2,3,7),('negative',1,-2,-3,7),('wrap-add',-(1<<63),-(1<<63),1,0),('wrap-mul',3,(1<<63)-1,2,1),('wrap-neg',-(1<<63),-(1<<63),-1,0)]:
 entries.append((name,f'(let [v (vector-alloc 16) a (write v {basev} {stride} {k} x)] (vector-at a {idx}))','narrow'))
entries += [('constant','(let [v (vector-alloc 16) a (write v 0 2 1 -9223372036854775808)] (vector-at a 2))','zero'),('zero','(let [v (vector-alloc 16) a (write v 0 2 1 0)] (vector-at a 2))','zero'),('alias','(let [v (vector-alloc 16) a v b (write v 0 2 1 x)] (+ (vector-at a 2) (vector-at b 2)))','alias'),('dynamic','(let [v (vector-alloc 16) i (bit-and x 15) a (write v 0 1 i x)] (vector-at a i))','narrow'),('nonmatch-index','(let [v (vector-alloc 16) a (wrong-index v 10 2 3 x)] (vector-at a 4))','narrow'),('nonmatch-sign','(let [v (vector-alloc 16) a (wrong-sign v 0 2 1 x)] (vector-at a 2))','i8'),('nonmatch-write','(let [v (vector-alloc 16) a (wrong-write v 0 2 1 x)] (vector-at a 2))','narrow')]
for count in [4,5,9]:entries.append(('high'+str(count),'(+ x '*count+'(let [v (vector-alloc 16) a (write v 0 2 1 x)] (vector-at a 2))'+')'*count,'high'+str(count)))
for name,length,basev,stride,k in [('empty',0,0,1,0),('bad-low',16,-1,1,0),('bad-high',16,16,1,0),('bad-wrap',16,(1<<63)-1,1,1)]:entries.append((name,f'(let [v (vector-alloc {length}) a (write v {basev} {stride} {k} x)] (vector-at a 0))','trap'))
symbols=[x[0] for x in entries];forms += [f'(defn {name} [x :i64] :i64 {expr})' for name,expr,_ in entries];src=w/'probe.kotoba';src.write_text('(ns probe (:export ['+' '.join(symbols)+']))\n'+'\n'.join(forms)+'\n')
def signed(x):
 x&=(1<<64)-1
 return x-(1<<64) if x>>63 else x
def narrow(x,width=16):
 mask=(1<<width)-1;x&=mask
 return x-(1<<width) if x>=(1<<(width-1)) else x
values=[-(1<<63),-(1<<63)+1,-65537,-65536,-32769,-32768,-32767,-257,-256,-255,-129,-128,-127,-2,-1,0,1,2,127,128,255,256,257,32767,32768,65535,65536,(1<<63)-1]
a=w/'probe-baseline';b=w/'probe-candidate';oa=compile(base/'seed-4.bin',src,a,symbols);ob=compile(w/'seed-4.bin',src,b,symbols)
for symbol,_,kind in entries:
 for n in values:
  for fuel in [16777216,1,2,3,4,5,6]:
   x=run(a,oa[symbol],n,fuel);y=run(b,ob[symbol],n,fuel);assert x==y,(symbol,n,fuel,x,y)
   if fuel==16777216:
    if kind=='trap':assert x['exit']!=0 and any('SIGILL' in t for t in x['traps']),(symbol,n,x)
    else:
     expected=narrow(n) if kind=='narrow' else 0 if kind=='zero' else signed(2*narrow(n)) if kind=='alias' else narrow(n,8) if kind=='i8' else signed(int(kind[4:])*n+narrow(n))
     assert x['exit']==0 and x['value']['result']==expected,(symbol,n,x,expected)
   report['rows'].append({'symbol':symbol,'input':n,'fuel':fuel,**x})
 print('PASS',symbol,flush=True);report['status']='in-progress';(w/'correctness.json').write_text(json.dumps(report,indent=2)+'\n')
report['status']='complete-signed-result-and-exact-fuel-and-trap-kind-and-resource-parity';report['executionAdapter']='Signed native loader with structured supervisor report: compare exact fuel, result/trap kind and complete resource report.';report['sourceSha256']=sha(src);report['baselineBytes']=(a/'native.bin').stat().st_size;report['candidateBytes']=(b/'native.bin').stat().st_size;(w/'correctness.json').write_text(json.dumps(report,indent=2)+'\n')
