from pathlib import Path
import importlib.util,subprocess,os,re,json,types,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-index-write-20261005');sp=importlib.util.spec_from_file_location('fx',r/'scripts/seed/a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)

sign=[('LGET',0,1),('CONST',1,65535),('BIN','BOP-AND',0),('LSET',2,0),('LGET',0,2),('CONST',1,32768),('CMP','CC-GE',0),('BRZ',0,'sg_else'),('LGET',0,2),('CONST',1,65536),('BIN','BOP-SUB',0),('BR','sg_exit'),('LABEL','sg_else'),('LGET',0,2),('LABEL','sg_exit'),('RET',0)]
def narrow(x):
 x&=65535
 return x-65536 if x>=32768 else x
for charge in [0,1]:
 name='sg'+str(charge);m.fx(name,1,2,([('FUEL',)] if charge else [])+[tuple(name+'_'+x if isinstance(x,str) and x.startswith('sg_') else x for x in row) for row in sign])
 m.fx('wr'+str(charge),3,3,([('FUEL',)] if charge else [])+[('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('RET',0)])
values=[m.MIN,m.MIN+1,-65537,-65536,-32769,-32768,-32767,-257,-256,-255,-129,-128,-127,-2,-1,0,1,2,127,128,255,256,257,32767,32768,65535,65536,m.MAX]
for c in [0,1]:
 for s in [0,1]:
  for z in [0,1]:
   name=f'iw{c}{s}{z}';charges=c+s+z
   chain=[('LGET',0,1),('LGET',1,2),('LGET',2,3),('LGET',3,4),('BIN','BOP-MUL',2),('BIN','BOP-ADD',1),('LGET',2,5),('CALL','sg'+str(s),2,1),('CALL','wr'+str(z),0,3),('RET',0)]
   m.fx(name,5,5,([('FUEL',)] if c else [])+chain)
   for tag,base,stride,k,idx in [('pos',1,2,3,7),('neg',1,-2,-3,7),('wrapadd',m.MIN,m.MIN,1,0),('wrapmul',3,m.MAX,2,1)]:
    caller=f'call_{name}_{tag}';m.fx(caller,1,2,[('FUEL',),('FUEL',),('CONST',0,16),('RT','RT-VECTOR-ALLOC',0,1),('LSET',2,0),('LGET',0,2),('CONST',1,base),('CONST',2,stride),('CONST',3,k),('LGET',4,1),('CALL',name,0,5),('CONST',1,idx),('RT','RT-VECTOR-AT',0,2),('RET',0)])
    for x in values:m.run(caller,[x],narrow(x),fuel=2+charges)
    for fuel in range(1,2+charges):m.run(caller,[1],'trap',fuel=fuel)
   for t in [4,5]:
    caller=f'high{t}_{name}';rows=[('FUEL',),('FUEL',),('CONST',0,16),('RT','RT-VECTOR-ALLOC',0,1),('LSET',2,0)]+[('CONST',j,j+1) for j in range(t)]+[('LGET',t,2),('CONST',t+1,0),('CONST',t+2,2),('CONST',t+3,1),('LGET',t+4,1),('CALL',name,t,5),('CONST',t+1,2),('RT','RT-VECTOR-AT',t,2)]+[('BIN','BOP-ADD',j) for j in reversed(range(t))]+[('RET',0)];m.fx(caller,1,2,rows)
    for x in values:m.run(caller,[x],t*(t+1)//2+narrow(x),fuel=2+charges)
   caller=f'const_{name}';m.fx(caller,0,1,[('FUEL',),('FUEL',),('CONST',0,16),('RT','RT-VECTOR-ALLOC',0,1),('CONST',1,0),('CONST',2,2),('CONST',3,1),('CONST',4,65535),('CALL',name,0,5),('CONST',1,2),('RT','RT-VECTOR-AT',0,2),('RET',0)]);m.run(caller,[],-1,fuel=2+charges)
   for tag,length,base,stride,k in [('empty',0,0,1,0),('low',16,-1,1,0),('high',16,16,1,0),('overflow',16,m.MAX,1,1)]:
    caller=f'bad_{name}_{tag}';m.fx(caller,1,1,[('FUEL',),('FUEL',),('CONST',0,length),('RT','RT-VECTOR-ALLOC',0,1),('CONST',1,base),('CONST',2,stride),('CONST',3,k),('LGET',4,1),('CALL',name,0,5),('RET',0)])
    m.run(caller,[m.MIN],'trap',fuel=2+charges)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800');loader=str(w/'kexe-loader');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];chunks=[]
for real in [False,True]:
 prefix='fixture-real' if real else 'fixture-test';src=w/(prefix+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real))
 for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(prefix+'.kseed'))]),('extract',['extract-native',str(w/(prefix+'.kseed')),'--symbol','main','--output',str(w/(prefix+'.bin'))])]:
  p=subprocess.run([loader,str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(prefix+'-'+label+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(label,p.stdout,p.stderr)
  if label=='extract':off=re.search(r':offset (\d+)',p.stdout).group(1)
 p=subprocess.run([loader,str(w/(prefix+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(prefix+'.stdout')).write_text(p.stdout);assert p.returncode==0,p.stderr;chunks.append(p.stdout)
assert m.blob_from(chunks[0])[0].rstrip(b'\0')==m.blob_from(chunks[1])[0].rstrip(b'\0') and m.blob_from(chunks[0])[1]==m.blob_from(chunks[1])[1]
d=w/'fixture-run/unit/41-a64gen';d.mkdir(parents=True,exist_ok=True);(d/'stdout').write_text(chunks[1]);os.environ['SEED_BUILD']=str(w/'fixture-run');original=m.subprocess.run

def run(args,**kw):
 if args[:2]==['zsh',m.R+'/scripts/seed/unit.sh']:return types.SimpleNamespace(returncode=0,stdout='native experimental fixture emitter already verified; byte golden untouched',stderr='')
 return original(args,**kw)
m.subprocess.run=run;assert m.runs(False)==0
blob,fns=m.blob_from(chunks[1]);names=[f[0] for f in m.FIX];audit={}
for name in ['call_iw000_pos','call_iw111_wrapmul','high4_iw101','high5_iw101']:
 f=names.index(name)+1;end=fns.get(f+1,int(re.search(r'words (\d+)',chunks[1]).group(1))*4);words=struct.unpack('<'+'I'*((end-fns[f])//4),blob[fns[f]:end]);bl=sum((x&0xfc000000)==0x94000000 for x in words);b=sum((x&0xfc000000)==0x14000000 for x in words);blr=sum((x&0xfffffc1f)==0xd63f0000 for x in words);udf=sum(x==0 for x in words)
 # Exactly one indirect allocator call; admitted write and read remain checked.
 assert blr==1 and udf==(2 if name.startswith('high5') else 4),(name,blr,udf)
 if name.startswith('high5'):assert bl+b>0,(name,bl,b)
 else:assert bl==b==0,(name,bl,b)
 audit[name]={'directBL':bl,'directB':b,'indirectAllocator':blr,'handleIndexTrapWords':udf,'bytes':end-fns[f]}
(w/'fixture-proof.json').write_text(json.dumps({'runs':len(m.RUNS),'fixtures':len(m.FIX),'realTestLayoutIdentical':True,'instructionAudit':audit},indent=2)+'\n');print('PASS index-write instruction and fallback audits',flush=True)
