from pathlib import Path
import json,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-index-write-20261005');old=(r/'seed/41-a64gen.kotoba').read_text();g=old

def match(shape):
 return '\n                 '.join(f'(and (= (gn-op M (+ q {j})) {op}) (= (gn-sir M (+ q {j}) IF-A) {a}) (= (gn-sir M (+ q {j}) IF-B) {b}) (= (gn-sir M (+ q {j}) IF-C) {c}))' for j,(op,a,b,c) in enumerate(shape))
ss=[('OP-LGET',0,1,0),('OP-CONST',1,65535,0),('OP-BIN','BOP-AND',0,0),('OP-LSET','slot',0,0),('OP-LGET',0,'slot',0),('OP-CONST',1,32768,0),('OP-CMP','CC-GE',0,0),('OP-BRZ',0,'le',0),('OP-LGET',0,'slot',0),('OP-CONST',1,65536,0),('OP-BIN','BOP-SUB',0,0),('OP-BR','lx',0,0),('OP-LABEL','le',0,0),('OP-LGET',0,'slot',0),('OP-LABEL','lx',0,0),('OP-RET',0,0,0),('OP-END','f',0,0)]
ws=[('OP-LGET',0,1,0),('OP-LGET',1,2,0),('OP-LGET',2,3,0),('OP-RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('OP-RET',0,0,0),('OP-END','f',0,0)]
cs=[('OP-LGET',0,1,0),('OP-LGET',1,2,0),('OP-LGET',2,3,0),('OP-LGET',3,4,0),('OP-BIN','BOP-MUL',2,0),('OP-BIN','BOP-ADD',1,0),('OP-LGET',2,5,0),('OP-CALL','sf',2,1),('OP-CALL','wf',0,3),('OP-RET',0,0,0),('OP-END','f',0,0)]
helper=''';; Exact index-write dependency proof; token4096+prefix charges0..2+16*final writer charge.
;; Generic natural-argument SIR shapes, never names. Handle/index checks remain.
(defn- gn-index-fuel [M :vector-i64 p :i64] :bool
  (or (not= (gn-op M (inc p)) OP-FUEL)
      (and (= (gn-sir M (inc p) IF-A) 0) (= (gn-sir M (inc p) IF-B) 0) (= (gn-sir M (inc p) IF-C) 0))))
(defn- gn-index-sign [M :vector-i64 f :i64] :i64
  (let [p (gn-fnf M f FF-SIR)]
    (if (or (< p 1) (not= (gn-op M p) OP-FN) (not= (gn-sir M p IF-A) f)
            (not= (gn-sir M p IF-B) 1) (not (gn-index-fuel M p))) 0
      (let [fuel (if (= (gn-op M (inc p)) OP-FUEL) 1 0) q (gn-skiplab M (+ p 1 fuel))
            slot (gn-sir M (+ q 3) IF-A) le (gn-sir M (+ q 7) IF-B) lx (gn-sir M (+ q 11) IF-A)]
        (if (and (> slot 1) (> le 0) (> lx 0) (not= le lx)
                 SIGNCHECKS) (inc fuel) 0)))))
(defn- gn-index-write [M :vector-i64 f :i64] :i64
  (let [p (gn-fnf M f FF-SIR)]
    (if (or (< p 1) (not= (gn-op M p) OP-FN) (not= (gn-sir M p IF-A) f)
            (not= (gn-sir M p IF-B) 3) (not (gn-index-fuel M p))) 0
      (let [fuel (if (= (gn-op M (inc p)) OP-FUEL) 1 0) q (gn-skiplab M (+ p 1 fuel))]
        (if (and WRITECHECKS) (inc fuel) 0)))))
(defn- gn-index-wrapper [M :vector-i64 f :i64 t :i64 n :i64] :i64
  (let [p (gn-fnf M f FF-SIR)]
    (if (or (< p 1) (not= n 5) (> t 4) (not= (gn-op M p) OP-FN)
            (not= (gn-sir M p IF-A) f) (not= (gn-sir M p IF-B) 5) (not (gn-index-fuel M p))) 0
      (let [fuel (if (= (gn-op M (inc p)) OP-FUEL) 1 0) q (gn-skiplab M (+ p 1 fuel))
            sf (gn-sir M (+ q 7) IF-A) wf (gn-sir M (+ q 8) IF-A)]
        (if (and (> sf 0) (> wf 0) (not= f sf) (not= f wf) (not= sf wf)
                 INDEXCHECKS)
          (let [s (gn-index-sign M sf) z (gn-index-write M wf)]
            (if (and (> s 0) (> z 0)) (+ 4096 fuel (dec s) (* 16 (dec z))) 0)) 0)))))
'''.replace('SIGNCHECKS',match(ss)).replace('WRITECHECKS',match(ws)).replace('INDEXCHECKS',match(cs))
a='(defn- gn-call-wrapper [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :i64\n  (if (= (gn-op M (inc i)) OP-RES2) 0\n      (let [w (gn-wrapper M f t n)] (if (> w 0) w (gn-sign-wrapper M f n)))))'
b=helper+'''(defn- gn-call-wrapper [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :i64
  (if (= (gn-op M (inc i)) OP-RES2) 0
    (let [w (gn-wrapper M f t n) s (if (> w 0) w (gn-sign-wrapper M f n))]
      (if (> s 0) s (gn-index-wrapper M f t n)))))''';assert g.count(a)==1;g=g.replace(a,b)
a='(if (> w 0) (if (if (>= w 1024) (>= w 1536) (>= w 256)) (gn-gs M gn-f-fuel 1) M)';b='(if (> w 0) (if (>= w 4096) (-> M (gn-gs gn-f-leaf 0) (cond-> (> w 4096) (gn-gs gn-f-fuel 1))) (if (if (>= w 1024) (>= w 1536) (>= w 256)) (gn-gs M gn-f-fuel 1) M))';assert g.count(a)==1;g=g.replace(a,b)
a='(defn- gn-op-call [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :vector-i64'
b=''';; Private arithmetic is total. Commit outer/sign charges normally, but the
;; final leaf writer checks fuel before the store and commits only on return.
;; Keep the caller nonleaf to preserve context fuel observed on bounds traps.
(defn- gn-index-charges [M :vector-i64 n :i64] :vector-i64
  (if (= n 0) M (gn-index-charges (gn-op-fuel M) (dec n))))
;; Internal results must not coalesce with the caller's following LSET.
(defn- gn-index-bin [M :vector-i64 bop :i64 t :i64] :vector-i64
  (if (and (gn-isk M t gn-k-const) (gn-isk M (inc t) gn-k-const))
    (gn-def M t gn-k-const (gn-fold bop (gn-dv M t) (gn-dv M (inc t))))
    (let [d (gn-dreg M t 0)] (-> M (gn-bin-emit bop t d) (gn-fin t 0 d)))))
(defn- gn-index-copy [M :vector-i64 t :i64 src :i64] :vector-i64
  (if (gn-isk M src gn-k-const) (gn-def M t gn-k-const (gn-dv M src))
    (let [d (gn-dreg M t 0)] (-> M (gn-into 16 src) (gn-mov d 16) (gn-fin t 0 d)))))
(defn- gn-index-write-check [M :vector-i64] :vector-i64
  (-> M (gn-ctx) (gn-emit (enc-ldr 16 7 CTX-FUEL))
      (gn-emit (enc-cmp-i 16 0)) (gn-emit (enc-bcond (enc-cond-ne) 2)) (gn-emit (enc-brk 0))))
(defn- gn-index-write-commit [M :vector-i64] :vector-i64
  (-> M (gn-ctx) (gn-emit (enc-ldr 16 7 CTX-FUEL))
      (gn-emit (enc-sub-i 16 16 1)) (gn-emit (enc-str 16 7 CTX-FUEL))))
(defn- gn-call-index [M :vector-i64 t :i64 w :i64] :vector-i64
  (-> M (gn-index-charges (bit-and w 15))
      (gn-index-bin BOP-MUL (+ t 2)) (gn-index-bin BOP-ADD (inc t))
      (gn-call-sign 0 (+ t 4) 1040) (gn-index-copy (+ t 2) (+ t 4))
      (cond-> (= (bit-and w 16) 16) (gn-index-write-check))
      (gn-rt-set t)
      (cond-> (= (bit-and w 16) 16) (gn-index-write-commit))))
'''+a;assert g.count(a)==1;g=g.replace(a,b)
a='(cond (>= w 1024) (gn-call-sign M i t w)';b='(cond (>= w 4096) (gn-call-index M t w)\n         (>= w 1024) (gn-call-sign M i t w)';assert g.count(a)==1;g=g.replace(a,b)
(w/'41-a64gen-prototype.kotoba').write_text(g)
files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];u=''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files);(w/'seed-unity.kotoba').write_text(u)
for ext in ['bin','offset']:shutil.copyfile(Path('/private/tmp/amu-sign-wrapper-20261005')/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile('/private/tmp/amu-sign-wrapper-20261005/kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['check-ports.py','bulk-state.py','remote.py','build.py']:
 s=Path('/private/tmp/amu-compound-narrow-20261005',name).read_text().replace('/private/tmp/amu-compound-narrow-20261005','/private/tmp/amu-index-write-20261005').replace('/private/tmp/amu-zebulun-compound-narrow-20261005','/private/tmp/amu-zebulun-index-write-20261005');(w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'hypothesis':'Exact natural-parameter5 chain computes wrapped base+stride*k, signed16(value), and a proved in-place vector-write wrapper. Inline arithmetic and original checked store, retaining all optional charges0..3 and no name admission. Remove hot call/frame overhead.','promotion':'30 fresh rotating quiet baseline/candidate/C triples; >=5% speedup and gap>sumSD; unchanged source, native exact-fuel/correctness and fixedpoint.','sourceHead':'382fb4f20488843a1bfecc4a7a5db8e1ecd81e8e','exception':'One-off new compiler algorithm authoring, not mechanical refactoring'},indent=2)+'\n')
