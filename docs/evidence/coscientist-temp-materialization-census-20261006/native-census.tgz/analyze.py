from pathlib import Path
import json,re,hashlib,struct,collections
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-temp-materialization-census-20261006');C={}
for n in ['seed/SIR','seed/HEADS','seed/MEMORY-MAP']:
 for m in re.finditer(r'\[:c (\S+) (-?\d+)',(r/n).read_text()):C[m[1]]=int(m[2])
ops={v:k for k,v in C.items() if k.startswith('OP-')};audit=json.loads((w/'observer-byte-audit.json').read_text());assert len(audit['entries'])==19;entries=[];allEvents=[]
for e in audit['entries']:
 name=e['workload'];d=w/'meta-ports'/name;text=(d/'compile.log').read_text();blob=(d/'native.bin').read_bytes();sir={};fns={};events=[]
 for line in text.splitlines():
  if line.startswith('SIR '):
   i,*a=map(int,line.split()[1:]);assert i not in sir or sir[i]==a;sir[i]=a
  elif line.startswith('FN '):
   f,*a=map(int,line.split()[1:]);assert f not in fns;fns[f]=dict(zip(['start','frameBytes','locals','depth','localCalleeRegisters','leaf','codeWordStart'],a))
  elif line.startswith('HOME '):events.append(list(map(int,line.split()[1:])))
 assert sorted(sir)==list(range(1,max(sir)+1));labels={}
 for i,(op,a,b,c) in sir.items():
  if op==C['OP-LABEL']:assert a not in labels;labels[a]=i
 for f,info in fns.items():
  start=info['start'];assert sir[start][0]==C['OP-FN'] and sir[start][1]==f;j=start+1
  while sir[j][0]!=C['OP-END']:j+=1
  info['end']=j;info['loops']=[]
  for i in range(start+1,j):
   op,a,b,c=sir[i];label=a if op==C['OP-BR'] else b if op in [C['OP-BRZ'],C['OP-BRNZ']] else 0;p=labels.get(label,0)
   if p<i and p>start:
    assert sir[p][0]==C['OP-LABEL'] and sir[p][1]==label;info['loops'].append({'start':p,'backedge':i,'label':label})
 counts={};wordAudits=[]
 for load,f,i,t,reg,dk,dv,pos,ns,F in events:
  info=fns[f];assert info['start']<=i<=info['end'] and ns==info['locals'] and F==info['frameBytes'] and 7<=t<info['depth'];k=ns+1+t;off=F-8*(k+1);assert 0<=off<=32760 and off%8==0;expected=(0xf9400000 if load else 0xf9000000)+(off//8<<10)+(31<<5)+reg;actual=struct.unpack_from('<I',blob,(pos-1)*4)[0];assert actual==expected,(name,f,i,t,reg,pos,hex(actual),hex(expected))
  loops=[x for x in info['loops'] if x['start']<=i<=x['backedge']];key=(f,t);c=counts.setdefault(key,{'fn':f,'temp':t,'stores':0,'loads':0,'loopStores':0,'loopLoads':0,'descriptorKinds':collections.Counter(),'operations':collections.Counter()});c['loads' if load else 'stores']+=1
  if loops:c['loopLoads' if load else 'loopStores']+=1
  c['descriptorKinds'][str(dk)]+=1;c['operations'][ops[sir[i][0]]]+=1
  event={'workload':name,'load':bool(load),'fn':f,'sir':i,'temp':t,'register':reg,'descriptorKindBeforeEmission':dk,'descriptorValue':dv,'codeWord':pos,'frameOffset':off,'exactWord':hex(actual),'loops':loops};wordAudits.append(event);allEvents.append(event)
 mapped=[]
 for f,info in fns.items():
  spare=10-info['localCalleeRegisters'];upper=min(info['depth'],7+spare)
  if upper<=7:continue
  ts=[dict(c) for (fn,t),c in sorted(counts.items()) if fn==f and t<upper];body=[sir[i] for i in range(info['start']+1,info['end'])];constantOnly=all(x[0] in [C['OP-LABEL'],C['OP-CONST'],C['OP-VEC'],C['OP-RET']] for x in body)
  mapped.append({'fn':f,**info,'proposedRegs':upper-7,'prologueEpilogueAddedInstructions':2*(upper-7),'constantOnlyInitializer':constantOnly,'candidateMappedTemps':ts,'potentialReplacedStores':sum(x['stores'] for x in ts),'potentialReplacedLoads':sum(x['loads'] for x in ts),'potentialLoopStores':sum(x['loopStores'] for x in ts),'potentialLoopLoads':sum(x['loopLoads'] for x in ts)})
 entry={'workload':name,'nativeSha256':hashlib.sha256(blob).hexdigest(),'sourceSha256':next(x for x in json.loads((r/'bench/embench/comparison-matrix.json').read_text())['entries'] if x['workload']==name)['expectedSourceSha256'],'fnCount':len(fns),'sirCount':len(sir),'highTempHomeEvents':len(events),'allHighTempLoads':sum(x[0] for x in events),'allHighTempStores':sum(1-x[0] for x in events),'mappedFunctions':mapped,'compileLogSha256':hashlib.sha256((d/'compile.log').read_bytes()).hexdigest()};entries.append(entry);print(name,[(x['fn'],x['proposedRegs'],x['potentialReplacedStores'],x['potentialReplacedLoads'],x['potentialLoopStores'],x['potentialLoopLoads'],x['constantOnlyInitializer']) for x in mapped])
(w/'instruction-audit.json').write_text(json.dumps({'status':'complete-all-current-original19-high-temp-home-words-and-loop-ownership-audit','events':len(allEvents),'allEvents':allEvents,'observerAll19GuestBytesEqualCurrentProduct':True},indent=2)+'\n');(w/'materialization-census.json').write_text(json.dumps({'status':'complete-native-current-product-high-temp-materialization-census','notRuntimeTimeShares':True,'notPerformanceMeasurement':True,'all19CanonicalSourcesAndNativeMachinesPinned':True,'events':len(allEvents),'entries':entries},indent=2)+'\n');print('PASS all',len(allEvents),'actual native high-home words and validated same-function loop regions')
