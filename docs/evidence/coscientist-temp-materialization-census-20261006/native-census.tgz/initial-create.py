from pathlib import Path
import shutil,json,subprocess,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-temp-materialization-census-20261006');b=Path('/private/tmp/amu-loop-high-temp-20261006');g=(r/'seed/41-a64gen.kotoba').read_text();(w/'baseline-41-a64gen.kotoba').write_text(g)
def rep(a,z):
 global g
 assert g.count(a)==1,(a,g.count(a));g=g.replace(a,z,1)
def string(fields):
 s='"\\n"'
 for x in reversed(fields):s=f'(string-concat (string-from-i64 {x}) (string-concat " " {s}))'
 return s
helper=''';; Observation only: spare state cells13/14 record FN/SIR, never code policy.
(defn- gn-home-event [M :vector-i64 r :i64 k :i64 load :i64] :i64
 (let [t (- k (gn-g M gn-f-ns) 1)]
  (if (and (>= t 7) (< t (gn-g M gn-f-dp)))
   (io-out (string-concat "HOME " '''+string(['load','(gn-g M 13)','(gn-g M 14)','t','r','(gn-dk M t)','(gn-dv M t)','(vector-at M MM-CODE-N)','(gn-g M gn-f-ns)','(gn-g M gn-f-fb)'])+''')) 0)))
'''
rep('(defn- gn-ld [',helper+'(defn- gn-ld [')
rep('(gn-emit M (enc-ldr r 31 (gn-soff M k))))','(let [printed (gn-home-event M r k 1)] (gn-emit M (enc-ldr r 31 (gn-soff M k)))))')
rep('(gn-emit M (enc-str r 31 (gn-soff M k))))','(let [printed (gn-home-event M r k 0)] (gn-emit M (enc-str r 31 (gn-soff M k)))))')
rep('M2 (gn-assign M1)','M2 (gn-assign (-> M1 (gn-gs 13 f) (gn-gs 14 i)))')
rep('                leaf (gn-g M2 gn-f-leaf)]','                leaf (gn-g M2 gn-f-leaf)\n                printed (io-out (string-concat "FN " '+string(['f','i','F','ns','dp','(gn-g M2 gn-f-nsv)','leaf','(vector-at M2 MM-CODE-N)'])+'))]')
rep('(let [M1 (gn-ins M i (gn-op M i))','(let [printed (io-out (string-concat "SIR " '+string(['i','(gn-op M i)','(gn-sir M i IF-A)','(gn-sir M i IF-B)','(gn-sir M i IF-C)'])+'))\n          M1 (gn-ins (gn-gs M 14 i) i (gn-op M i))')
(w/'observer-41-a64gen.kotoba').write_text(g);parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'observer-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader')]:shutil.copy2(b/src,w/dst)
s=Path('/private/tmp/amu-callee-temp-20261006/observe.py').read_text().replace('amu-callee-temp-20261006','amu-temp-materialization-census-20261006').replace("pc=json.loads((w/'ports-correctness.json').read_text())","pc=json.loads(Path('/private/tmp/amu-loop-high-temp-20261006/ports-correctness.json').read_text())").replace("w/'seed-4.bin'","w/'seed-0.bin'")
a=s.index(' for f,F,ns,dp,nsv,nt in regs:');z=s.index(' eb=next(',a);s=s[:a]+s[z:];a=s.index(";row={'workload':name");z=s.index(";rows.append(row)",a);s=s[:a]+";row={'workload':name,'diagnosticTargetByteIdentical':True,'nativeSha256':sha(d/'native.bin'),'offset':offset}"+s[z:];s=s.replace(",row['mappedFunctions']",'');s=s.replace("w/'register-observation.json'","w/'observer-byte-audit.json'").replace('complete-native-observer-byte-parity-and-register-storage-census','complete-native-observer-byte-parity');(w/'observe.py').write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'status':'registered-before-native-census','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'hypothesis':'Actual high-temp spill emission and loop reuse identify profitable register allocation; named depth alone overallocates constant-only initializer paths. First observe all19 current product guests, exact words and validated same-function backward regions.','observationOnly':True,'productChanged':False,'notRuntimeTimeShares':True,'bootstrapSeedSha256':hashlib.sha256((w/'seed-0.bin').read_bytes()).hexdigest(),'authoringException':'One-off diagnostic Kotoba instrumentation, no mechanical refactor rule covers new event schema; never added to product path.','goal':'C-or-better across all19 unchanged original aligned workloads; not officialscores.'},indent=2)+'\n');print('PASS registered observation-only experiment')
