from pathlib import Path
import importlib.util,subprocess,os,re,json,types,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-scalar-mask-reuse-20261005');spec=importlib.util.spec_from_file_location('base',w/'baseline-a64gen-fixtures.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);masknames=[];callnames=[]
values=[m.MIN,m.MIN+1,-65537,-1,0,1,127,255,256,65535,65536,2147483647,2147483648,4294967295,4294967296,m.MAX]
for width in [1,2,8,16,31,32,63]:
 for fuel in [0,1]:
  fn=f'sm_w{width}_f{fuel}';mask=(1<<width)-1;masknames.append(fn);m.fx(fn,1,1,([('FUEL',)] if fuel else [])+[('LGET',0,1),('CONST',1,mask),('BIN','BOP-AND',0),('RET',0)])
  for t in [0,1,2,3,6,7,8]:
   c=f'{fn}_t{t}';callnames.append(c);body=[('FUEL',),('LGET',t,1),('CALL',fn,t,1),('LGET',t+1,2),('BIN','BOP-ADD',t),('RET',t)];m.fx(c,2,2,body)
   for x in values:
    for live in [m.MIN,-1,0,37,m.MAX]:m.run(c,[x,live],m.s64((x&mask)+live),fuel=1+fuel)
   if fuel:m.run(c,[m.MAX,37],'trap',fuel=1)
# Same-looking body with a distinct operation/extra write/type/frame cannot enter.
for mode in ['xor','extra','wrong-type','frame']:
 fn='sm_refuse_'+mode;masknames.append(fn);b=[('FUEL',),('LGET',0,1),('CONST',1,255),('BIN','BOP-XOR' if mode=='xor' else 'BOP-AND',0)]
 if mode=='extra':b += [('CONST',1,1),('BIN','BOP-ADD',0)]
 b += [('RET',0)];m.fx(fn,1,2 if mode=='frame' else 1,b);c=fn+'_call';callnames.append(c);m.fx(c,1,1,[('FUEL',),('LGET',0,1),('CALL',fn,0,1),('RET',0)])
 for x in values:m.run(c,[x],m.s64(x^255) if mode=='xor' else m.s64((x&255)+(1 if mode=='extra' else 0)),fuel=2)
 m.run(c,[0],'trap',fuel=1)
ids={x[0]:i+1 for i,x in enumerate(m.FIX)};first=min(ids[n] for n in masknames);last=len(m.FIX)+1
# Actual native matcher receipts on exactly the SIR used for execution.
typed='''(defn- sm-types [M :vector-i64 f :i64] :vector-i64
 (if (>= f LAST) M
  (sm-types (-> M (t-put (+ MM-FN-BASE (* f MM-FN-W) FF-PT0) TY-I64)
                 (t-put (+ MM-FN-BASE (* f MM-FN-W) FF-RTYPE) TY-I64)) (inc f))))
(defn- sm-admit [M :vector-i64 i :i64] :i64
 (if (>= i (vector-at M MM-SIR-N)) 0
  (let [f (gn-sir M i IF-A) token (if (= (gn-op M i) OP-CALL) (gn-scalar-mask M i f (gn-sir M i IF-C)) 0)
        o (if (and (= (gn-op M i) OP-CALL) (>= f FIRST))
           (t-out (string-concat "MASKPROOF " (string-concat (string-from-i64 i) (string-concat " " (string-concat (string-from-i64 f) (string-concat " " (string-concat (string-from-i64 token) "\\n"))))))) 0)]
   (sm-admit M (inc i)))))
'''.replace('LAST',str(last)).replace('FIRST',str(first))
parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');outputs={}
for label,real in [('expanded-test',False),('expanded-real',True)]:
 text=m.kotoba(real).replace('(defn- seed-main [] :i64',typed+'(defn- seed-main [] :i64',1).replace('        M0 (t-load (t-init))',f'        MT (sm-types (t-load (t-init)) {first})\n        M0 (t-put MT (+ MM-FN-BASE (* {ids["sm_refuse_wrong-type"]} MM-FN-W) FF-PT0) TY-BOOL)\n        diagnostic (sm-admit M0 1)',1)
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+text)
 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+mode+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,mode,q.stdout[-500:],q.stderr)
  if mode=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'.stdout')).write_text(q.stdout);(w/(label+'.stderr')).write_text(q.stderr);assert q.returncode==0,(label,q.stdout[-300:],q.stderr);outputs[label]=q.stdout
admissions=[list(map(int,x.split()[1:])) for x in outputs['expanded-real'].splitlines() if x.startswith('MASKPROOF ')];positives=0;refusals=0
for i,f,token in admissions:
 name=m.FIX[f-1][0]
 if name.startswith('sm_refuse'):assert token==0,(name,token);refusals+=1
 else:
  width=int(name.split('_')[1][1:]);fuel=int(name.split('_')[2][1:]);assert token==width+256*fuel,(name,token);positives+=1
assert positives==98 and refusals==4
for label in outputs:assert [x for x in outputs[label].splitlines() if x.startswith('MASKPROOF ')]==[x for x in outputs['expanded-real'].splitlines() if x.startswith('MASKPROOF ')]
aa=m.blob_from(outputs['expanded-test']);bb=m.blob_from(outputs['expanded-real']);assert aa[1]==bb[1] and aa[0][:len(bb[0])]==bb[0] and not any(aa[0][len(bb[0]):]);assert 0<=len(aa[0])-len(bb[0])<=7
(w/'fixture-ids.json').write_text(json.dumps(ids,indent=2)+'\n');d=w/'expanded-run/unit/41-a64gen';d.mkdir(parents=True,exist_ok=True);(d/'stdout').write_text(outputs['expanded-real']);os.environ['SEED_BUILD']=str(w/'expanded-run');old=m.subprocess.run;m.subprocess.run=lambda args,**kw:types.SimpleNamespace(returncode=0,stdout='compiled and executed natively',stderr='') if args[:2]==['zsh',m.R+'/scripts/seed/unit.sh'] else old(args,**kw);previous=m.blob_from((w/'zero-admission/expanded-real.stdout').read_text());assert previous==bb;print('PASS fresh native generators reproduce exact previously executed fixture blob/FN table',flush=True);m.subprocess.run=old
(w/'expanded-proof.json').write_text(json.dumps({'status':'complete-native-hand-oracles-and-mask-admission','fixtures':len(m.FIX),'nativeRuns':len(m.RUNS),'nativePositiveSites':positives,'nativeRefusedSites':refusals,'codeAndLiteralBytesIdentical':True,'trailingZeroPaddingBytes':len(aa[0])-len(bb[0]),'candidateSha256':hashlib.sha256((w/'seed-4.bin').read_bytes()).hexdigest(),'fullSupervisorProofPending':True,'canonicalRunsReuse':'11582 actual prior native executions; fresh real/test native generators produce exact same full blob and FN table. No repeated executions claimed.'},indent=2)+'\n');print('PASS',len(m.RUNS),'actual native scalar-mask/base executions',flush=True)
