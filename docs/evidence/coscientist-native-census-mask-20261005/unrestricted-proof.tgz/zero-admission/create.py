from pathlib import Path
import json,subprocess,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-scalar-mask-call-20261005');base=Path('/private/tmp/amu-clamp-call-20261005');g=(r/'seed/41-a64gen.kotoba').read_text();proof=''';; Exact closed frameless scalar low-bit mask. Optional one entry charge.
;; Keep separate from gn-call-wrapper: original caller nonleaf prescan remains.
;; Token width +256*charged; zero means refusal. No names or input guesses.
(defn- gn-scalar-mask [M :vector-i64 i :i64 f :i64 n :i64] :i64
 (let [p (gn-fnf M f FF-SIR)
       fuel (if (= (gn-op M (inc p)) OP-FUEL) 1 0)
       q (+ p 1 fuel) mask (gn-sir M (inc q) IF-B)]
  (if (and (> f 0) (< f (vector-at M MM-FN-N)) (> p 0)
           (not (gn-clamp-open M f)) (= n 1)
           (not= (gn-op M (inc i)) OP-RES2)
           (= (gn-fnf M f FF-NPARAMS) 1) (= (gn-fnf M f FF-PT0) TY-I64)
           (= (gn-fnf M f FF-RTYPE) TY-I64)
           (= (gn-fnf M f FF-NSLOTS) 1) (<= (gn-fnf M f FF-DEPTH) 2)
           (= (gn-op M p) OP-FN) (= (gn-sir M p IF-A) f) (= (gn-sir M p IF-B) 1)
           (= (gn-op M q) OP-LGET) (= (gn-sir M q IF-A) 0) (= (gn-sir M q IF-B) 1)
           (= (gn-op M (inc q)) OP-CONST) (= (gn-sir M (inc q) IF-A) 1)
           (> mask 0) (= (bit-and mask (inc mask)) 0)
           (= (gn-op M (+ q 2)) OP-BIN) (= (gn-sir M (+ q 2) IF-A) BOP-AND)
           (= (gn-sir M (+ q 2) IF-B) 0) (= (gn-sir M (+ q 2) IF-C) 0)
           (= (gn-op M (+ q 3)) OP-RET) (= (gn-sir M (+ q 3) IF-A) 0)
           (= (gn-op M (+ q 4)) OP-END) (= (gn-sir M (+ q 4) IF-A) f))
      (+ (gn-tz (inc mask) 0) (* fuel 256)) 0)))
(defn- gn-call-scalar-mask [M :vector-i64 i :i64 t :i64 token :i64] :vector-i64
 (let [width (bit-and token 255) charged (>= token 256)]
  (-> M (gn-into 0 t) (gn-ctx)
      (cond-> charged (gn-emit (enc-ldr 8 7 CTX-FUEL)) charged (gn-mask-charge))
      (gn-emit (gn-e-bf 0xd3400000 0 0 0 (dec width)))
      (cond-> charged (gn-emit (enc-str 8 7 CTX-FUEL)))
      (gn-take i t 0))))
'''
pos=g.index('(defn- gn-op-call [');g=g[:pos]+proof+g[pos:];old='(let [w (gn-call-wrapper M i f t n) q (gn-clamp M i f n)]';assert g.count(old)==1;g=g.replace(old,'(let [w (gn-call-wrapper M i f t n) q (gn-clamp M i f n) mask (gn-scalar-mask M i f n)]');old='(cond (> q 0)';assert g.count(old)==1;g=g.replace(old,'(cond (> mask 0) (gn-call-scalar-mask M i t mask) (> q 0)');(w/'41-a64gen-prototype.kotoba').write_text(g);(w/'baseline-41-a64gen.kotoba').write_text((r/'seed/41-a64gen.kotoba').read_text());files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
for ext in ['bin','offset']:shutil.copyfile(base/('seed-4.'+ext),w/('seed-0.'+ext))
shutil.copyfile(base/'kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['build.py','check-ports.py']:(w/name).write_text((base/name).read_text().replace('amu-clamp-call-20261005','amu-scalar-mask-call-20261005'))
old=Path('/private/tmp/amu-static-arg-20261005')
for name in ['base-proof.py','baseline-a64gen-fixtures.py']:(w/name).write_text((old/name).read_text().replace('amu-static-arg-20261005','amu-scalar-mask-call-20261005'))
(w/'hypothesis.json').write_text(json.dumps({'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'hypothesis':'Direct composition of an exact closed frameless scalar low-bit-mask leaf, preserving original caller frame and callee fuel transaction. Known source mask lowers UBFX without call/return/argument shuffling.','dynamicEvidence':'Diagnostic native one-body census:5184 mask32 entries MD5,1776 SHA-256. Generic exact body proof, no source/workload names. Census counts do not prove time share.','recognition':'i64->i64,np/ns1,depth<=2,FN optionalFUEL LGET0slot1 CONST1positiveLowMask BIN-AND0 RET0 ENDsameFN. Open imports/RES2/different op/types/body/frame refuse.','proof':'nativeall19,threegenerationfixedpoint,handoracles signed/wrapping/width extremes/live operands/low fuel/open allocating imports/full supervisor,thenfresh30tripleseach changedworkload ratio>=1.05 and gap>sumSD;fullgatesintegratedcorpusbeforepromotion','exception':'New one-off Kotoba compiler algorithm, isolated; product unchanged'},indent=2)+'\n');print('registered measured scalar-mask leaf composition hypothesis')
