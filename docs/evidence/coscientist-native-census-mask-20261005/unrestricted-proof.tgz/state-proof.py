from pathlib import Path
import subprocess,os,re,json
w=Path('/private/tmp/amu-scalar-mask-call-20261005');scope={};s=(w/'expanded-proof.py').read_text();exec(s[:s.index("parts=['seed/")],scope);m=scope['m'];r=scope['r'];typed=scope['typed'].split('(defn- sm-admit')[0];first=scope['first'];ids=scope['ids'];env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];label='baseline-real';text=m.kotoba(True).replace('(defn- seed-main [] :i64',typed+'(defn- seed-main [] :i64',1).replace('        M0 (t-load (t-init))',f'        MT (sm-types (t-load (t-init)) {first})\n        M0 (t-put MT (+ MM-FN-BASE (* {ids["sm_refuse_wrong-type"]} MM-FN-W) FF-PT0) TY-BOOL)',1);src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'baseline-41-a64gen.kotoba').read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+text)
for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
 q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+mode+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,mode,q.stdout[-500:],q.stderr)
 if mode=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'.stdout')).write_text(q.stdout);assert q.returncode==0,(q.stdout[-200:],q.stderr);images={}
for label,path in [('baseline',w/'baseline-real.stdout'),('candidate',w/'expanded-real.stdout')]:
 blob,fc=m.blob_from(path.read_text());p=w/(label+'-fixture.bin');p.write_bytes(blob);images[label]=(p,fc)
rows=[]
for caller in scope['callnames']:
 f=ids[caller];nargs=1 if caller.startswith('sm_refuse') else 2
 for x in [m.MIN,-1,0,m.MAX]:
  for live in ([0] if nargs==1 else [m.MIN,37,m.MAX]):
   for fuel in [1,2,3,16777216]:
    pair={}
    for label,(p,fc) in images.items():
     e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(p),str(fc[f]),str(nargs),'aarch64','-',str(x),*([str(live)] if nargs==2 else [])],env=e,capture_output=True,text=True);assert ':fuel ' in q.stdout,(label,caller,q.stdout,q.stderr);pair[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
    assert pair['baseline']==pair['candidate'],(caller,x,live,fuel,pair);rows.append({'caller':caller,'x':x,'live':live,'fuel':fuel,'observation':pair['candidate']})
 print('PASS full report',caller,flush=True)
(w/'state-proof.json').write_text(json.dumps({'status':'complete-native-all-mask-fixture-supervisor-parity','comparisons':len(rows),'fields':'exit,result,fuel,heap,stringpool,vectors,vectoritems,diagnosticitems,traps; no allocations/writes in these scalar cases','runs':rows},indent=2)+'\n');print('PASS',len(rows),'full supervisor comparisons',flush=True)
