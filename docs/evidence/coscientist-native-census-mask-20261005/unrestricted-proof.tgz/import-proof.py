from pathlib import Path
import subprocess,os,re,json,struct
w=Path('/private/tmp/amu-scalar-mask-call-20261005');scope={};s=(w/'expanded-proof.py').read_text();exec(s[:s.index("parts=['seed/")],scope);m=scope['m'];r=scope['r'];typed=scope['typed'].split('(defn- sm-admit')[0];first=scope['first'];ids=scope['ids'];target=ids['sm_w32_f1'];m.fx('sm_replacement',1,1,[('FUEL',),('CONST',0,1),('RT','RT-VECTOR-ALLOC',0,1),('CONST',0,77),('RET',0)]);replacement=len(m.FIX);env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');images={};parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba']
for label in ['baseline-open','candidate-open','candidate-closed']:
 backend=w/('baseline-41-a64gen.kotoba' if label.startswith('baseline') else '41-a64gen-prototype.kotoba');test=m.kotoba(True).replace('(defn- seed-main [] :i64',typed+'(defn- seed-main [] :i64',1).replace('        M0 (t-load (t-init))',f'        M0 (sm-types (t-load (t-init)) {first})',1)
 if not label.endswith('closed'):test=test.replace('(gn-run M0)',f'(gn-run-open M0 {target} 1)',1)
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/x).read_text() for x in parts)+'\n'+backend.read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+test)
 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+mode+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,mode,q.stdout[-500:],q.stderr)
  if mode=='extract':offset=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),offset,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'.stdout')).write_text(q.stdout);assert q.returncode==0,(label,q.stdout[-400:],q.stderr);blob,fc=m.blob_from(q.stdout);patched=bytearray(blob);struct.pack_into('<I',patched,fc[target],0x14000000|(((fc[replacement]-fc[target])//4)&0x03ffffff));p=w/(label+'-linked.bin');p.write_bytes(patched);images[label]=(p,fc)
rows=[]
for t in [0,1,2,3,6,7,8]:
 caller=f'sm_w32_f1_t{t}';f=ids[caller]
 for x in [m.MIN,-1,0,m.MAX]:
  for fuel in [1,2,3,16777216]:
   pair={}
   for label,(path,fc) in images.items():
    e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(path),str(fc[f]),'2','aarch64','-',str(x),'37'],env=e,capture_output=True,text=True);assert ':fuel ' in q.stdout,(label,caller,q.stdout,q.stderr);pair[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
   assert pair['baseline-open']==pair['candidate-open'],(caller,x,fuel,pair)
   if fuel>=2:assert pair['candidate-open']!=pair['candidate-closed'],(caller,x,fuel,pair)
   rows.append({'caller':caller,'x':x,'fuel':fuel,**pair})
 print('PASS actual allocating import substitution',caller,flush=True)
(w/'import-proof.json').write_text(json.dumps({'status':'complete-native-mask-allocating-import-refusal','comparisons':len(rows),'closedControlsDiffer':True,'signature':'one i64->i64; actual alternate allocates and charges fuel, returns77; allocator clobbersx7','runs':rows},indent=2)+'\n')
