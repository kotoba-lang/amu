from pathlib import Path
import subprocess,os,re,json
w=Path('/private/tmp/amu-native-census-20261005');r=Path('/Users/junkawasaki/github/wt/amu-seed17');base=Path('/private/tmp/amu-clamp-call-20261005');src=w/'counter-control.kotoba';src.write_text('''(ns native.census.control (:export [bench]))
(defn- a [x :i64] :i64 (+ x 1))
(defn- b [x :i64] :i64 (+ (a x) 2))
(defn bench [n :i64] :i64 (loop [i 0 total 0] (if (>= i n) total (recur (+ i 1) (+ total (b i))))))
''');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');images={};maps={}
for label,seed,offset in [('baseline',base/'seed-4.bin',0),('census',w/'census-seed.bin',int((w/'census-seed.offset').read_text()))]:
 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'-control.kseed'))]),('extract',['extract-native',str(w/(label+'-control.kseed')),'--symbol','bench','--output',str(w/(label+'-control.bin'))])]:
  q=subprocess.run([str(w/'census-loader'),str(seed),str(offset),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-control-'+mode+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,mode,q.stdout,q.stderr)
  if mode=='compile' and label=='census':
   for f,a,b,kind in re.findall(r'^FNMAP (\d+) (\d+) (\d+) (\d+)',q.stdout,re.M):maps[src.read_text()[int(a):int(b)]]=int(f)
  if mode=='extract':images[label]=(w/(label+'-control.bin'),int(re.search(r':offset (\d+)',q.stdout).group(1)))
rows=[]
for n in [-1,0,1,2,17]:
 for fuel in [1,2,3,16777216]:
  pair={};counts={}
  for label,(p,offset) in images.items():
   e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1',KEXE_NATIVE_CENSUS='1');e.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'census-loader'),str(p),str(offset),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True);(w/(label+f'-control-n{n}-fuel{fuel}.stdout')).write_text(q.stdout);(w/(label+f'-control-n{n}-fuel{fuel}.stderr')).write_text(q.stderr);pair[label]={'exit':q.returncode,'report':q.stdout.strip(),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
   if label=='census':counts={int(a):int(b) for a,b in re.findall(r'^NATIVE_COUNT (\d+) (\d+)$',q.stderr,re.M)}
  assert pair['baseline']==pair['census'],(n,fuel,pair)
  if fuel==16777216:
   assert counts.get(maps['bench'],0)==1 and counts.get(maps['a'],0)==max(0,n) and counts.get(maps['b'],0)==max(0,n),(n,counts,maps)
   expected=max(0,n)*(max(0,n)-1)//2+3*max(0,n);assert f':result {expected} ' in pair['census']['report']
  rows.append({'n':n,'fuel':fuel,'counts':counts,'observation':pair['census']})
(w/'counter-control.json').write_text(json.dumps({'status':'complete-native-counter-oracles-and-trap-parity','cases':rows,'functionMap':maps},indent=2)+'\n');print('PASS20 native count/report/fuel/trap controls')
