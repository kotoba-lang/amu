from pathlib import Path
import subprocess,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-native-census-20261005');g=(r/'seed/41-a64gen.kotoba').read_text();c=(r/'tools/kexe_loader.c').read_text()
helper=''';; DIAGNOSTIC ONLY. Appended context pointer400 belongs solely to census loader.
;; Scratch x16/x17 and non-flag-setting instructions preserve live operands/NZCV.
(defn- gn-census [M :vector-i64 index :i64] :vector-i64
 (-> M (gn-ctx) (gn-emit (enc-ldr 16 7 400)) (gn-mov-imm 17 (* index 8))
       (gn-emit (enc-add-r 16 16 17)) (gn-emit (enc-ldr 17 16 0))
       (gn-emit (enc-add-i 17 17 1)) (gn-emit (enc-str 17 16 0))))
'''
pos=g.index('(defn- gn-op-fn [');g=g[:pos]+helper+g[pos:];old='(gn-gs gn-f-h 0) (gn-tree-entry f)';assert g.count(old)==1;g=g.replace(old,'(gn-gs gn-f-h 0) (gn-census f) (gn-tree-entry f)')
old='(defn- gn-op-rt [M :vector-i64 i :i64 slot :i64 t :i64 n :i64] :vector-i64';assert g.count(old)==1;g=g.replace(old,'(defn- gn-op-rt-body [M :vector-i64 i :i64 slot :i64 t :i64 n :i64] :vector-i64');pos=g.index(';; VEC t n:');g=g[:pos]+'''(defn- gn-op-rt [M :vector-i64 i :i64 slot :i64 t :i64 n :i64] :vector-i64
 (gn-op-rt-body (gn-census M (+ 4096 (quot slot 8))) i slot t n))
'''+g[pos:]
# Native name->FN provenance from frontend symbol byte spans, not a guessed parse order.
fields=['f','(vector-at M2 (+ MM-SYM-BASE (* (gn-fnf M2 f FF-SYM) MM-SYM-W) SF-START))','(vector-at M2 (+ MM-SYM-BASE (* (gn-fnf M2 f FF-SYM) MM-SYM-W) SF-END))','(gn-fnf M2 f FF-KIND)'];s='"\\n"'
for f in reversed(fields):s='(string-concat (string-from-i64 '+f+') (string-concat " " '+s+'))'
old='                leaf (gn-g M2 gn-f-leaf)]';assert g.count(old)==1;g=g.replace(old,'                leaf (gn-g M2 gn-f-leaf)\n                map_observed (io-out (string-concat "FNMAP " '+s+'))]')
(w/'41-a64gen-census.kotoba').write_text(g);files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
old='  uint64_t code_length;\n};';assert c.count(old)==1;c=c.replace(old,'  uint64_t code_length;\n  uint64_t *native_census; /* diagnostic-only appended pointer, offset400 */\n};\n_Static_assert(offsetof(struct kexe_context_v11, native_census)==400, "diagnostic ABI drift");')
old='  shared->context.code_length = (uint64_t)length;';assert c.count(old)==1;c=c.replace(old,old+'''\n  void *native_counts = mmap(NULL, 12288 * sizeof(uint64_t), PROT_READ|PROT_WRITE, MAP_SHARED|MAP_ANONYMOUS, -1,0);
  if (native_counts==MAP_FAILED) fail("native census mmap");
  shared->context.native_census = native_counts;''')
old='    report_budget_trap(shared, child_status);';assert c.count(old)==1;c=c.replace(old,old+'''\n    if (getenv("KEXE_NATIVE_CENSUS") != NULL) {
      for (unsigned i=0;i<12288;i++) if (shared->context.native_census[i])
        fprintf(stderr,"NATIVE_COUNT %u %" PRIu64 "\\n",i,shared->context.native_census[i]);
    }''');(w/'census-loader.c').write_text(c);q=subprocess.run(['clang','-std=c11','-O2','-I',str(r/'tools'),str(w/'census-loader.c'),'-o',str(w/'census-loader')],capture_output=True,text=True);(w/'loader-build.log').write_text(q.stdout+q.stderr);assert q.returncode==0,q.stderr
(w/'hypothesis.json').write_text(json.dumps({'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'purpose':'Actual native function-entry and ordinary RT-lowering execution census; no elapsed-time/cost attribution or full operation coverage claim. Generic fusion bypasses some helper and RT sites; those omitted operations must not be counted as zero actual memory cost.','instrumentation':'Diagnostic appended context pointer400->shared12288counts. Each increment uses only scratchx16/x17 and no flags/calls/charges; gn-ctx restores actual context if needed. Product compiler source/native bytes unchanged.','next':'Inspect busiest actual native callee and its exact SIR/body; choose generic removable cost then prospective proof and fresh quiet C/baseline/candidate timing.','exception':'One-off diagnostic instrumentation authoring; no product mechanical refactor'},indent=2)+'\n');print('created isolated native census compiler and loader')
