#include "c-bridge.c"
#include <stdio.h>
int main(void){for(int n=1;n<=32;n++)if(oracle_selfcheck(n,0,0,0,0,0,0,0)!=1||bench(n,0,0,0,0,0,0,0)!=1)return 1;
for(int n=0;n<=1024;n++){if(prefix_crc(n,0,0,0,0,0,0,0)<0||prefix_seed(n,0,0,0,0,0,0,0)<0)return 2;}for(int i=0;i<256;i++)if(table_entry(i,0,0,0,0,0,0,0)<0)return 3;
printf("PASS 32 original CRC bodies/verifiers/RNG, 2306 initialized table/prefix observations\n");return 0;}
