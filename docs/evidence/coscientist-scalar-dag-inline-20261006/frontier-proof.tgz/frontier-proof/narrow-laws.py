from pathlib import Path
import json
D=Path(__file__).resolve().parent
wrap=lambda x:((x+(1<<63))%(1<<64))-(1<<63)
short=lambda x:((x+32768)%65536)-32768
def quot(x,d):return (-1 if x<0 else 1)*(abs(x)//d)
def sourcefloor(x,d):return wrap(-quot(wrap(wrap(-x)+(d-1)),d)) if x<0 else quot(x,d)
rows=[]
for f in [196,277,669,362]:
 for x in range(-32768,32768):
  v=x*f+128;assert -(1<<31)<=v<(1<<31);assert sourcefloor(v,256)==v//256;assert short(sourcefloor(v,256))==short(v>>8)
 rows.append({'factor':f,'signed16Inputs':65536,'noSigned32Overflow':True,'sourceFloorMatchesASR8ThenWrap16':True})
for x in range(-65536,65535):assert sourcefloor(x+64,128)==((x+64)>>7)
faults=[{'fault':'generic i64 floor loses source signed-overflow behavior','source':sourcefloor(-(1<<63),256),'ASR':(-(1<<63))>>8},{'fault':'signed versus saturating16 narrowing','wrap16':short((32767*669+128)>>8),'saturated':min(32767,(32767*669+128)>>8)},{'fault':'treat unsigned-offset depth operand as signed8','input':196,'signed8':-60,'filter':1,'sourceProduct':196,'wrongSDOTProduct':-60}];assert faults[0]['source']!=faults[0]['ASR'] and faults[1]['wrap16']!=faults[1]['saturated'] and faults[2]['sourceProduct']!=faults[2]['wrongSDOTProduct']
(D/'narrow-laws.json').write_text(json.dumps({'status':'PASS finite source semantic laws and unsafe generalization controls; no native instruction run','picoMultiplyRows':rows,'picoDescaleBoundedValues':131071,'faults':faults,'fullI64SignExtend16Law':'Source masklow16/branchsubtract65536 equals signextend16 on every low16 pattern; arbitraryhigherbits ignored.','notProved':'Actual bounded CFG/rooted match, SIMD lane ordering/rounding/store/fuel/register contracts remain future proof.'},indent=2)+'\n');print('PASS bounded262144multiply+131071descale cases and3 unsafe model controls')
