from pathlib import Path
import subprocess,os,re,json,hashlib
W=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17');B=Path('/private/tmp/amu-stable-vector-cfg-20261006/implementation');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def out(prefix,fields):
 s='"\\n"'
 for x in reversed(fields):s=f'(string-concat (string-from-i64 {x}) (string-concat " " {s}))'
 return f'(io-out (string-concat "{prefix} " {s}))'
helper=(W/'inline-native.kotoba').read_text()
# Observer emits no generator mutation, and all19 binaries must be exact.
needle='(defn- di-call ['
extra='(defn- di-observe-args [M :vector-i64 t :i64 n :i64 k :i64] :i64\n (if (= k n) 0\n  (let [u (+ t k) printed '+out('DIARGS',['u','(gn-dk M u)','(gn-dv M u)','(gn-sr M u 1)','(gn-home M u)','(gn-soff M (gn-home M u))'])+']\n   (di-observe-args M t n (inc k)))))\n'
helper=helper.replace(needle,extra+needle)
needle='       m0 (di-save M 0 0)';helper=helper.replace(needle,'       before '+out('DIPRE',['i','f','t','n','end','code','fix','(gn-g M gn-f-fb)','(gn-g M gn-f-ns)','(gn-g M gn-f-dp)','(gn-g M gn-f-h)','(gn-g M gn-f-ctx)','(gn-g M gn-f-vmode)','(gn-g M di-used)','(gn-g M di-sites)'])+'\n       args (di-observe-args M t n 0)\n'+needle)
helper=helper.replace('       m2 (di-emit-body','       bodyStart (vector-at m1 MM-CODE-N)\n       m2 (di-emit-body')
helper=helper.replace('       m3 (-> m2','       bodyEnd (vector-at m2 MM-CODE-N)\n       m3 (-> m2')
needle='(= (vector-at m3 MM-FIX-N) fix))]';helper=helper.replace(needle,'(= (vector-at m3 MM-FIX-N) fix))\n       observed '+out('DIRESULT',['i','f','t','n','end','code','bodyStart','bodyEnd','(vector-at m3 MM-CODE-N)','words','(if good 1 0)','(gn-g m3 di-used)','(gn-g m3 di-sites)'])+']')
helper=helper.replace('  (let [op (gn-op M j) a (gn-sir M j IF-A) b (gn-sir M j IF-B)\n        m1 (case op','  (let [start (vector-at M MM-CODE-N) op (gn-op M j) a (gn-sir M j IF-A) b (gn-sir M j IF-B)\n        m1 (case op')
helper=helper.replace('        skip (gn-g m1 gn-f-skip)]','        skip (gn-g m1 gn-f-skip) printed '+out('DIBODY',['j','op','a','b','start','(vector-at m1 MM-CODE-N)','skip'])+']')
g=(B/'observer/41.kotoba').read_text()
prepare=(W/'prepare.py').read_text();ops=prepare[prepare.index("needle='(defn- gn-op-call [") :prepare.index("(W/'41-a64gen-prototype.kotoba').write_text")]
ctx={'g':g,'helper':helper};exec(ops,ctx);g=ctx['g']
o=W/'observer';o.mkdir(exist_ok=True);(o/'41.kotoba').write_text(g)
parts=[p.strip() for p in (R/'seed/MANIFEST').read_text().splitlines() if p.strip() and not p.lstrip().startswith('#')];(o/'unity.kotoba').write_text('\n'.join(g if p=='seed/41-a64gen.kotoba' else (R/p).read_text() for p in parts))
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for label,args in [('compile',['compile',str(o/'unity.kotoba'),'--target','aarch64-macos','--output',str(o/'image.kseed')]),('extract',['extract-native',str(o/'image.kseed'),'--symbol','main','--output',str(o/'seed.bin')])]:
 q=subprocess.run([str(W/'kexe-loader'),str(W/'seed-0.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(o/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout[-2000:],q.stderr[-1000:])
 if label=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1);(o/'seed.offset').write_text(off+'\n')
rows=[];base=json.loads((W/'ports-build.json').read_text())['entries']
for e in json.loads((R/'bench/embench/comparison-matrix.json').read_text())['entries']:
 d=o/'ports'/e['workload'];d.mkdir(parents=True,exist_ok=True)
 for label,args in [('compile',['compile',str(R/e['source']),'--target','aarch64-macos','--output',str(d/'image.kseed')]),('extract',['extract-native',str(d/'image.kseed'),'--symbol',e['symbol'],'--output',str(d/'native.bin')])]:
  q=subprocess.run([str(W/'kexe-loader'),str(o/'seed.bin'),off,'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(e['workload'],label,q.stdout[-2000:],q.stderr[-1000:])
  if label=='extract':offset=int(re.search(r':offset (\d+)',q.stdout).group(1))
 old=next(x for x in base if x['workload']==e['workload']);assert sha(d/'native.bin')==old['nativeSha256'] and offset==old['offset']
 records=[list(map(int,l.split()[1:])) for l in (d/'compile.log').read_text().splitlines() if l.startswith('DIRESULT ')];rows.append({'workload':e['workload'],'nativeSha256':sha(d/'native.bin'),'offset':offset,'admissions':records});print('PASS byte-exactobserver',e['workload'],'inline',sum(r[10] for r in records),flush=True)
(o/'admission.json').write_text(json.dumps({'status':'PASS read-only observer byte+offset exact all19','schema':{'DIPRE':'i f t n end code fix frame ns dp h ctx vmode used sites','DIARGS':'temp descriptorKind descriptorValue sourceRegister homeSlot homeByteOffset','DIBODY':'calleeSir op a b firstWord afterWord skip','DIRESULT':'i f t n end code firstBody afterBody afterFinish fullSpanWords accepted priorUsed priorSites'},'entries':rows},indent=2)+'\n')
