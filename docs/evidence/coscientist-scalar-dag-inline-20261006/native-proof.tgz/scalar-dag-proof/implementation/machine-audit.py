from pathlib import Path
import json,struct,copy,collections,hashlib
W=Path(__file__).resolve().parent
exec(Path('/private/tmp/amu-native-hotpath-20261006/implementation/machine-audit.py').read_text().split('rows=[];tot=')[0])
W=Path(__file__).resolve().parent;B=Path('/private/tmp/amu-stable-vector-cfg-20261006/implementation/observer/ports')
def load(p):
 d=parse(p);d['di']={};d['pre']={};d['args']={};owner=None
 for line in (p/'compile.log').read_text().splitlines():
  q=line.split()
  if not q:continue
  if q[0]=='DIPRE':v=tuple(map(int,q[1:]));owner=v[0];d['pre'][owner]=v;d['args'][owner]=[]
  if q[0]=='DIARGS':d['args'][owner].append(tuple(map(int,q[1:])))
  if q[0]=='DIRESULT':v=tuple(map(int,q[1:]));assert v[0] not in d['di'];d['di'][v[0]]=v
 return d

def verify_expansions(a,b):
 assert a['sir']==b['sir'] and a['fn'].keys()==b['fn'].keys()
 for f,v in a['fn'].items():assert v[:-1]==b['fn'][f][:-1],('fnframeownership',f,v,b['fn'][f])
 assert [(e[0],e[1]) for e in a['events']]==[(e[0],e[1]) for e in b['events']]
 eventsA={e[0]:e for e in a['events']};eventsB={e[0]:e for e in b['events']};sites={};used=0;cnt=0
 for i,q in b['di'].items():
  si,f,t,n,end,code,bs,be,finish,words,good,priorUsed,priorSites=q
  assert priorUsed==used and priorSites==cnt and words==finish-code and words>=0
  assert good in (0,1)
  if not good:continue
  assert words<=64 and used+words<=4096 and cnt<256
  pre=b['pre'][i];assert pre[:7]==(i,f,t,n,end,code,pre[6]) and pre[7]>0 and pre[10]>=t+n
  args=b['args'][i];assert len(args)==n
  for k,(u,kind,value,reg,home,off) in enumerate(args):
   assert u==t+k and kind in (1,2,3,4)
   if kind==3:assert value>0 and (reg<0 or 19<=reg<=28)
   if kind==1 and u<7:assert reg==9+u
   if kind==4 or kind==1 and u>=7:assert reg<0
   assert home==pre[8]+1+u and off==pre[7]-8*(home+1)
  op,fa,tt,nn=a['sir'][i];assert (op,fa,tt,nn)==(13,f,t,n)
  ea=eventsA[i];eb=eventsB[i];assert eb[2]==code and eb[3]==finish and ea[1]==eb[1]
  fixes=[x for x in a['fix'] if ea[2]<=x[1]<ea[3]]
  assert len(fixes)==1 and fixes[0][2:]==(4,f,0)
  oldat=fixes[0][1];oldword=a['words'][oldat-1];assert oldword&0xfc000000==0x94000000
  assert oldat+branch(oldword)[1]==a['fn'][f][-1]
  assert a['words'][ea[2]-1:oldat-1]==b['words'][code-1:bs-1],('prefix/saveargsctx',i)
  assert a['words'][oldat:ea[3]-1]==b['words'][be-1:finish-1],('suffix/cachetake',i)
  fn=a['fn'][f];assert fn[1]==0 and fn[4]==0 and fn[5]==1 and fn[2]<=7 and fn[3]<=7
  ret=[e for e in a['events'] if fn[0]<e[0]<end and a['sir'][e[0]][0]==19]
  assert len(ret)==1 and a['words'][ret[0][3]-2]==0xd65f03c0
  expected=a['words'][fn[-1]-1:ret[0][3]-2]
  assert expected==b['words'][bs-1:be-1],('exactoriginalcallee-body',i,expected,b['words'][bs-1:be-1])
  assert not any(branch(z) for z in expected)
  assert not any(bs<=x[1]<be for x in b['fix'])
  sites[i]={'fn':f,'oldCallWord':oldat,'firstBody':bs,'afterBody':be,'fullSpanWords':words,'bodyWords':len(expected),'prefixWords':bs-code,'suffixWords':finish-be}
  used+=words;cnt+=1
 return sites

def normalize(d,sites,candidate):
 stream=[];pos={};edges=[];internal=set();lit={};fixremoved=set()
 for ix,at,k,t,u in d['fix']:
  if k==5:lit[at]=(t,0);lit[at+1]=(t,1)
 for sir,skip,start,end in d['events']:
  r=sites.get(sir);lo=r['firstBody'] if candidate and r else r['oldCallWord'] if r else 0;hi=r['afterBody'] if candidate and r else lo+1
  j=start
  while j<end:
   if r and j==lo:
    for k in range(lo,hi):pos[k]=len(stream)
    stream.append(('INLINE',sir,r['fn']));internal.update(range(lo+1,hi));j=hi
    if not candidate:fixremoved.add(lo)
    continue
   pos[j]=len(stream);z=d['words'][j-1];q=branch(z)
   if q:stream.append(('BR',q[0]));edges.append((len(stream)-1,j+q[1]))
   elif j in lit:stream.append(('LIT',lit[j],z&~0x1fffe0))
   else:stream.append(('WORD',z))
   j+=1
  pos[end]=len(stream)
 assert set(pos)==set(range(1,d['n']+1)),('fullwordcoverage',len(pos),d['n'])
 for ix,target in edges:assert target not in internal,('externaledgeinexpandedbody',target)
 return stream,pos,edges,fixremoved

def audit(a,b):
 sites=verify_expansions(a,b);aa,pa,ea,removed=normalize(a,sites,False);bb,pb,eb,_=normalize(b,sites,True)
 assert aa==bb,next(((i,x,y) for i,(x,y) in enumerate(zip(aa,bb)) if x!=y),(len(aa),len(bb)))
 assert len(ea)==len(eb)
 for x,y in zip(ea,eb):assert x[0]==y[0] and pa[x[1]]==pb[y[1]],('projectededge',x,y)
 for f,v in a['fn'].items():assert pa[v[-1]]==pb[b['fn'][f][-1]]
 for x,y in zip(a['events'],b['events']):assert pa[x[2]]==pb[y[2]] and pa[x[3]]==pb[y[3]],('eventprojection',x,y)
 af=[x for x in a['fix'] if x[1] not in removed];assert len(af)==len(b['fix'])
 private=literal=0;ap=((a['n']-1)*4+7)//8*8;bp=((b['n']-1)*4+7)//8*8
 for (ix,at,k,t,u),(iy,bt,l,s,v) in zip(af,b['fix']):
  assert (k,t,u)==(l,s,v) and pa[at]==pb[bt]
  if k==5:
   assert pa[at+1]==pb[bt+1]
   old=((a['words'][at-1]>>5)&65535)|(((a['words'][at]>>5)&65535)<<16);new=((b['words'][bt-1]>>5)&65535)|(((b['words'][bt]>>5)&65535)<<16);assert old-ap==new-bp;literal+=2
  if u:
   assert k==4 and u==1;oe=a['fn'][t][-1];ne=b['fn'][t][-1]
   assert a['words'][oe-1]==b['words'][ne-1]==0xd2800005
   assert at+branch(a['words'][at-1])[1]==oe+1 and bt+branch(b['words'][bt-1])[1]==ne+1;private+=1
 assert a['raw'][ap:]==b['raw'][bp:] and set(a['raw'][(a['n']-1)*4:ap])<={0} and set(b['raw'][(b['n']-1)*4:bp])<={0}
 assert b['n']-a['n']==sum(r['bodyWords']-1 for r in sites.values())
 return {'sites':len(sites),'callees':len({r['fn'] for r in sites.values()}),'inlineEmittedWords':sum(r['fullSpanWords'] for r in sites.values()),'addedWords':b['n']-a['n'],'remainingTokens':len(aa),'remainingEdges':len(ea),'literalWords':literal,'privateAux1':private,'details':sites}

if __name__=='__main__':
 rows=[];tot=collections.Counter();data={}
 for r in json.loads((W/'observer/admission.json').read_text())['entries']:
  name=r['workload'];a=load(B/name);b=load(W/'observer/ports'/name);v=audit(a,b);data[name]=(a,b,v);rows.append({'workload':name,**v});tot.update({k:x for k,x in v.items() if isinstance(x,int)});print('PASS',name,v['sites'],v['addedWords'],flush=True)
 controls=[]
 def reject(name,title,mutate):
  a,b,_=data[name];d=copy.deepcopy(b);mutate(d)
  try:audit(a,d)
  except (AssertionError,KeyError,IndexError) as e:controls.append({'mutation':title,'workload':name,'status':'DETECTED','diagnostic':str(e)[:400]})
  else:raise AssertionError('accepted mutant '+title)
 name='nettle-aes';a,b,v=data[name];i=next(iter(v['details']));r=v['details'][i]
 reject(name,'inline arithmetic/register word',lambda d:d['words'].__setitem__(r['firstBody']-1,d['words'][r['firstBody']-1]^1))
 reject(name,'capture argument word',lambda d:d['words'].__setitem__(b['di'][i][5]-1,d['words'][b['di'][i][5]-1]^1))
 reject(name,'fullspan budget off-by-one',lambda d:d['di'].__setitem__(i,tuple(x+1 if k==9 else x for k,x in enumerate(d['di'][i]))))
 reject(name,'unsafe low-local argument source',lambda d:d['args'][i].__setitem__(0,(d['args'][i][0][0],3,1,0,*d['args'][i][0][4:])))
 reject(name,'module accounting drift',lambda d:d['di'].__setitem__(i,tuple(x+1 if k==11 else x for k,x in enumerate(d['di'][i]))))
 ret=next(e for e in b['events'] if b['sir'][e[0]][0]==19 and e[3]>e[2]);reject(name,'remaining return word',lambda d:d['words'].__setitem__(ret[3]-2,d['words'][ret[3]-2]^1))
 edge=next(at for ix,at,k,t,u in b['fix'] if k==4);reject(name,'external edge into inline interior',lambda d:d['words'].__setitem__(edge-1,0x94000000|((r['firstBody']+1-edge)&0x3ffffff)))
 for name,(a,b,v) in data.items():
  lits=[at for ix,at,k,t,u in b['fix'] if k==5]
  if lits:reject(name,'literal pointer constant',lambda d:d['words'].__setitem__(lits[0]-1,d['words'][lits[0]-1]^32));break
 for name,(a,b,v) in data.items():
  prv=[j for j,x in enumerate(b['fix']) if x[4]]
  if prv:reject(name,'private aux1 contract',lambda d:d['fix'].__setitem__(prv[0],tuple([*d['fix'][prv[0]][:4],0])));break
 report={'status':'PASS full actual original19 machine projection and exact original scalar callee body expansion','totals':dict(tot),'rows':rows,'controls':controls,'limits':['All original call prefix save/arguments/context and suffix cacheclear/resulttake exact. Every inline body byte equals preserved original frameless scalar callee machine body without RET.','Only declared literal MOVZ/MOVK pointer fields normalized with exact pool-relative validation. Every remaining branch/fixup/privateaux1 and fullpool retained.','Typed SIR admission, caller source-bank/frame lifetime and generic scalar arithmetic meaning require independent admission/constructor/resource proofs. No timing or arbitrary-program proof claim.']}
 (W/'machine-audit.json').write_text(json.dumps(report,indent=2)+'\n');print('TOTAL',dict(tot))
