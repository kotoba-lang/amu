from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
g=(W/'baseline-41-a64gen.kotoba').read_text();helper=(W/'inline-native.kotoba').read_text()
needle='(defn- gn-op-call [';assert g.count(needle)==1;g=g.replace(needle,helper+'\n'+needle)
needle='reader (if (= (gn-g M gn-f-leaf) 2) 0 (gn-affine-reader M i f n))]';assert g.count(needle)==1;g=g.replace(needle,'reader (if (= (gn-g M gn-f-leaf) 2) 0 (gn-affine-reader M i f n)) dag (di-admit M i f t n)]')
needle='         (and (<= n 7) (= (gn-op M (inc i)) OP-RET)';assert g.count(needle)==1;g=g.replace(needle,'         (> dag 0) (di-call M i f t n dag)\n         :else (gn-call-generic M i f t n))))\n(defn- gn-call-generic [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :vector-i64\n (cond\n'+needle)
needle='(gn-take i t 0)))))\n;; A direct call';assert g.count(needle)==1;g=g.replace(needle,'(gn-take i t 0))))\n;; A direct call')
needle='(mem-alloc M0 (+ gn-a-lp MM-LABEL-CAP 2))';assert g.count(needle)==1;g=g.replace(needle,'(mem-alloc M0 (+ gn-a-lp MM-LABEL-CAP 80))')
needle='(gn-gs gn-g-open first) (gn-gs gn-g-open-n count))';assert g.count(needle)==1;g=g.replace(needle,'(gn-gs gn-g-open first) (gn-gs gn-g-open-n count)\n               (gn-gs di-used 0) (gn-gs di-sites 0))')
(W/'41-a64gen-prototype.kotoba').write_text(g)
parts=[p.strip() for p in (R/'seed/MANIFEST').read_text().splitlines() if p.strip() and not p.lstrip().startswith('#')]
(W/'unity.kotoba').write_text('\n'.join(g if p=='seed/41-a64gen.kotoba' else (R/p).read_text() for p in parts))
for rel in parts+['seed/MANIFEST','seed/SIR','seed/HEADS','seed/MEMORY-MAP','bench/embench/comparison-matrix.json']:
 p=W/'source-snapshot'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(g if rel=='seed/41-a64gen.kotoba' else (R/rel).read_text())
(W/'source-pins.json').write_text(json.dumps({p.name:sha(p) for p in [W/'inline-native.kotoba',W/'41-a64gen-prototype.kotoba',W/'unity.kotoba',W/'42-layout-prototype.kotoba']},indent=2)+'\n')
print('Separate scalar DAG candidate source written and pinned')
