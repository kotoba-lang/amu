from pathlib import Path
import subprocess,os,re,json,hashlib
W=Path(__file__).resolve().parent;D=W/'proof-controls';D.mkdir(exist_ok=True)
base=(W/'unity.kotoba').read_text().replace('(ns seed (:export [main]))','(ns seed (:export [main probe]))',1)
probe='''
(defn- cp-put [M :vector-i64 i :i64 op :i64 a :i64 b :i64 c :i64] :vector-i64
 (let [x (+ MM-SIR-BASE (* i MM-SIR-W))]
  (-> M (vector-assoc! x op) (vector-assoc! (+ x 1) a) (vector-assoc! (+ x 2) b) (vector-assoc! (+ x 3) c))))
(defn probe [case :i64] :i64
 (let [g 1000 f (+ MM-FN-BASE MM-FN-W)
       M (-> (vector-alloc (+ MM-SIR-BASE (* 10 MM-SIR-W)))
        (vector-assoc! gn-cell g) (vector-assoc! MM-FN-N 2) (vector-assoc! MM-SIR-N 8)
        (vector-assoc! (+ f FF-NPARAMS) 1) (vector-assoc! (+ f FF-RTYPE) TY-I64)
        (vector-assoc! (+ f FF-PT0) (if (= case 16) TY-BOOL TY-I64))
        (vector-assoc! (+ f FF-NSLOTS) (if (= case 3) 2 1)) (vector-assoc! (+ f FF-DEPTH) 2) (vector-assoc! (+ f FF-SIR) 1)
        (gn-gs gn-f-leaf (if (= case 11) 1 0)) (gn-gs gn-f-fb 64)
        (gn-gs gn-f-ns 2) (gn-gs gn-f-dp 3) (gn-gs gn-f-h (if (= case 14) 0 2))
        (gn-gs (+ gn-a-sreg 1) (if (= case 2) 1 20))
        (gn-dset 0 (if (= case 13) 0 gn-k-local) 1)
        (gn-gs gn-g-open (if (= case 1) 1 0)) (gn-gs gn-g-open-n (if (= case 1) 1 0))
        (gn-gs di-used (if (= case 9) 4096 0)) (gn-gs di-sites (if (= case 10) 256 0))
        (cp-put 1 OP-FN 1 1 (if (= case 3) 2 1))
        (cp-put 2 OP-LGET 0 (if (= case 3) 2 1) 0)
        (cp-put 3 (if (= case 5) OP-FUEL OP-CONST) 1 7 0)
        (cp-put 4 OP-BIN (if (= case 6) BOP-QUOT BOP-ADD) (if (= case 4) 1 0) 0)
        (cp-put 5 OP-RET 0 0 (if (= case 7) 1 0))
        (cp-put 6 (if (= case 8) OP-CONST OP-END) (if (= case 15) 2 1) 0 0)
        (cp-put 7 OP-CALL 1 0 1))]
  (di-admit M 7 1 0 (if (= case 12) 6 1))))
'''
expected=[6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6]
variants=[('pristine',None,None),('ignore-open','(> n 5) (gn-clamp-open M f))','(> n 5) false)'),('allow-low-local','(or (< r 0) (and (>= r 19) (<= r 28)))','true'),('ignore-definition','(di-have locals b)','true'),('ignore-ret-reserved','OP-RET (and (>= a 0) (< a h) (= b 0) (= c 0)','OP-RET (and (>= a 0) (< a h) (= b 0) true'),('ignore-used-cap','(< (gn-g M di-used) 4096)','true'),('ignore-site-cap','(< (gn-g M di-sites) 256)','true'),('allow-leaf','(and (= (gn-g M gn-f-leaf) 0) (> (gn-g M gn-f-fb) 0)','(and true (> (gn-g M gn-f-fb) 0)')]
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/private/tmp:/Users/junkawasaki/github/wt/amu-seed17',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[]
for name,needle,replacement in variants:
 d=D/name;d.mkdir(exist_ok=True);source=base
 if needle is not None:assert source.count(needle)==1,(name,source.count(needle));source=source.replace(needle,replacement)
 (d/'source.kotoba').write_text(source+probe)
 for step,args in [('compile',['compile',str(d/'source.kotoba'),'--target','aarch64-macos','--output',str(d/'image.kseed')]),('extract',['extract-native',str(d/'image.kseed'),'--symbol','probe','--output',str(d/'native.bin')])]:
  q=subprocess.run([str(W/'kexe-loader'),str(W/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(step+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,step,q.stdout[-2000:],q.stderr[-2000:])
  if step=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1]);(d/'native.offset').write_text(str(off)+'\n')
 outcomes=[]
 for case in range(len(expected)):
  e=dict(os.environ,KEXE_STRUCTURED_REPORT='1',KEXE_FUEL='100000000',KEXE_VECTOR_ITEMS='134217728');e.pop('KEXE_COMMAND',None)
  q=subprocess.run([str(W/'kexe-loader'),str(d/'native.bin'),str(off),'1','aarch64','-',str(case)],env=e,capture_output=True,text=True);(d/f'case-{case}.stdout').write_text(q.stdout);(d/f'case-{case}.stderr').write_text(q.stderr);assert q.returncode==0,(name,case,q.stdout,q.stderr)
  outcomes.append(int(re.search(r':result (-?\d+)',q.stdout)[1]))
 if name=='pristine':assert outcomes==expected,(outcomes,expected)
 else:assert outcomes!=expected,(name,'undetected')
 rows.append({'variant':name,'outcomes':outcomes,'status':'PASS pristine' if name=='pristine' else 'MUTATION DETECTED','nativeSha256':hashlib.sha256((d/'native.bin').read_bytes()).hexdigest()});print(name,outcomes,flush=True)
(D/'report.json').write_text(json.dumps({'status':'PASS actual native admission17cases and7actualsource mutation calibrations','nativeExecutions':len(expected)*len(variants),'rows':rows,'limits':'Synthetic SIR+generator-state predicate controls; not typed-source or whole compiler proof. Mutation artifacts separate from immutable primary.'},indent=2)+'\n')
