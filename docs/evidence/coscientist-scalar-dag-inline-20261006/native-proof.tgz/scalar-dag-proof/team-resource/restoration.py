from pathlib import Path
import json,re,os,subprocess
D=Path(__file__).resolve().parent;I=D.parent/'implementation';env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');source=(D/'budget-exact-4/probe.kotoba').read_text();P=D/'restoration';P.mkdir(exist_ok=True)
expr=source.split('(let [a (gn-run ',1)[1].split(') x (r-out',1)[0]
funcs='''
(defn- rr-copy [M :vector-i64 V :vector-i64 base :i64 i :i64 n :i64] :vector-i64 (if (= i n) V (rr-copy M (mem-set V i (vector-at M (+ base i))) base (inc i) n)))
(defn- rr-equal [M :vector-i64 V :vector-i64 base :i64 i :i64 n :i64] :bool (if (= i n) true (and (= (vector-at V i) (vector-at M (+ base i))) (rr-equal M V base (inc i) n))))
(defn- seed-main [] :i64 (let [M INIT sn (* 4 (vector-at M MM-SIR-N)) S (rr-copy M (vector-alloc sn) MM-SIR-BASE 0 sn) a (gn-run M) cn (vector-at a MM-CODE-N) V (rr-copy a (vector-alloc cn) MM-CODE-BASE 0 cn)
 x (r-out "CLOSED-SOURCE" (if (rr-equal a S MM-SIR-BASE 0 sn) 1 0)) u (r-out "CLOSED-USED" (gn-g a di-used))
 o (gn-run-open (-> a (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1)) 1 1)
 y (r-out "OPEN-SOURCE" (if (rr-equal o S MM-SIR-BASE 0 sn) 1 0)) ou (r-out "OPEN-USED" (gn-g o di-used)) os (r-out "OPEN-SITES" (gn-g o di-sites))
 b (gn-run (-> o (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1)))
 z (r-out "AGAIN-SOURCE" (if (rr-equal b S MM-SIR-BASE 0 sn) 1 0)) w (r-out "AGAIN-CODE" (if (and (= cn (vector-at b MM-CODE-N)) (rr-equal b V MM-CODE-BASE 0 cn)) 1 0)) bu (r-out "AGAIN-USED" (gn-g b di-used)) err (r-out "ERR" (vector-at b MM-ERR))] 0))
'''.replace('INIT',expr)
source=source.split('(defn- seed-main []',1)[0]+funcs;(P/'probe.kotoba').write_text(source)
def run(src,name):
 p=D/name;p.mkdir(exist_ok=True);(p/'probe.kotoba').write_text(src)
 for stage,args in [('compile',['compile',str(p/'probe.kotoba'),'--target','aarch64-macos','--output',str(p/'probe.kseed')]),('extract',['extract-native',str(p/'probe.kseed'),'--symbol','main','--output',str(p/'probe.bin')])]:
  q=subprocess.run([str(I/'kexe-loader'),str(I/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(p/(stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,stage,q.stdout[-300:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout)[1]
 q=subprocess.run([str(I/'kexe-loader'),str(p/'probe.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(p/'stdout').write_text(q.stdout);(p/'stderr').write_text(q.stderr);assert q.returncode==0;return q.stdout
out=run(source,'restoration');vals={l.split()[0]:int(l.split()[1]) for l in out.splitlines() if len(l.split())==2};assert vals=={'CLOSED-SOURCE':1,'CLOSED-USED':64,'OPEN-SOURCE':1,'OPEN-USED':0,'OPEN-SITES':0,'AGAIN-SOURCE':1,'AGAIN-CODE':1,'AGAIN-USED':64,'ERR':0},vals
bad=(D/'budget-exact-5/probe.kotoba').read_text();needle='words (- (vector-at m3 MM-CODE-N) code)';assert bad.count(needle)==1;outbad=run(bad.replace(needle,'words (dec (- (vector-at m3 MM-CODE-N) code))'),'undercount-fault');span=next(list(map(int,l.split()[1:])) for l in outbad.splitlines() if l.startswith('SPAN '));assert span[0]==64 and span[2]-span[1]==65 and 'USED 64' in outbad and 'SITES 1' in outbad,span
(D/'restoration-proof.json').write_text(json.dumps({'status':'PASS actual same-M closed/open/closed source+code restoration and actual compiled65word-as64 accounting fault detected','restoration':vals,'accountingFault':{'reported':span[0],'physicalSpan':span[2]-span[1],'wronglyAccepted':True,'detected':True},'limits':'SIR preserved incl original calls; function signature metadata unchanged by source inspection, generated FF-CODE legitimately changes across open mode.'},indent=2)+'\n')
print('PASS same-M and actual physical-word accounting fault')
