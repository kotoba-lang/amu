from pathlib import Path
import json,re,os,subprocess,hashlib
D=Path(__file__).resolve().parent;I=D.parent/'implementation';OLD=Path('/private/tmp/amu-private-length-clones-20261006');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');s=(I/'unity.kotoba').read_text();variants={'omit-save':s.replace('m1 (-> m0 (gn-save 0 t)','m1 (-> m0'),'restore-presave':s.replace('m3 (-> m2 (di-restore 1 0)','m3 (-> m2 (di-restore 0 0)'),'zero-site-budget':s.replace('(< (gn-g M di-sites) 256)','(< (gn-g M di-sites) 0)'),'one-word-budget':s.replace('(<= words 64)','(<= words 1)')};assert len(set([s,*variants.values()]))==5
rows=[]
for kind,source in variants.items():
 P=D/kind;P.mkdir(exist_ok=True);src=P/'compiler.kotoba';src.write_text(source)
 def invoke(bin,off,args,label):
  q=subprocess.run([str(I/'kexe-loader'),str(bin),str(off),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(P/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(kind,label,q.stdout[-500:],q.stderr);return q.stdout
 invoke(I/'seed-4.bin',0,['compile',str(src),'--target','aarch64-macos','--output',str(P/'compiler.kseed')],'compiler-compile');o=invoke(I/'seed-4.bin',0,['extract-native',str(P/'compiler.kseed'),'--symbol','main','--output',str(P/'compiler.bin')],'compiler-extract');off=int(re.search(r':offset (\d+)',o)[1]);observations=[]
 for case in ['abi-permutation','spill-survivors','resource-around-call','fueled-loop-call']:
  invoke(P/'compiler.bin',off,['compile',str(D/(case+'.kotoba')),'--target','aarch64-macos','--output',str(P/(case+'.kseed'))],case+'-compile');o=invoke(P/'compiler.bin',off,['extract-native',str(P/(case+'.kseed')),'--symbol','run','--output',str(P/(case+'.bin'))],case+'-extract');at=int(re.search(r':offset (\d+)',o)[1])
  if kind in ['zero-site-budget','one-word-budget']:
   assert (P/(case+'.bin')).read_bytes()==(D/case/'baseline.bin').read_bytes() and at==int((D/case/'baseline.offset').read_text()),(kind,case,'not exact generic rollback')
  for n in [0,1,2,4]:
   e=dict(os.environ,KEXE_FUEL='1048576',KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run([str(OLD/'full-state-loader'),str(P/(case+'.bin')),str(at),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True);reference=next(r for r in json.loads((D/'baseline.json').read_text())['rows'] if r['case']==case and r['n']==n);obs={'exit':q.returncode,'stdout':q.stdout.strip(),'stderr':q.stderr.strip()};good=all(obs[k]==reference[k] for k in obs);observations.append({'case':case,'n':n,**obs,'equal':good})
 if kind in ['omit-save','restore-presave']:assert any(not r['equal'] for r in observations),(kind,'fault not detected')
 else:assert all(r['equal'] for r in observations)
 rows.append({'variant':kind,'compilerSha256':hashlib.sha256((P/'compiler.bin').read_bytes()).hexdigest(),'detected':kind in ['omit-save','restore-presave'],'safeExactGenericFallback':kind in ['zero-site-budget','one-word-budget'],'observations':observations});print('PASS actual source fault/control',kind,flush=True)
(D/'fault-proof.json').write_text(json.dumps({'status':'PASS actual compiled native caller faults and fullstate byte-exact budget rollback controls','rows':rows},indent=2)+'\n')
