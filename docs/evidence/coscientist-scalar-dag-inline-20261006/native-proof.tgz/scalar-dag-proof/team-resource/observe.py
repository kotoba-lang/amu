from pathlib import Path
import json,subprocess,os,re,hashlib
D=Path(__file__).resolve().parent;I=D.parent/'implementation';env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[]
for case in json.loads((D/'preparation.json').read_text())['fixtures']:
 d=D/case
 q=subprocess.run([str(I/'kexe-loader'),str(I/'observer/seed.bin'),(I/'observer/seed.offset').read_text().strip(),'0','aarch64','35,37,38,39','--','compile',str(D/(case+'.kotoba')),'--target','aarch64-macos','--output',str(d/'observed.kseed')],env=env,capture_output=True,text=True);(d/'observer.log').write_text(q.stdout+q.stderr);assert q.returncode==0,(case,q.stdout[-500:],q.stderr)
 result=[list(map(int,l.split()[1:])) for l in q.stdout.splitlines() if l.startswith('DIRESULT ')]
 q=subprocess.run([str(I/'kexe-loader'),str(I/'observer/seed.bin'),(I/'observer/seed.offset').read_text().strip(),'0','aarch64','35,37,38,39','--','extract-native',str(d/'observed.kseed'),'--symbol','run','--output',str(d/'observed.bin')],env=env,capture_output=True,text=True);(d/'observer-extract.log').write_text(q.stdout+q.stderr);assert q.returncode==0 and (d/'observed.bin').read_bytes()==(d/'candidate.bin').read_bytes();off=int(re.search(r':offset (\d+)',q.stdout)[1]);assert off==int((d/'candidate.offset').read_text());assert any(x[10]==1 for x in result),(case,result)
 for x in result:
  assert x[9]==x[8]-x[5],x
  if x[10]:assert 0<x[9]<=64 and x[11]+x[9]<=4096 and x[12]<256
 rows.append({'case':case,'results':result,'primaryNativeExact':True})
 print('PASS actual readonly primary-exact call admission',case,len(result),flush=True)
(D/'admission-proof.json').write_text(json.dumps({'status':'PASS real candidate caller admissions with independent finalized span and caps','rows':rows},indent=2)+'\n')
