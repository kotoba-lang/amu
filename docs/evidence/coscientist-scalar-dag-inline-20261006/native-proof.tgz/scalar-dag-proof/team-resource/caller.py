from pathlib import Path
import json,os,re,subprocess,hashlib
D=Path(__file__).resolve().parent;I=D.parent/'implementation';OLD=Path('/private/tmp/amu-private-length-clones-20261006');assert hashlib.sha256((I/'seed-4.bin').read_bytes()).hexdigest()=='761856bb455de5d36021e177be8f3a0bbf65772dd66cbdf29c8e114f8cbe3d93'
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[]
for case in json.loads((D/'preparation.json').read_text())['fixtures']:
 d=D/case
 for stage,args in [('compile',['compile',str(D/(case+'.kotoba')),'--target','aarch64-macos','--output',str(d/'candidate.kseed')]),('extract',['extract-native',str(d/'candidate.kseed'),'--symbol','run','--output',str(d/'candidate.bin')])]:
  q=subprocess.run([str(I/'kexe-loader'),str(I/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(stage+'-candidate.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(case,stage,q.stdout[-500:],q.stderr)
  if stage=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1]);(d/'candidate.offset').write_text(str(off)+'\n')
 cases=[]
 for n in [0,1,2,4,8]:
  for fuel in [1,2,3,4,5,8,1048576]:cases.append((n,fuel,{}))
 for key in ['KEXE_VECTORS','KEXE_VECTOR_ITEMS','KEXE_PAIRS','KEXE_STRING_POOL']:
  for cap in [1,2,3,4,5]:cases.append((2,1048576,{key:str(cap)}))
 for n,fuel,caps in cases:
  e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1',**caps);e.pop('KEXE_COMMAND',None);obs={}
  for label in ['baseline','candidate']:
   at=int((d/(label+'.offset')).read_text());q=subprocess.run([str(OLD/'full-state-loader'),str(d/(label+'.bin')),str(at),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'stdout':q.stdout.strip(),'stderr':q.stderr.strip()}
  assert obs['baseline']==obs['candidate'],(case,n,fuel,caps,obs);rows.append({'case':case,'n':n,'fuel':fuel,'caps':caps,**obs})
 print('PASS fresh caller resource/fuel/spills',case,len(cases),flush=True)
(D/'caller-proof.json').write_text(json.dumps({'status':'PASS exact new caller argument permutations/live spills/resources/lowfuel partial-state comparisons','pairs':len(rows),'traps':sum(r['baseline']['exit']!=0 for r in rows),'rows':rows},indent=2)+'\n')
