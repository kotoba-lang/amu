from pathlib import Path
import hashlib,json,os,re,subprocess
D=Path(__file__).resolve().parent;B=Path('/private/tmp/amu-stable-vector-cfg-20261006/implementation');OLD=Path('/private/tmp/amu-private-length-clones-20261006');assert hashlib.sha256((B/'seed-4.bin').read_bytes()).hexdigest()=='eab3a7c26eac2fdf32a3d4736fd8dd1c159b811a6dc6b5ef0f69c1d44b798406'
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[]
for name in json.loads((D/'preparation.json').read_text())['fixtures']:
 d=D/name;d.mkdir(exist_ok=True)
 for label,args in [('compile',['compile',str(D/(name+'.kotoba')),'--target','aarch64-macos','--output',str(d/'baseline.kseed')]),('extract',['extract-native',str(d/'baseline.kseed'),'--symbol','run','--output',str(d/'baseline.bin')])]:
  q=subprocess.run([str(B/'kexe-loader'),str(B/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,label,q.stdout[-700:],q.stderr)
  if label=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1]);(d/'baseline.offset').write_text(str(off)+'\n')
 for n in [0,1,2,4]:
  e=dict(os.environ,KEXE_FUEL='1048576',KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run([str(OLD/'full-state-loader'),str(d/'baseline.bin'),str(off),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True);assert q.returncode==0,(name,n,q.stdout,q.stderr);rows.append({'case':name,'n':n,'exit':q.returncode,'stdout':q.stdout.strip(),'stderr':q.stderr.strip()})
 print('PASS new owned baseline',name,flush=True)
(D/'baseline.json').write_text(json.dumps({'status':'PASS16 fresh baseline observations of new independent caller fixtures; no candidate proof','rows':rows},indent=2)+'\n')
