from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
helper='(defn- mix [a :i64 b :i64 c :i64 d :i64 e :i64] :i64 (+ a (* b 3) (* c 5) (* d 7) (* e 11)))\n'
fixtures={
'abi-permutation':'(defn walk [a :i64 b :i64 c :i64 d :i64 e :i64] :i64 (+ (mix e d c b a) (mix a a c c e) a b c d e))\n(defn run [n :i64] :i64 (walk n (+ n 1) (+ n 2) (+ n 3) (+ n 4)))',
'spill-survivors':'(defn walk [a :i64 b :i64 c :i64 d :i64 e :i64] :i64 (let [f (+ a b) g (+ b c) h (+ c d) i (+ d e) j (+ e a)] (+ (* a 2) (* b 3) (* c 5) (* d 7) (* e 11) (* f 13) (* g 17) (* h 19) (* i 23) (* j 29) (mix e d c b a) (mix j i h g f) f g h i j)))\n(defn run [n :i64] :i64 (walk n (+ n 1) (+ n 2) (+ n 3) (+ n 4)))',
'resource-around-call':'(defn run [n :i64] :i64 (let [v (vector-alloc 4) a (vector-assoc! v 0 n) b (vector-assoc! a 1 (+ n 1)) x (mix (vector-at b 1) n n n n) c (vector-assoc! b 2 x) d (vector-assoc! c 3 (+ x n))] (+ (vector-at d 0) (vector-at d 1) (vector-at d 2) (vector-at d 3))))',
'fueled-loop-call':'(defn- walk [v :vector-i64 n :i64 a :i64 b :i64 c :i64] :i64 (if (= n 0) (+ a b c (vector-at v 0)) (let [x (mix c b a n n) w (vector-assoc! v 0 x)] (walk w (- n 1) b c x))))\n(defn run [n :i64] :i64 (walk [0] n 1 2 3))'
}
for name,body in fixtures.items():
 exports='[run walk]' if name in ['abi-permutation','spill-survivors'] else '[run]'
 (D/(name+'.kotoba')).write_text('(ns resource.'+name+' (:export '+exports+'))\n'+helper+body+'\n')
plan=Path('/Users/junkawasaki/github/wt/amu-seed17/docs/evidence/coscientist-stable-vector-cfg-20261006/next-plan/report.json');census=plan.parent/'scalar-census.json'
(D/'preparation.json').write_text(json.dumps({'status':'PREPARED independent caller resource/ABI controls; not compiled or candidate proof','fixtures':list(fixtures),'scope':['5arg permutations/duplicates','caller live locals and nested temps incl spills','allocation/read/write around pure call','caller lowfuel prefix and loop writes','exported public caller sentinel ABI'],'censusPins':{str(p):sha(p) for p in [plan,census]},'limits':['No new timing or implementation/product changes','Native candidate tests wait for frozen source and precise contract']},indent=2)+'\n')
print('PASS prepared',len(fixtures),'owned typed caller fixtures')
