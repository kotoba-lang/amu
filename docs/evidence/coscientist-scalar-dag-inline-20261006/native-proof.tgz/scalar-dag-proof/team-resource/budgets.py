from pathlib import Path
import re,json,os,subprocess
D=Path(__file__).resolve().parent;I=D.parent/'implementation';C={n:int(v) for n,v in re.findall(r'\(def ([A-Z][A-Z0-9-]*) (-?\d+)\)',(I/'unity.kotoba').read_text())};env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');R=I/'source-snapshot';base='\n'.join((R/p).read_text() for p in ['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba']);code=(I/'41-a64gen-prototype.kotoba').read_text();rows=[]
# Observer is local IO instrumentation only; measure finalized physical CODE counts.
needle='good (and (<= words 64)';assert code.count(needle)==1
code=code.replace(needle,'trace (io-out (string-concat "SPAN " (string-concat (string-from-i64 words) (string-concat " " (string-concat (string-from-i64 code) (string-concat " " (string-concat (string-from-i64 (vector-at m3 MM-CODE-N)) (string-concat " " (string-concat (string-from-i64 (gn-g m3 di-used)) (string-concat " " (string-concat (string-from-i64 (gn-g m3 di-sites)) "\\n")))))))))))\n       '+needle)
for mult,count in [(1,257),(9,110),(10,1),(11,1),(12,1)]:
 body=[('FN',1,2,2),('LGET',0,1)]
 for k in range(mult):body += [('CONST',1,81985529216486895),('BIN',C['BOP-MUL'],0)]
 body += [('LGET',1,2),('BIN',C['BOP-ADD'],0),('RET',0),('END',1)];p2=len(body)+1;body += [('FN',2,1,1)]
 for t in range(6):body += [('LGET',t,1),('CONST',t+1,t+1),('BIN',C['BOP-ADD'],t)]
 for k in range(count):body += [('CONST',6,23),('CONST',7,29),('CALL',1,6,2),('BIN',C['BOP-ADD'],5)]
 for t in range(4,-1,-1):body += [('BIN',C['BOP-ADD'],t)]
 body += [('RET',0),('END',2)]
 writes=[(C['MM-SIR-N'],len(body)+1),(C['MM-FN-N'],3),(C['MM-LABEL-N'],1),(C['MM-CODE-N'],1),(C['MM-FIX-N'],1)]
 for f,np,ns,dp,start in [(1,2,2,2,1),(2,1,1,8,p2)]:
  for fld,v in [('FF-SIR',start),('FF-NPARAMS',np),('FF-NSLOTS',ns),('FF-DEPTH',dp),('FF-RTYPE',C['TY-I64']),('FF-PT0',C['TY-I64']),('FF-KIND',C['FK-PRIV'])]:writes.append((C['MM-FN-BASE']+f*C['MM-FN-W']+C[fld],v))
  if np==2:writes.append((C['MM-FN-BASE']+f*C['MM-FN-W']+C['FF-PT0']+1,C['TY-I64']))
 for j,r in enumerate(body,1):
  vals=[C['OP-'+r[0]],*r[1:]]+[0]*(4-len(r))
  for k,v in enumerate(vals):writes.append((C['MM-SIR-BASE']+j*4+k,v))
 loads=[]
 for g in range(0,len(writes),20):
  ch=writes[g:g+20];loads.append('(defn- r-load%d [M0 :vector-i64] :vector-i64 (let [%s] M%d))'%(g//20,' '.join('M%d (mem-set M%d %d %d)'%(i+1,i,a,v) for i,(a,v) in enumerate(ch)),len(ch)))
 expr='(vector-alloc MM-WORDS)'
 for k in range(len(loads)):expr='(r-load%d %s)'%(k,expr)
 entry='(defn- r-out [s :string v :i64] :i64 (io-out (string-concat s (string-concat " " (string-concat (string-from-i64 v) "\\n")))))\n(defn- seed-main [] :i64 (let [a (gn-run '+expr+') x (r-out "USED" (gn-g a di-used)) y (r-out "SITES" (gn-g a di-sites)) z (r-out "ERR" (vector-at a MM-ERR))] 0))'
 P=D/('budget-%d-%d'%(mult,count));P.mkdir(exist_ok=True);src=P/'probe.kotoba';src.write_text(base+'\n'+code+'\n'+'\n'.join(loads)+'\n'+entry)
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(P/'probe.kseed')]),('extract',['extract-native',str(P/'probe.kseed'),'--symbol','main','--output',str(P/'probe.bin')])]:
  q=subprocess.run([str(I/'kexe-loader'),str(I/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(P/(stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(mult,count,stage,q.stdout[-300:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout)[1]
 q=subprocess.run([str(I/'kexe-loader'),str(P/'probe.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(P/'stdout').write_text(q.stdout);(P/'stderr').write_text(q.stderr);assert q.returncode==0,(mult,count,q.stdout,q.stderr)
 spans=[list(map(int,l.split()[1:])) for l in q.stdout.splitlines() if l.startswith('SPAN ')];totals={l.split()[0]:int(l.split()[1]) for l in q.stdout.splitlines() if l.split()[0] in ['USED','SITES','ERR']};used=sites=0;rejected=0
 for words,start,end,priorused,priorsites in spans:
  assert words==end-start and priorused==used and priorsites==sites
  if words<=64 and used+words<=4096:used+=words;sites+=1
  else:rejected+=1
 assert used==totals['USED'] and sites==totals['SITES'] and used<=4096 and sites<=256 and totals['ERR']==0,(mult,count,totals,spans[-3:])
 rows.append({'multiplications':mult,'sourceCalls':count,'speculatedSites':len(spans),'used':used,'accepted':sites,'rollbackRefusals':rejected,'genericWithoutSpeculation':count-len(spans),'spans':spans});print('PASS actual resource/code cap',mult,count,used,sites,rejected,count-len(spans),flush=True)
assert rows[0]['accepted']==256 and rows[0]['genericWithoutSpeculation']==1
assert rows[1]['rollbackRefusals']>0
assert any(r['rollbackRefusals'] for r in rows[2:])
(D/'budget-proof.json').write_text(json.dumps({'status':'PASS actual compiled scalar SIR generator site/module caps with exact finalized spans/counter rollback','rows':rows},indent=2)+'\n')
