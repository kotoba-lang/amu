from pathlib import Path
import subprocess,json,hashlib,os,re
D=Path(__file__).resolve().parent;I=D.parent/'implementation';B=Path('/private/tmp/amu-stable-vector-cfg-20261006/implementation');L=Path('/private/tmp/amu-private-length-clones-20261006/full-state-loader');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/private/tmp:/Users/junkawasaki/github/wt/amu-seed17',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(I/'seed-4.bin')=='761856bb455de5d36021e177be8f3a0bbf65772dd66cbdf29c8e114f8cbe3d93';assert sha(B/'seed-4.bin')=='eab3a7c26eac2fdf32a3d4736fd8dd1c159b811a6dc6b5ef0f69c1d44b798406'
rows=[];mathematics=[];metadata=[];oracle=json.load(open(D/'source-meaning.json'))['rows']
for case in json.load(open(D/'cases.json'))['cases']:
 name=case['case'];p=D/(name+'.kotoba');d=D/name;d.mkdir(exist_ok=True);images={}
 for label,compiler in [('baseline',B/'seed-4.bin'),('candidate',I/'seed-4.bin')]:
  symbols=['run']+(['scalar'] if name in ['generic-export','indirect'] else [])
  for symbol in symbols:
   out=d/(label+'-'+symbol+'.bin');stages=[]
   if symbol=='run':stages.append(('compile',['compile',str(p),'--target','aarch64-macos','--output',str(d/(label+'.kseed'))]))
   stages.append((symbol+'-extract',['extract-native',str(d/(label+'.kseed')),'--symbol',symbol,'--output',str(out)]))
   for stage,args in stages:
    q=subprocess.run([str(I/'kexe-loader'),str(compiler),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,label,stage,q.stdout[-400:],q.stderr[-400:])
   off=int(re.search(r':offset (\d+)',q.stdout)[1]);(d/(label+'-'+symbol+'.offset')).write_text(str(off)+'\n');images[label,symbol]=(out,off)
  metadata.append({'case':name,'side':label,'nativeSha256':sha(images[label,'run'][0]),'bytes':images[label,'run'][0].stat().st_size})
 for meaning in [r for r in oracle if r['case']==name]:
  args=meaning['inputs']
  for fuel in json.load(open(D/'cases.json'))['fuels']:
   obs={}
   for label in ['baseline','candidate']:
    out,off=images[label,'run'];e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run([str(L),str(out),str(off),'2','aarch64','37',*map(str,args)],env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
   assert obs['baseline']==obs['candidate'],(name,args,fuel,obs)
   if fuel==1048576:
    q=obs['candidate']
    if meaning['expectedTrap']:assert q['exit']!=0 and 'KEXE_TRAP' in q['stderr'],(name,args,meaning,q)
    else:
     result=re.search(r':result (-?\d+)',q['stdout']);assert q['exit']==0 and result and int(result[1])==meaning['expectedResult'],(name,args,meaning,q)
    assert q['stdout'].startswith(meaning['expectedEffectTrace']), (name,args,meaning,q);mathematics.append(meaning)
   rows.append({'case':name,'inputs':args,'fuel':fuel,**obs})
 print('PASS typed DAG',name,flush=True)
(D/'semantic.json').write_text(json.dumps({'status':'PASS exact native fullstate and independent source mathematical controls','nativePairs':len(rows),'sourceMeaningCases':len(mathematics),'rows':rows,'meaning':mathematics,'images':metadata,'baselineSha256':sha(B/'seed-4.bin'),'candidateSha256':sha(I/'seed-4.bin')},indent=2)+'\n')
