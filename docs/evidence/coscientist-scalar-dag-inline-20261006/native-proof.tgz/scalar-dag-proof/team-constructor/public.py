exec((__import__('pathlib').Path(__file__).resolve().parent/'verify.py').read_text().split('rows=[];')[0])
rows=[];mask=(1<<64)-1
signed=lambda x:((x&mask)^(1<<63))-(1<<63)
for name in ['generic-export','indirect']:
 d=D/name
 for values in json.load(open(D/'cases.json'))['inputs']:
  a,b=values;want=signed(a*a+3*b+a-b)
  for fuel in [1,3,1048576]:
   obs={}
   for label in ['baseline','candidate']:
    off=int((d/(label+'-scalar.offset')).read_text());out=d/(label+'-scalar.bin');e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run([str(L),str(out),str(off),'2','aarch64','-',*map(str,values)],env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
   assert obs['baseline']==obs['candidate'];q=obs['candidate'];r=re.search(r':result (-?\d+)',q['stdout']);assert q['exit']==0 and r and int(r[1])==want;left=re.search(r':remaining (-?\d+)',q['stdout']);assert left and int(left[1])==fuel
   rows.append({'case':name,'inputs':values,'fuel':fuel,'expectedResult':want,'fuelConsumed':0,**obs})
(D/'public.json').write_text(json.dumps({'status':'PASS actual generic exported scalar body preserved, independent math and zero callee fuel','pairs':len(rows),'rows':rows},indent=2)+'\n');print('PASS publicgeneric',len(rows))
