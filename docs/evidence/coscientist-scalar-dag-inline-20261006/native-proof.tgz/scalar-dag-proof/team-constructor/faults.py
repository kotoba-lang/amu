exec((__import__('pathlib').Path(__file__).resolve().parent/'verify.py').read_text().split('rows=[];')[0])
F=D/'faults';F.mkdir(exist_ok=True);base=(I/'unity.kotoba').read_text();rows=[]
def build(name,src,compiler,symbol):
 p=F/(name+'.kotoba');p.write_text(src);out=F/(name+'.bin')
 for stage,args in [('compile',['compile',str(p),'--target','aarch64-macos','--output',str(F/(name+'.kseed'))]),('extract',['extract-native',str(F/(name+'.kseed')),'--symbol',symbol,'--output',str(out)])]:
  q=subprocess.run([str(I/'kexe-loader'),str(compiler),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(F/(name+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,stage,q.stdout[-500:],q.stderr[-500:])
 return out,int(re.search(r':offset (\d+)',q.stdout)[1])
ref=next(r for r in json.load(open(D/'semantic.json'))['rows'] if r['case']=='repeated-swap' and r['inputs']==[1,2] and r['fuel']==1048576)['baseline']
for name,old,new in [('wrong-argument-destination','(gn-args t 0 n) (gn-ctx) (di-save 1 0)','(gn-args t 1 n) (gn-ctx) (di-save 1 0)'),('omit-caller-state-restore','(di-restore 1 0) (gn-vclear)','(gn-vclear)'),('wrong-dag-addition','OP-BIN (gn-op-bin M j a b)','OP-BIN (gn-op-bin M j (if (= a BOP-ADD) BOP-SUB a) b)')]:
 assert base.count(old)==1,(name,base.count(old))
 compiler=F/(name+'-compiler.bin')
 if not compiler.exists():
  compiler,coff=build(name+'-compiler',base.replace(old,new,1),B/'seed-4.bin','main');assert coff==0
 try:
  target,toff=build(name+'-target',(D/'repeated-swap.kotoba').read_text(),compiler,'run')
 except AssertionError as failure:
  rows.append({'name':name,'detected':True,'detection':'actual native mutant compiler refused genuine baseline-accepted target','failure':str(failure),'compilerSha256':sha(compiler)});print('PASS actual source fault rejection',name,flush=True);continue
 e=dict(os.environ,KEXE_FUEL='1048576',KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
 q=subprocess.run([str(L),str(target),str(toff),'2','aarch64','-','1','2'],env=e,capture_output=True,text=True)
 actual={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};assert actual!=ref,(name,actual)
 rows.append({'name':name,'detected':True,'detection':'actual native target result/state differs','baseline':ref,'mutant':actual,'compilerSha256':sha(compiler),'targetSha256':sha(target)});print('PASS actual source fault',name,flush=True)
(D/'faults.json').write_text(json.dumps({'status':'PASS actual native compiler-source fault calibration','rows':rows},indent=2)+'\n')
