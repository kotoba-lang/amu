from pathlib import Path
import json,re
D=Path(__file__).resolve().parent;I=D.parent/'implementation';C={k:int(v) for k,v in re.findall(r'\(def ([A-Z][A-Z0-9-]*) (-?\d+)\)',(I/'unity.kotoba').read_text())};O=lambda x:C['OP-'+x];allowed={C[k] for k in ['BOP-ADD','BOP-SUB','BOP-MUL','BOP-AND','BOP-OR','BOP-XOR','BOP-SHL','BOP-USHR','BOP-SSHR']};rows=[]
def body(s,f,np):
 p=next(i for i,q in s.items() if q[0]==O('FN') and q[1]==f);ns=s[p][3];local={i:('param',i) for i in range(1,np+1)};values={};uses=[];reason=None
 for j in range(p+1,min(p+33,max(s)+1)):
  op,a,b,c=s[j]
  if op==O('LABEL') and j==p+1 and 0<a<C['MM-LABEL-CAP'] and b==c==0:continue
  if op==O('CONST') and 0<=a<=len(values) and c==0:values={k:v for k,v in values.items() if k<a};values[a]=('const',b);continue
  if op==O('LGET') and 0<=a<=len(values) and b in local and c==0:values={k:v for k,v in values.items() if k<a};values[a]=local[b];uses.append((j,b));continue
  if op==O('LSET') and 0<a<=ns and b in values and c==0:local[a]=values[b];continue
  if op in [O('BIN'),O('CMP')] and b in values and b+1 in values and c==0 and (op==O('BIN') and a in allowed or op==O('CMP') and C['CC-EQ']<=a<=C['CC-GE']):
   expr=(op,a,values[b],values[b+1]);values={k:v for k,v in values.items() if k<b};values[b]=expr;continue
  if op==O('UN') and b in values and c==0 and a in [C['UOP-NOT'],C['UOP-BITNOT']]:
   expr=(op,a,values[b]);values={k:v for k,v in values.items() if k<b};values[b]=expr;continue
  if op==O('RET') and a in values and b==c==0 and s.get(j+1)==(O('END'),f,0,0):return {'acceptedDefinition':True,'start':p,'end':j+1,'nodesVisited':j-p,'resultExpression':values[a],'formalUseSites':uses}
  return {'acceptedDefinition':False,'reason':{'sir':j,'instruction':s[j]}}
 return {'acceptedDefinition':False,'reason':'body32cap'}
for r in json.load(open(D/'observations.json'))['rows']:
 ev=r['events'];s={q[0]:tuple(q[1:]) for q in ev['SIR']};case=r['case'];certs=[];pre={q[0]:q for q in ev['DIPRE']}
 for q in ev['DIRESULT']:
  site,f,t,np,end,start,bodyfirst,bodyafter,finish,words,yes,used,sites=q;b=body(s,f,np);assert b['acceptedDefinition'] and b['end']==end,(case,q,b);p=pre[site];assert p[7]>0 and p[8]>=np and s[site]==(O('CALL'),f,t,np);assert s[site+1][0] not in [O('RET'),O('RES2')];assert t>=0 and t+np<=p[10] and t+np<=p[9];assert words==finish-start and yes==int(words<=64 and used+words<=4096 and sites<256);certs.append({'site':site,'callee':f,'actualAccepted':bool(yes),'fullSpanWords':words,'priorUsed':used,'priorSites':sites,'definitionCertificate':b})
 positive=case not in ['branch-refuse','div-refuse','fuel-refuse','effect-refuse'];assert bool(certs)==positive,(case,certs)
 if case=='site-budget':assert len(certs)==256 and all(x['actualAccepted'] for x in certs) and certs[-1]['priorSites']==255
 rows.append({'case':case,'independentDefinitionAndCallerCertificates':certs,'expectedNearMatchCalleeRefusal':not positive})
(D/'admission-oracle.json').write_text(json.dumps({'status':'PASS independent symbolic stack/local expression definitions vs native call admission and budgets','rows':rows,'notNativeEmitterImplementation':True,'limits':'Actual first256sites observed; generic fallbacks beyond256 must additionally preserve full native result/output. Types are genuine checked source; raw malformed predicate controls separately owned.'},indent=2)+'\n');print('PASS independent ownDAG admission',sum(len(r['independentDefinitionAndCallerCertificates']) for r in rows))
