exec((__import__('pathlib').Path(__file__).resolve().parent/'verify.py').read_text().split('rows=[];')[0])
import shutil,runpy
m=runpy.run_path(str(I/'machine-audit.py'),run_name='audit_library');rows=[]
for c in json.load(open(D/'cases.json'))['cases']:
 name=c['case'];p=D/'physical'/name;p.mkdir(parents=True,exist_ok=True);a=p/'baseline';b=p/'candidate';a.mkdir(exist_ok=True);b.mkdir(exist_ok=True)
 for stage,args in [('compile',['compile',str(D/(name+'.kotoba')),'--target','aarch64-macos','--output',str(a/'target.kseed')]),('extract',['extract-native',str(a/'target.kseed'),'--symbol','run','--output',str(a/'native.bin')])]:
  q=subprocess.run([str(I/'kexe-loader'),str(B/'observer/seed.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(a/(stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,stage,q.stderr)
 assert (a/'native.bin').read_bytes()==(D/name/'baseline-run.bin').read_bytes()
 shutil.copy2(D/name/'observer.bin',b/'native.bin');shutil.copy2(D/name/'observer-compile.log',b/'compile.log')
 av=m['load'](a);bv=m['load'](b);v=m['audit'](av,bv);rows.append({'case':name,**v});print('PASS typed physical',name,v['sites'],flush=True)
(D/'physical.json').write_text(json.dumps({'status':'PASS exact native typed-control expansion and retained machine projection','rows':rows,'method':'Shared machine projection verifier executed independently on separately compiled own15 typed controls; independent source DAG oracle and actual mutants are separate.'},indent=2)+'\n')
