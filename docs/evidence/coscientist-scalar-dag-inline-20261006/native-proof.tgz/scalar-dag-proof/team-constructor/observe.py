exec((__import__('pathlib').Path(__file__).resolve().parent/'verify.py').read_text().split('rows=[];')[0])
rows=[]
for case in json.load(open(D/'cases.json'))['cases']:
 name=case['case'];d=D/name
 for stage,args in [('compile',['compile',str(D/(name+'.kotoba')),'--target','aarch64-macos','--output',str(d/'observer.kseed')]),('extract',['extract-native',str(d/'observer.kseed'),'--symbol','run','--output',str(d/'observer.bin')])]:
  q=subprocess.run([str(I/'kexe-loader'),str(I/'observer/seed.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/('observer-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,stage,q.stderr)
 off=int(re.search(r':offset (\d+)',q.stdout)[1]);assert (d/'observer.bin').read_bytes()==(d/'candidate-run.bin').read_bytes() and off==int((d/'candidate-run.offset').read_text())
 log=(d/'observer-compile.log').read_text();events={k:[list(map(int,l.split()[1:])) for l in log.splitlines() if l.startswith(k+' ')] for k in ['DIPRE','DIARGS','DIBODY','DIRESULT','SIR','FN','CACHE','REG','FIX','EMIT']};rows.append({'case':name,'observerBytesAndOffsetExact':True,'events':events});print('PASS own observer',name,len(events['DIRESULT']),flush=True)
(D/'observations.json').write_text(json.dumps({'status':'PASS actual observer byte exact own15typedcontrols','rows':rows},indent=2)+'\n')
