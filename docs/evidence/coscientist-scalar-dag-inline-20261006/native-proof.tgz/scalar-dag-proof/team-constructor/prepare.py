from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent
cases={
'repeated-swap':('(defn- scalar [a :i64 b :i64] :i64 (+ (* a a) (* b 3) (- a b)))','(scalar y x)','i64','eligible', ['x','y']),
'shared-dag':('(defn- scalar [a :i64 b :i64] :i64 (let [p (+ a b) q (* p p) r (bit-xor q p)] (+ r q p)))','(scalar x y)','i64','eligible',['x','y']),
'live-caller':('(defn- scalar [a :i64 b :i64] :i64 (+ (* a a) (* b 3) (- a b)))','(let [a (+ x 1) b (+ x 2) c (+ x 3) d (+ y 4) e (+ y 5) f (+ y 6) z (scalar b a)] (+ a b c d e f z))','i64','eligible-or-liveness-fallback',['x','y']),
'shifts':('(defn- scalar [a :i64 b :i64] :i64 (bit-xor (i64-shift-left a b) (u64-shift-right a b)))','(scalar x y)','i64','eligible',['x','y']),
'bool':('(defn- scalar [a :bool b :bool] :bool (= (not a) b))','(scalar (< x y) (= x y))','bool','eligible',['x','y']),
'generic-export':('(defn scalar [a :i64 b :i64] :i64 (+ (* a a) (* b 3) (- a b)))','(scalar y x)','i64','generic-body-preserved',['x','y']),
'indirect':('(defn scalar [a :i64 b :i64] :i64 (+ (* a a) (* b 3) (- a b)))','(let [f (fn [a b] (scalar a b))] (+ (scalar x y) (f y x)))','i64','addressable-body-preserved',['x','y']),
'branch-refuse':('(defn- scalar [a :i64 b :i64] :i64 (if (< a b) (+ (* a a) b) (- (* b b) a)))','(scalar x y)','i64','callee-refuse',['x','y']),
'div-refuse':('(defn- scalar [a :i64 b :i64] :i64 (+ (quot a b) (- a b)))','(scalar x y)','i64','callee-refuse',['x','y']),
'fuel-refuse':('(defn- scalar [a :i64 b :i64] :i64 (loop [i 0 s b] (if (>= i a) s (recur (+ i 1) (+ s i)))))','(scalar (bit-and x 3) y)','i64','callee-refuse',['x','y']),
'effect-refuse':('(defn- scalar [a :i64 b :i64] :i64 (do (typed-cap-call :io/write :string :string "E") (+ (* a a) b)))','(scalar x y)','i64','callee-refuse',['x','y']),
'argument-effects':('(defn- scalar [a :i64 b :i64] :i64 (+ (* a a) (* b 3) (- a b)))','(scalar (do (typed-cap-call :io/write :string :string "A") x) (do (typed-cap-call :io/write :string :string "B") y))','i64','argument-order-preserved',['x','y']),
'argument-trap':('(defn- scalar [a :i64 b :i64] :i64 (+ (* a a) (* b 3) (- a b)))','(scalar (quot x y) x)','i64','argument-trap-order-preserved',['x','y'])}
rows=[]
for name,(helper,body,rt,kind,args) in cases.items():
 export='[run scalar]' if name in ['generic-export','indirect'] else '[run]'
 if name in ['repeated-swap','shared-dag','shifts','generic-export','argument-effects','argument-trap','branch-refuse','div-refuse','fuel-refuse','effect-refuse']:
  body='(let [r '+body+'] (+ r x))'
 if name=='bool':body='(not '+body+')'
 source=f'(ns dag.{name} (:export {export}))\n{helper}\n(defn run [x :i64 y :i64] :{rt} {body})\n';p=D/(name+'.kotoba');p.write_text(source);rows.append({'case':name,'contractRole':kind,'resultType':rt,'sourceSha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(D/'cases.json').write_text(json.dumps({'status':'DESIGN typed controls unexecuted','cases':rows,'inputs':[[0,0],[1,2],[-1,3],[7,-9],[9223372036854775807,1],[-9223372036854775808,-1],[-9223372036854775808,63],[17,64],[17,65],[17,-1]],'nativeBaseline':'eab3a7c26eac2fdf32a3d4736fd8dd1c159b811a6dc6b5ef0f69c1d44b798406','fuels':[1,2,3,7,1048576]},indent=2)+'\n');print('PREPARED13typedcontrols; no native execution')
