"""Independent small source interpreter; no SIR/native compiler implementation."""
from pathlib import Path
import re,json,hashlib
D=Path(__file__).resolve().parent;MASK=(1<<64)-1;MIN=-(1<<63)
def signed(x):return ((int(x)&MASK)^(1<<63))-(1<<63)
class Trap(Exception):pass
class Again(Exception):
 def __init__(self,values):self.values=values
def parse(s):
 s=re.sub(r';[^\n]*','',s);tokens=re.findall(r'"(?:\\.|[^"\\])*"|[()\[\]]|[^\s()\[\]]+',s);at=0
 def read():
  nonlocal at
  t=tokens[at];at+=1
  if t in ['(','[']:
   close=')' if t=='(' else ']';a=[]
   while tokens[at]!=close:a.append(read())
   at+=1;return a
  return int(t) if re.fullmatch(r'-?\d+',t) else t
 result=[]
 while at<len(tokens):result.append(read())
 return result
class Program:
 def __init__(self,path):
  self.functions={};self.trace=[]
  for a in parse(path.read_text()):
   if a[0] in ['defn','defn-']:self.functions[a[1]]=([a[2][i] for i in range(0,len(a[2]),2)],a[4])
 def call(self,name,args):
  formals,body=self.functions[name];return self.eval(body,dict(zip(formals,args)))
 def eval(self,e,env):
  if isinstance(e,int):return signed(e)
  if isinstance(e,str):
   if e in env:return env[e]
   if e in self.functions:return ('function',e)
   if e=='true':return 1
   if e=='false':return 0
   if e.startswith('"'):return json.loads(e)
   raise ValueError(e)
  op=e[0]
  if op=='fn':return ('closure',e[1],e[2],dict(env))
  if op=='let':
   local=dict(env)
   for k in range(0,len(e[1]),2):local[e[1][k]]=self.eval(e[1][k+1],local)
   return self.eval(e[2],local)
  if op=='loop':
   local=dict(env);names=e[1][::2]
   for k,name in enumerate(names):local[name]=self.eval(e[1][2*k+1],local)
   for _ in range(16):
    try:return self.eval(e[2],local)
    except Again as a:local.update(dict(zip(names,a.values)))
   raise ValueError('source loop finite bound')
  if op=='recur':raise Again([self.eval(v,env) for v in e[1:]])
  if op=='if':return self.eval(e[2] if self.eval(e[1],env) else e[3],env)
  if op=='do':
   value=0
   for v in e[1:]:value=self.eval(v,env)
   return value
  if op=='typed-cap-call':
   assert e[1:4]==[':io/write',':string',':string'];s=self.eval(e[4],env);self.trace.append(s);return s
  args=[self.eval(v,env) for v in e[1:]]
  if op in self.functions:return self.call(op,args)
  if op in env and isinstance(env[op],tuple):
   value=env[op]
   if value[0]=='function':return self.call(value[1],args)
   captured=dict(value[3]);captured.update(dict(zip(value[1],args)));return self.eval(value[2],captured)
  if op=='+':return signed(sum(args))
  if op=='-':return signed(-args[0] if len(args)==1 else args[0]-sum(args[1:]))
  if op=='*':
   value=1
   for a in args:value=signed(value*a)
   return value
  if op=='quot':
   a,b=args
   if b==0 or (a==MIN and b==-1):raise Trap()
   return signed((abs(a)//abs(b))*(-1 if (a<0)!=(b<0) else 1))
  if op=='bit-xor':return signed(args[0]^args[1])
  if op=='bit-and':return signed(args[0]&args[1])
  if op=='bit-or':return signed(args[0]|args[1])
  if op=='bit-not':return signed(~args[0])
  if op=='not':return int(not args[0])
  if op=='=':return int(args[0]==args[1])
  if op=='<':return int(args[0]<args[1])
  if op=='>=':return int(args[0]>=args[1])
  if op=='i64-shift-left':return signed(args[0]<<(args[1]&63))
  if op=='u64-shift-right':return signed((args[0]&MASK)>>(args[1]&63))
  raise ValueError(op)
inputs=json.loads((D/'cases.json').read_text())['inputs'];rows=[]
for p in sorted(D.glob('*.kotoba')):
 for values in inputs:
  prog=Program(p)
  try:value=prog.call('run',values);trap=False
  except Trap:value=None;trap=True
  rows.append({'case':p.stem,'inputs':values,'expectedResult':value,'expectedTrap':trap,'expectedEffectTrace':''.join(prog.trace),'sourceSha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(D/'source-meaning.json').write_text(json.dumps({'status':'PASS independent unexecuted-source mathematical evaluation','rows':rows,'nativeExecutions':0,'modular64':True,'simultaneousFunctionArgumentCapture':True,'limits':'Finite source syntax subset and input table; fuel/physical admission checked independently later'},indent=2)+'\n');print('PASS source mathematics',len(rows),'no native execution')
