from pathlib import Path
import json,re,struct,sys,importlib.util,runpy,copy,hashlib
D=Path(__file__).resolve().parent;W=D.parent;I=W/'implementation';B=Path('/private/tmp/amu-stable-vector-cfg-20261006/root-proof');sys.path.insert(0,str(W/'root-proof'))
sp=importlib.util.spec_from_file_location('fx',W/'root-proof/permanent-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
Q=runpy.run_path(str(I/'machine-audit.py'));branch=Q['branch'];fnids,labs,lits,SIR,fnrecs=m.layout_tables();sir={j+1:tuple(q) for j,q in enumerate(SIR)}
def load(label):
 p=D/label;text=(p/'compile.log').read_text();out=(p/'observer.stdout').read_text();d={'sir':sir,'fn':{},'events':[],'fix':[],'raw':(p/'native.bin').read_bytes(),'di':{},'pre':{},'args':{}};owner=None
 for l in text.splitlines():
  q=l.split()
  if not q:continue
  tag=q[0]
  if tag=='FN':d['fn'][int(q[1])]=tuple(map(int,q[2:]))
  if tag=='EMIT':d['events'].append(tuple(map(int,q[1:])))
  if tag=='FIX':d['fix'].append(tuple(map(int,q[1:])))
  if tag=='DIPRE':v=tuple(map(int,q[1:]));owner=v[0];d['pre'][owner]=v;d['args'][owner]=[]
  if tag=='DIARGS':d['args'][owner].append(tuple(map(int,q[1:])))
  if tag=='DIRESULT':v=tuple(map(int,q[1:]));d['di'][v[0]]=v
 d['n']=int(re.search(r'gen err 0 words (\d+)',out)[1])+1;d['words']=[z[0] for z in struct.iter_unpack('<I',d['raw'][:4*(d['n']-1)])]
 # Called generic callee is frameless straightline. Locate its final RET by
 # original source RET/END and actual complete function bytes, never omit words.
 callees={v[1] for v in load_calls()}
 for f in callees:
  start=d['fn'][f][-1];nxt=min([v[-1] for v in d['fn'].values() if v[-1]>start]+[d['n']]);tail=d['words'][nxt-3:nxt-1]
  assert tail==[0xd65f03c0,0xd4200020],('callee explicit return+END',f,tail)
  pos=[j for j,v in sir.items() if d['fn'][f][0]<j and v[0]==19 and j<next(k for k in range(d['fn'][f][0]+1,len(sir)+1) if sir[k][0]==2)]
  assert len(pos)==1
  d['events'].append((pos[0],0,nxt-2,nxt-1))
 d['events'].sort();return d

def load_calls():
 return [tuple(map(int,l.split()[1:])) for l in (D/'candidate/compile.log').read_text().splitlines() if l.startswith('DIRESULT ')]

def norm(d,sites,candidate):
 repl={r['firstBody'] if candidate else r['oldCallWord']:(i,r) for i,r in sites.items()};lit={}
 for ix,at,k,t,u in d['fix']:
  if k==5:lit[at]=(t,0);lit[at+1]=(t,1)
 stream=[];pos={};edges=[];interior=set();removed=set();j=1
 while j<d['n']:
  if j in repl:
   si,r=repl[j];end=r['afterBody'] if candidate else j+1
   for k in range(j,end):pos[k]=len(stream)
   stream.append(('INLINE',si,r['fn']));interior.update(range(j+1,end))
   if not candidate:removed.add(j)
   j=end;continue
  pos[j]=len(stream);z=d['words'][j-1];q=branch(z)
  if q:stream.append(('BR',q[0]));edges.append((len(stream)-1,j+q[1]))
  elif j in lit:stream.append(('LIT',lit[j],z&~0x1fffe0))
  else:stream.append(('WORD',z))
  j+=1
 pos[d['n']]=len(stream);assert len(pos)==d['n']
 for k,t in edges:assert t not in interior,('externalbranch enters expansion',t)
 return stream,pos,edges,removed

def audit(a,b):
 sites=Q['verify_expansions'](a,b);aa,pa,ea,removed=norm(a,sites,False);bb,pb,eb,_=norm(b,sites,True)
 assert aa==bb,next(((j,x,y) for j,(x,y) in enumerate(zip(aa,bb)) if x!=y),(len(aa),len(bb)))
 assert len(ea)==len(eb)
 for x,y in zip(ea,eb):assert x[0]==y[0] and pa[x[1]]==pb[y[1]],('allbranchprojection',x,y)
 for f,v in a['fn'].items():assert pa[v[-1]]==pb[b['fn'][f][-1]]
 for x,y in zip(a['events'],b['events']):assert pa[x[2]]==pb[y[2]] and pa[x[3]]==pb[y[3]]
 af=[x for x in a['fix'] if x[1] not in removed];assert len(af)==len(b['fix']);private=lit=0
 ap=((a['n']-1)*4+7)//8*8;bp=((b['n']-1)*4+7)//8*8
 for (ix,at,k,t,u),(iy,bt,l,s,v) in zip(af,b['fix']):
  assert (k,t,u)==(l,s,v) and pa[at]==pb[bt]
  if k==5:
   old=((a['words'][at-1]>>5)&65535)|(((a['words'][at]>>5)&65535)<<16);new=((b['words'][bt-1]>>5)&65535)|(((b['words'][bt]>>5)&65535)<<16);assert old-ap==new-bp and pa[at+1]==pb[bt+1];lit+=2
  if u:
   assert k==4 and u==1;oe=a['fn'][t][-1];ne=b['fn'][t][-1];assert a['words'][oe-1]==b['words'][ne-1]==0xd2800005;assert at+branch(a['words'][at-1])[1]==oe+1 and bt+branch(b['words'][bt-1])[1]==ne+1;private+=1
 assert a['raw'][ap:]==b['raw'][bp:] and set(a['raw'][(a['n']-1)*4:ap])<={0} and set(b['raw'][(b['n']-1)*4:bp])<={0}
 assert b['n']-a['n']==sum(r['bodyWords']-1 for r in sites.values())==7
 return {'sites':sites,'codeWords':[a['n']-1,b['n']-1],'addedCodeWords':7,'poolStart':[ap,bp],'poolDeltaBytes':bp-ap,'remainingTokens':len(aa),'remainingEdges':len(ea),'literalWords':lit,'privateAux1':private,'all593FunctionOffsetsProjected':True,'allPoolBytesExactRelative':True}

if __name__=='__main__':
 a=load('baseline');b=load('candidate');r=audit(a,b);details=[]
 for i,q in r['sites'].items():
  f=max((f for f,v in b['fn'].items() if v[0]<=i),key=lambda f:b['fn'][f][0]);name=m.FIX[f-1][0];callee=m.FIX[q['fn']-1][0];obs=[x for x in m.RUNS if x[0]==name]
  details.append({'callerFN':f,'fixture':name,'calleeFN':q['fn'],'callee':callee,'sir':i,**q,'unchangedHandRuns':len(obs),'handExpectations':obs})
 controls=[]
 for title,mut in [('expanded arithmetic',lambda d:d['words'].__setitem__(next(iter(r['sites'].values()))['firstBody']-1,0)),('remaining instruction',lambda d:d['words'].__setitem__(0,d['words'][0]^1)),('fullspan receipt',lambda d:d['di'].__setitem__(next(iter(d['di'])),tuple(v+1 if k==9 else v for k,v in enumerate(next(iter(d['di'].values()))))))]:
  d=copy.deepcopy(b);mut(d)
  try:audit(a,d)
  except (AssertionError,KeyError,IndexError) as e:controls.append({'mutation':title,'status':'DETECTED','diagnostic':str(e)[:300]})
  else:raise AssertionError('accepted mutant '+title)
 # Independent branch/literal/pool/function-metadata corruption calibration.
 for title,mut in [
  ('projected branch target',lambda d:d['words'].__setitem__(next(at for ix,at,k,t,u in d['fix'] if k==4)-1,d['words'][next(at for ix,at,k,t,u in d['fix'] if k==4)-1]^1)),
  ('literal pointer',lambda d:d['words'].__setitem__(next(at for ix,at,k,t,u in d['fix'] if k==5)-1,d['words'][next(at for ix,at,k,t,u in d['fix'] if k==5)-1]^32)),
  ('literal pool byte',lambda d:d.__setitem__('raw',d['raw'][:-1]+bytes([d['raw'][-1]^1]))),
  ('function metadata frame',lambda d:d['fn'].__setitem__(223,tuple(v+16 if k==1 else v for k,v in enumerate(d['fn'][223]))))]:
  d=copy.deepcopy(b);mut(d)
  try:audit(a,d)
  except (AssertionError,KeyError,IndexError) as e:controls.append({'mutation':title,'status':'DETECTED','diagnostic':str(e)[:300]})
  else:raise AssertionError('accepted mutant '+title)
 golden=Path('/Users/junkawasaki/github/wt/amu-seed17/seed/tests/unit/41-a64gen.expected')
 baseline=(B/'adoption-permanent-test.stdout').read_text()+'exit=0\n'
 assert golden.read_text()==baseline
 goldenEvidence={'originalGoldenEqualsBaselineStdoutPlusExit0':True,'goldenSha256':hashlib.sha256(golden.read_bytes()).hexdigest(),'candidateStillDiffers':golden.read_text()!=(W/'root-proof/adoption-permanent-test.stdout').read_text()+'exit=0\n'}
 # Both retained test and real stdout must reproduce the same first code image
 # with their established test-only trailing zero padding contract.
 parity=[]
 for label,root in [('baseline',B),('candidate',W/'root-proof')]:
  test,tfn=m.blob_from((root/'adoption-permanent-test.stdout').read_text());real,rfn=m.blob_from((root/'adoption-permanent-real.stdout').read_text());assert tfn==rfn and test[:len(real)]==real and not any(test[len(real):]) and len(test)-len(real)<=7
  parity.append({'label':label,'testBytes':len(test),'realBytes':len(real),'testOnlyZeroPadding':len(test)-len(real),'testRealOffsetsExact':True})
 (D/'report.json').write_text(json.dumps({'status':'PASS independently justified complete retained fixture machine byte delta; original golden still differs and untouched','fixtures':593,'retainedGolden':goldenEvidence,'changedFixtures':details,'projection':r,'controls':controls,'retainedTestRealParity':parity,'handMeaning':'Only closed pure scalar mw_unknown body x+1 is expanded; actual native body exactly original instructions without RET; original surroundingfuel/effects/frame/state and all other words/edges/fixups/literal pool preserved. Existing hand expectations/runs unchanged, semantic proof belongs to root25658observations.','notGoldenUpdate':True,'notTiming':True,'assumptions':['Original hand-written fixture generator + loaded typed metadata exact; independently supplied SIR arrays from layout_tables.','Read-only observer copies filter diagnostic output only, preserve all CALL/FN/FIX/admission events and produce exact root blobs/offsets.','Hardware/code semantics and runtime/source contracts as independently audited.'],'harnessCorrections':['Initial import lacked generator helper path; fixed excluded path.','65536 and4M vector diagnostic arenas failed full SIR/EMIT print allocation; retained initial evidence. Filtered owned observers report call/function/fixup/admission only; complete raw-code projection unchanged.']},indent=2)+'\n');print('PASS exact retainedfixture delta',len(details),'sites',r['addedCodeWords'],'words',[(x['callerFN'],x['fixture']) for x in details])
