from pathlib import Path
import json,importlib.util,subprocess,os,re,hashlib,sys
D=Path(__file__).resolve().parent;W=D.parent;I=W/'implementation';R=Path('/Users/junkawasaki/github/wt/amu-seed17');B=Path('/private/tmp/amu-stable-vector-cfg-20261006');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(W/'root-proof'))
sp=importlib.util.spec_from_file_location('fx',W/'root-proof/permanent-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
# Exact same hand-written fixture generator; add only read-only compiler observer.
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[]
for label,base,obs in [('baseline',B/'root-proof',B/'implementation/observer/41.kotoba'),('candidate',W/'root-proof',I/'observer/41.kotoba')]:
 d=D/label;d.mkdir(exist_ok=True)
 g=obs.read_text()
 # Owned diagnostic filtering: retain every CALL event/FN/fixup/admission,
 # obtain exact SIR independently from original generator arrays.
 def disable_io(g,prefix):
  needle='(io-out (string-concat "'+prefix+' '
  while needle in g:
   a=g.index(needle);depth=0;quoted=False;escape=False
   for b in range(a,len(g)):
    c=g[b]
    if quoted:
     if escape:escape=False
     elif c=='\\':escape=True
     elif c=='"':quoted=False
    elif c=='"':quoted=True
    elif c=='(':depth+=1
    elif c==')':
     depth-=1
     if depth==0:break
   g=g[:a]+'0'+g[b+1:]
  return g
 for prefix in ['SIR','CACHE','BASE','TAILWIT','SCQUERY','SCRESULT','SLADMIT']:g=disable_io(g,prefix)
 needle='printed (io-out (string-concat "EMIT '
 at=g.index(needle);a=at+len('printed ');depth=0;quoted=False;escape=False
 for b in range(a,len(g)):
  c=g[b]
  if quoted:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':quoted=False
  elif c=='"':quoted=True
  elif c=='(':depth+=1
  elif c==')':
   depth-=1
   if depth==0:break
 g=g[:a]+'(if (= (gn-op M i) OP-CALL) '+g[a:b+1]+' 0)'+g[b+1:]
 (d/'observer-41.kotoba').write_text(g)
 src='\n'.join((R/p).read_text() for p in ['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'])+'\n'+g+'\n'+(I/'42-layout-prototype.kotoba').read_text()+'\n'+m.kotoba(True)
 (d/'source.kotoba').write_text(src)
 for step,args in [('compile',['compile',str(d/'source.kotoba'),'--target','aarch64-macos','--output',str(d/'image.kseed')]),('extract',['extract-native',str(d/'image.kseed'),'--symbol','main','--output',str(d/'observer.bin')])]:
  q=subprocess.run([str(I/'kexe-loader'),str(I/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(step+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,step,q.stdout[-1500:],q.stderr[-1000:])
  if step=='extract':off=re.search(r':offset (\d+)',q.stdout)[1];(d/'observer.offset').write_text(off+'\n')
 q=subprocess.run([str(I/'kexe-loader'),str(d/'observer.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(d/'observer.stdout').write_text(q.stdout);(d/'observer.stderr').write_text(q.stderr);assert q.returncode==0,(label,q.returncode,q.stderr[-500:])
 blob,fn=m.blob_from(q.stdout);orig,ofn=m.blob_from((base/'adoption-permanent-real.stdout').read_text());assert blob==orig and fn==ofn
 # Observer source emits several diagnostic gn-run calls later; first is real fixture artifact.
 prefix=q.stdout.split('gen err ',1)[0];(d/'compile.log').write_text(prefix);(d/'native.bin').write_bytes(blob)
 rows.append({'label':label,'generatedBlobSha256':sha(d/'native.bin'),'bytes':len(blob),'exactOriginalRootBlob':True,'functionOffsetsExact':True,'sourceSha256':sha(d/'source.kotoba')});print('PASS exact original fixture observer',rows[-1],flush=True)
(D/'observer-parity.json').write_text(json.dumps({'status':'PASS exact original593 unit fixture blobs +function offsets from read-only native observers','rows':rows,'notTiming':True,'expectationsUnchanged':True},indent=2)+'\n')
