; benchmark generated from python API
(set-info :status unknown)
(declare-fun r () (Array Int (_ BitVec 64)))
(assert
 (let ((?x219 (select r 1)))
 (let ((?x217 (select r 0)))
 (and (distinct ?x217 ?x219) true))))
(assert
 (let ((?x217 (select r 0)))
(let ((?x219 (select r 1)))
(let ((?x221 (store r 0 ?x219)))
(let ((?x203 (store ?x221 1 (select ?x221 0))))
(and (distinct (select ?x203 1) ?x217) true))))))
(check-sat)
