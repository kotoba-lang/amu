from pathlib import Path
import hashlib, json, subprocess

T = Path(__file__).resolve().parent
W = T.parent / 'implementation'
B = Path('/private/tmp/amu-stable-vector-cfg-20261006/root-proof')
runner = Path('/private/tmp/amu-embench-compare-20261004/runner')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
base = json.loads((B / 'ports-semantic.json').read_text())
rows = []
for e in json.loads((W / 'ports-build.json').read_text())['entries']:
    old = next(x for x in base['entries'] if x['workload'] == e['workload'])
    native = W / 'ports' / e['workload'] / 'native.bin'
    assert sha(native) == e['nativeSha256']
    runs = []
    d = T / 'ports-semantic-raw' / e['workload']
    d.mkdir(parents=True, exist_ok=True)
    for x in old['runs']:
        q = subprocess.run([str(runner), 'raw', str(native), str(e['offset']), 'aarch64',
                            str(x['n']), '1', '0', '16777216'], capture_output=True, text=True)
        (d / ('n-' + str(x['n']) + '.stdout')).write_text(q.stdout)
        (d / ('n-' + str(x['n']) + '.stderr')).write_text(q.stderr)
        assert q.returncode == 0, (e['workload'], q.stderr)
        v = json.loads(q.stdout)
        assert v['result'] == x['result'] and v['contextFuelConsumed'] == x['fuelConsumed'], (e['workload'], x, v)
        runs.append({'n': x['n'], 'result': v['result'], 'fuelConsumed': v['contextFuelConsumed'],
                     'exit': q.returncode})
    q = subprocess.run([str(runner), 'raw', str(native), str(e['offset']), 'aarch64',
                        '1', '1', '0', '1'], capture_output=True, text=True)
    (d / 'fuel1.stdout').write_text(q.stdout)
    (d / 'fuel1.stderr').write_text(q.stderr)
    assert q.returncode == old['fuelTrapReturncode'], (e['workload'], q.returncode)
    rows.append({**e, 'sourceSha256': old['sourceSha256'], 'runs': runs,
                 'fuelTrapReturncode': q.returncode})
    print('PASS actual original result/fuel', e['workload'], flush=True)
(T / 'ports-semantic.json').write_text(json.dumps({
    'status': 'PASS actual-original19-results-exact-fuel-and-fuel1-traps',
    'entries': rows, 'matrixExecutions': sum(len(x['runs']) for x in rows),
    'runnerSha256': sha(runner), 'performanceClaim': False
}, indent=2) + '\n')
print('PASS original19 complete matrix', flush=True)
