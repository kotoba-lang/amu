; benchmark generated from python API
(set-info :status unknown)
(declare-fun src0 () Int)
(declare-fun kind0 () Int)
(declare-fun home0 () (_ BitVec 64))
(declare-fun imm0 () (_ BitVec 64))
(declare-fun r () (Array Int (_ BitVec 64)))
(assert
 (let (($x21 (= src0 31)))
 (or (and (>= src0 9) (<= src0 15)) (and (>= src0 19) (<= src0 28)) $x21)))
(assert
 (>= kind0 0))
(assert
 (<= kind0 2))
(assert
 (let ((?x51 (ite (= kind0 0) (ite (= src0 31) (_ bv0 64) (select r src0)) (ite (= kind0 1) imm0 home0))))
(or (and (distinct (select (store r 0 ?x51) 0) ?x51) true))))
(check-sat)
