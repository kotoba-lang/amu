; benchmark generated from python API
(set-info :status unknown)
(declare-fun src0 () Int)
(declare-fun kind0 () Int)
(declare-fun src1 () Int)
(declare-fun kind1 () Int)
(declare-fun src2 () Int)
(declare-fun kind2 () Int)
(declare-fun home2 () (_ BitVec 64))
(declare-fun imm2 () (_ BitVec 64))
(declare-fun r () (Array Int (_ BitVec 64)))
(declare-fun home1 () (_ BitVec 64))
(declare-fun imm1 () (_ BitVec 64))
(declare-fun home0 () (_ BitVec 64))
(declare-fun imm0 () (_ BitVec 64))
(assert
 (let (($x8 (= src0 31)))
 (let (($x38 (and (>= src0 19) (<= src0 28))))
 (let (($x6 (and (>= src0 9) (<= src0 15))))
 (or $x6 $x38 $x8)))))
(assert
 (>= kind0 0))
(assert
 (<= kind0 2))
(assert
 (let (($x53 (= src1 31)))
 (or (and (>= src1 9) (<= src1 15)) (and (>= src1 19) (<= src1 28)) $x53)))
(assert
 (>= kind1 0))
(assert
 (<= kind1 2))
(assert
 (let (($x86 (= src2 31)))
 (or (and (>= src2 9) (<= src2 15)) (and (>= src2 19) (<= src2 28)) $x86)))
(assert
 (>= kind2 0))
(assert
 (<= kind2 2))
(assert
 (let ((?x97 (ite (= kind2 1) imm2 home2)))
(let (($x111 (= kind2 0)))
(let ((?x98 (ite $x111 (ite (= src2 31) (_ bv0 64) (select r src2)) ?x97)))
(let ((?x24 (ite (= kind1 1) imm1 home1)))
(let ((?x47 (ite (= kind0 0) (ite (= src0 31) (_ bv0 64) (select r src0)) (ite (= kind0 1) imm0 home0))))
(let ((?x61 (store r 0 ?x47)))
(let (($x53 (= src1 31)))
(let (($x83 (= kind1 0)))
(let ((?x36 (ite $x83 (ite $x53 (_ bv0 64) (select ?x61 src1)) ?x24)))
(let ((?x27 (store ?x61 1 ?x36)))
(let (($x86 (= src2 31)))
(let ((?x101 (ite $x111 (ite $x86 (_ bv0 64) (select ?x27 src2)) ?x97)))
(let ((?x102 (store ?x27 2 ?x101)))
(let ((?x28 (ite $x83 (ite $x53 (_ bv0 64) (select r src1)) ?x24)))
(or (and (distinct (select ?x102 0) ?x47) true) (and (distinct (select ?x102 1) ?x28) true) (and (distinct (select ?x102 2) ?x98) true)))))))))))))))))
(check-sat)
