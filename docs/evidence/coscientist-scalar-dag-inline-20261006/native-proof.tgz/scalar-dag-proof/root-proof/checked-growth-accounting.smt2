; benchmark generated from python API
(set-info :status unknown)
(declare-fun sites () Int)
(declare-fun words () Int)
(declare-fun width () Int)
(assert
 (>= sites 0))
(assert
 (< sites 256))
(assert
 (>= words 0))
(assert
 (<= words 4096))
(assert
 (>= width 0))
(assert
 (<= width 64))
(assert
 (let ((?x181 (+ words width)))
 (<= ?x181 4096)))
(assert
 (or (> (+ sites 1) 256) (> (+ words width) 4096)))
(check-sat)
