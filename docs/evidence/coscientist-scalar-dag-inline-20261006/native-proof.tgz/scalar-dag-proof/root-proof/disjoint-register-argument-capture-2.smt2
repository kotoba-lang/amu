; benchmark generated from python API
(set-info :status unknown)
(declare-fun src0 () Int)
(declare-fun kind0 () Int)
(declare-fun src1 () Int)
(declare-fun kind1 () Int)
(declare-fun home1 () (_ BitVec 64))
(declare-fun imm1 () (_ BitVec 64))
(declare-fun r () (Array Int (_ BitVec 64)))
(declare-fun home0 () (_ BitVec 64))
(declare-fun imm0 () (_ BitVec 64))
(assert
 (let (($x52 (= src0 31)))
 (or (and (>= src0 9) (<= src0 15)) (and (>= src0 19) (<= src0 28)) $x52)))
(assert
 (>= kind0 0))
(assert
 (<= kind0 2))
(assert
 (let (($x63 (= src1 31)))
 (or (and (>= src1 9) (<= src1 15)) (and (>= src1 19) (<= src1 28)) $x63)))
(assert
 (>= kind1 0))
(assert
 (<= kind1 2))
(assert
 (let ((?x71 (ite (= kind1 1) imm1 home1)))
(let (($x67 (= kind1 0)))
(let ((?x72 (ite $x67 (ite (= src1 31) (_ bv0 64) (select r src1)) ?x71)))
(let ((?x33 (ite (= kind0 0) (ite (= src0 31) (_ bv0 64) (select r src0)) (ite (= kind0 1) imm0 home0))))
(let ((?x32 (store r 0 ?x33)))
(let (($x63 (= src1 31)))
(let ((?x75 (ite $x67 (ite $x63 (_ bv0 64) (select ?x32 src1)) ?x71)))
(let ((?x76 (store ?x32 1 ?x75)))
(or (and (distinct (select ?x76 0) ?x33) true) (and (distinct (select ?x76 1) ?x72) true)))))))))))
(check-sat)
