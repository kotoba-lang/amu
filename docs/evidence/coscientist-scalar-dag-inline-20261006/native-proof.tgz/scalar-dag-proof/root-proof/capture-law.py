"""Bootstrap-only symbolic obligations for prospective register capture.
Does not prove actual admission/emission; independent audits must bind it.
"""
from pathlib import Path
import json,hashlib
import z3
D=Path(__file__).resolve().parent
rows=[]
def save(name,s,expected):
 p=D/(name+'.smt2');p.write_text(s.to_smt2());status=str(s.check());assert status==expected,(name,status)
 rows.append({'name':name,'status':status,'smt2Sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'counterexample':str(s.model()) if status=='sat' else None})
# Sequential gn-args writes x0..n-1. Reg sources cannot overlap them;
# constants and immutable frame homes are modeled as independent values.
for n in range(1,6):
 regs=z3.Array('r',z3.IntSort(),z3.BitVecSort(64)); cur=regs
 solver=z3.Solver(); wanted=[]
 for i in range(n):
  src=z3.Int('src'+str(i));kind=z3.Int('kind'+str(i));imm=z3.BitVec('imm'+str(i),64);home=z3.BitVec('home'+str(i),64)
  solver.add(z3.Or(z3.And(src>=9,src<=15),z3.And(src>=19,src<=28),src==31),kind>=0,kind<=2)
  val=lambda rr:z3.If(kind==0,z3.If(src==31,z3.BitVecVal(0,64),z3.Select(rr,src)),z3.If(kind==1,imm,home))
  wanted.append(val(regs));cur=z3.Store(cur,i,val(cur))
 solver.add(z3.Or(*[z3.Select(cur,i)!=wanted[i] for i in range(n)]));save('disjoint-register-argument-capture-'+str(n),solver,'unsat')
r=z3.Array('r',z3.IntSort(),z3.BitVecSort(64));cur=z3.Store(r,0,z3.Select(r,1));cur=z3.Store(cur,1,z3.Select(cur,0));s=z3.Solver();s.add(z3.Select(r,0)!=z3.Select(r,1),z3.Select(cur,1)!=z3.Select(r,0));save('unsafe-overlapping-argument-swap',s,'sat')
# Arbitrary expression clobbers x0..6,x9..17. Owning homes saved first
# restores live earlier temps; x7,x8,x19..28 are outside that write set.
r=z3.Array('before',z3.IntSort(),z3.BitVecSort(64));cur=r
for i in list(range(7))+list(range(9,18)):
 cur=z3.Store(cur,i,z3.BitVec('write'+str(i),64))
s=z3.Solver();s.add(z3.Or(*[z3.Select(cur,i)!=z3.Select(r,i) for i in [7,8]+list(range(19,29))]));save('owned-pure-register-write-set',s,'unsat')
s=z3.Solver();bad=z3.Store(cur,8,z3.BitVec('badFuelRegister',64));s.add(z3.Select(bad,8)!=z3.Select(r,8));save('unsafe-fuel-register-clobber',s,'sat')
s=z3.Solver();saved=z3.Select(r,9);s.add(z3.Select(cur,9)!=saved);save('unsafe-live-temp-unsaved',s,'sat')
# Compiler word caps are necessary independently of the number of sites.
s=z3.Solver();sites,words,width=z3.Ints('sites words width');s.add(sites>=0,sites<256,words>=0,words<=4096,width>=0,width<=64,words+width<=4096,z3.Or(sites+1>256,words+width>4096));save('checked-growth-accounting',s,'unsat')
(D/'capture-law.json').write_text(json.dumps({'status':'PASS symbolic prospective capture/owned-register/cap obligations','solverVersion':z3.get_version_string(),'queries':rows,'actualCandidateVerified':False,'scope':'64-bit register values with exact stated disjoint source/write sets; homes/constant values assumed immutable during capture. Actual descriptor admission, complete body semantics, spill addresses, flags, code, compiler-state rollback and fuel require separate native audits.','universalCompilerProof':False,'performanceClaim':False},indent=2)+'\n');print('PASS',len(rows),'prospective symbolic obligations; not actual candidate proof')
