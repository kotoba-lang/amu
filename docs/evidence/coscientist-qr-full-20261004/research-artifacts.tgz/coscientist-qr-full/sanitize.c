#include "c-bridge.c"
#include <stdio.h>
int main(void){int reads=0;
 for(int c=0;c<4;c++){if(oracle_selfcheck(c,0,0,0,0,0,0,0)!=1)return 1;
  for(int stage=0;stage<10;stage++){
   for(int i=0;i<100;i++){if(observe(c*1048576+stage*2048+i,0,0,0,0,0,0,0)==INT64_MIN)return 2;reads++;if(observe(c*1048576+stage*2048+768+i,0,0,0,0,0,0,0)==INT64_MIN)return 3;reads++;}
   if(stage&&stage<9){if(observe(c*1048576+stage*2048+1780+stage-1,0,0,0,0,0,0,0)==INT64_MIN)return 4;reads++;}
  }
 }
 for(int n=1;n<=32;n++){if(original_repeat_selfcheck(n,0,0,0,0,0,0,0)!=1||batch(n,0,0,0,0,0,0,0)!=1)return 5;}
 printf("PASS 4 unchanged QR selfchecks, 32 original benchmark/verify selfchecks, %d initialized image/score reads\n",reads);return 0;
}
