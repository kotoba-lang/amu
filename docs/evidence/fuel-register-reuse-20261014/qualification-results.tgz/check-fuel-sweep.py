from pathlib import Path
import json,hashlib,os,subprocess,re
W=Path(__file__).parent;B=W/'generic84-v1';D=W/'fuel-sweep512-v1';D.mkdir(exist_ok=False);raw=D/'raw';raw.mkdir();L=W.parent/'embench-pf-twoarg-20261013/protected-host/kexe-loader'
def pin(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
assert json.loads((B/'report.json').read_text())['actualStoreRemovalSites']==18
arms={}
for tag in ['OFF','ON']:
 b=B/'artifacts'/(tag+'.bin');k=b.with_suffix('.kseed');h,payload=k.read_bytes().split(b'\n\n',1);assert payload==b.read_bytes();ex={n:[int(o),int(a)]for n,o,a in map(str.split,h.decode().splitlines()[1:])};assert ex['run'][1]==2;arms[tag]=dict(native=pin(b),offset=ex['run'][0])
pins=[pin(L),pin(B/'report.json'),pin(B/'physical-proof.json')]+[pin(B/'artifacts'/(t+ext))for t in ['OFF','ON']for ext in ['.bin','.kseed']];(D/'input-pins.json').write_text(json.dumps(dict(files=pins),indent=2)+'\n')
def verify():
 for row in pins:assert pin(row['path'])==row
E={k:v for k,v in os.environ.items()if not k.startswith('KEXE_')};E.update(KEXE_STRUCTURED_REPORT='1',KEXE_ARENA_USE='1',KEXE_CPU_SECONDS='60',KEXE_WALL_SECONDS='60');calls=[];rows=[]
for mode in range(4):
 for fuel in range(1,129):
  pair=[];E['KEXE_FUEL']=str(fuel)
  for tag,arm in arms.items():
   key=f'{mode}-{fuel}-{tag}';verify();z=subprocess.run(list(map(str,[L,arm['native']['path'],arm['offset'],'2','aarch64','37',mode,127])),cwd=D,env=E,capture_output=True,timeout=60);(raw/(key+'.stdout')).write_bytes(z.stdout);(raw/(key+'.stderr')).write_bytes(z.stderr);calls.append(dict(tag=key,exit=z.returncode));(D/'calls.json').write_text(json.dumps(calls,indent=2)+'\n');verify();o,e=z.stdout,z.stderr
   if b':status :ok' in o:
    v=re.search(rb':result (-?\d+)',o);assert z.returncode==0 and mode!=3 and v and int(v[1])==8*(127+[0,1,-1][mode])
   else:
    assert z.returncode==120 and b':status :trap :exit 120'in o
    if b':SIGILL'in e:assert mode==3
    else:assert b':SIGTRAP'in e and b'budget/fuel'in e and re.search(rb':remaining 0\}',o)
   f=re.search(rb':fuel \{:initial (\d+) :remaining (\d+)\}',o);assert f and int(f[1])==fuel and 0<=int(f[2])<=fuel and len(re.findall(rb':[a-z-]+ \d+',e))==17;pair.append((z.returncode,o,e))
  assert pair[0]==pair[1],('FUEL_ORIGINAL_COLD_PAID_BOUNDARY',mode,fuel);rows.append(dict(mode=mode,fuel=fuel,exit=pair[0][0],stdoutSHA256=hashlib.sha256(pair[0][1]).hexdigest(),stderrSHA256=hashlib.sha256(pair[0][2]).hexdigest()))
r=dict(status='PASS_FUEL512_COLD_PREPAID_BOUNDARY_EVERY_FUEL1_128_EXACT_RAW_EXIT_ALL17',pairs=512,guestCalls=1024,compilerCalls=0,actualFuelAccessRemovalSites=18,rows=rows,performanceMeasured=False);(D/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(r['status'])
