from pathlib import Path
import ast, hashlib, json, os, re, shlex, subprocess, tarfile

root = Path('/Users/joseph/github/workspaces/codex/embench-picojpeg-edn-20261009/Paid-fuel-reuse-round98-fixed4-20261014-v1')
report = json.loads((root / 'results/report.json').read_text())
assert report['status'] in ['COMPLETE_EXPLORATORY_ONE_FIXED4', 'REFUSED_INCOMPLETE_FIXED4', 'FAILED_NON_CPU_NO_RETRY']
assert report['closure'] == []
controller = root / 'pf-fixed4-controller.py'
node = next(n for n in ast.parse(controller.read_text()).body if isinstance(n, ast.FunctionDef) and n.name == 'global_idle')
__file__ = str(controller)
exec(compile(ast.Module(body=[node], type_ignores=[]), '<fresh-closure>', 'exec'))
assert global_idle() == []
for rel, row in json.loads((root / 'packet-manifest.json').read_text()).items():
    b = (root / rel).read_bytes()
    assert len(b) == row['bytes'] and hashlib.sha256(b).hexdigest() == row['sha256']
setup = json.loads((root / 'root-setup-receipt.json').read_text())
for name, sha in setup['timerHashes'].items():
    assert hashlib.sha256((root / 'timers' / name / 'timer').read_bytes()).hexdigest() == sha
for name, sha in setup['wrapperHashes'].items():
    assert hashlib.sha256((root / 'timers' / name / 'timer-fixed-n').read_bytes()).hexdigest() == sha
files = []
for p in sorted(root.rglob('*')):
    if p.is_file():
        assert not p.is_symlink()
        b = p.read_bytes()
        files.append(dict(path=str(p.relative_to(root)), bytes=len(b), sha256=hashlib.sha256(b).hexdigest()))
receipt = dict(status='PASS_TERMINAL_FIXED4_ALL_SOURCE_TIMERS_RAW_FILES_AND_GLOBAL_CLOSURE', root=str(root), ownedRows=[], files=files)
(root / 'collection-custody.json').write_text(json.dumps(receipt, indent=2) + '\n')
archive = Path(str(root) + '-collected.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for row in files:
        t.add(root / row['path'], arcname=row['path'], recursive=False)
    t.add(root / 'collection-custody.json', arcname='collection-custody.json', recursive=False)
b = archive.read_bytes()
print(json.dumps(dict(archive=str(archive), bytes=len(b), sha256=hashlib.sha256(b).hexdigest(), members=len(files)+1, root=str(root))))
