"""Pure source assembly only; never builds, executes, transfers or measures."""
import argparse,json,hashlib,re,shutil,shlex
from pathlib import Path
W=Path(__file__).resolve().parent
R=Path('/Users/junkawasaki/github/workspaces/codex/embench-total-C-round86-v7-20261013-v1/official/remote-packet')
def check(row):
 p=Path(row['path']);b=p.read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'];return p

def assemble(binding):
 plan=json.loads((W/'PLAN.json').read_text())
 for row in plan['inputs'].values():check(row)
 b=json.loads(Path(binding).read_text())
 assert b['rootReviewedExecutionReady'] is True
 assert b['all39NativeGatesPASS'] is True and b['original483PASS'] is True and b['genericControlsPASS'] is True
 for key in ['all39Receipt','original483Receipt','genericControlsReceipt','qualificationReceipt']:check(b[key])
 q=json.loads(check(b['qualificationReceipt']).read_text());assert q['status']=='PASS_ROOT_PREPAID_FUEL_REUSE_PROGRAM_TIMING_SCOPE_NOT_COMPILER_ADOPTION'
 assert q['all39Gate']==b['all39Receipt'] and q['original483']==b['original483Receipt'] and q['genericControls']==b['genericControlsReceipt']
 assert b['generatedArtifactsSHA256']==plan['generatedArtifactsSHA256']
 dest=W/'qualified-public-packet';assert not dest.exists();dest.mkdir()
 images=json.loads(Path(plan['generatedArtifacts']).read_text())['images']
 expected=json.loads((R/'expected-original-accounting.json').read_text());workloads=json.loads((R/'workloads.json').read_text())
 for f in ['run_trigger.py','darwin_cpu_idle.py']:shutil.copy2(R/f,dest/f)
 shutil.copy2(W/'controller.py',dest/'pf-fixed4-controller.py')
 specs=[];builds=[]
 for name in plan['workloads']:
  row=next(x for x in images if x['tag']=='official-'+name);ref=next(x for x in workloads if x['workload']==name);account=next(x for x in expected if x['workload']==name)
  assert account['n']==8192*ref['LSF'];assert row['baseline']['source']['sha256']==row['arm']['source']['sha256']
  for arm,key in [('OFF','baseline'),('ON','arm')]:
   d=dest/'timers'/name/arm;d.mkdir(parents=True)
   for f in ['separated-loader.c','timing-extension.h','timing-frontend.h']:shutil.copy2(R/'timers'/name/f,d/f)
   native=check(row[key]['native']).read_bytes();check(row[key]['container']);check(row[key]['source'])
   h=(R/'timers'/name/'timing-packet-generated.h').read_text()
   exports=row[key]['exports'];symbol=ref['measuredSymbol'];assert exports[symbol][1]==ref['measuredArity']
   replacements={'TIMING_NATIVE_PATH':json.dumps(plan['remoteRoot']+'/timers/'+name+'/'+arm+'/image.bin'),'TIMING_BENCH_OFFSET':str(exports[symbol][0]),'TIMING_VERIFY_OFFSET':str(exports['verify-state'][0]),'TIMING_BENCH_ARITY':str(exports[symbol][1])}
   for macro,value in replacements.items():h,n=re.subn(r'^#define '+macro+r' .*$', '#define '+macro+' '+value,h,flags=re.M);assert n==1
   h,n=re.subn(r'static const unsigned char timing_native\[\]=\{[0-9,]+\};','static const unsigned char timing_native[]={'+','.join(map(str,native))+'};',h);assert n==1
   assert bytes(map(int,re.search(r'timing_native\[\]=\{([0-9,]+)\}',h)[1].split(',')))==native
   (d/'timing-packet-generated.h').write_text(h);(d/'image.bin').write_bytes(native)
   wrapper='#!/bin/sh\nexec '+shlex.quote(plan['remoteRoot']+'/timers/'+name+'/'+arm+'/timer')+' '+str(account['n'])+'\n'
   (d/'timer-fixed-n').write_text(wrapper);(d/'timer-fixed-n').chmod(0o755)
   builds.append(['/usr/bin/clang','-std=c11','-O2',str(d.relative_to(dest)/'separated-loader.c'),'-o',str(d.relative_to(dest)/'timer')])
  specs.append({'workload':name,'n':account['n'],'LSF':ref['LSF'],'order':['OFF','ON','OFF','ON'],'expected':account,'environment':{'KEXE_FUEL':'34359738368','KEXE_STRUCTURED_REPORT':'1','KEXE_ARENA_USE':'1','KEXE_CPU_SECONDS':'1800','KEXE_WALL_SECONDS':'1800',**({'KEXE_PAIRS':'8388608'} if name=='slre' else {})}})
 (dest/'spec.json').write_text(json.dumps(specs,indent=2)+'\n');(dest/'build-plan.json').write_text(json.dumps(builds,indent=2)+'\n');(dest/'expected-original-accounting.json').write_text(json.dumps([s['expected']for s in specs],indent=2)+'\n')
 (dest/'qualification-binding.json').write_text(json.dumps(b,indent=2)+'\n')
 manifest={str(p.relative_to(dest)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in dest.rglob('*')if p.is_file()}
 (dest/'packet-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('SOURCE_ASSEMBLED_ONLY',dest)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root-qualified-binding',required=True);a=p.parse_args();assemble(a.root_qualified_binding)
