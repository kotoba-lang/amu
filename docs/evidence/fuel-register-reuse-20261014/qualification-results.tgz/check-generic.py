from pathlib import Path
import json,hashlib,os,subprocess,shutil,re,importlib.util
W=Path(__file__).parent;D=W/'generic84-v1';D.mkdir(exist_ok=False);A=D/'artifacts';A.mkdir();H=D/'host';H.mkdir();raw=D/'raw';raw.mkdir()
L=W.parent/'embench-pf-twoarg-20261013/protected-host/kexe-loader'
P={'OFF':W.parent/'seed-mask-direct-source-20261013/selfbuild-v1/host/G4.bin','ON':W/'compiler-only-v1/artifacts/candidate.bin'}
def pin(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
q=json.loads((W/'compiler-only-v1/report.json').read_text())
assert pin(P['OFF'])['sha256']=='e918a3d56f79671494991a65ed4762336ef3704afad130b10d8fcee710d936ec'
assert pin(P['ON'])['sha256']==q['nativeSHA256']
S=A/'controls.kotoba';S.write_bytes((W/'generic-fixture.kotoba').read_bytes());pins={p:pin(p)for p in[L,S,*P.values()]}
env={k:v for k,v in os.environ.items()if not k.startswith('KEXE_')};env.update(KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(A),KEXE_FUEL='off',KEXE_VECTORS='4194304',KEXE_VECTOR_ITEMS='134217728',KEXE_STRING_POOL='268435456',KEXE_PAIRS='16777216',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',TMPDIR=str(A))
calls=[]
def call(tag,args,e):
 z=subprocess.run(list(map(str,args)),cwd=A,env=e,capture_output=True,timeout=1800);(raw/(tag+'.stdout')).write_bytes(z.stdout);(raw/(tag+'.stderr')).write_bytes(z.stderr);calls.append(dict(tag=tag,exit=z.returncode));(D/'calls.json').write_text(json.dumps(calls,indent=2)+'\n');assert all(pin(p)==v for p,v in pins.items()),(tag,z.returncode)
 return z.returncode,z.stdout,z.stderr
arms={}
for tag,p in P.items():
 k=A/(tag+'.kseed');b=A/(tag+'.bin');base=[L,p,'0','0','aarch64','35,37,38,39','--']
 for name,args in [('compile',['compile',S,'--target','aarch64-macos','--output',k]),('extract',['extract-native',k,'--symbol','run','--output',b])]:
  code,_,err=call(tag+'-'+name,base+args,env);assert code==0 and not err
 h,payload=k.read_bytes().split(b'\n\n',1);assert payload==b.read_bytes();ex={n:[int(o),int(a)]for n,o,a in map(str.split,h.decode().splitlines()[1:])};arms[tag]=dict(native=pin(b),container=pin(k),source=pin(S),exports=ex,offset=ex['run'][0],arity=ex['run'][1]);assert ex['run'][1]==2
spec=importlib.util.spec_from_file_location('generic_positive_physical',W/'native-gate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);proof=m.audit(arms['OFF'],arms['ON']);assert proof['changed'],'Acceptance controls must contain an actual prepaid store removal';(D/'physical-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
def wrap(x):x&=(1<<64)-1;return x-(1<<64)if x>=1<<63 else x
def div(x,k):return (-1 if x<0 else 1)*(abs(x)//k)
def oracle(mode,x):
 if mode==3:return None
 y=(x+[0,1,-1][mode])&65535;y=y-65536 if y>=32768 else y
 return 8*min(255,max(0,y))

xs=[-(1<<63),-(1<<63)+1,-65536,-65535,-1024,-256,-255,-1,0,1,7,127,128,255,256,65535,65536,(1<<63)-2,(1<<63)-1];rows=[]
guest={k:v for k,v in env.items()if not k.startswith('KEXE_')};guest.update(KEXE_ARENA_USE='1',KEXE_STRUCTURED_REPORT='1',KEXE_FUEL='100000',KEXE_CPU_SECONDS='60',KEXE_WALL_SECONDS='60')
cases=[(mode,x,100000)for mode in range(4)for x in xs]+[(mode,-1,f)for mode in range(4)for f in [1,2]]
for i,(mode,x,fuel)in enumerate(cases):
 pair=[];guest['KEXE_FUEL']=str(fuel)
 for tag,a in arms.items():
  code,o,e=call(f'{i}-{tag}',[L,a['native']['path'],a['offset'],'2','aarch64','37',mode,x],guest)
  if b':status :ok'in o:
   v=re.search(rb':result (-?\d+)',o);assert mode!=3 and code==0 and v and int(v[1])==oracle(mode,x)
  else:
   assert (mode==3 or fuel<=2)and code==120 and b':status :trap :exit 120'in o
   if b':SIGILL'in e:assert mode==3
   else:assert fuel<=2 and b'budget/fuel'in e
  f=re.search(rb':fuel \{:initial (\d+) :remaining (\d+)\}',o);assert f and int(f[1])==fuel and 0<=int(f[2])<=fuel
  assert len(re.findall(rb':[a-z-]+ \d+',e))==17;pair.append((code,o,e))
 assert pair[0]==pair[1],('EXACT_RAW_FUEL_ARENA',mode,x,fuel);rows.append(dict(mode=mode,x=x,fuel=fuel,oracle=oracle(mode,x)))
assert len(rows)==84
r=dict(status='PASS_GENERIC84_PREPAID_FUEL_REUSE_FULL64_CLIP_ORACLE_SMALL_VECTOR_FALLBACK_LOWFUEL_EXACT_RAW_ALL17',pairs=84,guestCalls=168,compilerCalls=4,actualStoreRemovalSites=len(proof['sites']),rows=rows,performanceMeasured=False)
(D/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(r['status'],len(proof['sites']))
