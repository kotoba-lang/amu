from pathlib import Path
import json,struct,importlib.util,sys
assert not sys.flags.optimize
W=Path(__file__).parent
ROOT=W.parent/'embench-dve-ocb-sdiv2-composed-20261012'
def module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
m=module('effects',ROOT/'native-audit-preparation-v1/effects.py')
g=module('gate',ROOT/'same-layout-direct-read-v3/qualification-source-v2/native-gate.py')
P=json.loads((W/'all39-g1-screen-v1/generated-artifacts.json').read_text());out=[]
for e in P['images']:
 r=g.audit(e['baseline'],e['arm'])
 if not r['changed']:continue
 B,ex=g.m.payload(e['arm']);pool,_=g.m.source_pool(Path(e['source']['path']).read_bytes());end=len(B)-len(pool);ws=struct.unpack('<%dI'%(end//4),B[:end]);refs=[(p,t[1])for p in range(0,end,4) if (t:=g.m.ref(ws[p//4],p))];sites=[]
 for s in r['sites']:
  finish=s['PC'];rv=s['handleRegister'];seeds=[]
  for p in range(0,finish,4):
   x=list(ws[p//4:p//4+15])
   if len(x)==15 and x[:2]==[0xf9409cf0,0xf9400210] and x[2]==0xd1000411|(rv<<5) and x[3:11]==[0xeb10023f,0x54000043,0,0xf940a0f0,0x8b111210,0xa9400e11,0xf940a4e4,0x8b110c84]:seeds.append(p)
  assert seeds,('NO_RETAINED_CHECKED_SEED',e['tag'],finish)
  seed=max(seeds);entry=seed+44
  assert not [(p,t) for p,t in refs if seed<t<=finish and not seed<=p<finish],('EXTERNAL_ENTRY',e['tag'],seed,finish)
  assert not [p for p,a in ex.values()if seed<p<=finish],('EXPORT_ENTRY',e['tag'],seed,finish)
  todo=[entry];seen=set();nodes=[];reaches=False
  while todo:
   pc=todo.pop()
   if pc==finish:reaches=True;continue
   if pc in seen:continue
   assert len(seen)<1024 and 0<=pc<end and pc%4==0,('UNBOUNDED',e['tag'],pc)
   seen.add(pc);w=ws[pc//4];rd,wr,succ,kind=m.effects(w,pc)
   if not entry<=pc<finish:
    exitTodo=[pc];exitSeen=set()
    while exitTodo:
     ep=exitTodo.pop()
     if ep in exitSeen:continue
     if ep==seed:continue # Full retained descriptor check re-establishes the witness before any later reuse.
     assert 0<=ep<end and ep%4==0 and len(exitSeen)<1024,('UNBOUNDED_EXIT',e['tag'],ep)
     assert not seed<ep<=finish,('EXIT_REENTERS_DESCRIPTOR_HISTORY',e['tag'],finish,ep)
     exitSeen.add(ep);ew=ws[ep//4];er,ev,es,ek=m.effects(ew,ep)
     assert ek not in ['issued-runtime-callback-ABI','indirect-tail-ABI'],('OPAQUE_EXIT',e['tag'],ep) # Direct BL follows both the actual target and return continuation; neither may reenter history.
     if not es:assert ek in ['synchronous-trap-scratch-not-source-home','source-gn-e-udf-zero-synchronous-trap','return-scratch-not-return-register'],('UNKNOWN_EXIT_TERMINAL',e['tag'],ep,ek)
     exitTodo.extend(es)
    nodes.append(dict(exitStart=pc,exitVisited=sorted(exitSeen),noReentry=True));continue
   assert not ({3,4,rv}&wr),('CACHE_CLOBBER',e['tag'],finish,pc,hex(w),sorted(wr))
   assert kind not in ['issued-runtime-callback-ABI','indirect-tail-ABI','return-scratch-not-return-register'] and w&0xfc000000!=0x94000000,('OPAQUE_CALL',e['tag'],pc,hex(w))
   store=False;rn=w>>5&31
   if w&0x3b000000==0x39000000 or w&0x3b200c00==0x38200800 or w&0x3b200000==0x38000000 or w&0x3a000000==0x28000000:store=not bool(w&0x00400000)
   assert not store or rn==31 or w in (0xf90004f0,0xf90004e8,0xf90004ff),('UNPROVEN_STORE',e['tag'],pc,hex(w))
   assert succ or w in (0,0xd4200000,0xd4200020),('UNKNOWN_TERMINAL',e['tag'],pc)
   nodes.append(dict(pc=pc,word=hex(w),writes=sorted(wr),successors=succ));todo.extend(succ)
  assert reaches,('NO_SUCCESS',e['tag'],finish)
  sites.append(dict(pc=finish,seed=seed,handleRegister=rv,nodes=nodes))
 out.append(dict(tag=e['tag'],sites=sites))
(W/'descriptor-cfg-report.json').write_text(json.dumps(dict(status='PASS_DESCRIPTOR_DOMINANCE_CLOBBER_STORE_CFG_NOT_SOURCE_QUALIFICATION',images=out),indent=2)+'\n');print('PASS',sum(len(e['sites']) for e in out))
