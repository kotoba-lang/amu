from pathlib import Path
import json,struct,importlib.util,sys
assert not sys.flags.optimize
W=Path(__file__).parent;ROOT=W.parent/'embench-dve-ocb-sdiv2-composed-20261012';s=importlib.util.spec_from_file_location('effects',ROOT/'native-audit-preparation-v1/effects.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);rows=[]
P=json.loads((W/'all39-stable-v1/generated-artifacts.json').read_text());Q=json.loads((W/'physical-all39-v1.json').read_text())
for e,r in zip(P['images'],Q['images']):
 assert e['tag']==r['tag']
 B=Path(e['arm']['native']['path']).read_bytes();ws=struct.unpack('<%dI'%(len(B)//4),B[:len(B)//4*4])
 for site in r['report'].get('sites',[]):
  for reg in [16,17]:
   todo=[site['PC']+60];seen=set();kills=[]
   while todo:
    at=todo.pop()
    if at in seen:continue
    assert 0<=at<len(B)//4*4 and at%4==0 and len(seen)<1024,('UNBOUNDED',e['tag'],at)
    seen.add(at);w=ws[at//4];rd,wr,succ,kind=m.effects(w,at)
    assert reg not in rd,('SCRATCH_OBSERVED',e['tag'],site['PC'],reg,at,hex(w))
    if reg in wr:kills.append(at);continue
    if not succ:
     assert kind in ['synchronous-trap-scratch-not-source-home','source-gn-e-udf-zero-synchronous-trap','return-scratch-not-return-register'];continue
    assert kind not in ['issued-runtime-callback-ABI','indirect-tail-ABI'],('OPAQUE',e['tag'],at)
    todo.extend(succ)
   rows.append(dict(tag=e['tag'],site=site['PC'],register=reg,visited=sorted(seen),firstKills=kills))
(W/'scratch-report.json').write_text(json.dumps(dict(status='PASS_ALL23_SITES_POST_PAYLOAD_SCRATCH16_17_LIVENESS',rows=rows),indent=2)+'\n');print('PASS',len(rows),'scratch obligations')
