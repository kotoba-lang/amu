from pathlib import Path
import importlib.util,json,hashlib,subprocess,sys
assert not sys.flags.optimize
W=Path(__file__).parent.parent
for name in ['descriptor-cfg','scratch']:
 p=W/(name+'-report.json');before=p.read_bytes()
 z=subprocess.run([sys.executable,str(W/('descriptor-cfg-audit.py' if name=='descriptor-cfg' else 'scratch-audit.py'))],capture_output=True)
 assert z.returncode==0,(name,z.stderr)
 assert p.read_bytes()==before,('PROOF_REPLAY_CHANGED',name)
G=W.parent/'embench-dve-ocb-sdiv2-composed-20261012/same-layout-direct-read-v3/qualification-source-v2/native-gate.py'
s=importlib.util.spec_from_file_location('physical',G);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
A=json.loads((W/'all39-stable-v1/generated-artifacts.json').read_text())['images'];P=json.loads((W/'physical-all39-v1.json').read_text())['images']
def audit(old,arm):
 e=next(e for e in A if e['arm']['native']==arm['native']);assert old==e['baseline'] and arm==e['arm']
 r=m.audit(old,arm);assert r==next(p['report'] for p in P if p['tag']==e['tag']);return r
