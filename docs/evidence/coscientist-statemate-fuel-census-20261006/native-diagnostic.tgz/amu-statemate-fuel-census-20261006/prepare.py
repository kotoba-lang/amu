from pathlib import Path
import json,hashlib,shutil,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path(__file__).resolve().parent;b=Path('/private/tmp/amu-static-vector-chain-20261006');t=Path('/private/tmp/amu-terminal-census-20261006');g=(r/'seed/41-a64gen.kotoba').read_text();assert g==(b/'41-a64gen-prototype.kotoba').read_text();(w/'baseline-41-a64gen.kotoba').write_text(g)
h={'status':'registered-before-native-execution','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'hypothesis':'Attribute completed original fuel charges by SIR site and plain/masked lowering on unchanged statemate. Counts do not prove cost.','limits':'Diagnostic only, no timed optimizer. Three-generation product seed builds diagnostic compiler; disabled output must match product bytes and offset.','authoringException':'One-off new diagnostic algorithm outside product path, not mechanical refactor.'};(w/'hypothesis.json').write_text(json.dumps(h,indent=2)+'\n')
helper=''';; Diagnostic arena: 65536 counters, site*2 + charge lowering kind.
;; Save reserved scratch and flags; completed charges only, original code intact.
(def gn-fuel-observe true)
(defn- gn-fuel-record [M :vector-i64 kind :i64] :vector-i64
 (if (not gn-fuel-observe) M
  (-> M (gn-emit (enc-stp-pre 16 17 31 -16))
        (gn-emit 0xd53b4210) (gn-emit (enc-stp-pre 16 31 31 -16))
        (gn-emit (enc-ldr 16 7 400))
        (gn-mov-imm 17 (+ (* (gn-g M 15) 2) kind))
        (gn-emit (gn-e-addsl 16 16 17 3))
        (gn-emit (enc-ldr 17 16 0)) (gn-emit (enc-add-i 17 17 1))
        (gn-emit (enc-str 17 16 0))
        (gn-emit (enc-ldp-post 16 31 31 16)) (gn-emit 0xd51b4210)
        (gn-emit (enc-ldp-post 16 17 31 16)))))
'''
a='(defn- gn-mask-charge [';assert g.count(a)==1;g=g.replace(a,helper+a)
a='(gn-ins-quiet (gn-chain-step M i op (gn-sir M i IF-A)) i op)';assert g.count(a)==1;g=g.replace(a,'(gn-ins-quiet (gn-chain-step (gn-gs M 15 i) i op (gn-sir M i IF-A)) i op)')
a='(gn-emit (enc-str 31 7 CTX-FUEL)) (gn-emit (enc-brk 0))))\n(defn- gn-call-mask-writer';assert g.count(a)==1;g=g.replace(a,'(gn-emit (enc-str 31 7 CTX-FUEL)) (gn-emit (enc-brk 0)) (gn-fuel-record 1)))\n(defn- gn-call-mask-writer')
a='(gn-emit (enc-str 16 7 CTX-FUEL)))))\n\n;; Exact affine';assert g.count(a)==1;g=g.replace(a,'(gn-emit (enc-str 16 7 CTX-FUEL)) (gn-fuel-record 0))))\n\n;; Exact affine')
a='(gn-emit (enc-str 31 7 CTX-FUEL)) (gn-emit (enc-brk 0)))\n    (-> M\n        (gn-ctx)';assert g.count(a)==1;g=g.replace(a,'(gn-emit (enc-str 31 7 CTX-FUEL)) (gn-emit (enc-brk 0)) (gn-fuel-record 0))\n    (-> M\n        (gn-ctx)')
(w/'41-a64gen-diagnostic.kotoba').write_text(g)
parts=[z.strip() for z in (r/'seed/MANIFEST').read_text().splitlines() if z.strip() and not z.lstrip().startswith('#')]
for arm,source in [('diagnostic',g),('quiet',g.replace('(def gn-fuel-observe true)','(def gn-fuel-observe false)'))]:(w/(arm+'-unity.kotoba')).write_text(''.join(source if p=='seed/41-a64gen.kotoba' else (r/p).read_text() for p in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader')]:shutil.copy2(b/src,w/dst)
c=(t/'diagnostic-loader.c').read_text();assert c.count('diagnostic_counters[32768]')==1;c=c.replace('diagnostic_counters[32768]','diagnostic_counters[65536]');assert c.count('d < 32768')==1;c=c.replace('d < 32768','d < 65536');(w/'diagnostic-loader.c').write_text(c)
q=subprocess.run(['clang','-O2','-o',str(w/'diagnostic-loader'),str(w/'diagnostic-loader.c')],capture_output=True,text=True);(w/'loader-build.log').write_text(q.stdout+q.stderr);assert q.returncode==0,q.stderr
shutil.copy2(b/'full-state-loader',w/'full-state-loader')
(w/'source-pins.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [w/'baseline-41-a64gen.kotoba',w/'41-a64gen-diagnostic.kotoba',w/'diagnostic-loader.c',w/'diagnostic-unity.kotoba',w/'quiet-unity.kotoba']},indent=2)+'\n')
print('PASS prepared bounded completed-charge counter diagnostic, product unchanged')
