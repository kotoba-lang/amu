from pathlib import Path
import subprocess,struct,json
w=Path(__file__).resolve().parent;s='''.text
.globl _counter
_counter:
stp x16, x17, [sp, #-16]!
mrs x16, nzcv
stp x16, xzr, [sp, #-16]!
ldr x16, [x7, #400]
mov x17, #1234
add x16, x16, x17, lsl #3
ldr x17, [x16]
add x17, x17, #1
str x17, [x16]
ldp x16, xzr, [sp], #16
msr nzcv, x16
ldp x16, x17, [sp], #16
''';(w/'counter.s').write_text(s);q=subprocess.run(['clang','-c','-arch','arm64',str(w/'counter.s'),'-o',str(w/'counter.o')],capture_output=True,text=True);assert q.returncode==0,q.stderr;p=(w/'counter.o').read_bytes();off=32;code=None
for _ in range(struct.unpack_from('<I',p,16)[0]):
 cmd,size=struct.unpack_from('<II',p,off)
 if cmd==25:
  for j in range(struct.unpack_from('<I',p,off+64)[0]):
   sec=off+72+j*80
   if p[sec:sec+16].rstrip(b'\0')==b'__text':length=struct.unpack_from('<Q',p,sec+40)[0];at=struct.unpack_from('<I',p,sec+48)[0];code=p[at:at+length]
 off+=size
assert code is not None and len(code)==48;seq=list(struct.unpack('<12I',code));rows=[]
for name in ['statemate','fixtures']:
 guest=[v[0] for v in struct.iter_unpack('<I',(w/('diagnostic-'+name+'.bin')).read_bytes()[:(w/('diagnostic-'+name+'.bin')).stat().st_size//4*4])];blocks=[]
 for i in range(len(guest)-11):
  if guest[i:i+3]!=seq[:3]:continue
  z=guest[i:i+12];assert z[:4]==seq[:4] and z[5:]==seq[5:],(name,i,[hex(x) for x in z]);assert z[4]&0xffe0001f==0xd2800011,(name,i,hex(z[4]));slot=(z[4]>>5)&65535;assert slot<65536;blocks.append({'word':i,'slot':slot,'site':slot//2,'kind':slot%2})
 assert blocks;rows.append({'guest':name,'blocks':len(blocks),'maxSlot':max(z['slot'] for z in blocks),'regions':blocks})
 if name=='statemate':assert (w/'diagnostic-statemate.bin').stat().st_size-(w/'quiet-statemate.bin').stat().st_size==48*len(blocks)
out={'status':'complete-independent-assembler-actual-counter-block-audit','rows':rows,'registersPreserved':[16,17],'flagsPreserved':'NZCV','stackDeltaAtExit':0,'noCallsOrBranchesInsideBlocks':True,'noX8ChangesInsideBlocks':True,'counterBounds':'Every actual slot lies in separately allocated65536-element arena; original statemate SIR9739<32768.','diagnosticTimingIsNotPerformance':True};(w/'machine-audit.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS actual balanced bounded counters',[(z['guest'],z['blocks'],z['maxSlot']) for z in rows])
