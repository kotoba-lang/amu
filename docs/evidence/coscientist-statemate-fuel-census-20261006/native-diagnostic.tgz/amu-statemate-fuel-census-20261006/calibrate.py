from pathlib import Path
import importlib.util,subprocess,os,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path(__file__).resolve().parent;frozen=w/'a64gen-fixtures.py';frozen.write_text((r/'scripts/seed/a64gen-fixtures.py').read_text().replace("R = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))","R = '/Users/junkawasaki/github/wt/amu-seed17'",1));shutil=None
# Preserve the renderer's sibling import.
(w/'a64gen_vector_chain_fixtures.py').write_bytes((r/'scripts/seed/a64gen_vector_chain_fixtures.py').read_bytes())
sp=importlib.util.spec_from_file_location('fx',frozen);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);assert len(m.layout_tables()[3])<32768
ns={};exec((w/'build.py').read_text().split('port=next(')[0],ns);compile=ns['compile'];images={};parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba']
for arm,g in [('baseline','baseline-41-a64gen.kotoba'),('diagnostic','41-a64gen-diagnostic.kotoba')]:
 src=w/(arm+'-fixtures.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/g).read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+m.kotoba(True));seed,off=compile(w/'seed-0.bin',(w/'seed-0.offset').read_text().strip(),src,arm+'-fixtures-generator','main');env=dict(os.environ,KEXE_COMMAND='1',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');q=subprocess.run([str(w/'kexe-loader'),str(seed),str(off),'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0,(q.stdout[-500:],q.stderr);(w/(arm+'-fixtures.stdout')).write_text(q.stdout);blob,fns=m.blob_from(q.stdout);p=w/(arm+'-fixtures.bin');p.write_bytes(blob);images[arm]=(p,fns);print('PASS native calibration SIR image',arm,len(blob),flush=True)
names=[f[0] for f in m.FIX];rows=[]
for name,args,total,expect in [('sum',[0],0,0),('sum',[1],1,1),('sum',[3],3,6),('sum',[10],10,55),('r2_fuel2',[3],7,12),('cl_call3_0',[0,0],3,11),('cl_call3_0',[255,0],3,24)]:
 for fuel in [1,2,3,4,10,100]:
  obs={};counts={}
  for arm,(p,offs) in images.items():
   env=dict(os.environ,KEXE_STRUCTURED_REPORT='1',KEXE_FUEL=str(fuel));env.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'diagnostic-loader'),str(p),str(offs[names.index(name)+1]),str(len(args)),'aarch64','-',*map(str,args)],env=env,capture_output=True,text=True);(w/f'cal-{name}-{args[0]}-{fuel}-{arm}.log').write_text(q.stdout+q.stderr);obs[arm]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)};counts[arm]=[list(map(int,z)) for z in re.findall(r'^DIAG_COUNT (\d+) (\d+)$',q.stderr,re.M)]
  assert obs['baseline']==obs['diagnostic'];assert not counts['baseline'];actual=sum(z[1] for z in counts['diagnostic']);assert actual==min(total,fuel),(name,args,fuel,total,actual)
  assert (obs['diagnostic']['exit']==0)==(fuel>=total),(name,args,fuel,obs)
  if fuel>=total:
   assert ':result '+str(expect)+' ' in obs['diagnostic']['report'],(name,args,expect,obs)
   assert ':remaining '+str(fuel-total)+'}' in obs['diagnostic']['report']
   if name=='cl_call3_0':assert sum(z[1] for z in counts['diagnostic'] if z[0]%2)==2,(name,counts)
  rows.append({'fixture':name,'args':args,'fuel':fuel,'expectedCharges':min(total,fuel),'expectedSuccessfulCharges':total,'expectedSuccessfulResult':expect,'observation':obs['diagnostic'],'counts':counts['diagnostic']});print('PASS independent plain/leaf/masked charge oracle',name,args,fuel,actual,flush=True)
(w/'calibration-proof.json').write_text(json.dumps({'status':'complete-handwritten-SIR-native-independent-charge-oracles','cases':len(rows),'rows':rows,'maskedChargeControls':True},indent=2)+'\n')
