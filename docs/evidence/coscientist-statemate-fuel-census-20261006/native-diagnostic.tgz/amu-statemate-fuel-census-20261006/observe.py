from pathlib import Path
import json,os,re,subprocess,collections,shutil
w=Path(__file__).resolve().parent;b=Path('/private/tmp/amu-static-vector-chain-20261006');e=next(x for x in json.loads((b/'ports-correctness.json').read_text())['entries'] if x['workload']=='statemate');rows=[]
c=json.loads((b/'observer/meta-ports/statemate/census.json').read_text());assert c['sirCount']<32768
sir={int(z.split()[1]):list(map(int,z.split()[2:])) for z in (b/'observer/meta-ports/statemate/compile.log').read_text().splitlines() if z.startswith('SIR ')};owner={i:int(f) for f,v in c['functions'].items() for i in range(v['start'],v['end']+1)};closed={x['fn'] for x in json.loads((b/'instruction-audit.json').read_text())['mode2Functions'] if x['workload']=='statemate'}
for name in ['census.json','compile.log']:shutil.copy2(b/'observer/meta-ports/statemate'/name,w/('product-'+name))
shutil.copy2(b/'instruction-audit.json',w/'product-instruction-audit.json')
for n in [0,1,2,17,32]:
 for fuel in [1,2,64,805,806,16777216]:
  obs={};counts={}
  for label,p,off,loader in [('baseline',b/'ports-2/statemate/native.bin',e['offset'],w/'diagnostic-loader'),('quiet',w/'quiet-statemate.bin',int((w/'quiet-statemate.offset').read_text()),w/'diagnostic-loader'),('diagnostic',w/'diagnostic-statemate.bin',int((w/'diagnostic-statemate.offset').read_text()),w/'diagnostic-loader'),('original-supervisor',b/'ports-2/statemate/native.bin',e['offset'],w/'full-state-loader')]:
   env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');env.pop('KEXE_COMMAND',None);q=subprocess.run([str(loader),str(p),str(off),'1','aarch64','-',str(n)],env=env,capture_output=True,text=True);(w/f'run-{n}-{fuel}-{label}.log').write_text(q.stdout+q.stderr);assert ':fuel ' in q.stdout,(n,fuel,label,q.stdout,q.stderr);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)};counts[label]=[list(map(int,z)) for z in re.findall(r'^DIAG_COUNT (\d+) (\d+)$',q.stderr,re.M)]
  assert obs['baseline']==obs['diagnostic']==obs['quiet']==obs['original-supervisor'],(n,fuel,obs);assert not counts['baseline'] and not counts['quiet'];total=sum(z[1] for z in counts['diagnostic']);remaining=int(re.search(r':remaining (\d+)',q.stdout)[1]);consumed=fuel-remaining
  if obs['diagnostic']['exit']==0:assert total==consumed,(n,fuel,total,consumed)
  cats=collections.Counter();fs=collections.Counter();sites=[]
  for slot,amount in counts['diagnostic']:
   site,kind=divmod(slot,2);assert site in sir and site in owner;f=owner[site];mode='closedMode2' if f in closed else 'leaf' if c['functions'][str(f)]['leaf'] else 'nonleaf';cats[mode]+=amount;cats['plain' if kind==0 else 'maskedInline']+=amount;fs[f]+=amount;sites.append({'site':site,'loweringKind':kind,'fn':f,'count':amount,'mode':mode,'sir':sir[site]})
  rows.append({'n':n,'initialFuel':fuel,'consumedFuel':consumed,'completedCharges':total,'observation':obs['baseline'],'categories':dict(cats),'functions':dict(fs),'sites':sites});print('PASS original state and charge attribution',n,fuel,total,consumed,dict(cats),flush=True)
(w/'observations.json').write_text(json.dumps({'status':'complete-current-original-statemate-four-arm-fuel-census-fullstate-parity','comparisons':len(rows),'supervisorExecutions':len(rows)*4,'sirCount':c['sirCount'],'counterCapacity':65536,'rows':rows,'officialEmbenchScore':False,'performanceMeasurement':False,'productChanged':False},indent=2)+'\n')
