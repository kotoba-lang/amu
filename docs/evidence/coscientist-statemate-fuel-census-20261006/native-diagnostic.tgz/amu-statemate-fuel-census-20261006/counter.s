.text
.globl _counter
_counter:
stp x16, x17, [sp, #-16]!
mrs x16, nzcv
stp x16, xzr, [sp, #-16]!
ldr x16, [x7, #400]
mov x17, #1234
add x16, x16, x17, lsl #3
ldr x17, [x16]
add x17, x17, #1
str x17, [x16]
ldp x16, xzr, [sp], #16
msr nzcv, x16
ldp x16, x17, [sp], #16
