from pathlib import Path
import json,importlib.util,collections,re,copy
w=Path(__file__).resolve().parent;sp=importlib.util.spec_from_file_location('fx',w/'a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);fns,labels,lits,sir,recs=m.layout_tables();owners={};f=None
for i,z in enumerate(sir,1):
 if z[0]==m.C['OP-FN']:f=z[1]
 owners[i]=f
site=lambda name,op:next(i for i,z in enumerate(sir,1) if owners[i]==fns[name] and z[0]==m.C['OP-'+op])
sumslot=site('sum','FUEL')*2;rootslot=site('r2_fuel2','FUEL')*2;clroot=site('cl_call3_0','FUEL')*2;clmask=site('cl_call3_0','CALL')*2+1
cal=json.loads((w/'calibration-proof.json').read_text());assert cal['cases']==42
for z in cal['rows']:
 expected={};fuel=z['fuel']
 if z['fixture']=='sum':expected[sumslot]=min(z['args'][0],fuel)
 elif z['fixture']=='r2_fuel2':expected[rootslot]=1;expected[sumslot]=min(2*z['args'][0],fuel-1)
 else:expected[clroot]=1;expected[clmask]=min(2,fuel-1)
 expected={k:v for k,v in expected.items() if v};assert dict(z['counts'])==expected,(z,expected)
obs=json.loads((w/'observations.json').read_text());c=json.loads((w/'product-census.json').read_text());s={int(z.split()[1]):list(map(int,z.split()[2:])) for z in (w/'product-compile.log').read_text().splitlines() if z.startswith('SIR ')};owner={i:int(f) for f,v in c['functions'].items() for i in range(v['start'],v['end']+1)};closed={x['fn'] for x in json.loads((w/'product-instruction-audit.json').read_text())['mode2Functions'] if x['workload']=='statemate'}
for z in obs['rows']:
 counts=collections.Counter()
 for x in z['sites']:
  assert x['site']<32768 and owner[x['site']]==x['fn'] and s[x['site']]==x['sir'];mode='closedMode2' if x['fn'] in closed else 'leaf' if c['functions'][str(x['fn'])]['leaf'] else 'nonleaf';assert mode==x['mode'];counts[mode]+=x['count'];counts['plain' if x['loweringKind']==0 else 'maskedInline']+=x['count']
 assert dict(counts)==z['categories'] and sum(x['count'] for x in z['sites'])==z['completedCharges']
 if z['observation']['exit']==0:assert z['completedCharges']==z['consumedFuel']
success=[z for z in obs['rows'] if z['initialFuel']==16777216];assert [z['consumedFuel'] for z in success]==[1,806,1545,12630,23715]
for z in success:assert z['categories'].get('closedMode2',0)==555*z['n']
# Negative controls: the independent exact-site oracle rejects lost, duplicate,
# wrong-site, and plain/masked counter substitution.
def gate(actual,expected):return dict(actual)==expected
z=next(z for z in cal['rows'] if z['fixture']=='cl_call3_0' and z['fuel']==3);expected=dict(z['counts']);bad=[]
for tag,changed in [('lost',[[clroot,1],[clmask,1]]),('duplicate',[[clroot,1],[clmask,3]]),('wrong-site',[[clroot,1],[clmask+2,2]]),('wrong-kind',[[clroot,1],[clmask-1,2]])]:assert not gate(changed,expected);bad.append(tag)
summary={'status':'complete-offline-independent-source-site-plain-masked-charge-and-original-observation-replay','originalStateGroups':30,'originalSupervisorExecutions':120,'independentCalibrationCases':42,'calibrationSupervisorExecutions':84,'mutationControlsRejected':bad,'successfulOriginalCounts':[{'n':z['n'],'completedCharges':z['completedCharges'],'categories':z['categories']} for z in success],'oneBodyClosedShareOfCharges':555/806,'subsequentBodyClosedShareOfCharges':555/739,'timingClaims':False,'productChanged':False,'freshNativeExecutionsInReplay':0};(w/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('PASS offline exact-site calibration, negative controls, source ownership and raw observations',json.dumps(summary))
