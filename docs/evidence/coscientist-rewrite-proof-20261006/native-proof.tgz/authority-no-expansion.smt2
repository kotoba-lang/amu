; benchmark generated from python API
(set-info :status unknown)
(declare-fun runtime () (_ BitVec 64))
(declare-fun policy () (_ BitVec 64))
(declare-fun delegation () (_ BitVec 64))
(declare-fun request () (_ BitVec 64))
(declare-fun compiler () (_ BitVec 64))
(assert
 (let ((?x63 (bvnot runtime)))
(let ((?x52 (bvand (bvand (bvand (bvand compiler request) delegation) policy) runtime)))
(or (and (distinct (bvand ?x52 (bvnot compiler)) (_ bv0 64)) true) (and (distinct (bvand ?x52 (bvnot request)) (_ bv0 64)) true) (and (distinct (bvand ?x52 (bvnot delegation)) (_ bv0 64)) true) (and (distinct (bvand ?x52 (bvnot policy)) (_ bv0 64)) true) (and (distinct (bvand ?x52 ?x63) (_ bv0 64)) true)))))
(check-sat)
