; benchmark generated from python API
(set-info :status unknown)
(declare-fun index () (_ BitVec 64))
(declare-fun base () (_ BitVec 64))
(assert
 (let (($x72 (and (distinct (bvadd base (bvshl index (_ bv3 64))) (bvadd base (bvshl index (_ bv2 64)))) true)))
(let (($x11 (bvule index (_ bv4095 64))))
(and $x11 $x72))))
(check-sat)
