; benchmark generated from python API
(set-info :status unknown)
(declare-fun remainingEligibleRoots () Int)
(assert
 (let (($x63 (or (< (- remainingEligibleRoots 1) 0) (>= (- remainingEligibleRoots 1) remainingEligibleRoots))))
(and (> remainingEligibleRoots 0) $x63)))
(check-sat)
