; benchmark generated from python API
(set-info :status unknown)
(declare-fun length () (_ BitVec 64))
(declare-fun index () (_ BitVec 64))
(assert
 (let (($x20 (= index (_ bv0 64))))
(and $x20 (not (bvult index length)))))
(check-sat)
