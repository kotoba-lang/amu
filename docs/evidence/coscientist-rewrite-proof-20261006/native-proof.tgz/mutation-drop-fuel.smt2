; benchmark generated from python API
(set-info :status unknown)
(declare-fun fuel () (_ BitVec 64))
(assert
 (and (distinct (bvsub fuel (_ bv1 64)) fuel) true))
(check-sat)
