; benchmark generated from python API
(set-info :status unknown)
(declare-fun index () (_ BitVec 64))
(declare-fun length () (_ BitVec 64))
(assert
 (let (($x11 (bvule index (_ bv4095 64))))
(and $x11 (and (distinct (bvult index length) (bvugt length index)) true))))
(check-sat)
