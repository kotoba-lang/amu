; benchmark generated from python API
(set-info :status unknown)
(declare-fun index () (_ BitVec 64))
(declare-fun x () (_ BitVec 64))
(declare-fun memory () (Array (_ BitVec 64) (_ BitVec 64)))
(assert
 (and (distinct (select (store memory x index) x) index) true))
(check-sat)
