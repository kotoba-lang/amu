; benchmark generated from python API
(set-info :status unknown)
(declare-fun index () (_ BitVec 64))
(declare-fun offset () (_ BitVec 64))
(declare-fun base () (_ BitVec 64))
(assert
 (let (($x37 (and (distinct (bvadd base (bvshl (bvadd offset index) (_ bv3 64))) (bvadd (bvadd base (bvshl offset (_ bv3 64))) (bvshl index (_ bv3 64)))) true)))
(let (($x11 (bvule index (_ bv4095 64))))
(and $x11 $x37))))
(check-sat)
