; benchmark generated from python API
(set-info :status unknown)
(declare-fun current () Bool)
(declare-fun issued () Bool)
(assert
 (and (not current) (and issued current)))
(check-sat)
