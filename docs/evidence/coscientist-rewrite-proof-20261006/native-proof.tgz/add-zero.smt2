; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () (_ BitVec 64))
(assert
 (and (distinct (bvadd x (_ bv0 64)) x) true))
(check-sat)
