; benchmark generated from python API
(set-info :status unknown)
(declare-fun current () Bool)
(declare-fun cached () Bool)
(assert
 (let (($x759 (not current)))
(and cached $x759)))
(check-sat)
