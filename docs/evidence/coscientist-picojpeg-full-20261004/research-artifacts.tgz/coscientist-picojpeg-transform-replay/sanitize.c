#include "c-bridge.c"
#include <stdio.h>
int main(void){for(int n=1;n<=32;n++)if(transform_selfcheck(n,0,0,0,0,0,0,0)!=1)return 1;
for(int phase=1;phase<=2;phase++)for(int n=1;n<=168;n++)for(int k=1536;k<1600;k++)if(observe(phase*1048576+n*4096+k,0,0,0,0,0,0,0)==INT64_MIN)return 2;
for(int n=1;n<=56;n++)for(int color=0;color<3;color++)for(int k=0;k<64;k++)if(observe(3*1048576+n*3*4096+2048+color*256+k,0,0,0,0,0,0,0)==INT64_MIN)return 3;
for(unsigned i=0;i<sizeof(terminal_fields)/sizeof(terminal_fields[0]);i++)if(observe(3*1048576+169*4096+terminal_fields[i],0,0,0,0,0,0,0)==INT64_MIN)return 4;
printf("PASS 32 original full-decoder/IDCT/RGB selfchecks, 33356 initialized reads\n");return 0;}
