/* BOOTSTRAP-TOOL: original IDCT/color boundaries; full original transforms retained. */
#define observe observe_headers
#include "headers-bridge.c"
#undef observe
static int64_t rows[168][64],cols[168][64],rgb[168][768];
static int captures,currentBlock;
static void save_coeff(int64_t dst[168][64]){for(int i=0;i<64;i++)dst[captures][i]=gCoeffBuf[i];}
static void save_rgb(void){for(int i=0;i<256;i++){rgb[captures][i]=gMCUBufR[i];rgb[captures][256+i]=gMCUBufG[i];rgb[captures][512+i]=gMCUBufB[i];}}
static void observed_transform(uint8 mcuBlock){

  idctRows (); save_coeff(rows);
  idctCols (); save_coeff(cols);

  switch (gScanType)
    {
    case PJPG_GRAYSCALE:
      {
	// MCU size: 1, 1 block per MCU
	copyY (0);
	break;
      }
    case PJPG_YH1V1:
      {
	// MCU size: 8x8, 3 blocks per MCU
	switch (mcuBlock)
	  {
	  case 0:
	    {
	      copyY (0);
	      break;
	    }
	  case 1:
	    {
	      convertCb (0);
	      break;
	    }
	  case 2:
	    {
	      convertCr (0);
	      break;
	    }
	  }

	break;
      }
    case PJPG_YH1V2:
      {
	// MCU size: 8x16, 4 blocks per MCU
	switch (mcuBlock)
	  {
	  case 0:
	    {
	      copyY (0);
	      break;
	    }
	  case 1:
	    {
	      copyY (128);
	      break;
	    }
	  case 2:
	    {
	      upsampleCbV (0, 0);
	      upsampleCbV (4 * 8, 128);
	      break;
	    }
	  case 3:
	    {
	      upsampleCrV (0, 0);
	      upsampleCrV (4 * 8, 128);
	      break;
	    }
	  }

	break;
      }
    case PJPG_YH2V1:
      {
	// MCU size: 16x8, 4 blocks per MCU
	switch (mcuBlock)
	  {
	  case 0:
	    {
	      copyY (0);
	      break;
	    }
	  case 1:
	    {
	      copyY (64);
	      break;
	    }
	  case 2:
	    {
	      upsampleCbH (0, 0);
	      upsampleCbH (4, 64);
	      break;
	    }
	  case 3:
	    {
	      upsampleCrH (0, 0);
	      upsampleCrH (4, 64);
	      break;
	    }
	  }

	break;
      }
    case PJPG_YH2V2:
      {
	// MCU size: 16x16, 6 blocks per MCU
	switch (mcuBlock)
	  {
	  case 0:
	    {
	      copyY (0);
	      break;
	    }
	  case 1:
	    {
	      copyY (64);
	      break;
	    }
	  case 2:
	    {
	      copyY (128);
	      break;
	    }
	  case 3:
	    {
	      copyY (192);
	      break;
	    }
	  case 4:
	    {
	      upsampleCb (0, 0);
	      upsampleCb (4, 64);
	      upsampleCb (4 * 8, 128);
	      upsampleCb (4 + 4 * 8, 192);
	      break;
	    }
	  case 5:
	    {
	      upsampleCr (0, 0);
	      upsampleCr (4, 64);
	      upsampleCr (4 * 8, 128);
	      upsampleCr (4 + 4 * 8, 192);
	      break;
	    }
	  }

	break;
      }
    }

}
static uint8 observed_decode(void){

  uint8 status;
  uint8 mcuBlock;

  if (gRestartInterval)
    {
      if (gRestartsLeft == 0)
	{
	  status = processRestart ();
	  if (status)
	    return status;
	}
      gRestartsLeft--;
    }

  for (mcuBlock = 0; mcuBlock < gMaxBlocksPerMCU; mcuBlock++)
    {
      uint8 componentID = gMCUOrg[mcuBlock];
      uint8 compQuant = gCompQuant[componentID];
      uint8 compDCTab = gCompDCTab[componentID];
      uint8 numExtraBits, compACTab, k;
      const int16 *pQ = compQuant ? gQuant1 : gQuant0;
      uint16 r, dc;

      uint8 s =
	huffDecode (compDCTab ? &gHuffTab1 : &gHuffTab0,
		    compDCTab ? gHuffVal1 : gHuffVal0);

      r = 0;
      numExtraBits = s & 0xF;
      if (numExtraBits)
	r = getBits2 (numExtraBits);
      dc = huffExtend (r, s);

      dc = dc + gLastDC[componentID];
      gLastDC[componentID] = dc;

      gCoeffBuf[0] = dc * pQ[0];

      compACTab = gCompACTab[componentID];

      if (gReduce)
	{
	  // Decode, but throw out the AC coefficients in reduce mode.
	  for (k = 1; k < 64; k++)
	    {
	      s =
		huffDecode (compACTab ? &gHuffTab3 : &gHuffTab2,
			    compACTab ? gHuffVal3 : gHuffVal2);

	      numExtraBits = s & 0xF;
	      if (numExtraBits)
		getBits2 (numExtraBits);

	      r = s >> 4;
	      s &= 15;

	      if (s)
		{
		  if (r)
		    {
		      if ((k + r) > 63)
			return PJPG_DECODE_ERROR;

		      k = (uint8) (k + r);
		    }
		}
	      else
		{
		  if (r == 15)
		    {
		      if ((k + 16) > 64)
			return PJPG_DECODE_ERROR;

		      k += (16 - 1);	// - 1 because the loop counter is k
		    }
		  else
		    break;
		}
	    }

	  transformBlockReduce (mcuBlock);
	}
      else
	{
	  // Decode and dequantize AC coefficients
	  for (k = 1; k < 64; k++)
	    {
	      uint16 extraBits;

	      s =
		huffDecode (compACTab ? &gHuffTab3 : &gHuffTab2,
			    compACTab ? gHuffVal3 : gHuffVal2);

	      extraBits = 0;
	      numExtraBits = s & 0xF;
	      if (numExtraBits)
		extraBits = getBits2 (numExtraBits);

	      r = s >> 4;
	      s &= 15;

	      if (s)
		{
		  int16 ac;

		  if (r)
		    {
		      if ((k + r) > 63)
			return PJPG_DECODE_ERROR;

		      while (r)
			{
			  gCoeffBuf[ZAG[k++]] = 0;
			  r--;
			}
		    }

		  ac = huffExtend (extraBits, s);

		  gCoeffBuf[ZAG[k]] = ac * pQ[k];
		}
	      else
		{
		  if (r == 15)
		    {
		      if ((k + 16) > 64)
			return PJPG_DECODE_ERROR;

		      for (r = 16; r > 0; r--)
			gCoeffBuf[ZAG[k++]] = 0;

		      k--;	// - 1 because the loop counter is k
		    }
		  else
		    break;
		}
	    }

	  while (k < 64)
	    gCoeffBuf[ZAG[k++]] = 0;

	  observed_transform(mcuBlock); save_rgb(); currentBlock=mcuBlock; captures++;
	}
    }

  return 0;

}
static int64_t pixel_value(int cell){if(cell>=1536&&cell<1600)return gCoeffBuf[cell-1536];if(cell>=2048&&cell<2304)return gMCUBufR[cell-2048];if(cell>=2304&&cell<2560)return gMCUBufG[cell-2304];if(cell>=2560&&cell<2816)return gMCUBufB[cell-2560];if(cell==1610)return currentBlock;return cellvalue(cell);}
static int prepare(void){memset(gCoeffBuf,0,sizeof(gCoeffBuf));memset(gMCUBufR,0,sizeof(gMCUBufR));memset(gMCUBufG,0,sizeof(gMCUBufG));memset(gMCUBufB,0,sizeof(gMCUBufB));stages(3);captures=0;currentBlock=0;
 if(lastStatus||gReduce||gRestartInterval||gMaxBlocksPerMCU!=3||gNumMCUSRemaining!=56)return 0;
 pInfo.m_pMCUBufR=gMCUBufR;pInfo.m_pMCUBufG=gMCUBufG;pInfo.m_pMCUBufB=gMCUBufB;
 while(gNumMCUSRemaining){lastStatus=observed_decode();if(lastStatus)return 0;gNumMCUSRemaining--;}
 lastStatus=pjpeg_decode_mcu();return captures==168&&lastStatus==PJPG_NO_MORE_BLOCKS&&verify_benchmark(0);}
int64_t observe(int64_t encoded,EXTRA){int phase=encoded/1048576,rest=encoded%1048576,n=rest/4096,cell=rest%4096;
 if(encoded<0||n>169||phase<1||phase>3||!prepare())return INT64_MIN;
 if(n==169)return pixel_value(cell);if(n==0)return INT64_MIN;
 if((phase==1||phase==2)&&cell>=1536&&cell<1600)return phase==1?rows[n-1][cell-1536]:cols[n-1][cell-1536];
 if(phase==3&&cell>=2048&&cell<2816)return rgb[n-1][cell-2048];return INT64_MIN;}
static const int terminal_fields[]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,1510,1511,1512,1413,1520,1536,1537,1538,1539,1540,1541,1542,1543,1544,1545,1546,1547,1548,1549,1550,1551,1552,1553,1554,1555,1556,1557,1558,1559,1560,1561,1562,1563,1564,1565,1566,1567,1568,1569,1570,1571,1572,1573,1574,1575,1576,1577,1578,1579,1580,1581,1582,1583,1584,1585,1586,1587,1588,1589,1590,1591,1592,1593,1594,1595,1596,1597,1598,1599,2048,2049,2050,2051,2052,2053,2054,2055,2056,2057,2058,2059,2060,2061,2062,2063,2064,2065,2066,2067,2068,2069,2070,2071,2072,2073,2074,2075,2076,2077,2078,2079,2080,2081,2082,2083,2084,2085,2086,2087,2088,2089,2090,2091,2092,2093,2094,2095,2096,2097,2098,2099,2100,2101,2102,2103,2104,2105,2106,2107,2108,2109,2110,2111,2112,2113,2114,2115,2116,2117,2118,2119,2120,2121,2122,2123,2124,2125,2126,2127,2128,2129,2130,2131,2132,2133,2134,2135,2136,2137,2138,2139,2140,2141,2142,2143,2144,2145,2146,2147,2148,2149,2150,2151,2152,2153,2154,2155,2156,2157,2158,2159,2160,2161,2162,2163,2164,2165,2166,2167,2168,2169,2170,2171,2172,2173,2174,2175,2176,2177,2178,2179,2180,2181,2182,2183,2184,2185,2186,2187,2188,2189,2190,2191,2192,2193,2194,2195,2196,2197,2198,2199,2200,2201,2202,2203,2204,2205,2206,2207,2208,2209,2210,2211,2212,2213,2214,2215,2216,2217,2218,2219,2220,2221,2222,2223,2224,2225,2226,2227,2228,2229,2230,2231,2232,2233,2234,2235,2236,2237,2238,2239,2240,2241,2242,2243,2244,2245,2246,2247,2248,2249,2250,2251,2252,2253,2254,2255,2256,2257,2258,2259,2260,2261,2262,2263,2264,2265,2266,2267,2268,2269,2270,2271,2272,2273,2274,2275,2276,2277,2278,2279,2280,2281,2282,2283,2284,2285,2286,2287,2288,2289,2290,2291,2292,2293,2294,2295,2296,2297,2298,2299,2300,2301,2302,2303,2304,2305,2306,2307,2308,2309,2310,2311,2312,2313,2314,2315,2316,2317,2318,2319,2320,2321,2322,2323,2324,2325,2326,2327,2328,2329,2330,2331,2332,2333,2334,2335,2336,2337,2338,2339,2340,2341,2342,2343,2344,2345,2346,2347,2348,2349,2350,2351,2352,2353,2354,2355,2356,2357,2358,2359,2360,2361,2362,2363,2364,2365,2366,2367,2368,2369,2370,2371,2372,2373,2374,2375,2376,2377,2378,2379,2380,2381,2382,2383,2384,2385,2386,2387,2388,2389,2390,2391,2392,2393,2394,2395,2396,2397,2398,2399,2400,2401,2402,2403,2404,2405,2406,2407,2408,2409,2410,2411,2412,2413,2414,2415,2416,2417,2418,2419,2420,2421,2422,2423,2424,2425,2426,2427,2428,2429,2430,2431,2432,2433,2434,2435,2436,2437,2438,2439,2440,2441,2442,2443,2444,2445,2446,2447,2448,2449,2450,2451,2452,2453,2454,2455,2456,2457,2458,2459,2460,2461,2462,2463,2464,2465,2466,2467,2468,2469,2470,2471,2472,2473,2474,2475,2476,2477,2478,2479,2480,2481,2482,2483,2484,2485,2486,2487,2488,2489,2490,2491,2492,2493,2494,2495,2496,2497,2498,2499,2500,2501,2502,2503,2504,2505,2506,2507,2508,2509,2510,2511,2512,2513,2514,2515,2516,2517,2518,2519,2520,2521,2522,2523,2524,2525,2526,2527,2528,2529,2530,2531,2532,2533,2534,2535,2536,2537,2538,2539,2540,2541,2542,2543,2544,2545,2546,2547,2548,2549,2550,2551,2552,2553,2554,2555,2556,2557,2558,2559,2560,2561,2562,2563,2564,2565,2566,2567,2568,2569,2570,2571,2572,2573,2574,2575,2576,2577,2578,2579,2580,2581,2582,2583,2584,2585,2586,2587,2588,2589,2590,2591,2592,2593,2594,2595,2596,2597,2598,2599,2600,2601,2602,2603,2604,2605,2606,2607,2608,2609,2610,2611,2612,2613,2614,2615,2616,2617,2618,2619,2620,2621,2622,2623,2624,2625,2626,2627,2628,2629,2630,2631,2632,2633,2634,2635,2636,2637,2638,2639,2640,2641,2642,2643,2644,2645,2646,2647,2648,2649,2650,2651,2652,2653,2654,2655,2656,2657,2658,2659,2660,2661,2662,2663,2664,2665,2666,2667,2668,2669,2670,2671,2672,2673,2674,2675,2676,2677,2678,2679,2680,2681,2682,2683,2684,2685,2686,2687,2688,2689,2690,2691,2692,2693,2694,2695,2696,2697,2698,2699,2700,2701,2702,2703,2704,2705,2706,2707,2708,2709,2710,2711,2712,2713,2714,2715,2716,2717,2718,2719,2720,2721,2722,2723,2724,2725,2726,2727,2728,2729,2730,2731,2732,2733,2734,2735,2736,2737,2738,2739,2740,2741,2742,2743,2744,2745,2746,2747,2748,2749,2750,2751,2752,2753,2754,2755,2756,2757,2758,2759,2760,2761,2762,2763,2764,2765,2766,2767,2768,2769,2770,2771,2772,2773,2774,2775,2776,2777,2778,2779,2780,2781,2782,2783,2784,2785,2786,2787,2788,2789,2790,2791,2792,2793,2794,2795,2796,2797,2798,2799,2800,2801,2802,2803,2804,2805,2806,2807,2808,2809,2810,2811,2812,2813,2814,2815};
int64_t transform_selfcheck(int64_t n,EXTRA){if(n<1||n>32||!prepare())return 0;int64_t saved[sizeof(terminal_fields)/sizeof(terminal_fields[0])];
 for(unsigned i=0;i<sizeof(terminal_fields)/sizeof(terminal_fields[0]);i++)saved[i]=pixel_value(terminal_fields[i]);
 benchmark_body(1,n);lastStatus=pjpeg_decode_mcu();if(lastStatus!=PJPG_NO_MORE_BLOCKS||!verify_benchmark(0))return 0;
 for(unsigned i=0;i<sizeof(terminal_fields)/sizeof(terminal_fields[0]);i++)if(saved[i]!=pixel_value(terminal_fields[i]))return 0;return 1;}
