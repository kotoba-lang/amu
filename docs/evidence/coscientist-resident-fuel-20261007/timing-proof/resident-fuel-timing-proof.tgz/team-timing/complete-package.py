from pathlib import Path
import json,hashlib,shutil,tarfile,subprocess
W=Path(__file__).parent;H=W.parent;P=W/'timing-package';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');load=lambda p:json.loads(p.read_text())
shutil.copy2(H/'root/preflight-ISA-decision.json',P/'root-retained-ISA-decision.json');shutil.copy2(H/'root/remote-feature-read.json',P/'root-early-remote-feature-read.json');shutil.copy2(W/'preregistration-supplement-fuel.json',P/'preregistration-supplement-fuel.json')
for name,source in [('measure-native-candidate-v2.py',Path('/private/tmp/amu-closed-chain-fuel-20261006/timing-package/measure-native-candidate-v2.py')),('darwin_cpu_idle.py',Path('/Users/junkawasaki/github/wt/amu-seed17/scripts/seed/image/darwin_cpu_idle.py'))]:shutil.copy2(source,P/('source-template-'+name));shutil.copy2(source,P/name)
# Only descriptor admission and rootpermission assertions change; no timingstat thresholds.
s=(P/'measure-native-candidate-v2.py').read_text().replace("baseline['status']=='complete-provisional-timing'","baseline['status']=='prepared-current-input-descriptor'")
needle="matrix_path=a.spec.parent/'comparison-matrix.json';"
assert s.count(needle)==1
s=s.replace(needle,"""go=json.loads((a.spec.parent/'ROOT-GO.json').read_text())
require(go.get('performanceAuthorized') is True,'performance is not root authorized')
require(go['preregistrationSHA256']==sha(a.spec.parent/'preregistration.json'),'rootGO prereg pin')
require(go['packageInputPinsSHA256']==sha(a.spec.parent/'package-input-pins.json'),'rootGO package pin')
"""+needle)
(P/'measure-native-candidate-v2.py').write_text(s)
for row in load(W/'build-report.json')['entries']:
 d=P/row['workload'];bd=d/'baseline';cd=d/'candidate';(bd/row['workload']).mkdir(parents=True);cd.mkdir();shutil.copy2(d/'baseline.bin',bd/row['workload']/'native.bin');shutil.copy2(d/'c.dylib',bd/row['workload']/'c.dylib');shutil.copy2(d/'candidate.bin',cd/'native.bin')
 write(bd/'results.json',{'status':'prepared-current-input-descriptor','entries':[{'workload':row['workload'],'iterationsPerCall':row['n'],'cSymbol':row['Csymbol'],'cDylibSha256':row['CbinarySHA256'],'nativeSha256':row['baselineNativeSHA256'],'offset':row['baselineOffset']}],'runnerSha256':row['runnerSHA256'],'matrixSpecSha256':sha(P/'comparison-matrix.json'),'derivation':'CurrentbaselineAESv2 byteidentity only; no historic timingdata.'})
 write(cd/'manifest.json',{'workload':row['workload'],'offset':row['candidateOffset'],'nativeSha256':row['candidateNativeSHA256'],'sourceSha256':row['sourceSHA256'],'baselineSourceSha256':row['sourceSHA256'],'compilerGenerationSha256':{str(g['generation']):g['sha256'] for g in load(P/'producer/candidate/fixed-point.json')['generations']},'expectedFuelPerCall':row['expectedNativeFuelConsumed'],'featureRecipe':'immutablehostheader required6; explicitresident1/no genericembedding claim','headerSHA256':row['immutableHeaderSHA256']})
(P/'semantic-preflight.py').write_text('''from pathlib import Path
import json,hashlib,subprocess,os,datetime,socket
P=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\\n');pr=json.loads((P/'preregistration.json').read_text())
assert str(P.parent)==pr['remoteRoot'],'unexpected remote root'
assert not (P/'semantic-preflight.json').exists(),'refusing to overwrite semantic receipts'
pins=json.loads((P/'package-input-pins.json').read_text())
for p,h in pins.items():assert sha(P/p)==h,p
feature={}
for name,args in [('architecture',['uname','-m']),('AES',['/usr/sbin/sysctl','-n','hw.optional.arm.FEAT_AES']),('host',['hostname']),('model',['/usr/sbin/sysctl','-n','hw.model']),('load',['/usr/sbin/sysctl','-n','vm.loadavg'])]:
 q=subprocess.run(args,capture_output=True,text=True);feature[name]={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
write(P/'fresh-remote-feature.json',{'timeUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fields':feature,'performanceAuthorized':False})
assert feature['architecture']['exit']==0 and feature['architecture']['stdout'].strip()=='arm64'
assert feature['AES']['exit']==0 and feature['AES']['stdout'].strip()=='1'
assert socket.gethostname().split('.')[0]==json.loads((P/'paired-timing-spec.json').read_text())['host']
report={'status':'running semantic preparation only','entries':[],'performanceCalls':0,'diagnosticElapsedNotStatistics':True}
write(P/'semantic-preflight.json',report)
for row in json.loads((P/'compiled-manifest.json').read_text())['entries']:
 d=P/row['workload'];assert sha(d/'runner')==row['runnerSHA256'];entries=[]
 for arm,kind,file,entry in [('baseline','raw','baseline.bin',str(row['baselineOffset'])),('candidate','raw','candidate.bin',str(row['candidateOffset'])),('C','dylib','c.dylib',row['Csymbol'])]:
  q=subprocess.run([str(d/'runner'),kind,str(d/file),entry,'aarch64',str(row['n']),'1','0','16777216'],capture_output=True,text=True,timeout=30)
  raw={'workload':row['workload'],'arm':arm,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr,'diagnosticElapsedNotStatistics':True};write(d/('semantic-'+arm+'.json'),raw)
  assert q.returncode==0,raw;r=json.loads(q.stdout);assert r['result']==1 and r['calls']==1 and r['warmupCalls']==0,raw
  expected=0 if arm=='C' else row['expectedNativeFuelConsumed'];assert r['contextFuelBefore']==16777216 and r['contextFuelConsumed']==expected and r['contextFuelAfter']==16777216-expected,raw
  entries.append(raw)
 report['entries'].append({'workload':row['workload'],'n':row['n'],'expectedNativeFuel':row['expectedNativeFuelConsumed'],'arms':entries});write(P/'semantic-preflight.json',report);print('PASS PREFLIGHT',row['workload'],flush=True)
assert len(report['entries'])==19
report.update(status='PASS57fresh admittedhost semantic calls; no performance campaign',calls=57);write(P/'semantic-preflight.json',report)
''')
(P/'campaign-run.py').write_text('''from pathlib import Path
import json,hashlib,subprocess,os
P=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\\n');go=json.loads((P/'ROOT-GO.json').read_text())
assert go['performanceAuthorized'] is True and go['preregistrationSHA256']==sha(P/'preregistration.json') and go['packageInputPinsSHA256']==sha(P/'package-input-pins.json')
assert go['remoteSemanticReportSHA256']==sha(P/'semantic-preflight.json')
assert json.loads((P/'semantic-preflight.json').read_text())['calls']==57
assert not (P/'campaign.json').exists(),'refusing to replace campaign'
for p,h in json.loads((P/'package-input-pins.json').read_text()).items():assert sha(P/p)==h,p
report={'status':'running singlefresh original19campaign','entries':[],'noRetry':True};write(P/'campaign.json',report)
for row in json.loads((P/'compiled-manifest.json').read_text())['entries']:
 d=P/row['workload'];print('START',row['workload'],flush=True)
 with (d/'timing.log').open('w') as log:q=subprocess.run(['python3',str(P/'measure-native-candidate-v2.py'),str(d/'baseline'),str(d/'candidate'),str(d/'runner'),str(P/'paired-timing-spec.json'),str(d/'timing')],stdout=log,stderr=subprocess.STDOUT)
 result=json.loads((d/'timing/results.json').read_text());report['entries'].append({'workload':row['workload'],'exit':q.returncode,'status':result['status'],'acceptedTriples':result.get('acceptedTriples'),'attemptedTriples':result.get('attemptedTriples'),'summary':result.get('summary'),'failure':result.get('failure')});write(P/'campaign.json',report);print('FINISH',row['workload'],q.returncode,flush=True)
report['status']='terminal-onecampaign all19 attempted';write(P/'campaign.json',report)
''')
write(P/'measurement-helper-delta.json',{'scope':'Template descriptor label changed to prepared-current-input-descriptor plus explicitROOTGO source/package pins before calibration; originaltimedloop/helperstat protocol otherwiseunchanged','originalSHA256':sha(P/'source-template-measure-native-candidate-v2.py'),'currentSHA256':sha(P/'measure-native-candidate-v2.py'),'performanceCalls':0})
(P/'compiler-version.stdout').write_text(subprocess.check_output(['clang','--version'],text=True));(P/'local-build-uname.stdout').write_text(subprocess.check_output(['uname','-a'],text=True))
packagePins={str(p.relative_to(P)):sha(p) for p in sorted(P.rglob('*')) if p.is_file() and p.name!='package-input-pins.json'};write(P/'package-input-pins.json',packagePins)
pre={'status':'READY19immutablehosts andcode/header/Cinputs; ROOT review required BEFORE57remote guestcalls','compiledHosts':19,'nativeAndCThreeArmsSameRunner':True,'candidateOnlyChanged':'nettle-aes','actualGuestCalls':0,'performanceAuthorized':False,'sourceSHA256':sha(P/'timing-host.c'),'packageInputPinsSHA256':sha(P/'package-input-pins.json'),'packagePins':len(packagePins),'preregSHA256':sha(W/'preregistration.json'),'minimalDescriptorsExcludeHistoricStatistics':True,'CcompilerMetadata':'Unknownexactversion/flags forinheritedoriginalCbinaries explicitlyretained; matchedbyte/sourcebridge/archivepins checked','semanticExpectedFuel':{'successfulCurrent99':14,'unchanged4PriorSuccessfulAESv2Bridge':['picojpeg','qrduino','wikisort','xgboost'],'depthconvPriorN2000Fuel':70034,'fresh57VerificationMandatory':True},'retainedISA':'EarlieractualM4 132/unchanged9words retainedonly; no new132 calibration perrootdecision','setupFailures':[{'directory':'setup-failure-fuel-cap','reason':'Beforeanybuild/guest,99n32fuel1Mtrap equality misassumedsuccess. Correctedinheritedexactcode fuelbridge; no oracle/statthreshold adjustment.'}],'GOformatRequired':{'performanceAuthorized':True,'preregistrationSHA256':'must match prereg','packageInputPinsSHA256':'mustmatch package-input-pins','remoteSemanticReportSHA256':'mustmatchnew57report'},'rootGOIssued':False}
write(W/'preflight-prepared.json',pre)
with tarfile.open(W/'timing-package-prepared.tgz','w:gz') as tf:tf.add(P,arcname='timing-package')
write(W/'prepared-artifacts.json',{'preflightSHA256':sha(W/'preflight-prepared.json'),'archiveSHA256':sha(W/'timing-package-prepared.tgz'),'archiveBytes':(W/'timing-package-prepared.tgz').stat().st_size,'sourceSHA256':sha(P/'timing-host.c'),'preregSHA256':sha(W/'preregistration.json'),'performanceAuthorized':False})
print('READY PACKAGE',sha(W/'preflight-prepared.json'),sha(W/'timing-package-prepared.tgz'),len(packagePins))
