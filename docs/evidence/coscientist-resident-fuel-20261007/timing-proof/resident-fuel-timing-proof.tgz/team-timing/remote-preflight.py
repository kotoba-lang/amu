from pathlib import Path
import subprocess,json,hashlib,shlex
W=Path(__file__).parent;pr=json.loads((W/'preregistration.json').read_text());host=pr['hostSSH'];remote=pr['remoteRoot'];key='/Users/junkawasaki/.ssh/murakumo';archive=W/'timing-package-prepared.tgz';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();expected=json.loads((W/'prepared-artifacts.json').read_text())['archiveSHA256'];assert sha(archive)==expected
trust=W.parent/'root/destination-trust-review.json';t=json.loads(trust.read_text());assert t['sameUserAsSelf'] and t['online'] and t['targetIP']=='100.66.28.79'
def run(label,args):
 q=subprocess.run(args,capture_output=True,text=True);r={'phase':label,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};(W/('remote-'+label+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(label,q.returncode,q.stdout,q.stderr,flush=True);assert q.returncode==0,r
ssh=['ssh','-i',key,'-o','BatchMode=yes',host]
run('mkdir',ssh+['mkdir '+shlex.quote(remote)])
run('transfer',['scp','-i',key,str(archive),host+':'+remote+'/timing-package-prepared.tgz'])
cmd='cd '+shlex.quote(remote)+" && python3 -c "+shlex.quote("import hashlib;from pathlib import Path;assert hashlib.sha256(Path('timing-package-prepared.tgz').read_bytes()).hexdigest()=='"+expected+"'")+" && tar xzf timing-package-prepared.tgz && python3 timing-package/semantic-preflight.py"
q=subprocess.run(ssh+[cmd],capture_output=True,text=True);r={'phase':'finite57semantic-only','exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr,'archiveSHA256':expected,'performanceAuthorized':False};(W/'remote-semantic-run.json').write_text(json.dumps(r,indent=2)+'\n');print('SEMANTIC TERMINAL',q.returncode,q.stdout,q.stderr,flush=True)
run('collect',['scp','-r','-i',key,host+':'+remote+'/timing-package',str(W/'remote-preflight-evidence')]);assert q.returncode==0,r
