from pathlib import Path
import json,hashlib,subprocess,os,datetime,socket
P=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');pr=json.loads((P/'preregistration.json').read_text())
assert str(P.parent)==pr['remoteRoot'],'unexpected remote root'
assert not (P/'semantic-preflight.json').exists(),'refusing to overwrite semantic receipts'
pins=json.loads((P/'package-input-pins.json').read_text())
for p,h in pins.items():assert sha(P/p)==h,p
feature={}
for name,args in [('architecture',['uname','-m']),('AES',['/usr/sbin/sysctl','-n','hw.optional.arm.FEAT_AES']),('host',['hostname']),('model',['/usr/sbin/sysctl','-n','hw.model']),('load',['/usr/sbin/sysctl','-n','vm.loadavg'])]:
 q=subprocess.run(args,capture_output=True,text=True);feature[name]={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
write(P/'fresh-remote-feature.json',{'timeUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fields':feature,'performanceAuthorized':False})
assert feature['architecture']['exit']==0 and feature['architecture']['stdout'].strip()=='arm64'
assert feature['AES']['exit']==0 and feature['AES']['stdout'].strip()=='1'
assert socket.gethostname().split('.')[0]==json.loads((P/'paired-timing-spec.json').read_text())['host']
report={'status':'running semantic preparation only','entries':[],'performanceCalls':0,'diagnosticElapsedNotStatistics':True}
write(P/'semantic-preflight.json',report)
for row in json.loads((P/'compiled-manifest.json').read_text())['entries']:
 d=P/row['workload'];assert sha(d/'runner')==row['runnerSHA256'];entries=[]
 for arm,kind,file,entry in [('baseline','raw','baseline.bin',str(row['baselineOffset'])),('candidate','raw','candidate.bin',str(row['candidateOffset'])),('C','dylib','c.dylib',row['Csymbol'])]:
  q=subprocess.run([str(d/'runner'),kind,str(d/file),entry,'aarch64',str(row['n']),'1','0','16777216'],capture_output=True,text=True,timeout=30)
  raw={'workload':row['workload'],'arm':arm,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr,'diagnosticElapsedNotStatistics':True};write(d/('semantic-'+arm+'.json'),raw)
  assert q.returncode==0,raw;r=json.loads(q.stdout);assert r['result']==1 and r['calls']==1 and r['warmupCalls']==0,raw
  expected=0 if arm=='C' else row['expectedNativeFuelConsumed'];assert r['contextFuelBefore']==16777216 and r['contextFuelConsumed']==expected and r['contextFuelAfter']==16777216-expected,raw
  entries.append(raw)
 report['entries'].append({'workload':row['workload'],'n':row['n'],'expectedNativeFuel':row['expectedNativeFuelConsumed'],'arms':entries});write(P/'semantic-preflight.json',report);print('PASS PREFLIGHT',row['workload'],flush=True)
assert len(report['entries'])==19
report.update(status='PASS57fresh admittedhost semantic calls; no performance campaign',calls=57);write(P/'semantic-preflight.json',report)
