from pathlib import Path
import json,hashlib,subprocess,os
P=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');go=json.loads((P/'ROOT-GO.json').read_text())
assert go['performanceAuthorized'] is True and go['preregistrationSHA256']==sha(P/'preregistration.json') and go['packageInputPinsSHA256']==sha(P/'package-input-pins.json')
assert go['remoteSemanticReportSHA256']==sha(P/'semantic-preflight.json')
assert json.loads((P/'semantic-preflight.json').read_text())['calls']==57
assert not (P/'campaign.json').exists(),'refusing to replace campaign'
for p,h in json.loads((P/'package-input-pins.json').read_text()).items():assert sha(P/p)==h,p
report={'status':'running singlefresh original19campaign','entries':[],'noRetry':True};write(P/'campaign.json',report)
for row in json.loads((P/'compiled-manifest.json').read_text())['entries']:
 d=P/row['workload'];print('START',row['workload'],flush=True)
 with (d/'timing.log').open('w') as log:q=subprocess.run(['python3',str(P/'measure-native-candidate-v2.py'),str(d/'baseline'),str(d/'candidate'),str(d/'runner'),str(P/'paired-timing-spec.json'),str(d/'timing')],stdout=log,stderr=subprocess.STDOUT)
 result=json.loads((d/'timing/results.json').read_text());report['entries'].append({'workload':row['workload'],'exit':q.returncode,'status':result['status'],'acceptedTriples':result.get('acceptedTriples'),'attemptedTriples':result.get('attemptedTriples'),'summary':result.get('summary'),'failure':result.get('failure')});write(P/'campaign.json',report);print('FINISH',row['workload'],q.returncode,flush=True)
report['status']='terminal-onecampaign all19 attempted';write(P/'campaign.json',report)
