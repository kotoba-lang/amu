from pathlib import Path
import json,hashlib,statistics,math
W=Path(__file__).parent;P=W/'remote-campaign-evidence';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();run=json.loads((W/'remote-campaign-run.json').read_text());assert run['exit']==0
pins=json.loads((W/'timing-package/package-input-pins.json').read_text());assert len(pins)==412
for rel,h in pins.items():assert sha(P/rel)==h,rel
spec=json.loads((P/'paired-timing-spec.json').read_text());campaign=json.loads((P/'campaign.json').read_text());assert len(campaign['entries'])==19
results=[]
for entry in campaign['entries']:
 name=entry['workload'];d=P/name;r=json.loads((d/'timing/results.json').read_text());out={'workload':name,'status':r['status'],'nativeBytesChanged':sha(d/'baseline.bin')!=sha(d/'candidate.bin'),'acceptedTriples':r.get('acceptedTriples',0),'attemptedTriples':r.get('attemptedTriples',0),'failure':r.get('failure'),'rawReportSHA256':sha(d/'timing/results.json')}
 if 'summary' in r:
  n=json.loads((d/'baseline/results.json').read_text())['entries'][0]['iterationsPerCall'];stats={}
  for arm in ['baseline','candidate','C']:
   xs=[z['elapsedNanoseconds']/(z['calls']*n) for z in r['rows'] if z['arm']==arm and z['accepted']];assert len(xs)==30
   mu=statistics.mean(xs);sd=statistics.stdev(xs);stats[arm]={'meanNsPerBody':mu,'sdNs':sd,'relativeSd':sd/mu,'samples':len(xs)}
   assert stats[arm]==r['summary'][arm]
  b=stats['baseline'];c=stats['candidate'];ref=stats['C'];stable=max(z['relativeSd'] for z in stats.values())<=spec['maximumRelativeSd'];gain=stable and b['meanNsPerBody']/c['meanNsPerBody']>=spec['minimumSpeedup'] and b['meanNsPerBody']-c['meanNsPerBody']>b['sdNs']+c['sdNs'];regress=stable and c['meanNsPerBody']/b['meanNsPerBody']>=spec['minimumSpeedup'] and c['meanNsPerBody']-b['meanNsPerBody']>b['sdNs']+c['sdNs'];cbetter=stable and ref['meanNsPerBody']/c['meanNsPerBody']>=spec['minimumSpeedup'] and ref['meanNsPerBody']-c['meanNsPerBody']>ref['sdNs']+c['sdNs']
  assert stable==r['summary']['stable'] and gain==r['summary']['candidateImprovesBaseline']
  out.update(stats=stats,stable=stable,baselineOverCandidate=b['meanNsPerBody']/c['meanNsPerBody'],candidateOverC=c['meanNsPerBody']/ref['meanNsPerBody'],qualifiedGain=gain,qualifiedRegression=regress,qualifiedCandidateBetterThanC=cbetter,changedCodeGain=gain and out['nativeBytesChanged'])
 results.append(out)
allstable=all(z.get('stable',False) for z in results);report={'status':'OWNER raw-derived final statistics; independent audit pending','oneCampaign':True,'workloads':19,'all19Stable':allstable,'entries':results,'acceptedTriples':sum(z['acceptedTriples'] for z in results),'attemptedTriples':sum(z['attemptedTriples'] for z in results),'qualifiedChangedGains':[z['workload'] for z in results if z.get('changedCodeGain')],'qualifiedRegressions':[z['workload'] for z in results if z.get('qualifiedRegression')],'candidateBetterThanC':[z['workload'] for z in results if z.get('qualifiedCandidateBetterThanC')],'officialEmbenchScore':False,'productAdoption':False,'historicalStatisticsUsed':False,'semanticElapsedUsed':False,'baseline':'AESv2 8e35; not source-adopted product','candidate':'resident fuel a236; experimental required host features6'}
if allstable:
 geo=lambda xs:math.exp(statistics.mean([math.log(x) for x in xs]));report['all19GeometricBaselineOverCandidate']=geo([z['baselineOverCandidate'] for z in results]);report['all19GeometricCandidateOverC']=geo([z['candidateOverC'] for z in results])
(W/'campaign-owner-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='entries'},indent=2))
