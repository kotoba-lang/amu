from pathlib import Path
import subprocess,json,hashlib,shlex
W=Path(__file__).parent;go=W.parent/'root/ROOT-GO.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();g=json.loads(go.read_text());assert g['performanceAuthorized'] is True
P=W/'timing-package';R=W/'remote-preflight-evidence';assert g['preregistrationSHA256']==sha(P/'preregistration.json') and g['packageInputPinsSHA256']==sha(P/'package-input-pins.json') and g['remoteSemanticReportSHA256']==sha(R/'semantic-preflight.json')
pr=json.loads((W/'preregistration.json').read_text());host=pr['hostSSH'];remote=pr['remoteRoot'];key='/Users/junkawasaki/.ssh/murakumo';ssh=['ssh','-i',key,'-o','BatchMode=yes',host]
def run(label,args):
 q=subprocess.run(args,capture_output=True,text=True);r={'phase':label,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};(W/('campaign-'+label+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(label,q.returncode,q.stdout,q.stderr,flush=True);assert q.returncode==0,r
run('nooverwrite',ssh+['test ! -e '+shlex.quote(remote+'/timing-package/ROOT-GO.json')+' && test ! -e '+shlex.quote(remote+'/timing-package/campaign.json')])
run('go-transfer',['scp','-i',key,str(go),host+':'+remote+'/timing-package/ROOT-GO.json'])
cmd='cd '+shlex.quote(remote)+" && python3 -c "+shlex.quote("import hashlib;from pathlib import Path;assert hashlib.sha256(Path('timing-package/ROOT-GO.json').read_bytes()).hexdigest()=='"+sha(go)+"'")+" && python3 timing-package/campaign-run.py"
q=subprocess.run(ssh+[cmd],capture_output=True,text=True);r={'phase':'one-original19-campaign','exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr,'rootGoSHA256':sha(go),'noRetry':True};(W/'remote-campaign-run.json').write_text(json.dumps(r,indent=2)+'\n');print('CAMPAIGN TERMINAL',q.returncode,q.stdout,q.stderr,flush=True)
run('collect',['scp','-r','-i',key,host+':'+remote+'/timing-package',str(W/'remote-campaign-evidence')]);assert q.returncode==0,r
