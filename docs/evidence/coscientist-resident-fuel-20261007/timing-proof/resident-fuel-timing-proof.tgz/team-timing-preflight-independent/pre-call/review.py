from pathlib import Path
import hashlib,json,re
D=Path(__file__).parent;H=D.parent.parent;W=H/'team-timing';P=W/'timing-package';B=Path('/private/tmp/amu-hardware-aes-20261006/implementation-v2');I=H/'implementation';R=Path('/Users/junkawasaki/github/wt/amu-seed17');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
pre=load(D/'preregistration.json')
for f,h in {**pre['inputs'],**pre['externalOriginPins']}.items():assert sha(Path(f))==h,f
pr=load(W/'preregistration.json');build=load(W/'build-report.json');entries=build['entries'];assert len(entries)==19 and build['builds']==19 and build['guestCalls']==build['performanceRuns']==0
assert sha(P/'timing-host.c')=='39cdbfa14ace3196029c5f1d50be8d2a1200d7aa9ab3c08d2435837e23b752eb'
oldproof={r['workload']:r for r in load(Path('/private/tmp/amu-hardware-aes-20261006/team-timing-v2/candidate-proof.json'))['entries']}
rows=[]
for e in entries:
 name=e['workload'];p=P/name;manifest=load(p/'input-manifest.json');assert manifest==e
 for f,k in [('baseline.bin','baselineNativeSHA256'),('candidate.bin','candidateNativeSHA256'),('c.dylib','CbinarySHA256'),('source.kotoba','sourceSHA256'),('immutable-header.h','immutableHeaderSHA256'),('runner','runnerSHA256')]:assert sha(p/f)==e[k]
 assert (p/'baseline.bin').read_bytes()==(B/'ports'/name/'native.bin').read_bytes();assert (p/'candidate.bin').read_bytes()==(I/'ports'/name/'native.bin').read_bytes()
 sourceOrigins=[Path(f) for f,x in pre['externalOriginPins'].items() if f.endswith('.kotoba') and '/bench/embench/' in f and x==e['sourceSHA256']];assert len(sourceOrigins)==1 and (p/'source.kotoba').read_bytes()==sourceOrigins[0].read_bytes()
 for source,field in [(B,'baselineOffset'),(I,'candidateOffset')]:
  log=(source/'ports'/name/'extract.log').read_text();assert int(re.search(r':offset (\d+)',log)[1])==e[field]
 h=(p/'immutable-header.h').read_text();arrays={k:bytes(map(int,v.split(','))) for k,v in re.findall(r'static const unsigned char (\w+)\[\] = \{([0-9,]+)\};',h)}
 assert arrays['known_baseline']==(p/'baseline.bin').read_bytes() and arrays['known_candidate']==(p/'candidate.bin').read_bytes() and arrays['timing_known_c_bytes']==(p/'c.dylib').read_bytes()
 assert '#define KEXE_EMBEDDED_REQUIRED_HOST_FEATURES 6ULL' in h and '#define KEXE_EMBEDDED_ISA "aarch64"' in h and '#define TIMING_KNOWN_IMAGES 2' in h
 assert re.search(r'timing_known_sizes\[\] = \{(\d+),(\d+)\}',h).groups()==tuple(str(len(arrays['known_'+x])) for x in ['baseline','candidate'])
 assert re.search(r'timing_known_offsets\[\] = \{(\d+),(\d+)\}',h).groups()==(str(e['baselineOffset']),str(e['candidateOffset']))
 assert f'#define TIMING_KNOWN_C_SYMBOL "{e["Csymbol"]}"' in h
 b=load(p/'build.status.json');assert b['exit']==0 and b['sourceSHA256']==build['sourceSHA256'] and b['headerSHA256']==e['immutableHeaderSHA256'];assert str(P/'timing-host.c') in b['args'] and str(p/'immutable-header.h') in b['args']
 desc=load(p/'C-input-descriptor.json');de=desc['entry'];assert de['workload']==name and de['iterationsPerCall']==e['n'] and de['cSymbol']==e['Csymbol'] and de['cDylibSha256']==e['CbinarySHA256'];assert set(de)=={'workload','iterationsPerCall','cSymbol','cDylibSha256'}
 origins=[Path(f) for f,x in pre['externalOriginPins'].items() if f.endswith('c.dylib') and x==e['CbinarySHA256']];assert len(origins)==1 and origins[0].read_bytes()==(p/'c.dylib').read_bytes()
 assert e['n']==(2000 if name=='depthconv' else 32) and e['expectedResult']==1 and e['requiredMask']==6
 if name in ['depthconv','picojpeg','qrduino','wikisort','xgboost']:
  o=oldproof[name];assert o['sourceSha256']==e['sourceSHA256'] and o['nativeSha256']==e['baselineNativeSHA256']==e['candidateNativeSHA256'] and o['offset']==e['baselineOffset']==e['candidateOffset'];r=[x for x in o['runs'] if x['n']==e['n']]
  if name=='depthconv':
   bridge=load(D/'depthconv-bridge-binding.json');assert sha(Path(bridge['path']))==bridge['sha256'];oldpre=load(Path(bridge['path']));r=[x for x in oldpre['fuelInheritance'] if x['workload']==name and x['n']==2000];assert r[0]['sourceSha256']==e['sourceSHA256'] and r[0]['nativeSha256']==e['candidateNativeSHA256'] and r[0]['offset']==e['candidateOffset']
  assert len(r)==1 and r[0]['fuelConsumed']==e['expectedNativeFuelConsumed'] and r[0].get('exit',0)==0 and r[0].get('result',1)==1
 rows.append(e)
assert [r['workload'] for r in rows if r['changedNative']]==['nettle-aes']
assert pr['acceptedTriplesPerBody']==30 and pr['attemptCapPerBody']==90 and pr['rotation']==['baseline','candidate','C'] and pr['targetIntervalNs']==300000000 and pr['minimumIntervalNs']==50000000 and pr['maximumLoad']==4 and pr['minimumBackgroundIdlePercent']==90 and pr['maximumRelativeSd']==.1 and pr['minimumSpeedup']==1.05 and not pr['performanceAuthorized']
out={'status':'PASS independent full19 precall immutable package review; finite remote57 semantic preflight and performance ROOTGO pending','sourceSHA256':build['sourceSHA256'],'preregistrationSHA256':sha(W/'preregistration.json'),'precallSnapshotSHA256':sha(D/'preregistration.json'),'snapshotPins':len(pre['inputs']),'externalOriginsRehashed':len(pre['externalOriginPins']),'workloads':19,'compiledSamePerWorkloadRunner':True,'completeHeaderNativeAndCArrayExact':True,'sourceNativeOffsetsAndCExportBound':True,'requiredMask':6,'expectedInputs':'n32 except depthconv2000; result1; publicbudget16777216','expectedFuelBridge':'depthconv70034 plus picojpeg/qrduino/wikisort/xgboost highfuel successful receipts are semantic inherited only with exact source/native/offset; prospective supplement records prior1Mtrap setup refusal; fresh57 must validate all.','entries':rows,'historicalStatisticsCopied':False,'CRecipeBoundary':'Exact inherited original Cbinary and entry pinned; original compiler version/flags unknown, not independently reconstructed. Declared paired-spec bridge source/provenance is separate from exact Cbinary build proof.','newHostContract':'39cdb scoped private singlethread exclusive fuel writer, copied featuregate firstmain and known fullbytes/offset/ISA before RX; C exact symbol/bytes then immutableprivate0400copy. Prior independent static/v3 reviews bound; not genericABI/frozenloader extension.','futureRemoteLimits':{'semanticCalls':57,'perArmCalls':1,'warmup':0,'calibrationBeforeRootGO':0,'processWallSeconds':30},'guestCallsByReviewer':0,'performanceRuns':0,'performanceAuthorized':False};write(D/'report.json',out)
for f,h in {**pre['inputs'],**pre['externalOriginPins']}.items():assert sha(Path(f))==h,f
fs=sorted(p for p in D.iterdir() if p.is_file() and p.name not in ['artifact-pins.json','terminal-report.json']);write(D/'artifact-pins.json',{p.name:sha(p) for p in fs});t={'status':out['status'],'reportSha256':sha(D/'report.json'),'pinsSha256':sha(D/'artifact-pins.json'),'pins':len(fs),'ownGuestCalls':0,'performanceRuns':0};write(D/'terminal-report.json',t);print(json.dumps(t,indent=2));print('TERMINAL',sha(D/'terminal-report.json'))
