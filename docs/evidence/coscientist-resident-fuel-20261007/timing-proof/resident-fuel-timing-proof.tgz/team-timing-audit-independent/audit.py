from pathlib import Path
import json,math,statistics,hashlib,sys
D=Path(__file__).parent;H=D.parent;W=H/'team-timing';E=Path(sys.argv[1]) if len(sys.argv)>1 else W/'remote-campaign-evidence';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');near=lambda a,b:math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-8)
pre=load(D/'preregistration.json')
for f,h in pre['inputs'].items():assert sha(Path(f))==h,f
spec=load(E/'paired-timing-spec.json');go=load(E/'ROOT-GO.json');assert go==load(H/'root/ROOT-GO.json') and go['performanceAuthorized'];assert go['preregistrationSHA256']==sha(E/'preregistration.json') and go['packageInputPinsSHA256']==sha(E/'package-input-pins.json') and go['remoteSemanticReportSHA256']==sha(E/'semantic-preflight.json')
for f,h in load(E/'package-input-pins.json').items():assert sha(E/f)==h,f
for f,h in load(W/'post57-artifact-pins.json').items():assert sha(W/f)==h['sha256'] and (W/f).stat().st_size==h['bytes'],f
sem=load(E/'semantic-preflight.json');assert sem['calls']==57 and sem['performanceCalls']==0
campaign=load(E/'campaign.json');assert campaign['status']=='terminal-onecampaign all19 attempted';entries=load(E/'compiled-manifest.json')['entries'];assert len(entries)==len(campaign['entries'])==19
arms=['baseline','candidate','C'];out=[];totals={'acceptedTriples':0,'attemptedTriples':0,'rejectedTriples':0,'rawAttemptRows':0,'calibrationRows':0};allcomplete=True
for entry,terminal in zip(entries,campaign['entries']):
 name=entry['workload'];assert terminal['workload']==name;p=E/name;q=load(p/'timing/results.json');assert q['host'].split('.')[0]==spec['host'] and q['specSha256']==sha(E/'paired-timing-spec.json') and q['runnerSha256']==entry['runnerSHA256']==sha(p/'runner');assert q['manifest']==load(p/'candidate/manifest.json') and q['baselineResultsSha256']==sha(p/'baseline/results.json')
 def value(row):
  arm=row['arm'];assert arm in arms;assert type(row['elapsedNanoseconds']) is int and row['elapsedNanoseconds']>0 and type(row['calls']) is int and 0<row['calls']<=100000000 and row['warmupCalls']==spec['warmupCalls'] and row['result']==1
  f=0 if arm=='C' else entry['expectedNativeFuelConsumed'];assert row['fuelPerCall']==row['contextFuelBefore']==16777216 and row['contextFuelConsumed']==f and row['contextFuelAfter']==16777216-f and row['artifactKind']==('dylib' if arm=='C' else 'raw')
  assert row['nativeArtifactAbi']=='kotoba.native-artifact-i64x8-to-i64-indirect/v1' and row['format']=='kotoba.runtime-sample/v1'
 # Reconstruct calibration exactly from freshretained armsequence, no history.
 calibration=q.get('calibrationRows',[]);counts={};cursor=0
 for arm in arms:
  calls=3;converged=False
  for i in range(5):
   if cursor==len(calibration):break
   row=calibration[cursor]
   if row['arm']!=arm:break
   cursor+=1;value(row);assert row['calls']==calls and row['calibrationAttempt']==i
   elapsed=row['elapsedNanoseconds']
   if spec['targetIntervalNs']*.75<=elapsed<=spec['targetIntervalNs']*1.5:converged=True;counts[arm]=calls;break
   calls=max(1,min(100000000,round(calls*spec['targetIntervalNs']/elapsed)))
  if not converged:assert q['status']=='failed';break
 assert cursor==len(calibration)
 totals['calibrationRows']+=len(calibration)
 rows=q['rows'];assert len(rows)%3==0 and len(rows)//3<=spec['maximumPairAttempts'];accepted=0;reasonCounts={};xs={a:[] for a in arms}
 for attempt in range(len(rows)//3):
  group=rows[attempt*3:attempt*3+3];assert [r['arm'] for r in group]==arms[attempt%3:]+arms[:attempt%3];quiet=True
  for r in group:
   value(r);assert r['attempt']==attempt and r['calls']==counts[r['arm']]
   c=r['cpuActivityEnvelope'];before=c['before'];after=c['after'];assert before['processors']==after['processors'] and before['api']==after['api']=='host_processor_info/PROCESSOR_CPU_LOAD_INFO';assert after['monotonicNs']>before['monotonicNs']
   for point in [before,after]:assert len(point['ticks'])==4 and all(type(v)is int and 0<=v<=0xffffffff for v in point['ticks'])
   delta=[(b-a)&0xffffffff for a,b in zip(before['ticks'],after['ticks'])];assert delta==c['deltaTicks'];total=sum(delta);assert total>0;idle=100*delta[2]/total;envelope=after['monotonicNs']-before['monotonicNs'];assert near(idle,c['idlePercent']) and envelope==c['envelopeNs'];assert type(c['childCpuNs'])is int and c['childCpuNs']>=0 and type(c['logicalCpuCount'])is int and c['logicalCpuCount']>0
   child=100*c['childCpuNs']/(envelope*c['logicalCpuCount']);assert child<=100;bg=min(100,idle+child);assert near(bg,c['estimatedBackgroundIdlePercent'])
   assert envelope>=r['elapsedNanoseconds'];assert math.isfinite(r['loadBefore']) and math.isfinite(r['loadAfter']) and r['loadBefore']>=0 and r['loadAfter']>=0
   reasons=[]
   if max(r['loadBefore'],r['loadAfter'])>spec['maximumLoad']:reasons.append('host-load')
   if r['elapsedNanoseconds']<spec['minimumIntervalNs']:reasons.append('short-interval')
   if bg<spec['minimumBackgroundIdlePercent']:reasons.append('background-cpu')
   assert reasons==r['rejectionReasons'];quiet&=not reasons
   for reason in reasons:reasonCounts[reason]=reasonCounts.get(reason,0)+1
  for r in group:assert r['accepted']==quiet
  accepted+=int(quiet)
  if quiet:
   for r in group:xs[r['arm']].append(r['elapsedNanoseconds']/(r['calls']*entry['n']))
  if accepted==spec['samplesPerArm']:assert attempt==len(rows)//3-1
 assert q.get('acceptedTriples',0)==accepted and q.get('attemptedTriples',0)==len(rows)//3
 totals['acceptedTriples']+=accepted;totals['attemptedTriples']+=len(rows)//3;totals['rejectedTriples']+=len(rows)//3-accepted;totals['rawAttemptRows']+=len(rows)
 complete=q['status']=='complete-provisional-candidate-timing' and accepted==30 and len(counts)==3;allcomplete&=complete
 rowout={'workload':name,'status':q['status'],'acceptedTriples':accepted,'attemptedTriples':len(rows)//3,'rejectedTriples':len(rows)//3-accepted,'calibrationRows':len(calibration),'rejectionReasonRows':reasonCounts,'rawSha256':sha(p/'timing/results.json'),'complete':complete}
 if complete:
  assert terminal['exit']==0 and q['performanceMeasured'] and q['officialEmbenchScore']==False
  summary={}
  for a in arms:
   mu=statistics.mean(xs[a]);sd=statistics.stdev(xs[a]);summary[a]={'meanNsPerBody':mu,'sdNs':sd,'relativeSd':sd/mu,'samples':len(xs[a])}
   for k,v in summary[a].items():assert near(v,q['summary'][a][k]),(name,a,k,v,q['summary'][a][k])
  b=summary['baseline'];c=summary['candidate'];ref=summary['C'];stable=max(x['relativeSd'] for x in summary.values())<=spec['maximumRelativeSd'];speed=b['meanNsPerBody']/c['meanNsPerBody'];ratio=c['meanNsPerBody']/ref['meanNsPerBody'];gain=stable and speed>=spec['minimumSpeedup'] and b['meanNsPerBody']-c['meanNsPerBody']>b['sdNs']+c['sdNs'];regression=stable and 1/speed>=spec['minimumSpeedup'] and c['meanNsPerBody']-b['meanNsPerBody']>b['sdNs']+c['sdNs'];cbetter=stable and 1/ratio>=spec['minimumSpeedup'] and ref['meanNsPerBody']-c['meanNsPerBody']>ref['sdNs']+c['sdNs']
  assert stable==q['summary']['stable'] and near(speed,q['summary']['baselineOverCandidate']) and near(ratio,q['summary']['candidateOverC']) and gain==q['summary']['candidateImprovesBaseline'];assert terminal['summary']==q['summary']
  rowout.update(summary=summary,stable=stable,baselineOverCandidate=speed,candidateOverC=ratio,qualifiedGain=gain,qualifiedRegression=regression,qualifiedCOrBetter=cbetter,classification='gain' if gain else 'regression' if regression else 'neutral' if stable else 'unstable')
 else:assert terminal['status']==q['status'];rowout['failure']=q.get('failure');rowout['classification']='incomplete';assert 'summary' not in q
 out.append(rowout)
aggregate=None
if allcomplete:
 gm=lambda vs:math.exp(statistics.mean(math.log(v) for v in vs));speed=gm([r['baselineOverCandidate'] for r in out]);aggregate={'baselineOverCandidateGeometricMean':speed,'candidateRelativeTimePercent':100*(1/speed-1),'candidateOverCGeometricMean':gm([r['candidateOverC'] for r in out]),'baselineOverCGeometricMean':gm([r['baselineOverCandidate']*r['candidateOverC'] for r in out]),'descriptiveOnly':True,'all19Stable':all(r['stable'] for r in out)}
result={'status':'PASS independent raw audit complete19' if allcomplete else 'PASS independent raw audit with partialcampaign; nofull19aggregate','all19Complete':allcomplete,'rawRowsTotals':totals,'entries':out,'aggregate':aggregate,'qualifiedGains':[r['workload'] for r in out if r.get('qualifiedGain')],'qualifiedRegressions':[r['workload'] for r in out if r.get('qualifiedRegression')],'qualifiedCOrBetter':[r['workload'] for r in out if r.get('qualifiedCOrBetter')],'goalAchieved':False,'officialScore':False,'productAdoption':False,'ownGuestCalls':0,'ownNetworkAttempts':0,'ownTimingRuns':0,'trustBoundary':'Offline checks parse retained runner samples and CPUfields; trusted frozen source/producer/OS. Child CPU share reconstructed from recordedns, not independently remeasured. No rawhardwarecounter/trace universalproof.'};write(D/'report.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ['entries','trustBoundary']},indent=2))
