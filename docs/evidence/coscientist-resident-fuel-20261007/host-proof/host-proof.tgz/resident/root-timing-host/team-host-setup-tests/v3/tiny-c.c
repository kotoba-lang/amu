#include <stdint.h>
#include <stdio.h>
#include <dlfcn.h>
#include <sys/stat.h>
#include <string.h>
int64_t run(int64_t n,int64_t b,int64_t c,int64_t d,int64_t e,int64_t f,int64_t g,int64_t h){(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;(void)h;return n;}
__attribute__((constructor)) static void owned_marker(void){
 Dl_info i;struct stat file,parent;char dir[1024];
 if(!dladdr((void*)&run,&i) || !i.dli_fname || strlen(i.dli_fname)>=sizeof(dir))return;
 strcpy(dir,i.dli_fname);char *slash=strrchr(dir,'/');if(!slash)return;*slash=0;
 if(stat(i.dli_fname,&file) || stat(dir,&parent))return;
 fprintf(stderr,"HOST_TINY_CTOR path=%s fileMode=%o dirMode=%o\n",i.dli_fname,(unsigned)(file.st_mode&0777),(unsigned)(parent.st_mode&0777));
}
