from pathlib import Path
import hashlib,json,subprocess,os,shutil,re
D=Path(__file__).parent;H=D.parent.parent;C=H/'timing-host.c';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();p=json.loads((H/'preregistration.json').read_text());freeze=json.loads((H/'source-freeze.json').read_text())
for f,h in p['inputPins'].items():assert sha(Path(f))==h,f
assert sha(C)==freeze['sourceSha256'];assert sha(H/'preregistration.json')==freeze['preregSha256']
(D/'input-binding.json').write_text(json.dumps({'rootInputPins':p['inputPins'],'preregistrationSHA256':sha(H/'preregistration.json'),'sourceFreezeSHA256':sha(H/'source-freeze.json'),'sourceSHA256':sha(C),'beforeAnyBuild':True,'controlsMax':24,'buildVariantsMax':8,'guest':'synthetic RET4bytes only n0 calls1 warm0 fuel32','noPerformanceClaim':True,'rawOnlyScope':'Immutable Cdeclaration absent deliberately refused beforedlopen; no dylib execution'},indent=2)+'\n')
shim=Path('/private/tmp/amu-embedded-host-feature-gate-20261007/test-host-detection.c');shutil.copy2(shim,D/'test-host-detection.c')
ret=bytes.fromhex('c0035fd6');(D/'ret.bin').write_bytes(ret);(D/'wrong-content.bin').write_bytes(bytes.fromhex('000020d4'));(D/'wrong-size.bin').write_bytes(bytes.fromhex('1f2003d5c0035fd6'));(D/'wrong-content.bin.features.json').write_text('{"availableHostFeatures":18446744073709551615,"knownImage":true,"offset":0}')
mut=D/'omit-gate.c';s=C.read_text();needle='  if(!kexe_embedded_host_gate(KEXE_EMBEDDED_ISA))return 2;';assert s.count(needle)==1;mut.write_text(s.replace(needle,'  /* actual source fault control: omit early gate */'))
builds=[];runs=[]
def build(name,mask,isa='aarch64',test=True,source=C,known=True):
 qdir=D/name;qdir.mkdir(exist_ok=True)
 h=f'#define KEXE_EMBEDDED 1\n#define KEXE_EMBEDDED_REQUIRED_HOST_FEATURES {mask}ULL\n#define KEXE_EMBEDDED_ISA "{isa}"\n'
 if known:h+='''#define TIMING_KNOWN_IMAGES 1
static const unsigned char timing_known_ret[] = {192,3,95,214};
static const unsigned char * const timing_known_images[] = {timing_known_ret};
static const unsigned long timing_known_sizes[] = {4};
static const unsigned long long timing_known_offsets[] = {0};
'''
 (qdir/'embedded.h').write_text(h)
 cmd=['clang','-O2','-std=c11','-include',str(qdir/'embedded.h')]
 if test:cmd+=['-DKEXE_HOST_GATE_TEST=1']
 cmd+=[str(source)]
 if test:cmd+=[str(D/'test-host-detection.c')]
 cmd+=['-o',str(qdir/'runner')];q=subprocess.run(cmd,capture_output=True,text=True);(qdir/'build.stdout').write_text(q.stdout);(qdir/'build.stderr').write_text(q.stderr);(qdir/'build.status.json').write_text(json.dumps({'exit':q.returncode,'args':cmd},indent=2)+'\n')
 row={'variant':name,'source':str(source),'sourceSHA256':sha(source),'headerSHA256':sha(qdir/'embedded.h'),'testOnlyShim':test,'compileExit':q.returncode,'binarySHA256':sha(qdir/'runner') if (qdir/'runner').exists() else None};builds.append(row)
 if known:assert q.returncode==0,q.stderr
 else:assert q.returncode!=0 and 'owned_timing_host_requires_immutable_known_images' in q.stderr
 return qdir
prod=build('production6',6,test=False);actual=build('actual6',6);unknown=build('unknown8',8);isa=build('isa-mismatch',6,isa='x86_64');crc=build('crc1',1);aes=build('aes2',2);omitted=build('omit-gate8',8,source=mut);missing=build('missing-known-header',6,known=False)
def run(qdir,name,env=None,blob='ret.bin',off=0,argvISA='aarch64',refuse=None,calls='1',fuel='32',missingArgs=False):
 args=[str(qdir/'runner'),'raw',str(D/blob),str(off),argvISA,'0',calls,'0',fuel]
 if missingArgs:args=[str(qdir/'runner')]
 e=dict(os.environ);e.update(env or {});q=subprocess.run(args,env=e,capture_output=True,text=True,timeout=15);stages=[x for x in ['RX','ENTRY'] if 'HG_STAGE '+x+'\n' in q.stderr];r={'case':name,'variant':qdir.name,'args':args,'envControl':env or {},'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr,'stages':stages,'elapsedDiagnosticNotPerformance':True};(qdir/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n')
 if refuse:assert q.returncode==2 and refuse in q.stderr and not stages,(r)
 else:
  assert q.returncode==0,(r);raw=json.loads(q.stdout);assert raw['result']==0 and raw['contextFuelBefore']==32 and raw['contextFuelAfter']==32 and raw['contextFuelConsumed']==0,(r)
  if qdir!=prod:assert stages==['RX','ENTRY'],r
 runs.append(r)
run(prod,'production-actual')
run(prod,'production-fault-env-ignored',env={'HG_TEST_FAULT':'error','KEXE_REQUIRED_HOST_FEATURES':'0','KEXE_HOST_FEATURES':'0'})
run(actual,'instrumented-actual')
run(unknown,'unknown-required',refuse='unknown required feature')
run(unknown,'forged-metadata-env',env={'KEXE_REQUIRED_HOST_FEATURES':'0','KEXE_HOST_FEATURES':'18446744073709551615'},blob='wrong-content.bin',refuse='unknown required feature')
run(isa,'immutable-isa-mismatch',refuse='isa mismatch')
for variant in [crc,aes]:
 for fault in ['unsupported','error','short','badvalue']:run(variant,'fault-'+fault,env={'HG_TEST_FAULT':fault},refuse='unavailable' if fault=='unsupported' else 'detection error')
run(actual,'wrong-size',blob='wrong-size.bin',refuse='unknown native bytes or offset')
run(actual,'wrong-content',blob='wrong-content.bin',refuse='unknown native bytes or offset')
run(actual,'wrong-offset',off=2,refuse='unknown native bytes or offset')
run(actual,'argv-isa-mismatch',argvISA='x86_64',refuse='argument isa differs from immutable isa')
run(actual,'forged-bytes-metadata',blob='wrong-content.bin',env={'KEXE_REQUIRED_HOST_FEATURES':'0','TIMING_KNOWN_IMAGES':'1'},refuse='unknown native bytes or offset')
run(omitted,'omitted-gate-reaches-entry')
run(actual,'forged-feature-env-ignored',env={'KEXE_REQUIRED_HOST_FEATURES':'0','KEXE_HOST_FEATURES':'0'})
run(unknown,'unknown-first-main-before-args',missingArgs=True,refuse='unknown required feature')
run(actual,'invalid-calls-before-RX',calls='0',refuse='calls is outside the admitted range')
# Without immutable Cdeclaration even a nonexistent suppliedlibrary must fail beforedlopen.
q=subprocess.run([str(actual/'runner'),'dylib','/nonexistent/untrusted-library.dylib','untrusted','aarch64','0','1','0','32'],capture_output=True,text=True,timeout=15)
r={'case':'absent-immutable-C-declaration','variant':actual.name,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr,'stages':[],'elapsedDiagnosticNotPerformance':True}
(actual/'absent-immutable-C-declaration.json').write_text(json.dumps(r,indent=2)+'\n');assert q.returncode==1 and 'owned timing host has no immutable C declaration' in q.stderr and 'HG_STAGE' not in q.stderr and 'dlopen:' not in q.stderr,r
runs.append(r)
assert len(builds)==8 and len(runs)==24,(len(builds),len(runs))
base=Path('/Users/junkawasaki/github/wt/amu-seed17/bench/runtime-comparison/kexe-benchmark.c').read_text()
assert s[s.index('  memset(&shared,'):].replace('  HG_STAGE("ENTRY");\n','')==base[base.index('  memset(&shared,'):]
assert 'pthread_create' not in s and 'sigaction(' not in s and 'signal(' not in s
report={'status':'PASS v2 host-only raw immutableimage gate finite controls and absentCdeclaration failclosed','builds':builds,'controls':runs,'buildVariants':len(builds),'controlCount':len(runs),'timedLoopContextResetExactOriginal':True,'privateContext':'static bench_shared in same one-thread process; contextfuel reset before everyfn; no installed resuminghandlers or concurrent writers in this source. Excludes externaldebugger/hostcompromise and requires certifiednohiddenwriters perresidentregion.','scope':'NEW scoped timing-host contract; not genericembedding or inherited frozenloader guarantee.','productionTestEnvIgnored':True,'immutableHeaderBytesOffsetBoundBeforeRX':True,'argvHeaderISAExact':True,'unsupportedHardware':'Testcompiledshim simulates unavailable/detectionerror; no claim actually unsupportedCPU executed','guestScope':'RET4byte only; result0/fuelunchanged; no actual AES/CRC/workloadguest invocation','actualElapsed':'Retained raw diagnostic field only, not performance data/statistics or calibration','Cscope':'Only absentCdeclaration rejection tested. Positive knownCbytes/export/privatecopy needs separateprereg; no dylib was loaded.','sourceEdited':False,'performanceRuns':0,'candidateOrProductChanged':False}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
for f,h in p['inputPins'].items():assert sha(Path(f))==h
assert sha(C)==freeze['sourceSha256'];print('PASS HOST SETUP',len(builds),len(runs),flush=True)
