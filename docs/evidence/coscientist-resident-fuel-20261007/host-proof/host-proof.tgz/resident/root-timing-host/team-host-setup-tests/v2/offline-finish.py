from pathlib import Path
import json,hashlib,shutil
D=Path(__file__).parent;H=D.parent.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=H/'timing-host.c'
assert sha(source)=='39cdbfa14ace3196029c5f1d50be8d2a1200d7aa9ab3c08d2435837e23b752eb'
shutil.copy2(source,D/'compiled-source39cdb.c');shutil.copy2(H/'preregistration.json',D/'parent-preregistration.json');shutil.copy2(H/'source-freeze.json',D/'parent-source-freeze.json')
(D/'harness-classification-error.json').write_text(json.dumps({'kind':'Offline harness assertion error after all24native controls executed','originalExit':1,'wrongAssumption':'Expected different absent-Cdeclaration message and absence of text dlopen:','actualSource':'#ifndefTIMING_KNOWN_DYLIB returnsNULL immediately; outer caller prints dlopen: immutable C admission refused. It doesnotcall dlopen API.','expectedControl':'No RX/ENTRY, refusal1, no library load','correction':'Offline only classify retainedactualrawreceipt against authoritative39cdbsource. No source/header/native/binary/nativecontrol rerun.','originalScriptAndLogRetained':True},indent=2)+'\n')
positive={'production-actual','production-fault-env-ignored','instrumented-actual','omitted-gate-reaches-entry','forged-feature-env-ignored'};builds=[];runs=[]
for d in sorted(p for p in D.iterdir() if p.is_dir()):
 if not (d/'build.status.json').exists():continue
 b=json.loads((d/'build.status.json').read_text());assert b['exit']==(1 if d.name=='missing-known-header' else 0)
 builds.append({'variant':d.name,'exit':b['exit'],'sourceSHA256':sha(D/'omit-gate.c') if d.name=='omit-gate8' else sha(source),'headerSHA256':sha(d/'embedded.h'),'binarySHA256':sha(d/'runner') if (d/'runner').exists() else None,'args':b['args']})
 for p in sorted(d.glob('*.json')):
  r=json.loads(p.read_text())
  if 'case' not in r:continue
  if r['case'] in positive:
   assert r['exit']==0;rj=json.loads(r['stdout']);assert rj['result']==0 and rj['contextFuelBefore']==rj['contextFuelAfter']==32 and rj['contextFuelConsumed']==0
   assert r['stages']==([] if d.name=='production6' else ['RX','ENTRY'])
  elif r['case']=='absent-immutable-C-declaration':
   assert r['exit']==1 and r['stderr']=='timing-host: no immutable C library declared\ndlopen: immutable C admission refused\n' and 'HG_STAGE' not in r['stderr']
  else:assert r['exit']==2 and r['stages']==[]
  r['rawPath']=str(p.relative_to(D));runs.append(r)
assert len(builds)==8 and len(runs)==24
base=Path('/Users/junkawasaki/github/wt/amu-seed17/bench/runtime-comparison/kexe-benchmark.c').read_text();s=source.read_text();assert s[s.index('  memset(&shared,'):].replace('  HG_STAGE("ENTRY");\n','')==base[base.index('  memset(&shared,'):]
assert 'pthread_create' not in s and 'sigaction(' not in s and 'signal(' not in s
report={'status':'PASS v2 host-only immutable rawgate8builds24controls and absentCdecl rejection; original harness run exited1 due errorstring classification','sourceSHA256':sha(source),'buildVariants':8,'controls':24,'builds':builds,'runs':runs,'timedLoopContextResetExactOriginal':True,'hostContract':'NEW scoped one-thread staticprivatecontext, resetbeforecalls, no installedresuminghandlers or concurrentwriters. Certified6core separately excludes hiddenwriters/calls. Not inherited frozenloader/genericABI.','actualCode':'RET4bytes only n0/calls1/warm0/fuel32, result0/fuelunchanged','actualCPU':'Production strictsysctl real supportedhost; error/unavailable/short/nonboolean clearly testcompiledfaultshim','CAdmissionScope':'Absent immutableCdeclaration refusalonly; no dylibAPI/load/constructor/guest. KnownCbytes/symbol/privatecopy positive path NOTtested orqualified.','forgedMetadataEnv':'Cannotrelax unknownmask/rawbytes/offset or argvISA; productionHG_TEST_FAULT ignored','setupFailures':['Retained original24th-control assertion expected wrong errorstring; correctedoffline no additional nativecontrols.'],'sourceCopyTiming':'Beforebuild input-binding recorded root-frozen39cdbhash; builds consumed trustedparentfrozenpath and source remainedsame. Exactcompiledsourcecopy captured atterminal, not falsely represented as beforebuild copy. Futurephases mustcompile ownprefrozencopy.','performanceSamples':0,'diagnosticElapsed':'RawRETelapsedfield retained only; no statistics/score/calibration/admission ofbenchworkload','productEdited':False}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
pins=[{'path':str(p.relative_to(D)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(D.rglob('*')) if p.is_file() and p.name not in ['artifact-pins.json','terminal-report.json']]
(D/'artifact-pins.json').write_text(json.dumps(pins,indent=2)+'\n');(D/'terminal-report.json').write_text(json.dumps({'status':report['status'],'reportSHA256':sha(D/'report.json'),'pinsSHA256':sha(D/'artifact-pins.json'),'pins':len(pins),'sourceSHA256':sha(source),'nativeSession':41117,'actualNativeSessionExit':1,'offlineClassificationPASS':True,'nativeReruns':0,'nativeControls':24,'buildVariants':8,'performanceRuns':0,'writesComplete':True},indent=2)+'\n');print('V2TERMINAL',sha(D/'terminal-report.json'),len(pins),sha(D/'artifact-pins.json'))
