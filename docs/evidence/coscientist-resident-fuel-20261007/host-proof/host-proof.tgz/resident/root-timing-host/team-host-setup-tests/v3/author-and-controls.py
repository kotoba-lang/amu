from pathlib import Path
import json,hashlib,shutil,subprocess,os,re
D=Path(__file__).parent;H=D.parent.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();src=H/'timing-host.c';assert sha(src)=='39cdbfa14ace3196029c5f1d50be8d2a1200d7aa9ab3c08d2435837e23b752eb'
# Capture source and declaration BEFORE builds, not mutable-parent after build.
for a,b in [(src,D/'timing-host-frozen.c'),(H/'source-freeze.json',D/'parent-source-freeze.json'),(H/'preregistration.json',D/'parent-preregistration.json')]:shutil.copy2(a,b)
inputs={str(p):sha(p) for p in [D/'timing-host-frozen.c',D/'parent-source-freeze.json',D/'parent-preregistration.json']}
(D/'preregistration.json').write_text(json.dumps({'status':'PREREGISTERED before newfixture source authoring and anybuild/nativecontrols','inputPins':inputs,'maxBuilds':3,'maxNativeControls':8,'maxWorkloadCalls':0,'performanceCampaigns':0,'oneoffFixtureAuthoringException':'TrustedtinyC.dylib ownrun8 returnsn; constructorstderr provesactualprivatecopy/filemode400/directory700, touchesno context. Not anEmbenchCscore substitute.','requiredHostFeatures':6,'knownImages':'RET4bytesoffset0 plus immutableCbytes andrunexport embeddedincompiledheaders','controls':['supportedtinyC','productionfaultenvignored','wrongCbytes','wrongCsymbol','missingCpath','forgedmetadatawrongC','knownrawRETunaffected','appendedCbytes'],'expected':'n0 calls1 warm0 fuel32 returns0 fuelunchanged; invalidC refusedbeforector/ENTRY; rootKBtimedloop exact'} ,indent=2)+'\n')
c='''#include <stdint.h>
#include <stdio.h>
#include <dlfcn.h>
#include <sys/stat.h>
#include <string.h>
int64_t run(int64_t n,int64_t b,int64_t c,int64_t d,int64_t e,int64_t f,int64_t g,int64_t h){(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;(void)h;return n;}
__attribute__((constructor)) static void owned_marker(void){
 Dl_info i;struct stat file,parent;char dir[1024];
 if(!dladdr((void*)&run,&i) || !i.dli_fname || strlen(i.dli_fname)>=sizeof(dir))return;
 strcpy(dir,i.dli_fname);char *slash=strrchr(dir,'/');if(!slash)return;*slash=0;
 if(stat(i.dli_fname,&file) || stat(dir,&parent))return;
 fprintf(stderr,"HOST_TINY_CTOR path=%s fileMode=%o dirMode=%o\\n",i.dli_fname,(unsigned)(file.st_mode&0777),(unsigned)(parent.st_mode&0777));
}
'''
(D/'tiny-c.c').write_text(c);builds=[];runs=[]
def build(name,args):
 q=subprocess.run(args,capture_output=True,text=True);(D/(name+'.stdout')).write_text(q.stdout);(D/(name+'.stderr')).write_text(q.stderr);r={'name':name,'args':args,'exit':q.returncode};(D/(name+'.status.json')).write_text(json.dumps(r,indent=2)+'\n');builds.append(r);assert q.returncode==0,(name,q.stderr)
build('tiny-c-build',['clang','-O2','-std=c11','-dynamiclib',str(D/'tiny-c.c'),'-o',str(D/'tiny-c.dylib')])
raw=(D/'tiny-c.dylib').read_bytes();(D/'known-c-artifact-freeze.json').write_text(json.dumps({'sourceSHA256':sha(D/'tiny-c.c'),'artifactSHA256':sha(D/'tiny-c.dylib'),'artifactBytes':len(raw),'export':'run','beforeRunnerBuild':True},indent=2)+'\n')
h='''#define KEXE_EMBEDDED 1
#define KEXE_EMBEDDED_REQUIRED_HOST_FEATURES 6ULL
#define KEXE_EMBEDDED_ISA "aarch64"
#define TIMING_KNOWN_IMAGES 1
static const unsigned char timing_known_ret[] = {192,3,95,214};
static const unsigned char *const timing_known_images[] = {timing_known_ret};
static const unsigned long timing_known_sizes[] = {4};
static const unsigned long long timing_known_offsets[] = {0};
#define TIMING_KNOWN_DYLIB 1
#define TIMING_KNOWN_C_SYMBOL "run"
'''+ 'static const unsigned char timing_known_c_bytes[] = {'+','.join(map(str,raw))+'};\n'
(D/'embedded.h').write_text(h);(D/'header-freeze.json').write_text(json.dumps({'headerSHA256':sha(D/'embedded.h'),'loaderSourceSHA256':sha(D/'timing-host-frozen.c'),'knownCBytesSHA256':sha(D/'tiny-c.dylib'),'knownCExport':'run','requiredMask':6,'beforeRunnerBuild':True},indent=2)+'\n')
shutil.copy2(Path('/private/tmp/amu-embedded-host-feature-gate-20261007/test-host-detection.c'),D/'test-host-detection.c')
build('instrumented-build',['clang','-O2','-std=c11','-DKEXE_HOST_GATE_TEST=1','-include',str(D/'embedded.h'),str(D/'timing-host-frozen.c'),str(D/'test-host-detection.c'),'-o',str(D/'runner-test')])
build('production-build',['clang','-O2','-std=c11','-include',str(D/'embedded.h'),str(D/'timing-host-frozen.c'),'-o',str(D/'runner-production')])
(D/'ret.bin').write_bytes(bytes.fromhex('c0035fd6'));bad=bytearray(raw);bad[-1]^=1;(D/'wrong-c.dylib').write_bytes(bad);(D/'long-c.dylib').write_bytes(raw+b'X');(D/'wrong-c.dylib.features.json').write_text('{"knownC":true,"requiredFeatures":0,"symbol":"run"}')
def run(name,path='tiny-c.dylib',symbol='run',rawMode=False,production=False,env=None,refuse=None):
 before=set(Path('/private/tmp').glob('amu-timing-C-*'));exe=D/('runner-production' if production else 'runner-test');args=[str(exe),'raw' if rawMode else 'dylib',str(D/path),'0' if rawMode else symbol,'aarch64','0','1','0','32'];e=dict(os.environ);e.update(env or {});q=subprocess.run(args,env=e,capture_output=True,text=True,timeout=15);after=set(Path('/private/tmp').glob('amu-timing-C-*'));assert before==after,(before,after)
 r={'case':name,'args':args,'envControl':env or {},'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr,'temporaryDirectorySetUnchanged':True,'diagnosticElapsedNotPerformance':True};(D/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n')
 if refuse:
  assert q.returncode==1 and 'HOST_TINY_CTOR' not in q.stderr and 'HG_STAGE' not in q.stderr and refuse in q.stderr,r
 else:
  assert q.returncode==0,r;j=json.loads(q.stdout);assert j['result']==0 and j['contextFuelBefore']==j['contextFuelAfter']==32 and j['contextFuelConsumed']==0,r
  if rawMode:assert 'HOST_TINY_CTOR' not in q.stderr and 'HG_STAGE RX\n' in q.stderr and 'HG_STAGE ENTRY\n' in q.stderr
  else:
   m=re.search(r'HOST_TINY_CTOR path=(/private/tmp/amu-timing-C-[^ /]+/known.dylib) fileMode=400 dirMode=700\n',q.stderr);assert m,r;assert not Path(m[1]).exists() and not Path(m[1]).parent.exists();r['privateCopyPath']=m[1];r['loadedPrivateFileMode']=400;r['privateDirectoryMode']=700
   if not production:assert 'HG_STAGE ENTRY\n' in q.stderr
  (D/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n')
 runs.append(r)
run('supported-tiny-C')
run('production-fault-env-ignored',production=True,env={'HG_TEST_FAULT':'error','KEXE_REQUIRED_HOST_FEATURES':'0'})
run('wrong-C-bytes',path='wrong-c.dylib',refuse='unknown C bytes')
run('wrong-C-symbol',symbol='untrusted',refuse='unknown C export')
run('missing-C-path',path='missing.dylib',refuse='immutable C admission refused')
run('forged-metadata-C',path='wrong-c.dylib',env={'KEXE_REQUIRED_HOST_FEATURES':'0','TIMING_KNOWN_C_SYMBOL':'run','TIMING_KNOWN_DYLIB':'1'},refuse='unknown C bytes')
run('raw-known-RET-unaffected',path='ret.bin',rawMode=True)
run('appended-C-bytes',path='long-c.dylib',refuse='unknown C bytes')
assert len(builds)==3 and len(runs)==8
for p,s in inputs.items():assert sha(Path(p))==s
report={'status':'PASS trustedtinyC immutablebytes/export/privatecopy admission3builds8controls','builds':builds,'controls':runs,'knownCSourceSHA256':sha(D/'tiny-c.c'),'knownCArtifactSHA256':sha(D/'tiny-c.dylib'),'knownHeaderSHA256':sha(D/'embedded.h'),'frozenHostSourceSHA256':sha(D/'timing-host-frozen.c'),'sourceCopiedBeforeBuild':True,'productionTestFaultEnvIgnored':True,'unknownCNoConstructorOrEntry':True,'actualPrivatePermissionsAndCleanup':True,'knownRawBytesGateUnaffected':True,'Cscope':'Trustedownrun8 identityonly, constructoronly stderr/statreads; no arbitraryC/library/dependency orbenchmarkCqualification. Systemdynamicloader/compiler/OS trusted.','noPerformance':'DiagnosticRET/identity1call elapsedfield retainedonly, no comparisons/statistics/workload/score substitution.','productEdited':False,'workloadCalls':0,'performanceRuns':0}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS CSETUP 3 8',flush=True)
