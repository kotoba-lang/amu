#define KEXE_EMBEDDED 1
#define KEXE_EMBEDDED_REQUIRED_HOST_FEATURES 6ULL
#define KEXE_EMBEDDED_ISA "x86_64"
#define TIMING_KNOWN_IMAGES 1
static const unsigned char timing_known_ret[] = {192,3,95,214};
static const unsigned char * const timing_known_images[] = {timing_known_ret};
static const unsigned long timing_known_sizes[] = {4};
static const unsigned long long timing_known_offsets[] = {0};
