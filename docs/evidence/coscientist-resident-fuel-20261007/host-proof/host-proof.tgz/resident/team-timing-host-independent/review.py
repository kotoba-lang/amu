from pathlib import Path
import json,hashlib,re,difflib
D=Path(__file__).parent;H=D.parent;S=H/'root-timing-host';T=S/'team-host-setup-tests';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
pre=load(D/'preregistration.json')
for p,h in pre['inputPins'].items():assert sha(Path(p))==h,p
src=(S/'timing-host.c').read_text();base=Path('/Users/junkawasaki/github/wt/amu-seed17/bench/runtime-comparison/kexe-benchmark.c').read_text();loader=Path('/private/tmp/amu-embedded-host-feature-gate-20261007/host-feature-loader.c').read_text()
assert sha(S/'timing-host.c')==pre['sourceSha256']=='39cdbfa14ace3196029c5f1d50be8d2a1200d7aa9ab3c08d2435837e23b752eb'
assert src[:src.index('static struct bench_shared shared;')]==base[:base.index('static struct bench_shared shared;')]
assert src[src.index('  memset(&shared,'):].replace('  HG_STAGE("ENTRY");\n','')==base[base.index('  memset(&shared,'):]
# Brace extraction with comments removed for cross-source gate comparison.
def clean(s):return re.sub(r'\s+','',re.sub(r'/\*.*?\*/|//[^\n]*','',s,flags=re.S))
def fn(s,name):
 a=s.index('static int '+name+'(');b=s.index('\n}',a)+2;return s[a:b]
assert clean(fn(src,'kexe_host_cpu_feature'))==clean(fn(loader,'kexe_host_cpu_feature'))
assert clean(fn(src,'kexe_embedded_host_gate'))==clean(fn(loader,'kexe_embedded_host_gate'))
assert src[src.index('int main('):].split('\n')[1]=='  if(!kexe_embedded_host_gate(KEXE_EMBEDDED_ISA))return 2;'
assert src.index('if(strcmp(argv[4],KEXE_EMBEDDED_ISA)')<src.index('memory = mmap(')<src.index('if(!timing_known_image(memory,artifact_bytes,offset))')<src.index('mprotect(memory, mapped, PROT_READ | PROT_EXEC)')
assert 'size==timing_known_sizes[i] && offset==timing_known_offsets[i]' in src and 'memcmp(bytes,timing_known_images[i],size)==0' in src
assert all(x not in src for x in ['pthread_create(', 'sigaction(', 'signal(', 'fork('])
assert len(re.findall(r'context->fuel\s*=',src))==2
# C reader binds exact export and complete supplied bytes, then loads embedded bytes only.
a=src.index('static void *timing_known_c_library(');b=src.index('\nint main(',a);c=src[a:b]
assert '#ifndef TIMING_KNOWN_DYLIB' in c and c.index('return NULL;')<c.index('#else')
assert c.index('strcmp(symbol,TIMING_KNOWN_C_SYMBOL)')<c.index('fopen(path,"rb")')<c.index('memcmp(buf,timing_known_c_bytes+pos,need)')<c.index('mkdtemp(dir)')<c.index('write(fd,timing_known_c_bytes+pos')<c.index('fchmod(fd,0400)')<c.index('dlopen(file,RTLD_NOW|RTLD_LOCAL)')<c.index('unlink(file);rmdir(dir);')
assert 'fgetc(input)!=EOF' in c and 'ferror(input)' in c and 'O_WRONLY|O_CREAT|O_EXCL,0600' in c
assert 'dlopen(argv[2]' not in src and 'dlopen(path' not in src
# Native prefix has independently verified six original STR and no BL/callback.
m=load(H/'team-independent/machine-report.json');n=load(H/'team-independent/native-trace-report.json');assert len(m['controls'])==8 and n['nativeProcesses']==66
phases=[]
for name,p in [('v1',T),('v2',T/'v2')]:
 report=load(p/'report.json');term=load(p/'terminal-report.json');pins=load(p/'artifact-pins.json');ct=0
 for e in pins:
  f=p/e['path'];assert sha(f)==e['sha256'] and f.stat().st_size==e['bytes'],f;ct+=1
 assert sha(p/'report.json')==term['reportSHA256'] and sha(p/'artifact-pins.json')==term['pinsSHA256']
 rows=report['runs'] if name=='v2' else report['controls'];assert len(rows)==24 and len(report['builds'])==8
 out=[]
 for r in rows:
  raw=p/r.get('rawPath',r['variant']+'/'+r['case']+'.json');rr=load(raw)
  for k in ['case','variant','exit','stdout','stderr','stages']:assert rr[k]==r[k],(raw,k)
  stages=[x for x in ['RX','ENTRY'] if 'HG_STAGE '+x+'\n' in rr['stderr']];assert stages==rr['stages']
  if rr['exit']==0:
   q=json.loads(rr['stdout']);assert q['result']==0 and q['contextFuelBefore']==32 and q['contextFuelAfter']==32 and q['contextFuelConsumed']==0
   if rr['variant']!='production6':assert stages==['RX','ENTRY']
  elif rr['case']=='absent-immutable-C-declaration':
   assert rr['exit']==1 and 'no immutable C library declared' in rr['stderr'] and stages==[] and rr['stdout']==''
  else:assert rr['exit']==2 and stages==[] and rr['stdout']==''
  out.append({'case':rr['case'],'variant':rr['variant'],'exit':rr['exit'],'stages':stages,'rawSha256':sha(raw)})
 phases.append({'phase':name,'sourceSHA256':report.get('sourceSHA256',report['builds'][0]['sourceSHA256']),'builds':8,'rawControls':24,'pinsRehashed':ct,'reportSha256':sha(p/'report.json'),'terminalSha256':sha(p/'terminal-report.json'),'rawControlsIndependentClassification':out})
supp=load(S/'root-setup-budget-supplement.json');assert supp['v2AdditionalLimits']=={'buildVariants':8,'gateControls':24} and supp['CPositiveAdmissionPending']
(D/'actual-source.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),src.splitlines(True),fromfile='pinned-original',tofile='frozen-39cdbf')))
r={'status':'PASS scoped static host-contract and retained raw setup review; positive known-C native admission pending, no performance GO','sourceSha256':sha(S/'timing-host.c'),'preregistrationSha256':sha(D/'preregistration.json'),'inputPinsRehashed':len(pre['inputPins']),'sourceChecks':{'contextStructCallbacksOriginalExact':True,'timedLoopArgumentABIResetOriginalExact':True,'copiedActualCPUGateNormalizedExact':True,'gateFirstMainBeforeArgValidation':True,'argvImmutableISAAndBytesSizeOffsetBeforeRX':True,'productionFeatureEnvNotConsulted':True,'testShimOnlyCompileTime':True,'contextFuelAssignments':2,'contextOwnership':'Private static context; same main thread; no fork/thread creation or installed resuming handlers; only warmup/call resets in host. Callbacks/context ABI exact original. External debugger/host corruption/default inherited process environment excluded.','residentCore':'Independent actual65-word site verification binds six separate SUBS/STR, no calls in certified charge core, original slow prefix and dynamic mode BL outside core. Scope only trusted admitted images/certificates, not arbitrary input code.'},'knownC':{'absentDeclaration':'Actual retained refusal1, no RX/ENTRY; outer dlopen text is error label, API not invoked because preprocessor branch immediately returns NULL.','supportedHelperStatic':'Exact supplied complete bytes and exact export check; owned mkdtemp directory, O_EXCL file, embedded bytes written, 0400, RTLD_NOW|LOCAL, unlink after dlopen. The caller-selected pathname is never dlopened.','positiveNativeAdmission':'PENDING separate prospective setup. This review does not certify C execution or performance readiness.','trust':'Trusted embedded declaration/source/compiler/OS and pinned C artifact including dynamic dependencies/constructors; same-user malicious replacement or arbitrary shared embedding not covered.'},'phases':phases,'setupBudgetSupplementSha256':sha(S/'root-setup-budget-supplement.json'),'aggregateBuilds':16,'aggregateRawControls':48,'nativeRunsByThisReviewer':0,'timingRuns':0,'retainedFailures':['Initial missing argv ISA correction before build','v1 source-copy inventory race retained, historical0bb restored; no false current-source identity','v2 original assertion exited1 on incorrect text predicate after24 raw controls; offline classify only, no native rerun'],'remainingAdmissionObligations':['Final immutable all19 native/C/header mask6 recipes and runner/build pins','Supported knownC bytes/export/private-copy positive native controls','Fresh actual target FEAT_AES and actual nineword ISA calibration/publicfuel preflight','Exact new versioned exclusivewriter host contract, not generic ABI/frozenloader claim','ROOT GO after all final semantic and timing input gates'],'productChanged':False,'goalAchieved':False,'officialScore':False};write(D/'report.json',r)
for p,h in pre['inputPins'].items():assert sha(Path(p))==h,p
files=[p for p in D.rglob('*') if p.is_file() and p.name not in ['artifact-pins.json','terminal-report.json']];write(D/'artifact-pins.json',{str(p.relative_to(D)):sha(p) for p in sorted(files)})
t={'status':r['status'],'reportSha256':sha(D/'report.json'),'pinsSha256':sha(D/'artifact-pins.json'),'pins':len(files),'sourceSha256':sha(S/'timing-host.c'),'nativeRuns':0,'timingRuns':0};write(D/'terminal-report.json',t);print(json.dumps(t,indent=2));print('TERMINAL',sha(D/'terminal-report.json'))
