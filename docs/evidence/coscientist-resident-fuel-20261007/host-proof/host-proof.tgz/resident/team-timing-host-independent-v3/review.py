from pathlib import Path
import json,hashlib,re
D=Path(__file__).parent;H=D.parent;V=H/'root-timing-host/team-host-setup-tests/v3';P=H/'team-timing-host-independent';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
pr=load(D/'preregistration.json')
for f,h in pr['inputPins'].items():assert sha(Path(f))==h,f
term=load(V/'terminal-report.json');rep=load(V/'report.json');pins=load(V/'artifact-pins.json');assert sha(V/'report.json')==term['reportSHA256'] and sha(V/'artifact-pins.json')==term['pinsSHA256'] and len(pins)==37
for e in pins:assert sha(V/e['path'])==e['sha256'] and (V/e['path']).stat().st_size==e['bytes']
old=load(P/'terminal-report.json');assert sha(P/'report.json')==old['reportSha256'] and sha(P/'artifact-pins.json')==old['pinsSha256']
for f,h in load(P/'artifact-pins.json').items():assert sha(P/f)==h
s=V/'timing-host-frozen.c';assert sha(s)==term['sourceSHA256']=='39cdbfa14ace3196029c5f1d50be8d2a1200d7aa9ab3c08d2435837e23b752eb' and s.read_bytes()==(H/'root-timing-host/timing-host.c').read_bytes()
prep=load(V/'preregistration.json');assert prep['maxBuilds']==3 and prep['maxNativeControls']==8 and prep['maxWorkloadCalls']==0 and prep['requiredHostFeatures']==6
for f,h in prep['inputPins'].items():assert sha(Path(f))==h
h=(V/'embedded.h').read_text();m=re.search(r'static const unsigned char timing_known_c_bytes\[\] = \{([0-9,]+)\};',h);assert m;embedded=bytes(map(int,m[1].split(',')));assert embedded==(V/'tiny-c.dylib').read_bytes() and len(embedded)==33808
assert '#define KEXE_EMBEDDED_REQUIRED_HOST_FEATURES 6ULL' in h and '#define TIMING_KNOWN_C_SYMBOL "run"' in h
assert '#define TIMING_KNOWN_DYLIB 1' in h
cf=load(V/'known-c-artifact-freeze.json');hf=load(V/'header-freeze.json');assert cf['beforeRunnerBuild'] and hf['beforeRunnerBuild'] and cf['artifactSHA256']==sha(V/'tiny-c.dylib') and hf['headerSHA256']==sha(V/'embedded.h')
script=(V/'author-and-controls.py').read_text();assert script.index('shutil.copy2(a,b)')<script.index("build('tiny-c-build'")<script.index("known-c-artifact-freeze.json")<script.index("build('instrumented-build'")
assert len(rep['builds'])==3 and len(rep['controls'])==8
for b in rep['builds']:
 saved=load(V/(b['name']+'.status.json'));assert b==saved and b['exit']==0
 if b['name']!='tiny-c-build':assert str(s) in b['args'] and str(V/'embedded.h') in b['args']
csrc=(V/'tiny-c.c').read_text();assert 'return n;' in csrc and 'context' not in csrc and '__attribute__((constructor))' in csrc
rows=[]
for r in rep['controls']:
 saved=load(V/(r['case']+'.json'));assert saved==r
 assert r['temporaryDirectorySetUnchanged'] and r['diagnosticElapsedNotPerformance']
 if r['exit']==0:
  j=json.loads(r['stdout']);assert j['calls']==1 and j['warmupCalls']==0 and j['result']==0 and j['contextFuelBefore']==j['contextFuelAfter']==32 and j['contextFuelConsumed']==0
  if r['case']=='raw-known-RET-unaffected':assert 'HOST_TINY_CTOR' not in r['stderr'] and 'HG_STAGE RX\nHG_STAGE ENTRY\n'==r['stderr']
  else:
   match=re.fullmatch(r'HOST_TINY_CTOR path=(/private/tmp/amu-timing-C-[^ /]+/known.dylib) fileMode=400 dirMode=700\n(?:HG_STAGE ENTRY\n)?',r['stderr']);assert match and match[1]==r['privateCopyPath'];assert not Path(match[1]).exists() and not Path(match[1]).parent.exists()
   assert r['loadedPrivateFileMode']==400 and r['privateDirectoryMode']==700
   if r['case']=='supported-tiny-C':assert r['stderr'].endswith('HG_STAGE ENTRY\n')
   else:assert 'HG_STAGE' not in r['stderr'] and r['envControl']['HG_TEST_FAULT']=='error'
 else:assert r['exit']==1 and r['stdout']=='' and 'HOST_TINY_CTOR' not in r['stderr'] and 'HG_STAGE' not in r['stderr']
 rows.append({'case':r['case'],'exit':r['exit'],'rawSha256':sha(V/(r['case']+'.json'))})
out={'status':'PASS independent v3 retained native setup review; known trusted tiny C positive admission verified, performance not admitted','sourceSha256':sha(s),'ownerTerminalSha256':sha(V/'terminal-report.json'),'ownerReportSha256':sha(V/'report.json'),'ownerPinsSha256':sha(V/'artifact-pins.json'),'ownerPinsRehashed':37,'inputPinsRehashed':len(pr['inputPins']),'priorStaticReviewTerminalSha256':sha(P/'terminal-report.json'),'priorStaticSourceLoopContextCPUGateReviewUnchanged':True,'actualBuilds':3,'retainedNativeControls':8,'controlOutcomes':rows,'knownCByteBinding':{'completeEmbeddedBytes':33808,'bytesSha256':sha(V/'tiny-c.dylib'),'headerSha256':sha(V/'embedded.h'),'export':'run','requiredMask':6,'sourceSnapshotBeforeBuild':'Author order, prereg captured inputs, native compiler argv use own frozen39cdbf copy; trusted orchestration timestamps not an independently instrumented build proof.'},'privateCopy':'Actual trusted constructor reports owned private file0400 and directory0700; final paths absent and retained before/after directory set equality. Two successful C starts, one raw RET success, five refusals without constructor or ENTRY.','diagnosticBoundary':'C tiny identity returnsn with n0; constructor reads stat/dladdr and stderr only. No original benchmark C, workload guest, timing comparison or officialscore. Diagnostic elapsed fields retained uninterpreted.','contractBoundary':'New versioned scoped single-thread exclusive context writer host; trusted exact source/header/compiler/OS/dependencies. Does not inherit frozen production loader or authorize arbitrary C/plugin/generic ABI. No source or expectation changes and no native reruns by independent reviewer.','remaining':['Final actual19 C artifacts/exports/dependencies + baseline/candidate bytes/offset/mask6 headers/runner pins','Fresh target CPU/actualISA/publicfuel preflight','One prospective full19 quiet campaign prereg and ROOT GO'],'nativeRunsByIndependentReviewer':0,'timingRuns':0,'productAdoption':False,'goalAchieved':False};write(D/'report.json',out)
for f,x in pr['inputPins'].items():assert sha(Path(f))==x
fs=sorted(p for p in D.rglob('*') if p.is_file() and p.name not in ['artifact-pins.json','terminal-report.json']);write(D/'artifact-pins.json',{str(p.relative_to(D)):sha(p) for p in fs});t={'status':out['status'],'reportSha256':sha(D/'report.json'),'pinsSha256':sha(D/'artifact-pins.json'),'pins':len(fs),'nativeRuns':0,'timingRuns':0};write(D/'terminal-report.json',t);print(json.dumps(t,indent=2));print('TERMINAL',sha(D/'terminal-report.json'))
