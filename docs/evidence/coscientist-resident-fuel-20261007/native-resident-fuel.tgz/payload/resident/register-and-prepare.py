from pathlib import Path
import json,hashlib,shutil
W=Path(__file__).parent;I=W/'implementation';B=Path('/private/tmp/amu-hardware-aes-20261006/implementation-v2');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
auth=W/'root/experiment-authorization.json';inputs=json.loads(auth.read_text())['inputs']
for p,h in inputs.items():assert sha(Path(p))==h,(p,h)
inputs[str(auth)]=sha(auth)
prereg={'status':'PREREGISTERED before source edits and native execution','hypothesis':'Exclusive-loader-certified, no-call contiguous six nonleaf fuel charges may reuse x16 while preserving six separate decrements and stores; insufficient fuel retains exact original prefix. No bulk debit.','baselineInputs':inputs,'algorithmAuthoringException':'One new bounded Kotoba compiler helper and diagnostic C/stdlib harness; no AST rewrite framework yet; purpose exact original publication machine experiment.','feature':{'canonicalDefault':0,'explicitExperimentalOptin':1,'embeddedRequiredHostFeatures':6,'genericABIClaim':False,'noSameChildWriterProof':'Contiguous emitter region has no calls, arithmetic beyond decrements, memory store except CTX-FUEL, or capability; loader feature alone is insufficient.'},'machine':{'register':16,'guard':'LDR x16,[x7,#8]; CMP x16,#6; B.LO old-six','fast':'six SUBS x16,x16,#1 then STR x16,[x7,#8]; branch over slow','slow':'exact six old LDR/SUBS/B.HS/BRK/STR blocks','downstream':'args, mode!=0 generic BL, AES value ops remain unchanged','capSiteWords':96,'capModuleWords':4096,'capSites':64},'finiteBounds':{'activeCompilerGenerations':4,'disabledCompilerControlBuilds':1,'observerCompilerControlBuilds':1,'originalWorkloads':19,'ordinaryInputsPerWorkload':3,'fuelCases':[0,1,2,3,4,5,6,7,8,9,4294967295,9223372036854775807,9223372036854775808,18446744073709551615],'typedProgramsMax':8,'machineMutantsMax':8,'nativeControlProcessesMax':800,'wallSecondsPerNativeControl':30,'compilerWallSeconds':1800},'requiredGates':['native generations2/3/4 identical','defaultoff exact original19 AESv2 native bytes+offset','full19 ordinary result/fuel/resources','actual unsigned guard six publications and insufficient old prefix','invalid mode generic path','x19..28 sentinels','open/FADDR preserved','independent machine/SMT fault controls'],'diagnosticAdapters':'Root explicitly authorizes owned reporter/arity adapter separately; freeze source delta exact gate and mask6. Also unchanged embedded loader with arity0 thin entry control.','performanceAuthorized':False,'productEdited':False}
(W/'preregistration.json').write_text(json.dumps(prereg,indent=2)+'\n')
h=(B/'aes-native.kotoba').read_text();old='(defn- as-charges [M :vector-i64 n :i64]';assert h.count(old)==1
new='''(def rf-feature 0)
(defn- rf-stores [M :vector-i64 n :i64] :vector-i64
 (if (= n 0) M (rf-stores (-> M (gn-emit (enc-subs-i 16 16 1)) (gn-emit (enc-str 16 7 CTX-FUEL))) (dec n))))
(defn- rf-charges [M :vector-i64] :vector-i64
 (if (= rf-feature 0) (as-charges M 6)
  (let [m0 (-> M (gn-emit (enc-ldr 16 7 CTX-FUEL)) (gn-emit (enc-subs-i 31 16 6)))
        guard (vector-at m0 MM-CODE-N) m1 (-> m0 (gn-emit (enc-bcond (enc-cond-lo) 0)) (rf-stores 6))
        jump (vector-at m1 MM-CODE-N) m2 (gn-emit m1 (enc-b 0)) slow (vector-at m2 MM-CODE-N)
        m3 (as-charges m2 6) after (vector-at m3 MM-CODE-N)]
   (-> m3 (gn-put (+ MM-CODE-BASE guard) (enc-bcond (enc-cond-lo) (- slow guard)))
          (gn-put (+ MM-CODE-BASE jump) (enc-b (- after jump)))))))
'''
# as-charges must be defined before rf-charges, exact insertion before as-call
h=h.replace('(defn- as-call [',new+'(defn- as-call [');h=h.replace('(gn-emit (enc-cbnz 0 0)) (as-charges 6)','(gn-emit (enc-cbnz 0 0)) (rf-charges)')
assert h.count('(def rf-feature 0)')==1
(I/'aes-native-default.kotoba').write_text(h);active=h.replace('(def rf-feature 0)','(def rf-feature 1)');(I/'aes-native.kotoba').write_text(active)
g=(B/'41-a64gen-prototype.kotoba').read_text();original=(B/'aes-native.kotoba').read_text();assert g.count(original)==1;g=g.replace(original,active);(I/'41-a64gen-prototype.kotoba').write_text(g)
u=(B/'unity.kotoba').read_text();assert u.count(original)==1;u=u.replace(original,active);(I/'unity.kotoba').write_text(u)
for name in ['42-layout-prototype.kotoba','kexe-loader']:shutil.copy2(B/name,I/name)
shutil.copytree(B/'source-snapshot',I/'source-snapshot',dirs_exist_ok=True)
for d,s in [('seed-0.bin','seed-4.bin'),('seed-0.offset','seed-4.offset')]:shutil.copy2(B/s,I/d)
shutil.copy2(B/'ports-build.json',I/'baseline-ports.json')
for name in ['build.py','ports.py','observe.py']:shutil.copy2(B/name,I/name)
(I/'input-pins.json').write_text(json.dumps({str(p):sha(p) for p in [I/'seed-0.bin',I/'kexe-loader',W/'preregistration.json',auth]},indent=2)+'\n')
(I/'source-pins.json').write_text(json.dumps({str(p):sha(p) for p in [I/'aes-native-default.kotoba',I/'aes-native.kotoba',I/'41-a64gen-prototype.kotoba',I/'unity.kotoba',I/'42-layout-prototype.kotoba']},indent=2)+'\n')
(I/'feature-recipe.json').write_text(json.dumps({'requiredEmbeddedMask':6,'residentFuelOptin':1,'canonicalDefault':0,'recipeNotDefCID':True,'source':sha(I/'41-a64gen-prototype.kotoba'),'rawArtifactNotAutomaticallyAttested':True},indent=2)+'\n')
print('PREREG',sha(W/'preregistration.json'));print('SOURCE',sha(I/'41-a64gen-prototype.kotoba'))
