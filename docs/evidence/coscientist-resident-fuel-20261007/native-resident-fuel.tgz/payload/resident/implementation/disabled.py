from pathlib import Path
import subprocess,os,re,json,hashlib
I=Path(__file__).resolve().parent;D=I/'disabled';D.mkdir(exist_ok=True);R=Path('/Users/junkawasaki/github/wt/amu-seed17');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=(I/'unity.kotoba').read_text();assert s.count('(def rf-feature 1)')==1;s=s.replace('(def rf-feature 1)','(def rf-feature 0)');(D/'unity.kotoba').write_text(s)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
def command(seed,args,log):
 q=subprocess.run([str(I/'kexe-loader'),str(seed),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);log.write_text(q.stdout+q.stderr);assert q.returncode==0,(args,q.stdout[-1200:],q.stderr[-700:]);return q.stdout
command(I/'seed-0.bin',['compile',str(D/'unity.kotoba'),'--target','aarch64-macos','--output',str(D/'seed.kseed')],D/'compile.log')
out=command(I/'seed-0.bin',['extract-native',str(D/'seed.kseed'),'--symbol','main','--output',str(D/'seed.bin')],D/'extract.log');assert int(re.search(r':offset (\d+)',out)[1])==0
base=json.loads((I/'baseline-ports.json').read_text())['entries'];rows=[]
for e in json.loads((I/'source-snapshot/bench/embench/comparison-matrix.json').read_text())['entries']:
 d=D/'ports'/e['workload'];d.mkdir(parents=True,exist_ok=True)
 command(D/'seed.bin',['compile',str(R/e['source']),'--target','aarch64-macos','--output',str(d/'image.kseed')],d/'compile.log')
 out=command(D/'seed.bin',['extract-native',str(d/'image.kseed'),'--symbol',e['symbol'],'--output',str(d/'native.bin')],d/'extract.log');off=int(re.search(r':offset (\d+)',out)[1]);b=next(x for x in base if x['workload']==e['workload']);assert sha(d/'native.bin')==b['nativeSha256'] and off==b['offset'];rows.append({'workload':e['workload'],'sha256':sha(d/'native.bin'),'offset':off});print('PASS disabled exact',e['workload'],flush=True)
(D/'parity.json').write_text(json.dumps({'status':'PASS explicit opt-in disabled exact baselineAESv2 all19 bytes and offsets','compilerSha256':sha(D/'seed.bin'),'unitySha256':sha(D/'unity.kotoba'),'featureToken':'rf-feature=0','notDefCID':True,'entries':rows},indent=2)+'\n')
