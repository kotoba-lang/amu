from pathlib import Path
import hashlib,json,difflib,re
W=Path(__file__).parent;D=W/'native-controls';D.mkdir(exist_ok=True)
C=Path('/private/tmp/amu-embedded-host-feature-gate-20261007/host-feature-loader.c');s=C.read_text();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(C)=='60402b09513923f9b8d820b117618d06831a047294b5ed120acc32d7634555ef'
assert s.count('const int command_mode = 1;')==1
new=s.replace('const int command_mode = 1;','const int command_mode = 0; /* owned diagnostic result reporter; gate/context unchanged */')
(D/'diagnostic-loader.c').write_text(new);(D/'diagnostic-loader.diff').write_text(''.join(difflib.unified_diff(s.splitlines(True),new.splitlines(True),fromfile=str(C),tofile='owned diagnostic-loader.c')))
assert re.search(r'struct kexe_context_v11 \{.*?\n\};',s,re.S)[0]==re.search(r'struct kexe_context_v11 \{.*?\n\};',new,re.S)[0]
(D/'reporter-contract.json').write_text(json.dumps({'frozenSource':str(C),'frozenSHA256':sha(C),'ownedReporterSHA256':sha(D/'diagnostic-loader.c'),'soleSourceChange':'Embedded command_mode1 to0; enables original supervisor result reporting instead of guest exit-status command behavior.','earlyGateExact':True,'contextStructExact':True,'everyGuestHeaderMask':6,'wrapper':'Arity0 immutable appended MOVZ/MOVK n then B to original entry; baseline/candidate native image prefix exact.','notProductPath':True,'unchangedGateCouplingControlRequired':True,'rootAuthorization':'collaboration root explicitly authorizes adapter/reporter; no timing'},indent=2)+'\n')
print(sha(D/'diagnostic-loader.c'))
