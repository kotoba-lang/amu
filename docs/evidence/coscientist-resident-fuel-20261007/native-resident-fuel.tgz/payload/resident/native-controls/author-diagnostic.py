from pathlib import Path
import difflib,hashlib,json
D=Path(__file__).parent;C=Path('/private/tmp/amu-embedded-host-feature-gate-20261007/host-feature-loader.c');s=C.read_text();n=s.replace('const int command_mode = 1;','const int command_mode = 0; /* diagnostic reporter only */')
needle='  /* Both decision modules are mapped here, before the fork:'
assert n.count(needle)==1
inject='''  /* Owned diagnostic inputs only. Immutable embedded code and mask6 remain
   * tied to the binary. Parent initializes once before fork; never resumes
   * or mutates child context. High-u64 controls exceed normal budget admission
   * deliberately and are NOT packaged-product budget claims. */
  for (int di=0; di<5; di++) {
    char name[32]; snprintf(name,sizeof(name),"DIAG_ARG%d",di);
    const char *v=getenv(name); if(v && parse_i64(v,&args[di])!=0)return 2;
  }
  const char *df=getenv("DIAG_FUEL");
  if(df) { uint64_t f=0; if(parse_u64(df,&f)!=0)return 2;
    kexe_initial_fuel=f; kexe_fuel_metered=1; shared->context.fuel=f; }
'''
n=n.replace(needle,inject+needle);(D/'diagnostic-loader.c').write_text(n);(D/'diagnostic-loader.diff').write_text(''.join(difflib.unified_diff(s.splitlines(True),n.splitlines(True),fromfile=str(C),tofile='owned diagnostic-loader.c')))
q=json.loads((D/'reporter-contract.json').read_text());q.update(ownedReporterSHA256=hashlib.sha256(n.encode()).hexdigest(),soleSourceChange='Three explicit diagnostic changes: command result reporter; args0..4 parent-only initialization; fuel parent-only initialization including raw u64 beyond product budget bound. Early gate/context/wire exact.',wrapper='Primary controls use immutable arity0 header direct original entry plus explicit parent-initialized diagnosticargs; unchanged frozenloader couplingcontrol appends constant32 wrapper.',notProductBudgetAdmission=True);(D/'reporter-contract.json').write_text(json.dumps(q,indent=2)+'\n')
