from pathlib import Path
import os,subprocess,json,hashlib,re,struct
D=Path(__file__).parent;I=D.parent/'implementation';B=Path('/private/tmp/amu-hardware-aes-20261006/implementation-v2');T=D/'typed-abi';T.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Reuse immutable previously qualified typed source; no expected values edited.
origin=B/'typed-controls/positive/source.kotoba';(T/'source.kotoba').write_bytes(origin.read_bytes())
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
def command(seed,args,p):
 q=subprocess.run([str(I/'kexe-loader'),str(seed),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);p.write_text(q.stdout+q.stderr);assert q.returncode==0,(p,q.stdout[-1500:],q.stderr[-1000:]);return q.stdout
offsets={}
for label,seed in [('baseline',B/'seed-4.bin'),('candidate',I/'seed-4.bin'),('observer',I/'observer/seed.bin')]:
 p=T/label;p.mkdir(exist_ok=True);command(seed,['compile',str(T/'source.kotoba'),'--target','aarch64-macos','--output',str(p/'image.kseed')],p/'compile.log');offsets[label]={}
 for symbol in ['forward','modes','run']:
  out=command(seed,['extract-native',str(p/'image.kseed'),'--symbol',symbol,'--output',str(p/(symbol+'.bin'))],p/(symbol+'-extract.log'));offsets[label][symbol]=int(re.search(r':offset (\d+)',out)[1])
for symbol in offsets['candidate']:assert sha(T/'candidate'/(symbol+'.bin'))==sha(T/'observer'/(symbol+'.bin')) and offsets['candidate'][symbol]==offsets['observer'][symbol]
assert len([l for l in (T/'observer/compile.log').read_text().splitlines() if l.startswith('ASPRE ')])==3
# Header/build helpers from owned run.py only definitions, never run its main.
s=(D/'run.py').read_text();exec(s[:s.index('for c in cand:')],globals());rows=[]
for label in ['baseline','candidate']:
 for symbol in offsets[label]:build('typed-abi/'+label+'/'+symbol,(T/label/(symbol+'.bin')).read_bytes(),offsets[label][symbol])
fuels=[0,1,2,3,4,5,6,7,8,9,4294967295,9223372036854775807,9223372036854775808,18446744073709551615]
argslist=[('forward',[0,0,0,0,0]),('forward',[-9223372036854775808,9223372036854775807,-1,0,-9223372036854775808])]+[('modes',[m,0x12345678,-1,-9223372036854775808,9223372036854775807]) for m in [0,1,-1,9223372036854775807]]+[('run',[32])]
# pair helper expectsname/baseline,candidate dirs; symbolic dirs reversed, use own.
def compare(symbol,args,fuel,tag):
 out=[]
 for label in ['baseline','candidate']:
  p=T/label/symbol;e=dict(os.environ,KEXE_STRUCTURED_REPORT='1',DIAG_FUEL=str(fuel));e.update({'DIAG_ARG'+str(i):str(v) for i,v in enumerate(args)});q=subprocess.run([str(p/'loader')],env=e,capture_output=True,text=True,timeout=30);r={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};(p/(tag+'.json')).write_text(json.dumps(r,indent=2)+'\n');out.append(r)
 assert out[0]==out[1],(symbol,args,fuel,out);rows.append({'symbol':symbol,'args':args,'fuel':fuel,'tag':tag,'outcome':out[1]});return out[1]
for a,(symbol,args) in enumerate(argslist):
 for f in fuels:compare(symbol,args,f,'a'+str(a)+'-f'+str(f))
# Actual wrapper preserves external ABI, tests every x19..28 sentinel across guest.
def abi(raw,off,mutant=False):
 words=[0xd10183ff] # SUB SP,SP,#96
 def stp(a,b,o):return 0xa9000000|((o//8)&127)<<15|(b<<10)|(31<<5)|a
 def ldp(a,b,o):return 0xa9400000|((o//8)&127)<<15|(b<<10)|(31<<5)|a
 for i in range(0,10,2):words.append(stp(19+i,20+i,i*8))
 words.append(stp(29,30,80))
 for r in range(19,29):words.append(0xd2800000|((700+r)<<5)|r)
 call=len(raw)//4+len(words);words.append(0x94000000|((off//4-call)&0x3ffffff))
 if mutant:words.append(0xd2800013) # actual x19clobber test
 checks=[]
 for r in range(19,29):
  words.extend([0xd2800000|((700+r)<<5)|16,0xeb10001f|(r<<5)]);checks.append(len(words));words.append(0)
 jump=len(words);words.append(0);fail=len(words);words.extend([0xd2800000|(0xdead<<5),0xf2a00000|(0xbeef<<5)])
 restore=len(words)
 for ix in checks:words[ix]=0x54000001|(((fail-ix)&0x7ffff)<<5)
 words[jump]=0x14000000|((restore-jump)&0x3ffffff)
 for i in range(0,10,2):words.append(ldp(19+i,20+i,i*8))
 words.extend([ldp(29,30,80),0x910183ff,0xd65f03c0]);return raw+b''.join(struct.pack('<I',v) for v in words),len(raw)
for label in ['baseline','candidate']:
 raw=(T/label/'run.bin').read_bytes();blob,off=abi(raw,offsets[label]['run']);build('typed-abi/'+label+'/abi',blob,off)
for f in fuels:compare('abi',[32],f,'f'+str(f))
blob,off=abi((T/'candidate/run.bin').read_bytes(),offsets['candidate']['run'],True);p=build('typed-abi/callee-clobber-mutant',blob,off);q=subprocess.run([str(p/'loader')],env=dict(os.environ,KEXE_STRUCTURED_REPORT='1',DIAG_ARG0='32',DIAG_FUEL='1048576'),capture_output=True,text=True,timeout=30);r={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};(p/'run.json').write_text(json.dumps(r));assert ':result 3203391149' in q.stdout,(r) # 0xbeefdead
(T/'report.json').write_text(json.dumps({'status':'PASS typed args/value/dynamicnonzero modes/raw-u64 fuel prefix/x19..28 sentinels','sourceOrigin':str(origin),'sourceSHA256':sha(origin),'admissions':3,'offsets':offsets,'pairs':len(rows),'processes':len(rows)*2+1,'rows':rows,'builds':builds,'calleeClobberMutantDetected':r,'notTiming':True,'scope':'Arity0 embedded mask6 with owned parentargs/fuel initialization. Explicit sentinelwrapper ABI, unchanged original native prefix.'},indent=2)+'\n');print('PASS typedABI',len(rows),flush=True)
