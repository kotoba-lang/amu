from pathlib import Path
import os,subprocess,json,hashlib,re
D=Path(__file__).parent;I=D.parent/'implementation';B=Path('/private/tmp/amu-hardware-aes-20261006/implementation-v2');G=D/'g1-adapted';G.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();R=Path('/Users/junkawasaki/github/wt/amu-seed17');S=D.parent/'root-formal/source'
(G/'preregistration.json').write_text(json.dumps({'status':'Preregistered G1 root-authorized finite adapter before native actions','source':'root-formal committed44bf singleiteration ports, unchanged exports/expected1','compilers':['frozenAESv2','residentcandidatea236'],'maxTargetCompiles':38,'maxNativeProcesses':76,'maxEmbeddedCBinaries':76,'fuel':16777216,'arena':{'pairs':2097152,'vectors':4096,'items':65536},'paths':['frozenloader commandreturn1','ownedreporter result1'],'rawKBOmitted':True,'notUnmodifiedG1Script':True,'timing':False},indent=2)+'\n')
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
def command(seed,args,p):
 q=subprocess.run([str(I/'kexe-loader'),str(seed),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);p.write_text(q.stdout+q.stderr);assert q.returncode==0,(p,q.stdout[-1000:],q.stderr);return q.stdout
s=(D/'run.py').read_text();exec(s[:s.index('for c in cand:')],globals());rows=[]
for src in sorted((S/'bench/embench/ports').glob('*.kotoba')):
 name=src.stem;sym=re.search(r':export \[[^]]*(test-[a-z0-9-]*)',src.read_text().splitlines()[0])[1];row={'workload':name,'source':str(src),'sourceSHA256':sha(src),'symbol':sym,'expectedResult':1,'entries':[]}
 for label,seed in [('baseline',B/'seed-4.bin'),('candidate',I/'seed-4.bin')]:
  p=G/name/label;p.mkdir(parents=True,exist_ok=True);command(seed,['compile',str(src),'--target','aarch64-macos','--output',str(p/'image.kseed')],p/'compile.log');out=command(seed,['extract-native',str(p/'image.kseed'),'--symbol',sym,'--output',str(p/'native.bin')],p/'extract.log');off=int(re.search(r':offset (\d+)',out)[1])
  obs=[]
  for route,loader in [('frozen',Path('/private/tmp/amu-embedded-host-feature-gate-20261007/host-feature-loader.c')),('reporter',D/'diagnostic-loader.c')]:
   guest=build('g1-adapted/'+name+'/'+label+'/'+route,(p/'native.bin').read_bytes(),off,loader)
   # Preserve exact G1 baked fuel and arenas instead of diagnostic default.
   h=(guest/'embedded.h').read_text().replace('KEXE_EMBEDDED_FUEL 1048576u','KEXE_EMBEDDED_FUEL 16777216u').replace('KEXE_EMBEDDED_PAIRS 1048576u','KEXE_EMBEDDED_PAIRS 2097152u').replace('KEXE_EMBEDDED_VECTORS 131072u','KEXE_EMBEDDED_VECTORS 4096u').replace('KEXE_EMBEDDED_VECTOR_ITEMS 4194304u','KEXE_EMBEDDED_VECTOR_ITEMS 65536u');(guest/'embedded-defaults.h').write_bytes((guest/'embedded.h').read_bytes());(guest/'embedded-defaults-loader').write_bytes((guest/'loader').read_bytes());(guest/'embedded.h').write_text(h)
   q=subprocess.run(['clang','-O2','-std=c11','-include',str(guest/'embedded.h'),str(loader),'-o',str(guest/'loader')],capture_output=True,text=True);(guest/'g1build.stdout').write_text(q.stdout);(guest/'g1build.stderr').write_text(q.stderr);assert q.returncode==0,q.stderr
   e=dict(os.environ,KEXE_STRUCTURED_REPORT='1');e.pop('DIAG_FUEL',None)
   q=subprocess.run([str(guest/'loader')],env=e,capture_output=True,text=True,timeout=30);r={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr,'sourceSHA256':sha(loader),'headerSHA256':sha(guest/'embedded.h'),'binarySHA256':sha(guest/'loader')};(guest/'run.json').write_text(json.dumps(r,indent=2)+'\n')
   assert q.returncode==(1 if route=='frozen' else 0),(name,label,route,r)
   if route=='reporter':assert ':result 1 ' in q.stdout,(r)
   obs.append({'route':route,**r})
  row['entries'].append({'compiler':label,'nativeSHA256':sha(p/'native.bin'),'offset':off,'observations':obs})
 assert row['entries'][0]['observations'][1]['stdout']==row['entries'][1]['observations'][1]['stdout']
 row['candidateByteOffsetExactBaseline']=row['entries'][0]['nativeSHA256']==row['entries'][1]['nativeSHA256'] and row['entries'][0]['offset']==row['entries'][1]['offset'];rows.append(row);print('PASS G1 admitted',name,row['candidateByteOffsetExactBaseline'],flush=True)
assert len(rows)==19
(G/'report.json').write_text(json.dumps({'status':'PASS featureadmitted G1 functional 19x2seedx2route controls; unmodified script/rawKB NOT claimed','rows':rows,'processes':76,'originalExpected1Unchanged':True,'originalSourceUnchanged':True,'rawKBStatus':'OMITTED outside frozen embedded ownership contract; no timing claims','allCandidateBytesOffsetsAESv2Exact':all(r['candidateByteOffsetExactBaseline'] for r in rows),'frozenCommandTrapLabel':'Structured originalloader labels nonzero commandexit1 trap; commandreturn1 is originalexpectedresult. Ownedreporter confirms successful completed result1.','notTiming':True},indent=2)+'\n')
