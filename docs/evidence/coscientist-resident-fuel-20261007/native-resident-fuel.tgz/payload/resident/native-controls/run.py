from pathlib import Path
import os,subprocess,json,hashlib,struct
D=Path(__file__).parent;I=D.parent/'implementation';B=Path('/private/tmp/amu-hardware-aes-20261006/implementation-v2');C=D/'diagnostic-loader.c';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((B/'ports-build.json').read_text())['entries'];cand=json.loads((I/'ports-build.json').read_text())['entries'];rows=[];builds=[]
def build(name,blob,off,source=C):
 p=D/name;p.mkdir(parents=True,exist_ok=True);(p/'image.bin').write_bytes(blob)
 vals={'REQUIRED_HOST_FEATURES':'6ULL','OFFSET':str(off)+'u','ARITY':'0u','ISA':'"aarch64"','ALLOW':'"-"','SCOPE35':'""','SCOPE34':'""','SPAWN_PROGRAMS':'""','SPAWN_ENV':'""','SPAWN_PATH_LOOKUP':'0','STRING_POOL':'16777216u','FUEL':'1048576u','PAIRS':'1048576u','VECTORS':'131072u','VECTOR_ITEMS':'4194304u','CPU_SECONDS':'15u','WALL_SECONDS':'20u'}
 h='#define KEXE_EMBEDDED 1\n'+''.join('#define KEXE_EMBEDDED_'+k+' '+v+'\n' for k,v in vals.items())+'static const unsigned char kexe_embedded_code[] = {'+','.join(map(str,blob))+'};\n';(p/'embedded.h').write_text(h)
 cmd=['clang','-O2','-std=c11','-include',str(p/'embedded.h'),str(source),'-o',str(p/'loader')];q=subprocess.run(cmd,capture_output=True,text=True);(p/'build.stdout').write_text(q.stdout);(p/'build.stderr').write_text(q.stderr);(p/'build.status.json').write_text(json.dumps({'args':cmd,'exit':q.returncode}));assert q.returncode==0,q.stderr
 builds.append({'name':name,'source':sha(source),'header':sha(p/'embedded.h'),'binary':sha(p/'loader'),'native':sha(p/'image.bin'),'offset':off});return p
for c in cand:
 name=c['workload'];b=next(x for x in base if x['workload']==name)
 for label,origin,row in [('baseline',B,b),('candidate',I,c)]:build(name+'/'+label,(origin/'ports'/name/'native.bin').read_bytes(),row['offset'])
 print('BUILT',name,flush=True)
def pair(name,args,fuel,tag):
 out=[]
 for label in ['baseline','candidate']:
  p=D/name/label;e=dict(os.environ,KEXE_STRUCTURED_REPORT='1',DIAG_FUEL=str(fuel));e.update({'DIAG_ARG'+str(i):str(v) for i,v in enumerate(args)})
  q=subprocess.run([str(p/'loader')],capture_output=True,text=True,timeout=30,env=e);r={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};(p/(tag+'.json')).write_text(json.dumps(r,indent=2)+'\n');out.append(r)
 assert out[0]==out[1],(name,args,fuel,out)
 rows.append({'workload':name,'args':args,'fuel':fuel,'rawTag':tag,'outcome':out[1]})
for c in cand:
 for n in [0,1,32]:pair(c['workload'],[n],1048576,'n'+str(n)+'-normal')
for n in [0,1,32]:
 for f in [0,1,2,3,4,5,6,7,8,9,4294967295,9223372036854775807,9223372036854775808,18446744073709551615]:pair('nettle-aes',[n],f,'n'+str(n)+'-f'+str(f))
# Gate coupling uses exactly frozen C and arity0 constant-n appended wrapper.
c=next(x for x in cand if x['workload']=='nettle-aes');raw=(I/'ports/nettle-aes/native.bin').read_bytes();at=len(raw)//4;target=c['offset']//4;wrapper=struct.pack('<II',0xd2800400,0x14000000|((target-(at+1))&0x3ffffff));p=build('unchanged-frozen-loader-coupling',raw+wrapper,len(raw),Path('/private/tmp/amu-embedded-host-feature-gate-20261007/host-feature-loader.c'))
q=subprocess.run([str(p/'loader')],capture_output=True,text=True,timeout=30,env=dict(os.environ,KEXE_STRUCTURED_REPORT='1'));r={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};(p/'run.json').write_text(json.dumps(r,indent=2)+'\n');assert q.returncode==1,(r)
assert len(rows)*2+1<=800
(D/'report.json').write_text(json.dumps({'status':'PASS scoped embeddedmask6 native fullsupervisor equality','pairs':len(rows),'processes':len(rows)*2+1,'entries':rows,'builds':builds,'unchangedFrozenLoaderCoupling':r,'ownership':'Only parent initializes context before single child; mask6 alone does not admit arbitrary samechild mutation. Generated region separately proved no calls/writes aside original fuel stores.','u64Scope':'Diagnostic parent initialization deliberately beyond normal product ceiling; not a product admission guarantee.','zeroScope':'Diagnostic metered fuel0; original production admission zero differs. Actual prefix parity retained.','notTiming':True,'productEdited':False},indent=2)+'\n');print('PASS native pairs',len(rows),flush=True)
