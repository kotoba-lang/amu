"""Prospective bounds contract under stated exact-length/normal-allocation assumptions."""
from pathlib import Path
import json,z3 as z
W=Path(__file__).resolve().parent
actual,fact,index=z.BitVecs('actual_length proved_length index',64)
small=lambda x:z.ULE(x,z.BitVecVal(4096,64));eligible=z.And(index>=0,z.ULT(index,fact));checks=[]
items=[('exact-small-length-implies-original-unsigned-bound',z.And(actual==fact,small(fact),eligible),z.ULT(index,actual),'unsat'),('wrong-constructor-length-is-unsound',z.And(actual==0,fact==1,index==0,eligible),z.ULT(index,actual),'sat'),('merged-different-length-is-unsound',z.And(actual==0,fact==3,index==2,eligible),z.ULT(index,actual),'sat'),('negative-index-cannot-use-signed-only-bound',z.And(actual==3,index<actual,index==-1),z.ULT(index,actual),'sat')]
for name,assume,claim,expect in items:
 s=z.Solver();s.add(assume,z.Not(claim));result=str(s.check());assert result==expect
 checks.append({'name':name,'result':result,'counterexample':str(s.model()) if result=='sat' else None})
out={'status':'PASS prospective64-bit unsigned bounds laws and negative controls','solverVersion':z.get_version_string(),'checks':checks,'assumptions':['Actual successfully allocated length equals static fact at this particular private callsite.','Existing handle validation still executes in original order; these laws do not remove it.','Traps, fuel, resource limits and partial vectors remain observed separately.'],'nativeEmitterProof':False,'boundsChecksRemoved':0,'performanceClaim':False}
(W/'laws-proof.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
