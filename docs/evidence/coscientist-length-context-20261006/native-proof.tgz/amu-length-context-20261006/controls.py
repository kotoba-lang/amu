from pathlib import Path
import json,os,re,subprocess
from verify import C,O,verify,shape,inference
W=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17');F=[]
def fn(name,np,rt,body):F.append((name,np,rt,body))
fn('reader',1,C['TY-I64'],[('LGET',0,1),('CONST',1,2),('RT',176,0,2),('RET',0)])
fn('identity',1,4,[('LGET',0,1),('RET',0)])
fn('other-alias',2,4,[('LGET',0,2),('RET',0)])
fn('effect',1,4,[('LGET',0,1),('CAP',1,0,0),('RET',0)])
fn('ctor-three',0,C['TY-I64'],[('CONST',0,3),('RT',200,0,1),('CALL','reader',0,1),('RET',0)])
fn('ctor-empty',0,C['TY-I64'],[('CONST',0,0),('RT',200,0,1),('CALL','reader',0,1),('RET',0)])
fn('ctor-five',0,C['TY-I64'],[('CONST',0,5),('RT',200,0,1),('CALL','reader',0,1),('RET',0)])
fn('ctor-negative',0,C['TY-I64'],[('CONST',0,-1),('RT',200,0,1),('CALL','reader',0,1),('RET',0)])
fn('ctor-large',0,C['TY-I64'],[('CONST',0,4097),('RT',200,0,1),('CALL','reader',0,1),('RET',0)])
fn('ctor-identity-chain',0,C['TY-I64'],[('CONST',0,3),('RT',200,0,1),('CALL','identity',0,1),('CALL','reader',0,1),('RET',0)])
fn('ctor-other-alias-clears',0,C['TY-I64'],[('CONST',0,3),('RT',200,0,1),('CONST',1,0),('CALL','other-alias',0,2),('CALL','reader',0,1),('RET',0)])
fn('ctor-effect-clears',0,C['TY-I64'],[('CONST',0,3),('RT',200,0,1),('LSET',1,0),('CALL','effect',0,1),('LGET',0,1),('CALL','reader',0,1),('RET',0)])
fn('ctor-indirect-clears',0,C['TY-I64'],[('CONST',0,3),('RT',200,0,1),('LSET',1,0),('CALLI',0,0,0),('LGET',0,1),('CALL','reader',0,1),('RET',0)])
fn('different-length-join-clears',0,C['TY-I64'],[('CONST',0,3),('RT',200,0,1),('CONST',1,0),('BRZ',1,1),('CONST',0,5),('RT',200,0,1),('BR',2),('LABEL',1),('LABEL',2),('CALL','reader',0,1),('RET',0)])
fn('same-length-other-handle-join-retains',0,C['TY-I64'],[('CONST',0,3),('RT',200,0,1),('CONST',1,0),('BRZ',1,3),('CONST',0,3),('RT',200,0,1),('BR',4),('LABEL',3),('LABEL',4),('CALL','reader',0,1),('RET',0)])
fn('unknown-index-not-admitted',0,C['TY-I64'],[('CONST',0,3),('RT',200,0,1),('LSET',1,0),('LGET',0,1),('LGET',1,2),('RT',176,0,2),('RET',0)])
fn('literal-negative-index',0,C['TY-I64'],[('CONST',0,3),('RT',200,0,1),('CONST',1,-1),('RT',176,0,2),('RET',0)])
fn('literal-at-length',0,C['TY-I64'],[('CONST',0,3),('RT',200,0,1),('CONST',1,3),('RT',176,0,2),('RET',0)])
fn('zero-index-into-empty',0,C['TY-I64'],[('CONST',0,0),('RT',200,0,1),('CONST',1,0),('RT',176,0,2),('RET',0)])
fn('loop-changes-length',0,C['TY-I64'],[('CONST',0,3),('RT',200,0,1),('LSET',1,0),('LABEL',5),('CONST',2,0),('BRZ',2,6),('CONST',0,5),('RT',200,0,1),('LSET',1,0),('BR',5),('LABEL',6),('LGET',0,1),('CALL','reader',0,1),('RET',0)])
fn('writer',1,4,[('LGET',0,1),('CONST',1,2),('CONST',2,9),('RT',208,0,3),('RET',0)])
fn('ctor-store-return',0,C['TY-I64'],[('CONST',0,3),('RT',200,0,1),('CALL','writer',0,1),('CALL','reader',0,1),('RET',0)])
fn('recursive',1,4,[('LGET',0,1),('CONST',1,0),('BRZ',1,7),('CALL','recursive',0,1),('LABEL',7),('RET',0)])
fn('ctor-recursive-return',0,C['TY-I64'],[('CONST',0,3),('RT',200,0,1),('CALL','recursive',0,1),('CALL','reader',0,1),('RET',0)])
fn('same-length-newalloc-keeps-old-local',0,C['TY-I64'],[('CONST',0,3),('RT',200,0,1),('LSET',1,0),('CONST',0,5),('RT',200,0,1),('LGET',0,1),('CALL','reader',0,1),('RET',0)])
ids={x[0]:f for f,x in enumerate(F,1)};writes=[(C['MM-SIR-N'],1),(C['MM-FN-N'],len(F)+1)];pos=1
for f,(name,np,rt,body) in enumerate(F,1):
 b=C['MM-FN-BASE']+f*C['MM-FN-W']
 for field,v in [('FF-SIR',pos),('FF-NPARAMS',np),('FF-NSLOTS',2),('FF-DEPTH',3),('FF-RTYPE',rt),('FF-PT0',4)]:writes.append((b+C[field],v))
 ins=[(O('FN'),f,np,2)]+[(O(x[0]),*(tuple(ids[v] if isinstance(v,str) else v for v in x[1:])+(0,)*(4-len(x)))) for x in body]+[(O('END'),f,0,0)]
 for row in ins:
  for k,v in enumerate(row):writes.append((C['MM-SIR-BASE']+pos*C['MM-SIR-W']+k,v))
  pos+=1
writes.append((C['MM-SIR-N'],pos));load=[]
for group in range(0,len(writes),20):
 chunk=writes[group:group+20];n=group//20;load.append('(defn- t-lc-load%d [M0 :vector-i64] :vector-i64 (let [%s] M%d))'%(n,' '.join('M%d (mem-set M%d %d %d)'%(i+1,i,a,v) for i,(a,v) in enumerate(chunk)),len(chunk)))
expr='(vector-alloc MM-WORDS)'
for n in range((len(writes)+19)//20):expr='(t-lc-load%d %s)'%(n,expr)
entry='\n'.join(load)+'\n(defn- seed-main [] :i64 (let [M '+expr+' sir (sh-sir M 1) meta (sh-meta M 1) report (sh-report M) length (lc-report M)] 0))\n'
base='\n'.join((R/p).read_text() for p in ['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'])+'\n'+(W/'baseline-41-a64gen.kotoba').read_text()+'\n'+(W/'shape-native.kotoba').read_text()+'\n';code=(W/'length-native.kotoba').read_text();mutants={'correct':code,
 'wrong-constructor-length':code.replace('value (if (> kind 0) len 0)','value (if alloc (inc len) (if (> kind 0) len 0))'),
 'unsafe-join-first-path':code.replace('nk (if keep hk 0) nv (if (= nk 0) 0 hv)','nk (if first hk oldk) nv (if first hv oldv)'),
 'unknown-call-preserves-old-locals':code.replace('h1 (if closed h0 (lc-zero h0 0))','h1 h0'),
 'collapse-distinct-length-contexts':code.replace('(and (= (vector-at J (+ 16 (* 2 j))) f) (= (vector-at J (+ 17 (* 2 j))) len))','(= (vector-at J (+ 16 (* 2 j))) f)'),
 'zero-cfg-budget':code.replace('(* 128 (- end p))','0')}
# Hand expectations are authored before execution, separate from the tuple oracle.
expected={'readerPrivateLengths':[0,3,5],'mustNotSeedReader':['ctor-negative','ctor-large','ctor-other-alias-clears','ctor-effect-clears','ctor-indirect-clears','different-length-join-clears','loop-changes-length'],'mustSeedReaderLength3':['ctor-three','ctor-identity-chain','same-length-other-handle-join-retains','ctor-store-return','ctor-recursive-return','same-length-newalloc-keeps-old-local'],'outsideRangeRoots':['literal-negative-index','literal-at-length','zero-index-into-empty'],'noAccessRoot':'unknown-index-not-admitted'}
(W/'control-expectations.json').write_text(json.dumps({'functions':ids,'expected':expected},indent=2)+'\n')
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[]
for name,native in mutants.items():
 d=W/'controls'/name;d.mkdir(parents=True,exist_ok=True);src=d/'probe.kotoba';src.write_text(base+native+'\n'+entry)
 for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(d/'probe.kseed')]),('extract',['extract-native',str(d/'probe.kseed'),'--symbol','main','--output',str(d/'probe.bin')])]:
  q=subprocess.run([str(W/'observer/kexe-loader'),str(W/'observer/seed-0.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,label,q.stdout[-500:],q.stderr)
  if label=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(W/'observer/kexe-loader'),str(d/'probe.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(d/'stdout').write_text(q.stdout+q.stderr);assert q.returncode==0,(name,q.stderr)
 s,m,flags,end=shape.parse(d/'stdout');contexts,calls,accesses,status=inference(s,m,flags)
 assert sorted(n for f,n in contexts if f==ids['reader'] and n>=0)==[0,3,5]
 for n in expected['mustNotSeedReader']:assert not any(x[0]==ids[n] and x[3]==ids['reader'] for x in calls),n
 for n in expected['mustSeedReaderLength3']:assert any(x[0]==ids[n] and x[3:]==(ids['reader'],3) for x in calls),n
 for n in expected['outsideRangeRoots']:assert any(x[0]==ids[n] and not 0<=x[4]<x[3] for x in accesses),n
 assert not any(x[0]==ids[expected['noAccessRoot']] for x in accesses)
 try:counts=verify(d/'stdout');detected=False;failure=None
 except AssertionError as e:detected=True;failure=str(e)
 assert detected==(name!='correct'),(name,detected)
 rows.append({'variant':name,'expected':'PASS' if name=='correct' else 'DETECTED','detected':detected,'failure':failure,'functions':len(F),'exit':q.returncode});print(name,rows[-1]['expected'],flush=True)
(W/'controls-proof.json').write_text(json.dumps({'status':'PASS native constructor/alias/join/loop/context controls and five actual source mutants','rows':rows},indent=2)+'\n')
