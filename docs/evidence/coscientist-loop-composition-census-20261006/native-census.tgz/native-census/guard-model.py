# Bootstrap oracle for a prospective guard, not product code or native qualification.
from pathlib import Path
import random,json
w=Path('/private/tmp/amu-loop-composition-census-20261006');rng=random.Random(2026100601);MIN=-(1<<63);MAX=(1<<63)-1
wrap=lambda x:((x+(1<<63))%(1<<64))-(1<<63)
def admit(n,sa,sb,oa,ob,row,col,k,length,fuel):
 return (1<=n<=64 and 1<=sa<=64 and 1<=sb<=64 and 0<=oa<=4095 and 0<=ob<=4095 and k==0 and 0<=row<n and 0<=col<n and fuel>=n and max(oa+row*sa+n-1,ob+(n-1)*sb+col)<length)
count=0;accepted=0;zero=0;unsafe=0
values=[MIN,MAX,-65,-64,-1,0,1,2,19,20,21,63,64,65,4095,4096]
for n in [1,2,3,20,63,64]:
 for sa,sb,oa,ob in [(n,n,800,1200),(1,1,0,0),(64,64,4095,4095),(2,3,0,4095)]:
  for row,col,k in [(a,b,c) for a in values for b in [0,n-1,n,MIN,MAX] for c in [0,n,1,MIN,MAX]]:
   for length in [0,1,2001,8192]:
    for fuel in [0,n-1,n,n+1,MAX]:
     count+=1;ok=admit(n,sa,sb,oa,ob,row,col,k,length,fuel)
     if k==n:zero+=1;assert not ok # do not touch an unused invalid handle
     if ok:
      accepted+=1
      a=[wrap(oa+wrap(wrap(row*sa)+j)) for j in range(n)];b=[wrap(ob+wrap(wrap(j*sb)+col)) for j in range(n)]
      assert a==[oa+row*sa+j for j in range(n)] and b==[ob+j*sb+col for j in range(n)]
      assert all(0<=z<length for z in a+b) and fuel-n>=0
      v={z:rng.choice([MIN,MAX,-1,0,1,rng.randrange(MIN,MAX)]) for z in set(a+b)}
      sum0=rng.choice([MIN,MAX,-1,0,1]);orig=sum0;fast=sum0
      # Scalar recursion and sequential native i64 madd have equal low64 result.
      for j in range(n):orig=wrap(orig+wrap(v[a[j]]*v[b[j]]))
      for j in range(n):fast=wrap(v[a[j]]*v[b[j]]+fast)
      assert orig==fast
# Explicit endpoint: longest unrolled load offset still fits original unsigned LDR.
assert (64-1)*64*8<=32760
(w/'guard-model.json').write_text(json.dumps({'status':'complete-prospective-guard-model-only','cases':count,'admitted':accepted,'zeroTripRefusedBeforeHandleValidation':zero,'seed':2026100601,'covers':'i64 extremes, wrap, endpoint range, insufficient fuel, zero-trip, 1..64 trip bound, distinct positive strides and offsets; original scalar arithmetic vs sequential madd','notNativeProof':True,'notPerformanceMeasurement':True,'productChanged':False,'remaining':'Implement exact closed typed SIR matcher and native code; prove fallback descriptors/context unchanged; actual invalid handles/traps/partial states/resources/open-imports; original470/11187 and19; fresh timing/gates/integrated proofs.'},indent=2)+'\n')
print('PASS',count,'model cases;',accepted,'safe guards; native proof still required')
