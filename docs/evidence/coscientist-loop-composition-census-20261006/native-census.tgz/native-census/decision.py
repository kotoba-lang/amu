from pathlib import Path
import json,hashlib,tarfile,re,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-loop-composition-census-20261006');b=Path('/private/tmp/amu-same-local-read-20261006');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
e=next(x for x in load(w/'census.json')['entries'] if x['workload']=='matmult-int');f=e['functions']['5'];loop=f['loops'][0];assert loop['emittedWords']==47 and f['emittedWords']==73
blob=(w/'meta-ports/matmult-int/native.bin').read_bytes()
word=lambda n:struct.unpack_from('<I',blob,(n-1)*4)[0]
# Prove the exact skip ranges used for the conditional steady-path instruction count.
assert word(2181)==0xf100527f and word(2182)==0x54000061
assert word(2183)==0xaa1703e9 and word(2184)==0x1400002c
assert word(2191)==0xb4000065 and word(2192)==0xeb05001f and word(2193)==0x540001a0
assert word(2194)==0xaa0003e5 and word(2205)==0x8b110c84
assert [word(x) for x in [2200,2208,2216]]==[0,0,0]
assert word(2225)==0xd4200000
warmSkipped=set([2183,2184,2200,2208,2216,2225])|set(range(2194,2206))
coldSkipped=set([2183,2184,2192,2193,2200,2208,2216,2225])
warm=[n for n in range(2181,2228) if n not in warmSkipped];cold=[n for n in range(2181,2228) if n not in coldSkipped]
assert len(warm)==30 and len(cold)==39
# C is the exact dylib retained with the latest timing, not a rebuilt comparator.
c=b/'remote-evidence/timing-package/matmult-int/baseline/matmult-int/c.dylib';cb=load(b/'remote-evidence/timing-package/matmult-int/baseline/results.json')['entries'][0];assert sha(c)==cb['cDylibSha256']
archive=r/cb['archive'];assert sha(archive)==cb['archiveSha256']
with tarfile.open(archive) as t:
 src=t.extractfile(cb['files'][0]['member']).read();assert hashlib.sha256(src).hexdigest()==cb['files'][0]['sha256'];(w/'c-bridge.c').write_bytes(src)
text=(w/'c-disassembly.txt').read_text();instructions={}
for line in text.splitlines():
 m=re.match(r'\s*([0-9a-f]+):\s+([0-9a-f]{8})\s+(\w+)\s*(.*)',line)
 if m:instructions[int(m[1],16)]={'word':m[2],'mnemonic':m[3],'operands':m[4]}
ci=[instructions[x] for x in range(0x5cc,0x66c,4)]
assert len(ci)==40 and sum(x['mnemonic']=='ldr' for x in ci)==20 and sum(x['mnemonic']=='madd' for x in ci)==19 and sum(x['mnemonic']=='mul' for x in ci)==1
summary={'status':'complete-fresh-native-observation-and-next-decision','sourceCommit':load(w/'hypothesis.json')['sourceCommit'],'sourceSha256':load(w/'hypothesis.json')['sourceSha256'],'seedSha256':sha(w/'seed-0.bin'),'all19DiagnosticQuietBytesAndOffsetsEqual':True,'all19CompleteSIRAndEmissionPartition':True,'productChanged':False,'performanceMeasured':False,'officialEmbenchScore':False,'notRuntimeTimeShares':True,'matmult':{'nativeSha256':e['nativeSha256'],'fn':5,'fnWords':73,'loopStaticWords':47,'conditionalWarmValidIterationExecutedWords':30,'conditionalColdValidIterationExecutedWords':39,'pathConditions':'k!=20; index in range; fuel sufficient; warm key==positive source handle, cold key==0; count excludes untaken return, misses and traps, and is not measured dynamic share','warmExecutedWordPositions':warm,'coldExecutedWordPositions':cold,'cDylibSha256':sha(c),'cMultiplyBodyRegion':{'firstByte':0x5cc,'afterByte':0x66c,'words':40,'loads':20,'madd':19,'mul':1,'rowPreloadsAndLoopControlOutsideRegion':True,'notDirectTimeOrTotalInstructionComparison':True}},'decision':'Prototype whole bounded dot-loop composition with one range/fuel guard and compile-time unrolled loads/madd; preserve original frame, entry charge, fallback code and all resource/trap/partial-state semantics. C observation shows unrolling/reuse rather than SIMD in this exact region. No speedup claim from counts.'}
(w/'decision.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary['matmult'].items() if 'Positions' not in k},indent=2))
