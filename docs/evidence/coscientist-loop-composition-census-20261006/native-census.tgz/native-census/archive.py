from pathlib import Path
import shutil,json,hashlib,tarfile
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-loop-composition-census-20261006');b=Path('/private/tmp/amu-same-local-read-20261006');d=r/'docs/evidence/coscientist-loop-composition-census-20261006';d.mkdir()
shutil.copyfile(b/'ports-correctness.json',w/'quiet-product-proof.json')
shutil.copyfile(r/'bench/embench/comparison-matrix.json',w/'comparison-matrix.json')
for e in json.loads((r/'bench/embench/comparison-matrix.json').read_text())['entries']:
 p=w/'original-sources'/e['workload'];p.parent.mkdir(exist_ok=True);shutil.copyfile(r/e['source'],p.with_suffix('.kotoba'))
shutil.copyfile(b/'remote-evidence/timing-package/matmult-int/baseline/matmult-int/c.dylib',w/'c.dylib')
for n in ['hypothesis.json','decision.json','guard-model.json','count-correction.json','observer-byte-audit.json']:
 shutil.copyfile(w/n,d/n)
with tarfile.open(d/'native-census.tgz','w:gz') as t:
 for p in sorted(w.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:t.add(p,arcname='native-census/'+str(p.relative_to(w)))
with tarfile.open(d/'native-census.tgz') as t:
 for n in ['create.py','observe.py','analyze.py','decision.py','guard-model.py','seed-0.bin','observer-unity.kotoba','c.dylib','c-disassembly.txt','native-disassembly.txt','meta-ports/matmult-int/census.json']:
  p=t.extractfile('native-census/'+n).read();assert p==(w/n).read_bytes(),n
(d/'checksums.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(d.iterdir()) if p.is_file()))
print('PASS full native census archived and critical members checked')
