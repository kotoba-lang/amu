from pathlib import Path
import json,hashlib,os,subprocess,shutil,re,importlib.util
W=Path(__file__).parent;D=W/'generic192-v1';D.mkdir(exist_ok=False);A=D/'artifacts';A.mkdir();H=D/'host';H.mkdir();raw=D/'raw';raw.mkdir()
L=W.parent/'embench-pf-twoarg-20261013/protected-host/kexe-loader'
P={'OFF':W.parent/'seed-masked-positive-quotient-20261013/selfbuild-v1/host/G4.bin','ON':W/'selfbuild-v1/host/G4.bin'}
def pin(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
q=json.loads((W/'g1-fixedpoint-identity.json').read_text());assert q['status']=='PASS_G1_NATIVE_AND_CONTAINER_WHOLE_IDENTITY_G2_G3_G4'
assert pin(P['OFF'])['sha256']=='47fba216e1a65b892458216575bbb70be228d86f4b7a6d73ebae84230279f20b'
assert pin(P['ON'])['sha256']==q['nativeSHA256']
S=A/'controls.kotoba';S.write_bytes((W/'generic-fixture.kotoba').read_bytes());pins={p:pin(p)for p in[L,S,*P.values()]}
env={k:v for k,v in os.environ.items()if not k.startswith('KEXE_')};env.update(KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(A),KEXE_FUEL='off',KEXE_VECTORS='4194304',KEXE_VECTOR_ITEMS='134217728',KEXE_STRING_POOL='268435456',KEXE_PAIRS='16777216',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',TMPDIR=str(A))
calls=[]
def call(tag,args,e):
 z=subprocess.run(list(map(str,args)),cwd=A,env=e,capture_output=True,timeout=1800);(raw/(tag+'.stdout')).write_bytes(z.stdout);(raw/(tag+'.stderr')).write_bytes(z.stderr);calls.append(dict(tag=tag,exit=z.returncode));(D/'calls.json').write_text(json.dumps(calls,indent=2)+'\n');assert z.returncode==0 and all(pin(p)==v for p,v in pins.items()),(tag,z.returncode)
 return z.stdout,z.stderr
arms={}
for tag,p in P.items():
 k=A/(tag+'.kseed');b=A/(tag+'.bin');base=[L,p,'0','0','aarch64','35,37,38,39','--']
 for name,args in [('compile',['compile',S,'--target','aarch64-macos','--output',k]),('extract',['extract-native',k,'--symbol','run','--output',b])]:
  _,err=call(tag+'-'+name,base+args,env);assert not err
 h,payload=k.read_bytes().split(b'\n\n',1);assert payload==b.read_bytes();ex={n:[int(o),int(a)]for n,o,a in map(str.split,h.decode().splitlines()[1:])};arms[tag]=dict(native=pin(b),container=pin(k),source=pin(S),exports=ex,offset=ex['run'][0],arity=ex['run'][1]);assert ex['run'][1]==2
spec=importlib.util.spec_from_file_location('generic_positive_physical',W/'native-gate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);proof=m.audit(arms['OFF'],arms['ON']);assert proof['changed'],'Acceptance controls must contain actual direct-mask fusion hits';(D/'physical-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
def wrap(x):x&=(1<<64)-1;return x-(1<<64)if x>=1<<63 else x
def div(x,k):return (-1 if x<0 else 1)*(abs(x)//k)
def oracle(mode,x):
 return [x&255,(wrap(x+1)&255),0,1,2*(x&255),(x^42)&255,x&65535,None][mode]

xs=[-(1<<63),-(1<<63)+1,-65536,-65535,-1024,-256,-255,-1,0,1,7,127,128,255,256,65535,65536,(1<<63)-2,(1<<63)-1];rows=[]
guest={k:v for k,v in env.items()if not k.startswith('KEXE_')};guest.update(KEXE_ARENA_USE='1',KEXE_STRUCTURED_REPORT='1',KEXE_FUEL='100000',KEXE_CPU_SECONDS='60',KEXE_WALL_SECONDS='60')
cases=[(m,x,100000)for m in range(8)for x in xs]+[(m,-1,f)for m in range(8)for f in range(5)]
for i,(mode,x,fuel)in enumerate(cases):
 pair=[];guest['KEXE_FUEL']=str(fuel)
 for tag,a in arms.items():
  o,e=call(f'{i}-{tag}',[L,a['native']['path'],a['offset'],'2','aarch64','37',mode,x],guest)
  if fuel==100000:
   if mode==7:assert b':status :trap' in o
   else:
    v=re.search(rb':status :ok :result (-?\d+)',o);assert v and int(v[1])==oracle(mode,x)
  f=re.search(rb':fuel \{:initial (\d+) :remaining (\d+)\}',o);assert f and int(f[1])==fuel
  assert len(re.findall(rb':[a-z-]+ \d+',e))==17;pair.append((o,e))
 assert pair[0]==pair[1],('EXACT_RAW_FUEL_ARENA_MISMATCH',mode,x,fuel)
 rows.append(dict(mode=mode,x=x,fuel=fuel,oracle=oracle(mode,x)))
assert len(rows)==192
report=dict(status='PASS_GENERIC192_DIRECT_MASK_FULL64_ORACLE_CONSTANT_NEARMISS_INVALID_INDEX_LOWFUEL_EXACT_RAW_ALL17',pairs=192,guestCalls=384,compilerCalls=4,actualFusionSites=len(proof['sites']),performanceMeasured=False,rows=rows)
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'],len(proof['sites']))
