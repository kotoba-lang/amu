from pathlib import Path
import json,hashlib,os,subprocess,re,importlib.util
W=Path(__file__).parent;B=W/'generic192-v1';D=W/'generic192-resume-v4';D.mkdir(exist_ok=False);raw=D/'raw';raw.mkdir();L=W.parent/'embench-pf-twoarg-20261013/protected-host/kexe-loader'
def pin(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
S=B/'artifacts/controls.kotoba';assert S.read_bytes()==(W/'generic-fixture.kotoba').read_bytes();arms={}
for tag in ['OFF','ON']:
 b=B/'artifacts'/(tag+'.bin');k=b.with_suffix('.kseed');h,payload=k.read_bytes().split(b'\n\n',1);assert payload==b.read_bytes();ex={n:[int(o),int(a)]for n,o,a in map(str.split,h.decode().splitlines()[1:])};arms[tag]=dict(native=pin(b),container=pin(k),source=pin(S),exports=ex,offset=ex['run'][0],arity=2);assert ex['run'][1]==2
spec=importlib.util.spec_from_file_location('mask_physical',W/'native-gate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);proof=m.audit(arms['OFF'],arms['ON']);assert proof['changed'] and len(proof['sites'])>0
(D/'physical-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
priorDirs=[B,W/'generic192-resume-v2',W/'generic192-resume-v3'];calls={};cache={}
for previous in priorDirs:
 for r in json.loads((previous/'calls.json').read_text()):
  if r['tag'].endswith('-compile')or r['tag'].endswith('-extract'):continue
  assert r['tag']not in calls;calls[r['tag']]=r['exit'];cache[r['tag']]=previous/'raw'/(r['tag']+'.stdout')
pins=[pin(L),pin(S),pin(W/'native-gate.py'),pin(B/'calls.json')]+[e[k]for e in arms.values()for k in['native','container']]
for previous in priorDirs:
 pins.append(pin(previous/'calls.json'))
 for p in sorted((previous/'raw').glob('*')):pins.append(pin(p))
(D/'input-pins.json').write_text(json.dumps(dict(files=pins,priorStoppedOnExpectedTrap=True,additionalCompilerCalls=0),indent=2)+'\n')
def verify():
 for row in pins:assert pin(row['path'])==row
xs=[-(1<<63),-(1<<63)+1,-65536,-65535,-1024,-256,-255,-1,0,1,7,127,128,255,256,65535,65536,(1<<63)-2,(1<<63)-1]
def oracle(mode,x):return [x&255,(x+1)&255,0,1,2*(x&255),(x^42)&255,x&65535,None][mode]
cases=[(m,x,100000)for m in range(8)for x in xs]+[(m,-1,f)for m in range(8)for f in range(5)]
env={k:v for k,v in os.environ.items()if not k.startswith('KEXE_')};env.update(KEXE_STRUCTURED_REPORT='1',KEXE_ARENA_USE='1',KEXE_CPU_SECONDS='60',KEXE_WALL_SECONDS='60');rows=[];new=[];reused=0
for i,(mode,x,fuel)in enumerate(cases):
 pair=[];env['KEXE_FUEL']=str(fuel)
 for tag,arm in arms.items():
  key=f'{i}-{tag}';p=cache.get(key,B/'raw'/(key+'.stdout'))
  if key in calls:
   code=calls[key];o=p.read_bytes();e=p.with_suffix('.stderr').read_bytes();reused+=1;authority=pin(p)
  else:
   verify();z=subprocess.run(list(map(str,[L,arm['native']['path'],arm['offset'],'2','aarch64','37',mode,x])),cwd=D,env=env,capture_output=True,timeout=60);code=z.returncode;o=z.stdout;e=z.stderr
   (raw/(key+'.stdout')).write_bytes(o);(raw/(key+'.stderr')).write_bytes(e);new.append(dict(tag=key,exit=code));(D/'calls.json').write_text(json.dumps(new,indent=2)+'\n');verify();authority=pin(raw/(key+'.stdout'))
  if fuel==0:
   assert code==2 and o==b'' and e==b'kexe-loader: KEXE_FUEL must be a positive decimal integer, or off\n'
   pair.append((code,o,e));rows.append(dict(case=i,arm=tag,mode=mode,x=x,fuel=fuel,exit=code,loaderConfigurationRefusal=True,stdout=authority,stderrSHA256=hashlib.sha256(e).hexdigest()));continue
  if b':status :ok' in o:
   assert code==0 and mode!=7;v=re.search(rb':result (-?\d+)',o);assert v and int(v[1])==oracle(mode,x)
  else:
   assert code==120 and b':status :trap :exit 120' in o
   if b'KEXE_TRAP {:kind :signal :signal :SIGILL}'in e:assert mode==7
   else:
    assert 1<=fuel<=4 and b'KEXE_TRAP {:kind :signal :signal :SIGTRAP}'in e and b'KEXE_TRAP {:kind :budget :reason :budget/fuel}'in e
    assert re.search(rb':remaining 0\}',o)
  f=re.search(rb':fuel \{:initial (\d+) :remaining (\d+)\}',o);assert f and int(f[1])==fuel and 0<=int(f[2])<=fuel
  assert len(re.findall(rb':[a-z-]+ \d+',e))==17
  pair.append((code,o,e));rows.append(dict(case=i,arm=tag,mode=mode,x=x,fuel=fuel,exit=code,stdout=authority,stderrSHA256=hashlib.sha256(e).hexdigest()))
 assert pair[0]==pair[1],('EXACT_RAW_EXIT_FUEL_ARENA',i)
assert len(rows)==384;verify()
r=dict(status='PASS_GENERIC192_DIRECT_MASK_FULL64_ORACLE_CONSTANT_NEARMISS_INVALID_INDEX_LOWFUEL_AND_CONFIG_REFUSALS',pairs=192,loaderInvocations=384,guestCalls=368,loaderConfigurationRefusals=16,additionalLoaderInvocations=len(new),reusedPriorActualCorrectnessCalls=reused,compilerCalls=4,additionalCompilerCalls=0,actualFusionSites=len(proof['sites']),performanceMeasured=False,rows=rows)
(D/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(r['status'],len(proof['sites']),len(new),reused)
