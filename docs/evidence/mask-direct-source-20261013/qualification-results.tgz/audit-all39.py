from pathlib import Path
import json,importlib.util
W=Path(__file__).parent;D=W/'physical-audit-v1';D.mkdir(exist_ok=False)
s=importlib.util.spec_from_file_location('physical',W/'native-gate.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
j=json.loads((W/'all39-g1-screen-v1/generated-artifacts.json').read_text());assert len(j['images'])==39
rows=[]
for e in j['images']:
 r=m.audit(e['baseline'],e['arm']);(D/(e['tag']+'.json')).write_text(json.dumps(r,indent=2)+'\n');rows.append(dict(tag=e['tag'],status=r['status'],changed=r['changed'],sites=len(r.get('sites',[])),oldBytes=r.get('oldBytes'),newBytes=r.get('newBytes')))
report=dict(status='PASS_ALL39_DIRECT_MASK_WHOLE_NATIVE_SOURCE_POOL_REFERENCE_EXPORT_REPLAY',rows=rows,changedImages=[r['tag']for r in rows if r['changed']],adopted=False,performanceMeasured=False)
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status']);print([r for r in rows if r['changed']])
