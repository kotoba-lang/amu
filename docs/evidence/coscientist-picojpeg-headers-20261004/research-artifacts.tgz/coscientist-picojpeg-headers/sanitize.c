#include "c-bridge.c"
#include <stdio.h>
int main(void){unsigned reads=0;for(int n=1;n<=32;n++)if(oracle_selfcheck(n,0,0,0,0,0,0,0)!=1||decoder_selfcheck(n,0,0,0,0,0,0,0)!=1)return 1;
 for(int stage=0;stage<4;stage++)for(unsigned i=0;i<sizeof(fields)/sizeof(fields[0]);i++){if(observe(stage*2048+fields[i],0,0,0,0,0,0,0)==INT64_MIN)return 2;reads++;}
 printf("PASS 32 original init-API and decoder/verifier selfchecks, %u initialized header/table state reads\n",reads);return 0;}
