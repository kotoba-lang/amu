from pathlib import Path
old=Path('/private/tmp/amu-local-vector-charged-20261006');w=Path('/private/tmp/amu-private-vector-chain-20261006');s=(old/'fixture-proof.py').read_text().replace(str(old),str(w)).replace("(r/'seed/42-layout.kotoba').read_text()","(w/'42-layout-prototype.kotoba').read_text()")
a="prefix=[('FUEL',)";idx=s.index(a);s=s[:idx]+"m.fx('lv_finish',1,2,[('FUEL',),('LGET',0,1),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('CONST',1,1),('BIN','BOP-ADD',0),('LSET',2,0),('LGET',0,1),('CONST',1,0),('LGET',2,2),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('LGET',0,1),('CALL','lv_sink',0,1),('RET',0)])\n"+s[idx:]
s=s.replace("('twice','lv_writer',[])]","('twice','lv_writer',[]),('transfer_new','lv_writer',[]),('transfer_invalid','lv_writer',[]),('write_first','lv_writer',[])]")
a=" ops += [('CALL','lv_sink',0,1),('RET',0)];m.fx"
z=" if kind in ['transfer_new','transfer_invalid']:ops += [('LGET',0,1),('CONST',1,6 if kind=='transfer_new' else 4),('RT','RT-VECTOR-AT',0,2)]\n if kind=='write_first':ops=[('FUEL',),('LGET',0,1),('CONST',1,2),('CONST',2,7),('CALL','lv_writer',0,3)]\n ops += [('CALL','lv_finish',0,1),('RET',0)];m.fx";assert a in s;s=s.replace(a,z)
a=s.index('def oracle(');end=s.index('pairs=[',a)
s=s[:a]+'''def oracle(kind,a,b,probe,fuel):
 other=[13,17,19,23];inp=[a,b,m.MIN,m.MAX,-1,42,1];result='trap';remaining=max(fuel-2,0)
 arith_ok=True;read_ok=kind=='write_first' or 0<=a<7
 if fuel>=2 and read_ok:
  if kind=='write_first':v=7;wi=2
  else:
   v=inp[a];wi=b
   if kind=='quot0':arith_ok=False
   elif kind=='quotneg':arith_ok=v!=m.MIN;v=wrap(-v)
   elif kind=='quot3':v=(abs(v)//3)*(-1 if v<0 else 1)
   else:v=0 if kind=='zero' else wrap(v+7)
  if arith_ok:
   charges=3 if kind=='charged' else 2;remaining=max(fuel-charges,0);dest=other if kind=='changed' else inp
   if fuel>=charges and 0<=wi<len(dest):
    dest[wi]=v
    if kind=='twice':dest[0]=-99
    # Final parameter fetch occurs before the finish charge. transfer_new
    # index6 is valid, transfer_invalid index4 is valid; loaded -1 traps
    # at finish's original checked read after its charge.
    target=other if kind=='transfer_new' else None if kind=='transfer_invalid' else dest
    remaining=max(fuel-charges-1,0)
    if fuel>=charges+1 and target is not None:
     target[0]=wrap(target[0]+1)
     if 0<=probe<len(target):result=target[probe]
 return result,remaining,other+inp
''' +s[end:]
s=s.replace("for fuel in [1,2,3,4,(1<<53)-1]","for fuel in [1,2,3,4,5,(1<<53)-1]")
s=s.replace("'status':'complete-independent-native-read-write-alias-replacement-branch-fuel-trap-fullstate-items'","'status':'complete-independent-native-public-private-cold-changed-invalid-alias-read-write-partial-fuel-state'")
(w/'fixture-proof.py').write_text(s)
