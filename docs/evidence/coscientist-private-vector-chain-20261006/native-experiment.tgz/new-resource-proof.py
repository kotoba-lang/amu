from pathlib import Path
import json,subprocess,os,re
w=Path('/private/tmp/amu-private-vector-chain-20261006');ns={};exec((w/'fixture-proof.py').read_text().split('env=dict(')[0],ns);m=ns['m'];fns=ns['fns'];images={}
for label in ['baseline','candidate']:
 blob,offs=m.blob_from((w/(label+'-fixture.stdout')).read_text());assert blob==(w/(label+'-fixture.bin')).read_bytes();images[label]=(w/(label+'-fixture.bin'),offs)
rows=[]
for kind,_,_ in ns['variants']:
 for key,cap in [('KEXE_VECTORS',1),('KEXE_VECTORS',2),('KEXE_VECTOR_ITEMS',3),('KEXE_VECTOR_ITEMS',4),('KEXE_VECTOR_ITEMS',10),('KEXE_VECTOR_ITEMS',11)]:
  obs={}
  for label,(p,offs) in images.items():
   env=dict(os.environ,KEXE_FUEL='4',KEXE_STRUCTURED_REPORT='1');env[key]=str(cap);env.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'full-state-loader'),str(p),str(offs[fns['lv_'+kind+'_driver']]),'3','aarch64','-','2','2','2'],env=env,capture_output=True,text=True);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)};assert ':fuel ' in q.stdout,(kind,key,cap,q.stdout,q.stderr)
  assert obs['baseline']==obs['candidate'],(kind,key,cap,obs);rows.append({'variant':kind,'resource':key,'capacity':cap,**obs})
(w/'new-resource-proof.json').write_text(json.dumps({'status':'complete-native-new-read-writer-resource-and-partial-items-parity','comparisons':len(rows),'rows':rows},indent=2)+'\n');print('PASS',len(rows),'new allocation/resource/partial-item comparisons')
