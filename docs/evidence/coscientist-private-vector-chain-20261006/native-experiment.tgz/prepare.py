from pathlib import Path
import shutil,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');b=Path('/private/tmp/amu-small-tail-frame-20261006');w=Path('/private/tmp/amu-private-vector-chain-20261006');g=(r/'seed/41-a64gen.kotoba').read_text();assert g==(b/'41-a64gen-prototype.kotoba').read_text();(w/'baseline-41-a64gen.kotoba').write_text(g);layout=(r/'seed/42-layout.kotoba').read_text();(w/'baseline-42-layout.kotoba').write_text(layout);h=json.loads((r/'docs/evidence/coscientist-terminal-census-20261006/next-hypothesis.json').read_text());h['authoringException']='New one-off descriptor-transfer algorithm and layout contract, in a temporary prototype; not a mechanical product refactor.';(w/'hypothesis.json').write_text(json.dumps(h,indent=2)+'\n')
helper=''';; Private descriptor ABI: mode2 locals x0..2, temps x9..11, spare x3..5.
;; Target proof duplicates original classification facts without mutating G.
(defn- gn-chain-extra [M :vector-i64 j :i64 end :i64 ns :i64 dp :i64 found :i64] :i64
 (if (= j end) found
  (let [op (gn-op M j) a (gn-sir M j IF-A) b (gn-sir M j IF-B) c (gn-sir M j IF-C)
        valid (case op
          OP-CONST (and (>= a 0) (< a dp) (= c 0))
          OP-LGET (and (>= a 0) (< a dp) (> b 0) (<= b ns) (= c 0))
          OP-LSET (and (> a 0) (<= a ns) (>= b 0) (< b dp) (= c 0))
          OP-BIN (and (>= a 0) (< a BOP-F64-ADD) (>= b 0) (< (inc b) dp) (= c 0))
          OP-CMP (and (>= a 0) (< a CC-F64-EQ) (>= b 0) (< (inc b) dp) (= c 0))
          OP-UN (and (>= a 0) (< a UOP-F64-NEG) (>= b 0) (< b dp) (= c 0))
          OP-RET (and (>= a 0) (< a dp) (= b 0) (= c 0))
          (OP-CALL OP-RT) (and (>= b 0) (> c 0) (<= (+ b c) dp))
          (OP-BRZ OP-BRNZ) (and (>= a 0) (< a dp) (= c 0))
          (OP-FUEL OP-LABEL OP-BR) true
          false)
        genuine (and (= op OP-CALL) (= (gn-call-wrapper M j a b c) 0))]
   (if valid (gn-chain-extra M (inc j) end ns dp (if genuine 1 found)) -1))))
(defn- gn-chain-target [M :vector-i64 f :i64] :bool
 (if (or (<= f 0) (>= f (vector-at M MM-FN-N)) (gn-clamp-open M f)) false
  (let [p (gn-fnf M f FF-SIR) ns (gn-fnf M f FF-NSLOTS) dp (gn-fnf M f FF-DEPTH)]
   (if (or (<= p 0) (>= p (vector-at M MM-SIR-N))
           (< ns 1) (> ns 3) (< dp 1) (> dp 3)) false
    (let [end (gn-small-end M (inc p) f 4096)]
     (and (> end p) (= (gn-op M p) OP-FN)
          (= (gn-sir M p IF-A) f) (= (gn-sir M p IF-B) 1) (= (gn-sir M p IF-C) ns)
          (= (gn-fnf M f FF-NPARAMS) 1) (= (gn-fnf M f FF-PT0) TY-VEC)
          (= (gn-fnf M f FF-RTYPE) TY-VEC)
          (<= (gn-scan M (inc p) 2 0) ns) (<= (gn-scan M (inc p) 1 0) dp)
          (gn-small-scan M (inc p) p end TY-VEC)
          (= (gn-chain-extra M (inc p) end ns dp 0) 1)))))))
(defn- gn-chain-mode [M :vector-i64 i :i64] :bool
 (and (= (gn-g M gn-f-leaf) 2) (>= (gn-g M gn-f-ns) 1) (<= (gn-g M gn-f-ns) 3)
      (>= (gn-g M gn-f-dp) 1) (<= (gn-g M gn-f-dp) 3)
      (= (gn-g M gn-f-out) 0) (= (gn-g M gn-f-nsv) 0) (= (gn-g M gn-f-fb) 0)
      (= (gn-sreg M 1) 0) (gn-chain-target M (gn-sir M i IF-A))))
(defn- gn-chain-store [M :vector-i64 rv :i64 ri :i64 rx :i64] :vector-i64
 (if (not= (gn-g M gn-f-vmode) 2)
  (-> M (gn-hchk rv 312 320) (gn-vidx ri) (gn-emit (gn-e-strr3 rx 16 17)))
  (-> M (gn-emit (enc-cbz 5 3)) (gn-emit (enc-cmp-r rv 5)) (gn-emit (enc-bcond (enc-cond-eq) 13))
      (gn-mov 5 rv) (gn-hchk 5 312 320)
      (gn-emit (enc-ldp 17 3 16 0)) (gn-emit (enc-ldr 4 7 328)) (gn-emit (gn-e-addsl 4 4 17 3))
      (gn-emit (enc-cmp-r ri 3)) (gn-emit (enc-bcond (enc-cond-lo) 2)) (gn-emit (gn-e-udf))
      (gn-emit (gn-e-strr3 rx 4 ri)))))
(defn- gn-chain-fix [M :vector-i64 f :i64 n :i64] :vector-i64
 (let [private (and (= (gn-g M gn-f-vmode) 2) (= n 1) (gn-chain-target M f))
       M1 (gn-fix M FX-BL26 f) at (dec (vector-at M1 MM-FIX-N))]
  (if private (gn-put M1 (+ MM-FIX-BASE (* at MM-FIX-W) XF-AUX) 1) M1)))
'''
def rep(a,z):
 global g
 assert g.count(a)==1,(a,g.count(a));g=g.replace(a,z,1)
rep('(defn- gn-vmode [',helper+'\n(defn- gn-vmode [')
rep('(gn-gs M gn-f-vmode (if (and (= (gn-g M gn-f-leaf) 0)', '(gn-gs M gn-f-vmode (if (gn-chain-mode M i) 2 (if (and (= (gn-g M gn-f-leaf) 0)')
rep('(gn-vhot-scan M (inc i) 8192)) 1 0)))','(gn-vhot-scan M (inc i) 8192)) 1 0))))')
rep('(if (= (gn-g M gn-f-vmode) 1) (gn-mov-imm M 5 0) M)', '(if (> (gn-g M gn-f-vmode) 0) (gn-mov-imm M 5 0) M)')
rep('(-> M2 (gn-ctx) (gn-hchk rv 312 320) (gn-vidx ri) (gn-emit (gn-e-strr3 rx 16 17))', '(-> M2 (gn-ctx) (gn-chain-store rv ri rx)')
rep('(gn-fix FX-BL26 f) (gn-emit (enc-b 0))','(gn-chain-fix f n) (gn-emit (enc-b 0))')
(w/'41-a64gen-prototype.kotoba').write_text(g)
a='''        t (ly-target kind tgt lab fcode nfn)]''';z='''        t0 (ly-target kind tgt lab fcode nfn)
        aux (vector-at M (+ fb XF-AUX))
        t (if (= aux 0) t0
            (if (and (= aux 1) (= kind FX-BL26) (> t0 0)
                     (< (inc t0) (vector-at M MM-CODE-N))
                     (> at 0) (< at (vector-at M MM-CODE-N))
                     (= (bit-and (vector-at M (+ MM-CODE-BASE at)) 0xfc000000) 0x14000000)
                     (= (vector-at M (+ MM-CODE-BASE t0)) 0xd2800005))
                (inc t0) -1))]''';assert layout.count(a)==1;layout=layout.replace(a,z);(w/'42-layout-prototype.kotoba').write_text(layout)
parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join(g if x=='seed/41-a64gen.kotoba' else layout if x=='seed/42-layout.kotoba' else (r/x).read_text() for x in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader'),('full-state-loader','full-state-loader')]:shutil.copy2(b/src,w/dst)
old=Path('/private/tmp/amu-local-vector-charged-20261006')
for name in ['build.py','check-ports.py','ports-state.py','resource-proof.py','permanent-regression.py']:
 s=(old/name).read_text().replace(str(old),str(w)).replace("(r/'seed/42-layout.kotoba').read_text()","(w/'42-layout-prototype.kotoba').read_text()");(w/name).write_text(s)
abi={'status':'prospective-not-adopted','schema':'amu.closed-mode2-vector-descriptor-private-entry/v1','registers':{'3':'length','4':'items-base','5':'positive-validated-handle'},'publicEntryFirstWord':'0xd2800005 (MOVZ x5,#0)','privateEntryDeltaWords':1,'privateTailFix':'FX-BL26 + XF-AUX=1 only on genuine B with proved caller/callee contract; layout checks actual marker and opcode','sourcePins':{n:hashlib.sha256((w/n).read_bytes()).hexdigest() for n in ['41-a64gen-prototype.kotoba','42-layout-prototype.kotoba']},'recipeBoundary':'Both generator/layout/native-source artifacts sealed in prospective proof/timing manifests. Native DefCID cache remains unconnected.'};(w/'internal-abi.json').write_text(json.dumps(abi,indent=2)+'\n');print('PASS prospective descriptor ABI prepared from qualified product; rejected candidates excluded')
