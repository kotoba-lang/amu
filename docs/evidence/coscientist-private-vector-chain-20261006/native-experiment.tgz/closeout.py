from pathlib import Path
import json,hashlib,shutil,tarfile
w=Path('/private/tmp/amu-private-vector-chain-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');e=r/'docs/evidence/coscientist-private-vector-chain-20261006';e.mkdir(parents=True,exist_ok=True);load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=load(w/'timing-audit.json');assert not a['performanceAllowsFurtherAdoptionGates'];assert a['acceptedTriples']==30
cor={'status':'authoring-corrections-preserved-no-semantic-relaxation','notes':['Initial chain oracle assumed input slot6 still held handle1 after a writer. Both baseline and candidate correctly trapped on overwritten handle49. Corrected oracle reads the actual postwrite slot; complete9450 rerun passed.','Instruction audit initially read pre-FN cache mode as post-FN mode. Corrected to the observer recorded after-mode; all19 audit passed. No candidate or baseline source changed for either correction.']};(w/'authoring-corrections.json').write_text(json.dumps(cor,indent=2)+'\n')
next_h={'status':'registered-after-negative-private-descriptor-timing-before-next-implementation','hypothesis':'Restrict private descriptor entry to a source edge with a valid unchanged-root witness and a callee access whose actual local equals that root. A control-flow proof may remove a runtime equality guard, rather than transferring descriptor state with a guard on every first access.','prerequisites':['Count admitted original sites prospectively; no workload/name specialization.','An observed equal handle is insufficient. Prove each reaching path initialized the positive key and binds actual outgoing argument to it. Branch joins/root assignments/unknown effects must kill or intersect witness.','No earlier trap or descriptor read at entry: original fuel/access/partial items preserved. Public and unknown edges remain cold.','Independent changed/invalid/root-alias/fuel/branch controls; all19 unchanged source and native regression; then one unchanged-rule product/candidate/C campaign.'],'observedNegativeEvidence':a['rows'],'alternative':'If a closed proof admits too few original dynamic accesses, investigate scalar state representation rather than retime this candidate.','implementationExists':False,'nativeDefCIDCacheConnected':False,'all19GoalAchieved':False};(w/'next-hypothesis.json').write_text(json.dumps(next_h,indent=2)+'\n')
summary={'status':'complete-native-private-descriptor-experiment-rejected-after-timing','sourceCommit':'152a10e0307e6ce21a16095a849bc11e7dec2285','originalWorkloads':19,'changedGuests':['statemate'],'unchangedGuests':18,'fullSupervisorComparisons':11232,'permanentFixtures':508,'permanentExecutions':14523,'newChainFixtures':34,'newScratchFixtures':34,'sourceMutations':119,'layoutRefusals':5,'privateBranches':291,'coldEntryFunctions':390,'fuelPrefixes':1806,'statemateWords':{'baseline':21316,'candidate':23714},'fixedPointGenerations':[2,3,4],'firstGenerationDiffers':True,'generations':load(w/'generations.json'),'timing':a,'nativeDefCIDCacheConnected':False,'resultMemoization':False,'productChanged':False,'productPromoted':False,'officialEmbenchScore':False,'all19GoalAchieved':False};(w/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for n in ['summary.json','timing-audit.json','generations.json','internal-abi.json','hypothesis.json','next-hypothesis.json','authoring-corrections.json','instruction-audit.json','mathematical-proof.json','mutation-proof.json']:shutil.copy2(w/n,e/n)
s=(w/'timing-audit.py').read_text().replace("w=Path('/private/tmp/amu-private-vector-chain-20261006')", "w=Path(__file__).resolve().parent");(w/'replay-timing.py').write_text(s)
(w/'replay-analysis.py').write_text('''from pathlib import Path
import json,re,subprocess,sys
w=Path(__file__).resolve().parent;load=lambda n:json.loads((w/(n+'.json')).read_text());total=0
for name,key,count in [('fixture-proof','observations',9450),('scratch-proof','observations',1445),('new-resource-proof','rows',90),('ports-state','runs',209),('resource-proof','runs',38)]:
 d=load(name);assert d['comparisons']==len(d[key])==count
 for row in d[key]:
  a=row['baseline'];assert a==row['candidate']
  if key=='observations':
   assert int(re.search(r':remaining (-?\\d+)',a['report'])[1])==row['expectedRemaining'];vals=list(map(int,a['items'][0].split()[1:]));assert vals[0]==len(vals)-1 and vals[1:]==row['expectedItems'];res=row['expectedResult']
   if isinstance(res,int):assert a['exit']==0 and int(re.search(r':result (-?\\d+)',a['report'])[1])==res
   else:assert a['exit']==120
 total+=count
assert total==11232
q=subprocess.run([sys.executable,str(w/'replay-timing.py')]);assert q.returncode==0
print('PASS offline 11232 stored full-state comparisons/oracles plus raw30 timing/source/native/C/fuel audit; not a fresh native rerun')
''')
files=[x for x in w.iterdir() if x.is_file() and x.suffix in ['.py','.json','.kotoba','.kseed','.bin','.stdout','.log','.offset']]
with tarfile.open(e/'native-experiment.tgz','w:gz') as t:
 for p in files:t.add(p,arcname=p.name)
 for n in ['observer','ports-2','remote-evidence']:t.add(w/n,arcname=n)
checks=''.join(sha(p)+'  '+p.name+'\n' for p in sorted(e.iterdir()) if p.is_file() and p.name!='checksums.sha256');(e/'checksums.sha256').write_text(checks);print('PASS archived rejected prototype/raw evidence', (e/'native-experiment.tgz').stat().st_size)
