from pathlib import Path
w=Path('/private/tmp/amu-private-vector-chain-20261006');o=w/'observer';p=o/'observer-41-a64gen.kotoba';g=p.read_text()
def out(prefix,fields):
 s='"\\n"'
 for x in reversed(fields):s=f'(string-concat (string-from-i64 {x}) (string-concat " " {s}))'
 return f'(io-out (string-concat "{prefix} " {s}))'
f='''(defn- gn-census-fixes [M :vector-i64 k :i64] :i64
 (if (>= k (vector-at M MM-FIX-N)) 0
  (let [b (+ MM-FIX-BASE (* k MM-FIX-W)) printed '''+out('FIX',['k','(vector-at M (+ b XF-AT))','(vector-at M (+ b XF-KIND))','(vector-at M (+ b XF-TARGET))','(vector-at M (+ b XF-AUX))'])+''']
   (gn-census-fixes M (inc k)))))
''';a='(defn- gn-run-open [';assert g.count(a)==1;g=g.replace(a,f+a);a='        n (vector-at M3 MM-CODE-N)]';assert g.count(a)==1;g=g.replace(a,'        printed_fixes (gn-census-fixes M3 1)\n'+a);p.write_text(g);r=Path('/Users/junkawasaki/github/wt/amu-seed17');parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(o/'observer-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (w/'42-layout-prototype.kotoba').read_text() if x=='seed/42-layout.kotoba' else (r/x).read_text())+'\n' for x in parts));print('PASS added read-only private FIX aux/target census; guest code unchanged')
