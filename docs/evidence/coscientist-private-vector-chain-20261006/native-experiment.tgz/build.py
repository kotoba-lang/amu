from pathlib import Path
import subprocess,os,re,json,hashlib
w=Path('/private/tmp/amu-private-vector-chain-20261006');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[]
for n in range(1,5):
 for stage,args in [('compile',['compile',str(w/'seed-unity.kotoba'),'--target','aarch64-macos','--output',str(w/f'seed-{n}.kseed')]),('extract',['extract-native',str(w/f'seed-{n}.kseed'),'--symbol','main','--output',str(w/f'seed-{n}.bin')])]:
  p=subprocess.run([str(w/'kexe-loader'),str(w/f'seed-{n-1}.bin'),(w/f'seed-{n-1}.offset').read_text().strip(),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/f'seed-{n}-{stage}.log').write_text(p.stdout+p.stderr);assert p.returncode==0,(n,stage,p.stdout,p.stderr)
  if stage=='extract': (w/f'seed-{n}.offset').write_text(re.search(r':offset (\d+)',p.stdout).group(1)+'\n')
 sha=hashlib.sha256((w/f'seed-{n}.bin').read_bytes()).hexdigest();rows.append({'generation':n,'bytes':(w/f'seed-{n}.bin').stat().st_size,'sha256':sha});print(rows[-1],flush=True);(w/'generations.json').write_text(json.dumps(rows,indent=2)+'\n')
assert len({x['sha256'] for x in rows[1:]})==1
print('PASS generations 2/3/4 byte identical',flush=True)
