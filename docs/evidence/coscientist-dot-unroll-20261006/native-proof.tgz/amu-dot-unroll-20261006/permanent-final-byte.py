from pathlib import Path
w=Path('/private/tmp/amu-dot-unroll-20261006');s=(w/'permanent-regression.py').read_text();s=s[:s.index('blob,fns=b;bp=')]
s=s.replace('permanent-regression-test','permanent-final-test').replace('permanent-regression-real','permanent-final-real')
s+='''old=m.blob_from((w/'permanent-regression-real.stdout').read_text())
assert b==old and b[0]==(w/'permanent-regression-fixture.bin').read_bytes()
(w/'permanent-final-byte.json').write_text(json.dumps({'status':'complete-final-compiler-original470-fixture-byte-and-fn-offset-parity','fixtures':len(m.FIX),'nativeRunsAlreadyPassed':len(m.RUNS),'original11187ExecutesExactlyTheseFinalGuestBytes':True,'realTestCodeAndLiteralBytesEqual':True,'realTestFnOffsetsEqual':True,'fixtureSha256':hashlib.sha256(b[0]).hexdigest(),'finalSeedSha256':hashlib.sha256((w/'seed-4.bin').read_bytes()).hexdigest(),'prototypeSha256':hashlib.sha256((w/'41-a64gen-prototype.kotoba').read_bytes()).hexdigest()},indent=2)+'\\n')
print('PASS final native generator reproduces exact470 fixture bytes/offsets already passed11187runs',flush=True)
'''
exec(compile(s,'permanent-final-byte.py','exec'))
