from pathlib import Path
import json,hashlib,struct
w=Path('/private/tmp/amu-dot-unroll-20261006');b=Path('/private/tmp/amu-same-local-read-20261006');load=lambda p:json.loads(p.read_text());pc=load(w/'ports-correctness.json');old=load(b/'ports-correctness.json');initial=load(w/'ports-before-label-guard.json');rows=[]
for e in pc['entries']:
 o=next(x for x in old['entries'] if x['workload']==e['workload']);i=next(x for x in initial['entries'] if x['workload']==e['workload']);assert e==i
 changed=e['nativeSha256']!=o['nativeSha256'];assert changed==(e['workload']=='matmult-int');rows.append({'workload':e['workload'],'changed':changed,'finalGuestSameAsInitialHandTestedPrototype':True,'sha256':e['nativeSha256'],'offset':e['offset']})
a=(b/'ports-2/matmult-int/native.bin').read_bytes();z=(w/'ports-2/matmult-int/native.bin').read_bytes();start=(2163-1)*4;prefix=18*4;growth=len(z)-len(a);assert growth==392
assert a[start:start+prefix]==z[start:start+prefix]
assert a[start+prefix:start+73*4]==z[start+prefix+growth:start+73*4+growth]
fast=list(struct.iter_unpack('<I',z[start+prefix:start+prefix+growth]));assert len(fast)==98
words=[x[0] for x in fast];group=next(j for j in range(len(words)-2) if words[j]==0xf9400009 and words[j+1]==0xf940002a and words[j+2]==0x9b0a0922)
for j in range(20):assert words[group+3*j:group+3*j+3]==[0xf9400009+(j<<10),0xf940002a+(j*20<<10),0x9b0a0922]
(w/'instruction-audit.json').write_text(json.dumps({'status':'complete-original19-and-actual-whole-dot-native-instruction-frame-fallback-audit','onlyMatmultChanged':True,'all19FinalAndPreLabelGuestBytesAndOffsetsEqual':True,'originalFn5Prefix18WordsExact':True,'originalFn5Tail55WordsExact':True,'original192ByteFrameAndAll5ParamPlacementsExact':True,'originalEntryFuelWordsExact':True,'expanded20GroupsExact':True,'extraWords':98,'handMaddChecks':load(w/'hand-byte-recheck.json'),'entries':rows},indent=2)+'\n');print('PASS onlymatmult changes; originalframe/params/entryfuel/fallback55words exact;20load/load/madd groups')
