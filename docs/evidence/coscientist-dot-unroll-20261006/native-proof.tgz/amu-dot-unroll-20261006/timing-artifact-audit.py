from pathlib import Path
import json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-dot-unroll-20261006');p=w/'remote-evidence'/'timing-package';name=__import__('sys').argv[1];d=p/name;load=lambda x:json.loads(x.read_text());sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest();mf=load(d/'candidate/manifest.json');br=load(d/'baseline/results.json');tr=load(d/'timing/results.json');e=br['entries'][0];spec=load(p/'paired-timing-spec.json');m=load(r/'bench/embench/comparison-matrix.json');src=next(x for x in m['entries'] if x['workload']==name);assert sha(r/src['source'])==src['expectedSourceSha256']==mf['sourceSha256']==mf['baselineSourceSha256'];assert sha(p/'comparison-matrix.json')==br['matrixSpecSha256']==sha(r/'bench/embench/comparison-matrix.json');assert sha(p/'paired-timing-spec.json')==tr['specSha256']==sha(r/'bench/embench/paired-timing-spec.json');assert sha(d/'candidate/native.bin')==mf['nativeSha256']==sha(w/'ports-2'/name/'native.bin');assert sha(d/'baseline-native.bin')==sha(d/'baseline'/name/'native.bin')==mf['baselineNativeSha256']==e['nativeSha256'];assert sha(d/'baseline'/name/'c.dylib')==e['cDylibSha256'];assert tr['runnerSha256']==br['runnerSha256']=='a1b8778cf9af255f66bba3e3cad20e3baadd9653e18defe429bfa179840665ac';assert mf==tr['manifest'];assert sha(d/'baseline/results.json')==tr['baselineResultsSha256'];assert sha(p/'preflight.json')==br['nativePreflightSha256'];assert mf['compilerGenerationSha256']=={str(x['generation']):x['sha256'] for x in load(w/'generations.json')};assert mf['offset']==next(x for x in load(w/'ports-correctness.json')['entries'] if x['workload']==name)['offset'];assert tr['host'].split('.')[0]==spec['host'];assert tr['status']=='complete-provisional-candidate-timing';(w/('timing-artifact-audit-'+name+'.json')).write_text(json.dumps({'status':'complete-independent-canonical-source-machine-spec-C-and-receipt-pin-audit','sourceSha256':mf['sourceSha256'],'candidateSha256':mf['nativeSha256'],'baselineSha256':mf['baselineNativeSha256'],'cDylibSha256':e['cDylibSha256'],'runnerSha256':tr['runnerSha256'],'preflightNativeProofSealedBeforeTiming':True,'acceptedTriples':30,'attemptedTriples':tr['attemptedTriples'],'officialEmbenchScore':False},indent=2)+'\n');print('PASS actual canonical source/machine/spec/C and native proof pins, fresh timing rows independently audited')

import statistics,math
for arm in ['baseline','candidate','C']:
 rows=[row for row in tr['rows'] if row['arm']==arm and row['accepted']]
 assert len(rows)==30
 for row in rows:
  assert not row['rejectionReasons'] and max(row['loadBefore'],row['loadAfter'])<=spec['maximumLoad']
  assert row['cpuActivityEnvelope']['estimatedBackgroundIdlePercent']>=spec['minimumBackgroundIdlePercent']
  assert row['elapsedNanoseconds']>=spec['minimumIntervalNs'] and row['result']==1
 xs=[row['elapsedNanoseconds']/(row['calls']*e['iterationsPerCall']) for row in rows]
 assert statistics.mean(xs)==tr['summary'][arm]['meanNsPerBody']
 # Host floating arithmetic can differ by last-bit rounding in stdev.
 assert math.isclose(statistics.stdev(xs),tr['summary'][arm]['sdNs'],rel_tol=1e-14,abs_tol=1e-10)
sm=tr['summary'];gap=sm['baseline']['meanNsPerBody']-sm['candidate']['meanNsPerBody'];variation=sm['baseline']['sdNs']+sm['candidate']['sdNs']
stable=all(sm[arm]['relativeSd']<=spec['maximumRelativeSd'] for arm in ['baseline','candidate','C'])
assert sm['stable']==stable and not stable
assert sm['candidateImprovesBaseline']==(stable and sm['baselineOverCandidate']>=spec['minimumSpeedup'] and gap>variation)
assert not sm['candidateImprovesBaseline'] and sm['baselineOverCandidate']>=spec['minimumSpeedup'] and gap>variation
(w/'timing-artifact-audit.json').write_text(json.dumps({'status':'complete-independent-canonical-source-machine-spec-C-receipt-and-raw-row-audit','sourceSha256':mf['sourceSha256'],'candidateSha256':mf['nativeSha256'],'baselineSha256':mf['baselineNativeSha256'],'cDylibSha256':e['cDylibSha256'],'runnerSha256':tr['runnerSha256'],'nativeProofSealedBeforeTiming':True,'acceptedTriples':30,'attemptedTriples':tr['attemptedTriples'],'meanGapNs':gap,'summedSdNs':variation,'timeReductionPercent':100*(1-1/sm['baselineOverCandidate']),'decision':'rejected-baseline-RSD-exceeds-unchanged10pct-limit','baselineRsdPercent':100*sm['baseline']['relativeSd'],'summary':sm,'officialEmbenchScore':False},indent=2)+'\n')
print('PASS30 rawtriples independently audited; rejected under unchanged stability criteria; product unchanged')
