from pathlib import Path
import json,hashlib,tarfile,shutil,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-dot-unroll-20261006');n=Path('/private/tmp/amu-dot-unroll-return-20261006');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();tim=load(w/'remote-evidence/timing-package/matmult-int/timing/results.json');sm=tim['summary'];assert not sm['stable'] and not sm['candidateImprovesBaseline'];assert (r/'seed/41-a64gen.kotoba').read_bytes()==(w/'baseline-41-a64gen.kotoba').read_bytes();pre=load(w/'preflight-audit.json')
for name,h in pre['proofPins'].items():assert sha(w/name)==h
s=(w/'41-a64gen-prototype.kotoba').read_text();lines=[l for l in s.splitlines(True) if not any('(= (gn-lpos M (gn-sir M (+ p '+x in l for x in ['2)','6)','8)'])];old=''.join(lines);assert hashlib.sha256(old.encode()).hexdigest()==load(w/'hypothesis.json')['prototypeSha256'];(w/'prototype-before-label-guard.kotoba').write_text(old)
summary={'status':'rejected-under-unchanged-stability-rule-product-unchanged','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'originalGoal':'C-or-better all19 original aligned Embench workloads','goalAchieved':False,'productChanged':False,'prototypeSha256':sha(w/'41-a64gen-prototype.kotoba'),'nativeFixedpoint':load(w/'generations.json'),'original470Fixtures11187NativeRunsPassed':True,'finalFixtureBytesAndOffsetsExactlyReproduceThoseRuns':load(w/'permanent-final-byte.json'),'fullSupervisorComparisons':2786,'guardFields':188,'extraDiagnosticPathControls':30,'all19DiagnosticQuietBytesAndOffsetsEqual':True,'onlyOriginalMatmultGuestChanged':True,'original192ByteFrameParamEntryFuelAndFallback55WordsExact':True,'timing':{'host':'zebulun Apple M4','acceptedTriples':tim['acceptedTriples'],'attemptedTriples':tim['attemptedTriples'],'summary':sm,'timeReductionPercent':100*(1-1/sm['baselineOverCandidate']),'decision':'REJECT: baseline RSD10.203163834600815pct exceeds pre-registered10pct maximum; no threshold change or identical-machine retiming','notOfficialEmbenchScore':True,'noNewFullSuiteAggregate':True},'productGatesAndIntegratedProofNotRunBecauseRejected':True,'nextDistinctTrial':load(n/'hypothesis.json'),'nextTrialMeasured':False,'authoringException':'New one-off native whole-function optimization and independent hand/diagnostic fixtures; no existing AST refactor rule; prototype only.'}
(w/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');d=r/'docs/evidence/coscientist-dot-unroll-20261006';d.mkdir()
for name in ['summary.json','timing-artifact-audit.json','instruction-audit.json','preflight-audit.json','guard-proof.json','permanent-final-byte.json']:shutil.copyfile(w/name,d/name)
shutil.copyfile(n/'hypothesis.json',d/'next-hypothesis.json');shutil.copyfile(n/'41-a64gen-prototype.kotoba',d/'next-prototype.kotoba');shutil.copyfile(n/'create.py',d/'next-create.py');shutil.copyfile(n/'generations.json',d/'next-generations.json')
for arc,dirs in [('native-proof.tgz',[w]),('timing.tgz',[w/'remote-evidence'])]:
 with tarfile.open(d/arc,'w:gz') as t:
  for root in dirs:
   for p in sorted(root.rglob('*')):
    if not p.is_file() or '__pycache__' in p.parts:continue
    rel=p.relative_to(root)
    if arc=='native-proof.tgz' and rel.parts[0] in ['remote-evidence','timing-package']:continue
    t.add(p,arcname=root.name+'/'+str(rel))
 with tarfile.open(d/arc) as t:
  names=t.getnames();assert names
  if arc=='native-proof.tgz':
   for name in ['41-a64gen-prototype.kotoba','seed-4.bin','hand-proof.json','bad-handle-proof.json','fixture-state-proof.json','guard-proof.json','permanent-regression-proof.json','preflight-audit.json','summary.json']:
    assert t.extractfile(w.name+'/'+name).read()==(w/name).read_bytes()
  else:
   assert t.extractfile('remote-evidence/timing-package/matmult-int/timing/results.json').read()==(w/'remote-evidence/timing-package/matmult-int/timing/results.json').read_bytes()
(d/'checksums.sha256').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(d.iterdir()) if p.is_file()))
print('PASS rejected native/timing full evidence and next distinct4gen prototype archived; product unchanged',flush=True)
