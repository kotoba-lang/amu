from pathlib import Path
import json,subprocess,os,re,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-dot-unroll-20261006');proof=json.loads((w/'hand-proof.json').read_text());env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[]
for e in proof['images']:
 d=w/'hand2'/e['variant'];src=d/'source.kotoba';assert hashlib.sha256(src.read_bytes()).hexdigest()==e['sourceSha256']
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(d/'final.kseed')]),('extract',['extract-native',str(d/'final.kseed'),'--symbol','run','--output',str(d/'final.bin')])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/('final-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(e['variant'],stage,q.stdout,q.stderr)
 off=int(re.search(r':offset (\d+)',q.stdout).group(1));assert (d/'final.bin').read_bytes()==(d/'candidate.bin').read_bytes() and off==e['images']['candidate']['offset']
 rows.append({'variant':e['variant'],'finalGuestBytesAndOffsetsEqualHandTestedMachine':True,'sha256':hashlib.sha256((d/'final.bin').read_bytes()).hexdigest(),'offset':off});print('PASS final guarded compiler reproduces hand-tested guest',e['variant'],flush=True)
assert len(rows)==11
(w/'hand-byte-recheck.json').write_text(json.dumps({'status':'complete-final-label-proof-all11-hand-guest-byte-and-offset-parity','finalSeedSha256':hashlib.sha256((w/'seed-4.bin').read_bytes()).hexdigest(),'entries':rows},indent=2)+'\n')
