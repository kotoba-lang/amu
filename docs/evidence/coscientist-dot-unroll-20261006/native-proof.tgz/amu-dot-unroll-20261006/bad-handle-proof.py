from pathlib import Path
import subprocess,json,os,re
w=Path('/private/tmp/amu-dot-unroll-20261006');rows=[];MIN=-(1<<63);MAX=(1<<63)-1
for name,n in [('one',1),('three',3),('twenty',20),('sixtyfour',64)]:
 d=w/'hand2'/name
 if not (d/'candidate.bin').exists():continue
 for handle in [MIN,-1,0,1,MAX]:
  for k in [0,n,-1,MAX]:
   for fuel in [1,2,n+1,16777216,(1<<53)-1]:
    obs={}
    for label in ['baseline','candidate']:
     env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');env.pop('KEXE_COMMAND',None)
     q=subprocess.run([str(w/'clobber-full-state-loader'),str(d/(label+'.bin')),'0','5','aarch64','-',str(handle),'0','0',str(k),str(MAX)],env=env,capture_output=True,text=True)
     obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
     assert (q.returncode==0)==(k==n),(name,handle,k,fuel,label,q.stdout,q.stderr)
     assert f':remaining {fuel-1}' in q.stdout and ':vectors {:capacity 4096 :used 0}' in q.stdout and ':vector-items {:capacity 65536 :used 0}' in q.stdout,(name,label,q.stdout)
     if k==n:assert re.search(r':result '+str(MAX)+r'(?:\s|})',q.stdout)
    assert obs['baseline']==obs['candidate'],(name,handle,k,fuel,obs);rows.append({'variant':name,'args':[handle,0,0,k,MAX],'fuel':fuel,**obs})
 print('PASS native invalid handle and unused zero-trip handle',name,flush=True)
(w/'bad-handle-proof.json').write_text(json.dumps({'status':'complete-native-direct-invalid-handle-and-zero-trip-hand-proof','comparisons':len(rows),'publicMaxFuel':(1<<53)-1,'expectNoVectorsOrItems':True,'runs':rows},indent=2)+'\n');print('PASS',len(rows),'direct handle comparisons',flush=True)
