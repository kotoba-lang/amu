from pathlib import Path
import json,hashlib,shutil,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-dot-unroll-20261006');b=Path('/private/tmp/amu-same-local-read-20261006');g=(r/'seed/41-a64gen.kotoba').read_text();(w/'baseline-41-a64gen.kotoba').write_text(g)
# Newly authored exact structural algorithm. Labels/constants are captured, not workload names.
T=[('OP-FN','f',5,5),('OP-FUEL',0,0,0),('OP-LABEL','head',0,0),('OP-LGET',0,4,0),('OP-CONST',1,'n',0),('OP-CMP','CC-EQ',0,0),('OP-BRZ',0,'body',0),('OP-LGET',0,5,0),('OP-BR','exit',0,0),('OP-LABEL','body',0,0),('OP-LGET',0,1,0),('OP-LGET',1,2,0),('OP-LGET',2,3,0),('OP-LGET',3,4,0),('OP-CONST',4,1,0),('OP-BIN','BOP-ADD',3,0),('OP-LGET',4,5,0),('OP-LGET',5,1,0),('OP-CONST',6,'oa',0),('OP-LGET',7,2,0),('OP-CONST',8,'sa',0),('OP-BIN','BOP-MUL',7,0),('OP-LGET',8,4,0),('OP-BIN','BOP-ADD',7,0),('OP-BIN','BOP-ADD',6,0),('OP-RT','RT-VECTOR-AT',5,2),('OP-LGET',6,1,0),('OP-CONST',7,'ob',0),('OP-LGET',8,4,0),('OP-CONST',9,'sb',0),('OP-BIN','BOP-MUL',8,0),('OP-LGET',9,3,0),('OP-BIN','BOP-ADD',8,0),('OP-BIN','BOP-ADD',7,0),('OP-RT','RT-VECTOR-AT',6,2),('OP-BIN','BOP-MUL',5,0),('OP-BIN','BOP-ADD',4,0),('OP-LSET',1,0,0),('OP-LSET',2,1,0),('OP-LSET',3,2,0),('OP-LSET',4,3,0),('OP-LSET',5,4,0),('OP-FUEL',0,0,0),('OP-BR','head',0,0),('OP-LABEL','exit',0,0),('OP-RET',0,0,0),('OP-END','f',0,0)]
helper=''';; Prototype whole closed dot loop: proof-guarded expansion, original fallback.
(defn- gn-dot-at? [M :vector-i64 i :i64 op :i64 a :i64 b :i64 c :i64] :bool
 (and (= (gn-op M i) op) (= (gn-sir M i IF-A) a)
      (= (gn-sir M i IF-B) b) (= (gn-sir M i IF-C) c)))
(defn- gn-dot-shape [M :vector-i64 p :i64 f :i64 k :i64] :bool
 (let [head (gn-sir M (+ p 2) IF-A) body (gn-sir M (+ p 6) IF-B) exit (gn-sir M (+ p 8) IF-A)
       n (gn-sir M (+ p 4) IF-B) oa (gn-sir M (+ p 18) IF-B) sa (gn-sir M (+ p 20) IF-B)
       ob (gn-sir M (+ p 27) IF-B) sb (gn-sir M (+ p 29) IF-B)]
  (if (= k 47) true
   (and (case k
'''+''.join('    '+str(i)+' (gn-dot-at? M (+ p '+str(i)+') '+' '.join(map(str,x))+')\n' for i,x in enumerate(T))+'''    false)
        (gn-dot-shape M p f (inc k))))))
(defn- gn-dot? [M :vector-i64 i :i64] :bool
 (let [p (dec i) f (gn-sir M p IF-A)]
  (and (> p 0) (< (+ p 46) (vector-at M MM-SIR-N)) (= (gn-op M p) OP-FN)
       (> f 0) (< f (vector-at M MM-FN-N)) (not (gn-clamp-open M f))
       (= (gn-fnf M f FF-SIR) p) (= (gn-fnf M f FF-NPARAMS) 5)
       (= (gn-fnf M f FF-NSLOTS) 5) (= (gn-fnf M f FF-DEPTH) 10)
       (= (gn-fnf M f FF-PT0) TY-VEC) (= (gn-fnf M f (+ FF-PT0 1)) TY-I64)
       (= (gn-fnf M f (+ FF-PT0 2)) TY-I64) (= (gn-fnf M f (+ FF-PT0 3)) TY-I64)
       (= (gn-fnf M f (+ FF-PT0 4)) TY-I64) (= (gn-fnf M f FF-RTYPE) TY-I64)
       (= (gn-g M gn-f-leaf) 0) (= (gn-g M gn-f-freg) 0) (= (gn-g M gn-f-h) 0)
       (>= (gn-sreg M 1) 19) (>= (gn-sreg M 2) 19) (>= (gn-sreg M 3) 19)
       (>= (gn-sreg M 4) 19) (>= (gn-sreg M 5) 19)
       (<= (gn-sreg M 1) 28) (<= (gn-sreg M 2) 28) (<= (gn-sreg M 3) 28)
       (<= (gn-sreg M 4) 28) (<= (gn-sreg M 5) 28)
       (>= (gn-sir M (+ p 4) IF-B) 1) (<= (gn-sir M (+ p 4) IF-B) 64)
       (>= (gn-sir M (+ p 18) IF-B) 0) (<= (gn-sir M (+ p 18) IF-B) 4095)
       (>= (gn-sir M (+ p 27) IF-B) 0) (<= (gn-sir M (+ p 27) IF-B) 4095)
       (>= (gn-sir M (+ p 20) IF-B) 1) (<= (gn-sir M (+ p 20) IF-B) 64)
       (>= (gn-sir M (+ p 29) IF-B) 1) (<= (gn-sir M (+ p 29) IF-B) 64)
       (> (gn-sir M (+ p 2) IF-A) 0) (> (gn-sir M (+ p 6) IF-B) 0) (> (gn-sir M (+ p 8) IF-A) 0)
       (not= (gn-sir M (+ p 2) IF-A) (gn-sir M (+ p 6) IF-B))
       (not= (gn-sir M (+ p 2) IF-A) (gn-sir M (+ p 8) IF-A))
       (not= (gn-sir M (+ p 6) IF-B) (gn-sir M (+ p 8) IF-A))
       (gn-dot-shape M p f 0))))
(defn- gn-dot-expand [M :vector-i64 j :i64 n :i64 sb :i64] :vector-i64
 (if (= j n) M
  (gn-dot-expand (-> M (gn-emit (enc-ldr 9 0 (* 8 j)))
                      (gn-emit (enc-ldr 10 1 (* 8 j sb)))
                      (gn-emit (enc-madd 2 9 10 2))) (inc j) n sb)))
(defn- gn-dot-patch [M :vector-i64 at :i64 end :i64 cc :i64] :vector-i64
 (gn-put M (+ MM-CODE-BASE at) (enc-bcond cc (- end at))))
(defn- gn-dot-entry [M :vector-i64 i :i64] :vector-i64
 (if (not (gn-dot? M i)) M
  (let [p (dec i) n (gn-sir M (+ p 4) IF-B) sa (gn-sir M (+ p 20) IF-B)
        sb (gn-sir M (+ p 29) IF-B) oa (gn-sir M (+ p 18) IF-B) ob (gn-sir M (+ p 27) IF-B)
        r1 (gn-sreg M 1) r2 (gn-sreg M 2) r3 (gn-sreg M 3) r4 (gn-sreg M 4) r5 (gn-sreg M 5)
        M0 (gn-emit M (enc-cmp-i r4 0)) b0 (vector-at M0 MM-CODE-N)
        M1 (-> M0 (gn-emit (enc-bcond (enc-cond-ne) 0)) (gn-emit (enc-cmp-i r2 n))) b1 (vector-at M1 MM-CODE-N)
        M2 (-> M1 (gn-emit (enc-bcond (enc-cond-hs) 0)) (gn-emit (enc-cmp-i r3 n))) b2 (vector-at M2 MM-CODE-N)
        M3 (-> M2 (gn-emit (enc-bcond (enc-cond-hs) 0)) (gn-emit (enc-ldr 8 7 CTX-FUEL)) (gn-emit (enc-cmp-i 8 n))) b3 (vector-at M3 MM-CODE-N)
        M4 (-> M3 (gn-emit (enc-bcond (enc-cond-lo) 0)) (gn-emit (enc-ldr 16 7 312)) (gn-emit (enc-ldr 16 16 0))
                  (gn-emit (enc-sub-i 17 r1 1)) (gn-emit (enc-cmp-r 17 16))) b4 (vector-at M4 MM-CODE-N)
        M5 (-> M4 (gn-emit (enc-bcond (enc-cond-hs) 0)) (gn-emit (enc-ldr 16 7 320)) (gn-emit (gn-e-addsl 16 16 17 4))
                  (gn-emit (enc-ldp 17 3 16 0)) (gn-emit (enc-ldr 4 7 328)) (gn-emit (gn-e-addsl 4 4 17 3))
                  (gn-mov-imm 16 sa) (gn-emit (enc-mul 0 r2 16)) (gn-emit (enc-add-i 0 0 oa))
                  (gn-emit (enc-add-i 1 r3 ob)) (gn-emit (enc-add-i 17 0 (dec n))) (gn-emit (enc-cmp-r 17 3))) b5 (vector-at M5 MM-CODE-N)
        M6 (-> M5 (gn-emit (enc-bcond (enc-cond-hs) 0)) (gn-emit (enc-add-i 17 1 (* (dec n) sb)))
                  (gn-emit (enc-cmp-r 17 3))) b6 (vector-at M6 MM-CODE-N)
        M7 (-> M6 (gn-emit (enc-bcond (enc-cond-hs) 0)) (gn-emit (gn-e-addsl 0 4 0 3))
                  (gn-emit (gn-e-addsl 1 4 1 3)) (gn-mov 2 r5) (gn-dot-expand 0 n sb)
                  (gn-emit (enc-sub-i 8 8 n)) (gn-emit (enc-str 8 7 CTX-FUEL))
                  (gn-mov r5 2) (gn-mov-imm r4 n)
                  (gn-fix FX-B26 (gn-sir M (+ p 2) IF-A)) (gn-emit (enc-b 0)))
        end (vector-at M7 MM-CODE-N)]
   (-> M7 (gn-dot-patch b0 end (enc-cond-ne)) (gn-dot-patch b1 end (enc-cond-hs))
          (gn-dot-patch b2 end (enc-cond-hs)) (gn-dot-patch b3 end (enc-cond-lo))
          (gn-dot-patch b4 end (enc-cond-hs)) (gn-dot-patch b5 end (enc-cond-hs))
          (gn-dot-patch b6 end (enc-cond-hs)) (gn-vclear)))))
'''
needle=';; one SIR instruction (unreachable ones are dropped until the next LABEL / FN / END)';assert g.count(needle)==1;g=g.replace(needle,helper+'\n'+needle,1)
needle='OP-FUEL (gn-op-fuel M)';assert g.count(needle)==1;g=g.replace(needle,'OP-FUEL (gn-dot-entry (gn-op-fuel M) i)',1)
(w/'41-a64gen-prototype.kotoba').write_text(g)
parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')]
(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader'),('clobber-full-state-loader','clobber-full-state-loader')]:shutil.copy2(b/src,w/dst)
for s in ['build.py','check-ports.py','permanent-regression.py']:(w/s).write_text((b/s).read_text().replace('amu-same-local-read-20261006','amu-dot-unroll-20261006'))
(w/'hypothesis.json').write_text(json.dumps({'status':'registered-before-build-proof-timing','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'prototypeSha256':hashlib.sha256((w/'41-a64gen-prototype.kotoba').read_bytes()).hexdigest(),'hypothesis':'Exact closed typed whole affine dot loop with proof-guarded bounded unrolling removes repeated index/fuel/control costs. No cached results; originalloop fallback for unproved inputs.','entryFuelPreserved':True,'sourceBodiesUnchanged':True,'admission':'Exact47 SIR ops/fields, 5 typed params/locals, depth10, closed, nonleaf all5callee slots; trip/strides1..64, offsets0..4095; runtime k0, row/col unsigned<n, handle valid, complete read endpoints<len, remaining unsigned fuel>=n.','proofRequired':'Original470/11187, hand extreme/overflow/zero-trip/badhandle/index/partialfuel/resource/effects/closed-open controls; real/testlayout; all19 results/exactfuel/fullstate; 4genfixedpoint; fresh30triples under unchanged5pct and gap>sumSD criteria; gates/integrated before adoption','authoringException':'New algorithm with no existing AST refactor rule; one-off prototype only, no product edit.','productChanged':False,'officialEmbenchScore':False,'goal':'C-or-better across all19 original aligned workloads'},indent=2)+'\n')
print('PASS registered bounded whole-dot-loop native prototype')
