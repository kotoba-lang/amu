from pathlib import Path
import ast,json
D=Path(__file__).resolve().parent
fn=next(v for v in ast.parse((D/'native-call.py').read_text()).body if isinstance(v,ast.FunctionDef)and v.name=='call')
first=fn.body[0];assert isinstance(first,ast.Expr)and isinstance(first.value,ast.Call)and first.value.func.id=='need'
test=first.value.args[0];assert isinstance(test,ast.BoolOp)and isinstance(test.op,ast.And)
expected="type(pr['maximumLoaderCalls']) is int and pr['maximumLoaderCalls']==len(pr['cases']) and len(rows)<pr['maximumLoaderCalls'] and pr['cases'][len(rows)]==case"
assert ast.dump(test)==ast.dump(ast.parse(expected,mode='eval').body)
model=ast.FunctionDef(name='actual_precondition',args=fn.args,body=[first,ast.Return(ast.Constant(True))],decorator_list=[])
mod=ast.fix_missing_locations(ast.Module(body=[model],type_ignores=[]));ns={}
def need(v,m):
 if not v:raise AssertionError(m)
exec(compile(mod,'actual-native-call-first-statement','exec'),{'need':need},ns)
g=ns['actual_precondition'];cases=[{'index':i}for i in range(1,5)];p={'cases':cases,'maximumLoaderCalls':4};assert g(None,None,p,cases[0],[],None,None);assert g(None,None,p,cases[3],[{},{},{}],None,None)
ref=0
for rows,case in [([],cases[3]),([{}],cases[0]),([{}]*4,cases[0]),([{}]*4,cases[3]),([{}]*5,cases[0])]:
 try:g(None,None,p,case,rows,None,None)
 except AssertionError:ref+=1
 else:raise AssertionError('actual native literal precondition admitted outside ordering/cap')
assert ref==5
print(json.dumps({'status':'PASS_ACTUAL_NATIVE_CALL_AST_PRECONDITION_ONLY','registeredCallCap':4,'firstAndLastPositive':2,'outsideOrWrongOrderedRefusals':5,'sourceStatement':ast.unparse(first),'nativeOperations':0}))
