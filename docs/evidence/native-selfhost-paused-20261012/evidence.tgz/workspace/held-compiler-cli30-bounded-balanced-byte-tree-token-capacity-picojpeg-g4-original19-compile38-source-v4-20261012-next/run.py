from pathlib import Path

import json,hashlib,stat,re,os,importlib.util,time

D=Path(__file__).resolve().parent

def need(v,m):
 if not v:raise AssertionError(m)

def load(p):return json.loads(Path(p).read_bytes())

def receipt(p):
 p=Path(p);a=p.lstat();need(stat.S_ISREG(a.st_mode)and not p.is_symlink()and a.st_size<=33554432,'bounded regular');b=p.read_bytes();z=p.lstat();need((a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns),'stable bytes');return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def pin(p,r):need(receipt(p)=={k:r[k]for k in ['bytes','sha256']},'exact pin');return Path(p)

def save(p,v):
 b=(json.dumps(v,indent=2)+'\n').encode();need(len(b)<=16777216,'bounded metadata');q=Path(str(p)+'.pending')
 with q.open('xb',buffering=0)as f:
  view=memoryview(b)
  while view:n=f.write(view);need(type(n)is int and 0<n<=len(view),'short write');view=view[n:]
  os.fsync(f.fileno())
 os.replace(q,p)

def container(raw):
 m=re.match(rb'KSEED1 ([1-9][0-9]{0,9}) ([1-9][0-9]{0,2})\n',raw);need(m is not None and len(raw)<=4194560,'container header');cut=raw.find(b'\n\n',m.end());need(cut>=m.end(),'separator');e=[]
 for line in raw[m.end():cut].splitlines():
  q=re.fullmatch(rb'([A-Za-z0-9_-]+) ([0-9]{1,10}) ([0-9]{1,2})',line);need(q is not None,'export');e.append((q[1].decode(),int(q[2]),int(q[3])))
 b=raw[cut+2:];need(len(e)==int(m[2])and len(set(x[0]for x in e))==len(e)and len(b)==int(m[1])and 0<len(b)<=4194304 and all(x[1]%4==0 and x[1]+4<=len(b)and x[2]<=32 for x in e),'whole payload exports');return b,e

def native_transport_guard(p):
 import ast
 required=set()
 for name in ['native-call.py','launch-wrapper.py']:
  tree=ast.parse((D/name).read_text())
  required.update(n.slice.value for n in ast.walk(tree) if isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name) and n.value.id=='pr' and isinstance(n.slice,ast.Constant) and isinstance(n.slice.value,str))
 need(required<=set(p),'native/wrapper literal preregistration keys missing: '+repr(sorted(required-set(p))))
 expected={'path': '/opt/homebrew/Cellar/python@3.14/3.14.6/Frameworks/Python.framework/Versions/3.14/bin/python3.14', 'bytes': 52448, 'sha256': 'b502cb4c5b46b8d4192ec6bcb600ce8922f1afc396fcf646e8765c6eba74a0bf'}
 need(type(p['interpreter'])is dict and p['interpreter']==expected,'exact qualified transport interpreter')
 pin(expected['path'],expected)
 return sorted(required)

def native_call_cap_guard(p):
 import ast
 f=next(v for v in ast.parse((D/'native-call.py').read_text()).body if isinstance(v,ast.FunctionDef)and v.name=='call');first=f.body[0]
 expected="type(pr['maximumLoaderCalls']) is int and pr['maximumLoaderCalls']==len(pr['cases']) and len(rows)<pr['maximumLoaderCalls'] and pr['cases'][len(rows)]==case"
 need(isinstance(first,ast.Expr)and isinstance(first.value,ast.Call)and isinstance(first.value.func,ast.Name)and first.value.func.id=='need','actual first call admission')
 need(ast.dump(first.value.args[0])==ast.dump(ast.parse(expected,mode='eval').body),'registered count and ordered admission before API')
 need(type(p['maximumLoaderCalls'])is int and p['maximumLoaderCalls']==len(p['cases'])==38,'registered exact four')
 return True

def go_header(g,p,O):
 keys={'status','maximumLoaderCalls','outputRoot','noRetry','timingAuthorized','runtimeGuestAuthorized','compilerGuestAuthorized','C2','outerHostLaunchRequiresEscalation','sourcePinsSHA256','inputPinsSHA256','preregistrationSHA256','driverSHA256','sourceReviews','loaderBuildProof','main1ActualProof','candidateSourceReview'}
 need(set(g)==keys and g['status']==p['rootGOStatus']and g['maximumLoaderCalls']==38 and g['outputRoot']==str(O)and g['noRetry']is True and g['timingAuthorized']is False and g['runtimeGuestAuthorized']is False and g['compilerGuestAuthorized']is True and g['C2']is False and g['outerHostLaunchRequiresEscalation']is True and g['main1ActualProof']==p['main1ActualProof'],'exact four compiler only GO');return True

def candidate_producer_guard(p,rootGO,role='candidate'):
 need(role=='candidate','two generated roles');O=Path(p['freshOutputRoot']);offset=0
 e=load(O/(role+'-producer.json'));source=p['candidateUnity']
 need(set(e)=={'format','rootGO','sourcePinsSHA256','preregistrationSHA256','source','container','native','exports','admittedCalls','qualificationScope','noRetry'},'producer exact schema')
 need(e['format']==p['generatedCandidateReceiptFormat']and e['rootGO']==rootGO and e['sourcePinsSHA256']==receipt(D/'source-pins.json')['sha256']and e['preregistrationSHA256']==receipt(D/'preregistration.json')['sha256']and e['source']==source and e['qualificationScope']=='TWO_CURRENT_GO_ADMITTED_COMPILER_CALLS_ONLY'and e['noRetry']is True,'producer source/GO')
 need(e['container']['path']==str(O/('candidate.kseed'))and e['native']['path']==str(O/('candidate.bin'))and e['exports']==[['main',0,0]]and len(e['admittedCalls'])==2,'own main0 paths')
 pin(rootGO['path'],rootGO);pin(source['path'],source);b,x=container(pin(e['container']['path'],e['container']).read_bytes());need(b==pin(e['native']['path'],e['native']).read_bytes()and x==[('main',0,0)],'whole producer')
 from runtime import qualify
 for i,d in enumerate(e['admittedCalls']):
  c=p['cases'][offset+i];need(d['path']==str(O/(c['label']+'.result.json')),'two exact prior results');r=load(pin(d['path'],d));need(r['label']==c['label']and r['case']==c and r['returncode']==0 and semantic_call_admitted(r),'semantic prior producer call')
  out=(O/(c['label']+'.stdout')).read_bytes();err=(O/(c['label']+'.stderr')).read_bytes();need(hashlib.sha256(out).hexdigest()==r['rawStdoutSHA256']and hashlib.sha256(err).hexdigest()==r['rawStderrSHA256']and qualify(out,err,c)==r['report'],'whole stopped raw')
  need(r['report']['containerBytes']==e['container']['bytes']if i==0 else r['report']['nativeBytes']==e['native']['bytes']and r['report']['offset']==0 and r['report']['arity']==0,'producer lengths')
 return e

def compiler_case(argv,p,c):
 need(len(p['cases'])==38 and c in p['cases'],'exact38')
 i=p['cases'].index(c);e=p['originalEntries'][i//2];kind='compile'if i%2==0 else'extract';w=e['workload'];O=Path(p['freshOutputRoot']);inp=str(O/(w+('.kotoba'if kind=='compile'else'.kseed')));out=str(O/(w+('.kseed'if kind=='compile'else'.bin')));prod=p['currentCompiler']['path']if kind=='compile'else p['extractorNative']['path'];args=['compile',inp,'--target','aarch64-macos','--output',out]if kind=='compile'else['extract-native',inp,'--symbol',e['symbol'],'--output',out]
 need(c['index']==i+1 and c['label']==w+'-'+kind and c['workload']==w and c['kind']==kind and c['symbol']==e['symbol']and c['arity']==1 and c['producerRef']==('candidate'if kind=='compile'else'extractor')and c['snapshot']is False and c['telemetry']is False and c['inputPath']==inp and c['outputPath']==out,'exact source/symbol/order')
 need(argv==c['nativeArgv']==[p['loader'],prod,'0','0','aarch64','35,37,38,39','--',*args],'exact compiler CLI')
 need(p['environment']['KEXE_FUEL']=='off'and p['environment']['KEXE_CAP_RESOURCES_35']==str(O)and p['environment']['KEXE_CPU_SECONDS']==p['environment']['KEXE_WALL_SECONDS']=='30'and len(p['environment'])==17,'unchanged compiler environment')
 return True
def diagnostic_loader(g,p):
 q=load(pin(p['loaderBuildProof']['path'],p['loaderBuildProof']));need(q['status']==p['loaderBuildProofRequiredStatus']and q['artifact']==p['loaderArtifact']and q['copiedCSource']==p['candidateC'],'existing diagnostic loader identity');pin(p['loader'],p['loaderArtifact']);pin(p['main1ActualProof']['path'],p['main1ActualProof']);return True

def case_producer(p,c,rootGO):
 return (p['currentCompiler'],p['currentCompilerContainer'])if c['kind']=='compile'else(p['extractorNative'],p['extractorContainer'])

def baseline_guard(p):
 cl=load(pin(p['baselineClosure']['path'],p['baselineClosure']));z=load(pin(p['baselineCompletion']['path'],p['baselineCompletion']));old=load(pin(p['baselineRegistration']['path'],p['baselineRegistration']));need(cl['exit_code']==0 and cl['terminal']==dict(childCalls=4,allChildrenClosed=True,failure=False)and cl['report']==p['baselineCompletion']and z['closedCompilerCalls']==4,'exact retained prefix stopped four')
 need(z['aesImage']==p['baselineImage']and z['aesContainer']==p['baselineContainer']and old['subjectSource']==p['subjectSource'],'exact parent AES source/body');body,x=container(pin(p['baselineContainer']['path'],p['baselineContainer']).read_bytes());need(body==pin(p['baselineImage']['path'],p['baselineImage']).read_bytes()and tuple(p['baselineOwnExport'])in x and p['baselineOwnExport'][0]=='batch'and p['baselineOwnExport'][2]==1,'whole baseline ownbatch')
 return True

def semantic_call_admitted(r):
 if r['strictHeldSamplingPolicyPassed']is True:return True
 o=r['semanticControllerObservation'];c=o['capture'];m=o['memoryAdmissionRecord']
 need(c['semanticDecodeAuthorized']is True and c['completeRaw']is True and c['stoppedWriter']is True and m['completePipeEOF']is True and m['stoppedClosedCapture']is True and m['rawTruncated']is False and m['captureErrors']==[] and m['exactDirectChildWait']=='closed0'and m['waitUncertain']is False and m['withinOriginalDeadline']is True and m['groupAuthorityRetired']is True and m['groupOperationsAfterUncertainty']==m['groupOperationsAfterWait']==0,'existing complete owned semantic capture')
 from artifact_admission import accept_artifact_observation
 return accept_artifact_observation(o)

def ordinary_producer_guard(p):
 ap=load(pin(p['acceptedRegistration']['path'],p['acceptedRegistration']));completion=load(pin(p['acceptedCompletion']['path'],p['acceptedCompletion']));cl=load(pin(p['acceptedRootClosure']['path'],p['acceptedRootClosure']));e=load(pin(p['acceptedProducer']['path'],p['acceptedProducer']))
 need(cl['status']=='closed'and cl['exit_code']==0 and cl['terminal']==dict(childCalls=6,allChildrenClosed=True,failure=False)and cl['report']==p['acceptedCompletion']and completion['closedCompilerCalls']==6 and completion['noRetry']is True and completion['wholeG2G3G4Equal']is True and completion['sourceCandidate']==p['candidateUnity'],'actual selfhost fixedpoint6 whole closure')
 FD=Path(p['acceptedRegistration']['path']).parent;fsp=load(pin(p['acceptedSourcePins']['path'],p['acceptedSourcePins']));fip=load(pin(p['acceptedInputPins']['path'],p['acceptedInputPins']));pin(p['acceptedDriver']['path'],p['acceptedDriver'])
 for n,r in fsp.items():pin(FD/n,r)
 spec=importlib.util.spec_from_file_location('source_only_accepted_fixedpoint',p['acceptedDriver']['path']);fp=importlib.util.module_from_spec(spec);spec.loader.exec_module(fp);need(fp.source_scope(ap,fip),'same approved fixedpoint source prerequisites and native4 ancestor')
 rootGO=e['rootGO'];g=load(pin(rootGO['path'],rootGO));need(rootGO==completion['rootGO']and fp.go_header(g,ap,Path(ap['freshOutputRoot'])),'exact fixedpoint rootGO')
 for n,k in [('source-pins.json','sourcePinsSHA256'),('input-pins.json','inputPinsSHA256'),('preregistration.json','preregistrationSHA256'),('run.py','driverSHA256')]:need(receipt(FD/n)['sha256']==g[k],'fixedpoint GO SOURCE binding')
 need(g['loaderBuildProof']==ap['loaderBuildProof']and len(g['sourceReviews'])==1,'fixedpoint reviewed runner')
 for d in g['sourceReviews']:
  q=load(pin(d['path'],d));need(q['status']==ap['sourceReviewStatus']and all(q[k]==g[k]for k in ['sourcePinsSHA256','inputPinsSHA256','preregistrationSHA256','driverSHA256']),'exact fixedpoint SOURCE review')
 from runtime import qualify
 bodies=[];packed=[]
 for j,role in enumerate(['G2','G3','G4']):
  record=completion['wholeGenerations'][role];v=load(pin(record['producer']['path'],record['producer']));need(set(v)=={'format','rootGO','sourcePinsSHA256','preregistrationSHA256','source','container','native','exports','admittedCalls','qualificationScope','noRetry'},'fixedpoint producer exact schema')
  need(v['format']=='BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_PICOJPEG_FIXEDPOINT6_GENERATED_PRODUCER_V1'and v['rootGO']==rootGO and v['sourcePinsSHA256']==p['acceptedSourcePins']['sha256']and v['preregistrationSHA256']==p['acceptedRegistration']['sha256']and v['source']==p['candidateUnity']and v['native']==record['native']and v['container']==record['container']and v['exports']==[['main',0,0]]and v['qualificationScope']=='TWO_CURRENT_GO_ADMITTED_COMPILER_CALLS_ONLY'and v['noRetry']is True and len(v['admittedCalls'])==2,'exact ordered selfhost generation source/GO')
  need(v['native']['path']==str(FD/'run-outputs'/(role+'.bin'))and v['container']['path']==str(FD/'run-outputs'/(role+'.kseed')),'exact generation paths')
  body,exports=container(pin(v['container']['path'],v['container']).read_bytes());need(body==pin(v['native']['path'],v['native']).read_bytes()and exports==[('main',0,0)],'whole generation main0');bodies.append(body);packed.append(pin(v['container']['path'],v['container']).read_bytes())
  for k,dr in enumerate(v['admittedCalls']):
   i=j*2+k;c=ap['cases'][i];r=load(pin(dr['path'],dr));need(fp.compiler_case(c['nativeArgv'],ap,c)and dr['path']==str(FD/'run-outputs'/(c['label']+'.result.json'))and r==completion['calls'][i]and r['case']==c and r['label']==c['label']and r['returncode']==0 and semantic_call_admitted(r),'exact admitted selfhost six calls')
   base=Path(dr['path']).parent/c['label'];out=Path(str(base)+'.stdout').read_bytes();err=Path(str(base)+'.stderr').read_bytes();need(hashlib.sha256(out).hexdigest()==r['rawStdoutSHA256']and hashlib.sha256(err).hexdigest()==r['rawStderrSHA256']and qualify(out,err,c)==r['report'],'whole stopped selfhost raw')
  if role=='G4':need(v==e and record['producer']==p['acceptedProducer']and v['native']==p['acceptedCompiler']==p['currentCompiler']and v['container']==p['acceptedCompilerContainer']==p['currentCompilerContainer'],'exact G4 selected producer')
 need(bodies[0]==bodies[1]==bodies[2]and packed[0]==packed[1]==packed[2],'whole G2G3G4 fixedpoint identity')
 return e


def candidate_source_guard(p):
 nd=Path(p['acceptedRegistration']['path']).parent;ap=load(pin(p['acceptedRegistration']['path'],p['acceptedRegistration']));spec=importlib.util.spec_from_file_location('exact_accepted_interval_source',p['acceptedDriver']['path']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);need(m.source_scope(ap,load(pin(p['acceptedInputPins']['path'],p['acceptedInputPins']))),'same FP actual main source prerequisites');need(ap['candidateFreeze']==p['candidateFreeze'] and ap['candidate41']==p['candidate41'] and ap['candidate00']==p['candidate00'] and ap['candidateUnity']==p['candidateUnity'] and ap['qualificationPolicy']==p['qualificationPolicy'] and ap['candidateSourceReviews'][0]==p['candidateSourceReview'],'exact current two-owner00+41 source and policy');return True

def root_review_guard(p,g):
 need(g['candidateSourceReview']==p['candidateSourceReview'],'exact root GO review descriptor');return candidate_source_guard(p)

def source_scope(p,ip):
 native_transport_guard(p);native_call_cap_guard(p);diagnostic_loader(None,p);ordinary_producer_guard(p);candidate_source_guard(p)
 r=load(pin(p['originalRegistry']['path'],p['originalRegistry']));need(r['originalEntries']==p['originalEntries']and r['canonicalMatrix']==p['canonicalMatrix']and len(p['originalEntries'])==19 and sum(len(x['iterations'])for x in p['originalEntries'])==95,'exact original19/95 registry')
 pin(p['canonicalMatrix']['path'],p['canonicalMatrix'])
 need(p['materializations']==[dict(source=e['source'],destination=str(Path(p['freshOutputRoot'])/(e['workload']+'.kotoba')))for e in p['originalEntries']],'original source copies')
 need(p['maximumSequentialCampaignSeconds']==2400 and p['maximumLoaderCalls']==38 and all(compiler_case(c['nativeArgv'],p,c)for c in p['cases']),'bounded38 schedule')
 for f,r in ip.items():pin(f,r)
 return True

def main(goPath):
 p=load(D/'preregistration.json');sp=load(D/'source-pins.json');ip=load(D/'input-pins.json');gp=Path(goPath);g=load(gp);gr=receipt(gp);rootGO=dict(path=str(gp),**gr);O=Path(p['freshOutputRoot']);go_header(g,p,O);rows=[];results=[];generated={};ok=False
 for n,k in [('source-pins.json','sourcePinsSHA256'),('input-pins.json','inputPinsSHA256'),('preregistration.json','preregistrationSHA256'),('run.py','driverSHA256')]:need(receipt(D/n)['sha256']==g[k],'GO binding')
 need(g['loaderBuildProof']==p['loaderBuildProof']and len(g['sourceReviews'])==1,'one concise root runner SOURCE review')
 for r in g['sourceReviews']:
  q=load(pin(r['path'],r));need(q['status']==p['sourceReviewStatus']and all(q[k]==g[k]for k in ['sourcePinsSHA256','inputPinsSHA256','preregistrationSHA256','driverSHA256']),'reviewed runner identities')
 def guard():
  need(receipt(gp)==gr,'immutableGO')
  for n,r in sp.items():pin(D/n,r)
  for n,r in generated.items():pin(n,r)
  source_scope(p,ip)
 root_review_guard(p,g)
 guard();need(not O.exists(),'fresh output');O.mkdir();deadline=time.monotonic()+2400
 def artifact(path):
  r=dict(path=str(path),**receipt(path));generated[str(path)]={k:r[k]for k in ['bytes','sha256']};save(O/'generated-pins.json',generated);return r
 spec=importlib.util.spec_from_file_location('held_call',D/'native-call.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 try:
  for m in p['materializations']:
   dest=Path(m['destination']);need(dest.parent==O and not dest.exists(),'fresh copy');dest.write_bytes(pin(m['source']['path'],m['source']).read_bytes());dest.chmod(0o444);artifact(dest)
  for index,c in enumerate(p['cases'],1):
   guard();need(time.monotonic()+60<=deadline,'reserve30+cleanup30');need(not Path(c['outputPath']).exists(),'fresh output');prod,packed=case_producer(p,c,rootGO)
   seal=dict(format=p['invocationSealVersion'],index=index,label=c['label'],nativeArgv=c['nativeArgv'],producer=prod,producerContainer=packed,input=dict(path=c['inputPath'],**receipt(c['inputPath'])),outputPath=c['outputPath'],rootGO=rootGO,sourcePinsSHA256=g['sourcePinsSHA256'],preregistrationSHA256=g['preregistrationSHA256']);se=O/(c['label']+'.admission.json');save(se,seal);need(se.stat().st_size<=4096,'seal');se.chmod(0o444);sr=artifact(se)
   r=mod.call(D,O,p,c,rows,save,sr['sha256']);need(semantic_call_admitted(r),'strict or exact existing semantic termination gap; memory separate');out=artifact(Path(c['outputPath']));results.append(r)
   if c['kind']=='compile':need(r['report']['containerBytes']==out['bytes'],'compile length');container(Path(c['outputPath']).read_bytes())
   else:
    b,x=container(Path(c['inputPath']).read_bytes());need(b==Path(c['outputPath']).read_bytes(),'whole extraction');entry=next(v for v in x if v[0]==c['symbol']);need(r['report']['nativeBytes']==len(b)and r['report']['offset']==entry[1]and r['report']['arity']==entry[2]==c['arity'],'own export')
   for key,suffix in [('stdout','stdout'),('stderr','stderr'),('limitJournal','limit-journal.jsonl'),('memoryJournal','memory-journal.jsonl'),('ownershipJournal','ownership-journal.jsonl')]:
    path=O/(c['label']+'.'+suffix);need(receipt(path)=={k:rows[-1][key][k]for k in ['bytes','sha256']},'stopped evidence');artifact(path)
   rp=O/(c['label']+'.result.json');save(rp,r);rp.chmod(0o444);artifact(rp);save(O/'results.json',results)
  guard();ok=True
 except BaseException as ex:save(O/'failure.json',dict(error=repr(ex),noRetry=True));raise
 finally:save(O/'terminal.json',dict(childCalls=len(rows),allChildrenClosed=all(r['state']=='terminal'and r['returncode']==0 for r in rows),failure=not ok))
 need(ok and len(rows)==38,'complete38');guard();images=[]
 for e in p['originalEntries']:
  w=e['workload'];body,exports=container((O/(w+'.kseed')).read_bytes());need(body==(O/(w+'.bin')).read_bytes(),'whole workload');own=next(x for x in exports if x[0]==e['symbol']);need(own[2]==1,'own ABI');images.append(dict(workload=w,source=e['source'],symbol=e['symbol'],profiles=e['iterations'],native=artifact(O/(w+'.bin')),container=artifact(O/(w+'.kseed')),exports=[list(x)for x in exports],selectedExport=list(own)))
 save(O/'report.json',dict(status='COMPLETE_HELD_COMPILER_BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_PICOJPEG_G4_ORIGINAL19_COMPILE38_ARTIFACTS_ONLY',calls=results,closedCompilerCalls=38,rootGO=rootGO,original19Images=images,currentCandidateNative=p['currentCompiler'],currentCandidateContainer=p['currentCompilerContainer'],sourceCandidate=p['candidateUnity'],acceptedCompletion=p['acceptedCompletion'],benchmarkGuestCalls=0,runtimeQualified=False,physicalMemorySamplingQualified=False,performanceQualified=False,noRetry=True))
if __name__=='__main__':
 import sys
 need(len(sys.argv)==2,'one exactGO');main(sys.argv[1])
