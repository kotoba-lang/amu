import run,copy,json
p=run.load(run.D/'preregistration.json');assert run.source_scope(p,run.load(run.D/'input-pins.json'));n=0
for i,c in enumerate(p['cases']):
 assert run.compiler_case(c['nativeArgv'],p,c)
 q=copy.deepcopy(p);q['cases'][i]['symbol']='unknown'
 try:run.compiler_case(q['cases'][i]['nativeArgv'],q,q['cases'][i])
 except AssertionError:n+=1
 else:raise AssertionError('wrong export')
assert n==38
print(json.dumps(dict(status='PASS_SOURCE_ONLY_ORIGINAL19_COMPILE38_SCOPE',cases=38,wrongSymbolRefusals=38,originalOwners=19,sourceProfiles=95,nativeOperations=0)))
