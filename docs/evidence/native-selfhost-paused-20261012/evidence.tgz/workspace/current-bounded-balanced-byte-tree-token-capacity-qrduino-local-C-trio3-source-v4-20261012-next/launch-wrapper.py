"""Fixed SOURCE wrapper: named limits then exact native-loader exec. Import inert."""
from pathlib import Path
import os,sys,json,resource,hashlib,stat,fcntl

def target(before,soft,hard):
 s,h=before;inf=resource.RLIM_INFINITY
 # Required loader CPU soft30/hard31 must not raise finite inherited limits.
 assert h==inf or h>=hard,'inherited hard below exact policy'
 assert s==inf or s>=soft,'inherited soft below exact policy'
 return (soft,hard)
D=Path(__file__).resolve().parent
def checked(p,v):
 p=Path(p);a=p.lstat();assert stat.S_ISREG(a.st_mode)and not p.is_symlink()and a.st_size==v['bytes']and a.st_size<=384*1024**2
 b=p.read_bytes();z=p.lstat();assert (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns)
 assert hashlib.sha256(b).hexdigest()==v['sha256'];return str(p)
def allowed(argv,pr):return argv in [r['nativeArgv']for r in pr['cases']]
def runtime_case(argv,pr,row):
 assert row in pr['cases']and argv==row['nativeArgv']and len(argv)==5
 assert row['arm']in ['OFF','ON','C']and row['n']==32 and row['calls']==64 and row['warmup']==1
 assert len(pr['environment'])==17 and pr['environment']['KEXE_FUEL']=='16777216'and pr['C2']is False
 return True
def admit(argv,pr,seal,sp,sealSHA):
 from run import load,receipt,go_header,pin
 assert set(seal)=={'format','index','case','consumer','buildReceipt','rootGO','sourcePinsSHA256','preregistrationSHA256'}
 assert seal['format']==pr['invocationSealVersion']and type(seal['index'])is int and 1<=seal['index']<=3 and seal['case']==pr['cases'][seal['index']-1]and seal['case']['nativeArgv']==argv
 runtime_case(argv,pr,seal['case']);assert seal['sourcePinsSHA256']==receipt(D/'source-pins.json')['sha256']and seal['preregistrationSHA256']==sp['preregistration.json']['sha256']
 checked(seal['rootGO']['path'],seal['rootGO']);g=load(seal['rootGO']['path']);go_header(g,pr)
 checked(seal['consumer']['path'],seal['consumer']);checked(seal['buildReceipt']['path'],seal['buildReceipt']);b=load(seal['buildReceipt']['path']);assert b['returncode']==0 and b['consumer']==seal['consumer']and b['argv']==pr['buildArgv']and b['rootGO']==seal['rootGO']and b['rawWritersClosed']is True
 assert seal['consumer']['path']==argv[0]==str(Path(pr['taskRoot'])/'consumer')
 return True

def environment_admission(supplied,observed):
 required=set(supplied);extra=set(observed)-required
 assert len(required)==17 and required<=set(observed),'exact supplied keys present'
 assert all(observed[k]==supplied[k]for k in required),'supplied values unchanged'
 assert extra<= {'__CF_USER_TEXT_ENCODING'},'only named Python runtime metadata permitted'
 return {'stage':'environment-admission','suppliedKeyNames':sorted(required),'runtimeExtraKeyNames':sorted(extra),'missingKeyNames':[],'changedExpectedKeyNames':[],'nativeExecKeyNames':sorted(required),'nativeExecEnvironmentExact':True}
def main(fd,sealSHA,ownershipFD,argv):
 from run import load
 sp=load(D/'source-pins.json')
 for name in sp:checked(D/name,sp[name])
 pr=load(D/'preregistration.json');assert Path.cwd()==Path(pr['taskRoot'])and allowed(argv,pr)
 checked(pr['interpreter']['path'],pr['interpreter'])
 # argv duplicates across balanced rounds; invocation is selected by unique admissionSHA.
 found=[]
 for c in pr['cases']:
  p=Path(pr['freshOutputRoot'])/(c['label']+'.admission.json')
  if p.exists()and hashlib.sha256(p.read_bytes()).hexdigest()==sealSHA:found.append(p)
 assert len(found)==1;sealPath=found[0];sealStat=sealPath.lstat();assert stat.S_ISREG(sealStat.st_mode)and not sealPath.is_symlink()and 0<sealStat.st_size<=4096
 seal=load(sealPath);admit(argv,pr,seal,sp,sealSHA)

 assert type(ownershipFD)is int and ownershipFD>4 and fd!=4 and ownershipFD!=fd
 try:fcntl.fcntl(4,fcntl.F_GETFD)
 except OSError as ex:assert ex.errno==9,'fixed FD4 must be absent'
 else:raise AssertionError('FD4 collision')
 assert fcntl.fcntl(ownershipFD,fcntl.F_GETFL)&os.O_NONBLOCK
 os.dup2(ownershipFD,4,inheritable=True);os.close(ownershipFD)
 environmentWitness=environment_admission(pr['environment'],dict(os.environ))
 total=0
 def emit(q):
  nonlocal total
  b=(json.dumps(q,sort_keys=True)+'\n').encode();assert total+len(b)<=65536
  view=memoryview(b)
  while view:n=os.write(fd,view);assert n>0;view=view[n:]
  os.fsync(fd);total+=len(b)
 emit(environmentWitness)
 for idx,(name,soft,hard)in enumerate([('RLIMIT_FSIZE',67108864,67108864),('RLIMIT_CPU',30,31)],1):
  before=None;want=None
  try:
   kind=getattr(resource,name);before=resource.getrlimit(kind);want=target(before,soft,hard)
   emit({'index':idx,'limit':name,'stage':'before','before':before,'desired':want})
   resource.setrlimit(kind,want);after=resource.getrlimit(kind);assert after==want
   emit({'index':idx,'limit':name,'stage':'outcome','outcome':'installed','readback':after})
  except BaseException as ex:
   emit({'index':idx,'limit':name,'stage':'outcome','outcome':'failure','before':before,'desired':want,'exception':repr(ex)});return 78
 emit({'stage':'exec-ready','argv':argv,'ASSetterRequested':False,'CPUGraceHardSeconds':31})
 os.set_inheritable(fd,False);os.execve(argv[0],argv,dict(pr['environment']))
 return 79
if __name__=='__main__':
 assert len(sys.argv)>=9 and sys.argv[1]=='--journal-fd'and sys.argv[3]=='--admission-sha'and sys.argv[5]=='--ownership-fd'and sys.argv[7]=='--'
 assert len(sys.argv[4])==64 and all(c in '0123456789abcdef'for c in sys.argv[4])
 sys.exit(main(int(sys.argv[2]),sys.argv[4],int(sys.argv[6]),sys.argv[8:]))
