"""Local one wrapper build plus3 held exploratory consumer starts; root-only GO."""
from pathlib import Path
import json,hashlib,stat,os,sys,time,subprocess,importlib.util
D=Path(__file__).resolve().parent
def need(v,m):
 if not v:raise AssertionError(m)

def load(p):return json.loads(Path(p).read_bytes())

def receipt(p):
 p=Path(p);s=p.lstat();need(stat.S_ISREG(s.st_mode)and not p.is_symlink()and s.st_size<=469762048,'bounded regular pin');b=p.read_bytes();s2=p.lstat();need((s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(s2.st_dev,s2.st_ino,s2.st_size,s2.st_mtime_ns),'immutable bytes');return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def pin(p,r):need(receipt(p)=={k:r[k]for k in ['bytes','sha256']},'exact pin:'+str(p));return Path(p)

def save(p,v):
 
 if Path(p).name=='attempts.json':need(all(len(json.dumps(r).encode())<=65536 for r in v),'bounded per-case metadata before publication')
 b=(json.dumps(v,indent=2)+'\n').encode();need(len(b)<=16777216,'bounded valid-last metadata');q=Path(str(p)+'.pending')
 with q.open('wb',buffering=0)as f:
  view=memoryview(b)
  while view:
   n=f.write(view);need(type(n)is int and 0<n<=len(view),'metadata write');view=view[n:]
  os.fsync(f.fileno())
 os.replace(q,p);fd=os.open(str(Path(p).parent),os.O_RDONLY)
 try:os.fsync(fd)
 finally:os.close(fd)

def descriptor(r):
 need(type(r)is dict and set(r)=={'path','bytes','sha256'},'exact descriptor');return pin(r['path'],r)

GO_KEYS={'status','sourcePinsSHA256','inputPinsSHA256','driverSHA256','preregistrationSHA256','sourceReviews','maximumLoaderCalls','maximumClangBuildCalls','runtimeGuestAuthorized','timingAuthorized','diagnosticCBuildAuthorized','noRetry','outputRoot'}
def go_header(g,p):
 need(set(g)==GO_KEYS and g['status']==p['rootGOStatus']and g['maximumLoaderCalls']==3 and g['maximumClangBuildCalls']==1 and g['runtimeGuestAuthorized']is True and g['timingAuthorized']is True and g['diagnosticCBuildAuthorized']is True and g['noRetry']is True and g['outputRoot']==p['freshOutputRoot'],'exact local1build7starts GO')
 for n,k in [('source-pins.json','sourcePinsSHA256'),('input-pins.json','inputPinsSHA256'),('run.py','driverSHA256'),('preregistration.json','preregistrationSHA256')]:need(receipt(D/n)['sha256']==g[k],'exact GO aliases')
 need(len(g['sourceReviews'])==1,'single root source review')
 q=load(descriptor(g['sourceReviews'][0]));need(q['status']==p['sourceReviewStatus']and all(q[k]==g[k]for k in ['sourcePinsSHA256','inputPinsSHA256','driverSHA256','preregistrationSHA256']),'root review exact aliases')
 return True
def semantic_call_admitted(r):
 if r['strictHeldSamplingPolicyPassed']is True:return True
 o=r['semanticControllerObservation'];c=o['capture'];m=o['memoryAdmissionRecord']
 need(c['semanticDecodeAuthorized']is True and c['completeRaw']is True and c['stoppedWriter']is True and m['completePipeEOF']is True and m['stoppedClosedCapture']is True and m['rawTruncated']is False and m['captureErrors']==[] and m['exactDirectChildWait']=='closed0'and m['waitUncertain']is False and m['withinOriginalDeadline']is True and m['groupAuthorityRetired']is True and m['groupOperationsAfterUncertainty']==m['groupOperationsAfterWait']==0,'existing complete owned semantic capture')
 from artifact_admission import accept_artifact_observation
 return accept_artifact_observation(o)

def current_lineage_guard(p,z):
 e=load(descriptor(p['generatedProducer']));need(e['rootGO']==z['rootGO']and e['exports']==[['main',0,0]]and len(e['admittedCalls'])==2,'new producer two actual calls');descriptor(e['rootGO']);descriptor(e['source']);packed=descriptor(e['container']).read_bytes();native=descriptor(e['native']).read_bytes();need(packed[packed.index(b'\n\n')+2:]==native,'whole producer')
 parser=descriptor(p['compilerParser']);spec=importlib.util.spec_from_file_location('saved_compiler_parser',parser);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 need(len(z['calls'])==4 and all(r['returncode']==0 and semantic_call_admitted(r)for r in z['calls']),'four semantic compiler artifacts')
 for r in z['calls']:
  c=r['case'];base=Path(p['new4Completion']['path']).parent/c['label'];out=Path(str(base)+'.stdout').read_bytes();err=Path(str(base)+'.stderr').read_bytes();need(hashlib.sha256(out).hexdigest()==r['rawStdoutSHA256']and hashlib.sha256(err).hexdigest()==r['rawStderrSHA256']and m.qualify(out,err,c)==r['report'],'whole stopped compiler raw')
 for i,r in enumerate(e['admittedCalls']):need(load(descriptor(r))==z['calls'][i],'own exact first two producer records')
 return True



def source_scope():
 for n,r in load(D/'source-pins.json').items():pin(D/n,r)
 for n,r in load(D/'input-pins.json').items():pin(n,r)
 p=load(D/'preregistration.json');q=load(descriptor(p['proposal']));r=load(descriptor(p['stagedInputs']));policy=load(descriptor(p['explorationPolicy']));mp=load(descriptor(p['machinePeer']));m=load(descriptor(p['structuralEvidence']))
 need(policy['status']=='ROOT_ALLOW_GENERIC_BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_QRDUINO_TRIO3_V4' and policy['mechanical']==p['structuralEvidence'] and policy['machineIndependentPeer']==p['machinePeer'] and policy['original19Closure']==p['original19Closure'] and policy['original19SavedPeer']==p['original19Peer'] and policy['maximumRuntimeCalls']==3 and policy['maximumClangBuildCalls']==1 and policy['functionalSmokes']==0 and policy['coarseTrio']==1 and policy['noPrecisionRepeats'] and policy['noRetry'] and policy['noPicoTimingRepeat'] and not policy['adoptionAuthorizedByThisPacket'],'exact QR trio only policy')
 need(mp['status']=='PASS_INDEPENDENT_SAVED_QR_BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_MACHINE_V4' and mp['candidateFreeze']==policy['candidateFreeze'] and mp['rootClosure']==policy['original19Closure'] and mp['original19Completion']==policy['original19Completion'] and mp['original19SavedPeer']==policy['original19SavedPeer'] and mp['machineActivation']==policy['mechanical'] and mp['timingEligible'] and not mp['semanticAuditPending'],'current QR independent whole machine')
 for key in ['actual14WordsPlusBRKEach','allRetainedWordsAndControlsVerified','sixPairedFXLiteralReferencesSourceCertified','fullOwnExportStaticReach']:need(mp[key]is True,'QR semantic proof '+key)
 cl=load(descriptor(p['original19Closure']));z=load(descriptor(policy['original19Completion']));peer=load(descriptor(p['original19Peer']));need(cl['exit_code']==0 and cl['report']==policy['original19Completion'] and cl['terminal']==dict(childCalls=38,allChildrenClosed=True,failure=False) and peer['changedWorkloads']==['picojpeg','qrduino'],'current full38 census')
 reg=load(descriptor(p['current38Registration']));driver=descriptor(p['current38Driver']);spec=importlib.util.spec_from_file_location('current38_source',driver);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);previousRuntime=sys.modules.get('runtime');rs=importlib.util.spec_from_file_location('runtime',descriptor(p['current38Runtime']));rm=importlib.util.module_from_spec(rs);rs.loader.exec_module(rm);sys.modules['runtime']=rm
 try:need(mod.source_scope(reg,mod.load(mod.D/'input-pins.json')),'actual current38 SOURCE guarded custody')
 finally:
  if previousRuntime is None:sys.modules.pop('runtime',None)
  else:sys.modules['runtime']=previousRuntime
 need(reg['candidateFreeze']==policy['candidateFreeze'] and reg['parentCommit']==policy['parentCommit']==r['parentCommit'] and r['current38Registration']==p['current38Registration'],'same twoowner source/current0276')
 old=r['old'];new=next(x for x in z['original19Images']if x['workload']=='qrduino');need(new==r['new'] and new['source']==old['source']==p['subjectSource'],'unchanged full original QR source')
 for arm,x in [('OFF',old),('ON',new)]:
  need(q['row'][arm]['native']==x['native'] and q['row'][arm]['container']==x['container'] and q['row'][arm]['offset']==x['selectedExport'][1],'whole QR images')
  raw=descriptor(x['container']).read_bytes();cut=raw.index(b'\n\n');need(raw[cut+2:]==descriptor(x['native']).read_bytes() and (x['selectedExport'][0]+' '+str(x['selectedExport'][1])+' 1').encode()in raw[:cut].splitlines()[1:],'whole own QR payload/export')
 need(mp['newNative']==new['native'] and mp['baselineNative']==old['native'],'QR machine actual images')
 c=load(descriptor(q['CProof']));need(c['workload']=='qrduino' and c['symbol']==q['row']['symbol']=='batch' and c['savedCopy']==q['CSavedCopy']==r['CSavedCopy'],'unchanged canonical original C owner')
 need(q['metric']['schema']==p['metric']=='BATCH_ABI_RESET_VALIDATION_V1' and q['metric']['resetIncluded'] and receipt(D/'timing-packet-generated.h')=={k:q['generatedHeader'][k]for k in ['bytes','sha256']},'exact reset included header metric')
 need(len(p['cases'])==p['maximumLoaderCalls']==3 and [(x['phase'],x['arm'],x['n'],x['calls'],x['warmup'])for x in p['cases']]==[('timing1',arm,32,64,1)for arm in ['C','OFF','ON']],'one canonical QR trio only')
 for x in p['cases']:need(x['nativeArgv']==[str(Path(p['taskRoot'])/'consumer'),x['arm'],'32','64','1'] and x['workload']=='qrduino' and x['symbol']=='batch','exact each QR argv')
 return p

def build(go,p,gd):
 root=Path(p['taskRoot']);root.mkdir();proposal=load(p['proposal']['path']);I=root/'inputs/qrduino';I.mkdir(parents=True)
 for arm in ['OFF','ON']:(I/(arm+'.bin')).write_bytes(descriptor(proposal['row'][arm]['native']).read_bytes())
 (I/'C.dylib').write_bytes(descriptor(proposal['CSavedCopy']).read_bytes());O=Path(p['freshOutputRoot']);proc=None;rc=None;uncertain=False
 with (O/'build.stdout').open('xb',buffering=0)as out,(O/'build.stderr').open('xb',buffering=0)as err:
  try:
   proc=subprocess.Popen([p['interpreter']['path'],'-B',str(D/'build-limit.py'),str(go)],cwd=root,env=p['buildEnvironment'],stdin=subprocess.DEVNULL,stdout=out,stderr=err,close_fds=True,start_new_session=True)
   save(O/'build-started.json',dict(pid=proc.pid,argv=p['buildArgv'],rootGO=gd));deadline=time.monotonic()+180
   while proc.poll()is None:
    need(time.monotonic()<deadline,'build180 deadline');need(out.tell()<=1048576 and err.tell()<=1048576,'build raw1MiB');time.sleep(.01)
   try:rc=proc.wait(timeout=30)
   except BaseException:uncertain=True;raise
  finally:
   if proc is not None and rc is None and not uncertain:
    try:
     if proc.poll()is None:proc.kill()
     rc=proc.wait(timeout=30)
    except BaseException:uncertain=True
   os.fsync(out.fileno());os.fsync(err.fileno())
 need(not uncertain and rc==0,'known compiler stopped0; no retry');need((O/'build.stdout').stat().st_size<=1048576 and (O/'build.stderr').stat().st_size<=1048576,'bounded stopped raw')
 consumer=dict(path=str(root/'consumer'),**receipt(root/'consumer'));need(consumer['bytes']<=4194304,'bounded wrapper');save(O/'build-receipt.json',dict(argv=p['buildArgv'],returncode=rc,rootGO=gd,consumer=consumer,rawWritersClosed=True,sourcePinsSHA256=receipt(D/'source-pins.json')['sha256'],stdout=receipt(O/'build.stdout'),stderr=receipt(O/'build.stderr'),compilerDescendantClosure='trusted normal clang completion only'))
 return consumer,dict(path=str(O/'build-receipt.json'),**receipt(O/'build-receipt.json'))
def main(go):
 p=source_scope();g=load(go);go_header(g,p);gd=dict(path=str(Path(go).resolve()),**receipt(Path(go)));O=Path(p['freshOutputRoot']);O.mkdir(exist_ok=False);rows=[];results=[];failure=None;consumer=None;deadline=time.monotonic()+p['maximumCampaignSeconds']
 try:
  need(time.monotonic()+210<=deadline,'build reserve180+30');consumer,br=build(Path(go).resolve(),p,gd);source_scope();spec=importlib.util.spec_from_file_location('local_consumer_call',D/'native-call.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
  for i,c in enumerate(p['cases'],1):
   need(time.monotonic()+60<=deadline,'call reserve30+30');pin(gd['path'],gd)
   for n,v in load(D/'source-pins.json').items():pin(D/n,v)
   seal=dict(format=p['invocationSealVersion'],index=i,case=c,consumer=consumer,buildReceipt=br,rootGO=gd,sourcePinsSHA256=g['sourcePinsSHA256'],preregistrationSHA256=g['preregistrationSHA256']);f=O/(c['label']+'.admission.json');save(f,seal);need(f.stat().st_size<=4096,'seal bound');r=m.call(D,O,p,c,rows,save,receipt(f)['sha256']);need(semantic_call_admitted(r),'strict or exact existing semantic termination gap; memory separately retained')
   if c['phase'].startswith('timing'):need(r['report']['timing']['elapsedNs']>0,'positive exploratory clock')
   results.append(r);save(O/(c['label']+'.result.json'),r)
   if i==3:
    group=results[-3:];arms={x['case']['arm']:x for x in group};need(arms['OFF']['report']['observables']==arms['ON']['report']['observables'],'exact native fullreport/fuel17')
    if i==3:need(arms['C']['report']['result']==arms['ON']['report']['result']==1,'C result parity; native counters unavailable')
 except BaseException as e:failure=repr(e)
 save(O/'terminal.json',dict(starts=len(rows),closedCalls=len(results),allChildrenClosed=all(x['state']=='terminal'for x in rows),failure=failure,noRetry=True))
 measured=[dict(arm=r['case']['arm'],calls=r['case']['calls'],n=r['case']['n'],elapsedNs=r['report']['timing']['elapsedNs'],nsPerBody=r['report']['timing']['elapsedNs']/(r['case']['calls']*r['case']['n']))for r in results if r['case']['phase'].startswith('timing')]
 save(O/'report.json',dict(status='COMPLETE_LOCAL_GENERIC_BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_QRDUINO_TRIO3_EXPLORATION_ONLY'if failure is None and len(results)==3 else'REFUSE_LOCAL_GENERIC_BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_QRDUINO_C_EXPLORATION',semanticAuditPending=False,timingEligible=True,optimizationQualified=False,adoptionAuthorized=False,verdict="PROVISIONAL_SCREEN",results=results,measured=measured,consumer=consumer,failure=failure,metric=p['metric'],resetIncluded=True,pureKernelClock=False,officialCScore=False,full19Qualified=False,performanceQualified=False,physicalMemorySamplingQualified=False,importedCompileMemoryQualified=False))
 return 0 if failure is None and len(results)==3 else 78
if __name__=='__main__':sys.exit(main(sys.argv[1]))
