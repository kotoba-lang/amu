from pathlib import Path
import os,sys,json,resource,hashlib
D=Path(__file__).resolve().parent
def main():
 from run import source_scope,go_header,load
 p=source_scope();go_header(load(sys.argv[1]),p)
 assert set(os.environ)-set(p['buildEnvironment'])<={'__CF_USER_TEXT_ENCODING'}and all(os.environ[k]==v for k,v in p['buildEnvironment'].items())
 for k,a,b in [(resource.RLIMIT_CPU,180,181),(resource.RLIMIT_FSIZE,8388608,8388608)]:
  s,h=resource.getrlimit(k);assert (s==resource.RLIM_INFINITY or s>=a)and(h==resource.RLIM_INFINITY or h>=b);resource.setrlimit(k,(a,b));assert resource.getrlimit(k)==(a,b)
 assert not Path(p['buildArgv'][p['buildArgv'].index('-o')+1]).exists();os.execve(p['buildArgv'][0],p['buildArgv'],p['buildEnvironment'])
if __name__=='__main__':main()
