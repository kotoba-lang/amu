import ast,runpy,json,re
from pathlib import Path
import run
D=Path(__file__).parent;p=run.source_scope();q=run.load(run.descriptor(p['proposal']))
x=runpy.run_path(str(D/'wrapper-full-admit-controls.py'));assert x['positive']==3 and x['negative']==12
tr=ast.parse((D/'native-call.py').read_text());call=next(x for x in ast.walk(tr)if isinstance(x,ast.Call)and isinstance(x.func,ast.Name)and x.func.id=='need'and len(x.args)>1 and isinstance(x.args[1],ast.Constant)and x.args[1].value=='registered exact ordered noRetry before API');e=compile(ast.Expression(call.args[0]),'<actual native call precondition>','eval')
for i in range(3):assert eval(e,{},dict(pr=p,rows=[None]*i,case=p['cases'][i]))
for i in [3,4]:assert not eval(e,{},dict(pr=p,rows=[None]*i,case=p['cases'][0]))
for i in range(3):assert not eval(e,{},dict(pr=p,rows=[None]*i,case=p['cases'][(i+1)%3]))
h=(D/'timing-packet-generated.h').read_text()
for arm in ['OFF','ON']:
 m=re.search(r'static const unsigned char timing_'+arm.lower()+r'\[\]=\{([^}]+)\}',h);assert m and bytes(map(int,m.group(1).split(',')))==run.descriptor(q['row'][arm]['native']).read_bytes()
assert 'inputs/qrduino/C.dylib'in h and '#define TIMING_MAX_N 32ULL'in h
assert all(c['nativeArgv'][1:]==[c['arm'],'32','64','1']for c in p['cases'])
assert not(D/'run-outputs').exists()
print(json.dumps(dict(status='PASS_SOURCE_ONLY_QR_TRIO3_WHOLE_GUARD_AND_ACTUAL_CONTROLLER',wrapperPositives=3,wrapperWrongRowsRefused=12,orderedPositiveRows=3,orderedOutsideOrWrongRowsRefused=5,fullImageHeaderExact=True,nativeOperations=0)))
