"""One-clock exact two-record decoder; result1 and C-unavailable semantics only."""
import json
from qualification import native_raw,unique_object
def qualify(out,err,c):
 assert len(out)<=16384 and len(err)<=16384
 lines=out.splitlines(keepends=True);assert len(lines)==2;got=native_raw(lines[0],err);t=json.loads(lines[1],object_pairs_hook=unique_object)
 assert set(t)=={'schema','arm','calls','warmup','elapsedNs','nativeObservablesAvailable','resetIncluded'}
 assert all(type(t[k])is int for k in ['arm','calls','warmup','elapsedNs'])and type(t['nativeObservablesAvailable'])is bool and t['resetIncluded']is True
 assert t['schema']=='BATCH_ABI_RESET_VALIDATION_V1'and t['arm']==['OFF','ON','C'].index(c['arm'])and t['calls']==c['calls']and t['warmup']==1 and 0<=t['elapsedNs']<=30000000000 and t['nativeObservablesAvailable']is(c['arm']!='C')and got['result']==1
 if c['arm']=='C':assert got['fuelRemaining']==16777216 and got['arena17']==[0]*17 and got['finalUsed']==[0]*4
 return dict(timing=t,observables=got if c['arm']!='C'else dict(result=1,fuel=None,arena17=None),arena17=None if c['arm']=='C'else got['arena17'],result=1)
