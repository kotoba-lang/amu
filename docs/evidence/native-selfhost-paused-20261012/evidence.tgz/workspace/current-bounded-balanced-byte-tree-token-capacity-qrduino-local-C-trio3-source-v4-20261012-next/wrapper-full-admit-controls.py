"""Inert SOURCE fixtures replay full wrapper admit; not a root approval or real build."""
from pathlib import Path
import json,hashlib,copy,importlib.util
import run
D=Path(__file__).resolve().parent;p=run.source_scope();F=D.parent/(D.name+'-SOURCE-control-fixtures');F.mkdir(exist_ok=True)
def fixture(name,obj):
 q=F/name;q.write_text(json.dumps(obj,indent=2)+'\n');return dict(path=str(q),**run.receipt(q))
a={k:run.receipt(D/n)['sha256']for n,k in [('source-pins.json','sourcePinsSHA256'),('input-pins.json','inputPinsSHA256'),('run.py','driverSHA256'),('preregistration.json','preregistrationSHA256')]}
review=fixture('MOCK-SOURCE-REVIEW.json',dict(status=p['sourceReviewStatus'],**a,scope='SOURCE mock only'))
g=dict(status=p['rootGOStatus'],**a,sourceReviews=[review],maximumLoaderCalls=3,maximumClangBuildCalls=1,runtimeGuestAuthorized=True,timingAuthorized=True,diagnosticCBuildAuthorized=True,noRetry=True,outputRoot=p['freshOutputRoot']);gd=fixture('MOCK-SOURCE-GO.json',g);assert run.go_header(g,p)
spec=importlib.util.spec_from_file_location('whole_wrapper',D/'launch-wrapper.py');w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
consumerPath=str(Path(p['taskRoot'])/'consumer');buildPath=str(F/'MOCK-BUILD-LOGICAL.json')
consumer=dict(path=consumerPath,bytes=1,sha256=hashlib.sha256(b'X').hexdigest())
b=dict(returncode=0,consumer=consumer,argv=p['buildArgv'],rootGO=gd,rawWritersClosed=True)
bd=fixture('MOCK-BUILD-LOGICAL.json',b)
originalChecked=w.checked;originalLoad=run.load
def checked(path,v):
 if str(path)==consumerPath:
  assert v==consumer;return consumerPath  # logical mock artifact only; no output or guest created
 return originalChecked(path,v)
w.checked=checked
sp=run.load(D/'source-pins.json');positive=0;negative=0
try:
 for c in p['cases']:
  seal=dict(format=p['invocationSealVersion'],index=c['index'],case=c,consumer=consumer,buildReceipt=bd,rootGO=gd,sourcePinsSHA256=a['sourcePinsSHA256'],preregistrationSHA256=a['preregistrationSHA256'])
  assert w.runtime_case(c['nativeArgv'],p,c)and w.admit(c['nativeArgv'],p,seal,sp,'SOURCE-only-mock');positive+=1
  for k,v in [('calls',3),('warmup',2),('n',3),('arm','OTHER')]:
   bad=copy.deepcopy(c);bad[k]=v
   try:w.runtime_case(bad['nativeArgv'],p,bad)
   except AssertionError:negative+=1
   else:raise AssertionError('unregistered wrapper row admitted')
 assert positive==3 and negative==12
finally:w.checked=originalChecked;run.load=originalLoad
