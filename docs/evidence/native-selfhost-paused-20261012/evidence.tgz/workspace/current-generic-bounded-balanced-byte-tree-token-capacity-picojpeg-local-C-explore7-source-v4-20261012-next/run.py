"""Local one wrapper build plus7 held exploratory consumer starts; root-only GO."""
from pathlib import Path
import json,hashlib,stat,os,sys,time,subprocess,importlib.util
D=Path(__file__).resolve().parent
def need(v,m):
 if not v:raise AssertionError(m)

def load(p):return json.loads(Path(p).read_bytes())

def receipt(p):
 p=Path(p);s=p.lstat();need(stat.S_ISREG(s.st_mode)and not p.is_symlink()and s.st_size<=469762048,'bounded regular pin');b=p.read_bytes();s2=p.lstat();need((s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(s2.st_dev,s2.st_ino,s2.st_size,s2.st_mtime_ns),'immutable bytes');return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def pin(p,r):need(receipt(p)=={k:r[k]for k in ['bytes','sha256']},'exact pin:'+str(p));return Path(p)

def save(p,v):
 
 if Path(p).name=='attempts.json':need(all(len(json.dumps(r).encode())<=65536 for r in v),'bounded per-case metadata before publication')
 b=(json.dumps(v,indent=2)+'\n').encode();need(len(b)<=16777216,'bounded valid-last metadata');q=Path(str(p)+'.pending')
 with q.open('wb',buffering=0)as f:
  view=memoryview(b)
  while view:
   n=f.write(view);need(type(n)is int and 0<n<=len(view),'metadata write');view=view[n:]
  os.fsync(f.fileno())
 os.replace(q,p);fd=os.open(str(Path(p).parent),os.O_RDONLY)
 try:os.fsync(fd)
 finally:os.close(fd)

def descriptor(r):
 need(type(r)is dict and set(r)=={'path','bytes','sha256'},'exact descriptor');return pin(r['path'],r)

GO_KEYS={'status','sourcePinsSHA256','inputPinsSHA256','driverSHA256','preregistrationSHA256','sourceReviews','maximumLoaderCalls','maximumClangBuildCalls','runtimeGuestAuthorized','timingAuthorized','diagnosticCBuildAuthorized','noRetry','outputRoot'}
def go_header(g,p):
 need(set(g)==GO_KEYS and g['status']==p['rootGOStatus']and g['maximumLoaderCalls']==7 and g['maximumClangBuildCalls']==1 and g['runtimeGuestAuthorized']is True and g['timingAuthorized']is True and g['diagnosticCBuildAuthorized']is True and g['noRetry']is True and g['outputRoot']==p['freshOutputRoot'],'exact local1build7starts GO')
 for n,k in [('source-pins.json','sourcePinsSHA256'),('input-pins.json','inputPinsSHA256'),('run.py','driverSHA256'),('preregistration.json','preregistrationSHA256')]:need(receipt(D/n)['sha256']==g[k],'exact GO aliases')
 need(len(g['sourceReviews'])==1,'single root source review')
 q=load(descriptor(g['sourceReviews'][0]));need(q['status']==p['sourceReviewStatus']and all(q[k]==g[k]for k in ['sourcePinsSHA256','inputPinsSHA256','driverSHA256','preregistrationSHA256']),'root review exact aliases')
 return True
def semantic_call_admitted(r):
 if r['strictHeldSamplingPolicyPassed']is True:return True
 o=r['semanticControllerObservation'];c=o['capture'];m=o['memoryAdmissionRecord']
 need(c['semanticDecodeAuthorized']is True and c['completeRaw']is True and c['stoppedWriter']is True and m['completePipeEOF']is True and m['stoppedClosedCapture']is True and m['rawTruncated']is False and m['captureErrors']==[] and m['exactDirectChildWait']=='closed0'and m['waitUncertain']is False and m['withinOriginalDeadline']is True and m['groupAuthorityRetired']is True and m['groupOperationsAfterUncertainty']==m['groupOperationsAfterWait']==0,'existing complete owned semantic capture')
 from artifact_admission import accept_artifact_observation
 return accept_artifact_observation(o)

def current_lineage_guard(p,z):
 e=load(descriptor(p['generatedProducer']));need(e['rootGO']==z['rootGO']and e['exports']==[['main',0,0]]and len(e['admittedCalls'])==2,'new producer two actual calls');descriptor(e['rootGO']);descriptor(e['source']);packed=descriptor(e['container']).read_bytes();native=descriptor(e['native']).read_bytes();need(packed[packed.index(b'\n\n')+2:]==native,'whole producer')
 parser=descriptor(p['compilerParser']);spec=importlib.util.spec_from_file_location('saved_compiler_parser',parser);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 need(len(z['calls'])==4 and all(r['returncode']==0 and semantic_call_admitted(r)for r in z['calls']),'four semantic compiler artifacts')
 for r in z['calls']:
  c=r['case'];base=Path(p['new4Completion']['path']).parent/c['label'];out=Path(str(base)+'.stdout').read_bytes();err=Path(str(base)+'.stderr').read_bytes();need(hashlib.sha256(out).hexdigest()==r['rawStdoutSHA256']and hashlib.sha256(err).hexdigest()==r['rawStderrSHA256']and m.qualify(out,err,c)==r['report'],'whole stopped compiler raw')
 for i,r in enumerate(e['admittedCalls']):need(load(descriptor(r))==z['calls'][i],'own exact first two producer records')
 return True

def verify_current_native4_source(p,q,z):
 previousRuntime=sys.modules.get('runtime');rt=importlib.util.spec_from_file_location('runtime',descriptor(p['compilerParser']));rm=importlib.util.module_from_spec(rt);rt.loader.exec_module(rm);sys.modules['runtime']=rm
 driver=descriptor(p['native4SourceDriver']);spec=importlib.util.spec_from_file_location('native4_source',driver);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);pn=load(descriptor(p['native4Preregistration']));ip=m.load(m.D/'input-pins.json');need(m.source_scope(pn,ip),'actual current two-owner00+41 SOURCE and product baseline guards')
 need(pn['subjectSource']==p['subjectSource'] and pn['baselineImage']==q['row']['OFF']['native'] and pn['baselineContainer']==q['row']['OFF']['container'] and z['baselineImage']==pn['baselineImage'],'current adopted CFW0276 original whole PicoJPEG')
 need(pn['candidateUnity']==load(descriptor(p['generatedProducer']))['source'],'new compiler exact reviewed source')
 if previousRuntime is None:sys.modules.pop('runtime',None)
 else:sys.modules['runtime']=previousRuntime
 return True

def verify_screen_peers(p,policy):
 need(policy['status']=='ROOT_ALLOW_GENERIC_BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_PICOJPEG_SHORT7_V4' and policy['machineIndependentPeer']==p['machinePeer'] and policy['native4IndependentPeer']==p['stopped4Peer'],'exact BBT current policy peers')
 mp=load(descriptor(p['machinePeer']));sp=load(descriptor(p['stopped4Peer']));pn=load(descriptor(p['native4Preregistration']));z=load(descriptor(p['new4Completion']))
 need(mp['status']=='PASS_INDEPENDENT_SAVED_BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_MACHINE_V4' and mp['candidateFreeze']==policy['candidateFreeze']==pn['candidateFreeze'] and mp['rootClosure']==p['new4Closure'] and mp['native4Completion']==p['new4Completion'] and mp['machineActivation']==policy['mechanical']==p['structuralEvidence'] and mp['native4SavedPeer']==p['stopped4Peer'] and mp['timingEligible']is True and mp['semanticAuditPending']is False,'exact BBT independent source-machine-root joins')
 for key in ['actual14WordPureTreeTranslationVerified','sourcePoolPayload570Verified','allRetainedControlTargetsAndNonImmediateBitsVerified','allContainerPayloadAndExportsVerified','compilerCapacityPrerequisiteSeparatelyQualified','noFuelOrPublicationBatching']:need(mp[key]is True,'BBT semantic translation proof '+key)
 need(sp['status']=='PASS_INDEPENDENT_SAVED_BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_NATIVE4_V4' and sp['rootClosure']==p['new4Closure'] and sp['completion']==p['new4Completion'] and sp['closedCompilerCalls']==4 and sp['rawFilesReplayed']==8 and sp['actualSourceScopeGuardReplayed']is True and sp['strictOwnedSemanticCaptureVerified']is True and sp['subjectNative']==z['subjectImage'] and sp['subjectContainer']==z['subjectContainer'] and sp['baselineNative']==z['baselineImage'] and sp['baselineContainer']==z['baselineContainer'],'strict actual stopped4 peer')
 return True

def source_scope():
 for n,r in load(D/'source-pins.json').items():pin(D/n,r)
 for n,r in load(D/'input-pins.json').items():pin(n,r)
 p=load(D/'preregistration.json');q=load(descriptor(p['proposal']));need(q['metric']['schema']==p['metric']=='BATCH_ABI_RESET_VALIDATION_V1'and q['metric']['resetIncluded']is True,'exact metric source')
 need(receipt(D/'timing-packet-generated.h')=={k:q['generatedHeader'][k]for k in ['bytes','sha256']},'generated exact newheader')
 policy=load(descriptor(p['explorationPolicy']));verify_screen_peers(p,policy);need(policy['maximumRuntimeCalls']==7 and policy['functionalSmokes']==4 and policy['coarseTrio']==1 and policy['semanticAuditPending']is False and policy['timingEligible']is True and policy['optimizationQualified']is False and policy['performanceQualified']is False and policy['adoptionAuthorizedByThisPacket']is False and policy['noPrecisionRepeats']is True and policy['noRetry']is True and policy['mechanical']==p['structuralEvidence']and load(descriptor(policy['machineIndependentPeer']))['rootClosure']==p['new4Closure'],'explicit finite provisional screen policy');[descriptor(policy[k])for k in ['candidateFreeze','machineIndependentPeer','native4IndependentPeer','mechanical']];need(descriptor(p['activationCopy']).read_bytes()==descriptor(p['structuralEvidence']).read_bytes(),'exact copied producer activation bytes')
 v=load(descriptor(p['structuralEvidence']));a=load(descriptor(p['new4Closure']));z=load(descriptor(p['new4Completion']));need(a['exit_code']==0 and a['status']==p['new4RequiredStatus'] and a['report']==p['new4Completion'] and a['wholeRawFilesReplayed']==8 and a['terminal']==dict(childCalls=4,allChildrenClosed=True,failure=False) and z['closedCompilerCalls']==4 and v['newNative']==q['row']['ON']['native']==z['subjectImage'] and q['row']['OFF']['native']==z['baselineImage'],'strict stopped combined native4')
 verify_current_native4_source(p,q,z)
 for arm in ['OFF','ON']:
  packed=descriptor(q['row'][arm]['container']).read_bytes();body=packed[packed.index(b'\n\n')+2:];need(body==descriptor(q['row'][arm]['native']).read_bytes(),'whole selected native');lines=packed[:packed.index(b'\n\n')].splitlines()[1:];need((b'bench '+str(q['row'][arm]['offset']).encode()+b' 1')in lines,'own batch export')
 c=load(descriptor(q['CProof']));need(c['workload']=='picojpeg'and c['symbol']=='bench'and c['savedCopy']==q['CSavedCopy'],'exact original C owner/bridge');descriptor(q['CSavedCopy'])
 need(len(p['cases'])==p['maximumLoaderCalls']==7 and [(x['phase'],x['arm'],x['n'],x['calls'])for x in p['cases']]==[(phase,arm,n,calls)for phase,n,calls,arms in [('smoke1',1,2,['OFF','ON']),('smoke32',32,2,['OFF','ON']),('timing1',32,64,['C','OFF','ON'])]for arm in arms],'finite exact schedule')
 return p
def build(go,p,gd):
 root=Path(p['taskRoot']);root.mkdir();proposal=load(p['proposal']['path']);I=root/'inputs/picojpeg';I.mkdir(parents=True)
 for arm in ['OFF','ON']:(I/(arm+'.bin')).write_bytes(descriptor(proposal['row'][arm]['native']).read_bytes())
 (I/'C.dylib').write_bytes(descriptor(proposal['CSavedCopy']).read_bytes());O=Path(p['freshOutputRoot']);proc=None;rc=None;uncertain=False
 with (O/'build.stdout').open('xb',buffering=0)as out,(O/'build.stderr').open('xb',buffering=0)as err:
  try:
   proc=subprocess.Popen([p['interpreter']['path'],'-B',str(D/'build-limit.py'),str(go)],cwd=root,env=p['buildEnvironment'],stdin=subprocess.DEVNULL,stdout=out,stderr=err,close_fds=True,start_new_session=True)
   save(O/'build-started.json',dict(pid=proc.pid,argv=p['buildArgv'],rootGO=gd));deadline=time.monotonic()+180
   while proc.poll()is None:
    need(time.monotonic()<deadline,'build180 deadline');need(out.tell()<=1048576 and err.tell()<=1048576,'build raw1MiB');time.sleep(.01)
   try:rc=proc.wait(timeout=30)
   except BaseException:uncertain=True;raise
  finally:
   if proc is not None and rc is None and not uncertain:
    try:
     if proc.poll()is None:proc.kill()
     rc=proc.wait(timeout=30)
    except BaseException:uncertain=True
   os.fsync(out.fileno());os.fsync(err.fileno())
 need(not uncertain and rc==0,'known compiler stopped0; no retry');need((O/'build.stdout').stat().st_size<=1048576 and (O/'build.stderr').stat().st_size<=1048576,'bounded stopped raw')
 consumer=dict(path=str(root/'consumer'),**receipt(root/'consumer'));need(consumer['bytes']<=4194304,'bounded wrapper');save(O/'build-receipt.json',dict(argv=p['buildArgv'],returncode=rc,rootGO=gd,consumer=consumer,rawWritersClosed=True,sourcePinsSHA256=receipt(D/'source-pins.json')['sha256'],stdout=receipt(O/'build.stdout'),stderr=receipt(O/'build.stderr'),compilerDescendantClosure='trusted normal clang completion only'))
 return consumer,dict(path=str(O/'build-receipt.json'),**receipt(O/'build-receipt.json'))
def main(go):
 p=source_scope();g=load(go);go_header(g,p);gd=dict(path=str(Path(go).resolve()),**receipt(Path(go)));O=Path(p['freshOutputRoot']);O.mkdir(exist_ok=False);rows=[];results=[];failure=None;consumer=None;deadline=time.monotonic()+p['maximumCampaignSeconds']
 try:
  need(time.monotonic()+210<=deadline,'build reserve180+30');consumer,br=build(Path(go).resolve(),p,gd);source_scope();spec=importlib.util.spec_from_file_location('local_consumer_call',D/'native-call.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
  for i,c in enumerate(p['cases'],1):
   need(time.monotonic()+60<=deadline,'call reserve30+30');pin(gd['path'],gd)
   for n,v in load(D/'source-pins.json').items():pin(D/n,v)
   seal=dict(format=p['invocationSealVersion'],index=i,case=c,consumer=consumer,buildReceipt=br,rootGO=gd,sourcePinsSHA256=g['sourcePinsSHA256'],preregistrationSHA256=g['preregistrationSHA256']);f=O/(c['label']+'.admission.json');save(f,seal);need(f.stat().st_size<=4096,'seal bound');r=m.call(D,O,p,c,rows,save,receipt(f)['sha256']);need(semantic_call_admitted(r),'strict or exact existing semantic termination gap; memory separately retained')
   if c['phase'].startswith('timing'):need(r['report']['timing']['elapsedNs']>0,'positive exploratory clock')
   results.append(r);save(O/(c['label']+'.result.json'),r)
   if i in [2,4,7]:
    group=results[-(3 if i==7 else 2):];arms={x['case']['arm']:x for x in group};need(arms['OFF']['report']['observables']==arms['ON']['report']['observables'],'exact native fullreport/fuel17')
    if i==7:need(arms['C']['report']['result']==arms['ON']['report']['result']==1,'C result parity; native counters unavailable')
 except BaseException as e:failure=repr(e)
 save(O/'terminal.json',dict(starts=len(rows),closedCalls=len(results),allChildrenClosed=all(x['state']=='terminal'for x in rows),failure=failure,noRetry=True))
 measured=[dict(arm=r['case']['arm'],calls=r['case']['calls'],n=r['case']['n'],elapsedNs=r['report']['timing']['elapsedNs'],nsPerBody=r['report']['timing']['elapsedNs']/(r['case']['calls']*r['case']['n']))for r in results if r['case']['phase'].startswith('timing')]
 save(O/'report.json',dict(status='COMPLETE_LOCAL_GENERIC_BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_PICOJPEG_C_EXPLORATION_ONLY'if failure is None and len(results)==7 else'REFUSE_LOCAL_GENERIC_BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_PICOJPEG_C_EXPLORATION',semanticAuditPending=False,timingEligible=True,optimizationQualified=False,adoptionAuthorized=False,verdict="PROVISIONAL_SCREEN",results=results,measured=measured,consumer=consumer,failure=failure,metric=p['metric'],resetIncluded=True,pureKernelClock=False,officialCScore=False,full19Qualified=False,performanceQualified=False,physicalMemorySamplingQualified=False,importedCompileMemoryQualified=False))
 return 0 if failure is None and len(results)==7 else 78
if __name__=='__main__':sys.exit(main(sys.argv[1]))
