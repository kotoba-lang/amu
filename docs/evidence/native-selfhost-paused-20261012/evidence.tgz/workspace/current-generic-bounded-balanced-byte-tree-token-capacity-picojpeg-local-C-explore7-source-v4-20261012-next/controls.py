"""SOURCE-only finite schedule/consumer parser/native first-guard checks; no Popen."""
from pathlib import Path
import ast,importlib.util,json,copy
import run,runtime
from qualification import COUNTERS
D=Path(__file__).resolve().parent;p=run.source_scope();ref=0
for f in D.glob('*.py'):ast.parse(f.read_text())
t=ast.parse((D/'native-call.py').read_text());first=next(x for x in t.body if isinstance(x,ast.FunctionDef)and x.name=='call').body[0];guard=compile(ast.Expression(first.value.args[0]),str(D/'native-call.py'),'eval')
s=importlib.util.spec_from_file_location('consumer_wrapper',D/'launch-wrapper.py');w=importlib.util.module_from_spec(s);s.loader.exec_module(w)
for i,c in enumerate(p['cases']):
 assert eval(guard,{},dict(pr=p,case=c,rows=[None]*i));w.runtime_case(c['nativeArgv'],p,c)
 arena=[0]*17
 if c['arm']!='C':arena[2]=1;arena[3]=3309;arena[4]=16+3309*8
 raw=('{:status :ok :result 1 :fuel {:initial 16777216 :remaining '+str(16777216 if c['arm']=='C'else 16776216)+'} :heap {:capacity 2097152 :used 0} :string-pool {:capacity 65536 :used 0} :vectors {:capacity 4096 :used '+str(arena[2])+'} :vector-items {:capacity 65536 :used '+str(arena[3])+'}}\n').encode()
 timing=dict(schema='BATCH_ABI_RESET_VALIDATION_V1',arm=['OFF','ON','C'].index(c['arm']),calls=c['calls'],warmup=1,elapsedNs=123456,resetIncluded=True,nativeObservablesAvailable=c['arm']!='C');out=raw+(json.dumps(timing)+'\n').encode();err=('KEXE_ARENA_USE {'+' '.join(':'+k+' '+str(v)for k,v in zip(COUNTERS,arena))+'}\n').encode();q=runtime.qualify(out,err,c);assert q['result']==1
 for key,v in [('calls',c['calls']+1),('resetIncluded',False),('nativeObservablesAvailable',c['arm']=='C')]:
  b=dict(timing,**{key:v})
  try:runtime.qualify(raw+(json.dumps(b)+'\n').encode(),err,c)
  except AssertionError:ref+=1
  else:raise AssertionError('wrong metric/mode admitted')
for rows,c in [([None]*7,p['cases'][0]),([],p['cases'][-1])]:assert not eval(guard,{},dict(pr=p,case=c,rows=rows));ref+=1
# Deterministic guards from the actual compiled frontend; loader/OS admission remains runtime.
import re
q=run.load(run.descriptor(p['proposal']));header=(D/'timing-packet-generated.h').read_text();front=(D/'timing-frontend.h').read_text();driver=(D/'run.py').read_text()
assert '#define TIMING_MAX_N 32ULL' in header
assert 'if(argc!=5)return 2;' in front and 'timing_warmup!=1' in front
assert p['environment']['KEXE_ARENA_USE']=='1' and p['environment']['KEXE_STRUCTURED_REPORT']=='1'
assert "I=root/'inputs/picojpeg'" in driver
for arm in ['OFF','ON']:
 raw=run.descriptor(q['row'][arm]['native']).read_bytes()
 m=re.search(r'static const unsigned char timing_'+arm.lower()+r'\[\]=\{([^}]+)\}',header);assert m and bytes(map(int,m.group(1).split(',')))==raw
 assert 'inputs/picojpeg/'+arm+'.bin' in header
assert 'inputs/picojpeg/C.dylib' in header
for c in p['cases']:
 a=c['nativeArgv'];assert len(a)==5 and a[1]==c['arm'] and a[2]==str(c['n']) and a[3]==str(c['calls']) and a[4]=='1'
 assert c['arm'] in ['OFF','ON','C'] and c['n']in [1,32] and c['calls']in [2,64]

import runpy
full=runpy.run_path(str(D/'wrapper-full-admit-controls.py'))
assert full['positive']==7 and full['negative']==28
print(json.dumps(dict(status='PASS_SOURCE_ONLY_LOCAL_C_CONTROLS',schedule7=7,wrapperFullAdmitRows=7,wrapperWrongRows=28,explicitSourceMockOnly=True,rawModels=7,refusals=ref,nativeOperations=0)))
