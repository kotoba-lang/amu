from pathlib import Path
import sys,json,copy
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D));import run
p=run.load(D/'preregistration.json');ip=run.load(D/'input-pins.json');assert run.source_scope(p,ip)
refused=0
for i,c in enumerate(p['cases']):
 assert run.compiler_case(c['nativeArgv'],p,c)
 for key,val in [('index',99),('producerRef','wrong')]:
  q=copy.deepcopy(p);q['cases'][i][key]=val
  try:run.compiler_case(q['cases'][i]['nativeArgv'],q,q['cases'][i])
  except AssertionError:refused+=1
  else:raise AssertionError('case mismatch accepted')
assert refused==12
print(json.dumps({'sourcePrerequisites':True,'cases':6,'refusals':refused,'generatedFutureProducers':'Not fabricated; require own admitted prior2 at runtime','nativeOperations':0}))
