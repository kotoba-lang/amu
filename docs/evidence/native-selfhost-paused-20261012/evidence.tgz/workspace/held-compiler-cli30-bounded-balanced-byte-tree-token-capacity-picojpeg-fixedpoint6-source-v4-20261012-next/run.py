from pathlib import Path

import json,hashlib,stat,re,os,importlib.util,time

D=Path(__file__).resolve().parent

def need(v,m):
 if not v:raise AssertionError(m)

def load(p):return json.loads(Path(p).read_bytes())

def receipt(p):
 p=Path(p);a=p.lstat();need(stat.S_ISREG(a.st_mode)and not p.is_symlink()and a.st_size<=33554432,'bounded regular');b=p.read_bytes();z=p.lstat();need((a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns),'stable bytes');return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def pin(p,r):need(receipt(p)=={k:r[k]for k in ['bytes','sha256']},'exact pin');return Path(p)

def save(p,v):
 b=(json.dumps(v,indent=2)+'\n').encode();need(len(b)<=8388608,'bounded metadata');q=Path(str(p)+'.pending')
 with q.open('xb',buffering=0)as f:
  view=memoryview(b)
  while view:n=f.write(view);need(type(n)is int and 0<n<=len(view),'short write');view=view[n:]
  os.fsync(f.fileno())
 os.replace(q,p)

def container(raw):
 m=re.match(rb'KSEED1 ([1-9][0-9]{0,9}) ([1-9][0-9]{0,2})\n',raw);need(m is not None and len(raw)<=4194560,'container header');cut=raw.find(b'\n\n',m.end());need(cut>=m.end(),'separator');e=[]
 for line in raw[m.end():cut].splitlines():
  q=re.fullmatch(rb'([A-Za-z0-9_-]+) ([0-9]{1,10}) ([0-9]{1,2})',line);need(q is not None,'export');e.append((q[1].decode(),int(q[2]),int(q[3])))
 b=raw[cut+2:];need(len(e)==int(m[2])and len(set(x[0]for x in e))==len(e)and len(b)==int(m[1])and 0<len(b)<=4194304 and all(x[1]%4==0 and x[1]+4<=len(b)and x[2]<=32 for x in e),'whole payload exports');return b,e

def native_transport_guard(p):
 import ast
 required=set()
 for name in ['native-call.py','launch-wrapper.py']:
  tree=ast.parse((D/name).read_text())
  required.update(n.slice.value for n in ast.walk(tree) if isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name) and n.value.id=='pr' and isinstance(n.slice,ast.Constant) and isinstance(n.slice.value,str))
 need(required<=set(p),'native/wrapper literal preregistration keys missing: '+repr(sorted(required-set(p))))
 expected={'path': '/opt/homebrew/Cellar/python@3.14/3.14.6/Frameworks/Python.framework/Versions/3.14/bin/python3.14', 'bytes': 52448, 'sha256': 'b502cb4c5b46b8d4192ec6bcb600ce8922f1afc396fcf646e8765c6eba74a0bf'}
 need(type(p['interpreter'])is dict and p['interpreter']==expected,'exact qualified transport interpreter')
 pin(expected['path'],expected)
 return sorted(required)

def native_call_cap_guard(p):
 import ast
 f=next(v for v in ast.parse((D/'native-call.py').read_text()).body if isinstance(v,ast.FunctionDef)and v.name=='call');first=f.body[0]
 expected="type(pr['maximumLoaderCalls']) is int and pr['maximumLoaderCalls']==len(pr['cases']) and len(rows)<pr['maximumLoaderCalls'] and pr['cases'][len(rows)]==case"
 need(isinstance(first,ast.Expr)and isinstance(first.value,ast.Call)and isinstance(first.value.func,ast.Name)and first.value.func.id=='need','actual first call admission')
 need(ast.dump(first.value.args[0])==ast.dump(ast.parse(expected,mode='eval').body),'registered count and ordered admission before API')
 need(type(p['maximumLoaderCalls'])is int and p['maximumLoaderCalls']==len(p['cases'])==6,'registered exact four')
 return True

def go_header(g,p,O):
 keys={'status','maximumLoaderCalls','outputRoot','noRetry','timingAuthorized','runtimeGuestAuthorized','compilerGuestAuthorized','C2','outerHostLaunchRequiresEscalation','sourcePinsSHA256','inputPinsSHA256','preregistrationSHA256','driverSHA256','sourceReviews','loaderBuildProof','main1ActualProof'}
 need(set(g)==keys and g['status']==p['rootGOStatus']and g['maximumLoaderCalls']==6 and g['outputRoot']==str(O)and g['noRetry']is True and g['timingAuthorized']is False and g['runtimeGuestAuthorized']is False and g['compilerGuestAuthorized']is True and g['C2']is False and g['outerHostLaunchRequiresEscalation']is True and g['main1ActualProof']==p['main1ActualProof'],'exact four compiler only GO');return True

def semantic_call_admitted(r):
 if r['strictHeldSamplingPolicyPassed']is True:return True
 o=r['semanticControllerObservation'];c=o['capture'];m=o['memoryAdmissionRecord']
 need(c['semanticDecodeAuthorized']is True and c['completeRaw']is True and c['stoppedWriter']is True and m['completePipeEOF']is True and m['stoppedClosedCapture']is True and m['rawTruncated']is False and m['captureErrors']==[] and m['exactDirectChildWait']=='closed0'and m['waitUncertain']is False and m['withinOriginalDeadline']is True and m['groupAuthorityRetired']is True and m['groupOperationsAfterUncertainty']==m['groupOperationsAfterWait']==0,'existing complete owned semantic capture')
 from artifact_admission import accept_artifact_observation
 return accept_artifact_observation(o)

def candidate_producer_guard(p,rootGO=None,role='candidate'):
 need(role=='candidate','initial compiler');cl=load(pin(p['acceptedRootClosure']['path'],p['acceptedRootClosure']));r=load(pin(p['acceptedCompletion']['path'],p['acceptedCompletion']));need(cl['status']=='closed' and cl['exit_code']==0 and cl['report']==p['acceptedCompletion'] and cl['terminal']==dict(childCalls=4,allChildrenClosed=True,failure=False) and r['closedCompilerCalls']==4 and r['candidateProducer']==p['acceptedProducer'],'actual closed native4')
 nd=Path(p['acceptedRegistration']['path']).parent;pin(p['acceptedDriver']['path'],p['acceptedDriver']);pin(p['acceptedSourcePins']['path'],p['acceptedSourcePins']);pin(p['acceptedInputPins']['path'],p['acceptedInputPins']);np=load(pin(p['acceptedRegistration']['path'],p['acceptedRegistration']));spec=importlib.util.spec_from_file_location('accepted_native4_driver',p['acceptedDriver']['path']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 need(m.source_scope(np,load(nd/'input-pins.json')),'same actual native4 SOURCE guards');q=load(pin(p['acceptedProducer']['path'],p['acceptedProducer']));m.candidate_producer_guard(np,q['rootGO']);need(q['source']==p['candidateUnity'] and q['native']==p['acceptedCompiler'] and q['container']==p['acceptedCompilerContainer'],'current combined BBT plus capacity generated compiler custody')
 return q


def compiler_case(argv,p,c):
 need(len(p['cases'])==6 and c in p['cases'],'exact four cases')
 O=Path(p['freshOutputRoot']);i=p['cases'].index(c)
 schedule=[('G2-compile', 'compile', 'main', 0, 'candidate.kotoba', 'G2.kseed', 'candidate', False), ('G2-extract', 'extract', 'main', 0, 'G2.kseed', 'G2.bin', 'G4extractor', False), ('G3-compile', 'compile', 'main', 0, 'candidate.kotoba', 'G3.kseed', 'G2', False), ('G3-extract', 'extract', 'main', 0, 'G3.kseed', 'G3.bin', 'G4extractor', False), ('G4-compile', 'compile', 'main', 0, 'candidate.kotoba', 'G4.kseed', 'G3', False), ('G4-extract', 'extract', 'main', 0, 'G4.kseed', 'G4.bin', 'G4extractor', False)]
 label,kind,sym,arity,inp,out,prod,snap=schedule[i]
 need(type(c['index'])is int and c['index']==i+1 and c['label']==label and c['kind']==kind and c['symbol']==sym and type(c['arity'])is int and c['arity']==arity and c['producerRef']==prod and c['snapshot']is snap and c['telemetry']is False,'exact observer4 stage roles')
 source=str(O/inp);dest=str(O/out);producer=p['acceptedCompiler']['path']if prod=='candidate'else p['currentCompiler']['path']if prod=='G4extractor'else str(O/(prod+'.bin'))
 args=['compile',source,'--target','aarch64-macos','--output',dest]if kind=='compile'else['extract-native',source,'--symbol',sym,'--output',dest]
 expected={'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','HOME':'/Users/junkawasaki','TMPDIR':str(O),'LANG':'C','LC_ALL':'C','TZ':'UTC','KEXE_STRING_POOL':'268435456','KEXE_VECTORS':'4194304','KEXE_PAIRS':'16777216','KEXE_VECTOR_ITEMS':'134217728','KEXE_CPU_SECONDS':'30','KEXE_WALL_SECONDS':'30','KEXE_FUEL':'off','KEXE_ARENA_USE':'1','PYTHONNOUSERSITE':'1','KEXE_CAP_RESOURCES_35':str(O),'KEXE_COMMAND':'1'};need(p['environment']==expected,'exact compiler17')
 need(c['inputPath']==source and c['outputPath']==dest and argv==c['nativeArgv']==[p['loader'],producer,'0','0','aarch64','35,37,38,39','--',*args],'exact compiler CLI')
 return True
def loader_symbol_guard(p,c):
 text=pin(p['candidateC']['path'],p['candidateC']).read_text()
 exact='(!strcmp(kexe_guest_argv[3], "bench") || !strcmp(kexe_guest_argv[3], "batch") || !strcmp(kexe_guest_argv[3], "main"))'
 need(text.count(exact)==1,'actual frozen CLI30 extract enumeration')
 need(c['kind']!='extract' or c['symbol']in ('bench','batch','main'),'loader accepted extract symbol')
 return True

def diagnostic_loader(g,p):
 q=load(pin(p['loaderBuildProof']['path'],p['loaderBuildProof']));need(q['status']==p['loaderBuildProofRequiredStatus']and q['artifact']==p['loaderArtifact']and q['copiedCSource']==p['candidateC'],'existing diagnostic loader identity');pin(p['loader'],p['loaderArtifact']);pin(p['main1ActualProof']['path'],p['main1ActualProof']);return True

def generated_producer_guard(p,role,rootGO):
 need(role in ('G2','G3'),'earlier generation only');O=Path(p['freshOutputRoot']);at=0 if role=='G2'else 2;e=load(O/(role+'-producer.json'))
 need(set(e)=={'format','rootGO','sourcePinsSHA256','preregistrationSHA256','source','container','native','exports','admittedCalls','qualificationScope','noRetry'},'generated exactschema')
 need(e['format']=='BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_PICOJPEG_FIXEDPOINT6_GENERATED_PRODUCER_V1'and e['rootGO']==rootGO and e['sourcePinsSHA256']==receipt(D/'source-pins.json')['sha256']and e['preregistrationSHA256']==receipt(D/'preregistration.json')['sha256']and e['source']==p['candidateUnity']and e['noRetry']is True and e['qualificationScope']=='TWO_CURRENT_GO_ADMITTED_COMPILER_CALLS_ONLY','current generation seal')
 need(e['native']['path']==str(O/(role+'.bin'))and e['container']['path']==str(O/(role+'.kseed'))and e['exports']==[['main',0,0]]and len(e['admittedCalls'])==2,'ownmain0')
 body,exports=container(pin(e['container']['path'],e['container']).read_bytes());need(body==pin(e['native']['path'],e['native']).read_bytes()and exports==[('main',0,0)],'whole generation')
 from runtime import qualify
 for k,r in enumerate(e['admittedCalls']):
  c=p['cases'][at+k];need(r['path']==str(O/(c['label']+'.result.json')),'exact prior2');x=load(pin(r['path'],r));need(x['label']==c['label']and x['case']==c and x['returncode']==0 and semantic_call_admitted(x),'prior strict2');base=O/c['label'];out=Path(str(base)+'.stdout').read_bytes();err=Path(str(base)+'.stderr').read_bytes();need(hashlib.sha256(out).hexdigest()==x['rawStdoutSHA256']and hashlib.sha256(err).hexdigest()==x['rawStderrSHA256']and qualify(out,err,c)==x['report'],'whole prior raw')
 if role=='G3':generated_producer_guard(p,'G2',rootGO)
 return e

def case_producer(p,c,rootGO):
 if c['producerRef']=='G4extractor':return p['currentCompiler'],p['currentCompilerContainer']
 if c['producerRef']=='candidate':need(c['index']==1,'initialcompile');e=candidate_producer_guard(p)
 else:need(c['producerRef']in ('G2','G3')and c['index']in (3,5),'two later compiles');e=generated_producer_guard(p,c['producerRef'],rootGO)
 return e['native'],e['container']

def off_producer_guard(p):
 return candidate_producer_guard(p)

def source_scope(p,ip):
 native_transport_guard(p);native_call_cap_guard(p);diagnostic_loader(None,p);candidate_producer_guard(p)
 policy=load(pin(p['qualificationPolicy']['path'],p['qualificationPolicy']));d=load(pin(p['positiveScreenDecision']['path'],p['positiveScreenDecision']));cl=load(pin(p['positiveScreenClosure']['path'],p['positiveScreenClosure']))
 need(policy['qualificationAuthorized'] is True and policy['adoptionAuthorizedByThisPacket'] is False and policy['candidate']==p['candidateFreeze'] and policy['maximumCompilerCalls']==6 and policy['maximumOriginal19CompilerCalls']==38 and policy['currentShort7']==p['positiveScreenClosure'] and not policy['newTimingAuthorized'] and policy['decision']==p['positiveScreenDecision'] and policy['parentCommit']==p['parentCommit'] and policy['precisionRepeats']==0 and policy['confirmedRuntimeGain']is False,'current positive qualification policy only')
 need(policy['short7Peer']==p['short7IndependentPeer'] and policy['parentAdoption']==p['parentAdoption'] and policy['sourceReview']==p['candidateSourceReviews'][0] and policy['sourcePeer']==p['candidateSourceReviews'][1],'exact policy current source/parent/peer')
 need(d['status']=='PROVISIONAL_KEEP_SMALL_GAIN' and d['improvementPercent']>0 and d['rootClosure']==p['positiveScreenClosure'] and d['thresholdPercent']is None and d['precisionRepeats']==0 and not d['confirmedRuntimeGain'] and cl['exit_code']==0 and cl['terminal']==dict(starts=7,closedCalls=7,allChildrenClosed=True,failure=None,noRetry=True) and cl['wholeRawFilesReplayed']==14 and cl['allOFFONObservablesEqual'],'actual positive current single-point screen')
 peer=load(pin(p['short7IndependentPeer']['path'],p['short7IndependentPeer']));sf=load(pin(peer['sourceFreeze']['path'],peer['sourceFreeze']));sr=load(pin(sf['preregistration']['path'],sf['preregistration']));need(peer['status']=='PASS_INDEPENDENT_SAVED_BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_SHORT7_V4' and peer['rootClosure']==p['positiveScreenClosure'] and peer['decision']==p['positiveScreenDecision'] and peer['sourceScopeGuardReplayed']is True and sr['native4Preregistration']==p['acceptedRegistration'],'same current candidate saved7 peer via exact stopped-native4 registration')
 need(not p['structuralPrerequisiteOnly'] and not p['performanceQualified'] and not p['adoptionAuthorized'] and len(p['cases'])==6 and p['maximumLoaderCalls']==6 and p['noRetry'] and p['timingAuthorized'] is False,'finite six compile/extract qualification only')
 for c in p['cases']:compiler_case(c['nativeArgv'],p,c)
 f=load(pin(p['candidateFreeze']['path'],p['candidateFreeze']));need(f['candidate']==p['candidate41'] and f['candidate00']==p['candidate00'] and f['unity']==p['candidateUnity'] and f['full16InverseExact'] and f['other14ByteExact'] and not f['effectiveTokenCapacityFitClaim'],'exact combined two-owner source, no raw-fit claim')
 a=load(pin(p['candidateAssembly']['path'],p['candidateAssembly']));need(len(a['modulePins'])==16 and b''.join(pin(x['path'],x).read_bytes()+b'\n' for x in a['modulePins'])==pin(p['candidateUnity']['path'],p['candidateUnity']).read_bytes(),'full16 source')
 need(p['materializations']==[dict(source=p['candidateUnity'],destination=str(Path(p['freshOutputRoot'])/'candidate.kotoba'))],'one exact source copy')
 for name,x in ip.items():pin(name,x)
 return True

def main(goPath):
 p=load(D/'preregistration.json');sp=load(D/'source-pins.json');ip=load(D/'input-pins.json');gp=Path(goPath);g=load(gp);gr=receipt(gp);rootGO=dict(path=str(gp),**gr);O=Path(p['freshOutputRoot']);go_header(g,p,O);rows=[];results=[];generated={};ok=False
 for n,k in [('source-pins.json','sourcePinsSHA256'),('input-pins.json','inputPinsSHA256'),('preregistration.json','preregistrationSHA256'),('run.py','driverSHA256')]:need(receipt(D/n)['sha256']==g[k],'GO binding')
 need(g['loaderBuildProof']==p['loaderBuildProof']and len(g['sourceReviews'])==1,'one concise root runner SOURCE review')
 for r in g['sourceReviews']:
  q=load(pin(r['path'],r));need(q['status']==p['sourceReviewStatus']and all(q[k]==g[k]for k in ['sourcePinsSHA256','inputPinsSHA256','preregistrationSHA256','driverSHA256']),'reviewed runner identities')
 def guard():
  need(receipt(gp)==gr,'immutableGO')
  for n,r in sp.items():pin(D/n,r)
  for n,r in generated.items():pin(n,r)
  source_scope(p,ip)
 guard();need(not O.exists(),'fresh output');O.mkdir();deadline=time.monotonic()+480
 def artifact(path):
  r=dict(path=str(path),**receipt(path));generated[str(path)]={k:r[k]for k in ['bytes','sha256']};save(O/'generated-pins.json',generated);return r
 spec=importlib.util.spec_from_file_location('held_call',D/'native-call.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 try:
  for m in p['materializations']:
   dest=Path(m['destination']);need(dest.parent==O and not dest.exists(),'fresh copy');dest.write_bytes(pin(m['source']['path'],m['source']).read_bytes());dest.chmod(0o444);artifact(dest)
  for index,c in enumerate(p['cases'],1):
   guard();need(time.monotonic()+60<=deadline,'reserve30+cleanup30');need(not Path(c['outputPath']).exists(),'fresh output');prod,packed=case_producer(p,c,rootGO)
   seal=dict(format=p['invocationSealVersion'],index=index,label=c['label'],nativeArgv=c['nativeArgv'],producer=prod,producerContainer=packed,input=dict(path=c['inputPath'],**receipt(c['inputPath'])),outputPath=c['outputPath'],rootGO=rootGO,sourcePinsSHA256=g['sourcePinsSHA256'],preregistrationSHA256=g['preregistrationSHA256']);se=O/(c['label']+'.admission.json');save(se,seal);need(se.stat().st_size<=4096,'seal');se.chmod(0o444);sr=artifact(se)
   r=mod.call(D,O,p,c,rows,save,sr['sha256']);need(semantic_call_admitted(r),'semantic held compiler policy; memory separate');out=artifact(Path(c['outputPath']));results.append(r)
   if c['kind']=='compile':need(r['report']['containerBytes']==out['bytes'],'compile length');container(Path(c['outputPath']).read_bytes())
   else:
    b,x=container(Path(c['inputPath']).read_bytes());need(b==Path(c['outputPath']).read_bytes(),'whole extraction');entry=next(v for v in x if v[0]==c['symbol']);need(r['report']['nativeBytes']==len(b)and r['report']['offset']==entry[1]and r['report']['arity']==entry[2]==c['arity'],'own export')
   for key,suffix in [('stdout','stdout'),('stderr','stderr'),('limitJournal','limit-journal.jsonl'),('memoryJournal','memory-journal.jsonl'),('ownershipJournal','ownership-journal.jsonl')]:
    path=O/(c['label']+'.'+suffix);need(receipt(path)=={k:rows[-1][key][k]for k in ['bytes','sha256']},'stopped evidence');artifact(path)
   rp=O/(c['label']+'.result.json');save(rp,r);rp.chmod(0o444);artifact(rp);save(O/'results.json',results)

   if index%2==0:
    role=['G2','G3','G4'][index//2-1];body,exports=container((O/(role+'.kseed')).read_bytes());need(body==(O/(role+'.bin')).read_bytes()and exports==[('main',0,0)],'generation wholemain0')
    e=dict(format='BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_PICOJPEG_FIXEDPOINT6_GENERATED_PRODUCER_V1',rootGO=rootGO,sourcePinsSHA256=g['sourcePinsSHA256'],preregistrationSHA256=g['preregistrationSHA256'],source=p['candidateUnity'],container=artifact(O/(role+'.kseed')),native=artifact(O/(role+'.bin')),exports=[['main',0,0]],admittedCalls=[artifact(O/(z['label']+'.result.json'))for z in p['cases'][index-2:index]],qualificationScope='TWO_CURRENT_GO_ADMITTED_COMPILER_CALLS_ONLY',noRetry=True);save(O/(role+'-producer.json'),e);artifact(O/(role+'-producer.json'))

  guard();ok=True
 except BaseException as ex:save(O/'failure.json',dict(error=repr(ex),noRetry=True));raise
 finally:save(O/'terminal.json',dict(childCalls=len(rows),allChildrenClosed=all(r['state']=='terminal'and r['returncode']==0 for r in rows),failure=not ok))
 need(ok and len(rows)==6,'complete six');guard();need(len({(O/(r+'.bin')).read_bytes()for r in ['G2','G3','G4']})==1 and len({(O/(r+'.kseed')).read_bytes()for r in ['G2','G3','G4']})==1,'whole G2G3G4 fixedpoint');save(O/'report.json',dict(status='COMPLETE_HELD_COMPILER_BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_PICOJPEG_FIXEDPOINT6_ARTIFACTS_ONLY',calls=results,closedCompilerCalls=6,rootGO=rootGO,wholeGenerations={r:dict(native=artifact(O/(r+'.bin')),container=artifact(O/(r+'.kseed')),producer=artifact(O/(r+'-producer.json')))for r in ['G2','G3','G4']},sourceCandidate=p['candidateUnity'],G1EqualityRequired=False,wholeG2G3G4Equal=True,benchmarkGuestCalls=0,optimizationQualified=False,performanceQualified=False,noRetry=True))
if __name__=='__main__':
 import sys
 need(len(sys.argv)==2,'one exactGO');main(sys.argv[1])
