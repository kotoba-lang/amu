from pathlib import Path
import json,hashlib,subprocess,importlib.util,sys
A=Path('/Users/junkawasaki/github/wt/codex/amu-sx-native-adoption-20261010');W=Path('/Users/junkawasaki/github/workspaces/codex');AD=W/'current-bounded-balanced-byte-tree-token-capacity-adoption-root-v4-20261012/report.json'
def descriptor(p):
 b=Path(p).read_bytes();return dict(path=str(Path(p)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checked(r):
 assert set(r)in [{'path','bytes','sha256'},{'module','path','bytes','sha256'}];assert descriptor(r['path'])=={k:r[k]for k in ['path','bytes','sha256']}
 if 'module'in r:assert r['module']=='seed/'+Path(r['path']).name
 return Path(r['path']).read_bytes()
def load(r):return json.loads(checked(r))
def git(*args):return subprocess.check_output(['git','-C',str(A),*args])
def historical_git_source(r,revision,relative,frozen):
 # Explicit opt-in for one historical source only: no pin fallback or exemptions.
 assert str(A/relative)==r['path'] and relative.startswith('seed/') and '..'not in Path(relative).parts
 raw=git('show',revision+':'+relative);assert len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256'] and raw==checked(frozen)
 return raw
def container(r,native,symbol):
 b=checked(r);i=b.index(b'\n\n');assert b[i+2:]==checked(native)
 exports=[x.split()for x in b[:i].decode().splitlines()[1:]];assert len([x for x in exports if x[0]==symbol])==1
 return exports
def stopped(root,count):
 cl=load(root);assert cl['status']=='closed' and cl['exit_code']==0 and cl['terminal']==dict(childCalls=count,allChildrenClosed=True,failure=False) and cl['wholeRawFilesReplayed']==count*2
 z=load(cl['report']);assert z['closedCompilerCalls']==count and z['noRetry'] and len(z['calls'])==count
 D=Path(cl['report']['path']).parent.parent;sp=json.loads((D/'source-pins.json').read_text());runtime=descriptor(D/'runtime.py');assert {k:runtime[k]for k in ['bytes','sha256']}==sp['runtime.py']
 for name,r in sp.items():assert descriptor(D/name)==dict(path=str(D/name),**r)
 sys.path.insert(0,str(D));sys.modules.pop('compiler_output',None)
 spec=importlib.util.spec_from_file_location('saved_runtime_'+str(count),runtime['path']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 attempts={x['label']:x for x in json.loads((D/'run-outputs/attempts.json').read_text())};assert len(attempts)==count
 for row in z['calls']:
  assert row['returncode']==0
  out=(D/'run-outputs'/(row['label']+'.stdout')).read_bytes();err=(D/'run-outputs'/(row['label']+'.stderr')).read_bytes()
  assert hashlib.sha256(out).hexdigest()==row['rawStdoutSHA256'] and hashlib.sha256(err).hexdigest()==row['rawStderrSHA256']
  assert m.qualify(out,err,row['case'])==row['report']
  a=attempts[row['label']];assert a['returncode']==0 and not a['waitUncertain'] and a['captureStopAcknowledged'] and a['ownershipWriterStopAcknowledged']
  for kind in ['ownership','memory','limit']:
   jp=D/'run-outputs'/(row['label']+'.'+kind+'-journal.jsonl');d=descriptor(jp);assert all(d[k]==a[kind+'Journal'][k]for k in ['bytes','sha256']);records=[json.loads(x)for x in jp.read_bytes().splitlines()];assert records
   if kind=='ownership':assert any(x['stage']=='loader-child-wait'and x['waitStatus']==0 for x in records)
   if kind=='limit':assert len(records)==6 and all(x.get('outcome','success')!='failure'for x in records)
 sys.path.pop(0);sys.modules.pop('compiler_output',None)
 return cl,z,descriptor(D/'preregistration.json'),runtime
def timing_runtime(D):
 r=descriptor(D/'runtime.py');sp=json.loads((D/'source-pins.json').read_text());assert {k:r[k]for k in ['bytes','sha256']}==sp['runtime.py']
 for name,x in sp.items():assert descriptor(D/name)==dict(path=str(D/name),**x)
 sys.path.insert(0,str(D));prior=sys.modules.pop('qualification',None)
 try:
  spec=importlib.util.spec_from_file_location('custody_timing_runtime',r['path']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 finally:
  sys.path.pop(0);sys.modules.pop('qualification',None)
  if prior is not None:sys.modules['qualification']=prior
 return m

def replay_selected95(sel,final):
 D=Path(final['fresh10Completion']['path']).parent.parent;m=timing_runtime(D)
 for row in sel['rows']:
  key=row['executionKey'];c={k:key[k]for k in ['arm','calls','warmup','n']};c['expectedResult']=row['observables']['result'];c['expectedObservables']=row['observables'];decoded=m.qualify(checked(row['rawStdout']),checked(row['rawStderr']),c);assert decoded['observables']==row['observables']
  if 'consumer'in key:checked(key['consumer'])

def fresh10(root,final):
 cl=load(root);assert cl['status']=='closed' and cl['exit_code']==0 and cl['wholeRawFilesReplayed']==20 and cl['allOriginalFullObservablesEqual'] and cl['terminal']==dict(buildCalls=0,consumerReuses=2,starts=10,closedCalls=10,allChildrenClosed=True,failure=None,noRetry=True)
 z=load(cl['report']);assert cl['report']==final['fresh10Completion'] and z['all10Fresh'] and z['failure']is None and len(z['results'])==10
 D=Path(cl['report']['path']).parent.parent;m=timing_runtime(D);attempts={x['label']:x for x in json.loads((D/'run-outputs/attempts.json').read_text())};assert len(attempts)==10
 for p in final['raw']+final['journals']:checked(p)
 for row in z['results']:
  c=row['case'];a=attempts[c['label']];assert a['returncode']==row['returncode']==0 and not a['waitUncertain'] and a['captureStopAcknowledged'] and a['ownershipWriterStopAcknowledged']
  out=(D/'run-outputs'/(c['label']+'.stdout')).read_bytes();err=(D/'run-outputs'/(c['label']+'.stderr')).read_bytes();assert hashlib.sha256(out).hexdigest()==row['rawStdoutSHA256'] and hashlib.sha256(err).hexdigest()==row['rawStderrSHA256'] and m.qualify(out,err,c)==row['report'] and row['report']['observables']==c['expectedObservables']
  for kind in ['ownership','memory','limit']:
   p=D/'run-outputs'/(c['label']+'.'+kind+'-journal.jsonl');d=descriptor(p);assert all(d[k]==a[kind+'Journal'][k]for k in ['bytes','sha256']);records=[json.loads(x)for x in p.read_bytes().splitlines()];assert records
   if kind=='ownership':assert any(x['stage']=='loader-child-wait'and x['waitStatus']==0 for x in records) and all(x.get('guestStillHeld',True)for x in records)
   if kind=='limit':assert len(records)==6 and all(x.get('outcome','success')!='failure'for x in records)
 return 20,30

def verify(adoption=AD):
 adpin=descriptor(adoption);ad=load(adpin);assert ad['status']=='LOCALLY_ADOPTED_GENERIC_BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_V4'
 assert git('rev-parse','HEAD').decode().strip()==ad['commit'] and git('status','--porcelain')==b''
 assert ad['original19CompileExtract38Passed'] and ad['wholeThreeGenerationsNativeAndContainersExact'] and ad['bootstrapBoundaryFullTextEqual'] and ad['bothTrackedBootstrapBinariesUnchanged'] and ad['guestArenaFuelABIUnchanged']
 assert checked(ad['bootstrapBefore'])==checked(ad['bootstrapAfter'])
 for r in load(ad['bootstrapBinaryPins']):
  if isinstance(r,dict) and {'path','bytes','sha256'}<=set(r):checked(r)
 checked(ad['source00']);checked(ad['source41']);C=load(ad['proofs']['candidate']);asm=load(C['assembly']);assert len(asm['modulePins'])==16
 source=[]
 for r in asm['modulePins']:
  raw=checked(r);live=A/'seed'/Path(r['path']).name;assert live.read_bytes()==raw and git('show',ad['commit']+':seed/'+live.name)==raw;source.append(descriptor(live))
 assert b''.join(checked(r)+b'\n'for r in asm['modulePins'])==checked(ad['unity'])==checked(C['unity'])
 fc,fp,fr,rt=stopped(ad['proofs']['fixedpoint6'],6);assert fp['wholeG2G3G4Equal']
 for gen in ['G2','G3','G4']:
  assert checked(fp['wholeGenerations'][gen]['native'])==checked(ad['compiler']) and checked(fp['wholeGenerations'][gen]['container'])==checked(ad['compilerContainer']);container(fp['wholeGenerations'][gen]['container'],fp['wholeGenerations'][gen]['native'],'main')
 oc,orig,op,ort=stopped(ad['proofs']['original19'],38);assert orig['currentCandidateNative']==ad['compiler'] and orig['currentCandidateContainer']==ad['compilerContainer']
 sel=load(ad['proofs']['selected95']);assert sel['currentCompiler']==ad['compiler'] and sel['currentCompilerContainer']==ad['compilerContainer'] and sel['whole19CompilerClosure']==ad['proofs']['original19'] and sel['fullOriginal19Selected95Qualified'] and sel['wholeFixedpoint3GenerationsVerified'] and len(sel['rows'])==95
 assert sel['original19Images']==orig['original19Images'];images={x['workload']:x for x in sel['original19Images']};assert len(images)==19
 for im in images.values():
  checked(im['source']);exports=container(im['container'],im['native'],im['selectedExport'][0]);assert [[x[0],int(x[1]),int(x[2])]for x in exports]==im['exports'];assert im['selectedExport']in im['exports']
 assert len({(x['workload'],x['n'])for x in sel['rows']})==95
 for row in sel['rows']:
  im=images[row['workload']];assert all(row[k]==im[k]for k in ['source','native','container','selectedExport']);checked(row['rawStdout']);checked(row['rawStderr']);key=row['executionKey'];assert key['symbol']==im['selectedExport'][0] and key['offset']==im['selectedExport'][1] and key['arity']==im['selectedExport'][2] and key['n']==row['n'] and row['n']in im['profiles']
 prior=load(sel['parentAdoption']);priorCandidate=load(prior['proofs']['candidate']);priorAssembly=load(priorCandidate['assembly']);iv=load(C['inverse']);pa=load(iv['parentAssembly']);assert len(pa['modulePins'])==16
 for old,frozen in zip(pa['modulePins'],priorAssembly['modulePins']):
  assert old['module']==frozen['module']
  if old['module']in ['seed/00-ns.kotoba','seed/41-a64gen.kotoba'] and old['path']==str(A/old['module']):historical_git_source({k:old[k]for k in ['path','bytes','sha256']},prior['commit'],old['module'],frozen)
  else:assert checked(old)==checked(frozen)
 for owner,field in [('seed/00-ns.kotoba','source00'),('seed/41-a64gen.kotoba','source')]:
  frozen=next(x for x in priorAssembly['modulePins']if x['module']==owner)
  historical=next(x for x in ad['sourceModules16']if x['path']==str(A/owner));assert checked(historical)==checked(next(x for x in asm['modulePins']if x['module']==owner))
  raw=git('show',prior['commit']+':'+owner);assert raw==checked(frozen)
  if field in prior:historical_git_source(prior[field],prior['commit'],owner,frozen)
 final=load(ad['proofs']['finalPeer']);assert final['status']=='PASS_INDEPENDENT_FINAL_BOUNDED_BALANCED_BYTE_TREE_TOKEN_CAPACITY_QUALIFICATION_V4' and final['selected95']==ad['proofs']['selected95'] and final['candidateFreeze']==ad['proofs']['candidate'] and final['fixedpointPeer']==ad['proofs']['fixedpointPeer'] and final['original19Peer']==ad['proofs']['original19Peer'] and final['rootClosure']==ad['proofs']['functional10'] and final['allFresh10OriginalFullObservablesExact'] and final['fullOriginal19Selected95Qualified'] and final['reusedProfiles']==85 and final['freshProfiles']==10
 freshRaw,freshJournals=fresh10(ad['proofs']['functional10'],final)
 replay_selected95(sel,final)
 return dict(status='PASS_CURRENT_ADOPTED_BASELINE_SAVED_CUSTODY_V5',parentCommit=ad['commit'],adoption=adpin,currentSourceModules16=source,currentUnity=ad['unity'],currentCompiler=ad['compiler'],currentCompilerContainer=ad['compilerContainer'],fixedpointClosure=ad['proofs']['fixedpoint6'],fixedpointReport=fc['report'],original19Closure=ad['proofs']['original19'],original19Report=oc['report'],selected95=ad['proofs']['selected95'],finalQualificationPeer=ad['proofs']['finalPeer'],whole3GenerationsNativeAndContainerExact=True,stoppedCompilerCallsRawReplayed=44,stoppedCompilerJournalsReplayed=132,original19WholeImagesAndAllExportsVerified=True,selected95RowsAndRawIdentityVerified=True,historicalParent00And41ResolvedOnlyByExactGitRevisionAndFrozenModules=True,fresh10RawReplayed=freshRaw,fresh10JournalsReplayed=freshJournals,selected95WholeObservablesDecoded=True,changedOwners00And41Exact=True,oldPreapplicationSourceGuardsReexecuted=False,nativeOperations=0,networkOperations=0,productWrites=0)
if __name__=='__main__':
 r=verify();r['recomputeScript']=descriptor(Path(__file__));p=Path(__file__).parent/'report.json';text=json.dumps(r,indent=2)+'\n'
 if '--check'in sys.argv:assert p.read_text()==text;print('PASS_READONLY_CURRENT_BASELINE_CUSTODY')
 else:assert not p.exists();p.write_text(text)
 print(descriptor(p))
