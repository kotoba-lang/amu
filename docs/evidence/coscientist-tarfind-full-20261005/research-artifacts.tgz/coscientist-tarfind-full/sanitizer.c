#include "c-bridge.c"
#include <stdio.h>
int main(void){int count=0;for(int n=0;n<=32;n++){memset(heap,0,sizeof(heap));int r=bench(n,0,0,0,0,0,0,0);if(r!=(n>0))return 1;for(int i=0;i<8995;i++){if((unsigned char)heap[i]>90)return 2;count++;}for(int f=0;f<1127;f++)if(observe(n*2048+f,0,0,0,0,0,0,0)==INT64_MIN)return 3;}printf("PASS 32 original bodies/verifiers; %d initialized header bytes; 37191 packed/state reads\n",count);return 0;}
