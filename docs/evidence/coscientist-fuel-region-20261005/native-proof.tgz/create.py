from pathlib import Path
import shutil,json
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-fuel-region-20261005');base=Path('/private/tmp/amu-scalar-tree-20261005')
g=(r/'seed/41-a64gen.kotoba').read_text()
a=g.index('(defn- gn-op-fuel ');b=g.index(';; one SIR instruction',a);old=g[a:b]
new='''(defn- gn-op-fuel [M :vector-i64] :vector-i64
  (if (= (gn-g M 13) 1)
    (if (= (gn-g M gn-f-freg) 1)
      (gn-emit M (enc-subs-i 8 8 1))
      (-> M (gn-ctx) (gn-emit (enc-ldr 16 7 CTX-FUEL)) (gn-emit (enc-subs-i 16 16 1)) (gn-emit (enc-str 16 7 CTX-FUEL))))
    OLD))

'''.replace('OLD',old[old.index('(if '):].rstrip()[:-1])
g=g[:a]+new+g[b:];anchor=';; every instruction from i (an instruction may consume the next ones: gn-f-skip)';assert g.count(anchor)==1;g=g.replace(anchor,(w/'region.kotoba').read_text()+'\n'+anchor)
old='(let [M1 (gn-ins M i (gn-op M i))\n          k (gn-g M1 gn-f-skip)]';new='''(let [token (if (or (= (gn-g M gn-f-dead) 1) (= (gn-g M 14) 1) (not= (gn-g M 13) 0)
                               (= (gn-region-charge M i) 0)) 0 (gn-region-end M i i 0))
          M1 (if (> token 0) (gn-region M i token) (gn-ins M i (gn-op M i)))
          k (gn-g M1 gn-f-skip)]''';assert g.count(old)==1;g=g.replace(old,new)
old='(mem-alloc M0 (+ gn-a-lp MM-LABEL-CAP))';assert g.count(old)==1;g=g.replace(old,'(mem-alloc M0 (+ gn-region-save 16 (* 2 gn-cap)))')
(w/'41-a64gen-prototype.kotoba').write_text(g);files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
for ext in ['bin','offset']:shutil.copyfile(base/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile(base/'kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['build.py','check-ports.py','bulk-state.py']:
 s=(base/name).read_text().replace('amu-scalar-tree-20261005','amu-fuel-region-20261005').replace("base=Path('/private/tmp/amu-sign-wrapper-20261005')","base=Path('/private/tmp/amu-scalar-tree-20261005')").replace("pathlib.Path('/private/tmp/amu-sign-wrapper-20261005/ports-correctness.json')","pathlib.Path('/private/tmp/amu-scalar-tree-20261005/ports-correctness.json')");(w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'hypothesis':'Bounded straight-line SIR regions with >=3 exact charges, before any control transfer/unknown call. Guard sufficient unsigned fuel, then retain original decrements and context/leaf commits but omit provably unneeded exhaustion branches. Otherwise same original region. Duplicate lowering with exact private generator-state snapshot. Max128 SIR, wrapper/inlined-runtime only; no names.','promotion':'Native fixed point, 19 result/exactfuel/exhaustion and full state/trap proof; freshquiet30 originalC triples, >=5% and gap>sumSD.','sourceHead':'93e5618be65be0b03edac43c7b8a3520c2c09924','exception':'One-off compiler algorithm authoring, not mechanical refactoring'},indent=2)+'\n')
