from pathlib import Path
import subprocess,re,os,json,hashlib
D=Path(__file__).resolve().parent
ns={};exec((D/'audit.py').read_text().split('variants=')[0],ns)
W=ns['W'];base=ns['base'];code=ns['code'];expr=ns['expr'];loads=ns['loads'];env=dict(os.environ,KEXE_COMMAND='1',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
helpers=ns['entry'].split('(defn- seed-main')[0]
entry='''
(defn- r-layout-bad [M :vector-i64 Safe :vector-i64 origin :i64 at :i64 value :i64 label :string] :vector-i64
 (let [old (vector-at M at) m0 (pl-run (-> M (mem-set at value) (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1)) Safe 0 0 origin)
       out (r-out label (vector-at m0 MM-ERR))] (-> m0 (mem-set at old) (mem-set MM-ERR 0))))
(defn- r-map-bad [M :vector-i64 Safe :vector-i64 origin :i64 value :i64 label :string] :vector-i64
 (let [safe0 (mem-set Safe (+ MM-SIR-CAP 3) value) m0 (pl-run (-> M (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1)) safe0 0 0 origin)
       out (r-out label (vector-at m0 MM-ERR)) safe1 (mem-set safe0 (+ MM-SIR-CAP 3) 1)] (mem-set m0 MM-ERR 0)))
(defn- seed-main [] :i64
 (let [M INIT a (gn-run M) g (vector-at a gn-cell) origin (vector-at a (+ g gn-g-open-n 2))
       n (vector-at a MM-CODE-N) V (r-copy a (vector-alloc n) 0 n)
       Safe (-> (vector-alloc (+ MM-SIR-CAP MM-FN-CAP)) (mem-set 0 3) (mem-set (+ MM-SIR-CAP 3) 1) (mem-set 16 1))
       good (pl-run (-> a (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1)) Safe 0 0 origin)
       ox (r-out "CLONE-CODE" (gn-fnf good 3 FF-CODE))
       o0 (r-out "LAYOUT-ERR" (vector-at good MM-ERR))
       o1 (r-out "LAYOUT-CODE-EQUAL" (if (and (= n (vector-at good MM-CODE-N)) (r-equal good V 0 n)) 1 0))
       b0 (r-map-bad good Safe origin 0 "MAP-ZERO")
       b1 (r-map-bad b0 Safe origin 3 "MAP-OUTSIDE")
       b2 (r-layout-bad b1 Safe origin (+ MM-FN-BASE MM-FN-W FF-SIR) 2 "ORIGINAL-POINTER")
       b3 (r-layout-bad b2 Safe origin (+ MM-SIR-BASE 4) OP-CONST "ORIGINAL-HEADER")
       b4 (r-layout-bad b3 Safe origin (+ MM-SIR-BASE (* 6 4) IF-A) 2 "ORIGINAL-END")
       b5 (r-layout-bad b4 Safe origin (+ MM-FN-BASE (* 3 MM-FN-W) FF-SIR) 14 "CLONE-POINTER")
       b6 (r-layout-bad b5 Safe origin (+ MM-SIR-BASE (* 13 4) IF-A) 1 "CLONE-HEADER")
       b7 (r-layout-bad b6 Safe origin (+ MM-SIR-BASE (* 18 4) IF-A) 2 "CLONE-END")
       b8 (r-layout-bad b7 Safe origin MM-FN-N 5 "CLONE-COUNT")
       b9 (r-layout-bad b8 Safe origin MM-SIR-N 20 "TRAILING-INSTRUCTION")] 0))
'''.replace('INIT',expr)
variants={'layout-correct':code,'layout-bypass-validation':code.replace('(pl-original-valid M 1 limit n) (pl-clones-valid M Safe limit n)','true true'),'layout-skip-version':code.replace('(if (or (>= f (vector-at M MM-FN-N)) (not= (vector-at M MM-ERR) 0)) M\n  (let [p (gn-fnf M f FF-SIR) end','(if true M\n  (let [p (gn-fnf M f FF-SIR) end')}
rows=[]
for name,version in variants.items():
 d=D/name;d.mkdir(exist_ok=True);src=d/'probe.kotoba';src.write_text(base+'\n'+version+'\n'+'\n'.join(loads)+helpers+entry)
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(d/'probe.kseed')]),('extract',['extract-native',str(d/'probe.kseed'),'--symbol','main','--output',str(d/'probe.bin')])]:
  q=subprocess.run([str(W/'kexe-loader'),str(W/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,stage,q.stdout[-500:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout)[1]
 q=subprocess.run([str(W/'kexe-loader'),str(d/'probe.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(d/'stdout').write_text(q.stdout);(d/'stderr').write_text(q.stderr)
 obs={line.split()[0]:int(line.split()[1]) for line in q.stdout.splitlines() if len(line.split())==2};good=q.returncode==0 and obs.get('CLONE-CODE',0)>0 and obs.get('LAYOUT-ERR')==0 and obs.get('LAYOUT-CODE-EQUAL')==1 and all(obs.get(k)==4102 for k in ['MAP-ZERO','MAP-OUTSIDE','ORIGINAL-POINTER','ORIGINAL-HEADER','ORIGINAL-END','CLONE-POINTER','CLONE-HEADER','CLONE-END','CLONE-COUNT','TRAILING-INSTRUCTION'])
 assert good==(name=='layout-correct'),(name,obs,q.returncode,q.stderr);rows.append({'variant':name,'exit':q.returncode,'observations':obs,'accepted':good,'detected':not good,'sha256':hashlib.sha256((d/'probe.bin').read_bytes()).hexdigest()});print(name,obs,flush=True)
(D/'layout-controls.json').write_text(json.dumps({'status':'PASS','malformedPartitionNativeControls':10,'actualSourceMutantsDetected':2,'rows':rows},indent=2)+'\n')
