from pathlib import Path
import subprocess,os,re,json,hashlib
W=Path('/private/tmp/amu-private-length-layout-20261006');D=W/'team-resource';R=W/'source-snapshot'
C={n:int(v) for n,v in re.findall(r'\(def ([A-Z][A-Z0-9-]*) (-?\d+)\)',(W/'unity.kotoba').read_text())}
bodies=[ [('FN',1,1,1),('LGET',0,1),('CONST',1,2),('RT',176,0,2),('RET',0),('END',1)], [('FN',2,0,1),('CONST',0,3),('RT',200,0,1),('CALL',1,0,1),('RET',0),('END',2)] ]
writes=[(C['MM-SIR-N'],13),(C['MM-FN-N'],3),(C['MM-LABEL-N'],1),(C['MM-CODE-N'],1),(C['MM-FIX-N'],1)]
for f,p,np,rt,pt in [(1,1,1,C['TY-I64'],C['TY-VEC']),(2,7,0,C['TY-I64'],0)]:
 for field,v in [('FF-SIR',p),('FF-NPARAMS',np),('FF-NSLOTS',1),('FF-DEPTH',2),('FF-RTYPE',rt),('FF-PT0',pt),('FF-KIND',C['FK-PRIV'])]: writes.append((C['MM-FN-BASE']+f*C['MM-FN-W']+C[field],v))
for p,row in enumerate(sum(bodies,[]),1):
 vals=[C['OP-'+row[0]],*row[1:]]+[0]*(4-len(row))
 for k,v in enumerate(vals): writes.append((C['MM-SIR-BASE']+p*4+k,v))
loads=[]
for g in range(0,len(writes),20):
 chunk=writes[g:g+20];loads.append('(defn- r-load%d [M0 :vector-i64] :vector-i64 (let [%s] M%d))'%(g//20,' '.join('M%d (mem-set M%d %d %d)'%(i+1,i,a,v) for i,(a,v) in enumerate(chunk)),len(chunk)))
expr='(vector-alloc MM-WORDS)'
for n in range(len(loads)): expr='(r-load%d %s)'%(n,expr)
entry='''
(defn- r-out [label :string n :i64] :i64 (io-out (string-concat label (string-concat " " (string-concat (string-from-i64 n) "\\n")))))
(defn- r-copy [M :vector-i64 V :vector-i64 i :i64 n :i64] :vector-i64 (if (= i n) V (r-copy M (mem-set V i (vector-at M (+ MM-CODE-BASE i))) (inc i) n)))
(defn- r-equal [M :vector-i64 V :vector-i64 i :i64 n :i64] :bool (if (= i n) true (and (= (vector-at V i) (vector-at M (+ MM-CODE-BASE i))) (r-equal M V (inc i) n))))
(defn- r-bad [M :vector-i64 at :i64 value :i64 label :string] :vector-i64
 (let [old (vector-at M at) m0 (pc-restore (mem-set M at value)) out (r-out label (vector-at m0 MM-ERR))] (-> m0 (mem-set at old) (mem-set MM-ERR 0))))
(defn- seed-main [] :i64
 (let [M INIT a (gn-run M) f (vector-at a MM-FN-N) s (vector-at a MM-SIR-N) n (vector-at a MM-CODE-N)
       V (r-copy a (vector-alloc n) 0 n) o0 (r-out "CLOSED-FN" f) o1 (r-out "CLOSED-SIR" s)
       open (gn-run-open (-> a (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1)) 1 1)
       o2 (r-out "OPEN-FN" (vector-at open MM-FN-N)) o3 (r-out "OPEN-SIR" (vector-at open MM-SIR-N))
       o4 (r-out "OPEN-EDGE" (gn-sir open 10 IF-A)) o5 (r-out "OPEN-ERR" (vector-at open MM-ERR))
       again (gn-run (-> open (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1)))
       o6 (r-out "AGAIN-FN" (vector-at again MM-FN-N)) o7 (r-out "AGAIN-SIR" (vector-at again MM-SIR-N))
       o8 (r-out "AGAIN-ERR" (vector-at again MM-ERR))
       o9 (r-out "CODE-EQUAL" (if (and (= n (vector-at again MM-CODE-N)) (r-equal again V 0 n)) 1 0))
       g (vector-at again gn-cell) origin (vector-at again (+ g gn-g-open-n 2))
       b0 (r-bad again (+ g gn-g-open-n 2) 1 "BAD-ORIGIN")
       b1 (r-bad b0 (+ origin 3) 16385 "BAD-COUNT")
       b2 (r-bad b1 origin 0 "BAD-FNCOUNT")
       b3 (r-bad b2 (+ origin 4) 0 "BAD-SITE")
       b4 (r-bad b3 (+ origin 5) 0 "BAD-TARGET")
       b5 (r-bad b4 (+ origin 4) 1 "BAD-NONCALL")
] 0))
'''.replace('INIT',expr)
base='\n'.join((R/p).read_text() for p in ['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'])
code=(W/'41-a64gen-prototype.kotoba').read_text()
variants={'correct':code,'no-restore':code.replace('MR (pc-restore M0)','MR M0'),'accept-invalid-edge':code.replace('(if (not valid) (gn-err M E-GEN-OP OP-CALL)\n    (pc-restore-edges','(if false (gn-err M E-GEN-OP OP-CALL)\n    (pc-restore-edges')}
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
rows=[]
for name,code in variants.items():
 d=D/name;d.mkdir(exist_ok=True);src=d/'probe.kotoba';src.write_text(base+'\n'+code+'\n'+'\n'.join(loads)+entry)
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(d/'probe.kseed')]),('extract',['extract-native',str(d/'probe.kseed'),'--symbol','main','--output',str(d/'probe.bin')])]:
  q=subprocess.run([str(W/'kexe-loader'),str(W/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,stage,q.stdout[-500:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout)[1]
 q=subprocess.run([str(W/'kexe-loader'),str(d/'probe.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(d/'stdout').write_text(q.stdout);(d/'stderr').write_text(q.stderr)
 obs={line.split()[0]:int(line.split()[1]) for line in q.stdout.splitlines() if len(line.split())==2}; good=q.returncode==0 and obs.get('CLOSED-FN')==4 and obs.get('OPEN-FN')==3 and obs.get('OPEN-SIR')==13 and obs.get('OPEN-EDGE')==1 and obs.get('CODE-EQUAL')==1 and all(obs.get(k,0)!=0 for k in ['BAD-ORIGIN','BAD-COUNT','BAD-FNCOUNT','BAD-SITE','BAD-TARGET','BAD-NONCALL'])
 assert good==(name=='correct'),(name,obs,q.returncode,q.stderr);rows.append({'variant':name,'exit':q.returncode,'observations':obs,'accepted':good,'detected':not good,'sha256':hashlib.sha256((d/'probe.bin').read_bytes()).hexdigest()});print(name,obs,flush=True)
(D/'restoration.json').write_text(json.dumps({'status':'PASS','rows':rows},indent=2)+'\n')
