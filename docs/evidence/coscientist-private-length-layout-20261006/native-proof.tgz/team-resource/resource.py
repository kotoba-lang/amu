from pathlib import Path
import json,os,re,subprocess,hashlib
W=Path('/private/tmp/amu-private-length-layout-20261006');OLD=Path('/private/tmp/amu-private-length-clones-20261006');D=W/'team-resource';baseline=json.loads((W/'ports-correctness.json').read_text());current=json.loads((W/'ports-build.json').read_text());prior=json.loads((OLD/'ports-state.json').read_text());rows=[]
resources={'heap':'KEXE_PAIRS','string-pool':'KEXE_STRING_POOL','vectors':'KEXE_VECTORS','vector-items':'KEXE_VECTOR_ITEMS'}
for e in current['entries']:
 name=e['workload'];old=next(x for x in baseline['entries'] if x['workload']==name);p=next(x for x in prior['rows'] if x['workload']==name and x['n']==1 and x['fuel']==16777216);cases=[]
 for res,envkey in resources.items():
  used=int(re.search(':'+res+r' \{:capacity \d+ :used (\d+)\}',p['product']['report'])[1]);caps=sorted(set([1]+[max(1,used+x) for x in [-1,0,1]]))
  for cap in caps:cases.append((res,envkey,cap,used))
 for res,envkey,cap,used in cases:
  obs={}
  for label,path,off in [('product',OLD/'baseline-native'/(name+'.bin'),old['offset']),('candidate',W/'ports'/name/'native.bin',e['offset'])]:
   env=dict(os.environ,KEXE_FUEL='16777216',KEXE_STRUCTURED_REPORT='1',**{envkey:str(cap)});env.pop('KEXE_COMMAND',None)
   q=subprocess.run([str(OLD/'full-state-loader'),str(path),str(off),'1','aarch64','-','1'],env=env,capture_output=True,text=True)
   obs[label]={'exit':q.returncode,'stdout':q.stdout.strip(),'stderr':q.stderr.strip()}
  assert obs['product']==obs['candidate'],(name,res,cap,obs)
  assert ':fuel ' in obs['candidate']['stdout'],(name,res,cap,obs)
  rows.append({'workload':name,'resource':res,'capacity':cap,'nominalUsed':used,**obs})
 print('PASS resource boundary',name,len(cases),flush=True)
(D/'resource-states.json').write_text(json.dumps({'status':'PASS','fullStatePairs':len(rows),'trappedPairs':sum(r['product']['exit']!=0 for r in rows),'rows':rows},indent=2)+'\n')
pins=[]
for p in D.rglob('*'):
 if p.is_file():pins.append({'path':str(p.relative_to(D)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
rest=json.loads((D/'restoration.json').read_text());report={'status':'PASS focused native restoration and original19 resource boundary equality','candidateSeedSha256':hashlib.sha256((W/'seed-4.bin').read_bytes()).hexdigest(),'restoration':rest,'nativeSourceMutantsDetected':2,'invalidUndoNativeControls':6,'fullStatePairs':len(rows),'trappedPairs':sum(r['product']['exit']!=0 for r in rows),'resourceTypes':list(resources),'codeExactRepeatedClosedOpenClosed':True,'limitations':['Guest resource/fuel/result/partial vector contents equality only; compiler transient allocation differs from product and is not claimed equal.','Undo corruption controls assume intact G magic and valid checked IR; arbitrary privileged host memory/code mutation is outside contract.','No performance measurement or product promotion.'],'pins':pins}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'],len(rows),report['trappedPairs'])
