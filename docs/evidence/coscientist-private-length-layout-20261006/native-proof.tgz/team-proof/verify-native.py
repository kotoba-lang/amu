from pathlib import Path
import json,hashlib,subprocess,os,re,shutil
T=Path(__file__).resolve().parent;W=T.parent;B=Path('/private/tmp/amu-static-vector-chain-20261006');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();runner='/private/tmp/amu-embench-compare-20261004/runner';base=json.loads((B/'ports-correctness.json').read_text());rows=[]
for e in json.loads((W/'ports-build.json').read_text())['entries']:
 old=next(x for x in base['entries'] if x['workload']==e['workload']);runs=[]
 for x in old['runs']:
  q=subprocess.run([runner,'raw',str(W/'ports'/e['workload']/'native.bin'),str(e['offset']),'aarch64',str(x['n']),'1','0','16777216'],capture_output=True,text=True);assert q.returncode==0,(e['workload'],q.stderr);v=json.loads(q.stdout);assert v['result']==x['result'] and v['contextFuelConsumed']==x['fuelConsumed'],(e['workload'],x,v);runs.append({'n':x['n'],'result':v['result'],'fuelConsumed':v['contextFuelConsumed']})
 q=subprocess.run([runner,'raw',str(W/'ports'/e['workload']/'native.bin'),str(e['offset']),'aarch64','1','1','0','1'],capture_output=True,text=True);assert q.returncode==old['fuelTrapReturncode']
 rows.append({**e,'runs':runs,'fuelTrapReturncode':q.returncode});print('PASS actual original result/fuel',e['workload'],flush=True)
(T/'ports-semantic.json').write_text(json.dumps({'status':'PASS original19 results/fuel plus fuel1 traps','entries':rows,'performanceClaim':False},indent=2)+'\n')
shutil.copy2('/private/tmp/amu-closed-chain-fuel-20261006/full-state-loader',T/'full-state-loader');states=[]
for e in rows:
 old=next(x for x in base['entries'] if x['workload']==e['workload']);cases=[(x['n'],16777216) for x in e['runs'] if x['n'] in (0,1,2)]+[(1,f) for f in [1,2,3,4,31,32,33,257]]
 for n,fuel in cases:
  obs={}
  for label,p,offset in [('product',B/'ports-2'/e['workload']/'native.bin',old['offset']),('candidate',W/'ports'/e['workload']/'native.bin',e['offset'])]:
   env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');env.pop('KEXE_COMMAND',None);q=subprocess.run([str(T/'full-state-loader'),str(p),str(offset),'1','aarch64','-',str(n)],env=env,capture_output=True,text=True);assert ':fuel ' in q.stdout
   obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
  assert obs['product']==obs['candidate'],(e['workload'],n,fuel,obs);states.append({'workload':e['workload'],'n':n,'fuel':fuel,**obs})
 print('PASS actual original full supervisor state',e['workload'],flush=True)
(T/'ports-state.json').write_text(json.dumps({'status':'PASS original19 full-state and partial-fuel','groups':len(states),'rows':states},indent=2)+'\n')
