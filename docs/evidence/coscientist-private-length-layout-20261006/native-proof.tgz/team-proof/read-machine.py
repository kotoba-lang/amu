from pathlib import Path
import re,struct,json,collections,hashlib,copy
T=Path(__file__).resolve().parent;W=T.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def parse(p):
 lines=(p/'compile.log').read_text().splitlines();phase=None;records=[];post=[];fns={};fix=[];n=None;events=[]
 for l in lines:
  v=l.split()
  if not v:continue
  if v[0]=='PCPHASE':phase=int(v[1]);records.append(tuple(map(int,v[1:])))
  if v[0] in ('SIR','META','PCFF','PCJOB','PCFACT','PCSAFE'):post.append((phase,v[0],*map(int,v[1:])))
  if v[0]=='MCINS':events.append(tuple(map(int,v[1:])))
  if v[0]=='MCFN':fns[int(v[1])]=int(v[2])
  if v[0]=='MCFIX':fix.append(tuple(map(int,v[1:])))
  if v[0]=='MCCODE':assert n is None;n=int(v[1])
 assert n and fns and records
 b=(p/'native.bin').read_bytes();words=[v[0] for v in struct.iter_unpack('<I',b[:4*(n-1)])]
 assert len(words)==n-1
 return dict(records=records,post=post,fns=fns,fix=fix,n=n,words=words,raw=b,events=events)
def signed(n,b):return n-(1<<b) if n&(1<<(b-1)) else n
def branch(z):
 if z&0x7c000000==0x14000000:return z&0xfc000000,signed(z&0x3ffffff,26)
 if z&0xff000010==0x54000000:return z&0xff00001f,signed((z>>5)&0x7ffff,19)
 if z&0x7e000000==0x34000000:return z&0xff00001f,signed((z>>5)&0x7ffff,19)
 if z&0x7e000000==0x36000000:return z&0xfff8001f,signed((z>>5)&0x3fff,14)
 if z&0x9f000000==0x10000000:return z&0x9f00001f,signed(((z>>5)&0x7ffff)*4+((z>>29)&3),21)/4
 return None
def triple(w,i):
 if i+2>=len(w):return False
 z=w[i];return z&0xffe0fc1f==0xeb00001f and ((z>>16)&31) in (3,16) and ((z>>5)&31)!=17 and w[i+1]==0x54000043 and w[i+2]==0

