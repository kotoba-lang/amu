from pathlib import Path
import tarfile,json,hashlib,shutil
T=Path(__file__).resolve().parent;W=T.parent;E=Path('/Users/junkawasaki/github/wt/amu-seed17/docs/evidence/coscientist-private-length-layout-20261006')
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
per=load(T/'adoption-permanent-proof.json');assert per['runs']==25658 and per['fixtures']==593 and not per['committedGoldenChanged']
assert load(T/'layout-audit.json')['instructionsRemoved']==0
# Archive only after every native run is terminal and all owned inventories match.
for name,z in load(W/'all-artifact-pins.json')['files'].items():assert sha(W/name)==z['sha256'],name
files={str(p.relative_to(W)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in W.rglob('*') if p.is_file() and p.name not in ['all-proof-pins.json','proof.tgz'] and 'timing-package' not in p.parts}
(T/'all-proof-pins.json').write_text(json.dumps({'status':'PASS frozen primary and complete native proof artifacts','files':files},indent=2)+'\n')
E.mkdir(exist_ok=True,parents=True)
with tarfile.open(E/'native-proof.tgz','w:gz') as t:
 for n in files:t.add(W/n,arcname=n)
 t.add(T/'all-proof-pins.json',arcname='team-proof/all-proof-pins.json')
(E/'archive-manifest.json').write_text(json.dumps({'sha256':sha(E/'native-proof.tgz'),'bytes':(E/'native-proof.tgz').stat().st_size,'files':len(files)},indent=2)+'\n')
for n,p in {'hypothesis.json':W/'hypothesis.json','fixed-point.json':W/'fixed-point.json','ports-build.json':W/'ports-build.json','layout-native.kotoba':W/'layout-native.kotoba','layout-audit.json':T/'layout-audit.json','layout-audit.py':T/'layout-audit.py','constructor-proof.json':W/'team-constructor/report.json','resource-proof.json':W/'team-resource/report.json','ports-semantic.json':T/'ports-semantic.json','ports-state.json':T/'ports-state.json'}.items():shutil.copy2(p,E/n)
(E/'permanent-proof.json').write_text(json.dumps({k:v for k,v in per.items() if k!='observations'},indent=2)+'\n')
print('PASS complete native source/binary/proof archive',len(files),sha(E/'native-proof.tgz'))
