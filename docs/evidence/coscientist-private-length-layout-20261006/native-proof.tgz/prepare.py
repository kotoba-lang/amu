from pathlib import Path
import hashlib,json,shutil,subprocess
W=Path(__file__).resolve().parent;V=Path('/private/tmp/amu-private-length-clones-20261006');R=Path('/Users/junkawasaki/github/wt/amu-seed17');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(V/'seed-4.bin')=='20f9a9554a459725bcba06d6110f8b53ffd75c2e14f7ea1d6f08fa48f6040683'
pins={str(p):sha(p) for p in [V/'41-a64gen-prototype.kotoba',V/'42-layout-prototype.kotoba',V/'seed-4.bin',R/'seed/MANIFEST']}
for name in ['42-layout-prototype.kotoba','42-layout.kotoba','ports-correctness.json','kexe-loader']:shutil.copy2(V/name,W/name)
shutil.copy2(V/'seed-4.bin',W/'seed-0.bin');shutil.copy2(V/'seed-4.offset',W/'seed-0.offset')
g=(V/'41-a64gen-prototype.kotoba').read_text();(W/'baseline-v3-41-a64gen.kotoba').write_text(g)
# New separate ephemeral mapping, never retained in semantic source or compiler metadata.
a='Safe (vector-alloc MM-SIR-CAP)';assert g.count(a)==1;g=g.replace(a,'Safe (vector-alloc (+ MM-SIR-CAP MM-FN-CAP))')
a='m0 (if (> clone 0) (pc-copy (pc-record M f clone 0 pos) j0 D L Safe j clone p end pos) M)';assert g.count(a)==1;g=g.replace(a,a+'\n        mapped (if (> clone 0) (mem-set Safe (+ MM-SIR-CAP clone) f) Safe)')
a='m0 (pc-clone me j4 D L Safe 1)';assert g.count(a)==1;g=g.replace(a,'layout_orig (mem-set Safe 0 (vector-at M MM-FN-N))\n          '+a)
helper='''
;; Excluded new native layout algorithm: validate the whole source partition,
;; then emit each generic body and its private length clones in source order.
;; Safe[0]=original FN count; Safe[MM-SIR-CAP+clone]=original FN identity.
;; Public/source metadata and all clone transformations remain unchanged.
(defn- pl-original-valid [M :vector-i64 i :i64 limit :i64 n :i64] :bool
 (if (= i limit) true
  (if (or (< i 1) (>= i limit) (not= (gn-op M i) OP-FN)) false
   (let [f (gn-sir M i IF-A) end (sh-end M (inc i) f 8192)]
    (and (> f 0) (< f n) (= (gn-fnf M f FF-SIR) i) (> end i) (< end limit)
         (pl-original-valid M (inc end) limit n))))))
(defn- pl-clones-valid [M :vector-i64 Safe :vector-i64 i :i64 f :i64] :bool
 (let [limit (vector-at M MM-SIR-N) n (vector-at M MM-FN-N) orig (vector-at Safe 0)]
  (if (= i limit) (= f n)
   (if (or (< i 1) (>= i limit) (>= f n) (not= (gn-op M i) OP-FN) (not= (gn-sir M i IF-A) f)) false
    (let [source (vector-at Safe (+ MM-SIR-CAP f)) p (if (and (> source 0) (< source orig)) (gn-fnf M source FF-SIR) 0) end (sh-end M (inc i) f 8192)]
     (and (> source 0) (< source orig) (> p 0) (= (gn-op M p) OP-FN) (= (gn-sir M p IF-A) source)
          (= (gn-fnf M f FF-SIR) i) (> end i) (< end limit)
          (pl-clones-valid M Safe (inc end) (inc f))))))))
(defn- pl-range [M :vector-i64 i :i64 limit :i64 Safe :vector-i64] :vector-i64
 (if (and (< i limit) (= (vector-at M MM-ERR) 0))
  (let [m1 (gn-ins (gn-gs M (+ gn-g-open-n 1) (vector-at Safe i)) i (gn-op M i))
        next (+ i 1 (gn-g m1 gn-f-skip)) m2 (gn-gs m1 gn-f-skip 0)]
   (if (> next limit) (gn-err m2 E-GEN-OP OP-FN) (pl-range m2 next limit Safe))) M))
(defn- pl-versions [M :vector-i64 Safe :vector-i64 original :i64 f :i64] :vector-i64
 (if (or (>= f (vector-at M MM-FN-N)) (not= (vector-at M MM-ERR) 0)) M
  (let [p (gn-fnf M f FF-SIR) end (if (= (vector-at Safe (+ MM-SIR-CAP f)) original) (sh-end M (inc p) f 8192) 0)
        m0 (if (> end p) (pl-range M p (inc end) Safe) M)]
   (pl-versions m0 Safe original (inc f)))))
(defn- pl-source [M :vector-i64 Safe :vector-i64 i :i64 limit :i64] :vector-i64
 (if (or (>= i limit) (not= (vector-at M MM-ERR) 0)) M
  (let [f (gn-sir M i IF-A) end (sh-end M (inc i) f 8192)
        m0 (pl-range M i (inc end) Safe) m1 (pl-versions m0 Safe f (vector-at Safe 0))]
   (pl-source m1 Safe (inc end) limit))))
(defn- pl-run [M :vector-i64 Safe :vector-i64 first :i64 count :i64 Origin :i64] :vector-i64
 (let [n (vector-at Safe 0)]
  (if (or (not= first 0) (not= count 0) (= n 0) (= Origin 0)) (gn-loop M 1 Safe)
   (let [limit (vector-at M (inc Origin))]
    (if (and (> n 1) (< n (vector-at M MM-FN-N)) (> limit 1) (< limit (vector-at M MM-SIR-N))
             (pl-original-valid M 1 limit n) (pl-clones-valid M Safe limit n))
      (pl-source M Safe 1 limit) (gn-err M E-GEN-OP OP-FN))))))
'''
g=g.replace('(defn- gn-run-open [',helper+'\n(defn- gn-run-open [');a='(gn-loop M2 1 Safe)';assert g.count(a)==1;g=g.replace(a,'(pl-run M2 Safe first count Origin)')
(W/'layout-native.kotoba').write_text(helper);(W/'41-a64gen-prototype.kotoba').write_text(g)
parts=[p.strip() for p in (R/'seed/MANIFEST').read_text().splitlines() if p.strip() and not p.lstrip().startswith('#')]
source={p:(V/'source-snapshot'/p).read_text() for p in parts};assert all(source[p]==(R/p).read_text() for p in parts if p not in ['seed/41-a64gen.kotoba','seed/42-layout.kotoba'])
for p in parts:
 dest=W/'source-snapshot'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(g if p=='seed/41-a64gen.kotoba' else (W/'42-layout-prototype.kotoba').read_text() if p=='seed/42-layout.kotoba' else source[p])
(W/'source-snapshot/seed/MANIFEST').write_text((R/'seed/MANIFEST').read_text());(W/'unity.kotoba').write_text('\n'.join((W/'source-snapshot'/p).read_text() for p in parts))
(W/'hypothesis.json').write_text(json.dumps({'status':'registered before first native build','hypothesis':'Isolate original-source-function-order generic/private-length-clone interleaving as layout variable; same v3 contexts, cloned SIR, Safe facts and guards. Preserve all public generic/FADDR/replaceable-body contracts. No generic in-place specialization or clone deletion.','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'sourceBaseNativeSha256':sha(V/'seed-4.bin'),'authoringException':'Excluded new native layout algorithm, not product mechanical refactor.','performanceClaim':False,'COrBetterAchieved':False,'requirements':['Complete original/clone source partition validation before reordered emission; every body once','Open/no-clone/refused preparation retains existing sequential gn-loop','Native fixed point2/3/4; original19/fullstate/fixtures; independent source/instruction/branch/fixup/private ABI audit','Fresh paired same-rule quiet-host campaign only after proofs']},indent=2)+'\n');(W/'input-pins.json').write_text(json.dumps(pins,indent=2)+'\n');(W/'source-pins.json').write_text(json.dumps({str(p.relative_to(W)):sha(p) for p in (W/'source-snapshot').rglob('*') if p.is_file()},indent=2)+'\n')
shutil.copy2(V/'ports.py',W/'ports.py')
print('PASS registered layout candidate sources')
