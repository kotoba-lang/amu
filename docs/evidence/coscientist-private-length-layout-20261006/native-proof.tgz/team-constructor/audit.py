from pathlib import Path
import subprocess,os,re,json,hashlib,shutil
W=Path('/private/tmp/amu-private-length-layout-20261006');OLD=Path('/private/tmp/amu-private-length-clones-20261006');D=W/'team-constructor'
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
names=['empty-read','len3-read2','len3-oob3','distinct3-5','distinct5-3','equal-join','unequal-join','identity-inplace','loop-read','unknown-allocation','indirect-invalidate','public-entry']
def compile(src,compiler,out,symbol='run',allowFailure=False):
 out.parent.mkdir(exist_ok=True,parents=True)
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(out.with_suffix('.kseed'))]),('extract',['extract-native',str(out.with_suffix('.kseed')),'--symbol',symbol,'--output',str(out)])]:
  q=subprocess.run([str(W/'kexe-loader'),str(compiler),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(out.parent/(out.stem+'-'+stage+'.log')).write_text(q.stdout+q.stderr)
  if q.returncode and allowFailure:return {'stage':stage,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
  assert q.returncode==0,(src,stage,q.stdout[-1000:],q.stderr[-1000:])
  if stage=='extract': off=int(re.search(r':offset (\d+)',q.stdout)[1])
 return off

def state(p,off,n,fuel):
 e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
 q=subprocess.run([str(OLD/'full-state-loader'),str(p),str(off),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True)
 return {'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
rows=[];public=[];offsets={}
for name in names:
 src=D/(name+'.kotoba');shutil.copy2(OLD/'team-constructor'/(name+'.kotoba'),src)
 offsets[name]={label:compile(src,c,D/name/(label+'.bin')) for label,c in [('baseline',OLD/'seed-0.bin'),('candidate',W/'seed-4.bin')]}
 for n in [0,1,2,3,5]:
  for fuel in [1,2,7,31,1048576]:
   obs={label:state(D/name/(label+'.bin'),offsets[name][label],n,fuel) for label in ['baseline','candidate']}
   assert obs['baseline']==obs['candidate'],(name,n,fuel,obs);rows.append({'case':name,'n':n,'fuel':fuel,**obs})
 print('PASS actual layout',name,flush=True)
for label,c in [('baseline',OLD/'seed-0.bin'),('candidate',W/'seed-4.bin')]:
 off=compile(D/'public-entry.kotoba',c,D/'public-entry'/(label+'-public.bin'),'read3')
 for n in [0,1,-1,9223372036854775807]:public.append({'label':label,'handle':n,**state(D/'public-entry'/(label+'-public.bin'),off,n,1048576)})
for a,b in zip(public[:4],public[4:]):assert {k:v for k,v in a.items() if k!='label'}=={k:v for k,v in b.items() if k!='label'}
(D/'semantic.json').write_text(json.dumps({'status':'PASS','controlGroups':12,'fullStateComparisons':304,'rows':rows,'publicExportRows':public,'baselineCompilerSha256':hashlib.sha256((OLD/'seed-0.bin').read_bytes()).hexdigest(),'candidateCompilerSha256':hashlib.sha256((W/'seed-4.bin').read_bytes()).hexdigest()},indent=2)+'\n')
