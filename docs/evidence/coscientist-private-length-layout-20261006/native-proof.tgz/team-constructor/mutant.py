exec((__import__('pathlib').Path('/private/tmp/amu-private-length-layout-20261006/team-constructor/audit.py')).read_text().split('rows=[]')[0])
needle='m1 (pl-versions m0 Safe f (vector-at Safe 0))';base=(W/'unity.kotoba').read_text();assert base.count(needle)==1
src=D/'omit-private-versions-compiler.kotoba';src.write_text(base.replace(needle,'m1 m0',1));compiler=D/'omit-private-versions-compiler.bin';assert compile(src,OLD/'seed-0.bin',compiler,'main')==0
case='len3-read2';out=D/case/'omit-private.bin';result=compile(D/(case+'.kotoba'),compiler,out,allowFailure=True)
if isinstance(result,dict): record={'detected':True,'reason':'existing correctly compiled source refused by actual defective native compiler','nativeFailure':result}
else:
 ref=int(re.search(r':offset (\d+)',(D/case/'baseline-extract.log').read_text())[1]);a=state(D/case/'baseline.bin',ref,2,1048576);b=state(out,result,2,1048576);assert a!=b,(a,b);record={'detected':True,'reason':'actual native emitted faulty body changed full supervisor observation','baseline':a,'mutant':b}
record.update(status='PASS',sourceMutation='omit pl-versions emission entirely while generic CALLs still redirect to private clones',compilerSha256=hashlib.sha256(compiler.read_bytes()).hexdigest())
(D/'mutant.json').write_text(json.dumps(record,indent=2)+'\n');print('PASS actual native layout source mutant detected',record['reason'],flush=True)
