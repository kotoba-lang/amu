from pathlib import Path
import subprocess,os,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-affine-writer-20261005');base=Path('/private/tmp/amu-clamp-call-20261005');parts=[]
for x in (r/'seed/MANIFEST').read_text().splitlines():
 x=x.strip()
 if not x or x.startswith('#'):continue
 parts.append(x)
 if x=='seed/30-lower.kotoba':break
s=(r/'seed/tests/unit/30-lower_t.kotoba').read_text().replace('        S (typed-cap-call :fs/app-data', '        S0 (typed-cap-call :fs/app-data');needle='        o (t-out (string-concat "program "';assert s.count(needle)==1;s=s.replace(needle,'        S (string-concat S0 (ck-r6b-lib S0))\n'+needle);src=w/'dump.kotoba';src.write_text('\n'.join((r/x).read_text() for x in parts)+'\n'+s)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');offset=0
for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/'dump.kseed')]),('extract',['extract-native',str(w/'dump.kseed'),'--symbol','main','--output',str(w/'dump.bin')])]:
 q=subprocess.run([str(base/'kexe-loader'),str(base/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/('dump-'+mode+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(mode,q.stdout,q.stderr)
 if mode=='extract':offset=int(re.search(r':offset (\d+)',q.stdout).group(1))
q=subprocess.run([str(base/'kexe-loader'),str(w/'dump.bin'),str(offset),'0','aarch64','35,37,38,39','--','/','dummy',str(r/'bench/embench/picojpeg-full.kotoba'),'dump'],env=env,capture_output=True,text=True);(w/'sir.log').write_text(q.stdout+q.stderr);assert q.returncode==0,(q.stdout[-200:],q.stderr)
lines=q.stdout.splitlines();names=re.findall(r'^fn (\S+) nslots',q.stdout,re.M);ids=[int(x) for x in re.findall(r'^\d+ FN (\d+) ',q.stdout,re.M)];assert len(names)==len(ids);fn=dict(zip(names,ids));rows={}
for name in ['set-lane','i16','put']:
 f=fn[name];j=next(i for i,x in enumerate(lines) if re.match(r'^\d+ FN '+str(f)+r' ',x));end=next(i for i in range(j+1,len(lines)) if re.match(r'^\d+ END '+str(f)+r' ',lines[i]));rows[name]={'id':f,'sir':lines[j:end+1]};print(name,'\n'+'\n'.join(rows[name]['sir']),flush=True)
(w/'inspected-sir.json').write_text(json.dumps({'status':'complete-fresh-native-checked-SIR','sourceHead':'dbb707465fd8d8768edd5b1110828193214cbad4','producerSha256':hashlib.sha256((base/'seed-4.bin').read_bytes()).hexdigest(),'canonicalSourceSha256':hashlib.sha256((r/'bench/embench/picojpeg-full.kotoba').read_bytes()).hexdigest(),'functions':rows},indent=2)+'\n')
