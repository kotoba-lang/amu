from pathlib import Path
import json,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-affine-writer-20261005');base=Path('/private/tmp/amu-clamp-call-20261005');g=(r/'seed/41-a64gen.kotoba').read_text();assert json.loads((w/'inspected-sir.json').read_text())['status']=='complete-fresh-native-checked-SIR'
helper=''';; Exact five-argument affine-index/signed-value checked vector write.
;; Keep original nonleaf caller, closed dependencies and leaf fuel transaction.
(defn- gn-affine-writer [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :i64
  (let [p (gn-fnf M f FF-SIR) fuel (if (= (gn-op M (inc p)) OP-FUEL) 1 0)
        q (gn-skiplab M (+ p 1 fuel)) sign (gn-sir M (+ q 7) IF-A)
        writer (gn-sir M (+ q 8) IF-A) w (gn-wrapper M writer 0 3)]
    (if (and (> p 0) (= n 5) (<= t 2) (= (gn-g M gn-f-leaf) 0)
             (not (gn-clamp-open M f)) (not (gn-clamp-open M sign)) (not (gn-clamp-open M writer))
             (not= (gn-op M (inc i)) OP-RES2)
             (= (gn-op M p) OP-FN) (= (gn-sir M p IF-A) f) (= (gn-sir M p IF-B) 5)
             (= (gn-wparams M q 0 4) (+ q 4))
             (= (gn-op M (+ q 4)) OP-BIN) (= (gn-sir M (+ q 4) IF-A) BOP-MUL) (= (gn-sir M (+ q 4) IF-B) 2)
             (= (gn-op M (+ q 5)) OP-BIN) (= (gn-sir M (+ q 5) IF-A) BOP-ADD) (= (gn-sir M (+ q 5) IF-B) 1)
             (= (gn-op M (+ q 6)) OP-LGET) (= (gn-sir M (+ q 6) IF-A) 2) (= (gn-sir M (+ q 6) IF-B) 5)
             (= (gn-op M (+ q 7)) OP-CALL) (= (gn-sir M (+ q 7) IF-B) 2) (= (gn-sir M (+ q 7) IF-C) 1)
             (> (gn-sign-wrapper M sign 1) 0)
             (= (gn-op M (+ q 8)) OP-CALL) (= (gn-sir M (+ q 8) IF-B) 0) (= (gn-sir M (+ q 8) IF-C) 3)
             (or (= w RT-VECTOR-ASSOC-IN-PLACE) (= w (+ RT-VECTOR-ASSOC-IN-PLACE 256)))
             (= (gn-op M (+ q 9)) OP-RET) (= (gn-sir M (+ q 9) IF-A) 0)
             (= (gn-op M (+ q 10)) OP-END) (= (gn-sir M (+ q 10) IF-A) f)) q 0)))

'''
a='(defn- gn-use [M';assert g.count(a)==1;g=g.replace(a,helper+a)
emit=''';; x0 is the signed value, x1 the wrapping affine index; x2/x3 are
;; borrowed only in a retained nonleaf caller. Pinned vector stays in x9..x11.
(defn- gn-call-affine-writer [M :vector-i64 i :i64 f :i64 t :i64 q :i64] :vector-i64
  (let [p (gn-fnf M f FF-SIR) outer (= (gn-op M (inc p)) OP-FUEL)
        sw (gn-sign-wrapper M (gn-sir M (+ q 7) IF-A) 1)
        ww (gn-wrapper M (gn-sir M (+ q 8) IF-A) 0 3)
        charged (or outer (>= sw 1536) (>= ww 256)) width (bit-and sw 511)
        M1 (gn-pin M t) rv (gn-pinned M1 t)]
    (-> M1 (gn-into 1 (inc t)) (gn-into 2 (+ t 2)) (gn-into 3 (+ t 3)) (gn-into 0 (+ t 4))
        (gn-ctx)
        (cond-> charged (gn-emit (enc-ldr 8 7 CTX-FUEL))
                outer (gn-mask-charge))
        (gn-emit (enc-madd 1 2 3 1))
        (cond-> (>= sw 1536) (gn-mask-charge))
        (gn-emit (gn-e-bf 0x93400000 0 0 0 (dec width)))
        (cond-> (>= ww 256) (gn-mask-charge))
        (gn-hchk rv 312 320) (gn-vidx 1) (gn-emit (gn-e-strr3 0 16 17))
        (cond-> charged (gn-emit (enc-str 8 7 CTX-FUEL)))
        (gn-into 0 t) (gn-take i t 0))))

'''
a=';; Bounded structural proof';assert g.count(a)==1;g=g.replace(a,emit+a)
a='q (gn-clamp M i f n)]\n   (cond';assert g.count(a)==1;g=g.replace(a,'q (gn-clamp M i f n) aw (gn-affine-writer M i f t n)]\n   (cond (> aw 0) (gn-call-affine-writer M i f t aw)')
(w/'41-a64gen-prototype.kotoba').write_text(g);files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
for ext in ['bin','offset']:shutil.copyfile(base/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile(base/'kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
(w/'build.py').write_text((base/'build.py').read_text().replace('amu-clamp-call-20261005','amu-affine-writer-20261005'))
(w/'hypothesis.json').write_text(json.dumps({'sourceHead':'dbb707465fd8d8768edd5b1110828193214cbad4','previousRegistration':json.loads((r/'docs/evidence/coscientist-clamp-call-20261005/next-hypothesis.json').read_text()),'freshSIR':'Canonical affine writer charges entry and checked writer, not the sign helper. Generic optional charge bits preserved separately.','implementation':'Exact natural vector,base,stride,k,value arguments; wrapping MADD index, SBFM value, original checked vector write, leaf x8 fuel transaction. Original nonleaf caller and closed dependencies mandatory; t<=2 pins all five natural inputs in registers; other cases fallback. No names or canonical source edits.','promotion':'Original19 semantics/fuel/exhaustion, fullPico8192cells, independently native layouts/hand oracles/full supervisor/partial arenas/wrapping extremes/live temps/traps/import refusal. Every changed guest freshquiet30 originalC triples >=1.05x and gain>sumSD in at least one; no separated regressions. Then native gates and committed-source integrated3gen+percasecorpus.','exception':'New compiler algorithm authoring, not mechanical refactor; product untouched pending qualification'},indent=2)+'\n')
print('registered implementation from fresh SIR; product unchanged')
