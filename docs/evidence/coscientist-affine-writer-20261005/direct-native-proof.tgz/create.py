from pathlib import Path
import shutil,json
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-affine-writer-direct-20261005');old=Path('/private/tmp/amu-affine-writer-20261005');base=Path('/private/tmp/amu-clamp-call-20261005');g=(old/'41-a64gen-prototype.kotoba').read_text()
a='''        M1 (gn-pin M t) rv (gn-pinned M1 t)]
    (-> M1 (gn-into 1 (inc t)) (gn-into 2 (+ t 2)) (gn-into 3 (+ t 3)) (gn-into 0 (+ t 4))
        (gn-ctx)'''
b='''        M1 (gn-pin M t) rv (gn-pinned M1 t)
        rb (gn-src M1 (inc t) 0 1) rs (gn-src M1 (+ t 2) 16 1)
        rk (gn-src M1 (+ t 3) 17 1) rx (gn-src M1 (+ t 4) 0 1)]
    (-> M1 (gn-ldt (inc t) 0 1) (gn-ldt (+ t 2) 16 1) (gn-ldt (+ t 3) 17 1)
        (gn-ctx)'''
assert g.count(a)==1;g=g.replace(a,b)
a='''        (gn-emit (enc-madd 1 2 3 1))
        (cond-> (>= sw 1536) (gn-mask-charge))
        (gn-emit (gn-e-bf 0x93400000 0 0 0 (dec width)))'''
b='''        (gn-emit (enc-madd 1 rs rk rb))
        (cond-> (>= sw 1536) (gn-mask-charge))
        (gn-ldt (+ t 4) 0 1) (gn-emit (gn-e-bf 0x93400000 0 rx 0 (dec width)))'''
assert g.count(a)==1;g=g.replace(a,b);g=g.replace('x2/x3 are\n;; borrowed only in a retained nonleaf caller.', 'operands read\n;; existing caller registers or distinct x0/x16/x17 scratch words.')
(w/'41-a64gen-prototype.kotoba').write_text(g);files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
for ext in ['bin','offset']:shutil.copyfile(base/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile(base/'kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['build.py','check-ports.py','bulk-state.py','import-proof.py']:
 s=(old/name).read_text().replace('amu-affine-writer-20261005','amu-affine-writer-direct-20261005');(w/name).write_text(s)
shutil.copyfile(old/'inspected-sir.json',w/'inspected-sir.json')
(w/'hypothesis.json').write_text(json.dumps({'sourceHead':'dbb707465fd8d8768edd5b1110828193214cbad4','hypothesis':'Same exact affine signed checked-write proof and fuel transaction, but read existing descriptor registers directly for MADD and SBFM, load only missing operands into distinct x0/x16/x17 scratch. No argument-register staging copies. Materialize value after index calculation so x0 scratch lifetimes do not overlap. Retained nonleaf caller makes scratches safe; t<=2 and closed dependencies unchanged.','priorCandidate':'Staged x0/x1/x2/x3 prototype reduced average3.10% but failed >=5% and mean-gap>summedSD. Rejected, no product changes. This changes guest machine code and is not a retry of unchanged bytes.','proof':'Original19 exactfuel/result/exhaustion and fullPico8192cells; all prior hand-derived runs plus direct-operand scratch/constant/home/alias and partial-write/fullsupervisor/import tests. Every changed guest freshquiet30 current-product/new-candidate/original-C triples >=1.05x and gain>summedSD, no separated regression. Then native gates and committed-source integrated3gen+percasecorpus before promotion.','exception':'One-off compiler algorithm authoring, no product changes pending qualification'},indent=2)+'\n');print('registered direct-operand variant; product unchanged')
