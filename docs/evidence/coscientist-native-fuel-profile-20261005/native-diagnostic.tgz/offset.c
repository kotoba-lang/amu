#define main kexe_loader_main
#include "profile-loader.c"
#undef main
int main(void) { printf("%zu\n", offsetof(struct kexe_context_v11, profile_fuel)); return 0; }
