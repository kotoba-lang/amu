from pathlib import Path
import json,tarfile,difflib,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-native-fuel-profile-20261005');e=r/'docs/evidence/coscientist-native-fuel-profile-20261005';e.mkdir(parents=True,exist_ok=True);p=json.loads((w/'profile.json').read_text());one=next(x for x in p['rows'] if x['n']==1);p['topSixChargeFraction']=sum(x['successfulCharges'] for x in one['ranked'][:6])/one['exactFuelConsumed'];p['knownDiagnosticFailure']='First dumper omitted ck-r6b-lib and refused rem with E2101. Original failure kept; repaired dumper appends same source helper library as product driver.';p['nextHypothesis']='Exact generic scalar-index vector-write wrapper fusion: proved natural parameters, multiply/add index and signed16 value, proved in-place vector-write wrapper. Preserve all original entry fuel and checked vector handle/index path; unknown shape refuses. Prior isolated multiply has only2640 charges versus43008 at set-lane. Counts are not exclusive-time evidence.';(e/'profile.json').write_text(json.dumps(p,indent=2)+'\n')
for old,new,name in [(r/'seed/41-a64gen.kotoba',w/'41-a64gen-profile.kotoba','backend.diff'),(r/'tools/kexe_loader.c',w/'profile-loader.c','loader.diff')]:
 (e/name).write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=str(old.relative_to(r)),tofile='diagnostic/'+new.name,n=0)))
with tarfile.open(e/'native-diagnostic.tgz','w:gz') as t:
 for x in sorted(w.iterdir()):
  if x.name!='offset':t.add(x,arcname=x.name)
print('PASS native diagnostic archived',p['topSixChargeFraction'])
