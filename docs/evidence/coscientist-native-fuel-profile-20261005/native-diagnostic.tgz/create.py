from pathlib import Path
import subprocess,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-native-fuel-profile-20261005');c=(r/'tools/kexe_loader.c').read_text();start=c.index('struct kexe_context_v11 {');end=c.index('\n};',start);c=c[:end]+'\n  /* Diagnostic-only extension; original ABI offsets unchanged. */\n  uint64_t profile_fuel[8192];'+c[end:];needle='  shared->result = result;';repl='''  for (size_t f = 0; f < 8192; ++f) {
    if (shared->context.profile_fuel[f])
      fprintf(stderr, "PROFILE_FUEL %zu %" PRIu64 "\\n", f, shared->context.profile_fuel[f]);
  }
  fprintf(stderr, "PROFILE_REMAINING %" PRIu64 "\\n", shared->context.fuel);
'''+needle;assert c.count(needle)==1;c=c.replace(needle,repl);(w/'profile-loader.c').write_text(c)
(w/'offset.c').write_text('#define main kexe_loader_main\n#include "profile-loader.c"\n#undef main\nint main(void) { printf("%zu\\n", offsetof(struct kexe_context_v11, profile_fuel)); return 0; }\n')
for src,out in [('offset.c','offset'),('profile-loader.c','profile-loader')]:
 p=subprocess.run(['clang','-O2','-Wno-deprecated-declarations',str(w/src),'-o',str(w/out)],capture_output=True,text=True);(w/(out+'.cc.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
p=subprocess.run([str(w/'offset')],capture_output=True,text=True);assert p.returncode==0;off=int(p.stdout);(w/'context-offset.json').write_text(json.dumps({'offset':off,'diagnosticOnly':True})+'\n');assert off%8==0
old=(r/'seed/41-a64gen.kotoba').read_text();g=old;needle='(gn-zero gn-f-leaf gn-a-sreg)';assert g.count(needle)==1;g=g.replace(needle,needle+'\n                     (gn-gs 13 f)')
a='(defn- gn-op-fuel [M :vector-i64] :vector-i64';assert g.count(a)==1;g=g.replace(a,'(defn- gn-op-fuel-original [M :vector-i64] :vector-i64')
pos=g.index(';; one SIR instruction (unreachable')
helper=f''' ;; Diagnostic-only successful fuel counters, attributed to emitting function.
;; x16 is reserved scratch. Existing charge executes first, so failed charges
;; are not counted; calls/branches/fuel traps retain their original order.
(defn- gn-op-fuel [M :vector-i64] :vector-i64
  (let [f (gn-g M 13) offset (+ {off} (* f 8)) M1 (gn-op-fuel-original M)]
    (if (> offset 32760) (gn-err M1 E-GEN-OP f)
      (-> M1 (gn-ctx) (gn-emit (enc-ldr 16 7 offset))
          (gn-emit (enc-add-i 16 16 1)) (gn-emit (enc-str 16 7 offset))))))
\n''';g=g[:pos]+helper+g[pos:];(w/'41-a64gen-profile.kotoba').write_text(g)
files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];u=''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files);(w/'seed-unity.kotoba').write_text(u)
(w/'hypothesis.json').write_text(json.dumps({'question':'Where do the canonical Picojpeg 222003 successful per-body fuel charges occur? Locate major dynamic execution count before another optimization.','diagnosticOnly':True,'noTimingClaim':True,'sourceHead':'4feb0fa773f98f55c25625fdc19419e5711efc9b','compilerRoute':'Native promoted fixed-point seed compiles diagnostic compiler; that native compiler emits instrumented canonical benchmark. No host language compiler frontend.','chargeSemantics':'Every original check occurs first; increment afterward only on success. Original result and consumed fuel must match baseline.','exception':'One-off new diagnostic algorithm authoring, no product source or mechanical refactoring'},indent=2)+'\n');print('Diagnostic context extension offset',off)
