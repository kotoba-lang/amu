from pathlib import Path
import subprocess,os,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-native-fuel-profile-20261005');loader=Path('/private/tmp/amu-sign-wrapper-20261005/kexe-loader');base=Path('/private/tmp/amu-sign-wrapper-20261005/seed-4.bin');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
def compile(seed,src,name,symbol):
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(name+'.kseed'))]),('extract',['extract-native',str(w/(name+'.kseed')),'--symbol',symbol,'--output',str(w/(name+'.bin'))])]:
  p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(name+'-'+stage+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(stage,p.stdout,p.stderr)
  if stage=='extract':off=int(re.search(r':offset (\d+)',p.stdout).group(1))
 return off
assert compile(base,w/'seed-unity.kotoba','profile-compiler','main')==0
assert compile(base,w/'dump.kotoba','dump','main')==0
src=r/'bench/embench/picojpeg-full.kotoba';off=compile(w/'profile-compiler.bin',src,'picojpeg-profile','bench')
p=subprocess.run([str(loader),str(w/'dump.bin'),'0','0','aarch64','35,37,38,39','--','/','dummy',str(src),'dump'],env=env,capture_output=True,text=True);(w/'sir.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
names=re.findall(r'^fn (\S+) nslots',p.stdout,re.M);ids=[int(x) for x in re.findall(r'^\d+ FN (\d+) ',p.stdout,re.M)];assert len(names)==len(ids),(len(names),len(ids));fn=dict(zip(ids,names));rows=[]
baseports=json.loads(Path('/private/tmp/amu-sign-wrapper-20261005/ports-correctness.json').read_text());b=next(x for x in baseports['entries'] if x['workload']=='picojpeg')
for n in [0,1,2,17,32]:
 e=dict(env,KEXE_FUEL='16777216');e.pop('KEXE_COMMAND',None)
 p=subprocess.run([str(w/'profile-loader'),str(w/'picojpeg-profile.bin'),str(off),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True);(w/f'run-{n}.stdout').write_text(p.stdout);(w/f'run-{n}.stderr').write_text(p.stderr);assert p.returncode==0,(n,p.stdout,p.stderr);result=int(p.stdout.splitlines()[-1]);remaining=int(re.search(r'PROFILE_REMAINING (\d+)',p.stderr).group(1));counts={int(f):int(c) for f,c in re.findall(r'PROFILE_FUEL (\d+) (\d+)',p.stderr)};consumed=16777216-remaining;baseline=next(x for x in b['runs'] if x['n']==n);assert result==baseline['result'] and consumed==baseline['fuelConsumed'] and sum(counts.values())==consumed,(n,result,consumed,baseline,sum(counts.values()))
 ranked=[{'functionId':f,'function':fn[f],'successfulCharges':c} for f,c in sorted(counts.items(),key=lambda x:-x[1])];rows.append({'n':n,'result':result,'exactFuelConsumed':consumed,'sumProfiledCharges':sum(counts.values()),'ranked':ranked});print('PASS',n,consumed,ranked[:6],flush=True)
report={'status':'complete-native-canonical-dynamic-fuel-profile','diagnosticOnly':True,'performanceMeasured':False,'officialEmbenchScore':False,'contextExtension':json.loads((w/'context-offset.json').read_text()),'sourceSha256':hashlib.sha256(src.read_bytes()).hexdigest(),'compilerSha256':hashlib.sha256((w/'profile-compiler.bin').read_bytes()).hexdigest(),'nativeSha256':hashlib.sha256((w/'picojpeg-profile.bin').read_bytes()).hexdigest(),'offset':off,'rows':rows,'attribution':'Original successful emitted fuel checks attributed to the function containing them. Self-tail iterations count; inlined helper charges attributed to caller. No claim of exact exclusive time.'};(w/'profile.json').write_text(json.dumps(report,indent=2)+'\n')
