/* BOOTSTRAP-TOOL: check oracle fixture accesses, no timed code changes. */
#include "c-bridge.c"
int main(void){
 for(int i=0;i<42;i++){
  if(fixture_selfcheck(i,0,0,0,0,0,0,0)!=1)return 1;
  for(int cell=0;cell<805;cell++)(void)observe_fixture(i*1024+cell,0,0,0,0,0,0,0);
 }
 if(original_result(32,0,0,0,0,0,0,0)!=102)return 2;return 0;
}
