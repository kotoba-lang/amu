import pathlib,ctypes,json,re,subprocess
p=pathlib.Path('/private/tmp/amu-embench-compare-20261004/coscientist-slre');c=ctypes.CDLL(str(p/'c.dylib'))
for sym in ('observe_fixture','fixture_selfcheck'):
 f=getattr(c,sym);f.restype=ctypes.c_int64;f.argtypes=[ctypes.c_int64]*8
entry=re.search(r':offset (\d+)',(p/'observe-fixture-extract.log').read_text()).group(1)
report={'performanceMeasured':False,'fixtures':[],'cells':[]}
for i,case in enumerate(json.loads((p/'fixtures.json').read_text())):
 assert c.fixture_selfcheck(i,0,0,0,0,0,0,0)==1,(i,'oracle vs original')
 # All initialized state slots, including inactive slots, compared for each fixture.
 for cell in range(805):
  encoded=i*1024+cell;r=subprocess.run([str(p.parent/'runner'),'raw',str(p/'observe-fixture.bin'),entry,'aarch64',str(encoded),'1','0','16777216'],capture_output=True,text=True)
  assert r.returncode==0,(i,cell,r.returncode,r.stderr)
  v=json.loads(r.stdout)['result'];w=c.observe_fixture(encoded,0,0,0,0,0,0,0);assert v==w,(i,cell,v,w,case)
  report['cells'].append({'case':i,'cell':cell,'Kotoba':v,'C':w})
 report['fixtures'].append({'case':i,'originalCSelfcheck':True,'result':c.observe_fixture(i*1024+804,0,0,0,0,0,0,0)})
 (p/'fixture-results.json').write_text(json.dumps(report,indent=2)+'\n')
 print('case',i,'all 805 cells match',case,flush=True)
