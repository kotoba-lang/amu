from pathlib import Path
import json,subprocess,os,hashlib,re
D=Path(__file__).parent;pr=json.loads((D/'preregistration.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();C=D/'host-feature-loader.c'
assert sha(D/'baseline-loader.c')==pr['baselineLoaderSHA256']
(D/'actual-host.stdout').write_text(subprocess.check_output(['sysctl','hw.optional.arm.FEAT_CRC32','hw.optional.arm.FEAT_AES'],text=True));(D/'clang-version.stdout').write_text(subprocess.check_output(['clang','--version'],text=True));(D/'uname.stdout').write_text(subprocess.check_output(['uname','-a'],text=True))
code=bytes.fromhex('000080d2c0035fd6');trap=bytes.fromhex('000020d4c0035fd6');(D/'guest.bin').write_bytes(code)
def header(mask=None,isa='aarch64',raw=code):
 h='#define KEXE_EMBEDDED 1\n'
 if mask is not None:h+=f'#define KEXE_EMBEDDED_REQUIRED_HOST_FEATURES {mask}ULL\n'
 vals={'OFFSET':'0u','ARITY':'0u','ISA':json.dumps(isa),'ALLOW':'"-"','SCOPE35':'""','SCOPE34':'""','SPAWN_PROGRAMS':'""','SPAWN_ENV':'""','SPAWN_PATH_LOOKUP':'0','STRING_POOL':'4096u','FUEL':'100u','PAIRS':'32u','VECTORS':'32u','VECTOR_ITEMS':'128u','CPU_SECONDS':'2u','WALL_SECONDS':'3u'}
 for k,v in vals.items():h+=f'#define KEXE_EMBEDDED_{k} {v}\n'
 h+='static const unsigned char kexe_embedded_code[] = {'+','.join(str(x) for x in raw)+'};\n'
 return h
builds=[];runs=[]
def build(name,mask=0,isa='aarch64',raw=code,test=True,source=C,nonembedded=False):
 p=D/name;p.mkdir(exist_ok=False);h=p/'embedded.h'
 args=['clang','-O2','-std=c11']
 if nonembedded:
  if mask:args+=['-DKEXE_EMBEDDED_REQUIRED_HOST_FEATURES='+str(mask)]
 else:h.write_text(header(mask,isa,raw));args+=['-include',str(h)]
 if test:args+=['-DKEXE_HOST_GATE_TEST=1']
 args+=[str(source)]
 if test:args+=[str(D/'test-host-detection.c')]
 args+=['-o',str(p/'loader')]
 q=subprocess.run(args,text=True,capture_output=True);(p/'build.stdout').write_text(q.stdout);(p/'build.stderr').write_text(q.stderr);(p/'build.status.json').write_text(json.dumps({'exit':q.returncode,'args':args},indent=2)+'\n');builds.append({'name':name,'exit':q.returncode,'sourceSHA256':sha(source),'headerSHA256':sha(h) if h.exists() else None,'binarySHA256':sha(p/'loader') if (p/'loader').exists() else None})
 if nonembedded and mask:assert q.returncode!=0 and 'nonempty_required_host_features_are_embedded_only' in q.stderr
 else:assert q.returncode==0,q.stderr
 return p

def run(p,name,env=None,refuse=False,stages=True,args=None,markerMissing=False):
 environ=dict(os.environ)
 if env:environ.update(env)
 q=subprocess.run([str(p/'loader')]+(args or []),text=True,capture_output=True,timeout=15,env=environ);(p/(name+'.stdout')).write_text(q.stdout);(p/(name+'.stderr')).write_text(q.stderr)
 seen=[x for x in ['RX','FORK','ENTRY'] if 'HG_STAGE '+x+'\n' in q.stderr]
 if refuse:assert q.returncode==2 and 'host feature gate refused:' in q.stderr and not seen,(p,q.returncode,q.stderr)
 else:
  assert q.returncode==0,(p,q.returncode,q.stderr)
  if stages:assert seen==['RX','FORK','ENTRY'],seen
 row={'variant':p.name,'case':name,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr,'stages':seen,'refusedBeforeGuestRXForkEntry':refuse and not seen,'environmentFaults':env or {}};runs.append(row);(p/(name+'.status.json')).write_text(json.dumps(row,indent=2)+'\n');return row
# Actual production detection and exclusive loader contract, all feature subsets.
for mask in range(8):
 p=build('actual-'+str(mask),mask);run(p,'actual')
p=build('default-omitted',None);run(p,'default')
# No normal-binary test hook; forged sysctl-fault env not authoritative.
p=build('production-all',7,test=False);run(p,'actual',stages=False,env={'HG_TEST_FAULT':'error','KEXE_REQUIRED_HOST_FEATURES':'0'})
p=build('unknown-bit',8);run(p,'unknown',refuse=True);(p/'loader.features.json').write_text('{"requiredHostFeatures":0,"availableHostFeatures":18446744073709551615}')
run(p,'forged-sidecar-env',refuse=True,env={'KEXE_REQUIRED_HOST_FEATURES':'0','KEXE_HOST_FEATURES':'18446744073709551615'})
p=build('unknown-no-entry-marker',8,raw=trap);run(p,'refused-no-marker',refuse=True,markerMissing=True)
p=build('isa-mismatch',7,isa='x86_64');run(p,'isa',refuse=True)
for mask in [1,2]:
 p=build('fault-'+str(mask),mask)
 for fault in ['unsupported','error','short','badvalue']:
  run(p,fault,refuse=True,env={'HG_TEST_FAULT':fault})
p=build('raw-default',0,nonembedded=True);(D/'guest.bin.features.json').write_text('{"requiredHostFeatures":7,"fuelExclusiveWriter":true}')
run(p,'forged-metadata-ignored',args=[str(D/'guest.bin'),'0','0','aarch64','-'],env={'KEXE_REQUIRED_HOST_FEATURES':'7','KEXE_HOST_FEATURES':'7'})
build('raw-nonempty-compile-refusal',4,nonembedded=True)
# Actual source mutation: remove gate, unknown required mask now reaches all stages.
m=D/'mutant-skip-gate.c';s=C.read_text();assert s.count('  if(!kexe_embedded_host_gate(KEXE_EMBEDDED_ISA))return 2;')==1;m.write_text(s.replace('  if(!kexe_embedded_host_gate(KEXE_EMBEDDED_ISA))return 2;','  /* mutant omitted early host gate */'))
p=build('mutant-skip-gate',8,source=m);z=run(p,'unsafe-reached-guest');assert z['stages']==['RX','FORK','ENTRY']
# Bind unchanged context declaration and source exactly once added gate call earliest.
b=D/'baseline-loader.c'
def struct(s):return re.search(r'struct kexe_context_v11 \{.*?\n\};',s,re.S)[0]
assert struct(b.read_text())==struct(C.read_text())
assert len(builds)<=40 and len(runs)<=64
report={'status':'PASS_EMBEDDED_ONLY_HOST_FEATURE_GATE_NATIVE_CONTROLS','builds':builds,'runs':runs,'actualHost':(D/'actual-host.stdout').read_text(),'contextStructExact':True,'wireChanges':False,'normalBinaryFaultEnvIgnored':True,'rawNonemptyCompileRefused':True,'rawForgedMetadataDoesNotAttestAnything':True,'gateOmissionMutationDetected':True,'noFastcounterRewrite':True,'timingExecuted':False,'productChanged':False,'producerIntegrated':False,'trust':'Production path actualsysctl. Testhook/instrumented native controls separate; normalbinary compiledwithouttestmacro. Fuelownership only THISembeddedloader implementation; no claim arbitraryembeddingABI.'}
(D/'controls-report.json').write_text(json.dumps(report,indent=2)+'\n');print('CONTROL PASS',len(builds),len(runs),sha(C))
