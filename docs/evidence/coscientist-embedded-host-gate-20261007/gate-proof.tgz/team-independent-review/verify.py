from pathlib import Path
import json,hashlib,re
D=Path(__file__).parent.parent;O=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=(D/'host-feature-loader.c').read_text();b=(D/'baseline-loader.c').read_text();pr=json.loads((D/'preregistration.json').read_text())
assert sha(D/'baseline-loader.c')==pr['baselineLoaderSHA256']
start=s.index('/* Experimental embedded-only immutable host-feature contract.')
end=s.index('int main(int argc, char **argv)',start)
x=s[:start]+s[end:]
# Author inserted a leading newline before gate block.
assert x.count('\n\nint main')==1
x=x.replace('\n\nint main','\nint main',1)
x=x.replace('#ifdef KEXE_EMBEDDED\n  if(!kexe_embedded_host_gate(KEXE_EMBEDDED_ISA))return 2;\n#endif\n','',1)
for stage in ['RX','FORK','ENTRY']:
 assert x.count('  HG_STAGE("'+stage+'");\n')==1
 x=x.replace('  HG_STAGE("'+stage+'");\n','',1)
assert x==b,'non-gate baseline delta'
call='  if(!kexe_embedded_host_gate(KEXE_EMBEDDED_ISA))return 2;'
def early(z):
 main=z[z.index('int main(int argc, char **argv) {'):]
 return main.startswith('int main(int argc, char **argv) {\n#ifdef KEXE_EMBEDDED\n'+call+'\n#endif\n  kexe_decisions_init();')
assert early(s)
assert '#error nonempty_required_host_features_are_embedded_only' in s
block=s[start:end]
assert 'getenv(' not in block and 'argv[' not in block
assert 'required & ~KEXE_HF_KNOWN' in block
assert 'status!=0 || length!=sizeof value || (value!=0 && value!=1)' in block
assert 'sysctlbyname(name,&value,&length,NULL,0)' in block
assert '#else\n  (void)name;\n  return -1;' in block
assert block.count('hw.optional.arm.FEAT_CRC32')==1 and block.count('hw.optional.arm.FEAT_AES')==1
assert s.index(call)<s.index('  kexe_decisions_init();',s.index('int main'))
mutants=[s.replace(call,'/* omitted */'),s.replace(call,'/* moved */').replace('  kexe_decisions_init();','  kexe_decisions_init();\n'+call,1),s.replace('if(!kexe_embedded_host_gate','if(kexe_embedded_host_gate',1)]
assert all(not early(m) for m in mutants)
controls=json.loads((D/'controls-report.json').read_text());runproof=[]
for v in controls['builds']:
 p=D/v['name'];r=json.loads((p/'build.status.json').read_text())
 assert r['exit']==v['exit']
 if v['headerSHA256']:assert sha(p/'embedded.h')==v['headerSHA256']
 if v['binarySHA256']:assert sha(p/'loader')==v['binarySHA256']
 assert '-include' in r['args'] or v['name'].startswith('raw-')
 if v['name']=='production-all':assert not any('KEXE_HOST_GATE_TEST' in a for a in r['args'])
for r in controls['runs']:
 p=D/r['variant'];name=r['case']
 assert (p/(name+'.stdout')).read_text()==r['stdout']
 assert (p/(name+'.stderr')).read_text()==r['stderr']
 assert json.loads((p/(name+'.status.json')).read_text())==r
 seen=re.findall(r'HG_STAGE (RX|FORK|ENTRY)\n',r['stderr']);assert seen==r['stages']
 if r['refusedBeforeGuestRXForkEntry']:assert r['exit']==2 and not seen and 'host feature gate refused:' in r['stderr']
 runproof.append({'variant':r['variant'],'case':name,'exit':r['exit'],'stages':seen})
# Fuel writes and handlers are entirely baseline-identical by exact reversal.
assert s.count('shared->context.fuel = kexe_initial_fuel;')==1
assert s.index('shared->context.fuel = kexe_initial_fuel;')<s.index('  pid_t child = fork();')
assert 'siglongjmp(' not in s and 'pthread_create(' not in s
normal=json.loads((D/'production-unknown/report.json').read_text())
assert normal['exit']==2 and normal['stdout']=='' and 'unknown required feature' in normal['stderr']
assert (D/'production-unknown/run.stderr').read_text()==normal['stderr']
assert sha(D/'production-unknown/loader')==normal['binarySHA256']
assert (D/'production-unknown/build.exit').read_text().strip()=='0'
assert normal['sourceSHA256']==sha(D/'host-feature-loader.c')
assert normal['headerSHA256']==sha(D/'production-unknown/embedded.h')
owner=json.loads((D/'artifact-pins.json').read_text())
assert isinstance(owner,list)
for row in owner:
 rel=row['path'];assert (D/rel).stat().st_size==row['bytes'] and sha(D/rel)==row['sha256'],rel
out={'status':'PASS independent frozen-source and retained-native-receipt review','baselineSHA256':sha(D/'baseline-loader.c'),'sourceSHA256':sha(D/'host-feature-loader.c'),'ownerPinsChecked':len(owner),'ownerPinsSHA256':sha(D/'artifact-pins.json'),'ownerReportSHA256':sha(D/'report.json'),'ownerPreregistrationSHA256':sha(D/'preregistration.json'),'buildsChecked':len(controls['builds'])+1,'rawRunsChecked':len(runproof)+1,'productionUnknownControl':True,'sourceReverseExact':True,'earlyGateSourceMutantsDetected':3,'runs':runproof,'newNativeRuns':0,'newSolverRuns':0,'timing':False,'fuelClaim':'Only one supervised child process writes guest fuel after loader initialization. Parent callbacks/brokers use separate decision context, guest callbacks and terminating signal handlers remain exact baseline. This token does not establish arbitrary guest stores or unknown/reentrant callbacks cannot alter fuel, nor authorize batching/elision or deferred publication.','adoptionBlockers':['Producer required-feature generation/binding/provenance integration absent','No product native feature gate integration or unsupported-platform CPU detection','Fuel optimization requires separate actual compiler/call/effect/publication proof; current token alone insufficient','CPU capability admission controls execute trivial guest, not crypto ISA semantic validation'],'trustBoundary':'Trusted loader/header/compiler/OS. Header freezes declaration with guest bytes but does not prove declaration completeness. Raw v11 and forged sidecars attest nothing. Owner native receipts independently byte checked; no fresh native execution.'}
(O/'report.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'ownerPins':len(owner),'builds':out['buildsChecked'],'rawRuns':out['rawRunsChecked']}))
