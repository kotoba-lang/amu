
#include <sys/sysctl.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
int hg_test_sysctl(const char *name,void *value,size_t *length,const void *newvalue,size_t newlength){
 const char *fault=getenv("HG_TEST_FAULT");
 if(!fault || !*fault)return sysctlbyname(name,value,length,newvalue,newlength);
 if(strcmp(fault,"error")==0){errno=EIO;return -1;}
 if(strcmp(fault,"short")==0){*length=1;return 0;}
 if(strcmp(fault,"unsupported")==0){*(int*)value=0;return 0;}
 if(strcmp(fault,"badvalue")==0){*(int*)value=2;return 0;}
 errno=EINVAL;return -1;
}
