from pathlib import Path
import json,hashlib
D=Path(__file__).parent;pr=json.loads((D/'preregistration.json').read_text());R=Path(pr['baselineLoader']);assert hashlib.sha256(R.read_bytes()).hexdigest()==pr['baselineLoaderSHA256'];s=R.read_text();(D/'baseline-loader.c').write_text(s)
gate=r'''
/* Experimental embedded-only immutable host-feature contract. The required
 * mask and kexe_embedded_code arrive in one compiled immutable header.
 * This does not extend generic context ABI v11 or trust raw sidecars. */
#define KEXE_HF_CRC32 UINT64_C(1)
#define KEXE_HF_AES UINT64_C(2)
#define KEXE_HF_FUEL_EXCLUSIVE UINT64_C(4)
#define KEXE_HF_KNOWN (KEXE_HF_CRC32 | KEXE_HF_AES | KEXE_HF_FUEL_EXCLUSIVE)
#ifndef KEXE_EMBEDDED_REQUIRED_HOST_FEATURES
#define KEXE_EMBEDDED_REQUIRED_HOST_FEATURES 0
#endif
#ifndef KEXE_EMBEDDED
#if KEXE_EMBEDDED_REQUIRED_HOST_FEATURES != 0
#error nonempty_required_host_features_are_embedded_only
#endif
#endif
#if defined(__APPLE__)
#include <sys/sysctl.h>
#endif
#ifdef KEXE_HOST_GATE_TEST
#define HG_STAGE(name) ((void)write(STDERR_FILENO, "HG_STAGE " name "\n", sizeof("HG_STAGE " name "\n")-1))
#else
#define HG_STAGE(name) ((void)0)
#endif
#ifdef KEXE_EMBEDDED
static const uint64_t kexe_required_host_features = (uint64_t)KEXE_EMBEDDED_REQUIRED_HOST_FEATURES;
static int kexe_host_feature_refuse(const char *reason) {
  fprintf(stderr,"kexe-command: host feature gate refused: %s\n",reason);
  return 0;
}
static int kexe_host_cpu_feature(const char *name) {
#if defined(__APPLE__) && defined(__aarch64__)
  int value=0;size_t length=sizeof value;
#ifdef KEXE_HOST_GATE_TEST
  /* Test-only host-detection fault boundary. Not present in normal binaries. */
  extern int hg_test_sysctl(const char *,void *,size_t *,const void *,size_t);
  int status=hg_test_sysctl(name,&value,&length,NULL,0);
#else
  int status=sysctlbyname(name,&value,&length,NULL,0);
#endif
  if(status!=0 || length!=sizeof value || (value!=0 && value!=1))return -1;
  return value;
#else
  (void)name;
  return -1;
#endif
}
static int kexe_embedded_host_gate(const char *isa) {
  const uint64_t required=kexe_required_host_features;
#if defined(__aarch64__)
  if(strcmp(isa,"aarch64")!=0)return kexe_host_feature_refuse("isa mismatch");
#elif defined(__x86_64__)
  if(strcmp(isa,"x86_64")!=0)return kexe_host_feature_refuse("isa mismatch");
#else
  return kexe_host_feature_refuse("unsupported host isa");
#endif
  if((required & ~KEXE_HF_KNOWN)!=0)return kexe_host_feature_refuse("unknown required feature");
  if((required & (KEXE_HF_CRC32|KEXE_HF_AES))!=0 && strcmp(isa,"aarch64")!=0)
    return kexe_host_feature_refuse("cpu feature isa mismatch");
  if((required & KEXE_HF_CRC32)!=0){
    int supported=kexe_host_cpu_feature("hw.optional.arm.FEAT_CRC32");
    if(supported<0)return kexe_host_feature_refuse("crc32 detection error");
    if(!supported)return kexe_host_feature_refuse("crc32 unavailable");
  }
  if((required & KEXE_HF_AES)!=0){
    int supported=kexe_host_cpu_feature("hw.optional.arm.FEAT_AES");
    if(supported<0)return kexe_host_feature_refuse("aes detection error");
    if(!supported)return kexe_host_feature_refuse("aes unavailable");
  }
  /* FUEL_EXCLUSIVE is a versioned claim about THIS embedded loader:
   * context initialized before its one supervised child, parent normal paths
   * read fuel only, installed fault/trap handlers terminate instead of resume.
   * It must not be inferred from v11 or used to attest an arbitrary embedding.
   * No current guest-code rewrite consumes this feature; producer unintegrated. */
  return 1;
}
#endif
'''
pos=s.index('int main(int argc, char **argv)');s=s[:pos]+gate+s[pos:]
s=s.replace('int main(int argc, char **argv) {\n  kexe_decisions_init();','int main(int argc, char **argv) {\n#ifdef KEXE_EMBEDDED\n  if(!kexe_embedded_host_gate(KEXE_EMBEDDED_ISA))return 2;\n#endif\n  kexe_decisions_init();')
s=s.replace('  if (mprotect(memory, mapped, PROT_READ | PROT_EXEC) != 0) fail("mprotect RX");','  HG_STAGE("RX");\n  if (mprotect(memory, mapped, PROT_READ | PROT_EXEC) != 0) fail("mprotect RX");')
s=s.replace('  pid_t child = fork();','  HG_STAGE("FORK");\n  pid_t child = fork();')
s=s.replace('  int64_t result;\n  if (strcmp(isa, "x86_64") == 0)', '  int64_t result;\n  HG_STAGE("ENTRY");\n  if (strcmp(isa, "x86_64") == 0)')
assert s.count('HG_STAGE("RX")')==1 and s.count('HG_STAGE("FORK")')==1 and s.count('HG_STAGE("ENTRY")')==1
(D/'host-feature-loader.c').write_text(s)
# fault shim default delegates to actual sysctl; overrides are test-binary only.
(D/'test-host-detection.c').write_text(r'''
#include <sys/sysctl.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
int hg_test_sysctl(const char *name,void *value,size_t *length,const void *newvalue,size_t newlength){
 const char *fault=getenv("HG_TEST_FAULT");
 if(!fault || !*fault)return sysctlbyname(name,value,length,newvalue,newlength);
 if(strcmp(fault,"error")==0){errno=EIO;return -1;}
 if(strcmp(fault,"short")==0){*length=1;return 0;}
 if(strcmp(fault,"unsupported")==0){*(int*)value=0;return 0;}
 if(strcmp(fault,"badvalue")==0){*(int*)value=2;return 0;}
 errno=EINVAL;return -1;
}
''')
print('SOURCE',hashlib.sha256((D/'host-feature-loader.c').read_bytes()).hexdigest())
