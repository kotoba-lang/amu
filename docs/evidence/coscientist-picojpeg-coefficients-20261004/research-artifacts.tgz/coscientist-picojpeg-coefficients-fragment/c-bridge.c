/* BOOTSTRAP-TOOL: actual pre-transform snapshots; original transforms retained. */
#define observe observe_headers
#include "headers-bridge.c"
#undef observe
static const int coef_fields[]={1536,1537,1538,1539,1540,1541,1542,1543,1544,1545,1546,1547,1548,1549,1550,1551,1552,1553,1554,1555,1556,1557,1558,1559,1560,1561,1562,1563,1564,1565,1566,1567,1568,1569,1570,1571,1572,1573,1574,1575,1576,1577,1578,1579,1580,1581,1582,1583,1584,1585,1586,1587,1588,1589,1590,1591,1592,1593,1594,1595,1596,1597,1598,1599,1510,1511,1512,256,257,258,259,260,261,262,1413,1520,1610};
static int64_t saved[168][sizeof(coef_fields)/sizeof(coef_fields[0])],buffers[168][256];
static int captures,currentBlock;
static int64_t coef_value(int cell){if(cell>=1536&&cell<1600)return gCoeffBuf[cell-1536];if(cell==1610)return currentBlock;return cellvalue(cell);}
static void capture(int block){currentBlock=block;for(unsigned i=0;i<sizeof(coef_fields)/sizeof(coef_fields[0]);i++)saved[captures][i]=coef_value(coef_fields[i]);for(int i=0;i<256;i++)buffers[captures][i]=gInBuf[i];captures++;}
static uint8 observed_decode(void){

  uint8 status;
  uint8 mcuBlock;

  if (gRestartInterval)
    {
      if (gRestartsLeft == 0)
	{
	  status = processRestart ();
	  if (status)
	    return status;
	}
      gRestartsLeft--;
    }

  for (mcuBlock = 0; mcuBlock < gMaxBlocksPerMCU; mcuBlock++)
    {
      uint8 componentID = gMCUOrg[mcuBlock];
      uint8 compQuant = gCompQuant[componentID];
      uint8 compDCTab = gCompDCTab[componentID];
      uint8 numExtraBits, compACTab, k;
      const int16 *pQ = compQuant ? gQuant1 : gQuant0;
      uint16 r, dc;

      uint8 s =
	huffDecode (compDCTab ? &gHuffTab1 : &gHuffTab0,
		    compDCTab ? gHuffVal1 : gHuffVal0);

      r = 0;
      numExtraBits = s & 0xF;
      if (numExtraBits)
	r = getBits2 (numExtraBits);
      dc = huffExtend (r, s);

      dc = dc + gLastDC[componentID];
      gLastDC[componentID] = dc;

      gCoeffBuf[0] = dc * pQ[0];

      compACTab = gCompACTab[componentID];

      if (gReduce)
	{
	  // Decode, but throw out the AC coefficients in reduce mode.
	  for (k = 1; k < 64; k++)
	    {
	      s =
		huffDecode (compACTab ? &gHuffTab3 : &gHuffTab2,
			    compACTab ? gHuffVal3 : gHuffVal2);

	      numExtraBits = s & 0xF;
	      if (numExtraBits)
		getBits2 (numExtraBits);

	      r = s >> 4;
	      s &= 15;

	      if (s)
		{
		  if (r)
		    {
		      if ((k + r) > 63)
			return PJPG_DECODE_ERROR;

		      k = (uint8) (k + r);
		    }
		}
	      else
		{
		  if (r == 15)
		    {
		      if ((k + 16) > 64)
			return PJPG_DECODE_ERROR;

		      k += (16 - 1);	// - 1 because the loop counter is k
		    }
		  else
		    break;
		}
	    }

	  transformBlockReduce (mcuBlock);
	}
      else
	{
	  // Decode and dequantize AC coefficients
	  for (k = 1; k < 64; k++)
	    {
	      uint16 extraBits;

	      s =
		huffDecode (compACTab ? &gHuffTab3 : &gHuffTab2,
			    compACTab ? gHuffVal3 : gHuffVal2);

	      extraBits = 0;
	      numExtraBits = s & 0xF;
	      if (numExtraBits)
		extraBits = getBits2 (numExtraBits);

	      r = s >> 4;
	      s &= 15;

	      if (s)
		{
		  int16 ac;

		  if (r)
		    {
		      if ((k + r) > 63)
			return PJPG_DECODE_ERROR;

		      while (r)
			{
			  gCoeffBuf[ZAG[k++]] = 0;
			  r--;
			}
		    }

		  ac = huffExtend (extraBits, s);

		  gCoeffBuf[ZAG[k]] = ac * pQ[k];
		}
	      else
		{
		  if (r == 15)
		    {
		      if ((k + 16) > 64)
			return PJPG_DECODE_ERROR;

		      for (r = 16; r > 0; r--)
			gCoeffBuf[ZAG[k++]] = 0;

		      k--;	// - 1 because the loop counter is k
		    }
		  else
		    break;
		}
	    }

	  while (k < 64)
	    gCoeffBuf[ZAG[k++]] = 0;

	  capture(mcuBlock);
  transformBlock (mcuBlock);
	}
    }

  return 0;

}
static int prepare_coefficients(void){stages(3);captures=0;currentBlock=0;if(lastStatus||gReduce||gRestartInterval||gMaxBlocksPerMCU!=3||gNumMCUSRemaining!=56)return 0;
 pInfo.m_pMCUBufR=gMCUBufR;pInfo.m_pMCUBufG=gMCUBufG;pInfo.m_pMCUBufB=gMCUBufB;
 while(gNumMCUSRemaining){lastStatus=observed_decode();if(lastStatus)return 0;gNumMCUSRemaining--;}lastStatus=pjpeg_decode_mcu();return captures==168&&lastStatus==PJPG_NO_MORE_BLOCKS&&verify_benchmark(0);}
int64_t observe(int64_t encoded,EXTRA){int n=encoded/2048,cell=encoded%2048;if(encoded<0||n>169)return INT64_MIN;if(n==0){stages(3);return coef_value(cell);}if(!prepare_coefficients())return INT64_MIN;
 if(n==169)return coef_value(cell);if(cell>=0&&cell<256)return buffers[n-1][cell];for(unsigned i=0;i<sizeof(coef_fields)/sizeof(coef_fields[0]);i++)if(cell==coef_fields[i])return saved[n-1][i];return INT64_MIN;}
int64_t coefficient_oracle_selfcheck(int64_t n,EXTRA){if(n<1||n>32||!prepare_coefficients())return 0;int64_t state[268];int cells[268];int k=0;for(int i=0;i<263;i++)cells[k++]=i;for(int i=1510;i<1513;i++)cells[k++]=i;cells[k++]=1413;cells[k++]=1520;
 for(int i=0;i<k;i++)state[i]=coef_value(cells[i]);unsigned char r[256],g[256],b[256];memcpy(r,gMCUBufR,256);memcpy(g,gMCUBufG,256);memcpy(b,gMCUBufB,256);
 benchmark_body(1,n);lastStatus=pjpeg_decode_mcu();if(!verify_benchmark(0)||lastStatus!=PJPG_NO_MORE_BLOCKS)return 0;for(int i=0;i<k;i++)if(state[i]!=coef_value(cells[i]))return 0;
 return memcmp(r,gMCUBufR,256)==0&&memcmp(g,gMCUBufG,256)==0&&memcmp(b,gMCUBufB,256)==0;}
