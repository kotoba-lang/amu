#include "c-bridge.c"
#include <stdio.h>
int main(void){unsigned reads=0;for(int n=1;n<=32;n++)if(coefficient_oracle_selfcheck(n,0,0,0,0,0,0,0)!=1)return 1;
 for(int n=1;n<=168;n++)for(unsigned i=0;i<sizeof(coef_fields)/sizeof(coef_fields[0]);i++){if(observe(n*2048+coef_fields[i],0,0,0,0,0,0,0)==INT64_MIN)return 2;reads++;}
 for(int n=0;n<6;n++){int prefixes[]={1,3,4,84,165,168};for(int cell=0;cell<256;cell++){if(observe(prefixes[n]*2048+cell,0,0,0,0,0,0,0)==INT64_MIN)return 3;reads++;}}
 for(int cell=0;cell<263;cell++){if(observe(169*2048+cell,0,0,0,0,0,0,0)==INT64_MIN)return 4;reads++;}for(int cell=1510;cell<1513;cell++){if(observe(169*2048+cell,0,0,0,0,0,0,0)==INT64_MIN)return 5;reads++;}reads+=2;if(observe(169*2048+1413,0,0,0,0,0,0,0)||observe(169*2048+1520,0,0,0,0,0,0,0)!=1)return 6;
 printf("PASS 32 original full-decoder/entropy/RGB selfchecks, %u initialized coefficient/state reads\n",reads);return 0;}
