from pathlib import Path
import subprocess,os,re,json
w=Path('/private/tmp/amu-tail-continuation-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');ns={};exec((w/'fixture-proof.py').read_text().split('env=dict(')[0],ns);m=ns['m'];fns=ns['fns'];sir=ns['sir'];frec=ns['frec'];typeform=ns['typeform'];target=fns['tc_target'];caller=fns['tc_identity'];identity=fns['tc_id'];start=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==caller);ci=next(i for i,x in enumerate(sir,1) if i>start and x[0]==m.C['OP-CALL'] and x[1]==target);p=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==identity);end=next(i for i,x in enumerate(sir,1) if i>p and x[0]==m.C['OP-END']);checks=[];metas=[]
for j in list(range(p,end+1))+[ci+1,ci+2]:
 for fld in range(4):checks.append(m.C['MM-SIR-BASE']+j*m.C['MM-SIR-W']+fld)
for f in [identity,caller,target]:
 fields=['FF-SIR','FF-RTYPE']+(['FF-NPARAMS','FF-NSLOTS','FF-DEPTH','FF-PT0'] if f==identity else ['FF-NPARAMS'] if f==target else [])
 metas += [m.C['MM-FN-BASE']+f*m.C['MM-FN-W']+m.C[fld] for fld in fields]

join=fns['tc_join'];jp=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==join);ji=next(i for i,x in enumerate(sir,1) if i>jp and x[0]==m.C['OP-CALL'] and x[1]==target);branch=ji+1;label=sir[branch-1][1];lp=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-LABEL'] and x[1]==label);joinchecks=[m.C['MM-SIR-BASE']+j*m.C['MM-SIR-W']+fld for j in [branch,lp,lp+1,lp+2] for fld in range(4)]
probe=f'''(defn- t-tail-mut [M :vector-i64 at :i64] :bool
 (let [old (vector-at M at) MM (t-put M at (inc old)) got (gn-tail-continuation MM {ci} {target} 0 3)
       restore (t-put MM at old)] (not got)))
(defn- t-tail-open [M :vector-i64 f :i64] :bool
 (let [old (gn-g M gn-g-open) old_n (gn-g M gn-g-open-n)
       set (-> M (gn-gs gn-g-open f) (gn-gs gn-g-open-n 1)) got (gn-tail-continuation set {ci} {target} 0 3)
       restore (-> set (gn-gs gn-g-open old) (gn-gs gn-g-open-n old_n))] (not got)))
(defn- t-tail-join-mut [M :vector-i64 at :i64] :bool
 (let [old (vector-at M at) MM (t-put M at (inc old)) got (gn-tail-continuation MM {ji} {target} 0 3)
       restore (t-put MM at old)] (not got)))
(defn- t-tail-duplicate [M :vector-i64] :bool
 (let [at (+ MM-SIR-BASE (* {p+1} MM-SIR-W)) old_op (vector-at M at) old_a (vector-at M (+ at 1))
       set (-> M (t-put at OP-LABEL) (t-put (+ at 1) {label})) got (gn-tail-continuation set {ji} {target} 0 3)
       restore (-> set (t-put at old_op) (t-put (+ at 1) old_a))] (not got)))
(defn- t-tail-foreign [M :vector-i64] :bool
 (let [at (+ MM-SIR-BASE (* {branch} MM-SIR-W) IF-A) old (vector-at M at)
       set (t-put M at {ns['labels']['sum_h']}) got (gn-tail-continuation set {ji} {target} 0 3)
       restore (t-put set at old)] (not got)))
(defn- t-tail-cycle [M :vector-i64] :bool
 (let [at (+ MM-SIR-BASE (* {lp+2} MM-SIR-W)) old_op (vector-at M at) old_a (vector-at M (+ at 1))
       set (-> M (t-put at OP-BR) (t-put (+ at 1) {label})) got (gn-tail-continuation set {ji} {target} 0 3)
       restore (-> set (t-put at old_op) (t-put (+ at 1) old_a))] (not got)))
(defn- t-tail-guards [M :vector-i64] :bool
 (and (gn-tail-continuation M {ci} {target} 0 3)
      {' '.join('(t-tail-mut M '+str(at)+')' for at in checks+metas)}
      (gn-tail-continuation M {ji} {target} 0 3)
      {' '.join('(t-tail-join-mut M '+str(at)+')' for at in joinchecks)}
      (t-tail-duplicate M) (t-tail-foreign M) (t-tail-cycle M)
      (t-tail-open M {identity}) (t-tail-open M {caller}) (t-tail-open M {target})))
'''
text=m.kotoba(True).replace('(defn- seed-main [] :i64',typeform+probe+'(defn- seed-main [] :i64').replace('        M1 (gn-run M0)','        M1 (gn-run (t-tail-types M0))').replace('(if (and mask_shared','(if (and (t-tail-guards M1) mask_shared')
parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];src=w/'mutation-probe.kotoba';src.write_text('\n'.join((r/x).read_text() for x in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+text);env=dict(os.environ,KEXE_COMMAND='1',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/'mutation-probe.kseed')]),('extract',['extract-native',str(w/'mutation-probe.kseed'),'--symbol','main','--output',str(w/'mutation-probe.bin')])]:
 q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/('mutation-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(stage,q.stdout[-400:],q.stderr)
 if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
q=subprocess.run([str(w/'kexe-loader'),str(w/'mutation-probe.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/'mutation-probe.stdout').write_text(q.stdout+q.stderr);assert q.returncode==0,(q.stdout[-300:],q.stderr)
(w/'mutation-proof.json').write_text(json.dumps({'status':'complete-native-positive-and-field-metadata-open-refusal-controls','instructionFieldMutations':len(checks)+len(joinchecks),'ownedDuplicateForeignCycleRefusals':3,'metadataMutations':len(metas),'openRefusals':3,'positiveControl':True,'mutatedAddresses':checks+metas+joinchecks,'prototypeChanged':False},indent=2)+'\n');print('PASS native guards',len(checks)+len(joinchecks),len(metas),3,flush=True)
