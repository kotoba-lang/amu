from pathlib import Path
import json,importlib.util,subprocess,os,re,hashlib,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-tail-continuation-20261006');raw=(r/'scripts/seed/a64gen-fixtures.py').read_text();raw=raw.replace("R = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))", "R = '/Users/junkawasaki/github/wt/amu-seed17'",1);(w/'frozen-fixtures.py').write_text(raw);sp=importlib.util.spec_from_file_location('fx',w/'frozen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);oldcount=len(m.FIX)
m.fx('tc_id',1,1,[('LGET',0,1),('RET',0)])
m.fx('tc_charged_id',1,1,[('FUEL',),('LGET',0,1),('RET',0)])
m.fx('tc_target',3,3,[('FUEL',),('LGET',0,1),('LGET',1,2),('BIN','BOP-MUL',0),('LGET',1,3),('BIN','BOP-ADD',0),('RET',0)])
arg=[('LGET',0,3),('LGET',1,1),('LGET',2,2),('CALL','tc_target',0,3)]
m.fx('tc_identity',3,3,[('FUEL',)]+arg+[('CALL','tc_id',0,1),('RET',0)])
m.fx('tc_join',4,4,[('FUEL',),('LGET',0,4),('BRZ',0,'tc_else')]+arg+[('BR','tc_join_exit'),('LABEL','tc_else'),('CONST',0,27),('CALL','tc_id',0,1),('LABEL','tc_join_exit'),('CALL','tc_id',0,1),('RET',0)])
m.fx('tc_charged',3,3,[('FUEL',)]+arg+[('CALL','tc_charged_id',0,1),('RET',0)])
m.fx('tc_fuel',3,3,[('FUEL',)]+arg+[('FUEL',),('CALL','tc_id',0,1),('RET',0)])
m.fx('tc_trap',3,3,[('FUEL',)]+arg+[('TRAP',7),('CALL','tc_id',0,1),('RET',0)])
m.fx('tc_change',3,3,[('FUEL',)]+arg+[('CONST',0,42),('CALL','tc_id',0,1),('RET',0)])
fns,labels,lits,sir,frec=m.layout_tables();ids=[fns[x[0]] for x in m.FIX[oldcount:]];typeform='(defn- t-tail-types [M :vector-i64] :vector-i64\n (-> M '+' '.join('(t-put '+str(m.C['MM-FN-BASE']+f*m.C['MM-FN-W']+fld)+' TY-I64)' for f in ids for fld in [m.C['FF-RTYPE']]+[m.C['FF-PT0']+j for j in range(next(x[1] for x in m.FIX if fns[x[0]]==f))])+'))\n'
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');images={};parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba']
for label,gen in [('baseline','baseline-41-a64gen.kotoba'),('candidate','41-a64gen-prototype.kotoba')]:
 text=m.kotoba(True).replace('(defn- seed-main [] :i64',typeform+'(defn- seed-main [] :i64').replace('        M1 (gn-run M0)','        M1 (gn-run (t-tail-types M0))')
 src=w/(label+'-fixture.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/gen).read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+text)
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'-fixture.kseed'))]),('extract',['extract-native',str(w/(label+'-fixture.kseed')),'--symbol','main','--output',str(w/(label+'-fixture-generator.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-fixture-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-200:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'-fixture-generator.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'-fixture.stdout')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout[-300:],q.stderr);blob,offsets=m.blob_from(q.stdout);p=w/(label+'-fixture.bin');p.write_bytes(blob);images[label]=(p,offsets);print('PASS native fixture generator',label,len(blob),flush=True)
# Independent values are outputs of arithmetic, not sums of emitter instructions.
wrap=lambda x:((x+(1<<63))%(1<<64))-(1<<63)
rows=[]
for name in ['tc_identity','tc_join','tc_charged','tc_fuel','tc_trap','tc_change']:
 for a,b,c in [(3,5,7),(0,0,0),(-3,5,7),(1,-1,-1),(-(1<<63),-1,7),((1<<63)-1,2,17)]:
  for flag in ([0,1] if name=='tc_join' else [None]):
   args=[a,b,c]+([] if flag is None else [flag]);want=27 if flag==0 else 42 if name=='tc_change' else wrap(c*a+b)
   charges=1+(0 if flag==0 else 1)+(1 if name in ['tc_charged','tc_fuel'] else 0)
   for fuel in [1,2,3,4,5,16777216,(1<<53)-1]:
    obs={}
    for label,(p,offsets) in images.items():
     e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
     q=subprocess.run([str(w/'full-state-loader'),str(p),str(offsets[fns[name]]),str(len(args)),'aarch64','-']+list(map(str,args)),env=e,capture_output=True,text=True)
     obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
     success=fuel>=charges and name!='tc_trap';assert (q.returncode==0)==success,(name,args,fuel,charges,label,q.stdout,q.stderr)
     if success:assert ':result '+str(want)+' ' in q.stdout and ':remaining '+str(fuel-charges)+'}' in q.stdout,(name,args,fuel,want,label,q.stdout)
    assert obs['baseline']==obs['candidate'],(name,args,fuel,obs);rows.append({'fixture':name,'args':args,'fuel':fuel,'expected':want,'charges':charges,**obs})
 print('PASS independent result/fuel/fullstate',name,flush=True)
# Actual machine-code controls distinguish admitted terminal forwarding from refusals.
regions=[]
for name in ['tc_identity','tc_join','tc_charged','tc_fuel','tc_trap','tc_change']:
 counts={}
 for label,(p,offsets) in images.items():
  f=fns[name];data=p.read_bytes()[offsets[f]:offsets[f+1]] if f+1<len(offsets) else p.read_bytes()[offsets[f]:]
  counts[label]=sum((x[0]&0xfc000000)==0x94000000 for x in struct.iter_unpack('<I',data[:len(data)//4*4]))
 assert counts['candidate']==counts['baseline']-(1 if name in ['tc_identity','tc_join'] else 0),(name,counts);regions.append({'fixture':name,'returningBL':counts})
(w/'fixture-proof.json').write_text(json.dumps({'status':'complete-native-independent-arithmetic-fullstate-and-call-site-controls','comparisons':len(rows),'regions':regions,'originalFixturesRetained':oldcount,'totalFixtures':len(m.FIX),'images':{k:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,(p,_) in images.items()},'observations':rows},indent=2)+'\n');print('PASS',len(rows),'fullstate comparisons',flush=True)
