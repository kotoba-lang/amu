from pathlib import Path
import json,hashlib
w=Path('/private/tmp/amu-tail-continuation-20261006');old=Path('/private/tmp/amu-copy-forward-20261006/observer/meta-ports');new=w/'observer/meta-ports';rows=[]
for entry in json.loads((w/'ports-correctness.json').read_text())['entries']:
 name=entry['workload'];a=json.loads((old/name/'census.json').read_text());b=json.loads((new/name/'census.json').read_text());assert b['nativeSha256']==entry['nativeSha256'];assert a['sirCount']==b['sirCount'];assert a['functions'].keys()==b['functions'].keys();af=[z for z in (old/name/'compile.log').read_text().splitlines() if z.startswith('SIR ')];bf=[z for z in (new/name/'compile.log').read_text().splitlines() if z.startswith('SIR ')];assert af==bf
 for fn in a['functions']:
  for field in ['frameBytes','locals','depth','localCalleeRegisters','leaf','start','end']:assert a['functions'][fn][field]==b['functions'][fn][field],(name,fn,field)
 ae={x['sir']:x for x in a['events']};be={x['sir']:x for x in b['events']};sites=[]
 for i,event in ae.items():
  if event['op']!='OP-CALL' or not any(int(s,16)&0xfc000000==0x94000000 for s in event['words']):continue
  other=be[i]
  if other['words'] and int(other['words'][-1],16)&0xfc000000==0x14000000 and not any(int(s,16)&0xfc000000==0x94000000 for s in other['words']):sites.append({'sir':i,'fn':event['fn'],'oldWords':event['words'],'newWords':other['words']})
 rows.append({'workload':name,'unchangedSIR':True,'unchangedAllFrameRegisterLeafFields':True,'oldWords':a['codeWords'],'newWords':b['codeWords'],'replacedReturningCallSites':len(sites),'sites':sites,'nativeSha256':entry['nativeSha256']})
assert next(x for x in rows if x['workload']=='statemate')['replacedReturningCallSites']==201
(w/'instruction-audit.json').write_text(json.dumps({'status':'complete-all19-actual-code-sir-frame-leaf-register-and-tail-site-audit','currentV2GuestBytesEqualV1Observed':True,'staticCountsNotTimeShares':True,'rows':rows},indent=2)+'\n');print([(x['workload'],x['replacedReturningCallSites'],x['oldWords'],x['newWords']) for x in rows])
