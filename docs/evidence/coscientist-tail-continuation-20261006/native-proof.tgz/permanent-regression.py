from pathlib import Path
import importlib.util,subprocess,os,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-tail-continuation-20261006');raw=(r/'scripts/seed/a64gen-fixtures.py').read_text();needle="R = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))";frozen=w/'permanent-a64gen-fixtures.py';frozen.write_text(raw.replace(needle,"R = '/Users/junkawasaki/github/wt/amu-seed17'",1));sp=importlib.util.spec_from_file_location('fx',frozen);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];chunks=[]
for label,real in [('permanent-regression-test',False),('permanent-regression-real',True)]:
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real))
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(stage,q.stdout[-300:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0;(w/(label+'.stdout')).write_text(q.stdout);chunks.append(m.blob_from(q.stdout))
a,b=chunks;assert a[1]==b[1] and a[0][:len(b[0])]==b[0] and not any(a[0][len(b[0]):]) and 0<=len(a[0])-len(b[0])<=7
blob,fns=b;bp=w/'permanent-regression-fixture.bin';bp.write_bytes(blob);names=[f[0] for f in m.FIX];d=w/'permanent-regression-run';d.mkdir();rows=[]
for index,(name,args,expect,opts) in enumerate(m.RUNS):
 e=dict(os.environ,KEXE_CAP_RESOURCES_35=str(d));e.pop('KEXE_COMMAND',None);e.pop('KEXE_STRUCTURED_REPORT',None)
 if 'fuel' in opts:e['KEXE_FUEL']=str(opts['fuel'])
 if 'mkfile' in opts:(d/opts['mkfile'][0]).write_bytes(opts['mkfile'][1])
 if 'cmd' in opts:
  e['KEXE_COMMAND']='1';argv=[str(w/'kexe-loader'),str(bp),str(fns[names.index(name)+1]),'0','aarch64','35,37,38,39','--']+[a.replace('@OUT',str(d)) for a in opts['cmd']]
 else:argv=[str(w/'kexe-loader'),str(bp),str(fns[names.index(name)+1]),str(len(args)),'aarch64','35,37,38,39']+list(map(str,args))
 q=subprocess.run(argv,env=e,capture_output=True);so=q.stdout.decode('latin1');se=q.stderr.decode('latin1')
 if expect=='trap':good=q.returncode!=0 and b'KEXE_TRAP' in q.stderr
 elif 'cmd' in opts:good=q.returncode==(expect&255)
 else:good=q.returncode==0 and bool(so.splitlines()) and so.splitlines()[-1]==str(expect)
 if good and 'stdout' in opts:good=so.startswith(opts['stdout'])
 if good and 'file' in opts:good=(d/opts['file'][0]).exists() and (d/opts['file'][0]).read_bytes()==opts['file'][1]
 assert good,(index,name,args,expect,opts,q.returncode,so[-200:],se[-200:]);rows.append({'index':index,'fixture':name,'args':args,'expect':expect,'exit':q.returncode,'stdout':so,'stderr':se})
 if index%200==0:print('PASS native permanent-regression',index+1,flush=True)
(w/'permanent-regression-proof.json').write_text(json.dumps({'status':'complete-fresh-native-original-permanent-regression-real-test-layout','fixtures':len(m.FIX),'runs':len(rows),'realTestCodeAndLiteralBytesEqual':True,'realTestFnOffsetsEqual':True,'testOnlyPaddingBytes':len(a[0])-len(b[0]),'committedGoldenChanged':False,'frozenGeneratorSha256':hashlib.sha256(frozen.read_bytes()).hexdigest(),'observations':rows},indent=2)+'\n');print('PASS',len(rows),'original native permanent-regressions, no golden update',flush=True)
