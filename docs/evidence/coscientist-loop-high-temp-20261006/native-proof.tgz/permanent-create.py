from pathlib import Path
import shutil,importlib.util
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-loop-high-temp-20261006');g=(r/'scripts/seed/a64gen-fixtures.py').read_text();shutil.copyfile(r/'scripts/seed/a64gen-fixtures.py',w/'baseline-permanent-fixtures.py')
hand=(w/'hand-proof.py').read_text();start=hand.index("m.fx('ht_clobber'");end=hand.index('ids={');defs='HOT_CASES=[]\n'+hand[start:end].replace('m.fx(','fx(').replace('m.FIX','FIX').replace('cases','HOT_CASES')
owner=(w/'ownership-proof.py').read_text();start=owner.index('for t in [6,7,10,31]:');end=owner.index('ids={');defs+='HOT_OWN_CASES=[]\n'+owner[start:end].replace('m.fx(','fx(').replace('m.FIX','FIX').replace('cs','HOT_OWN_CASES')
defs+='''
# Pure hand model for the authored SIR (not compiler lowering or measured output).
def _hot_expect(c,handle,index,live,other,fuel):
 remaining=fuel-1;items=[11-3*j for j in range(8)]+[99]
 def charge():
  nonlocal remaining
  if remaining<1:remaining=0;return False
  remaining-=1;return True
 def read(h,ix):
  n=8 if h==1 else 1 if h==2 else 0
  return items[(0 if h==1 else 8)+ix] if 0<=ix<n else None
 prefix=s64(sum(s64((live if j%2==0 else other)+(-19+7*j)) for j in range(c['t'])));total=0
 for it in range(2 if c['mode'] in ['loop','walk'] else 1):
  if c['mode']=='beforecall' and not charge():return 'trap'
  value=77 if c['mode']=='skip' and index>=8 else read(handle,index)
  if value is None:return 'trap'
  if c['mode']=='aftercall':
   if not charge():return 'trap'
   value=s64(value+77)
  if c['mode']=='alias':
   handle=value;value=read(handle,0)
   if value is None:return 'trap'
  total=s64(total+prefix+value)
  if c['mode'] in ['loop','walk']:
   if c['mode']=='walk':index=s64(index+1)
   if not charge():return 'trap'
 return total if charge() else 'trap'
for c in HOT_CASES:
 for handle,index in [(1,0),(1,7),(1,8),(2,0),(0,0),(MIN,-1),(MAX,MAX),(1,MIN)]:
  for live,other in [(MIN,37),(37,MAX)]:
   for fuel in [1,2,3,4,16777216]:run(c['name'],[handle,index,live,other],_hot_expect(c,handle,index,live,other,fuel),fuel=fuel)
for c in HOT_OWN_CASES:
 for handle,index in [(1,0),(1,7),(1,8),(2,0),(2,1),(0,0),(MIN,0),(MAX,MAX)]:
  for live,other in [(MIN,37),(0,MAX),(37,MAX)]:
   for fuel in [1,2,3,16777216]:
    valid=fuel>=3 and ((handle==1 and 0<=index<8) or(handle==2 and index==0));value=(11-3*index if handle==1 else 99) if valid else 0;prefix=s64(sum(live if j%2==0 else other for j in range(c['t'])))
    if c['mode']=='join':prefix=s64(prefix+5) if live!=0 else s64(prefix-(live if (c['t']-1)%2==0 else other)-7)
    answer=s64(prefix+value+(value if c['mode']=='coalesced-alias' else live)) if valid else 'trap'
    run(c['caller'],[handle,index,live,other],answer,fuel=fuel)
# A cold high-depth access has no backward branch and retains the original path.
fx('ht_cold_control',0,1,[('FUEL',)]+[('CONST',j,11-3*j) for j in range(8)]+[('VEC',0,8),('LSET',1,0)]+[('CONST',j,100+j) for j in range(6)]+[('LGET',6,1),('CONST',7,0),('RT','RT-VECTOR-AT',6,2)]+[('BIN','BOP-ADD',j) for j in range(5,-1,-1)]+[('RET',0)])
run('ht_cold_control',[],626,fuel=1)

'''
needle='def kotoba(real_layout=False):';assert g.count(needle)==1;g=g.replace(needle,defs+needle,1)
needle="    clamp_fn = next(i+1 for i,x in enumerate(FIX) if x[0]=='cl_bound2')";extra="""    hot_fn = fns['ht_case_0']; cold_fn = fns['ht_cold_control']
    hot_start = next(i+1 for i,x in enumerate(sir) if x[0]==C['OP-FN'] and x[1]==hot_fn)
    cold_start = next(i+1 for i,x in enumerate(sir) if x[0]==C['OP-FN'] and x[1]==cold_fn)
    hot_i = next(i+1 for i,x in enumerate(sir) if i+1>hot_start and i+1<cold_start and x[0]==C['OP-RT'] and x[1]==C['RT-VECTOR-AT'] and x[2]==6)
    cold_i = next(i+1 for i,x in enumerate(sir) if i+1>cold_start and x[0]==C['OP-RT'])
    hot_label = labels['ht_case_0_outer']
""";assert g.count(needle)==1;g=g.replace(needle,extra+needle,1)
needle="          '        M1 (gn-run M0)',";extra="""          '        hot_guard (gn-high-loop M1 %d)' % hot_i,
          '        cold_guard (gn-high-loop M1 %d)' % cold_i,
          '        hot_limit (gn-high-loop-scan M1 %d %d %d 0)' % (hot_i,hot_i+1,hot_start),
          '        start_limit (gn-high-start M1 %d 0)' % hot_i,
          '        MH (gn-gs M1 (+ gn-a-lp %d) %d)' % (hot_label,hot_start+1),
          '        bad_label_guard (gn-high-loop MH %d)' % hot_i,
          '        MF (gn-gs MH (+ gn-a-lp %d) %d)' % (hot_label,cold_start),
          '        foreign_guard (gn-high-loop MF %d)' % hot_i,
""";assert g.count(needle)==1;g=g.replace(needle,needle+'\n'+extra,1)
needle="          '    (if (and mask_shared (not mask_single) (not mask_limit)',";extra="          '             hot_guard (not cold_guard) (not hot_limit) (= start_limit 0) (not bad_label_guard) (not foreign_guard)',";assert g.count(needle)==1;g=g.replace(needle,needle+'\n'+extra,1)
(r/'scripts/seed/a64gen-fixtures.py').write_text(g);shutil.copyfile(w/'41-a64gen-prototype.kotoba',r/'seed/41-a64gen.kotoba');print('Applied new compiler algorithm and authored fixture table; old table prefix and expectations will be independently audited')
