from pathlib import Path
import json,csv,re
w=Path('/private/tmp/amu-loop-high-temp-20261006');a=Path('/private/tmp/amu-loop-high-temp-integrated-20261006-parity');b=Path('/private/tmp/amu-affine-reader-integrated-20261005-parity');rows=list(csv.reader((a/'check.tsv').open(),delimiter='\t'));assert len(rows)==391
norm=lambda s:re.sub(r'#\{([^{}]*)\}',lambda m:'#{'+' '.join(sorted(re.findall(r'\[[^\]]*\]|\S+',m[1])))+'}',s)
old={x[0]:x for x in csv.reader((b/'check.tsv').open(),delimiter='\t')}
for x in rows:
 assert x[0] in old and x[1]==old[x[0]][1] and x[3]==old[x[0]][3] and x[5]==old[x[0]][5]
 assert norm(x[2])==norm(old[x[0]][2]) and norm(x[4])==norm(old[x[0]][4]),(x[0],x[2],old[x[0]][2],x[4],old[x[0]][4])
exports=list(csv.reader((a/'exports.tsv').open(),delimiter='\t'));assert len(exports)==891;pins=[]
for row in exports:
 if row[2]=='MISSING':continue
 name,run=row[:2];d=a/'run'/name;old=b/'run'/name
 for suffix in ['out','st']:
  p=d/('1.'+run+'.'+suffix);q=old/('1.'+run+'.'+suffix);assert p.is_file() and q.is_file(),(name,run,suffix)
  x=p.read_bytes().replace(str(a).encode(),b'@PARITY');y=q.read_bytes().replace(str(b).encode(),b'@PARITY');assert x==y,(name,run,suffix,x[:200],y[:200]);pins.append({'module':name,'exportRun':run,'field':suffix,'bytes':len(x)})
(w/'per-case-output-audit.json').write_text(json.dumps({'status':'complete-check391-normalized-messages-and-export891-native-result-status-parity','checkMessages':391,'exportRows':891,'missingRows':sum(x[2]=='MISSING' for x in exports),'nativeExportOutputAndStatusFilesCompared':len(pins),'normalization':'unordered set members in checker messages; per-run temporary parity directory prefix only','rows':pins},indent=2)+'\n');print('PASS 391 normalized full check messages and',len(pins),'native export output/status files')
