from pathlib import Path
import json,os,re,subprocess,importlib.util
w=Path('/private/tmp/amu-loop-high-temp-20261006');sp=importlib.util.spec_from_file_location('m',w/'baseline-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);ids=json.loads((w/'hand-ids.json').read_text());cs=json.loads((w/'hand-cases.json').read_text());images={label:(w/(label+'-fixture.bin'),m.blob_from((w/(label+'.stdout')).read_text())[1]) for label in ['baseline-hand','candidate-hand']};rows=[]
for c in cs:
 if c['mode']!='aftercall':continue
 for handle,index in [(1,0),(1,7),(1,8),(2,0),(0,0)]:
  for budget,key,val in [('table','KEXE_VECTORS',2),('items','KEXE_VECTOR_ITEMS',9)]:
   valid=(handle==1 and index<8) or handle==2;fuel=16777216;remaining=fuel-(2 if valid else 1);items=[11-3*j for j in range(8)]+[99]+([0] if valid and budget=='table' else []);obs={}
   for label,(path,fc) in images.items():
    env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');env[key]=str(val);env.pop('KEXE_COMMAND',None)
    q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(path),str(fc[ids[c['name']]]),'4','aarch64','-',str(handle),str(index),str(m.MIN),'37'],env=env,capture_output=True,text=True);assert q.returncode!=0 and f':remaining {remaining}' in q.stdout,(c,budget,q.stdout,q.stderr)
    assert re.search(r':vectors \{:capacity \d+ :used 2\}',q.stdout) and re.search(r':vector-items \{:capacity \d+ :used '+str(len(items))+r'\}',q.stdout),(c,budget,q.stdout)
    obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
    assert obs[label]['items']==['DIAG_VECTOR_ITEMS '+str(len(items))+' '+' '.join(map(str,items))],(c,budget,q.stderr)
   assert obs['baseline-hand']==obs['candidate-hand'];rows.append({'caller':c['name'],'handle':handle,'index':index,'budget':budget,'expectRemainingFuel':remaining,'expectItems':items,**obs})
(w/'resource-proof.json').write_text(json.dumps({'status':'complete-native-high-temp-read-resource-exhaustion-partial-write-hand-oracle','comparisons':len(rows),'runs':rows},indent=2)+'\n');print('PASS',len(rows),'resource exhaustion/partial writes')
