from pathlib import Path
import json,hashlib,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-loop-high-temp-20261006');b=Path('/private/tmp/amu-affine-reader-20261005');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();g=load(w/'generations.json');assert len(g)==4 and len(set(x['sha256'] for x in g))==1;assert all(sha(w/('seed-'+str(x['generation'])+'.bin'))==x['sha256'] for x in g)
counts={};pins={}
for name,key,n in [('hand-proof.json','comparisons',15840),('ports-state.json','comparisons',209),('resource-proof.json','comparisons',40),('import-proof.json','comparisons',96),('ownership-proof.json','comparisons',1152),('regression-proof.json','runs',4196)]:
 s=load(w/name);assert s[key]==n;rows=s['observations'] if name=='regression-proof.json' else s['runs'];assert len(rows)==n;counts[name]=n;pins[name]=sha(w/name)
 if name=='hand-proof.json':assert len({(x['caller'],x['handle'],x['index'],x['live'],x['other'],x['fuel']) for x in rows})==n
 if name=='ports-state.json':assert len({(x['workload'],x['n'],x['fuel']) for x in rows})==n
 if name=='regression-proof.json':assert len({x['index'] for x in rows})==n
 for row in rows:
  if name in ['hand-proof.json','resource-proof.json']:assert row['baseline-hand']==row['candidate-hand']
  if name=='ports-state.json':assert row['baseline']==row['candidate']
  if name=='ownership-proof.json':assert row['baseline-own']==row['candidate-own']
  if name=='import-proof.json':assert row['baseline-open']==row['candidate-open']
pa=load(w/'ports-correctness.json');pb=load(b/'ports-correctness.json');assert len(pa['entries'])==19;ch=load(w/'code-change.json');changed=[x['workload'] for x in ch if x['changed']];assert changed==['matmult-int']
for x in pa['entries']:
 y=next(z for z in pb['entries'] if z['workload']==x['workload']);assert x['runs']==y['runs'] and x['fuelTrapReturncode']==y['fuelTrapReturncode'] and x['sourceSha256']==y['sourceSha256'];assert sha(w/'ports-2'/x['workload']/'native.bin')==x['nativeSha256']
ob=load(w/'observer-byte-audit.json');assert len(ob['entries'])==19 and all(x['diagnosticTargetByteIdentical'] for x in ob['entries']);assert (r/'seed/41-a64gen.kotoba').read_bytes()==(w/'baseline-41-a64gen.kotoba').read_bytes();assert load(w/'meta-admission.json')['highTempReadSites']==1
ia=load(w/'instruction-audit.json');assert ia['auditAfterTiming'] is False;pins['instruction-audit.json']=sha(w/'instruction-audit.json')

s={'status':'complete-native-semantic-proof-before-product-edit','generations':g,'originalWorkloads':19,'changedGuests':changed,'freshNativeCounts':counts,'proofPins':pins,'fullSupervisorComparisons':17337,'qualifiedExactMachineLineage':load(w/'timing-lineage.json'),'productUnchangedAtPreflight':True,'productGatesAndIntegratedProofRequired':True,'officialEmbenchScore':False};assert sum(v for k,v in counts.items() if k!='regression-proof.json')==17337;assert s['qualifiedExactMachineLineage']['qualifies'];(w/'promotion-preflight.json').write_text(json.dumps(s,indent=2)+'\n');print('PASS 17337 full-state +4196 regression proofs, exact qualified machine lineage before product edits')
