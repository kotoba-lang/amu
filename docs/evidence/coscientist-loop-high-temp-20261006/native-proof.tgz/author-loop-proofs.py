from pathlib import Path
w=Path('/private/tmp/amu-loop-high-temp-20261006')
p=w/'hand-proof.py';s=p.read_text();needle="ids={x[0]:j+1 for j,x in enumerate(m.FIX)}";assert s.count(needle)==1
extra="""# Author one-iteration enclosing loop for every hand caller so the new
# profitability guard admits each access, including call/alias/resource paths.
for c in cases:
 k=next(j for j,x in enumerate(m.FIX) if x[0]==c['name']);name,np,ns,dp,body=m.FIX[k];at=body.index(('VEC',0,1))+1;label=name+'_outer'
 assert body[-1]==('RET',0)
 body=body[:at]+[('CONST',0,1),('LSET',6,0),('LABEL',label)]+body[at:-1]+[('LSET',9,0),('LGET',0,6),('CONST',1,1),('BIN','BOP-SUB',0),('LSET',6,0),('FUEL',),('BRNZ',0,label),('LGET',0,9),('RET',0)]
 m.FIX[k]=(name,np,9,dp,body)
""";s=s.replace(needle,extra+needle);s=s.replace('     if not failed:answer=total','     if not failed and charge():answer=total');assert "and charge():answer=total" in s;p.write_text(s)
p=w/'ownership-proof.py';s=p.read_text();needle="ids={x[0]:j+1 for j,x in enumerate(m.FIX)}";assert s.count(needle)==1
extra="""# The raw function has no call/allocation; only its high read makes it nonleaf.
# Enclose its authored alias/join cases in a one-iteration backward-branch region.
for c in cs:
 k=next(j for j,x in enumerate(m.FIX) if x[0]==c['raw']);name,np,ns,dp,body=m.FIX[k];label=name+'_outer';assert body[0]==('FUEL',) and body[-1]==('RET',0)
 body=body[:1]+[('CONST',0,1),('LSET',5,0),('LABEL',label)]+body[1:-1]+[('LSET',6,0),('LGET',0,5),('CONST',1,1),('BIN','BOP-SUB',0),('LSET',5,0),('FUEL',),('BRNZ',0,label),('LGET',0,6),('RET',0)]
 m.FIX[k]=(name,np,6,dp,body)
""";s=s.replace(needle,extra+needle);s=s.replace('valid=fuel>=2 and','valid=fuel>=3 and');s=s.replace('remaining=max(0,fuel-2);obs={}',"readValid=(handle==1 and 0<=index<8) or (handle==2 and index==0);remaining=max(0,fuel-(3 if readValid else 2));obs={}");p.write_text(s)
p=w/'import-proof.py';s=p.read_text();old="remaining=max(0,fuel-2);allocated=fuel>=2;items=[11-3*j for j in range(8)]+[99]+([0] if allocated else []);valid=allocated and ((handle==1 and 0<=index<8) or(handle in [2,3] and index==0));";new="allocated=fuel>=2;items=[11-3*j for j in range(8)]+[99]+([0] if allocated else []);readValid=allocated and ((handle==1 and 0<=index<8) or(handle in [2,3] and index==0));remaining=max(0,fuel-(3 if readValid else 2));valid=readValid and fuel>=3;";assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
print('PASS newly authored loop-admitted hand/oracle cases; additional backedge fuel explicit')
