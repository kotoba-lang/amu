from pathlib import Path
import shutil,json,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');old=Path('/private/tmp/amu-high-temp-no-spill-20261006');w=Path('/private/tmp/amu-loop-high-temp-20261006');w.mkdir();g=(old/'41-a64gen-prototype.kotoba').read_text();shutil.copyfile(r/'seed/41-a64gen.kotoba',w/'baseline-41-a64gen.kotoba')
helper=''';; Profitability guard: only an access inside an actual backward branch region.
;; Bounded scans refuse without changing the original call path. Label ownership
;; is checked against the current function; no code or benchmark names.
(defn- gn-high-start [M :vector-i64 j :i64 work :i64] :i64
 (cond (or (<= work 0) (<= j 0)) 0
       (= (gn-op M j) OP-FN) j
       (= (gn-op M j) OP-END) 0
       :else (gn-high-start M (dec j) (dec work))))
(defn- gn-high-loop-scan [M :vector-i64 i :i64 j :i64 start :i64 work :i64] :bool
 (if (or (<= work 0) (>= j (vector-at M MM-SIR-N)) (= (gn-op M j) OP-END)) false
  (let [op (gn-op M j) a (gn-sir M j IF-A) b (gn-sir M j IF-B)
        l (if (= op OP-BR) a (if (or (= op OP-BRZ) (= op OP-BRNZ)) b 0))
        p (if (> l 0) (gn-lpos M l) 0)]
   (if (and (> p start) (<= p i) (< p j) (= (gn-op M p) OP-LABEL) (= (gn-sir M p IF-A) l)) true
    (gn-high-loop-scan M i (inc j) start (dec work))))))
(defn- gn-high-loop [M :vector-i64 i :i64] :bool
 (let [start (gn-high-start M i 8192)]
  (and (> start 0) (gn-high-loop-scan M i (inc i) start 8192))))
'''
pos=g.index('(defn- gn-rt-high-at ');g=g[:pos]+helper+g[pos:];needle='(>= t 6) (= (gn-g M gn-f-leaf) 0)) (gn-rt-high-at M i t)';assert g.count(needle)==1;g=g.replace(needle,'(>= t 6) (= (gn-g M gn-f-leaf) 0) (gn-high-loop M i)) (gn-rt-high-at M i t)');(w/'41-a64gen-prototype.kotoba').write_text(g)
parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];unity=lambda g:''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in parts);(w/'seed-unity.kotoba').write_text(unity(g));start=g.index('(defn- gn-rt-high-at ');end=g.index('(defn- gn-op-rt ',start);block=g[start:end];needle='(-> M (gn-into 0 t) (gn-into 1 (inc t)) (gn-ctx)';assert block.count(needle)==1;block=block.replace(needle,'(let [printed (io-out (string-concat "HREAD " (string-concat (string-from-i64 i) (string-concat " " (string-concat (string-from-i64 t) "\\n")))))]\n '+needle,1);assert block.endswith('(gn-take i t 0)))\n');block=block[:-1]+')\n';(w/'observer-unity.kotoba').write_text(unity(g[:start]+block+g[end:]))
for n in ['seed-0.bin','seed-0.offset','kexe-loader','baseline-a64gen-fixtures.py','clobber-full-state-loader','clobber-full-state-loader.c']:shutil.copyfile(old/n,w/n)
for n in ['kexe-loader','clobber-full-state-loader']:(w/n).chmod(0o755)
for n in ['build.py','check-ports.py','observe-admission.py','observer-byte-audit.py','regression.py','hand-proof.py','import-proof.py','resource-proof.py','ports-state.py','ownership-proof.py','instruction-audit.py']:(w/n).write_text((old/n).read_text().replace('amu-high-temp-no-spill-20261006','amu-loop-high-temp-20261006'))
(w/'hypothesis.json').write_text(json.dumps({'status':'registered-before-native-build','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'hypothesis':'Inline high-temp vector reads without call spills only for actual loop-contained accesses. Keep original nonleaf frame/register assignments and per-access ordered handle/index checks, result alias protection and fuel.','evidence':json.loads((old/'loop-containment-census.json').read_text()),'timingLineage':'Reuse previous qualified30-triple matmult receipt only if emitted target bytes equal35b9ce6fa5071911882bb3f405ff6da1c16ef79afa75925d4f98ade86bc48abe exactly; do not retime identical machine to seek another pass. Other18 guests must equal current product. No fresh all19 aggregate claim.','qualification':'Fresh native4gen, all19canonicalsource/result/fuel/bytes, hand-loop/state/ownership/refusal/import/resource/fullstate, existingregression/permanentfixtures/fullgates/integrated3gen/corpus beforepromotion.','exception':'One-off new Kotoba compiler algorithm and authored proof fixtures; no mechanical AST rule covers it.','goal':'C-or-better across all19 original workloads; unchanged scope.'},indent=2)+'\n');shutil.copyfile(Path(__file__),w/'create.py');print('PASS registered loop-contained high-temp candidate before native build')
