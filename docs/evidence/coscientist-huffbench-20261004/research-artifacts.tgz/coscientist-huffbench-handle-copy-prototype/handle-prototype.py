# BOOTSTRAP-TOOL: concrete Huffbench Reflect experiment, not a product optimizer.
from pathlib import Path
import re,struct,json,hashlib,shutil
base=Path(__file__).resolve().parent;p=base.with_name('coscientist-huffbench-handle-prototype');p.mkdir(exist_ok=True)
blob=(base/'batch.bin').read_bytes();words=list(struct.unpack('<'+'I'*(len(blob)//4),blob));result=bytearray(blob)
log=(base/'test-huffbench-extract.log').read_text();code_end=(int(re.search(r':offset (\d+)',log).group(1))+int(re.search(r':length (\d+)',log).group(1)))//4
needle=[0xf9409cf0,0xf9400210,0xd1000411,0xeb10023f,0x54000043,0,0xf940a0f0,0x8b111210]
changes=[];proof=[];start=0
for end in range(code_end):
 if words[end]!=0xd4200020:continue
 fn=words[start:end]
 if any((w&0xfc000000)==0x94000000 or (w&0xfffffc1f)==0xd63f0000 for w in fn):start=end+1;continue
 incoming={}
 for at in range(start,end):
  w=words[at];target=None
  if (w&0x7c000000)==0x14000000:
   d=w&0x3ffffff;d=d-(1<<26) if d&(1<<25) else d;target=at+d
  elif (w&0xff000010)==0x54000000 or (w&0x7e000000)==0x34000000:
   d=(w>>5)&0x7ffff;d=d-(1<<19) if d&(1<<18) else d;target=at+d
  elif (w&0x7e000000)==0x36000000:
   d=(w>>5)&0x3fff;d=d-(1<<14) if d&(1<<13) else d;target=at+d
  if target is not None:incoming.setdefault(target,[]).append(at)
 safe_targets=set()
 for target,sources in incoming.items():
  if all(words[s]==0x54000043 and s+2==target and words[s+1]==0 for s in sources):safe_targets.add(target)
 validated=False;validated_at=None;at=start
 while at<end:
  if at in incoming and at not in safe_targets:validated=False
  if words[at:at+8]==needle:
   if any(t in incoming and not (t==at+6 and incoming[t]==[at+4]) for t in range(at+1,at+8)):
    validated=False;at+=8;continue
   if validated:
    replacement=[needle[2],0x14000005,0xd503201f,0xd503201f,0xd503201f,0xd503201f]
    struct.pack_into('<IIIIII',result,at*4,*replacement)
    changes.append({'offset':at*4,'dominatingValidatorOffset':validated_at*4,'old':needle[:6],'new':replacement})
   else:validated=True;validated_at=at
   at+=8;continue
  w=words[at]
  # The checked branch either skips its immediate trap or terminates. Do not
  # treat the unreachable UDF word as a write to x0 on the successful path.
  if w==0x54000043 and at+1<end and words[at+1]==0:at+=2;continue
  branch=(w&0x7c000000)==0x14000000 or (w&0xff000010)==0x54000000 or (w&0x7e000000) in (0x34000000,0x36000000) or (w&0xfffffc1f) in (0xd61f0000,0xd63f0000,0xd65f0000)
  if branch:validated=False
  # Conservative invalidation: stores whose source is x0 also invalidate.
  if (w&31)==0 or ((w&0x3a000000)==0x28000000 and (w&(1<<22)) and ((w>>10)&31)==0):validated=False
  at+=1
 proof.append({'start':start*4,'end':end*4,'nativeLeaf':True});start=end+1
assert changes,'no redundant validators found'
for f in base.iterdir():
 if f.is_file() and f.name not in ('results.json','c.dylib'):shutil.copy2(f,p/f.name)
for name in ('batch','state-cell','test-huffbench'):
 assert (base/(name+'.bin')).read_bytes()==blob;(p/(name+'.bin')).write_bytes(result)
meta={'kind':'handpatched-native-source-built','scope':'x0 validators in no-call functions; unchanged x0, no non-trapping control boundary or other entry between validators','baseSha256':hashlib.sha256(blob).hexdigest(),'patchedSha256':hashlib.sha256(result).hexdigest(),'changes':changes,'nativeLeaves':proof,'preserved':'first handle validator per segment; all index bounds checks; fuel; code/data offsets; other registers/context fields'}
(p/'prototype.json').write_text(json.dumps(meta,indent=2)+'\n');print('redundant validator sites',len(changes))
