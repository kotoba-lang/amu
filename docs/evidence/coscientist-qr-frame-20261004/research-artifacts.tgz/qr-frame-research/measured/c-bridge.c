/* BOOTSTRAP-TOOL: pinned C initframe with untimed snapshots only.
 * Copyright 2014-2019 Embecosm/Bristol, qrduino contributors; GPL-3.0-or-later. */
#include <stdint.h>
#include <limits.h>
#include "../upstream/src/qrduino/qrframe.c"
static unsigned char heap[8192] __attribute__((aligned));static int64_t states[9][256];
static void snapshot(int stage){for(int i=0;i<100;i++)states[stage][i]=framebase[i];for(int i=0;i<41;i++)states[stage][128+i]=framask[i];}
static int prepare(void){memset(states,0,sizeof(states));init_heap_beebs(heap,8192);initeccsize(1,22);return VERSION==2&&WD==25&&WDB==4&&adelta[VERSION]==15;}
static void observed(void){

  unsigned x, y;

  framebase = calloc_beebs (WDB * WD, 1);
  framask = calloc_beebs (((WD * (WD + 1) / 2) + 7) / 8, 1);
  rlens = malloc_beebs (WD + 1);
  snapshot(0);
  // finders
  putfind ();
  snapshot(1);
  // alignment blocks
  doaligns ();
  snapshot(2);
  // single black
  SETQRBIT (8, WD - 8);
  snapshot(3);
  // timing gap - masks only
  for (y = 0; y < 7; y++)
    {
      setmask (7, y);
      setmask (WD - 8, y);
      setmask (7, y + WD - 7);
    }
  for (x = 0; x < 8; x++)
    {
      setmask (x, 7);
      setmask (x + WD - 8, 7);
      setmask (x, WD - 8);
    }
  snapshot(4);
  // reserve mask-format area
  for (x = 0; x < 9; x++)
    setmask (x, 8);
  for (x = 0; x < 8; x++)
    {
      setmask (x + WD - 8, 8);
      setmask (8, x);
    }
  for (y = 0; y < 7; y++)
    setmask (8, y + WD - 7);
  snapshot(5);
  // timing
  for (x = 0; x < (unsigned) WD - 14; x++)
    if (x & 1)
      {
	setmask (8 + x, 6);
	setmask (6, 8 + x);
      }
    else
      {
	SETQRBIT (8 + x, 6);
	SETQRBIT (6, 8 + x);
      }

  snapshot(6);
  // version block
  putvpat ();
  snapshot(7);
  for (y = 0; y < WD; y++)
    for (x = 0; x <= y; x++)
      if (QRBIT (x, y))
	setmask (x, y);

snapshot(8);
}
#define EXTRA int64_t x1,int64_t x2,int64_t x3,int64_t x4,int64_t x5,int64_t x6,int64_t ctx
int64_t observe(int64_t encoded,EXTRA){int stage=encoded/256,cell=encoded%256;if(encoded<0||stage>8||!prepare())return INT64_MIN;observed();return states[stage][cell];}
int64_t oracle_selfcheck(int64_t n,EXTRA){if(n<1||n>32||!prepare())return 0;observed();int64_t saved[256];memcpy(saved,states[8],sizeof(saved));
 for(int j=0;j<n;j++){if(!prepare())return 0;initframe();for(int i=0;i<100;i++)if(framebase[i]!=saved[i])return 0;for(int i=0;i<41;i++)if(framask[i]!=saved[128+i])return 0;freeframe();freeecc();if(!check_heap_beebs(heap))return 0;}return 1;}
