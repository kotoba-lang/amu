/* BOOTSTRAP-TOOL: valid profile and initialized frame accesses only. */
#include "c-bridge.c"
int main(void){
 for(int n=1;n<=32;n++)if(oracle_selfcheck(n,0,0,0,0,0,0,0)!=1)return 1;
 for(int stage=0;stage<9;stage++)for(int cell=0;cell<256;cell++)(void)observe(stage*256+cell,0,0,0,0,0,0,0);
 return 0;
}
