#include "c-bridge.c"
#include <stdio.h>
int main(void){for(int n=1;n<=32;n++)if(!oracle_selfcheck(n,0,0,0,0,0,0,0)||bench(n,0,0,0,0,0,0,0)!=1||memcmp(buffer,hash,32)!=0)return 1;int count=0;for(int n=0;n<=32;n++)for(int f=0;f<302;f++){if(observe(n*512+f,0,0,0,0,0,0,0)==INT64_MIN)return 2;count++;}printf("PASS 32 original SHA256 bodies/verifiers; %d initialized packed/state observations\n",count);return 0;}
