from pathlib import Path
import json,hashlib,shutil,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-element-reuse-census-20261006');b=Path('/private/tmp/amu-static-vector-chain-20261006');t=Path('/private/tmp/amu-terminal-census-20261006');g=(r/'seed/41-a64gen.kotoba').read_text();assert g==(b/'41-a64gen-prototype.kotoba').read_text();(w/'baseline-41-a64gen.kotoba').write_text(g)
h=json.loads((r/'docs/evidence/coscientist-fallthrough-vector-chain-20261006/next-hypothesis.json').read_text());h.update(status='registered-before-new-native-observation',sourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),authoringException='One-off new read-only event algorithm and test schema in excluded diagnostic compiler, not mechanical product refactor.');(w/'hypothesis.json').write_text(json.dumps(h,indent=2)+'\n')
helper=''';; Diagnostic only: context400 points to a separate supervisor event arena.
;; Generator cell15 is unused in the product and overwritten at every SIR step.
(def gn-field-observe true)
(defn- gn-field-saved [M :vector-i64 dst :i64 src :i64] :vector-i64
 (case src 14 (gn-emit M (enc-ldr dst 31 32)) 15 (gn-emit M (enc-ldr dst 31 40))
           16 (gn-emit M (enc-ldr dst 31 16)) 17 (gn-emit M (enc-ldr dst 31 24))
           (gn-mov M dst src)))
(defn- gn-field-begin [M :vector-i64] :vector-i64
 (-> M (gn-emit (enc-stp-pre 14 15 31 -16)) (gn-emit (enc-stp-pre 16 17 31 -16))
       (gn-emit 0xd53b4210) (gn-emit (enc-stp-pre 16 31 31 -16)) (gn-emit (enc-ldr 14 7 400))))
(defn- gn-field-end [M :vector-i64] :vector-i64
 (-> M (gn-emit (enc-ldp-post 16 31 31 16)) (gn-emit 0xd51b4210)
       (gn-emit (enc-ldp-post 16 17 31 16)) (gn-emit (enc-ldp-post 14 15 31 16))))
(defn- gn-field-before [M :vector-i64 rv :i64 ri :i64 kind :i64 site :i64] :vector-i64
 (if (not gn-field-observe) M
  (-> M (gn-field-begin) (gn-field-saved 15 rv) (gn-field-saved 17 ri)
        (gn-emit (enc-str 15 14 8)) (gn-emit (enc-str 17 14 16))
        (gn-mov-imm 17 kind) (gn-emit (enc-str 17 14 24))
        (gn-mov-imm 17 site) (gn-emit (enc-str 17 14 32)) (gn-field-end))))
(defn- gn-field-after [M :vector-i64] :vector-i64
 (if (not gn-field-observe) M
  (let [M0 (-> M (gn-field-begin) (gn-emit (enc-ldr 17 14 0)) (gn-mov-imm 16 65536)
                 (gn-emit (enc-cmp-r 17 16))) at (vector-at M0 MM-CODE-N)
        M1 (-> M0 (gn-emit (enc-bcond (enc-cond-hs) 0))
               (gn-emit (enc-add-i 16 14 64)) (gn-emit (gn-e-addsl 16 16 17 5))
               (gn-emit (enc-ldr 15 14 24)) (gn-emit (enc-str 15 16 0))
               (gn-emit (enc-ldr 15 14 32)) (gn-emit (enc-str 15 16 8))
               (gn-emit (enc-ldr 15 14 8)) (gn-emit (enc-str 15 16 16))
               (gn-emit (enc-ldr 15 14 16)) (gn-emit (enc-str 15 16 24))
               (gn-emit (enc-add-i 17 17 1)) (gn-emit (enc-str 17 14 0))) skip (vector-at M1 MM-CODE-N)
        M2 (gn-emit M1 (enc-b 0)) overflow (vector-at M2 MM-CODE-N)
        M3 (-> M2 (gn-emit (enc-ldr 17 14 40)) (gn-emit (enc-add-i 17 17 1))
                  (gn-emit (enc-str 17 14 40))) clear (vector-at M3 MM-CODE-N)
        M4 (-> M3 (gn-mov-imm 17 0) (gn-emit (enc-str 17 14 24)) (gn-field-end))]
   (-> M4 (gn-put (+ MM-CODE-BASE at) (enc-bcond (enc-cond-hs) (- overflow at)))
          (gn-put (+ MM-CODE-BASE skip) (enc-b (- clear skip)))))))
(defn- gn-field-flow [M :vector-i64 kind :i64 site :i64] :vector-i64
 (if (not gn-field-observe) M
  (-> M (gn-ctx) (gn-field-before 31 31 kind site) (gn-field-after))))
'''
a='(defn- gn-chain-read [';assert g.count(a)==1;g=g.replace(a,helper+a)
start=g.index('(defn- gn-chain-read [');end=g.index('(defn- gn-chain-fix [',start)
old=g[start:end]
new=old.replace(' (if (not= (gn-g M gn-f-vmode) 2)', ' (let [M (gn-field-before M rv ri 1 (gn-g M 15))]\n (gn-field-after (if (not= (gn-g M gn-f-vmode) 2)',1)
a='   (gn-emit (gn-e-ldrr d 4 ri 1)))))';assert a in new;new=new.replace(a,'   (gn-emit (gn-e-ldrr d 4 ri 1)))))))',1)
split=new.index('(defn- gn-chain-store [');head=new[:split];tail=new[split:];a=' (if (not= (gn-g M gn-f-vmode) 2)';assert tail.count(a)==1;tail=tail.replace(a,' (let [M (gn-field-before M rv ri 2 (gn-g M 15))]\n (gn-field-after (if (not= (gn-g M gn-f-vmode) 2)',1);new=head+tail
a='      (gn-emit (gn-e-strr3 rx 4 ri)))))';assert a in new;new=new.replace(a,'      (gn-emit (gn-e-strr3 rx 4 ri)))))))',1);g=g[:start]+new+g[end:]
a='(gn-ins-quiet (gn-chain-step M i op (gn-sir M i IF-A)) i op)';assert g.count(a)==1;g=g.replace(a,'(gn-ins-quiet (gn-chain-step (gn-gs M 15 i) i op (gn-sir M i IF-A)) i op)')
a='(gn-tree-entry f)))))))';assert g.count(a)==1;g=g.replace(a,'(gn-field-flow 3 i) (gn-tree-entry f)))))))')
a='(gn-args t 0 n) (gn-ctx) (gn-epilogue)';assert g.count(a)==1;g=g.replace(a,'(gn-args t 0 n) (gn-ctx) (gn-field-flow 4 (gn-g M 15)) (gn-epilogue)')
a='(gn-gs gn-f-ctx (if (= (gn-g M1 gn-f-leaf) 0) 0 1))))))';assert g.count(a)==1;g=g.replace(a,'(gn-gs gn-f-ctx (if (= (gn-g M1 gn-f-leaf) 0) 0 1)) (gn-field-flow 6 (gn-g M 15))))))')
(w/'41-a64gen-diagnostic.kotoba').write_text(g);parts=[z.strip() for z in (r/'seed/MANIFEST').read_text().splitlines() if z.strip() and not z.lstrip().startswith('#')]
for arm,source in [('diagnostic',g),('quiet',g.replace('(def gn-field-observe true)','(def gn-field-observe false)'))]:(w/(arm+'-unity.kotoba')).write_text(''.join(source if p=='seed/41-a64gen.kotoba' else (r/p).read_text() for p in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader')]:shutil.copy2(b/src,w/dst)
c=(t/'diagnostic-loader.c').read_text();assert 'diagnostic_counters[32768]' in c;c=c.replace('diagnostic_counters[32768]','diagnostic_counters[262152]')
a='  for (unsigned d = 0; d < 32768; ++d) if (shared->diagnostic_counters[d]) fprintf(stderr, "DIAG_COUNT %u %llu\\n", d, (unsigned long long)shared->diagnostic_counters[d]);';assert c.count(a)==1;c=c.replace(a,'''  uint64_t *ev = shared->diagnostic_counters;
  fprintf(stderr, "DIAG_EVENTS %llu DROPS %llu\\n", (unsigned long long)ev[0], (unsigned long long)ev[5]);
  for (uint64_t d = 0; d < ev[0] && d < 65536; ++d) { uint64_t *z = ev + 8 + d*4;
    fprintf(stderr, "DIAG_ACCESS %llu %llu %lld %lld\\n", (unsigned long long)z[0], (unsigned long long)z[1], (long long)z[2], (long long)z[3]); }
  if (ev[3]) fprintf(stderr, "DIAG_PENDING %llu %llu %lld %lld\\n", (unsigned long long)ev[3], (unsigned long long)ev[4], (long long)ev[1], (long long)ev[2]);''');(w/'diagnostic-loader.c').write_text(c)
q=subprocess.run(['clang','-O2','-o',str(w/'diagnostic-loader'),str(w/'diagnostic-loader.c')],capture_output=True,text=True);(w/'loader-build.log').write_text(q.stdout+q.stderr);assert q.returncode==0,q.stderr
(w/'source-pins.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [w/'baseline-41-a64gen.kotoba',w/'41-a64gen-diagnostic.kotoba',w/'diagnostic-loader.c',w/'diagnostic-unity.kotoba',w/'quiet-unity.kotoba']},indent=2)+'\n');print('PASS new diagnostic prepared; completion-only events and balanced register/flag preservation, product unchanged')
