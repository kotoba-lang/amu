from pathlib import Path
import json,collections
w=Path('/private/tmp/amu-element-reuse-census-20261006');b=Path('/private/tmp/amu-static-vector-chain-20261006');c=json.loads((b/'observer/meta-ports/statemate/census.json').read_text());sir={int(z.split()[1]):list(map(int,z.split()[2:])) for z in (b/'observer/meta-ports/statemate/compile.log').read_text().splitlines() if z.startswith('SIR ')};owner={i:int(f) for f,v in c['functions'].items() for i in range(v['start'],v['end']+1)};closed={x['fn'] for x in json.loads((b/'instruction-audit.json').read_text())['mode2Functions'] if x['workload']=='statemate'};facts={};ld={};temps={};f=None
for i,(op,a,z,k) in sir.items():
 if op==1:f=a;ld={};temps={}
 if f not in closed:continue
 if op==3 and k==0:temps[a]=z
 elif op==4:temps[a]=ld.get(z)
 elif op==5:ld[a]=temps.get(z)
 elif op in [6,7,8]:temps[z]=None
 elif op in [9,10,11,12]:ld={};temps={}
 elif op in [13,14]:
  if k>=2:facts[i]={'index':temps.get(z+1),'storedValue':temps.get(z+2) if k==3 else None,'owner':f,'limitedProof':'CONST/LGET/LSET only; arithmetic/control/unknown results erased'}
  temps[z]=None
  if op==13 and not k==3 and not k==2:ld={};temps={}
 elif op not in [2,15,16]:ld={};temps={}
ev=next(x['events'] for x in json.loads((w/'observations.json').read_text())['rows'] if x['n']==1 and x['fuel']==16777216);counts=collections.Counter();rows=[]
for kind,site,handle,index in ev:
 if kind not in [1,2] or owner[site] not in closed:continue
 v=facts.get(site,{})
 if v.get('index') is not None:assert v['index']==index,(site,index,v);counts['completedReadsWithConstLocalIndex' if kind==1 else 'completedWritesWithConstLocalIndex']+=1
 if kind==2 and v.get('storedValue') is not None:counts['completedWritesWithConstLocalValue']+=1;counts['storeLiteral_'+str(v['storedValue'])]+=1
 rows.append({'kind':kind,'site':site,'actualHandle':handle,'actualIndex':index,'limitedStaticFact':v})
out={'status':'independent-limited-straightline-SIR-local-literal-facts','counts':dict(counts),'rows':rows,'scope':'Observed closed-mode2 functions; transfer only CONST/LGET/LSET, erase at labels/branches, unknown arithmetic/call results. Literal store value is a source fact, not a new runtime value observation. Does not prove ABI profitability or a compiler optimization.','productChanged':False};(w/'local-facts.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS literal/local source-fact census',dict(counts))
