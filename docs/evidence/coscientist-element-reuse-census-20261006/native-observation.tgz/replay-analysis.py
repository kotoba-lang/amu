from pathlib import Path
import json,re,hashlib,subprocess
w=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();count=0
for name,n in [('calibration-proof.json',24),('extremes-proof.json',8),('invalid-write-proof.json',6),('partial-fuel-proof.json',15)]:
 x=load(w/name);assert x['cases']==n and len(x['rows'])==n
 for row in x['rows']:
  observed=[[z[0],z[2],z[3]] for z in row['events'] if z[0] in [1,2]];assert observed==row['expectedCompletedAccesses']
  if name=='partial-fuel-proof.json':
   v=row['n'];f=row['fuel'];expected=((v+1+(1<<63))%(1<<64))-(1<<63) if f>=2 else v;assert row['expectedValue']==expected and row['expectedRemaining']==max(0,f-2);assert row['observation']['items']==['DIAG_VECTOR_ITEMS 1 '+str(expected)]
  else:
   assert row['observation']['items']==['DIAG_VECTOR_ITEMS '+str(len(row['expectedItems']))+' '+' '.join(map(str,row['expectedItems']))]
   if row['expectedResult'] is not None:assert int(re.search(r':result (-?\d+)',row['observation']['report'])[1])==row['expectedResult']
 count+=n
assert count==53
x=load(w/'observations.json');assert x['comparisons']==30;parse=lambda s:{'report':next(z for z in s.splitlines() if ':fuel ' in z),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',s,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',s,re.M)}
for row in x['rows']:
 obs=[parse((w/f"run-{row['n']}-{row['fuel']}-{a}.log").read_text()) for a in ['baseline','quiet','diagnostic','original-supervisor']];assert all(z==obs[0] for z in obs)
overflow=load(w/'overflow-proof.json');assert overflow['allStateExact'] and overflow['counts']['diagnostic']['records']==65536 and overflow['counts']['diagnostic']['dropped']>0
reports=[parse((w/('overflow-'+a+'.log')).read_text()) for a in ['baseline','quiet','diagnostic']];assert reports[0]==reports[1]==reports[2]
for name,h in load(w/'source-pins.json').items():assert sha(w/name)==h
base=w/'baseline';assert (base/'statemate.bin').read_bytes()==(w/'quiet-statemate.bin').read_bytes();assert load(w/'build-proof.json')['currentProductQuietOffsetExact'];assert load(w/'machine-audit.json')['blocks']==5146
for name in ['analyze.py','local-facts.py']:
 s=(w/name).read_text().replace("w=Path('/private/tmp/amu-element-reuse-census-20261006')",'w=Path(__file__).resolve().parent').replace("b=Path('/private/tmp/amu-static-vector-chain-20261006')","b=w/'baseline'").replace("b/'observer/meta-ports/statemate/census.json'","b/'census.json'").replace("b/'observer/meta-ports/statemate/compile.log'","b/'sir-snapshot.log'");out=w/('replay-'+name);out.write_text(s);q=subprocess.run(['python3',str(out)],capture_output=True,text=True);assert q.returncode==0,q.stderr;print(q.stdout.strip())
print('PASS extracted53 independent calibration/partial-state oracles,30 actual four-arm original-state log comparisons, native source pins/quiet guest bytes, handle-index and local-fact analysis. Offline replay does not execute native guest code again.')
