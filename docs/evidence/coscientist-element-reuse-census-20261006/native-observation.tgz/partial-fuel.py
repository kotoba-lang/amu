from pathlib import Path
import subprocess,json,os,re
w=Path('/private/tmp/amu-element-reuse-census-20261006');rows=[]
for n in [-1,0,17,-(1<<63),(1<<63)-1]:
 for fuel in [1,2,100]:
  obs={};events=[]
  for arm in ['baseline','quiet','diagnostic']:
   text=(w/(arm+'-alias-extract.log')).read_text();off=int(re.search(r':offset (\d+)',text)[1]);env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');env.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'diagnostic-loader'),str(w/(arm+'-alias.bin')),str(off),'1','aarch64','-',str(n)],env=env,capture_output=True,text=True);(w/f'fuel-{n}-{fuel}-{arm}.log').write_text(q.stdout+q.stderr);obs[arm]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
   if arm=='diagnostic':events=[list(map(int,z)) for z in re.findall(r'^DIAG_ACCESS (\d+) (\d+) (-?\d+) (-?\d+)$',q.stderr,re.M)];assert 'DIAG_PENDING' not in q.stderr and re.search(r'DIAG_EVENTS \d+ DROPS 0',q.stderr)
  assert obs['baseline']==obs['quiet']==obs['diagnostic'];actual=[[z[0],z[2],z[3]] for z in events if z[0] in [1,2]];expected=[[1,1,0],[1,1,0]]+([[1,1,0],[2,1,0],[1,1,0]] if fuel>=2 else []);value=((n+1+(1<<63))%(1<<64))-(1<<63) if fuel>=2 else n;assert actual==expected,(n,fuel,actual,expected);o=obs['diagnostic'];assert o['items']==['DIAG_VECTOR_ITEMS 1 '+str(value)] and int(re.search(r':remaining (-?\d+)',o['report'])[1])==max(0,fuel-2);assert o['exit']==(0 if fuel>=2 else 120)
  if fuel>=2:assert int(re.search(r':result (-?\d+)',o['report'])[1])==value
  rows.append({'n':n,'fuel':fuel,'expectedCompletedAccesses':expected,'expectedValue':value,'expectedRemaining':max(0,fuel-2),'observation':o,'events':events});print('PASS independent partial-fuel completion model',n,fuel,flush=True)
(w/'partial-fuel-proof.json').write_text(json.dumps({'status':'complete-independent-fuel-completion-partial-write-model','cases':len(rows),'rows':rows},indent=2)+'\n')
