.text
.globl _save_restore
_save_restore:
stp x14, x15, [sp, #-16]!
stp x16, x17, [sp, #-16]!
mrs x16, nzcv
stp x16, xzr, [sp, #-16]!
ldp x16, xzr, [sp], #16
msr nzcv, x16
ldp x16, x17, [sp], #16
ldp x14, x15, [sp], #16
