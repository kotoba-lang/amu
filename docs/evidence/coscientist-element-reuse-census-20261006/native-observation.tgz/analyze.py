from pathlib import Path
import json,collections
w=Path('/private/tmp/amu-element-reuse-census-20261006');b=Path('/private/tmp/amu-static-vector-chain-20261006');load=lambda p:json.loads(p.read_text());c=load(b/'observer/meta-ports/statemate/census.json');sir={int(z.split()[1]):list(map(int,z.split()[2:])) for z in (b/'observer/meta-ports/statemate/compile.log').read_text().splitlines() if z.startswith('SIR ')};owner={i:int(f) for f,v in c['functions'].items() for i in range(v['start'],v['end']+1)};closed={x['fn'] for x in load(b/'instruction-audit.json')['mode2Functions'] if x['workload']=='statemate'};incoming=collections.defaultdict(list)
for i,(op,a,z,k) in sir.items():
 if op==10:incoming[a].append(i)
 if op in [11,12]:incoming[z].append(i)
def tally(events,metadata=False):
 last=None;flows=[];counts=collections.Counter();pairs=[]
 for kind,site,handle,index in events:
  if metadata:assert site in sir
  if kind not in [1,2]:flows.append((kind,site));counts['flow'+str(kind)]+=1;continue
  counts['reads' if kind==1 else 'writes']+=1
  f=owner[site] if metadata else None
  if metadata and f in closed:counts['closedReads' if kind==1 else 'closedWrites']+=1
  if kind==1 and last is not None:
   pk,ps,ph,pi=last
   if (handle,index)==(ph,pi):
    counts['samePairReads']+=1;counts['samePairAfterRead' if pk==1 else 'samePairAfterWrite']+=1
    if metadata and f in closed and owner[ps] in closed:
     counts['closedSamePairReads']+=1
     allowed=True;tails=[]
     for fk,fs in flows:
      sf=owner[fs]
      if sf not in closed:allowed=False
      if fk==4:
       op,target,t,np=sir[fs];allowed=allowed and op==13 and target in closed and np==1;tails.append(fs)
      elif fk==3:allowed=allowed and sir[fs][0]==1
      elif fk==6:allowed=allowed and sir[fs][0]==9 and not incoming[sir[fs][1]]
      else:allowed=False
     if not flows and f==owner[ps]:counts['closedStraightLineSamePairReads']+=1
     if allowed:counts['closedOnlyCompatibleBoundariesSamePairReads']+=1
     pairs.append({'previousKind':pk,'previousSite':ps,'readSite':site,'handle':handle,'index':index,'previousOwner':owner[ps],'owner':f,'boundaries':flows,'observedClosedCompatibleBoundaries':bool(allowed),'tailSites':tails})
  last=(kind,site,handle,index);flows=[]
 return dict(counts),pairs
for name in ['calibration-proof.json','extremes-proof.json']:
 for x in load(w/name)['rows']:
  n=x['n'];kind=x['variant'];expected={'sequence':(2,1,1),'invalid_index':((1,1,0) if n==0 else (0,0,0)),'alias':(3,2,1),'changed_handle':(1,0,1)}[kind];z,_=tally(x['events']);assert (z.get('samePairReads',0),z.get('samePairAfterRead',0),z.get('samePairAfterWrite',0))==expected,(name,kind,n,z,expected)
rows=[]
for x in load(w/'observations.json')['rows']:
 counts,pairs=tally(x['events'],True);rows.append({'n':x['n'],'fuel':x['fuel'],'counts':counts,'observedPairs':pairs,'pending':x['pending']})
full=[x for x in rows if x['fuel']==16777216];one=next(x for x in full if x['n']==1);print('Original one body:',one['counts'])
for x in full:print('Full n',x['n'],x['counts'])
out={'status':'complete-native-calibrated-element-pair-observation','observedOriginalWorkload':'statemate','originalGoalScope':19,'all30FourArmOriginalStatesExact':True,'calibrationCases':24,'signedExtremeCases':8,'singleBody':one,'fullRuns':full,'rows':rows,'boundary':'Completed-access reuse on observed inputs only. Not cost shares, spare-register liveness, alias/effect validity proof or performance measurement. Coverage of chain-read/store in closed mode2; other specialized vector paths are outside the observed path. Flow entry/tail/label events are observed, returning/indirect/cap/other unknown edges are outside admitted closed boundaries.','productChanged':False,'performanceMeasured':False,'all19GoalAchieved':False};(w/'analysis.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS independent calibrated handle+index matching and closed-boundary classification')
