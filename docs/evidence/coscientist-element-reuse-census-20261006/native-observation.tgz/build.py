from pathlib import Path
import os,subprocess,json,re,hashlib
w=Path('/private/tmp/amu-element-reuse-census-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');b=Path('/private/tmp/amu-static-vector-chain-20261006');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
def compile(seed,off,src,label,symbol):
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol',symbol,'--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(seed),str(off),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-600:],q.stderr)
  if stage=='extract':offset=int(re.search(r':offset (\d+)',q.stdout)[1]);(w/(label+'.offset')).write_text(str(offset)+'\n')
 return w/(label+'.bin'),offset
port=next(e for e in json.loads((r/'bench/embench/comparison-matrix.json').read_text())['entries'] if e['workload']=='statemate');src=r/port['source'];assert sha(src)==port['expectedSourceSha256'];old=next(e for e in json.loads((b/'ports-correctness.json').read_text())['entries'] if e['workload']=='statemate')
for arm in ['quiet','diagnostic']:
 seed,off=compile(w/'seed-0.bin',(w/'seed-0.offset').read_text().strip(),w/(arm+'-unity.kotoba'),arm+'-seed','main');guest,goff=compile(seed,off,src,arm+'-statemate',port['symbol']);
 if arm=='quiet':assert sha(guest)==old['nativeSha256'] and goff==old['offset']
 rows.append({'arm':arm,'nativeSeedSha256':sha(seed),'guestSha256':sha(guest),'guestOffset':goff,'guestBytes':guest.stat().st_size});print('PASS native',arm,'compiler and original statemate',rows[-1],flush=True)
(w/'build-proof.json').write_text(json.dumps({'status':'native-diagnostic-and-disabled-diagnostic-build-complete','currentProductQuietGuestByteExact':True,'currentProductQuietOffsetExact':True,'sourceSha256':sha(src),'rows':rows},indent=2)+'\n')
