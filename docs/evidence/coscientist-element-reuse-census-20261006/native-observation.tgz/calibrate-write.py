from pathlib import Path
import os,subprocess,re,json,hashlib
w=Path('/private/tmp/amu-element-reuse-census-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');ns={};exec((w/'build.py').read_text().split('port=next(')[0],ns);compile=ns['compile'];rows=[]
specs={'invalid_write': '(defn batch [n :i64] :i64 (let [a [10 n] s (vector-assoc! a 0 n) t (vector-assoc! a n 99)] (vector-at t 0)))'}
for kind,body in specs.items():
 src=w/(kind+'.kotoba');src.write_text('(ns research.element-census (:export [batch]))\n'+body+'\n');images={}
 for arm,seed in [('baseline','seed-0'),('diagnostic','diagnostic-seed'),('quiet','quiet-seed')]:images[arm]=compile(w/(seed+'.bin'),(w/(seed+'.offset')).read_text().strip(),src,arm+'-'+kind,'batch')
 assert images['quiet'][0].read_bytes()==images['baseline'][0].read_bytes() and images['quiet'][1]==images['baseline'][1]
 for n in [-1,0,1,2,-(1<<63),(1<<63)-1]:
  obs={};events={};pending={}
  for arm,(p,off) in images.items():
   env=dict(os.environ,KEXE_STRUCTURED_REPORT='1',KEXE_FUEL='100');env.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'diagnostic-loader'),str(p),str(off),'1','aarch64','-',str(n)],env=env,capture_output=True,text=True);(w/f'write-{kind}-{n}-{arm}.log').write_text(q.stdout+q.stderr);obs[arm]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)};events[arm]=[list(map(int,z)) for z in re.findall(r'^DIAG_ACCESS (\d+) (\d+) (-?\d+) (-?\d+)$',q.stderr,re.M)];pending[arm]=[list(map(int,z)) for z in re.findall(r'^DIAG_PENDING (\d+) (\d+) (-?\d+) (-?\d+)$',q.stderr,re.M)];assert re.search(r'^DIAG_EVENTS \d+ DROPS 0$',q.stderr,re.M)
  assert obs['baseline']==obs['diagnostic']==obs['quiet'],(kind,n,obs);assert not events['baseline'] and not events['quiet']
  actual=[[z[0],z[2],z[3]] for z in events['diagnostic'] if z[0] in [1,2]]
  expected=[[2,1,0]]+([[2,1,n],[1,1,0]] if n in [0,1] else []);result=(99 if n==0 else n) if n in [0,1] else None;items=[n,n]
  if n in [0,1]:items[n]=99
  assert actual==expected,(kind,n,actual,expected,events['diagnostic']);assert obs['diagnostic']['items']==['DIAG_VECTOR_ITEMS '+str(len(items))+' '+' '.join(map(str,items))]
  assert obs['diagnostic']['exit']==(120 if result is None else 0)
  if result is not None:assert int(re.search(r':result (-?\d+)',obs['diagnostic']['report'])[1])==result and not pending['diagnostic']
  else:assert [[z[0],z[2],z[3]] for z in pending['diagnostic']]==[[2,1,n]]
  rows.append({'variant':kind,'n':n,'expectedCompletedAccesses':expected,'expectedResult':result,'expectedItems':items,'observation':obs['diagnostic'],'events':events['diagnostic'],'pending':pending['diagnostic']});print('PASS independent completion/handle/index/alias oracle',kind,n,flush=True)
(w/'invalid-write-proof.json').write_text(json.dumps({'status':'complete-independent-native-completion-handle-index-alias-invalid-oracles','cases':len(rows),'quietGuestBytesAndOffsetsExact':True,'rows':rows},indent=2)+'\n')
