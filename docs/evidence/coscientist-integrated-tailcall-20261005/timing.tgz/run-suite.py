import hashlib,json,pathlib,re,subprocess,os
base=pathlib.Path('/private/tmp/amu-zebulun-paired-20261005')
root=pathlib.Path('/private/tmp/amu-zebulun-integrated-20261005')
repo=base/'repo'; matrix=json.loads((repo/'bench/embench/comparison-matrix.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(root/'integrated-amu')=='6420b1b3ee3d1a308e24677a2d2f6840d5866d93e65c8d68fe16c763eab4d6e2'
proof=[]
for e in matrix['entries']:
 w=e['workload']; d=root/'remote-compile'/w;d.mkdir(parents=True)
 source=repo/e['source'];assert sha(source)==e['expectedSourceSha256']
 for label,args in [('check',['check',str(source)]),('compile',['compile',str(source),'--target','aarch64-macos','--output',str(d/'image.kexe')]),('extract',['extract-native',str(d/'image.kexe'),'--symbol',e['symbol'],'--output',str(d/'native.bin')])]:
  p=subprocess.run([str(root/'integrated-amu'),*args],capture_output=True,text=True)
  (d/(label+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(w,label,p.stdout,p.stderr)
 assert sha(d/'native.bin')==sha(root/'candidate-ports'/w/'native.bin'),w
 proof.append({'workload':w,'sourceSha256':sha(source),'nativeSha256':sha(d/'native.bin'),'compilerSha256':sha(root/'integrated-amu')})
 print('REMOTE-COMPILE-PASS',w,flush=True)
(root/'remote-compile.json').write_text(json.dumps(proof,indent=2)+'\n')
(root/'timing').mkdir();env=dict(os.environ,PYTHONPATH=str(repo/'scripts/seed/image'))
for e in matrix['entries']:
 w=e['workload'];print('TIMING-START',w,flush=True)
 p=subprocess.run(['python3',str(root/'measure-native-candidate.py'),str(base/'measurement-2'),str(root/'candidate-ports'/w),str(base/'environment/runner'),str(repo/'bench/embench/paired-timing-spec.json'),str(root/'timing'/w)],env=env,capture_output=True,text=True)
 (root/'timing'/(w+'.log')).write_text(p.stdout+p.stderr)
 print('TIMING-END',w,p.returncode,p.stdout.strip(),p.stderr.strip(),flush=True)
 assert p.returncode==0,w
print('COMPLETE 19 remote recompiles and timing experiments',flush=True)
