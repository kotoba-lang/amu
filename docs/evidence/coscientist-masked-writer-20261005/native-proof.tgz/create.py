from pathlib import Path
import shutil,json
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-masked-writer-20261005');base=Path('/private/tmp/amu-scalar-tree-20261005');prior=Path('/private/tmp/amu-multi-cold-20261005');g=(r/'seed/41-a64gen.kotoba').read_text()
helper=''';; Exact charged mask-and-write composition. Keep it outside gn-call-wrapper
;; so prescan retains the caller's original nonleaf frame and fuel publication.
;; Natural parameters, AND255, one charged inline writer dependency, RET/END.
(defn- gn-mask-writer [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :bool
  (let [p (gn-fnf M f FF-SIR)
        q (gn-skiplab M (+ p 2))
        target (gn-sir M (+ q 5) IF-A)]
    (and (> p 0) (= n 3) (<= t 4) (= (gn-g M gn-f-leaf) 0)
         (not= (gn-op M (inc i)) OP-RES2)
         (= (gn-op M p) OP-FN) (= (gn-sir M p IF-A) f) (= (gn-sir M p IF-B) 3)
         (= (gn-op M (inc p)) OP-FUEL)
         (= (gn-wparams M q 0 3) (+ q 3))
         (= (gn-op M (+ q 3)) OP-CONST) (= (gn-sir M (+ q 3) IF-A) 3) (= (gn-sir M (+ q 3) IF-B) 255)
         (= (gn-op M (+ q 4)) OP-BIN) (= (gn-sir M (+ q 4) IF-A) BOP-AND) (= (gn-sir M (+ q 4) IF-B) 2)
         (= (gn-op M (+ q 5)) OP-CALL) (= (gn-sir M (+ q 5) IF-B) 0) (= (gn-sir M (+ q 5) IF-C) 3)
         (= (gn-wrapper M target 0 3) (+ RT-VECTOR-ASSOC-IN-PLACE 256))
         (= (gn-op M (+ q 6)) OP-RET) (= (gn-sir M (+ q 6) IF-A) 0)
         (= (gn-op M (+ q 7)) OP-END))))

'''
a='(defn- gn-use [M';assert g.count(a)==1;g=g.replace(a,helper+a)
emit=''';; Emulate the callee leaf transaction in x8, not caller gn-op-fuel.
;; x0/x8 are free in the retained nonleaf caller; pinned argument/live temps
;; are x9..x15, callee-saved locals or homes. Traps keep the pre-call fuel,
;; except original exhaustion, which publishes zero. Return publishes x8.
(defn- gn-mask-charge [M :vector-i64] :vector-i64
  (-> M (gn-emit (enc-subs-i 8 8 1)) (gn-emit (enc-bcond (enc-cond-hs) 3))
      (gn-emit (enc-str 31 7 CTX-FUEL)) (gn-emit (enc-brk 0))))
(defn- gn-call-mask-writer [M :vector-i64 t :i64] :vector-i64
  (let [M1 (-> M (gn-pin t) (gn-pin (inc t)))
        rv (gn-pinned M1 t) ri (gn-pinned M1 (inc t))]
    (-> M1 (gn-ctx) (gn-emit (enc-ldr 8 7 CTX-FUEL)) (gn-mask-charge)
        (gn-into 0 (+ t 2)) (gn-emit (gn-e-bf 0xd3400000 0 0 0 7))
        (gn-mask-charge) (gn-hchk rv 312 320) (gn-vidx ri)
        (gn-emit (gn-e-strr3 0 16 17)) (gn-emit (enc-str 8 7 CTX-FUEL))
        (gn-gs gn-f-h (inc t)))))

'''
a='(defn- gn-op-call [M';assert g.count(a)==1;g=g.replace(a,emit+a)
a='(cond (>= w 1024)';assert g.count(a)==1;g=g.replace(a,'(cond (gn-mask-writer M i f t n) (gn-call-mask-writer M t)\n         (>= w 1024)')
(w/'41-a64gen-prototype.kotoba').write_text(g);files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
for ext in ['bin','offset']:shutil.copyfile(base/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile(base/'kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['build.py','check-ports.py','bulk-state.py','prepare-timing.py','remote-all.py']:
 s=(prior/name).read_text().replace('amu-multi-cold-20261005','amu-masked-writer-20261005').replace('amu-zebulun-multi-cold-20261005','amu-zebulun-masked-writer-20261005').replace('ca907def12d5c55a826745f8b1a18812829331bf','1d04fda6b354ba7463201b86a72e42f23626bbf8');(w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'sourceHead':'1d04fda6b354ba7463201b86a72e42f23626bbf8','hypothesis':'Exact charged natural3param AND255 writer composition inlined only into retained nonleaf callers t<=4. Keep existing caller prescan/frame and original callee leaf transaction x8: two original charges, zero exhaustion, no contextfuel publication before bounds/write, final success publication. Exact charged inline writer dependency and RET/END; unknown shapes fallback.','promotion':'Native fixedpoint; original19 result/fuel/exhaustion and fullPico workspace; adversarial masks, lowfuel, trap/partialarena/context and refused-neighborhood proofs; freshquiet30 all changed originalC triples >=5% and gain>sumSD, no separated regressions.','exception':'One-off compiler algorithm authoring, not mechanical refactoring'},indent=2)+'\n')
