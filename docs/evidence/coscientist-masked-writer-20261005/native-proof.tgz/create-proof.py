from pathlib import Path
w=Path('/private/tmp/amu-masked-writer-20261005');s=Path('/private/tmp/amu-multi-cold-20261005/fixture-proof.py').read_text().replace('amu-multi-cold-20261005','amu-masked-writer-20261005')
pos=s.index('env=dict(os.environ')
extra='''# Exact admitted shape and refused neighborhoods, caller temp heights0..5.
m.fx('mw_unknown',1,1,[('LGET',0,1),('RET',0)])
for charged in [0,1]:
 m.fx('mw_put'+str(charged),3,3,([('FUEL',)] if charged else [])+[('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('RET',0)])
masktargets=[]
for outer,inner,mask in [(1,1,255),(0,1,255),(1,0,255),(1,1,65535)]:
 writer=f'mw_mask_{outer}{inner}_{mask}'
 body=([('FUEL',)] if outer else [])+[('LGET',0,1),('LGET',1,2),('LGET',2,3),('CONST',3,mask),('BIN','BOP-AND',2),('CALL','mw_put'+str(inner),0,3),('RET',0)]
 m.fx(writer,3,3,body)
 for t in ([0,1,4,5] if (outer,inner,mask)==(1,1,255) else [0]):
  for restore in [0,1]:
   caller=f'mw_call_{outer}{inner}_{mask}_{t}_{restore}';body=[('CONST',0,11),('CONST',1,-22),('CONST',2,33),('CONST',3,-44),('VEC',0,4),('LSET',3,0)]
   if restore:body+=[('CONST',0,7),('CALL','mw_unknown',0,1)]
   # One valid write followed by a possibly invalid write: observe partial arena.
   for ix in [0,1]:
    body+=[('CONST',j,100+j) for j in range(t)]+[('LGET',t,3)]
    body+=[('CONST',t+1,0)] if ix==0 else [('LGET',t+1,1)]
    body+=[('LGET',t+2,2),('CALL',writer,t,3),('RT','RT-VECTOR-COUNT',t,1)]
    for j in range(t-1,-1,-1):body+=[('BIN','BOP-ADD',j)]
    body+=[('LSET',4,0)]
   body+=[('LGET',0,4),('RET',0)];m.fx(caller,2,4,body);masktargets.append((caller,(outer,inner,mask)==(1,1,255) and t<=4,restore))
'''
s=s[:pos]+extra+s[pos:];start=s.index('code_end=');end=s.index("shutil.copyfile('/private/tmp/amu-scatter",start)
audit='''audit={}
for name,admitted,restore in masktargets:
 f=names.index(name)+1;start=fc[f];end=fc.get(f+1,len(blob));words=list(struct.unpack('<'+'I'*((end-start)//4),blob[start:end]));leafcharges=sum(x==0xf1000508 for x in words)
 assert (leafcharges==4 if admitted else leafcharges==0),(name,leafcharges,admitted)
 # Caller retains its original nonleaf prologue/context save and has no leaf
 # fuel initialization. Two calls each carry the two callee transaction checks.
 assert blob[start:start+24]==base[fb[f]:fb[f]+24],(name,'caller prologue changed')
 if admitted:
  for j,x in enumerate(words):
   if x==0xf1000508:assert words[j+1:j+4]==[0x54000062,0xf90004ff,0xd4200000],(name,j,'leaf exhaustion transaction')
  assert sum(x==0xf90004e8 for x in words)==2,(name,'success publications')
  assert sum(x==0x53001c00 for x in words)==0 # 64-bit UBFM, never truncate through w0.
 audit[name]={'admitted':admitted,'leafTransactionChecks':leafcharges,'callerPrologueUnchanged':True,'contextRestorationPredecessor':bool(restore)}

'''
s=s[:start]+audit+s[end:];point=s.index("(w/'fixture-proof.json').write_text")
more='''for name,admitted,restore in masktargets:
 f=names.index(name)+1
 for index in [-1,0,1,3,4,m.MIN,m.MAX]:
  for value in [m.MIN,-257,-1,0,255,256,m.MAX]:
   for budget in [*range(1,8),16777216]:
    args=[index,value];a=run(w/'fixture-baseline-code.bin',fb[f],args,budget);b=run(w/'fixture-candidate-code.bin',fc[f],args,budget);assert a==b,(name,args,budget,a,b);rows.append({'function':name,'args':args,'fuel':budget,**a})
 print('PASS exact maskedwriter transaction/state',name,flush=True)
'''
s=s[:point]+more+s[point:];(w/'fixture-proof.py').write_text(s)
