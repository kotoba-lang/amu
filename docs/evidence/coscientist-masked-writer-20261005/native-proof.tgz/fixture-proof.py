from pathlib import Path
import importlib.util,subprocess,os,re,json,types,struct,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-masked-writer-20261005');sp=importlib.util.spec_from_file_location('fx',r/'scripts/seed/a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
targets=[];audits=[]
m.fx('fr_unknown',2,2,[('LGET',0,1),('LGET',1,2),('BIN','BOP-ADD',0),('RET',0)])
for charged in [0,1]:
 writer='fr_write'+str(charged);m.fx(writer,3,3,([('FUEL',)] if charged else [])+[('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('RET',0)])
 for nonleaf in [0,1]:
  for count in [3,7]:
   for trap in ['none','bounds','division','read']:
    name=f'fr_{charged}{nonleaf}_{count}_{trap}';body=[]
    if nonleaf:body+=[('CONST',0,1),('CONST',1,2),('CALL','fr_unknown',0,2)]
    for k in range(count):
     body+=[('FUEL',),('LGET',0,1)]
     body+=[('LGET',1,2)] if trap=='bounds' and k==1 else [('CONST',1,k%4)]
     if trap=='read' and k==1:
      body+=[('LGET',1,2),('RT','RT-VECTOR-AT',0,2),('LSET',4,0),('LGET',0,1),('CONST',1,1)]
     if trap=='division' and k==2:body+=[('CONST',2,m.MIN),('LGET',3,3),('BIN','BOP-QUOT',2)]
     else:body+=[('CONST',2,99-k)]
     body+=[('CALL',writer,0,3)]
    body+=[('LGET',0,1),('RT','RT-VECTOR-COUNT',0,1),('RET',0)];m.fx(name,3,4,body)
    caller='call_'+name;m.fx(caller,2,3,[('CONST',0,11),('CONST',1,-22),('CONST',2,33),('CONST',3,-44),('VEC',0,4),('LSET',3,0),('LGET',0,3),('LGET',1,1),('LGET',2,2),('CALL',name,0,3),('RET',0)])
    cost=count*(charged+1);targets.append((caller,cost,trap));audits.append((name,cost,not nonleaf))
# Boundaries and refused neighborhoods. Region charge3 is intentionally split.
for tag,mid in [('label',[('LABEL','fr_label')]),('unknown',[('CONST',0,1),('CONST',1,2),('CALL','fr_unknown',0,2)]),('allocation',[('CONST',0,2),('RT','RT-VECTOR-ALLOC',0,1)]),('cap',[('CONST',0,2)]*128)]:
 name='fr_barrier_'+tag;m.fx(name,0,0,[('FUEL',)]+mid+[('FUEL',),('FUEL',),('CONST',0,17),('RET',0)]);targets.append((name,3,'none'))
for count in [3,7]:
 name='fr_deep'+str(count);m.fx(name,1,1,[('CONST',j,10+j) for j in range(8)]+[('FUEL',),('LGET',8,1),('BIN','BOP-ADD',7)]+[('FUEL',)]*(count-1)+[('BIN','BOP-ADD',j) for j in range(6,-1,-1)]+[('RET',0)]);targets.append((name,count,'scalar'));audits.append((name,count,True))
# Exact admitted shape and refused neighborhoods, caller temp heights0..5.
m.fx('mw_unknown',1,1,[('LGET',0,1),('CONST',1,1),('BIN','BOP-ADD',0),('RET',0)])
for charged in [0,1]:
 m.fx('mw_put'+str(charged),3,3,([('FUEL',)] if charged else [])+[('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('RET',0)])
masktargets=[]
for outer,inner,mask in [(1,1,255),(0,1,255),(1,0,255),(1,1,65535)]:
 writer=f'mw_mask_{outer}{inner}_{mask}'
 body=([('FUEL',)] if outer else [])+[('LGET',0,1),('LGET',1,2),('LGET',2,3),('CONST',3,mask),('BIN','BOP-AND',2),('CALL','mw_put'+str(inner),0,3),('RET',0)]
 m.fx(writer,3,3,body)
 for t in ([0,1,4,5] if (outer,inner,mask)==(1,1,255) else [0]):
  for restore in [0,1]:
   caller=f'mw_call_{outer}{inner}_{mask}_{t}_{restore}';body=[('CONST',0,11),('CONST',1,-22),('CONST',2,33),('CONST',3,-44),('VEC',0,4),('LSET',3,0)]
   if restore:body+=[('CONST',0,7),('CALL','mw_unknown',0,1)]
   # One valid write followed by a possibly invalid write: observe partial arena.
   for ix in [0,1]:
    body+=[('CONST',j,100+j) for j in range(t)]+[('LGET',t,3)]
    body+=[('CONST',t+1,0)] if ix==0 else [('LGET',t+1,1)]
    body+=[('LGET',t+2,2),('CALL',writer,t,3),('RT','RT-VECTOR-COUNT',t,1)]
    for j in range(t-1,-1,-1):body+=[('BIN','BOP-ADD',j)]
    body+=[('LSET',4,0)]
   body+=[('LGET',0,4),('RET',0)];m.fx(caller,2,4,body);masktargets.append((caller,(outer,inner,mask)==(1,1,255) and t<=4,restore))
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800');loader=str(w/'kexe-loader');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];chunks={}
for label,real,seed,backend in [('candidate-test',False,w/'seed-4.bin',w/'41-a64gen-prototype.kotoba'),('candidate-real',True,w/'seed-4.bin',w/'41-a64gen-prototype.kotoba'),('baseline-real',True,Path('/private/tmp/amu-scalar-tree-20261005/seed-4.bin'),r/'seed/41-a64gen.kotoba')]:
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+backend.read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real))
 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  p=subprocess.run([loader,str(seed),seed.with_suffix('.offset').read_text().strip(),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+mode+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(label,mode,p.stdout,p.stderr)
  if mode=='extract':off=re.search(r':offset (\d+)',p.stdout).group(1)
 p=subprocess.run([loader,str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'.stdout')).write_text(p.stdout);assert p.returncode==0,p.stderr;chunks[label]=p.stdout
assert m.blob_from(chunks['candidate-test'])[0].rstrip(b'\0')==m.blob_from(chunks['candidate-real'])[0].rstrip(b'\0') and m.blob_from(chunks['candidate-test'])[1]==m.blob_from(chunks['candidate-real'])[1]
d=w/'fixture-run/unit/41-a64gen';d.mkdir(parents=True,exist_ok=True);(d/'stdout').write_text(chunks['candidate-real']);os.environ['SEED_BUILD']=str(w/'fixture-run');original=m.subprocess.run
def bypass(args,**kw):
 if args[:2]==['zsh',m.R+'/scripts/seed/unit.sh']:return types.SimpleNamespace(returncode=0,stdout='native test/real fixture emitter already verified; product golden unchanged',stderr='')
 return original(args,**kw)
m.subprocess.run=bypass;assert m.runs(False)==0;m.subprocess.run=original
names=[f[0] for f in m.FIX];blob,fc=m.blob_from(chunks['candidate-real']);base,fb=m.blob_from(chunks['baseline-real']);(w/'fixture-candidate-code.bin').write_bytes(blob);(w/'fixture-baseline-code.bin').write_bytes(base)
code_end=4*sum(len(line.split())-1 for line in chunks['candidate-real'].splitlines() if line.startswith('w '))
audit={}
for name,admitted,restore in masktargets:
 f=names.index(name)+1;start=fc[f];end=fc.get(f+1,code_end);words=list(struct.unpack('<'+'I'*((end-start)//4),blob[start:end]));leafcharges=sum(x==0xf1000508 for x in words)
 assert (leafcharges==4 if admitted else leafcharges==0),(name,leafcharges,admitted)
 # Caller retains its original nonleaf prologue/context save and has no leaf
 # fuel initialization. Two calls each carry the two callee transaction checks.
 assert blob[start:start+24]==base[fb[f]:fb[f]+24],(name,'caller prologue changed')
 if admitted:
  if restore:
   saved=[x for x in words if x&0xffc003ff==0xf90003e7];assert len(saved)==1,(name,'context save slot')
   first=words.index(0xf94004e8);assert words[first-1]==saved[0]|0x00400000,(name,'missing restoration from actual frame slot before leaf transaction')
  for j,x in enumerate(words):
   if x==0xf1000508:assert words[j+1:j+4]==[0x54000062,0xf90004ff,0xd4200000],(name,j,'leaf exhaustion transaction')
  assert sum(x==0xf90004e8 for x in words)==2,(name,'success publications')
  assert sum(x==0xd3401c00 for x in words)==2,(name,'64bit mask')
 audit[name]={'admitted':admitted,'leafTransactionChecks':leafcharges,'callerPrologueUnchanged':True,'contextRestorationPredecessor':bool(restore)}

shutil.copyfile('/private/tmp/amu-scatter-zero-20261005/vector-state-loader',w/'vector-state-loader');(w/'vector-state-loader').chmod(0o755);rows=[]
def run(path,off,args,budget):
 e=dict(os.environ,KEXE_FUEL=str(budget),KEXE_STRUCTURED_REPORT='1',KEXE_CPU_SECONDS='30',KEXE_WALL_SECONDS='30');e.pop('KEXE_COMMAND',None)
 p=subprocess.run([str(w/'vector-state-loader'),str(path),str(off),str(len(args)),'aarch64','-',*map(str,args)],env=e,capture_output=True,text=True,timeout=35);q=re.search(r':fuel \{:initial (\d+) :remaining (\d+)\}',p.stdout);assert q,(args,budget,p.stdout,p.stderr);state=re.search(r'^DIAG_VECTOR_ITEMS (\d+)(.*)$',p.stderr,re.M);assert state,(args,budget,p.stderr);items=list(map(int,state.group(2).split()));assert len(items)==int(state.group(1));return {'items':items,'exit':p.returncode,'report':p.stdout.strip(),'fuelConsumed':int(q.group(1))-int(q.group(2)),'traps':re.findall(r'^KEXE_TRAP.*$',p.stderr,re.M)}
for name,cost,kind in targets:
 f=names.index(name)+1;argslist=[[0,1],[1,1],[-1,1],[4,1],[m.MIN,1],[m.MAX,1],[1,0],[1,-1]] if name.startswith('call_') else [[m.MIN],[-1],[0],[m.MAX]] if kind=='scalar' else [[]]
 for args in argslist:
  for budget in [*range(1,cost+3),16777216]:
   a=run(w/'fixture-baseline-code.bin',fb[f],args,budget);b=run(w/'fixture-candidate-code.bin',fc[f],args,budget);assert a==b,(name,args,budget,a,b);rows.append({'function':name,'args':args,'fuel':budget,**a})
 print('PASS exact fuel/trap/partial arena',name,flush=True)
for name,admitted,restore in masktargets:
 f=names.index(name)+1
 for index in [-1,0,1,3,4,m.MIN,m.MAX]:
  for value in [m.MIN,-257,-1,0,255,256,m.MAX]:
   for budget in [*range(1,8),16777216]:
    args=[index,value];a=run(w/'fixture-baseline-code.bin',fb[f],args,budget);b=run(w/'fixture-candidate-code.bin',fc[f],args,budget);assert a==b,(name,args,budget,a,b);rows.append({'function':name,'args':args,'fuel':budget,**a})
 print('PASS exact maskedwriter transaction/state',name,flush=True)
(w/'fixture-proof.json').write_text(json.dumps({'status':'complete-native-fixture-and-exact-supervisor-parity','canonicalRuns':len(m.RUNS),'fixtures':len(m.FIX),'realTestLayoutIdentical':True,'instructionAudit':audit,'supervisorComparisons':len(rows),'rows':rows},indent=2)+'\n')
