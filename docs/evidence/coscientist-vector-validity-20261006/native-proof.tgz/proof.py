from pathlib import Path
import os,subprocess,re,json,hashlib,importlib.util
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-vector-validity-20261006');raw=(r/'scripts/seed/a64gen-fixtures.py').read_text();needle="R = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))";frozen=w/'baseline-a64gen-fixtures.py'
if not frozen.exists():frozen.write_text(raw.replace(needle,"R = '/Users/junkawasaki/github/wt/amu-seed17'",1))
sp=importlib.util.spec_from_file_location('frozen',frozen);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);first=len(m.FIX)+1;cases=[];leaves=[]
for k in [1,2,-1,m.MIN]:
 for charged in [0,1]:
  leaf='vd_leaf_'+str(k)+'_'+str(charged);leaves.append(leaf);m.fx(leaf,2,2,([('FUEL',)] if charged else [])+[('LABEL',leaf+'_entry'),('LGET',0,1),('LGET',1,2),('CONST',2,k),('BIN','BOP-MUL',1),('RT','RT-VECTOR-AT',0,2),('RET',0)])
m.fx('vd_unknown',0,0,[('FUEL',),('CONST',0,1),('RT','RT-VECTOR-ALLOC',0,1),('CONST',0,77),('RET',0)])
for k,charge,t,mode in [(k,c,t,'none') for k in [2,-1,m.MIN] for c in [0,1] for t in [0,3,7,8]]+[(1,1,t,mode) for t in [0,7] for mode in ['none','fuel','arith','label','call','write','conj-old','conj-new','reassign','selfassign','different']]:
 leaf='vd_leaf_'+str(k)+'_'+str(charge);name=f'vd_case_{len(cases)}';body=[('FUEL',)]+[('CONST',j,11-3*j) for j in range(8)]+[('VEC',0,8),('LSET',4,0)]+[('CONST',j,100+j) for j in range(t)]+[('LGET',t,4),('LGET',t+1,1),('CALL',leaf,t,2),('LSET',5,t)]
 if mode=='fuel':body += [('FUEL',)]
 if mode=='arith':body += [('CONST',t+2,12),('CONST',t+3,5),('BIN','BOP-ADD',t+2),('LSET',6,t+2)]
 if mode=='label':body += [('LABEL',name+'_barrier')]
 if mode=='call':body += [('CALL','vd_unknown',t,0),('LSET',6,t)]
 if mode=='write':body += [('LGET',t,4),('CONST',t+1,0),('CONST',t+2,77),('RT','RT-VECTOR-ASSOC-IN-PLACE',t,3)]
 if mode.startswith('conj'):body += [('LGET',t,4),('CONST',t+1,99),('RT','RT-VECTOR-CONJ',t,2),('LSET',4 if mode=='conj-new' else 6,t)]
 if mode=='reassign':body += [('CONST',t,0),('LSET',4,t)]
 if mode=='selfassign':body += [('LGET',t,4),('LSET',4,t)]
 if mode=='different':body += [('CONST',t,99),('VEC',t,1),('LSET',4,t)]
 body += [('LGET',t,4),('LGET',t+1,2),('CALL',leaf,t,2)] + [('BIN','BOP-ADD',j) for j in range(t-1,-1,-1)]+[('LGET',1,5),('BIN','BOP-ADD',0),('LGET',1,3),('BIN','BOP-ADD',0),('RET',0)];m.fx(name,3,6,body);cases.append({'name':name,'k':k,'charge':charge,'t':t,'mode':mode,'admit':mode in ['none','fuel','arith']})
# Conditional bypass of the first read on an externally supplied invalid handle.
for charge in [0,1]:
 leaf='vd_leaf_1_'+str(charge);name=f'vd_bypass_{charge}';m.fx(name,3,4,[('FUEL',),('LGET',0,2),('BRZ',0,name+'_skip'),('LGET',0,1),('LGET',1,2),('CALL',leaf,0,2),('LSET',4,0),('BR',name+'_join'),('LABEL',name+'_skip'),('CONST',0,17),('LSET',4,0),('LABEL',name+'_join'),('LGET',0,1),('LGET',1,3),('CALL',leaf,0,2),('LGET',1,4),('BIN','BOP-ADD',0),('RET',0)]);cases.append({'name':name,'k':1,'charge':charge,'t':0,'mode':'bypass','admit':False})
ids={x[0]:j+1 for j,x in enumerate(m.FIX)};leafform='(or '+' '.join('(= f %d)'%ids[n] for n in leaves)+')'
typed='''(defn- vd-types [M :vector-i64 f :i64] :vector-i64
 (if (>= f LAST) M
  (vd-types (-> M (t-put (+ MM-FN-BASE (* f MM-FN-W) FF-PT0) (if LEAVES TY-VEC TY-I64))
                 (t-put (+ MM-FN-BASE (* f MM-FN-W) (+ FF-PT0 1)) TY-I64)
                 (t-put (+ MM-FN-BASE (* f MM-FN-W) FF-RTYPE) TY-I64)) (inc f))))
'''.replace('LAST',str(len(m.FIX)+1)).replace('LEAVES',leafform)
text=m.kotoba(True).replace('(defn- seed-main [] :i64',typed+'(defn- seed-main [] :i64',1);needle='        M0 (t-put MR (+ MM-FN-BASE (* %d MM-FN-W) FF-PT0) TY-I64)'%ids['reader_refuse_wrong-type'];assert text.count(needle)==1;text=text.replace(needle,needle.replace('M0','MD')+f'\n        M0 (vd-types MD {first})')
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];images={}
for label in ['baseline','candidate']:
 g=(w/('baseline-41-a64gen.kotoba' if label=='baseline' else '41-a64gen-prototype.kotoba')).read_text()
 if label=='candidate':
  st='"\\n"'
  for x in reversed(['i','t','(gn-dv M t)']):st='(string-concat (string-from-i64 '+x+') (string-concat " " '+st+'))'
  g=g.replace('checked (gn-vchecked M i t)]','checked (gn-vchecked M i t)\n        printed (if checked (io-out (string-concat "VCHECK " '+st+')) 0)]')
 src=w/(label+'-proof.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+g+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+text)
 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'-proof.kseed'))]),('extract',['extract-native',str(w/(label+'-proof.kseed')),'--symbol','main','--output',str(w/(label+'-proof.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-proof-'+mode+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,mode,q.stdout[-700:],q.stderr)
  if mode=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'-proof.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'-proof.stdout')).write_text(q.stdout);assert q.returncode==0,(label,q.stdout[-300:],q.stderr);blob,fc=m.blob_from(q.stdout);path=w/(label+'-fixture.bin');path.write_bytes(blob);images[label]=(path,fc)
 if label=='candidate':
  sites=set(tuple(map(int,l.split()[1:])) for l in q.stdout.splitlines() if l.startswith('VCHECK '));sir=m.layout_tables()[3];belongs={};fn=None
  for j,x in enumerate(sir,1):
   if x[0]==m.C['OP-FN']:fn=x[1]
   belongs[j]=fn
  for c in cases:
   n=sum(belongs[x[0]]==ids[c['name']] for x in sites);assert n==int(c['admit']),(c,n,sites)
(w/'fixture-ids.json').write_text(json.dumps(ids,indent=2)+'\n');(w/'cases.json').write_text(json.dumps(cases,indent=2)+'\n');rows=[];pairs=[(0,0),(1,2),(2,3),(m.MIN,0),(0,m.MIN),(1,m.MAX),(m.MAX,0),(-1,0),(0,-1),(4,0),(0,4),(0,8)]
for c in cases:
 for a,b in pairs:
  for live in [m.MIN,37]:
   for fuel in [1,2,3,4,16777216]:
    args=[0,a,b] if c['mode']=='bypass' else [a,b,live];obs={};mode=c['mode'];remaining=fuel-1;firstidx=m.s64(a*c['k']);secondidx=m.s64(b*c['k']);items=[11-3*j for j in range(8)] if mode!='bypass' else [];vectors=int(bool(items));answer=None;failed=False
    def charge(n):
     global remaining,failed
     if remaining<n:remaining=0;failed=True;return False
     remaining-=n;return True
    if mode=='bypass':
     # Supplied handle zero is invalid whenever the first/second read executes.
     if a!=0:
      saved=remaining
      if charge(c['charge']):remaining=saved;failed=True
     else:
      saved=remaining
      if charge(c['charge']):remaining=saved;failed=True
    else:
     saved=remaining
     if charge(c['charge']):
      if not 0<=firstidx<8:remaining=saved;failed=True
      else:
       firstval=items[firstidx]
       if mode=='fuel':charge(1)
       if mode=='call' and charge(1):vectors+=1;items+=[0]
       if not failed:
        if mode=='write':items[0]=77
        if mode in ['conj-old','conj-new','different']:vectors+=1;items+=[99]
        saved=remaining
        if charge(c['charge']):
         length=9 if mode=='conj-new' else 1 if mode=='different' else 8
         valid=mode!='reassign' and 0<=secondidx<length
         if not valid:remaining=saved;failed=True
         else:
          secondval=99 if mode=='different' else items[secondidx];answer=m.s64(firstval+secondval+live+sum(100+j for j in range(c['t'])))
    for label,(path,fc) in images.items():
     e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(path),str(fc[ids[c['name']]]),'3','aarch64','-',*map(str,args)],env=e,capture_output=True,text=True);assert ':fuel ' in q.stdout,(label,c,q.stdout,q.stderr);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
     if answer is not None:assert q.returncode==0 and re.search(r':result '+str(answer)+r'(?:\s|})',q.stdout),(label,c,a,b,live,fuel,answer,q.stdout,q.stderr)
     else:assert q.returncode!=0,(label,c,a,b,fuel,q.stdout)
     assert f':fuel {{:initial {fuel} :remaining {remaining}}}' in q.stdout,(c,a,b,fuel,remaining,q.stdout)
     assert f':vectors {{:capacity 4096 :used {vectors}}}' in q.stdout and f':vector-items {{:capacity 65536 :used {len(items)}}}' in q.stdout,(c,a,b,fuel,items,q.stdout)
     assert obs[label]['items']==['DIAG_VECTOR_ITEMS '+str(len(items))+(' '+' '.join(map(str,items)) if items else '')],(c,a,b,fuel,items,q.stderr)
    assert obs['baseline']==obs['candidate'],(c,a,b,live,fuel,obs);rows.append({'caller':c['name'],'mode':mode,'firstIndex':a,'secondIndex':b,'live':live,'fuel':fuel,'expect':answer,**obs})
 print('PASS hand result/fuel/items and full state',c['name'],mode,flush=True)
(w/'state-proof.json').write_text(json.dumps({'status':'complete-native-dominance-mutation-and-control-hand-state-proof','comparisons':len(rows),'fixtures':len(m.FIX),'callers':len(cases),'positiveSites':len(sites),'handDerivedFields':'result/trap,remainingfuel,vectorcount/allitems; complete baseline/candidate supervisor reports inclheap/pool/signals','runs':rows},indent=2)+'\n');print('PASS',len(rows),'native dominance/invalidation hand-oracle/full-state comparisons',flush=True)
