from pathlib import Path
import json,subprocess,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-vector-validity-20261006');base=Path('/private/tmp/amu-affine-reader-20261005');g=(r/'seed/41-a64gen.kotoba').read_text();original=g
proof=''';; Bounded same-local provenance at a previous read argument. Pure prefix only;
;; writes to the local or temp, control flow and unknown effects refuse.
(defn- gn-vlocal [M :vector-i64 j :i64 t :i64 s :i64 work :i64] :bool
 (if (or (<= j 0) (<= work 0)) false
  (let [op (gn-op M j) a (gn-sir M j IF-A) b (gn-sir M j IF-B)]
   (case op
    OP-LGET (if (= a t) (= b s) (gn-vlocal M (dec j) t s (dec work)))
    OP-CONST (and (not= a t) (gn-vlocal M (dec j) t s (dec work)))
    (OP-BIN OP-CMP OP-UN) (and (not= b t) (gn-vlocal M (dec j) t s (dec work)))
    OP-LSET (and (not= a s) (gn-vlocal M (dec j) t s (dec work)))
    OP-FUEL (gn-vlocal M (dec j) t s (dec work))
    false))))
;; Dominating successful exact closed reader in this straight-line region.
;; No branches/labels, capability/runtime mutation, unknown calls or reassignment.
;; A chain of admitted reads terminates at a real check (strict decreasing j).
(defn- gn-vdom [M :vector-i64 j :i64 s :i64 work :i64] :bool
 (if (or (<= j 0) (<= work 0)) false
  (let [op (gn-op M j) a (gn-sir M j IF-A) b (gn-sir M j IF-B) n (gn-sir M j IF-C)]
   (case op
    (OP-CONST OP-LGET OP-BIN OP-CMP OP-UN OP-FUEL) (gn-vdom M (dec j) s (dec work))
    OP-LSET (and (not= a s) (gn-vdom M (dec j) s (dec work)))
    OP-CALL (and (> (gn-affine-reader M j a n) 0)
              (or (gn-vlocal M (dec j) b s 32) (gn-vdom M (dec j) s (dec work))))
    false))))
(defn- gn-vchecked [M :vector-i64 i :i64 t :i64] :bool
 (and (gn-isk M t gn-k-local) (gn-vdom M (dec i) (gn-dv M t) 64)))
;; Reload descriptor afresh; only the already-proved handle range check goes.
;; Per-access length/index checks and fuel/trap publication remain unchanged.
(defn- gn-vaddr [M :vector-i64 rv :i64] :vector-i64
 (-> M (gn-emit (enc-sub-i 17 rv 1)) (gn-emit (enc-ldr 16 7 320))
       (gn-emit (gn-e-addsl 16 16 17 4))))
'''
pos=g.index('(defn- gn-call-affine-reader [');g=g[:pos]+proof+g[pos:]
old='k (gn-sir M (+ q 2) IF-B) shift (gn-pow2 k)]';assert g.count(old)==1;g=g.replace(old,'k (gn-sir M (+ q 2) IF-B) shift (gn-pow2 k) checked (gn-vchecked M i t)]')
old='(gn-hchk 0 312 320) (gn-vidx 1)';assert g.count(old)==1;g=g.replace(old,'(cond-> checked (gn-vaddr 0) (not checked) (gn-hchk 0 312 320)) (gn-vidx 1)')
(w/'baseline-41-a64gen.kotoba').write_text(original);(w/'41-a64gen-prototype.kotoba').write_text(g)
parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')]
unity=lambda text:''.join((text if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in parts)
(w/'seed-unity.kotoba').write_text(unity(g))
s='"\\n"'
for x in reversed(['i','t','(gn-dv M t)']):s='(string-concat (string-from-i64 '+x+') (string-concat " " '+s+'))'
g=g.replace('checked (gn-vchecked M i t)]','checked (gn-vchecked M i t)\n        printed (if checked (io-out (string-concat "VCHECK " '+s+')) 0)]');(w/'observer-unity.kotoba').write_text(unity(g))
for ext in ['bin','offset']:shutil.copyfile(base/('seed-4.'+ext),w/('seed-0.'+ext))
shutil.copyfile(base/'kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['build.py','check-ports.py','observe-admission.py','observer-byte-audit.py']:
 s=(base/name).read_text().replace('amu-affine-reader-20261005','amu-vector-validity-20261006')
 if name=='observe-admission.py':s=s.replace('READCALL ','VCHECK ').replace('affineReaderCallSites','reusedValiditySites')
 (w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'status':'registered-before-native-build-or-timing','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'hypothesis':'Bounded straight-line dominance and unchanged-local provenance allow reusing successful handle validation across exact closed affine readers. Reload descriptor and retain original per-access index checks/private fuel. Reject control flow, mutation, unknown effects/calls/imports/local reassignment.','recognition':'Current handle temp must be LOCAL; scan<=64 records; prior exact closed reader handle comes from same unchanged local via <=32-record pure provenance. Strict backward chain ends at a real check.','proof':'Native all19 actual admission, signed/invalid/fuel/alias/mutation/control/open-import full-state hand oracles, fixedpoint, originalquiet30rotatingtriples for everychangedguest same1.05+sumSD, thenfullgates/integrated3gen/corpus. No caching of execution results.','runtimeCorrection':'checked_vector_conj returns intern_vector(new offset/length); intern_vector increments vector_used before initializing a new index. No existing descriptor mutation appears in those paths. This candidate nevertheless crosses no mutation/runtime effect and reloads the descriptor.','exception':'One-off new Kotoba compiler algorithm and diagnostic authoring; no existing mechanical AST refactor rule covers it; product remains unchanged.'},indent=2)+'\n');print('registered bounded dominance/provenance native hypothesis; product unchanged')
