from pathlib import Path
import subprocess,re,os,json,struct
w=Path('/private/tmp/amu-vector-validity-20261006');scope={};s=(w/'proof.py').read_text();exec(s[:s.index('env=dict(')],scope);m=scope['m'];r=scope['r'];ids=scope['ids'];target=ids['vd_leaf_2_1'];m.fx('vd_replacement',2,2,[('FUEL',),('CONST',0,1),('RT','RT-VECTOR-ALLOC',0,1),('CONST',0,77),('RET',0)]);replacement=len(m.FIX);text=scope['text'];env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];images={}
# Regenerate text after appending the actual replacement; preserve identical metadata prefix.
fresh=m.kotoba(True);old=scope['text'];marker='(defn- seed-main [] :i64';fresh=fresh.replace(marker,scope['typed']+marker,1);needle='        M0 (t-put MR (+ MM-FN-BASE (* %d MM-FN-W) FF-PT0) TY-I64)'%ids['reader_refuse_wrong-type'];fresh=fresh.replace(needle,needle.replace('M0','MD')+f'\n        M0 (vd-types MD {scope["first"]})')
for label in ['baseline-open','candidate-open','candidate-closed']:
 test=fresh if label.endswith('closed') else fresh.replace('(gn-run M0)',f'(gn-run-open M0 {target} 1)',1);backend=(w/('baseline-41-a64gen.kotoba' if label.startswith('baseline') else '41-a64gen-prototype.kotoba')).read_text();src=w/(label+'-imports.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+backend+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+test)
 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'-imports.kseed'))]),('extract',['extract-native',str(w/(label+'-imports.kseed')),'--symbol','main','--output',str(w/(label+'-imports.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-imports-'+mode+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,mode,q.stdout[-500:],q.stderr)
  if mode=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'-imports.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'-imports.stdout')).write_text(q.stdout);assert q.returncode==0,(label,q.stdout[-400:],q.stderr);blob,fc=m.blob_from(q.stdout);patched=bytearray(blob);struct.pack_into('<I',patched,fc[target],0x14000000|(((fc[replacement]-fc[target])//4)&0x3ffffff));p=w/(label+'-linked.bin');p.write_bytes(patched);images[label]=(p,fc)
rows=[]
for c in scope['cases']:
 if c['k']!=2 or c['charge']!=1:continue
 for a,b in [(0,0),(m.MIN,m.MAX),(-1,8)]:
  for fuel in [1,2,3,16777216]:
   pair={}
   for label,(p,fc) in images.items():
    e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(p),str(fc[ids[c['name']]]),'3','aarch64','-',str(a),str(b),'37'],env=e,capture_output=True,text=True);assert ':fuel ' in q.stdout,(label,c,q.stdout,q.stderr);pair[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
   assert pair['baseline-open']==pair['candidate-open'],(c,a,b,fuel,pair)
   if fuel>=3:
    answer=154+37+sum(100+j for j in range(c['t']));assert re.search(r':result '+str(answer)+r'(?:\s|})',pair['candidate-open']['report']);assert pair['candidate-open']!=pair['candidate-closed'];assert pair['candidate-open']['items']==['DIAG_VECTOR_ITEMS 10 11 8 5 2 -1 -4 -7 -10 0 0']
   rows.append({'caller':c['name'],'first':a,'second':b,'fuel':fuel,**pair})
(w/'import-proof.json').write_text(json.dumps({'status':'complete-native-open-reader-double-allocating-import-parity','comparisons':len(rows),'closedControlsDiffer':True,'actualReplacement':'samevector/i64->i64signature,chargesfuel,allocatesandreturns77; diagnosticallocatorclobbersx7','runs':rows},indent=2)+'\n');print('PASS',len(rows),'actual double allocating-import comparisons')
