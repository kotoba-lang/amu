from pathlib import Path
import os,subprocess,re,json,hashlib,importlib.util
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-vector-validity-20261006');raw=(r/'scripts/seed/a64gen-fixtures.py').read_text();needle="R = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))";frozen=w/'baseline-a64gen-fixtures.py'
if not frozen.exists():frozen.write_text(raw.replace(needle,"R = '/Users/junkawasaki/github/wt/amu-seed17'",1))
sp=importlib.util.spec_from_file_location('frozen',frozen);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);first=len(m.FIX)+1;cases=[];leaves=[]
for k in [1,2,-1,m.MIN]:
 for charged in [0,1]:
  leaf='vd_leaf_'+str(k)+'_'+str(charged);leaves.append(leaf);m.fx(leaf,2,2,([('FUEL',)] if charged else [])+[('LABEL',leaf+'_entry'),('LGET',0,1),('LGET',1,2),('CONST',2,k),('BIN','BOP-MUL',1),('RT','RT-VECTOR-AT',0,2),('RET',0)])
m.fx('vd_unknown',0,0,[('FUEL',),('CONST',0,1),('RT','RT-VECTOR-ALLOC',0,1),('CONST',0,77),('RET',0)])
for k,charge,t,mode in [(k,c,t,'none') for k in [2,-1,m.MIN] for c in [0,1] for t in [0,3,7,8]]+[(1,1,t,mode) for t in [0,7] for mode in ['none','fuel','arith','label','call','write','conj-old','conj-new','reassign','selfassign','different']]:
 leaf='vd_leaf_'+str(k)+'_'+str(charge);name=f'vd_case_{len(cases)}';body=[('FUEL',)]+[('CONST',j,11-3*j) for j in range(8)]+[('VEC',0,8),('LSET',4,0)]+[('CONST',j,100+j) for j in range(t)]+[('LGET',t,4),('LGET',t+1,1),('CALL',leaf,t,2),('LSET',5,t)]
 if mode=='fuel':body += [('FUEL',)]
 if mode=='arith':body += [('CONST',t+2,12),('CONST',t+3,5),('BIN','BOP-ADD',t+2),('LSET',6,t+2)]
 if mode=='label':body += [('LABEL',name+'_barrier')]
 if mode=='call':body += [('CALL','vd_unknown',t,0),('LSET',6,t)]
 if mode=='write':body += [('LGET',t,4),('CONST',t+1,0),('CONST',t+2,77),('RT','RT-VECTOR-ASSOC-IN-PLACE',t,3)]
 if mode.startswith('conj'):body += [('LGET',t,4),('CONST',t+1,99),('RT','RT-VECTOR-CONJ',t,2),('LSET',4 if mode=='conj-new' else 6,t)]
 if mode=='reassign':body += [('CONST',t,0),('LSET',4,t)]
 if mode=='selfassign':body += [('LGET',t,4),('LSET',4,t)]
 if mode=='different':body += [('CONST',t,99),('VEC',t,1),('LSET',4,t)]
 body += [('LGET',t,4),('LGET',t+1,2),('CALL',leaf,t,2)] + [('BIN','BOP-ADD',j) for j in range(t-1,-1,-1)]+[('LGET',1,5),('BIN','BOP-ADD',0),('LGET',1,3),('BIN','BOP-ADD',0),('RET',0)];m.fx(name,3,6,body);cases.append({'name':name,'k':k,'charge':charge,'t':t,'mode':mode,'admit':mode in ['none','fuel','arith']})
# Conditional bypass of the first read on an externally supplied invalid handle.
for charge in [0,1]:
 leaf='vd_leaf_1_'+str(charge);name=f'vd_bypass_{charge}';m.fx(name,3,4,[('FUEL',),('LGET',0,2),('BRZ',0,name+'_skip'),('LGET',0,1),('LGET',1,2),('CALL',leaf,0,2),('LSET',4,0),('BR',name+'_join'),('LABEL',name+'_skip'),('CONST',0,17),('LSET',4,0),('LABEL',name+'_join'),('LGET',0,1),('LGET',1,3),('CALL',leaf,0,2),('LGET',1,4),('BIN','BOP-ADD',0),('RET',0)]);cases.append({'name':name,'k':1,'charge':charge,'t':0,'mode':'bypass','admit':False})
ids={x[0]:j+1 for j,x in enumerate(m.FIX)};leafform='(or '+' '.join('(= f %d)'%ids[n] for n in leaves)+')'
typed='''(defn- vd-types [M :vector-i64 f :i64] :vector-i64
 (if (>= f LAST) M
  (vd-types (-> M (t-put (+ MM-FN-BASE (* f MM-FN-W) FF-PT0) (if LEAVES TY-VEC TY-I64))
                 (t-put (+ MM-FN-BASE (* f MM-FN-W) (+ FF-PT0 1)) TY-I64)
                 (t-put (+ MM-FN-BASE (* f MM-FN-W) FF-RTYPE) TY-I64)) (inc f))))
'''.replace('LAST',str(len(m.FIX)+1)).replace('LEAVES',leafform)
text=m.kotoba(True).replace('(defn- seed-main [] :i64',typed+'(defn- seed-main [] :i64',1);needle='        M0 (t-put MR (+ MM-FN-BASE (* %d MM-FN-W) FF-PT0) TY-I64)'%ids['reader_refuse_wrong-type'];assert text.count(needle)==1;text=text.replace(needle,needle.replace('M0','MD')+f'\n        M0 (vd-types MD {first})')

text=m.kotoba(False).replace('(defn- seed-main [] :i64',typed+'(defn- seed-main [] :i64',1)
needle='        M0 (t-put MR (+ MM-FN-BASE (* %d MM-FN-W) FF-PT0) TY-I64)'%ids['reader_refuse_wrong-type']
assert text.count(needle)==1
text=text.replace(needle,needle.replace('M0','MD')+f'\n        M0 (vd-types MD {first})')
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];label='new-test'
src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+text)
for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
 q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+mode+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(mode,q.stdout[-500:],q.stderr)
 if mode=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0;(w/(label+'.stdout')).write_text(q.stdout)
a=m.blob_from(q.stdout);b=m.blob_from((w/'candidate-proof.stdout').read_text());assert a[1]==b[1] and a[0][:len(b[0])]==b[0] and not any(a[0][len(b[0]):]);assert 0<=len(a[0])-len(b[0])<=7
(w/'layout-proof.json').write_text(json.dumps({'status':'complete-native-real-test-new-layout-equality','fixtures':len(m.FIX),'realFnOffsetsEqual':True,'realCodeAndLiteralBytesEqual':True,'testOnlyPaddingBytes':len(a[0])-len(b[0])},indent=2)+'\n');print('PASS new399-fixture real/test layout')
