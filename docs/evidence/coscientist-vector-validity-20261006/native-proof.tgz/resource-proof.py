from pathlib import Path
import json,os,re,subprocess,importlib.util
w=Path('/private/tmp/amu-vector-validity-20261006');sp=importlib.util.spec_from_file_location('m',w/'baseline-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
ids=json.loads((w/'fixture-ids.json').read_text());cases=json.loads((w/'cases.json').read_text());images={label:(w/(label+'-fixture.bin'),m.blob_from((w/(label+'-proof.stdout')).read_text())[1]) for label in ['baseline','candidate']};rows=[]
for c in cases:
 if c['mode'] not in ['call','conj-old','conj-new','different']:continue
 for budget,key,val in [('table','KEXE_VECTORS',1),('items','KEXE_VECTOR_ITEMS',8)]:
  fuel=16777216;remaining=fuel-(3 if c['mode']=='call' else 2);items=[11-3*j for j in range(8)]
  if budget=='table':items += [0 if c['mode'] in ['call','different'] else 99]
  obs={}
  for label,(path,fc) in images.items():
   env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');env[key]=str(val);env.pop('KEXE_COMMAND',None)
   q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(path),str(fc[ids[c['name']]]),'3','aarch64','-','0','0','37'],env=env,capture_output=True,text=True)
   assert q.returncode!=0 and f':remaining {remaining}' in q.stdout,(c,budget,q.stdout,q.stderr)
   assert re.search(r':vectors \{:capacity \d+ :used 1\}',q.stdout) and re.search(r':vector-items \{:capacity \d+ :used '+str(len(items))+r'\}',q.stdout),(c,budget,q.stdout)
   obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
   assert obs[label]['items']==['DIAG_VECTOR_ITEMS '+str(len(items))+' '+' '.join(map(str,items))],(c,budget,q.stderr)
  assert obs['baseline']==obs['candidate'];rows.append({'caller':c['name'],'mode':c['mode'],'budget':budget,'expectRemainingFuel':remaining,'expectItems':items,**obs})
(w/'resource-proof.json').write_text(json.dumps({'status':'complete-native-resource-exhaustion-partial-write-hand-oracle','comparisons':len(rows),'runs':rows},indent=2)+'\n');print('PASS',len(rows),'resource exhaustion/partial writes')
