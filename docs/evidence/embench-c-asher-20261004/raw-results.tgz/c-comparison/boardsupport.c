#include <stdint.h>
#include <stdio.h>
#include <time.h>
static uint64_t start;
static uint64_t now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return (uint64_t)t.tv_sec * 1000000000 + t.tv_nsec; }
void initialise_board(void) {}
void start_trigger(void) { start = now(); }
void stop_trigger(void) { printf("%llu\n", (unsigned long long)(now() - start)); }
