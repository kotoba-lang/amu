"""Prepared local fullbody diagnostic only. Explicit phase-specific root GO required."""
from pathlib import Path
import json,hashlib,subprocess,os,re,sys,traceback
R=Path(__file__).resolve().parent;D=R.parent;P=D/'timing-package';W=R/'results';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def main():
 if len(sys.argv)!=3 or sys.argv[1] not in ['preflight','remaining']:raise SystemExit('run.py preflight|remaining ROOT_PHASE_GO.json; no implicit execution')
 phase=sys.argv[1];go=json.loads(Path(sys.argv[2]).read_text())
 assert go['allowLocalFullBodyNative'] is True and go['allowTiming'] is False
 assert go['compilerMQualificationAccepted'] is True
 assert go['preregistrationSHA256']==sha(R/'preregistration.json') and go['runnerSHA256']==sha(Path(__file__))
 assert go['hostBuildCap']==38 and go['nativeInvocationCap']==198 and go['phase']==phase
 pr=json.loads((R/'preregistration.json').read_text())
 for path,pin in pr['inputPins'].items():assert sha(Path(path))==pin['sha256'],path
 schedule=json.loads((R/'schedule.json').read_text());manifest=json.loads((P/'manifest.json').read_text());byname={e['workload']:e for e in manifest['entries']}
 if phase=='preflight':
  assert go['maximumPairsThisPhase']==19 and not W.exists();W.mkdir();save(W/'preflight-authorization.json',go);attempts={'builds':[],'runs':[]};pairs=[]
 else:
  assert go['maximumPairsThisPhase']==80 and (W/'preflight-terminal.json').exists() and not (W/'remaining-terminal.json').exists()
  assert json.loads((W/'preflight-terminal.json').read_text())['status']=='PASS19preflightpairs'
  attempts=json.loads((W/'attempts.json').read_text());pairs=json.loads((W/'pairs.json').read_text());assert len(attempts['builds'])==38 and len(attempts['runs'])==38 and len(pairs)==19
  save(W/'remaining-authorization.json',go)
 def build(row,arm):
  assert len(attempts['builds'])<38;p=W/row['workload']/arm;p.mkdir(parents=True);raw=(P/row['workload']/(arm+'.bin')).read_bytes();off=row['baselineOffset' if arm=='baseline' else 'candidateOffset']
  assert 0<=off<len(raw) and off%4==0;assert hashlib.sha256(raw).hexdigest()==row['baselineNativeSHA256' if arm=='baseline' else 'candidateNativeSHA256'];(p/'image.bin').write_bytes(raw)
  vals={'REQUIRED_HOST_FEATURES':'6ULL','OFFSET':str(off)+'u','ARITY':'0u','ISA':'"aarch64"','ALLOW':'"-"','SCOPE35':'""','SCOPE34':'""','SPAWN_PROGRAMS':'""','SPAWN_ENV':'""','SPAWN_PATH_LOOKUP':'0','STRING_POOL':'16777216u','FUEL':'16777216u','PAIRS':'1048576u','VECTORS':'131072u','VECTOR_ITEMS':'4194304u','CPU_SECONDS':'15u','WALL_SECONDS':'20u'}
  header='#define KEXE_EMBEDDED 1\n'+''.join('#define KEXE_EMBEDDED_'+k+' '+v+'\n' for k,v in vals.items())+'static const unsigned char kexe_embedded_code[] = {'+','.join(map(str,raw))+'};\n';(p/'embedded.h').write_text(header)
  cmd=['clang','-O2','-std=c11','-include',str(p/'embedded.h'),str(R/'diagnostic-loader.c'),'-o',str(p/'loader')]
  a={'workload':row['workload'],'arm':arm,'argv':cmd,'sourceSHA256':sha(R/'diagnostic-loader.c'),'headerSHA256':sha(p/'embedded.h'),'imageSHA256':sha(p/'image.bin'),'offset':off,'state':'started'};attempts['builds'].append(a);save(W/'attempts.json',attempts)
  try:q=subprocess.run(cmd,capture_output=True,timeout=1800);stdout=q.stdout;stderr=q.stderr;rc=q.returncode
  except subprocess.TimeoutExpired as e:stdout=e.stdout or b'';stderr=e.stderr or b'';rc=None;a['timeout']=True
  (p/'build.stdout').write_bytes(stdout);(p/'build.stderr').write_bytes(stderr);a.update(state='terminal',exit=rc);save(p/'build.status.json',a);save(W/'attempts.json',attempts);assert rc==0,(row['workload'],arm,stderr[-1000:]);a['binarySHA256']=sha(p/'loader');save(W/'attempts.json',attempts)
 def capture(spec,arm):
  assert len(attempts['runs'])<198;p=W/spec['workload']/arm;label='case'+str(spec['originalIndex']);assert not (p/(label+'.json')).exists()
  built=next(a for a in attempts['builds'] if a['workload']==spec['workload'] and a['arm']==arm);assert sha(p/'loader')==built['binarySHA256'] and sha(p/'image.bin')==built['imageSHA256']
  env=dict(os.environ,KEXE_STRUCTURED_REPORT='1',DIAG_ARG0=str(spec['args'][0]),DIAG_FUEL=str(spec['fuel']))
  for k in range(1,5):env['DIAG_ARG'+str(k)]='0'
  a={'workload':spec['workload'],'arm':arm,'caseOriginalIndex':spec['originalIndex'],'args':spec['args'],'fuel':spec['fuel'],'state':'started'};attempts['runs'].append(a);save(W/'attempts.json',attempts)
  try:q=subprocess.run([str(p/'loader')],env=env,capture_output=True,text=True,timeout=30);raw={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
  except subprocess.TimeoutExpired as e:raw={'exit':None,'timeout':True,'stdout':(e.stdout or b'').decode(errors='replace'),'stderr':(e.stderr or b'').decode(errors='replace')}
  save(p/(label+'.json'),raw);a.update(state='terminal',receiptSHA256=sha(p/(label+'.json')));save(W/'attempts.json',attempts);return raw
 try:
  if phase=='preflight':
   for row in manifest['entries']:
    for arm in ['baseline','candidate']:build(row,arm)
   assert len(attempts['builds'])==38
  for spec in schedule['preflight' if phase=='preflight' else 'remaining']:
   b=capture(spec,'baseline');c=capture(spec,'candidate');row={'spec':spec,'baseline':b,'candidate':c};pairs.append(row);save(W/'pairs.json',pairs)
   assert b==c,('actualfullsupervisor mismatch',spec,b,c)
   assert b.get('timeout') is not True and b['exit'] is not None and b['exit']>=0
   initial=int(re.search(r':initial (\d+)',b['stdout'])[1]);remaining=int(re.search(r':remaining (\d+)',b['stdout'])[1]);assert initial==spec['fuel'] and 0<=remaining<=initial
   if spec['phase']=='ordinary-original-fullbody':
    assert b['exit']==0 and ':status :ok' in b['stdout'] and re.search(r':result 1\b',b['stdout']),b
    # Native fuel expectation is pinned retained semantic/source hypothesis;
    # this is a NEW observation and candidate qualification, especially AES.
    info=byname[spec['workload']]
    if spec['args']==[info['n']]:assert initial-remaining==info['expectedNativeFuelConsumed'],(spec,initial-remaining,info)
   print('PASS originalfullbody',spec['workload'],spec['args'][0],spec['fuel'],flush=True)
  expected=19 if phase=='preflight' else 99;assert len(pairs)==expected and len(attempts['runs'])==expected*2
  report={'status':'PASS19preflightpairs' if phase=='preflight' else 'PASS99originalfullbodypairs','pairs':len(pairs),'guestInvocations':len(attempts['runs']),'hostBuilds':len(attempts['builds']),'currentOriginal19NativeSuccess':phase=='remaining','timing':False,'statisticsUsed':False,'changedAESQualification':'firstn1only' if phase=='preflight' else 'freshn0/n1/n32success16M and actualconsumedfuel matchingRF/sourceexpectation; fuelprefix14x3fullstate','reporterLimits':'Finalsupervisor/trap/allocator/fuel observations only; no nativeasync perstore samples; metered0/highu64 diagnostic not productbudget admission'}
  if phase=='remaining':
   report['ordinaryFuelConsumption']=[{'workload':x['spec']['workload'],'n':x['spec']['args'][0],'consumed':x['spec']['fuel']-int(re.search(r':remaining (\d+)',x['candidate']['stdout'])[1]),'nativeSHA256':byname[x['spec']['workload']]['candidateNativeSHA256']} for x in pairs if x['spec']['phase']=='ordinary-original-fullbody']
  save(W/(phase+'-report.json'),report)
 except BaseException as e:save(W/(phase+'-failure.json'),{'exception':repr(e),'traceback':traceback.format_exc(),'pairsRetained':len(pairs),'nativeInvocations':len(attempts['runs']),'builds':len(attempts['builds'])});raise
 finally:save(W/(phase+'-pins.json'),{str(p.relative_to(W)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(W.rglob('*')) if p.is_file() and p.name not in [phase+'-pins.json',phase+'-terminal.json']})
 save(W/(phase+'-terminal.json'),{'status':report['status'],'reportSHA256':sha(W/(phase+'-report.json')),'pinsSHA256':sha(W/(phase+'-pins.json')),'allPhaseWritesComplete':True})
if __name__=='__main__':main()
