"""Remaining80 pairs only, frozen existing38hosts; no build or preflight rerun."""
from pathlib import Path
import json,hashlib,os,sys,subprocess,re
W=Path(__file__).parent;P=W.parent;A=P/'team-inverse-timing-prep/local-fullbody-runtime';OLD=A/'results';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def main():
 if len(sys.argv)!=2:raise SystemExit('ROOT remaining-v2authorization required')
 a=json.loads(Path(sys.argv[1]).read_text());pr=json.loads((W/'preregistration.json').read_text())
 assert a['allowLocalFullBodyNative'] is True and a['allowTiming'] is False and a['phase']=='remaining-v2'
 assert a['hostBuildCap']==0 and a['nativeInvocationCap']==160 and a['maximumPairsThisPhase']==80
 assert a['preregistrationSHA256']==sha(W/'preregistration.json') and a['runnerSHA256']==sha(Path(__file__)) and a['scheduleSHA256']==sha(W/'schedule.json') and a['sourceExpectationsSHA256']==sha(W/'source-expectations.json')
 for s,r in pr['inputs'].items():p=Path(s);assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],s
 terminal=json.loads((OLD/'preflight-terminal.json').read_text());assert terminal['status']=='PASS19preflightpairs'
 attempts=json.loads((OLD/'attempts.json').read_text());assert len(attempts['builds'])==38 and len(attempts['runs'])==38
 first=json.loads((OLD/'pairs.json').read_text());assert len(first)==19
 spec=json.loads((W/'schedule.json').read_text());assert len(spec)==80
 byname={r['workload']:r for r in json.loads((A.parent/'timing-package/manifest.json').read_text())['entries']}
 out=W/'actual';assert not out.exists();out.mkdir();save(out/'authorization.json',a);rows=[];calls=[]
 def capture(s,arm):
  assert len(calls)<160;b=next(r for r in attempts['builds']if r['workload']==s['workload']and r['arm']==arm);p=OLD/s['workload']/arm
  assert sha(p/'loader')==b['binarySHA256'] and sha(p/'image.bin')==b['imageSHA256']
  env=dict(os.environ,KEXE_STRUCTURED_REPORT='1',DIAG_ARG0=str(s['args'][0]),DIAG_FUEL=str(s['fuel']))
  for k in range(1,5):env['DIAG_ARG'+str(k)]='0'
  c={'workload':s['workload'],'arm':arm,'index':s['originalIndex'],'state':'started'};calls.append(c);save(out/'attempts.json',calls)
  try:q=subprocess.run([str(p/'loader')],env=env,capture_output=True,text=True,timeout=30);raw={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
  except subprocess.TimeoutExpired as e:raw={'exit':None,'timeout':True,'stdout':(e.stdout or b'').decode(errors='replace'),'stderr':(e.stderr or b'').decode(errors='replace')}
  path=out/(str(s['originalIndex'])+'-'+arm+'.json');save(path,raw);c.update(state='terminal',receiptSHA256=sha(path));save(out/'attempts.json',calls);return raw
 try:
  for s in spec:
   b=capture(s,'baseline');c=capture(s,'candidate');rows.append({'spec':s,'baseline':b,'candidate':c});save(out/'pairs.json',rows)
   assert b==c and not b.get('timeout') and b['exit'] is not None and b['exit']>=0,(s,b,c)
   initial=int(re.search(r':initial (\d+)',b['stdout'])[1]);remaining=int(re.search(r':remaining (\d+)',b['stdout'])[1]);assert initial==s['fuel'] and 0<=remaining<=initial
   if s['phase']=='ordinary-original-fullbody':
    match=re.search(r':result (-?\d+)\b',b['stdout']);assert b['exit']==0 and ':status :ok' in b['stdout'] and match and int(match[1])==s['expectedResult'],(s,b)
    info=byname[s['workload']]
    if s['args']==[info['n']]:assert initial-remaining==info['expectedNativeFuelConsumed'],(s,initial-remaining)
   print('PASS remaining-v2',s['workload'],s['args'][0],s['fuel'],flush=True)
  assert len(rows)==80 and len(calls)==160
  assert len({r['spec']['originalIndex']for r in first+rows})==99
  save(out/'report.json',{'status':'PASS remaining80pairsonly','additionalNativeCalls':160,'hostBuilds':0,'retainedFirst19Pairs':19,'retainedFirst38Calls':38,'uniqueOriginal99PairsAcrossProcedures':True,'singleVersion99Campaign':False,'expectedZeroSource':'19source-backedn0return0; positiveordinary1','limits':'Finalsupervisor comparison; private mask6; no asyncstore/performance or broadposttakeencodererror qualification'})
 except BaseException as e:
  save(out/'report.json',{'status':'FAIL no retry','exception':repr(e),'pairsRetained':len(rows),'additionalCalls':len(calls),'hostBuilds':0});raise
 finally:
  save(out/'pins.json',{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)}for p in out.iterdir()if p.is_file()and p.name not in ['pins.json','terminal.json']})
  save(out/'terminal.json',{'allWritesComplete':True,'reportSHA256':sha(out/'report.json'),'pinsSHA256':sha(out/'pins.json')})
if __name__=='__main__':main()
