"""Fixed3 finite probe calls; immutable inputs and explicit root authorization required."""
from pathlib import Path
import os,json,hashlib,sys,subprocess
W=Path(__file__).parent;D=W.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def freeze(out):
 save(out/'pins.json',{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)}for p in out.iterdir()if p.is_file()and p.name not in ['pins.json','terminal.json']})
 save(out/'terminal.json',{'allWritesComplete':True,'reportSHA256':sha(out/'report.json'),'pinsSHA256':sha(out/'pins.json')})
def main():
 if len(sys.argv)!=2:raise SystemExit('root3callauthorization required')
 a=json.loads(Path(sys.argv[1]).read_text());p=json.loads((W/'preregistration.json').read_text());b=json.loads((W/'compiled-input-binding.json').read_text())
 assert a['allowCompilerMProbe'] is True and a['allowTiming'] is False and a['guestCallCap']==3 and a['hostBuildCap']==0
 assert a['runtimePreregistrationSHA256']==sha(W/'preregistration.json') and a['runtimeRunnerSHA256']==sha(Path(__file__)) and a['compiledInputBindingSHA256']==sha(W/'compiled-input-binding.json') and b['allWritesComplete'] is True
 for s,r in dict(p['inputs'],**b['inputs']).items():f=Path(s);assert f.stat().st_size==r['bytes'] and sha(f)==r['sha256']
 out=W/'actual';assert not out.exists();out.mkdir();save(out/'authorization.json',a);rows=[]
 env=dict(os.environ,KEXE_RESULT_TYPE='i64',KEXE_FUEL='9007199254740991',KEXE_CPU_SECONDS='3600',KEXE_WALL_SECONDS='3600',KEXE_VECTOR_ITEMS='134217728',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216')
 for k in ['KEXE_COMMAND','KEXE_ARG_TYPES','KEXE_REPORT','KEXE_STRUCTURED_REPORT','KEXE_HASHCONS']:env.pop(k,None)
 for spec in p['schedule']:
  image=D/'compiled'/spec['profile']/'native.bin';cmd=[str(D.parent.parent/'inverse-implementation-v2/kexe-loader'),str(image),(image.parent/'native.offset').read_text().strip(),'1','aarch64','-',str(spec['case'])]
  row=dict(spec,argv=cmd,state='started');rows.append(row);save(out/'attempts.json',rows)
  try:q=subprocess.run(cmd,env=env,capture_output=True,timeout=3660);raw,err,rc=q.stdout,q.stderr,q.returncode
  except subprocess.TimeoutExpired as e:raw,err,rc=e.stdout or b'',e.stderr or b'',None
  tag=str(len(rows))+'-'+spec['profile']+'-'+str(spec['case']);(out/(tag+'.stdout')).write_bytes(raw);(out/(tag+'.stderr')).write_bytes(err);value=None
  try:value=int(raw.decode().strip())
  except(ValueError,UnicodeError):pass
  row.update(state='terminal',returncode=rc,value=value,PASS=rc==0 and value==0);save(out/'attempts.json',rows)
  print('PROBE',spec['profile'],spec['case'],'PASS' if row['PASS'] else 'FAIL',flush=True)
  if not row['PASS']:
   save(out/'report.json',{'status':'FAIL retained firstoutcome noretry','nativeCalls':len(rows),'rows':rows,'scope':p['scope']});freeze(out);raise SystemExit(1)
 save(out/'report.json',{'status':'PASS finite3callsonly','nativeCalls':3,'rows':rows,'scope':p['scope'],'single32V4Campaign':False,'posttakeEncoderRefusalQualified':False});freeze(out)
if __name__=='__main__':main()
