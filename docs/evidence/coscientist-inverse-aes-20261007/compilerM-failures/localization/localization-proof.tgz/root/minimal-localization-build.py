from pathlib import Path
import hashlib,json,subprocess,os,re,sys
W=Path('/private/tmp/amu-aes-resident-fuel-20261007/team-inverse-compilerM-plan/stage-localization-minimal-v1')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
a=json.loads(Path(sys.argv[1]).read_text());assert a['compilerProcessCap']==2 and a['diagnosticGuestsAllowed'] is False
assert a['runnerSHA256']==sha(Path(__file__)) and a['preregistrationSHA256']==sha(W/'preregistration.json')
for f,r in json.loads((W/'final-artifact-pins.json').read_text()).items():assert sha(W/f)==r['sha256']
for f,r in json.loads((W/'preregistration.json').read_text())['inputs'].items():assert sha(Path(f))==r['sha256']
out=W/'compiled';assert not out.exists();out.mkdir();save(out/'authorization.json',a)
r=json.loads((W/'recipe-v2.json').read_text());env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for k in ['KEXE_STRUCTURED_REPORT','KEXE_RESULT_TYPE','KEXE_ARG_TYPES']:env.pop(k,None)
rows=[]
for label,args in [('compile',['compile',str(W/r['source']),'--target','aarch64-macos','--output',str(out/'image.kseed')]),('extract',['extract-native',str(out/'image.kseed'),'--symbol','locate','--output',str(out/'native.bin')])]:
 cmd=[r['loader'],r['seed'],'0','0','aarch64','35,37,38,39','--',*args];row={'label':label,'argv':cmd,'state':'started'};rows.append(row);save(out/'attempts.json',rows)
 q=subprocess.run(cmd,env=env,capture_output=True,timeout=1800);(out/(label+'.stdout')).write_bytes(q.stdout);(out/(label+'.stderr')).write_bytes(q.stderr);row.update(state='terminal',returncode=q.returncode);save(out/'attempts.json',rows);assert q.returncode==0
 if label=='extract':(out/'native.offset').write_text(re.search(rb':offset (\d+)',q.stdout)[1].decode()+'\n')
save(out/'report.json',{'compilerProcesses':2,'diagnosticGuests':0,'status':'PASS compiler-only'})
save(out/'pins.json',{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()})
print('Minimal diagnostic compiled; guests0')
