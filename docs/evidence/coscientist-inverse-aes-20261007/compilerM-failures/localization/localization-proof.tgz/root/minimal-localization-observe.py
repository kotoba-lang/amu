from pathlib import Path
import json,hashlib,os,subprocess,sys,re
W=Path('/private/tmp/amu-aes-resident-fuel-20261007/team-inverse-compilerM-plan/stage-localization-minimal-v1')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
a=json.loads(Path(sys.argv[1]).read_text());assert a['guestCallCap']==1 and a['qualificationPASS'] is False and a['runnerSHA256']==sha(Path(__file__))
for f,r in a['inputs'].items():assert sha(Path(f))==r['sha256']
r=json.loads((W/'recipe-v2.json').read_text());env=dict(os.environ)
for k in ['KEXE_COMMAND','KEXE_ARG_TYPES','KEXE_HASHCONS','KEXE_REPORT','KEXE_STRUCTURED_REPORT','KEXE_RESULT_TYPE']:env.pop(k,None)
for k,v in r['guestEnvironment'].items():
 if v!='UNSET':env[k]=v
out=W/'observation';assert not out.exists();out.mkdir();save(out/'authorization.json',a)
cmd=[r['loader'],str(W/'compiled/native.bin'),(W/'compiled/native.offset').read_text().strip(),'1','aarch64','-','5'];save(out/'started.json',{'argv':cmd,'nativeCalls':1,'qualificationPASS':False})
q=subprocess.run(cmd,env=env,capture_output=True,timeout=3660);(out/'stdout').write_bytes(q.stdout);(out/'stderr').write_bytes(q.stderr);save(out/'status.json',{'returncode':q.returncode})
b=q.stdout.decode();m=re.search(r':result-items\s*\[([^]]*)\]',b);items=[] if not m else [int(x) for x in m[1].split()];observed=q.returncode==0 and ':status :ok' in b and ':result-type :vector-i64' in b and len(items)==7
save(out/'report.json',{'status':'OBSERVED' if observed else 'REPORTER FAIL','items':items,'nativeCalls':1,'qualificationPASS':False,'causalBranchRecorded':False});save(out/'pins.json',{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in out.iterdir() if p.is_file()});print(b);assert observed
