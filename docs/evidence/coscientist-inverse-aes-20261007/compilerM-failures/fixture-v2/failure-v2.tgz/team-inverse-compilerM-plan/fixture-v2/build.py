"""Prepared native compiler-only stage. Requires a root-issued bounded authorization."""
from pathlib import Path
import sys,json,hashlib,subprocess,os,re
D=Path(__file__).parent;H=D.parent.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def main():
 if len(sys.argv)!=2:raise SystemExit('Provide ROOT compiler-only authorization JSON; no implicit native action')
 auth=json.loads(Path(sys.argv[1]).read_text());assert auth['allowCompilerBuild'] is True and auth['allowDiagnosticGuest'] is False
 assert auth['compilerProcessCap']==4 and auth['preregistrationSHA256']==sha(D/'preregistration.json')
 prov=json.loads((D/'fixture-provenance.json').read_text());assert auth['fixturePins']==prov['artifacts']
 pr=json.loads((D/'preregistration.json').read_text())
 for p,r in pr['inputs'].items():assert sha(Path(p))==r['sha256']
 for p,h in prov['artifacts'].items():assert sha(D/p)==h
 W=D/'compiled';assert not W.exists();W.mkdir();save(W/'root-authorization.json',auth)
 seeds={'RF-core-probe':H/'implementation/seed-4.bin','inverse-v2-core-probe':H/'root-inverse-selfbuild-v2/seed-4.bin'};loader=H/'inverse-implementation-v2/kexe-loader';assert os.access(loader,os.X_OK)
 env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
 attempts=[]
 def run(out,label,args):
  seed=seeds[out.name]
  assert len(attempts)<4;cmd=[str(loader),str(seed),'0','0','aarch64','35,37,38,39','--',*args];a={'index':len(attempts)+1,'profile':out.name,'label':label,'argv':cmd,'state':'started'};attempts.append(a);save(W/'attempts.json',attempts)
  try:q=subprocess.run(cmd,env=env,capture_output=True,timeout=1800);stdout,stderr,rc=q.stdout,q.stderr,q.returncode
  except subprocess.TimeoutExpired as e:stdout,stderr,rc=e.stdout or b'',e.stderr or b'',None
  (out/(label+'.stdout')).write_bytes(stdout);(out/(label+'.stderr')).write_bytes(stderr);a.update(state='terminal',returncode=rc);save(out/(label+'.status.json'),a);save(W/'attempts.json',attempts)
  assert rc==0,(out.name,label,rc);return stdout.decode()
 for name in ['RF-core-probe.kotoba','inverse-v2-core-probe.kotoba']:
  out=W/name.split('.')[0];out.mkdir();run(out,'compile',['compile',str(D/name),'--target','aarch64-macos','--output',str(out/'image.kseed')]);log=run(out,'extract',['extract-native',str(out/'image.kseed'),'--symbol','probe','--output',str(out/'native.bin')]);off=int(re.search(r':offset (\d+)',log)[1]);(out/'native.offset').write_text(str(off)+'\n');print('COMPILER ONLY',out.name,flush=True)
 save(W/'report.json',{'status':'PASS compilation/extraction only; diagnostic probe guests not executed','compilerProcesses':len(attempts),'diagnosticGuestExecutions':0})
 save(W/'pins.json',{str(p.relative_to(W)):{'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(W.rglob('*'))if p.is_file()and p.name not in['pins.json','terminal.json']})
 save(W/'terminal.json',{'reportSHA256':sha(W/'report.json'),'pinsSHA256':sha(W/'pins.json'),'allWritesComplete':True,'diagnosticGuestExecutions':0})
if __name__=='__main__':main()
