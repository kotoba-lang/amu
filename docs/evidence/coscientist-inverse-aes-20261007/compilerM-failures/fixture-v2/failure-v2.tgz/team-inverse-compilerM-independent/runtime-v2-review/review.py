from pathlib import Path
import json,hashlib,re
D=Path(__file__).parent;W=D.parent.parent;P=W/'team-inverse-compilerM-plan';V=P/'fixture-v2';R=V/'runtime-procedure-v2';C=V/'compiled';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,r in json.loads((D/'preregistration.json').read_text())['inputs'].items():assert sha(Path(n))==r['sha256']
for n,r in json.loads((R/'artifact-pins.json').read_text()).items():assert sha(R/n)==r['sha256'] and (R/n).stat().st_size==r['bytes']
cp=json.loads((C/'pins.json').read_text())
for n,r in cp.items():assert sha(C/n)==r['sha256'] and (C/n).stat().st_size==r['bytes']
pr=json.loads((R/'preregistration.json').read_text());binding=json.loads((R/'compiled-input-binding.json').read_text());assert binding['allWritesComplete']
inputs={**pr['inputs'],**binding['inputs']}
for n,r in inputs.items():assert sha(Path(n))==r['sha256'] and Path(n).stat().st_size==r['bytes']
old=json.loads((P/'runtime-procedure/preregistration.json').read_text())
fields=['profiles','preflight','remaining','expectedReturn','guestCallCap','hostBuildCap','fuel','cpuSeconds','wallSeconds','hostTimeoutSeconds','vectorItems','maximumFullMVectors','fullMCells','cases','retries']
for f in fields:assert pr[f]==old[f],f
assert pr['preflight']==[0] and len(pr['profiles'])==2 and pr['remaining']==list(range(1,16))
s=(R/'run.py').read_text()
for x in ["'KEXE_COMMAND','KEXE_ARG_TYPES','KEXE_REPORT','KEXE_STRUCTURED_REPORT','KEXE_HASHCONS'","env.pop(k,None)","passed=rc==0 and value==0","if not passed:","raise SystemExit(1)","pf['status']=='PASS' and pf['guestCalls']==2","assert not out.exists()","auth['hostBuildCap']==0","auth['guestCallCap']==32"]:assert x in s,x
assert s.count('subprocess.run(')==1 and 'for case in pr[phase]' in s and 'for profile in pr[\'profiles\']' in s
for name in pr['profiles']:
 out=C/name;statuses=[json.loads((out/(t+'.status.json')).read_text()) for t in ['compile','extract']];assert all(x['returncode']==0 for x in statuses)
 log=(out/'extract.stdout').read_text();offset=int((out/'native.offset').read_text());assert offset==int(re.search(r':offset (\d+)',log)[1]) and 0<=offset<(out/'native.bin').stat().st_size
rep={'status':'PASS bounded static gate for FIRST2 preflight; no semantic qualification','compiledPinsRehashed':len(cp),'combinedRuntimeInputsRehashed':len(inputs),'scheduleAndBudgetsUnchangedFields':fields,'commandSelector':'KEXE_COMMAND explicitly absent; raw integer0 AND OSexit0 required','phaseSeparation':'2preflight first;30 remaining needs separateauthorization binding successful2-call report','firstFailure':'Retains raw and stops immediately; no retry','sourceOracles':'Same16 fixture assertions already independently bytechecked; no relaxed success criterion','limits':['Original failed phase and observation12101 preserved','Cases3/5 admission-only;14 diagnostic invalid state;15 active canonical ranges not fullM','Actual diagnostic native execution pending; syntax builds4 succeeded but no source semantic qualification yet'],'nativeSolverTimingNetworkByReviewer':0}
(D/'report.json').write_text(json.dumps(rep,indent=2)+'\n');(D/'pins.json').write_text(json.dumps({n:{'sha256':sha(D/n),'bytes':(D/n).stat().st_size} for n in ['preregistration.json','review.py','report.json']},indent=2)+'\n');(D/'terminal.json').write_text(json.dumps({'allWritesComplete':True,'reportSHA256':sha(D/'report.json'),'pinsSHA256':sha(D/'pins.json')},indent=2)+'\n');print(json.dumps(rep,indent=2));print('REPORT',sha(D/'report.json'));print('PINS',sha(D/'pins.json'))
