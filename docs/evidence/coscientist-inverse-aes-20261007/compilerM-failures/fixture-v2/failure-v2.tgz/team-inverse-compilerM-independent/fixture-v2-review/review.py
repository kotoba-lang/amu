from pathlib import Path
import json,re,hashlib
W=Path('/private/tmp/amu-aes-resident-fuel-20261007');P=W/'team-inverse-compilerM-plan';V=P/'fixture-v2';D=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def form(s,name):
 m=re.search(r'\(defn-? '+re.escape(name)+r'\s',s);assert m,name
 a=m.start(); dep=0;st=esc=com=False
 for i in range(a,len(s)):
  c=s[i]
  if com:
   if c=='\n':com=False
   continue
  if st:
   if esc:esc=False
   elif c=='\\':esc=True
   elif c=='"':st=False
   continue
  if c==';':com=True;continue
  if c=='"':st=True;continue
  if c=='(':dep+=1
  elif c==')':
   dep-=1
   if dep==0:return s[a:i+1]
 raise AssertionError(name)
def norm(s):return re.sub(r'\s+',' ',s).strip()
reg=json.loads((D/'preregistration.json').read_text())
for r in reg['inputs']:assert sha(Path(r['path']))==r['sha256']
pins=json.loads((V/'artifact-pins.json').read_text())
for n,r in pins.items():assert sha(V/n)==r['sha256'] and (V/n).stat().st_size==r['bytes']
pr=json.loads((V/'preregistration.json').read_text())
for n,r in pr['inputs'].items():assert sha(Path(n))==r['sha256']
checks=[]
expected_check='''(defn- cm-check [M :vector-i64 S :string H :vector-i64] :vector-i64
 (if (= (vector-at M MM-ERR) 0)
  (let [M1 (ck-run-h M S H)]
   (if (ck-hint-again? H M1)
    (cm-check (drv-reread M1 S) S H)
    (if (= (vector-at M1 MM-ERR) 0) (lw-run M1) M1)))
  M))'''
expected_lower='''(defn- cm-lowered [] :vector-i64
 (let [s cm-source m0 (vector-assoc! (mem-new) MM-SRC-LEN (string-length s))
       m1 (lx-run m0 s)]
  (if (= (vector-at m1 MM-ERR) 0)
   (let [m2 (rd-run m1 s)]
    (if (= (vector-at m2 MM-ERR) 0)
     (cm-check (nm-run m2 s) s (ck-hint-new)) m2)) m1)))'''
for n in ['RF-core-probe.kotoba','inverse-v2-core-probe.kotoba']:
 old=(P/n).read_text();new=(V/n).read_text();f0=form(old,'cm-lowered');f1=form(new,'cm-lowered');ck=form(new,'cm-check')
 assert norm(ck)==norm(expected_check) and norm(f1)==norm(expected_lower)
 # The authoring replacement is precisely helper+lowered separated by a newline.
 rebuilt=old.replace(f0,';; Fixture-v2: exact drv-c3h checking/refinement/reread control, retaining M instead of io reporting.\n'+ck+'\n'+f1,1);assert rebuilt==new,'outside-replacement delta'
 assert form(old,'probe')==form(new,'probe')
 embedded=re.search(r'^\(def cm-source (".*")\)$',new,re.M);raw=json.loads(embedded[1]).encode()
 assert hashlib.sha256(raw).hexdigest()=='5c224278b7abb7db9e70a118204f4772bb108483e1369828aabb12cc6f2408c4' and len(raw)==39294
 for fn in ['drv-c3h','drv-reread','ck-run-h','ck-hint-again?','cm-rf-call','cm-rf-ins','cm-rf-ins-quiet']:
  assert form(old,fn)==form(new,fn)
 checks.append({'profile':n,'outsideReplacementExact':True,'probeAndAll16OraclesExact':True,'embeddedAESBytes':len(raw),'persistentHintAndRereadSequence':True,'errorsPreservedBeforeLowering':True})
build=(V/'build.py').read_text();assert "auth['allowDiagnosticGuest'] is False" in build and "auth['compilerProcessCap']==4" in build and 'assert len(attempts)<4' in build
# Raw diagnostic is distinct from qualification.
o=P/'failure-observation-v1/actual';assert (o/'stdout').read_bytes()==b'12101\n' and (o/'stderr').read_bytes()==b''
r=json.loads((o/'report.json').read_text());assert r['value']==12101 and r['exit']==0 and r['nativeCalls']==1 and r['qualificationPASS'] is False
out={'status':'PASS bounded source/provenance gate for FOUR compiler-only processes; no diagnostic guest authorization','inputPinsVerified':len(pins),'externalPinsVerified':len(pr['inputs']),'checks':checks,'buildProcessCap':4,'diagnosticGuests':0,'solverNativeNetworkTimingByReviewer':0,'observation':{'actualRawValue':12101,'originalExit':69,'originalPhase':'FAIL retained','MMERR2101Interpretation':'Strongly supported by 10000+2101 return branch and omitted refinement API; raw integer alone does not print the selected branch or MMERR. cm-diff can numerically return same integer.','candidateAttribution':'No inverse guest executed; no inverse optimizer fault established'},'limits':['Lexical/source pipeline gate only; actual syntax/type/build success pending','Original sixteen scopes unchanged: cases3/5 admission-only, case14 diagnostic invalid state, case15 active canonical reuse not all-M equality','Future runtime needs compiled pins and reporter selection corrected; this review does not authorize guests']}
(D/'report.json').write_text(json.dumps(out,indent=2)+'\n')
selected=['preregistration.json','review.py','report.json','initial-review.py','initial-review-failure.json'];(D/'pins.json').write_text(json.dumps({n:{'sha256':sha(D/n),'bytes':(D/n).stat().st_size} for n in selected},indent=2)+'\n')
(D/'terminal.json').write_text(json.dumps({'allWritesComplete':True,'reportSHA256':sha(D/'report.json'),'pinsSHA256':sha(D/'pins.json')},indent=2)+'\n')
print(json.dumps(out,indent=2));print('REPORT SHA',sha(D/'report.json'));print('PINS SHA',sha(D/'pins.json'))
