"""Prospective fixed32 compiler-M probe calls; no host compilation or implicit execution."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
W=Path(__file__).parent; D=W.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def main():
 if len(sys.argv)!=3 or sys.argv[1] not in ['preflight','remaining']:raise SystemExit('run.py preflight|remaining ROOT_AUTHORIZATION.json')
 phase=sys.argv[1];auth=json.loads(Path(sys.argv[2]).read_text());pr=json.loads((W/'preregistration.json').read_text())
 assert auth['allowCompilerMProbe'] is True and auth['allowTiming'] is False
 assert auth['runtimePreregistrationSHA256']==sha(W/'preregistration.json')
 assert auth['runtimeRunnerSHA256']==sha(Path(__file__)) and auth['guestCallCap']==32 and auth['hostBuildCap']==0 and auth['phase']==phase
 for s,r in pr['inputs'].items():
  p=Path(s);assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],s
 if phase=='remaining':
  pf=json.loads((W/'preflight/report.json').read_text());assert pf['status']=='PASS' and pf['guestCalls']==2
  assert auth['preflightReportSHA256']==sha(W/'preflight/report.json')
 out=W/phase;assert not out.exists();out.mkdir();save(out/'authorization.json',auth)
 loader=D.parent/'inverse-implementation-v2/kexe-loader';assert os.access(loader,os.X_OK)
 env=dict(os.environ,KEXE_COMMAND='0',KEXE_RESULT_TYPE='i64',KEXE_FUEL=str(pr['fuel']),KEXE_CPU_SECONDS=str(pr['cpuSeconds']),KEXE_WALL_SECONDS=str(pr['wallSeconds']),KEXE_VECTOR_ITEMS=str(pr['vectorItems']),KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216')
 # Exclude inherited report/signature selectors; native arguments must be direct i64.
 for k in ['KEXE_ARG_TYPES','KEXE_REPORT','KEXE_STRUCTURED_REPORT','KEXE_HASHCONS']:env.pop(k,None)
 save(out/'effective-owned-environment.json',{k:v for k,v in env.items() if k.startswith('KEXE_')})
 rows=[]
 for case in pr[phase]:
  for profile in pr['profiles']:
   image=D/'compiled'/profile/'native.bin';offset=(image.parent/'native.offset').read_text().strip()
   cmd=[str(loader),str(image),offset,'1','aarch64','-',str(case)]
   r={'case':case,'profile':profile,'expectedReturn':0,'argv':cmd,'state':'started'};rows.append(r);save(out/'attempts.json',rows)
   try:q=subprocess.run(cmd,env=env,capture_output=True,timeout=pr['hostTimeoutSeconds']);stdout,stderr,rc=q.stdout,q.stderr,q.returncode
   except subprocess.TimeoutExpired as e:stdout,stderr,rc=e.stdout or b'',e.stderr or b'',None
   tag=f'{case:02d}-{profile}';(out/(tag+'.stdout')).write_bytes(stdout);(out/(tag+'.stderr')).write_bytes(stderr)
   value=None
   try:value=int(stdout.decode().strip())
   except (ValueError,UnicodeError):pass
   passed=rc==0 and value==0
   r.update(state='terminal',returncode=rc,actualReturn=value,PASS=passed);save(out/(tag+'.status.json'),r);save(out/'attempts.json',rows)
   print('PROBE',case,profile,'PASS' if passed else 'FAIL',flush=True)
   if not passed:
    save(out/'report.json',{'status':'FAIL retained first outcome; no retry','guestCalls':len(rows),'hostBuilds':0,'failedCase':case,'failedProfile':profile,'value':value,'returncode':rc});freeze(out);raise SystemExit(1)
 save(out/'report.json',{'status':'PASS','guestCalls':len(rows),'hostBuilds':0,'cases':pr[phase],'scope':'Finite source assertions only; case3/5 admission-only, case14 invalid diagnostic state, case15 canonical active ranges only. No broad old fallback repair, no external writer or async publication sampling claim.'});freeze(out)
def freeze(out):
 save(out/'pins.json',{str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.rglob('*')) if p.is_file() and p.name not in ['pins.json','terminal.json']})
 save(out/'terminal.json',{'allWritesComplete':True,'reportSHA256':sha(out/'report.json'),'pinsSHA256':sha(out/'pins.json'),'newTimingSolverHostBuilds':0})
if __name__=='__main__':main()
