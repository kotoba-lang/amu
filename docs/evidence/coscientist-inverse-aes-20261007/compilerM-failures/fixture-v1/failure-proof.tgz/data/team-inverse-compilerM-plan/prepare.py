from pathlib import Path
import json,hashlib,struct
D=Path(__file__).parent;H=D.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pr=json.loads((D/'preregistration.json').read_text())
for p,h in pr['inputs'].items():assert sha(Path(p))==h['sha256']
rf=(H/'implementation/unity.kotoba').read_text();iv=(H/'inverse-implementation-v2/unity-inverse-on.kotoba').read_text();src=(H/'team-inverse-native-images/continuation/sources/nettle-aes.kotoba').read_text();dispatch=rf[rf.index('(defn- gn-op-call '):rf.index('(defn- gn-call-generic ')].replace('(defn- gn-op-call ','(defn- cm-rf-call ')
insref=rf[rf.index('(defn- gn-ins '):rf.index(';; every instruction from i',rf.index('(defn- gn-ins '))].replace('(defn- gn-ins ','(defn- cm-rf-ins ').replace('(gn-ins-quiet ','(cm-rf-ins-quiet ').replace('(defn- gn-ins-quiet ','(defn- cm-rf-ins-quiet ').replace('(gn-op-call ','(cm-rf-call ')
raw=(H/'team-inverse-native-images/continuation/on/nettle-aes/native.bin').read_bytes();rr=json.loads((H/'team-inverse-machine-independent/machine-report.json').read_text());site=next(x['sites'][0]for x in rr['rows']if x['workload']=='nettle-aes');new=list(struct.unpack('<73I',raw[4*(site['newLo']-1):4*(site['newHi']-1)]));oldraw=(H/'implementation/ports/nettle-aes/native.bin').read_bytes();old=list(struct.unpack('<65I',oldraw[4*(site['oldLo']-1):4*(site['oldHi']-1)]));old[63]=0x94000000
common='''
(def cm-source @SOURCE@)
(def cm-new-words [@NEW@])
(def cm-rf-words [@OLD@])
(defn- cm-copy [M :vector-i64] :vector-i64
 (let [V (vector-alloc MM-WORDS)]
  (loop [i 0] (if (= i MM-WORDS) V (do (vector-assoc! V i (vector-at M i)) (recur (inc i)))))))
(defn- cm-diff [A :vector-i64 B :vector-i64] :i64
 (loop [i 0 n 0] (if (= i MM-WORDS) n (recur (inc i) (+ n (if (= (vector-at A i) (vector-at B i)) 0 1))))))
(defn- cm-range-diff [A :vector-i64 B :vector-i64 base :i64 count :i64] :i64
 (loop [i 0 n 0] (if (= i count) n (recur (inc i) (+ n (if (= (vector-at A (+ base i)) (vector-at B (+ base i))) 0 1))))))
(defn- cm-lowered [] :vector-i64
 (let [s cm-source m0 (vector-assoc! (mem-new) MM-SRC-LEN (string-length s))]
  (lw-run (ck-run (nm-run (rd-run (lx-run m0 s) s) s) s))))
(defn- cm-before [M :vector-i64] :vector-i64
 (let [m0 (mem-alloc M (+ gn-a-lp MM-LABEL-CAP 82))]
  (if (not= (vector-at m0 MM-ERR) 0) m0
   (let [m1 (-> m0 (gn-put gn-cell (vector-at m0 MM-R0)) (gn-gs gn-g-open 0) (gn-gs gn-g-open-n 0)
                  (gn-gs di-used 0) (gn-gs di-sites 0) (gn-gs as-used 0) (gn-gs as-sites 0))]
    (loop [m m1 i 1]
     (cond (not= (vector-at m MM-ERR) 0) m (= i 924) m (>= i (vector-at m MM-SIR-N)) (gn-err m 9924 i)
      :else (let [next (gn-ins m i (gn-op m i)) skip (gn-g next gn-f-skip)]
              (recur (gn-gs next gn-f-skip 0) (+ i 1 skip)))))))))
(defn- cm-rf-loop [M :vector-i64 i :i64] :vector-i64
 (if (and (< i (vector-at M MM-SIR-N)) (= (vector-at M MM-ERR) 0))
  (let [op (gn-op M i) m1 (cm-rf-ins M i op)
        k (gn-g m1 gn-f-skip)] (cm-rf-loop (gn-gs m1 gn-f-skip 0) (+ i 1 k))) M))
(defn- cm-rf-run-open [M :vector-i64 first :i64 count :i64] :vector-i64
 (let [top (vector-at M MM-HEAP-TOP) m0 (if (< top MM-HEAP-BASE) (gn-put M MM-HEAP-TOP MM-HEAP-BASE) M)
       m1 (mem-alloc m0 (+ gn-a-lp MM-LABEL-CAP 82))]
  (if (not= (vector-at m1 MM-ERR) 0) m1
   (let [m2 (-> (gn-put m1 gn-cell (vector-at m1 MM-R0)) (gn-gs gn-g-open first) (gn-gs gn-g-open-n count)
                   (gn-gs di-used 0) (gn-gs di-sites 0) (gn-gs as-used 0) (gn-gs as-sites 0))
         m3 (cm-rf-loop m2 1)] (gn-put m3 MM-R0 (- (vector-at m3 MM-CODE-N) 1))))))
(defn- cm-call [M :vector-i64] :vector-i64 (gn-op-call M 924 61 0 6))
(defn- cm-word-match [M :vector-i64 n :i64 V :vector-i64] :bool
 (loop [i 0] (if (= i (vector-count V)) true
  (and (= (vector-at M (+ MM-CODE-BASE n i)) (vector-at V i)) (recur (inc i))))))
(defn- cm-outside-diff [A :vector-i64 B :vector-i64 n :i64 fix :i64 g :i64] :i64
 (loop [i 0 bad 0]
  (if (= i MM-WORDS) bad
   (let [allowed (or (= i MM-CODE-N) (= i MM-FIX-N) (= i (+ g as-used))
                    (and (>= i (+ MM-CODE-BASE n)) (< i (+ MM-CODE-BASE n 73)))
                    (and (>= i (+ MM-FIX-BASE (* fix MM-FIX-W))) (< i (+ MM-FIX-BASE (* (inc fix) MM-FIX-W))))) ]
    (recur (inc i) (+ bad (if (or allowed (= (vector-at A i) (vector-at B i))) 0 1)))))))
(defn- cm-normal [P :vector-i64 n :i64] :i64
 (let [a0 (gn-put (cm-copy P) MM-CODE-N n) b0 (gn-put (cm-copy P) MM-CODE-N n)
       fix (vector-at P MM-FIX-N) g (vector-at P gn-cell) a (cm-call a0) b (cm-rf-call b0 924 61 0 6)]
  (if @ON@
   (if (and (= (vector-at a MM-ERR) 0) (= (vector-at b MM-ERR) 0)
            (= (vector-at a MM-CODE-N) (+ n 73)) (= (vector-at b MM-CODE-N) (+ n 65))
            (= (vector-at a MM-FIX-N) fix) (= (vector-at b MM-FIX-N) (inc fix))
            (= (gn-g a as-used) 73) (= (gn-g b as-used) 65) (= (gn-g a as-sites) 1) (= (gn-g b as-sites) 1)
            (cm-word-match a n cm-new-words) (cm-word-match b n cm-rf-words)
            (= (vector-at b (+ MM-FIX-BASE (* fix MM-FIX-W))) (+ n 63))
            (= (vector-at b (+ MM-FIX-BASE (* fix MM-FIX-W) 1)) FX-BL26)
            (= (vector-at b (+ MM-FIX-BASE (* fix MM-FIX-W) 2)) 61)
            (= (vector-at b (+ MM-FIX-BASE (* fix MM-FIX-W) 3)) 0)
            (= (cm-range-diff a P (+ MM-FIX-BASE (* fix MM-FIX-W)) MM-FIX-W) 0)
            (= (cm-outside-diff a b n fix g) 0)) 0 9001)
   (cm-diff a b))))
(defn- cm-refusal [P :vector-i64 n :i64] :i64
 (let [a0 (gn-put (cm-copy P) MM-CODE-N n) b0 (gn-put (cm-copy P) MM-CODE-N n)
       no (not (cm-admit a0)) a (cm-call a0) b (cm-rf-call b0 924 61 0 6)]
  (if no (cm-diff a b) 9002)))
(defn- cm-invalid [P :vector-i64 n :i64] :i64
 (let [a (gn-put (cm-copy P) MM-CODE-N n) b (cm-copy a) no (not (cm-admit a))]
  (if no (cm-diff a b) 9003)))
(defn- cm-open [M :vector-i64 f :i64] :i64
 (let [a (gn-run-open (cm-copy M) f 1) b (cm-rf-run-open (cm-copy M) f 1)]
  (if (and (= (vector-at a MM-ERR) 0) (= (gn-g a as-sites) 0)) (cm-diff a b) 9004)))
(defn- cm-exhaust [M :vector-i64 err :i64] :i64
 (let [a0 (-> (cm-copy M) (gn-put MM-HEAP-TOP (- MM-HEAP-END 1)) (gn-put MM-ERR err)) b0 (cm-copy a0)
       a (gn-run-open a0 61 1) b (mem-alloc b0 (+ gn-a-lp MM-LABEL-CAP 82))]
  (cm-diff a b)))
(defn- cm-t2 [P :vector-i64] :i64
 (let [a (cm-copy P) b (cm-copy a)] (if (not (cm-admit-t a 2)) (cm-diff a b) 9005)))
(defn- cm-sites [P :vector-i64] :i64
 (let [a (gn-gs (cm-copy P) as-sites 64) b (cm-copy a)] (if (not (cm-admit a)) (cm-diff a b) 9006)))
(defn- cm-reset [M :vector-i64] :vector-i64 (-> M (gn-put MM-CODE-N 1) (gn-put MM-FIX-N 1) (gn-put MM-ERR 0)))
(defn- cm-reuse [M :vector-i64] :i64
 (let [a (gn-run (cm-copy M)) ref (cm-copy a) first (gn-g a as-sites)
       b (gn-run-open (cm-reset a) 61 1) opened (gn-g b as-sites) z (gn-run (cm-reset b))]
  (if (and (= (vector-at z MM-ERR) 0) (= first 4) (= opened 0) (= (gn-g z as-sites) 4)
           (= (vector-at z MM-CODE-N) (vector-at ref MM-CODE-N)) (= (vector-at z MM-FIX-N) (vector-at ref MM-FIX-N))
           (= (cm-range-diff z ref MM-CODE-BASE (vector-at z MM-CODE-N)) 0)
           (= (cm-range-diff z ref MM-FIX-BASE (* (vector-at z MM-FIX-N) MM-FIX-W)) 0)
           (= (cm-range-diff z ref MM-FN-BASE (* (vector-at z MM-FN-N) MM-FN-W)) 0)
           (= (cm-range-diff z ref MM-SIR-BASE (* (vector-at z MM-SIR-N) MM-SIR-W)) 0)
           (= (cm-range-diff z ref MM-LIT-BASE (* (vector-at z MM-LIT-N) MM-LIT-W)) 0)
           (= (cm-range-diff z ref MM-LITB-BASE (vector-at z MM-LITB-N)) 0)) 0 9007)))
(defn probe [scenario :i64] :i64
 (let [m (cm-lowered)]
  (if (not= (vector-at m MM-ERR) 0) (+ 10000 (vector-at m MM-ERR))
   (cond
    (= scenario 6) (let [p (gn-fnf m 61 FF-SIR)] (cm-open m 61))
    (= scenario 7) (let [p (gn-fnf m 61 FF-SIR)] (cm-open m (gn-sir m (+ p 10) IF-A)))
    (= scenario 8) (let [p (gn-fnf m 61 FF-SIR)] (cm-open m (gn-sir m (+ p 11) IF-A)))
    (= scenario 9) (let [p (gn-fnf m 61 FF-SIR)] (cm-open m (gn-sir m (+ p 64) IF-A)))
    (= scenario 10) (cm-exhaust m 0) (= scenario 11) (cm-exhaust m 777) (= scenario 15) (cm-reuse m)
    :else (let [p (cm-before m)]
     (if (or (not= (vector-at p MM-ERR) 0) (not= (gn-op p 924) OP-CALL) (not= (gn-sir p 924 IF-A) 61)
             (not= (gn-g p gn-f-fb) 288) (not= (gn-g p gn-f-h) 6) (not= (gn-g p gn-f-ctx) 1)) 9900
      (case scenario
       0 (cm-normal p (- MM-CODE-CAP 97)) 1 (cm-normal p (- MM-CODE-CAP 96))
       2 (cm-refusal p (- MM-CODE-CAP 95)) 3 (cm-invalid p -1)
       4 (cm-refusal p MM-CODE-CAP) 5 (cm-invalid p (inc MM-CODE-CAP))
       12 (cm-t2 p) 13 (cm-sites p) 14 (cm-errors p) 9999)))))))
'''
common=common.replace('@SOURCE@',json.dumps(src,ensure_ascii=False)).replace('@NEW@',' '.join(map(str,new))).replace('@OLD@',' '.join(map(str,old)))
# Independent expected body stage: exact fixed source emission up through m3,
# without applying either ai branch patch or the result cleanup/counters.
ai=iv[iv.index('(defn- ai-call '):iv.index('(defn- gn-op-call ',iv.index('(defn- ai-call '))]
body=ai[:ai.index('  (if (not= (vector-at m3')].replace('(defn- ai-call ','(defn- cm-body ')+ '\n m3))\n'
errors='''
(defn- cm-errors [P :vector-i64] :i64
 (let [initial (gn-emit (cm-copy P) -1) a (ai-call (cm-copy initial) 924 61 0) b (cm-body (cm-copy initial) 924 61 0)
       q (-> (cm-copy P) (gn-put (+ MM-SIR-BASE (* 925 MM-SIR-W)) OP-LSET)
            (gn-put (+ MM-SIR-BASE (* 925 MM-SIR-W) IF-A) 1) (gn-put (+ MM-SIR-BASE (* 925 MM-SIR-W) IF-B) 0)
            (gn-put (+ MM-SIR-BASE (* 925 MM-SIR-W) IF-C) 0)
            (gn-put (+ MM-SIR-BASE (* 926 MM-SIR-W)) OP-CONST)
            (gn-put (+ MM-SIR-BASE (* 926 MM-SIR-W) IF-A) 0)
            (gn-put (+ MM-SIR-BASE (* 926 MM-SIR-W) IF-B) 0)
            (gn-put (+ MM-SIR-BASE (* 926 MM-SIR-W) IF-C) 0) (gn-gs (+ gn-a-sreg 1) 41))
       no (and (= (gn-co q 924 0) 1) (cm-admit q))
       n (vector-at q MM-CODE-N) c (ai-call (cm-copy q) 924 61 0)
       d0 (cm-body (cm-copy q) 924 61 0)
       d (-> d0 (gn-put (+ MM-CODE-BASE n 52) (enc-cbnz 0 11))
               (gn-put (+ MM-CODE-BASE n 62) (enc-b 10)) (gn-vclear) (gn-gs gn-f-ctx 0) (gn-take 924 0 0))]
  (if (and no (= (vector-at a MM-ERR) E-ENC-IMM) (= (vector-at c MM-ERR) E-ENC-IMM)
           (= (gn-g a as-used) (gn-g initial as-used)) (= (gn-g a as-sites) (gn-g initial as-sites))
           (= (gn-g c as-used) (gn-g q as-used)) (= (gn-g c as-sites) (gn-g q as-sites))
           (= (cm-diff a b) 0) (= (cm-diff c d) 0)) 0 9008)))
'''
for name,s,on in [('RF-core-probe.kotoba',rf,False),('inverse-v2-core-probe.kotoba',iv,True)]:
 assert s.count('(ns seed (:export [main]))')==1
 extra=dispatch+insref+common.replace('@ON@','true'if on else'false')
 extra+='\n(defn- cm-admit-t [M :vector-i64 t :i64] :bool '+('(ai-admit M 924 61 t 6)'if on else'false')+')\n(defn- cm-admit [M :vector-i64] :bool (cm-admit-t M 0))\n'
 extra+=body+errors if on else'\n(defn- cm-errors [P :vector-i64] :i64 (let [a0 (gn-emit (cm-copy P) -1) b0 (cm-copy a0) a (cm-call a0) b (cm-rf-call b0 924 61 0 6)] (cm-diff a b)))\n'
 # Later functions are already valid in ordinary unity (forward declarations supported).
 (D/name).write_text(s.replace('(ns seed (:export [main]))','(ns seed (:export [main probe]))')+'\n;; OWNED DIAGNOSTIC ADDITIONS; frozen implementation prefix otherwise unchanged\n'+extra)
(D/'fixture-provenance.json').write_text(json.dumps({'status':'Prepared typed source only, unchecked until native compiler build phase','RFDispatcherReferenceSHA256':hashlib.sha256(dispatch.encode()).hexdigest(),'reference':'byte-extracted RF gn-op-call renamed only; references unchanged original helpers','targetOriginalSourceSHA256':sha(H/'team-inverse-native-images/continuation/sources/nettle-aes.kotoba'),'fullMCellsCompared':8388608,'normalAllowedDifferences':'Exact73/65 codewords, verified4-cell RFBLfix vs unchangedAIrecord, CODE/FIX counts/sharedused. Allother M cells mustequal.','errorCase14':'two diagnostic subchecks: preexisting gn-emit refusal before ai patches, and invalid owned diagnostic slotreg40 causing posttake encoder refusal. Expected staged body/cleanup derives frozen source+actual73word sequence; not validordinary user program claims.','reuse':'Canonical active CODE/FIX/FN/SIR/LIT/pool exact closed/open/closed; abandonedtails and repeatedheap G allocations not claimed fullMidentical','artifacts':{n:sha(D/n)for n in['RF-core-probe.kotoba','inverse-v2-core-probe.kotoba']}},indent=2)+'\n')
print('PREPARED ONLY',sha(D/'fixture-provenance.json'))
