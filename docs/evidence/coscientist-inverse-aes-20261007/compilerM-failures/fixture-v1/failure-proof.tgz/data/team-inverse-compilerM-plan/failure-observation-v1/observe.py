"""Exactly one failed-result observation, never a qualification retry."""
from pathlib import Path
import hashlib,json,os,sys,subprocess
W=Path(__file__).parent;D=W.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def main():
 if len(sys.argv)!=2:raise SystemExit('Root one-observation authorization required')
 a=json.loads(Path(sys.argv[1]).read_text());pr=json.loads((W/'preregistration.json').read_text())
 assert a['allowFailureObservation'] is True and a['nativeCallCap']==1 and a['allowQualificationRetry'] is False
 assert a['preregistrationSHA256']==sha(W/'preregistration.json') and a['runnerSHA256']==sha(Path(__file__))
 for s,r in pr['inputs'].items():p=Path(s);assert sha(p)==r['sha256'] and p.stat().st_size==r['bytes']
 out=W/'actual';assert not out.exists();out.mkdir();save(out/'authorization.json',a)
 env=dict(os.environ,KEXE_RESULT_TYPE='i64',KEXE_FUEL='9007199254740991',KEXE_CPU_SECONDS='3600',KEXE_WALL_SECONDS='3600',KEXE_VECTOR_ITEMS='134217728',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216')
 for k in ['KEXE_COMMAND','KEXE_ARG_TYPES','KEXE_REPORT','KEXE_STRUCTURED_REPORT','KEXE_HASHCONS']:env.pop(k,None)
 img=D/'compiled/RF-core-probe/native.bin';cmd=[str(D.parent/'inverse-implementation-v2/kexe-loader'),str(img),(img.parent/'native.offset').read_text().strip(),'1','aarch64','-','0'];save(out/'started.json',{'argv':cmd,'KEXE_COMMAND':'ABSENT','callCap':1})
 try:q=subprocess.run(cmd,env=env,capture_output=True,timeout=3660);b,e,rc=q.stdout,q.stderr,q.returncode
 except subprocess.TimeoutExpired as x:b,e,rc=x.stdout or b'',x.stderr or b'',None
 (out/'stdout').write_bytes(b);(out/'stderr').write_bytes(e);value=None
 try:value=int(b.decode().strip())
 except(ValueError,UnicodeError):pass
 agreed=rc==0 and value is not None and value!=0 and value&255==69
 save(out/'report.json',{'status':'OBSERVATION AGREES' if agreed else 'OBSERVATION FAIL','value':value,'exit':rc,'originalCommandExit':69,'low8':None if value is None else value&255,'hypothesis12101Confirmed':value==12101,'qualificationPASS':False,'nativeCalls':1,'retry':False})
 save(out/'pins.json',{p.name:{'sha256':sha(p),'bytes':p.stat().st_size}for p in out.iterdir()if p.is_file()})
 save(out/'terminal.json',{'allWritesComplete':True,'pinsSHA256':sha(out/'pins.json'),'reportSHA256':sha(out/'report.json')})
 print('FAILURE OBSERVATION',value,rc,flush=True);raise SystemExit(0 if agreed else 1)
if __name__=='__main__':main()
