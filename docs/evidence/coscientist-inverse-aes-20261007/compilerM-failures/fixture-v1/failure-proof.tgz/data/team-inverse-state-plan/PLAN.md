# Inverse state safety: prospective finite plan only

No native build, guest execution, solver, network, or timing was performed by this reviewer. The initial 104-call prospective budget is preserved in preregistration.json. The owner now covers its overlapping runtime domains; this reviewer proposes **no duplicate CALL, ABI, or fault executions**. Any independent compiler-M execution needs a separate root-authorized phase and its own exact prepared source/loader/input inventory.

## Existing source and machine boundaries

V2 source reservation validates CODE-N in [0,CAP] before subtraction, reserves96 words, and normal structural bound is93+2t<=95 for t<=1. The actual original four AI spans are73words. The four new typed wrappers are74words because context is loaded once. This is below the same96-word reservation, not a grandfathered increased cap. The new dispatch is CBNZ+11, forward join B+10; both hardware arms contain9words. Exact common RF46 remains six separate decrement/publication pairs plus its unchanged insufficient branch.

## Owner runtime plan: review, do not duplicate

The owner has12 original-literal value cases times14 fuel values,168 baseline/candidate pairs (336 invocations), plus28 ABI invocations,4 unchanged-loader coupling invocations,8 purposeful fault invocations:376 diagnostics, and12 separately bounded trusted C oracle calls. Its four compiled wrappers have one entry fuel charge, followed by the six closed-callee charges. Thus successful wrappers require F>=7 and return remainingF-7; F=7 is a legal completed return with remaining0. F0..6 trap. Parent-only F0/u64 initialization is diagnostic, not normal product-budget admission. A raw remaining0 alone is not evidence of a trap.

The independently recomputed12 expectations use actual original enc/dec table literals, source byte positions0/8/16/24, full64 key XOR, and each exact wrapper consumer. Dynamic full64 mode fixes d=-1; the fixed-mode wrappers cover arbitrary d/key. No arbitrary six-argument public entry claim.

The owner reporter observes final fuel/arena/result/status. It does **not** log every intermediate fuel store. Any actual six-publication trace claim must bind the exact unchanged46-word core and original instrumentation/inputs, or use a separately preregistered trace adapter. The prepared actual-common-fuel46.bin is a scoped machine region, not an executable generic product artifact. Prefix math for F0..9 and eight unsigned boundaries is in fixtures.json: publication valuesF-1...F-min(F,6); F<6 traps on chargeF+1 before the wrapping decrement is published. F>=6 publishes six words and leavesF-6. No bulk subtraction, omitted store, refill, callback, or concurrent outside writer is allowed. The private context is child-owned; parent initialization precedes fork. Logging memory must be disjoint from fuel/context, preserve registers/NZCV, and terminating trap handlers must not resume.

## Distinct future compiler-M coverage:16 paired cases,32 invocations maximum

Prepare two owned diagnostic compiler fixtures from exact RF and inverse-v2 unity sources, preserving product files. Consolidate all scenarios into the two fixtures rather than compiling each scenario separately. Before any native execution, freeze source diffs, compiler/extracted native/offset/loader pins and a raw full-M result schema. A compiled fixture must use the actual reader/namer/checker/lowerer and actual gn-op-call/gn-run-open, not a Python source model substituted for the compiler.

At original SIR924, a diagnostic source hook may capture the actual pre-CALL M state and modify only preregistered CODE-N/G fields. Stop at the focused boundary and compare all MM-WORDS, including error header, CODE/FIX guards, heap top, NF/FN/SIR/labels/literals, descriptors, context flags and shared counters. Do not let later pipeline passes obscure the first failure. Bind the hook to exact source/native records and disclose that instrumentation creates a diagnostic fixture. A scalar checksum alone is insufficient; retain full states or exact paired cell differences with complete hashes. The hook must be in owned copies and must not modify frozen implementation or expectations.

1. Capacity CODE-N=CAP-97 and CAP-96: AI admission true, exact code-region writes and73/74-word span, no write at CODE-BASE+CAP==FIX-BASE, expected counters advance once. Compare against the independently derived allowed write region, not whole-image equality to the65-word RF path.
2. Capacity CODE-N=CAP-95 and CAP: AI admission false, original RF fallback selected. Paired full-M comparison preserves the old fallback's actual error/write behavior; it does not repair or certify that old behavior safe.
3. Invalid CODE-N=-1 and CAP+1: test actual ai-admit only, false and all-M unchanged. Do not invoke the inherited generic emitter outside its valid M contract.
4. Open root, byte, table, xor5: actual gn-run-open with nonzero first/count1. AI admission false; candidate/RF full-M and generated-byte parity. Resolve function IDs from frozen source/SIR, not workload names in product matching.
5. Allocator error0 and preexisting777 with heapTop=HEAP_END-1: actual gn-run-open against independent mem-alloc reference, all-MM-WORDS equality. No new G initialization/write after allocation failure.
6. t=2, sites=64, used=4001: actual AI refusal. Preserve original as/generic selection and prove no new AI patch/counter write. Under valid G metadata, do not fabricate signed-overflow states as normal compiler input.
7. Same M closed/open/closed: actual source/table/closure facts, expected4/0/4 original-site admission; final closed FN/SIR/CODE/FIX/literals and G state equal fresh closed result, no stale certificate. This is one case per arm, not three independent campaigns.

Unexpected encoder-error continuation remains an explicit limit: V2 checks failed m3 before new AI branch patches and failed m4 before shared counters. Inherited gn-emit/rf-charges can continue emission/internal rf patching inside reserved code capacity. This plan does not claim universal no-emission-after-error or repair old as/rf. A future injected-error fixture must compare current failed M, not assert no writes that the implementation never promised.

## Admission before future execution

Use the existing private embedded mask6 contract and a fresh actual FEAT_AES receipt plus exact instruction calibration before enabled guest execution; unsupported hardware fails closed. No performance until all semantic gates and explicit root GO. Every setup refusal, incomplete fixture, trap or failed check is retained; no outcome-driven oracle/source replacement or acceptance retry. Source/type certificates, exact machine projection, finite runtime observations, and universal compiler/ABI claims remain distinct.
