from pathlib import Path
import json,hashlib
W=Path(__file__).resolve().parent;D=W.parent/'vector-emitter-param-bounds-v1-controls';B=W.parent/'vector-emitter-local-bounds-v1-controls';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
pins=load(D/'frozen-source-pins.json');assert sha(D/'frozen-source-pins.json')=='45b5491966e562c2cead798a776df9785812dfe64dd7165ebbd87a53f1d665d6'
for name,h in pins.items():assert sha(D/name)==h,name
assert sha(D/'unity-vector-analysis-on.kotoba')=='ea8281843170b65999ff5a6460a2ba2b3474f04e8e5fda8abc616bf283a0acf5'
delta=load(D/'source-deltas.json');reversed=[]
for variant in ['41-vector-analysis-default.kotoba','41-vector-analysis-on.kotoba','unity-vector-analysis-default.kotoba','unity-vector-analysis-on.kotoba']:
 s=(D/variant).read_text()
 for change in delta['changes']:
  assert s.count(change['new'])==1,(variant,change['name']);s=s.replace(change['new'],change['old'],1)
 assert s.count(delta['newHelpers'])==1;s=s.replace(delta['newHelpers'],'',1);assert s==(B/variant).read_text(),variant
 reversed.append({'variant':variant,'baseSHA256':sha(B/variant),'candidateSHA256':sha(D/variant)})
# Finite storage accounting: all destinations incl lastslot/partialpair/overflow.
slots=[]
for dst in range(257):
 for amount in [1,2]:
  admitted=amount<=256-dst
  cells=list(range(8+dst*8,8+(dst+amount)*8))if admitted else []
  assert not cells or min(cells)>=8 and max(cells)<2056
  slots.append({'dst':dst,'amount':amount,'admitted':admitted})
assert not(2<=256-255) and (2<=256-254) and not(1<=256-256)
# The mask bank immediately follows every max width access and precedes escaped-root markers.
assert max(640+f*2+k for f in range(128)for k in range(2))==895
assert min(896+f for f in range(1,128))==897 and max(896+f for f in range(1,128))==1023
analysis=(D/'analysis.kotoba').read_text();helpers=(D/'helpers.kotoba').read_text();unity=(D/'unity-vector-analysis-on.kotoba').read_text()
assert analysis.count('(+ vw-old 896')==0 # introduced masks only in eight helpers, not oldanalysis writers.
assert '(def vw-work-cap 268435456)'in analysis and '(vw-clear vw-old (+ vw-old 2048))'in analysis
assert helpers.count('(+ vw-old 896')==2
assert '(def ve-feature 0)'in(D/'unity-vector-analysis-default.kotoba').read_text()
assert '(def ve-feature 1)'in unity
r={'status':'PASS_FROZEN_SOURCE_RESOURCE_PHASE_REVIEW_FOR_SEPARATE_BOUNDED_NATIVE_EXPERIMENT_ONLY','nativeGO':False,'nativeCalls':0,'priorHOLDPreservedSHA256':sha(W/'preliminary-report.json'),'explicitAuthorFreezeVerified':True,'sourcePinsSHA256':sha(D/'frozen-source-pins.json'),'frozenPins':pins,'fourVariantExactReversal':reversed,'registeredChanges':['vw-run','ve-source-eligible?','ve-export-sites','ve-export-header','ve-record-admit?','ve-find','ve-admit?'],'newHelpers':8,'registeredButUnchanged':'ve-copy-fields token sign inversion preserved','ownership':{'maskWords':128,'interval':'old896..1023','actualFunctionWrites':'old897..1023 for FN1..127','adjacentWidthLastCell':895,'escapedRootsFirstCell':1024,'sealWords':2056,'headerWords':8,'records':256,'paramSlots':2,'oldAnalysisCleanupWords':50689,'workCap':268435456,'FN':128,'edges':512,'sites':256},'finiteStorageCases':len(slots),'resourceChecks':['only new mask writes use metered vw-write after metered traversal; control30/31 are unused existing control cells','first context pass runs after fullshape convergence while all512x4 original orderededge contributions still exist','contribution ownership ends by existing metered2048zero before certificates','second context pass reads only savedmask, originaledge/SIR/FN identity and unchanged validmemo/fourkey summaries; does not read reusedsites','bothphase traversals requirec1=0, completeclosedgraph, supportedreachableprivateunexported/nonaddress-taken target and positive finalbound','incoming edge exactcaller/site/target/base/arity/body join; known contribution>=finalbound, nonselfzero/-1 reject; self-neutral -1 requires separate positive nonselfanchor','finalcallee incrementalmeet and detailed64 poison code byteexact baseline; no bounds/alias/memo evaluator changes','parameter tokens resolve exact TYVEC argumentpositions1..5 via final fourordinal map; L<=finaltargetbound','locals preserve positiveallocationseal origin; parameters negativeposition plus pairedcontext record stores immutable f/pos/finalbound/endpoints/support/closedescape beforecleanup','paircapacity checkedbeforefirstcopy; dst254param uses last2 slots; dst255param and dst256any refuse; allpartialwrites c1 clear entirebank','header version2, valid flag storedlast only after every record/companion/header completed underworkcap','newconsumer reads seal and currentcheckedFN/SIR/type/body/mode/constantindex only; no wiped VW fields consulted','retained original hchk/indexpool/address/load and original caller allocation/call/fuel/trap sequence, only gnreadbounds trio removed on admittedsite','entrydirty/refusal/partial clears, afteremit/MMERR clear2056 separatebank;50689oldcleanup unchanged'], 'semanticLimits':['activation-local trusted seal derived from existing checkedanalysis, not globalComputeCID/ResultCID or general formalproof','nonselfpositiveanchor may transitively depend on closed finite graph; soundness relies unchanged conservative final fixedpoint, zero external roots and alias/killcontracts; no universalSCC runtime claim','secondpass manufactured contributionL is not independent reevaluation: correctness relies firstpass validatedmask plus immutableedge/summary/key context until publication','positivecensus64param/34priority etc not actualemitteradmission; no omittedcount asserted','defaultOFF workloadbytegate, failurecuts/dirtybank/fullcleanup/positivezero/recursive/sourcecontexts/machineword/functional andactual19 qualification remain runtime gates','root retains nativeGO authority; explicit finalfreeze required for executedsources'], 'newConsumerAnalysisReads':False,'sourceMutationByReviewer':False}
(W/'report-v2.json').write_text(json.dumps(r,indent=2)+'\n');print(sha(W/'report-v2.json'))
