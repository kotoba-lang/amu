from pathlib import Path
import os, json, hashlib, subprocess, re
import compare
D=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,x):(D/n).write_text(json.dumps(x,indent=2)+'\n')
def require(x,why):
    if not x:raise AssertionError(why)

def functional_report(raw,n):
    pattern=(rb'\{:status :ok :result (-?\d+) :fuel \{:initial (\d+) :remaining (\d+)\}'
             rb' :heap \{:capacity (\d+) :used (\d+)\} :string-pool \{:capacity (\d+) :used (\d+)\}'
             rb' :vectors \{:capacity (\d+) :used (\d+)\} :vector-items \{:capacity (\d+) :used (\d+)\}\}\n')
    m=re.fullmatch(pattern,raw);require(m is not None,'exact metered structured i64 success report')
    x=list(map(int,m.groups()));require(x[0]==2*n,'mathematically expected result 2*n')
    require(x[1]==16777216 and 0<=x[2]<=x[1],'fuel in fixed budget')
    require(x[7]==4096 and x[9]==65536,'functional vector capacities')
    for cap,used in zip(x[3::2],x[4::2]):require(0<=used<=cap,'arena within capacity')
    return {'result':x[0],'initialFuel':x[1],'remainingFuel':x[2],
            'heap':x[3:5],'stringPool':x[5:7],'vectors':x[7:9],'vectorItems':x[9:11]}

def execute():
    g=json.loads((D/'parent-go.json').read_text());pins=json.loads((D/'source-pins.json').read_text())
    require(g.get('maximumLoaderCalls')==10 and g.get('authorizeNative') is True,'explicit root 10-call GO')
    require(g.get('sourcePinsSHA256')==sha(D/'source-pins.json'),'root pins source manifest')
    require(g.get('candidateInputSHA256')==sha(D/'candidate-input.json'),'root binds actual candidate build input pins')
    for name,h in pins.items():require(sha(D/name)==h,('source pin',name))
    prereg=json.loads((D/'preregistration.json').read_text())
    for key in ('referenceProducer','loader'):
        e=prereg[key];require(sha(e['path'])==e['sha256'] and Path(e['path']).stat().st_size==e['bytes'],('frozen input',key))
    candidate=json.loads((D/'candidate-input.json').read_text())
    require(candidate.get('parameterBridgeON') is True and candidate.get('returnedOrExportedParameterRelaxation') is False,'root reviewed parameter-only ON candidate')
    for key in ('candidateProducer','candidateBuild','candidateSource','sourceReviewReceipt'):
        e=candidate[key];require(isinstance(e['sha256'],str) and re.fullmatch(r'[0-9a-f]{64}',e['sha256']) and isinstance(e['bytes'],int) and e['bytes']>0,'actual input hash/size schema')
        require(sha(e['path'])==e['sha256'] and Path(e['path']).stat().st_size==e['bytes'],('actual candidate input',key))
    require(g.get('candidateSourceSHA256')==candidate['candidateSource']['sha256'],'root accepted exact candidate source')
    require(g.get('sourceReviewReceiptSHA256')==candidate['sourceReviewReceipt']['sha256'],'root accepted source/resource review receipt')
    loader=Path(prereg['loader']['path']);reference=Path(prereg['referenceProducer']['path']);candidate_image=Path(candidate['candidateProducer']['path'])
    require(not(D/'attempts.json').exists(),'no native reruns')
    rows=[];results={}; base={k:v for k,v in os.environ.items() if not k.startswith('KEXE_')}
    compiler={'KEXE_COMMAND':'1','KEXE_CAP_RESOURCES_35':str(D),'KEXE_STRING_POOL':'268435456',
              'KEXE_VECTORS':'4194304','KEXE_PAIRS':'16777216','KEXE_VECTOR_ITEMS':'134217728',
              'KEXE_CPU_SECONDS':'1800','KEXE_WALL_SECONDS':'1800'}
    functional={'KEXE_ARG_TYPES':'i64','KEXE_CPU_SECONDS':'30','KEXE_FUEL':'16777216','KEXE_RESULT_TYPE':'i64',
                'KEXE_STRUCTURED_REPORT':'1','KEXE_VECTORS':'4096','KEXE_VECTOR_ITEMS':'65536','KEXE_WALL_SECONDS':'30'}
    def guard_inputs():
        for name,h in pins.items():require(sha(D/name)==h,('source stays frozen',name))
        for e in (prereg['referenceProducer'],prereg['loader'],*[candidate[k] for k in ('candidateProducer','candidateBuild','candidateSource','sourceReviewReceipt')]):
            require(sha(e['path'])==e['sha256'] and Path(e['path']).stat().st_size==e['bytes'],'fixed producer/source/review/loader unchanged')
    def call(label,argv,env,timeout):
        guard_inputs()
        require(len(rows)<10,'ten-call cap')
        require(not (D/(label+'.stdout')).exists(),'no repeated label')
        row={'index':len(rows)+1,'label':label,'argv':argv,'kexeEnvironment':env,
             'inheritedKexeRemoved':sorted(k for k in os.environ if k.startswith('KEXE_')),
             'imageSHA256':sha(argv[1]),'state':'started','timeoutSeconds':timeout}
        rows.append(row);save('attempts.json',rows)
        try:
            q=subprocess.run(argv,env=base|env,capture_output=True,timeout=timeout)
            out,err,rc=q.stdout,q.stderr,q.returncode
        except subprocess.TimeoutExpired as e:out,err,rc=e.stdout or b'',e.stderr or b'',None
        (D/(label+'.stdout')).write_bytes(out);(D/(label+'.stderr')).write_bytes(err)
        row.update(state='terminal',returncode=rc,stdoutSHA256=hashlib.sha256(out).hexdigest(),stderrSHA256=hashlib.sha256(err).hexdigest());save('attempts.json',rows)
        guard_inputs()
        require(rc==0 and not err,('successful invocation',label,rc,err[-500:]));return out
    try:
        for variant,image in [('reference',reference),('candidate',candidate_image)]:
            argv=[str(loader),str(image),'0','0','aarch64','35,37,38,39','--']
            out=call(variant+'-compile',argv+['compile',str(D/'fixture.kotoba'),'--target','aarch64-macos','--output',str(D/(variant+'.kseed'))],compiler,1810)
            require(b':ok true' in out,'compile reports success')
            out=call(variant+'-extract',argv+['extract-native',str(D/(variant+'.kseed')),'--symbol','bench','--output',str(D/(variant+'.bin'))],compiler,1810)
            require(b':ok true' in out,'extract reports success')
            matches=re.findall(rb':offset (\d+)\b',out);require(len(matches)==1,'unique extract offset')
            offset=int(matches[0]);(D/(variant+'.offset')).write_text(str(offset)+'\n')
            compare.container(D/(variant+'.kseed'),D/(variant+'.bin'),offset)
        structural=compare.compare_folder(D);save('structural-validation.json',structural)
        for n in (0,7,-1):
            pair=[]
            for variant in ('reference','candidate'):
                label=variant+'-n'+str(n)
                argv=[str(loader),str(D/(variant+'.bin')),(D/(variant+'.offset')).read_text().strip(),'1','aarch64','-',str(n)]
                out=call(label,argv,functional,40)
                result=functional_report(out,n);pair.append((out,result));results[label]=result
            require(pair[0][0]==pair[1][0],'exact same structured result/fuel/arena observations')
        require(len(rows)==10,'exact four compiler plus six functional calls')
        save('report.json',{'status':'PASS_INITIAL_SINGLE_PRIVATE_PARAMETER_BOUNDS_FIXTURE','loaderCalls':10,'functionalCalls':6,
                           'inputs':[0,7,-1],'expectedResults':[0,14,-2],'candidateInputSHA256':sha(D/'candidate-input.json'),'results':results,'structural':structural,'timing':False,
                           'original19Qualified':False,'allRefusalsQualified':False,'selfhostQualified':False,'performanceQualified':False})
    except BaseException as e:
        save('failure.json',{'exception':repr(e),'loaderCalls':len(rows),'policy':'STOP_FIRST_FAILURE_NO_RERUN'});raise
    finally:save('terminal.json',{'allCallsClosed':all(x['state']=='terminal' for x in rows),'loaderCalls':len(rows),'failure':(D/'failure.json').exists()})

if __name__=='__main__':execute()
