import compare, json, tempfile
from pathlib import Path
s=compare.readseq(9,10,0)
old=[0x14000011]+s+[0xd65f03c0,0xd65f03c0]
new=[0x1400000e]+s[:9]+s[12:]+[0xd65f03c0,0xd65f03c0]
p=compare.compare_words(old,new,68,56); rejects=[]
mutants={
 'handle-load':(1,1),'handle-trap':(6,1),'descriptor':(9,1),'pool':(10,1),
 'address':(11,1),'load':(12,1),'branch-target':(0,1),'tail':(14,1)}
for name,(i,b) in mutants.items():
 m=new.copy();m[i]^=b
 try:compare.compare_words(old,m,68,56)
 except AssertionError:rejects.append(name)
 else:raise AssertionError(('accepted mutant',name))
for name,o,n in [('wrong-export',68,60),('wrong-length',68,56)]:
 try:compare.compare_words(old,new+[0] if name=='wrong-length' else new,o,n)
 except AssertionError:rejects.append(name)
 else:raise AssertionError(name)
print(json.dumps({'status':'PASS_OFFLINE_COMPARATOR_SELFTEST','positive':p,'rejectedMutants':rejects,'native':0},indent=2))
import run
raw=b'{:status :ok :result -2 :fuel {:initial 16777216 :remaining 16777000} :heap {:capacity 4096 :used 0} :string-pool {:capacity 65536 :used 0} :vectors {:capacity 4096 :used 1} :vector-items {:capacity 65536 :used 4}}\n'
run.functional_report(raw,-1)
report_rejects=[]
for name,m in [
 ('wrong-result',raw.replace(b':result -2',b':result 7')),
 ('trap',raw.replace(b':status :ok',b':status :trap')),
 ('unmetered',raw.replace(b':remaining 16777000}',b':remaining 16777000 :metered false}')),
 ('wrong-budget',raw.replace(b':initial 16777216',b':initial 16777215')),
 ('arena-overflow',raw.replace(b':used 4}',b':used 65537}')),
 ('duplicate-report',raw+raw),('trailing-text',raw+b'junk\n')]:
 try:run.functional_report(m,-1)
 except AssertionError:report_rejects.append(name)
 else:raise AssertionError(('report mutant',name))
print(json.dumps({'status':'PASS_OFFLINE_FUNCTIONAL_REPORT_SELFTEST','rejectedMutants':report_rejects,'native':0},indent=2))
