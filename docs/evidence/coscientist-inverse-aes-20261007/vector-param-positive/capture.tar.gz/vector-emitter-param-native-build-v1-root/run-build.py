from pathlib import Path
import hashlib,json,os,re,subprocess

D=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):(D/n).write_text(json.dumps(v,indent=2)+'\n')
g=json.loads((D/'preregistration.json').read_text())
assert g['authorizeNativeBuild'] is True and g['maximumLoaderCalls']==2
assert sha(Path(__file__))==g['driverSHA256']
def guard():
 for n,h in g['inputs'].items():assert sha(D/n)==h,n
 for n,h in g['reviews'].items():assert sha(Path(n))==h,n
guard();assert not (D/'attempts.json').exists(),'No native reruns'
base={k:v for k,v in os.environ.items()if not k.startswith('KEXE_')}
overrides={'KEXE_COMMAND':'1','KEXE_CAP_RESOURCES_35':str(D),
 'KEXE_STRING_POOL':'268435456','KEXE_VECTORS':'4194304',
 'KEXE_PAIRS':'16777216','KEXE_VECTOR_ITEMS':'134217728',
 'KEXE_CPU_SECONDS':'1800','KEXE_WALL_SECONDS':'1800'}
env=base|overrides
rows=[]
def call(label,args):
 guard();assert len(rows)<2
 cmd=[str(D/'kexe-loader'),str(D/'producer.bin'),'0','0','aarch64','35,37,38,39','--',*args]
 r={'index':len(rows)+1,'label':label,'argv':cmd,'state':'started',
    'kexeEnvironment':overrides,'removedInheritedKexeKeys':sorted(k for k in os.environ if k.startswith('KEXE_')),
    'producerSHA256':sha(D/'producer.bin'),'sourceSHA256':sha(D/'unity.kotoba'),'timeoutSeconds':1810}
 rows.append(r);save('attempts.json',rows)
 try:
  q=subprocess.run(cmd,env=env,capture_output=True,timeout=1810)
  out,err,rc=q.stdout,q.stderr,q.returncode
 except subprocess.TimeoutExpired as e:out,err,rc=e.stdout or b'',e.stderr or b'',None
 (D/(label+'.stdout')).write_bytes(out);(D/(label+'.stderr')).write_bytes(err)
 r.update(state='terminal',returncode=rc,stdoutSHA256=hashlib.sha256(out).hexdigest(),stderrSHA256=hashlib.sha256(err).hexdigest())
 save('attempts.json',rows);guard()
 assert rc==0 and err==b'' and b':ok true' in out,(label,rc,out[-1000:],err[-1000:])
 return out
try:
 call('compile',['compile',str(D/'unity.kotoba'),'--target','aarch64-macos','--output',str(D/'candidate.kseed')])
 out=call('extract',['extract-native',str(D/'candidate.kseed'),'--symbol','main','--output',str(D/'candidate.bin')])
 offsets=re.findall(rb':offset (\d+)\b',out);assert len(offsets)==1 and int(offsets[0])==0
 (D/'candidate.offset').write_text('0\n');b=(D/'candidate.bin').read_bytes()
 assert (D/'candidate.kseed').read_bytes()==f'KSEED1 {len(b)} 1\nmain 0 0\n\n'.encode()+b
 save('report.json',{'status':'PASS_TWO_CALL_PARAMETER_CANDIDATE_NATIVE_BUILD_ONLY','loaderCalls':2,
  'bytes':len(b),'sha256':sha(D/'candidate.bin'),'sourceSHA256':sha(D/'unity.kotoba'),
  'offset':0,'fullKSEEDPayloadEqualsNative':True,'soleExportMainArity0':True,
  'functionalCases':0,'benchmarkBodies':0,'timing':False,'actualEmittedBoundsOmissions':'NOT_VALIDATED',
  'selfbuildGenerations':0,'persistentCIDCache':'NOT_IMPLEMENTED','productAdopted':False})
except BaseException as e:save('failure.json',{'exception':repr(e),'loaderCalls':len(rows),'policy':'STOP_FIRST_FAILURE_NO_RERUN'});raise
finally:save('terminal.json',{'allCallsClosed':all(r['state']=='terminal'for r in rows),'loaderCalls':len(rows),'failure':(D/'failure.json').exists()})
