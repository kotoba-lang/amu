"""Offline finite raw receipt checker; does not execute native code."""
from pathlib import Path
import json,re,sys
MASK=(1<<64)-1
D=Path(__file__).resolve().parent
# FUTURE runtime owner supplies receipts using this exact schema.
def compare(case,fuel,baseline,candidate,entry_fuel=1,callee_fuel=6):
 assert baseline==candidate,('full supervisor/status/result/fuel/allocator/trap mismatch',case['tag'],fuel)
 row=candidate;state=row['stdout']
 initial=int(re.search(r':initial (\d+)',state)[1]);remaining=int(re.search(r':remaining (\d+)',state)[1]);assert initial==fuel
 expected_charges=entry_fuel+callee_fuel
 if fuel>=expected_charges:
  result=int(re.search(r':result (-?\d+)',state)[1])&MASK
  assert row['exit']==0 and result==case['expectedResultU64']
  assert remaining==fuel-expected_charges
 else:
  assert row['exit']==120 and ':status :trap' in state and remaining==0
  assert ':budget/fuel' in row['stderr']
 # no vector allocation by selected wrapper/table helper at runtime (literal pools are static).
 for name in ['heap','string-pool','vectors','vector-items']:
  assert re.search(r':'+name+r' \{:capacity \d+ :used 0\}',state)
 return True
if __name__=='__main__':
 if len(sys.argv)!=2:raise SystemExit('Provide frozen runtime receipt JSON only; no native execution here')
 x=json.loads(Path(sys.argv[1]).read_text());assert x['actualWrapperEntryFuel']==1 and x['actualClosedCalleeFuel']==6
 cases=json.loads((D/'cases.json').read_text());schedule=json.loads((D/'schedule.json').read_text())['pairs'];assert len(x['pairs'])==len(schedule)==168
 for expected,row in zip(schedule,x['pairs']):
  assert row['case']==expected['case'] and row['fuel']==expected['fuel'];compare(cases[row['case']],row['fuel'],row['baseline'],row['candidate'])
 print('PASS finite168 pairs; raw exact and source-literal expected values/fuel prefix')
