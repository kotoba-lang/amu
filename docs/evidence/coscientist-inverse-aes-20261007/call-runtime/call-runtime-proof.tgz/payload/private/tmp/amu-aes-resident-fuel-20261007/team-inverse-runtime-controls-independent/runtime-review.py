from pathlib import Path
import json,hashlib,importlib.util,re,struct
D=Path(__file__).parent;W=D.parent;P=W/'team-inverse-compiled-call-plan';C=P/'runtime-controls';R=C/'results';N=P/'runtime-procedure/results';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
for r in load(D/'runtime-review-preregistration.json')['inputs']:assert sha(Path(r['path']))==r['sha256']and Path(r['path']).stat().st_size==r['bytes']
for r in load(D/'static-pins.json'):assert sha(D/r['path'])==r['sha256']
normalpins=load(W/'root/inverse-compiled-call-runtime-result.json')['pins'];assert len(normalpins)==386
for n,pin in normalpins.items():assert sha(N/n)==pin['sha256']and(N/n).stat().st_size==pin['bytes']
terminal=load(R/'terminal.json');assert terminal['allWritesComplete']and sha(R/'report.json')==terminal['reportSHA256']and sha(R/'pins.json')==terminal['pinsSHA256']
for n,pin in load(R/'pins.json').items():assert sha(R/n)==pin['sha256']and(R/n).stat().st_size==pin['bytes']
def module(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
controls=module('offline_controls',C/'run.py');abi=module('offline_abi',P/'abi-wrapper.py');data=load(R/'results.json');reg=load(C/'preregistration.json');static=load(D/'static-report.json');cases=load(P/'cases.json');images=load(P/'compiled-images/images.json');attempt=load(R/'attempts.json');normal=load(N/'pairs.json');fuels=load(P/'schedule.json')['fuels'];assert len(attempt['hostBuilds'])==14 and len(attempt['guestInvocations'])==40
expectedImages={};expectedSource={};coupleExpected={}
for profile in ['default','candidate']:
 raw=(P/'compiled-images'/profile/'call-live.bin').read_bytes();blob,off=abi.append_sentinels(raw,images[profile]['call-live']['offset']);expectedImages['abi/'+profile]=(blob,off);expectedSource['abi/'+profile]=P/'diagnostic-loader.c'
for caseid in[0,2,6,10]:
 e=cases[caseid];raw=(P/'compiled-images/candidate'/(e['symbol']+'.bin')).read_bytes();blob,off=controls.append_coupling(raw,images['candidate'][e['symbol']]['offset'],e['args'],e['expectedResultU64']);label='coupling/'+e['symbol'];expectedImages[label]=(blob,off);expectedSource[label]=Path('/private/tmp/amu-embedded-host-feature-gate-20261007/host-feature-loader.c');coupleExpected[label]=caseid
for f,s in zip(reg['mutants'],static['mutations']):
 assert f['id']==s['id'];raw=(P/'compiled-images/candidate'/(f['symbol']+'.bin')).read_bytes();off=images['candidate'][f['symbol']]['offset']
 if f['id']=='callee-saved-clobber':blob,off=abi.append_sentinels(raw,off,True)
 else:blob=controls.patch_word(raw,s['oneBasedIndex'],int(s['old'],16),int(s['new'],16))
 label='mutants/'+f['id'];expectedImages[label]=(blob,off);expectedSource[label]=P/'diagnostic-loader.c'
seen=set()
for build in attempt['hostBuilds']:
 label=build['label'];assert label in expectedImages and label not in seen;seen.add(label);q=R/label;blob,off=expectedImages[label];source=expectedSource[label]
 assert build['state']=='terminal'and build['returncode']==0 and(q/'image.bin').read_bytes()==blob and sha(q/'loader')==build['binarySHA256']and sha(source)==build['sourceSHA256']and sha(q/'embedded.h')==build['headerSHA256']
 assert build['argv']==['clang','-O2','-std=c11','-include',str(q/'embedded.h'),str(source),'-o',str(q/'loader')]
 header=(q/'embedded.h').read_text();array=re.search(r'static const unsigned char kexe_embedded_code\[\] = \{([^}]+)\};',header)[1];assert bytes(map(int,array.split(',')))==blob
 for name,val in [('REQUIRED_HOST_FEATURES','6ULL'),('OFFSET',str(off)+'u'),('ARITY','0u'),('ISA','"aarch64"')]:assert f'#define KEXE_EMBEDDED_{name} {val}\n'in header
 assert'KEXE_HOST_GATE_TEST'not in header and(q/'build.stderr').read_text()==''
assert len(seen)==14
# Match every execution to single raw receipt and fixed predetermined schedule.
index=0;seenRuns=set()
def receipt(label,tag,args,fuel):
 global index
 e=attempt['guestInvocations'][index];index+=1;assert e['state']=='terminal'and(e['label'],e['tag'],e['args'],e['fuel'])==(label,tag,args,fuel)and(label,tag)not in seenRuns;seenRuns.add((label,tag));p=R/label/(tag+'.json');assert sha(p)==e['receiptSHA256'];out=load(p);assert not out.get('timeout',False);return out
assert len(data['abi'])==14
for row,f in zip(data['abi'],fuels):
 assert row['case']==10 and row['fuel']==f
 for profile,key in[('default','baseline'),('candidate','candidate')]:assert row[key]==receipt('abi/'+profile,'fuel'+str(f),cases[10]['args'],f)
 assert row['baseline']==row['candidate'];n=next(r for r in normal if r['case']==10 and r['fuel']==f);assert row['candidate']==n['candidate']==n['baseline']
assert len(data['coupling'])==4
for row,caseid in zip(data['coupling'],[0,2,6,10]):
 e=cases[caseid];out=receipt('coupling/'+e['symbol'],'one-call',[],1048576);assert row['case']==caseid and row['expectedFull64']==e['expectedResultU64']and row['outcome']==out
 assert out['exit']==0 and out['stderr']==''and ':status :ok :result 0 'in out['stdout']and':fuel {:initial 1048576 :remaining 1048569}'in out['stdout']
 for name,cap in[('heap',1048576),('string-pool',16777216),('vectors',131072),('vector-items',4194304)]:assert f':{name} {{:capacity {cap} :used 0}}'in out['stdout']
summary=[];assert len(data['mutants'])==8
for row,f,s in zip(data['mutants'],reg['mutants'],static['mutations']):
 assert row['fault']==f;e=cases[f['case']];out=receipt('mutants/'+f['id'],'one-case',e['args'],f['fuel']);assert out==row['outcome'];normalOutcome=next(r['candidate']for r in normal if r['case']==f['case']and r['fuel']==f['fuel']);assert row['normalOutcome']==normalOutcome and out!=normalOutcome and row['detected']is True
 blob,off=expectedImages['mutants/'+f['id']];raw=(P/'compiled-images/candidate'/(f['symbol']+'.bin')).read_bytes();assert row['originalNativeSHA256']==hashlib.sha256(raw).hexdigest()and row['mutantNativeSHA256']==hashlib.sha256(blob).hexdigest()
 if f['id']=='callee-saved-clobber':assert row['change']=={'postcallSentinelX19Clobber':True}and':result 3203391149 'in out['stdout']
 else:assert row['change']=={'oneBasedCodeIndex':s['oneBasedIndex'],'byteOffset':s['byteOffset'],'originalWord':s['old'],'mutantWord':s['new']}
 if f['id']=='missing-first-slow-publication':assert normalOutcome['exit']==120 and out['exit']==0 and':remaining 0}'in out['stdout']
 if f['id']=='wrong-context-store':assert out['exit']==120 and out['stderr']=='KEXE_TRAP {:kind :signal :signal :SIGBUS}\n'and':remaining 18446744073709551614}'in out['stdout']
 summary.append({'id':f['id'],'exit':out['exit'],'differentFromPinnedNormal':True,'result':int(m[1])if(m:=re.search(r':result (-?\d+)',out['stdout']))else None,'stderr':out['stderr']})
assert index==40 and len(seenRuns)==40
report={'status':'PASS independent retained40 runtime controls only','normalFrozen386Unchanged':True,'headerPrefixAndExecutedBinarySourceBindings':14,'ABI28':'Exact raw normalcandidate/default +sourceexpected/cost7 matched, x19..28 bank sentinels, aligned96B/saved29/30 only; not allABI/SIMD','coupling4':'Exact unchanged60402 loader source, appendedfull64CMP/CSET shim afteroriginalprefix, mask6/code/off immutable, normalized0match before low8exit','mutants8':summary,'allPredeterminedControlsProductive':True,'omittedFirstSlowSTR':'fuel6 erroneously complete remaining0, pinnednormal trap; actual finalstate detects retainedload/store obligation','wrongCtxSTR':'actual[x8] SIGBUS trap120 afterentryfuel1; not assumed preexecution','noRetry':True,'guestCount':40,'overallGuestCount':376,'hostBuildCount':14,'overallHostBuilds':23,'rootPreparationFailuresRetained':str(W/'root/inverse-controls-preparation-failures.json'),'reviewerNativeSolverNetworkTiming':0,'limits':['reported final status/result/fuel/pool only, not unreportedfullM/arena or asyncpublicationtrace','sentinelx19..28 and shimreturn/stack scope, not everypublicABI contract','parentdiagnosticrawu64 budgets exceed packagedbudget admission','no performance/productadoption/fullcompilerqualification']}
(D/'runtime-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
