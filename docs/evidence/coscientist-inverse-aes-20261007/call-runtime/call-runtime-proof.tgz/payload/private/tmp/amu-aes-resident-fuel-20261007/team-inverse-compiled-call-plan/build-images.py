"""Prepared only. Root must provide prospective explicit build-stage authorization."""
from pathlib import Path
import json,hashlib,os,subprocess,re,time,sys,traceback
D=Path(__file__).resolve().parent;P=D.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def main():
 if len(sys.argv)!=2:raise SystemExit('Usage: build-images.py ROOT_BUILD_AUTHORIZATION.json (no implicit run)')
 auth=json.loads(Path(sys.argv[1]).read_text())
 assert auth.get('allowCompilerBuild') is True and auth.get('allowBenchmarkGuest') is False
 assert auth['preregistrationSHA256']==sha(D/'preregistration.json')
 assert auth['fixtureSHA256']==sha(D/'source.kotoba')
 assert auth['compilerProcessCap']==15
 W=D/'compiled-images';assert not W.exists();W.mkdir();save(W/'root-authorization.json',auth)
 seeds={'default':P/'team-inverse-native-images/continuation/default/seed.bin','candidate':P/'root-inverse-selfbuild-v2/seed-4.bin','observer':P/'team-inverse-native-images/continuation/observer/seed.bin'}
 prereg=json.loads((D/'preregistration.json').read_text())
 for n,pin in prereg['inputPins'].items():assert sha(Path(n))==pin['sha256'],n
 loader=P/'inverse-implementation-v2/kexe-loader';assert os.access(loader,os.X_OK)
 env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
 attempts=[];images={};tags=set(json.loads((P/'team-inverse-native-images/continuation/observer-schemas.json').read_text()))
 def run(seed,out,label,args):
  assert len(attempts)<15;cmd=[str(loader),str(seed),'0','0','aarch64','35,37,38,39','--',*args]
  a={'number':len(attempts)+1,'label':str(out.relative_to(W))+'/'+label,'argv':cmd,'state':'started','start':time.time()};attempts.append(a);save(W/'attempts.json',attempts)
  try:q=subprocess.run(cmd,env=env,capture_output=True,timeout=1800);stdout=q.stdout;stderr=q.stderr;rc=q.returncode
  except subprocess.TimeoutExpired as e:stdout=e.stdout or b'';stderr=e.stderr or b'';rc=None;a['timeout']=True
  (out/(label+'.stdout')).write_bytes(stdout);(out/(label+'.stderr')).write_bytes(stderr)
  a.update(state='terminal',returncode=rc,elapsed=time.time()-a['start']);save(out/(label+'.status.json'),a);save(W/'attempts.json',attempts)
  assert rc==0,(a['label'],rc,stderr[-1000:]);return stdout.decode('utf8',errors='replace')
 try:
  for profile,seed in seeds.items():
   out=W/profile;out.mkdir();log=run(seed,out,'compile',['compile',str(D/'source.kotoba'),'--target','aarch64-macos','--output',str(out/'image.kseed')]);images[profile]={}
   for sym in ['call-forward','call-inverse','call-mode','call-live']:
    text=run(seed,out,sym+'-extract',['extract-native',str(out/'image.kseed'),'--symbol',sym,'--output',str(out/(sym+'.bin'))]);off=int(re.search(r':offset (\d+)',text)[1]);(out/(sym+'.offset')).write_text(str(off)+'\n')
    images[profile][sym]={'nativeSHA256':sha(out/(sym+'.bin')),'bytes':(out/(sym+'.bin')).stat().st_size,'offset':off}
   if profile=='observer':
    records=[]
    for line in log.splitlines():
     a=line.split()
     if a and a[0] in tags:records.append({'tag':a[0],'fields':[int(v) for v in a[1:]]})
    save(out/'records.json',records)
    assert images['observer']==images['candidate'],'observer must be code+offset exact'
   save(W/'images.json',images);print('COMPILED ONLY',profile,flush=True)
  assert len(attempts)==15
  save(W/'report.json',{'status':'PASS build/codeidentity only; root actual admission review pending before guest','compilerProcesses':15,'generatedGuestExecutions':0,'images':images})
 except BaseException as e:save(W/'failure.json',{'exception':repr(e),'traceback':traceback.format_exc(),'attempts':len(attempts)});raise
 finally:save(W/'pins.json',{str(p.relative_to(W)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(W.rglob('*')) if p.is_file() and p.name not in ('pins.json','terminal.json')})
 save(W/'terminal.json',{'reportSHA256':sha(W/'report.json'),'pinsSHA256':sha(W/'pins.json'),'guestExecutions':0,'allWritesComplete':True})
if __name__=='__main__':main()
