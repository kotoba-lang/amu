from pathlib import Path
import json,struct,hashlib,re,functools
D=Path(__file__).parent;W=D.parent;P=W/'team-inverse-compiled-call-plan';I=P/'compiled-images';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in json.loads((D/'preregistration.json').read_text())['inputs']:assert sha(Path(p['path']))==p['sha256']
records={}
for l in(I/'observer/compile.stdout').read_text().splitlines():
 x=l.split()
 if x and x[0]in ['SIR','FN','EMIT','FIX','AIARG','AIPRE','AIPOST','RFCORE','FREC']:records.setdefault(x[0],[]).append(tuple(map(int,x[1:])))
S={x[0]:x[1:]for x in records['SIR']};F={x[0]:x[1:]for x in records['FN']};E={x[0]:x[1:]for x in records['EMIT']};assert json.loads((I/'observer/records.json').read_text())==[{'tag':l.split()[0],'fields':list(map(int,l.split()[1:]))}for l in(I/'observer/compile.stdout').read_text().splitlines()if l.split()and l.split()[0]in ['SIR','FN','FREC','EMIT','FIX','LIT','CACHE','ASPRE','ASPOST','ASARG','AIARG','AIPRE','AIPOST','RFCORE','TABLES']]
b=(I/'candidate/call-mode.bin').read_bytes();a=(I/'default/call-mode.bin').read_bytes()
for name,f in [('call-forward',76),('call-inverse',77),('call-mode',78),('call-live',79)]:
 assert(I/'candidate'/f'{name}.bin').read_bytes()==(I/'observer'/f'{name}.bin').read_bytes()==b
 assert(I/'default'/f'{name}.bin').read_bytes()==a
 off=int((I/'candidate'/f'{name}.offset').read_text());assert off==4*(F[f][-1]-1)and(I/'candidate'/f'{name}.offset').read_bytes()==(I/'observer'/f'{name}.offset').read_bytes()
nb=max(x[3]for x in records['EMIT']);na=nb-64;bw=list(struct.unpack('<%dI'%(nb-1),b[:4*(nb-1)]));aw=list(struct.unpack('<%dI'%(na-1),a[:4*(na-1)]))
exec((W/'team-independent/machine-decoder.py').read_text().split('def parse')[0])
charge=[0xf94004f0,0xf1000610,0x54000042,0xd4200000,0xf90004f0];rf=[charge[0],0xf1001a1f,0x540001c3]+[charge[1],charge[4]]*6+[0x1400001f]+charge*6
fw=[0x4f00e401,0x1e270020,0x4e0c1c40,0x4e141c60,0x4e1c1c80,0x4e284820,0x4e286800,0x0e043c10,0xca050200];iv=[0x4f00e401,0x1e270020,0x4e0c1c80,0x4e141c60,0x4e1c1c40,0x4e285820,0x4e287800,0x0e043c10,0xca050200]
sites=[];assert len(records['AIPRE'])==len(records['AIPOST'])==len(records['RFCORE'])==8 and len(records['AIARG'])==48
for k,(pre,post,coreinfo)in enumerate(zip(records['AIPRE'],records['AIPOST'],records['RFCORE'])):
 sir,f,t,lo,fix,frame,height,ctx,vm,used,count=pre;ii,dispatch,jump,inverse,after,hi,words,fa,err=post;core,guard,fjoin,slow,join,re=coreinfo
 assert f==61 and S[sir]==(13,61,0,6)and t==0 and frame in[160,288]and height==6 and ctx in[0,1]and vm==0 and count==k and used==sum(s['words']for s in sites)and err==re==0
 assert(core,guard,fjoin,slow,join)==(dispatch-46,dispatch-44,dispatch-31,dispatch-30,dispatch)
 assert bw[core-1:dispatch-1]==rf and bw[dispatch-1]==0xb5000000|((inverse-dispatch)<<5)
 assert bw[dispatch:jump-1]==fw and bw[inverse-1:after-1]==iv and jump==dispatch+10 and inverse==jump+1 and after==inverse+9 and bw[jump-1]==0x14000000|(after-jump)
 assert words==hi-lo==(73 if k<4 else 74)and E[sir]==(0,lo,hi)and fa==fix
 oldlo=lo-8*k;oldhi=hi-8*(k+1);og=core-8*k;oj=og+56;of=oj+1;oa=of+1
 assert aw[oldlo-1:og-1]==bw[lo-1:core-1]and aw[oa-1:oldhi-1]==bw[after-1:hi-1]
 assert aw[og-1]==0xb5000000|((of-og)<<5)and aw[og:oj-1]==rf+fw and aw[oj-1]==0x14000000|(oa-oj)
 assert of+branch(aw[of-1])[1]==F[61][-1]
 args=records['AIARG'][6*k:6*k+6];capture=bw[lo-1:core-1]
 for j,(u,kind,value,reg,home,offset)in enumerate(args):
  assert u==j and kind in[1,2,3]and home>0 and offset==frame-8*(home+1)and(reg<0 or reg==31 or 9<=reg<=15 or 19<=reg<=28)
  if k>=4:
   assert len(capture)==7
   if kind==3:assert capture[j]==0xaa0003e0|(reg<<16)|j
   else:assert capture[j]==(0xd2800000|((value&65535)<<5)|j if value>=0 else 0x92800000|(((~value)&65535)<<5)|j)
 assert not any(lo<=q[1]<hi for q in records['FIX'])
 sites.append({'sir':sir,'callee':61,'newLo':lo,'newHi':hi,'oldLo':oldlo,'oldHi':oldhi,'words':words,'core':core,'full64CBNZ':dispatch,'args':args,'captureWords':capture,'callerFN':next(f for f,v in F.items()if v[0]<=sir<next((j for j in range(v[0]+1,max(S)+1)if S[j][0]==2),max(S)+1))})
# Direct complete remaining word/edge projection. Only certified8 spans and declared literal fixups normalize.
def normalize(words,n,new):
 spans={(s['newLo']if new else s['oldLo']):(s['newHi']if new else s['oldHi'],s)for s in sites};mapping={};stream=[];edges=[];inside=set();lits={}
 for ix,at,kind,target,aux in records['FIX']:
  if kind==5:
   q=at if new else at-8*sum(s['newHi']<=at for s in sites);lits[q]=(target,0);lits[q+1]=(target,1)
 i=1
 while i<n:
  if i in spans:
   end,s=spans[i]
   for j in range(i,end):mapping[j]=len(stream)
   inside.update(range(i+1,end));stream.append(('AI',s['sir']));i=end;continue
  mapping[i]=len(stream);z=words[i-1];q=branch(z)
  if q:stream.append(('BR',q[0]));edges.append((len(stream)-1,i+q[1]))
  elif i in lits:stream.append(('LIT',lits[i],z&~0x1fffe0))
  else:stream.append(('WORD',z))
  i+=1
 mapping[n]=len(stream)
 assert all(t not in inside for _,t in edges)
 return stream,mapping,edges
aa,pa,ea=normalize(aw,na,False);bb,pb,eb=normalize(bw,nb,True);assert aa==bb and len(ea)==len(eb)and all(x[0]==y[0]and pa[x[1]]==pb[y[1]]for x,y in zip(ea,eb))
ap=(4*(na-1)+7)//8*8;bp=(4*(nb-1)+7)//8*8;assert a[ap:]==b[bp:]
for ix,at,kind,target,aux in records['FIX']:
 if kind==5:
  oldat=at-8*sum(s['newHi']<=at for s in sites);get=lambda w,j:((w[j-1]>>5)&65535)|(((w[j]>>5)&65535)<<16);assert get(aw,oldat)-ap==get(bw,at)-bp
# Finite acyclic actualSIR path charge accounting, no assumptions about correlated mode branches.
memo={};visiting=set()
def fuel(f):
 if f in memo:return memo[f]
 assert f not in visiting;visiting.add(f);start=F[f][0];end=next(i for i in range(start+1,max(S)+1)if S[i][0]==2);labels={S[i][1]:i for i in range(start,end+1)if S[i][0]==9};seen=set()
 def walk(i,path):
  assert i not in path and start<=i<=end;op,x,y,z=S[i]
  if op in[19,2]:return{0}
  nxt=[labels[x]]if op==10 else([i+1,labels[y]]if op==11 else[i+1]);add=fuel(x)if op==13 else({1}if op==18 else{0});out=set()
  for j in nxt:
   for a in add:
    for b in walk(j,path|{i}):out.add(a+b)
  return out
 result=walk(start+1,set());visiting.remove(f);memo[f]=result;return result
assert fuel(61)=={6}and all(fuel(f)=={7}for f in[76,77,78,79])
# Actual live-key postcall read selects x19; consumer xor originalkey then increment.
assert S[1869]==(4,1,5,0);event=E[1870];consumer=bw[event[1]-1:event[2]-1];assert any((z&0xffe0ffe0)==0xca000000 and((z>>16)&31)==19 for z in consumer)
orig=(W/'team-inverse-native-images/continuation/sources/nettle-aes.kotoba').read_text();src=(P/'source.kotoba').read_text();assert src[:src.index('\n;; One-off diagnostic wrappers.')].splitlines()[1:]==orig.rstrip().splitlines()[1:]
report={'status':'PASS independent compiled wrapper static source/SIR/machine audit only','sites':sites,'actualOriginalAndWrapperAdmissions':[4,4],'wrapperFrames':160,'candidateObserverBytesAndOffsetsExact':True,'defaultAndCandidateOnly8CertifiedRegionsChanged':True,'remainingCanonicalWords':len(aa),'remainingEdges':len(ea),'literalPoolBytesExact':len(b)-bp,'genericOriginalCalleeCodeEntryUnchanged':F[61][-1],'semanticFuelCountByActualAllPathSIR':{str(k):sorted(v)for k,v in memo.items()},'callLiveKey':'AIARG5 LOCALslot5 reg19; capture3631 MOVx5,x19; actual XORconsumer reads x19 after AI','liveConsumerWords':[hex(z)for z in consumer],'defaultMetadataBoundary':'No separate default observer exists; oldregion locations derive from independently bound exact8-word delta and actual raw default instruction stream. No claim actualdefault allFF metadata comparison.','publicationBoundary':'Original literal-table leaf charges use x8 register decrement and return publication; RF six context stores are not cycle-by-cycle identical original stores. Static total6 and original insufficient sequence bound; actual prefix/fullstate runtime qualification still required.','unqualified':['compiledCALL dynamic value/capture ABI','private mask6 guest admission','fuelprefix/shared-state/fullM/arena/traps','performance/product adoption'],'newNativeBuildRunSolverNetworkTiming':0}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='sites'},indent=2))
