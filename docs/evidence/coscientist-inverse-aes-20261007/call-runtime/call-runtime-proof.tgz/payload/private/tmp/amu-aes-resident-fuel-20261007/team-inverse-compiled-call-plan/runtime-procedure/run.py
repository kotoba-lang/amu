from pathlib import Path
import json,hashlib,os,subprocess,sys,importlib.util,traceback
R=Path(__file__).resolve().parent;D=R.parent;W=R/'results';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def loadmodule(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
host=loadmodule('owned_host',D/'host-harness.py');check=loadmodule('owned_check',D/'check-results.py')
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def main():
 if len(sys.argv)!=3 or sys.argv[1] not in ['preflight','full']:raise SystemExit('run.py preflight|full ROOT_AUTHORIZATION.json; no implicit execution')
 phase=sys.argv[1];a=json.loads(Path(sys.argv[2]).read_text());assert a['allowCompiledCallNative'] is True and a['actualAdmissionReviewPASS'] is True
 assert a['runtimeProcedureSHA256']==sha(Path(__file__)) and a['fixtureSHA256']==sha(D/'source.kotoba')
 assert a['preregistrationSHA256']==sha(D/'preregistration.json') and a['guestInvocationCap']==376 and a['hostBuildCap']==32
 assert a['phase']==phase
 for n,h in json.loads((R/'preregistration.json').read_text())['inputPins'].items():assert sha(Path(n))==h,n
 cases=json.loads((D/'cases.json').read_text());schedule=json.loads((D/'schedule.json').read_text())['pairs'];images=json.loads((D/'compiled-images/images.json').read_text())
 if phase=='preflight':
  assert a['maximumPairsThisPhase']==4
  H=host.ScopedHost(sys.argv[2],W);rows=[];oracle=[]
  for profile in ['default','candidate']:
   for symbol,e in images[profile].items():
    raw=D/'compiled-images'/profile/(symbol+'.bin');assert sha(raw)==e['nativeSHA256'];H.build(profile+'/'+symbol,raw.read_bytes(),e['offset'])
  p=W/'source-oracle';p.mkdir();cmd=['clang','-O2','-std=c11',str(D/'source-oracle.c'),'-o',str(p/'oracle')]
  H.builds.append({'label':'source-oracle','state':'started','argv':cmd});H.save();q=subprocess.run(cmd,capture_output=True,timeout=1800);(p/'build.stdout').write_bytes(q.stdout);(p/'build.stderr').write_bytes(q.stderr);H.builds[-1].update(state='terminal',returncode=q.returncode);H.save();assert q.returncode==0
  allowed=schedule[:4]
 else:
  assert a['maximumPairsThisPhase']==164 and (W/'preflight-terminal.json').exists() and not (W/'full-terminal.json').exists()
  pre=json.loads((W/'preflight-terminal.json').read_text());assert pre['status']=='PASS4pairs'
  # Resume only this exact completed preflight; never create a second host/job.
  H=host.ScopedHost.__new__(host.ScopedHost);H.output=W;x=json.loads((W/'attempts.json').read_text());H.builds=x['hostBuilds'];H.runs=x['guestInvocations'];assert len(H.runs)==8
  rows=json.loads((W/'pairs.json').read_text());oracle=json.loads((W/'oracle-receipts.json').read_text());assert len(rows)==4
  save(W/'full-authorization.json',a);allowed=schedule[4:]
 try:
  for spec in allowed:
   e=cases[spec['case']];fuel=spec['fuel'];out=[]
   if not any(x['case']==e['id'] for x in oracle):
    assert len(oracle)<12;p=W/'source-oracle';q=subprocess.run([str(p/'oracle'),str(e['id'])],capture_output=True,timeout=30);receipt={'case':e['id'],'exit':q.returncode,'stdout':q.stdout.decode(errors='replace'),'stderr':q.stderr.decode(errors='replace')};oracle.append(receipt);save(W/'oracle-receipts.json',oracle);assert q.returncode==0
   for profile in ['default','candidate']:
    out.append(H.capture(profile+'/'+e['symbol'],'case'+str(e['id'])+'-fuel'+str(fuel),e['args'],fuel))
   row={'case':e['id'],'fuel':fuel,'baseline':out[0],'candidate':out[1]};rows.append(row);save(W/'pairs.json',rows)
   check.compare(e,fuel,*out,entry_fuel=1,callee_fuel=6)
   print('PASS fullstate/sourceoracle',e['tag'],fuel,flush=True)
  if phase=='preflight':assert len(rows)==4 and len(H.runs)==8
  else:assert len(rows)==168 and len(H.runs)==336
  save(W/(phase+'-terminal.json'),{'status':'PASS4pairs' if phase=='preflight' else 'PASS168pairs','actualWrapperEntryFuel':1,'actualClosedCalleeFuel':6,'pairs':len(rows),'guestInvocations':len(H.runs),'oracleCases':len(oracle),'noTiming':True,'remainingABIMutantCouplingGates':'separately gated; no automatic execution'})
 except BaseException as e:save(W/(phase+'-failure.json'),{'exception':repr(e),'traceback':traceback.format_exc(),'pairsRetained':len(rows),'guestInvocations':len(H.runs)});raise
if __name__=='__main__':main()
