from pathlib import Path
import json,hashlib,importlib.util,struct,inspect,re
D=Path(__file__).parent;P=D.parent/'team-inverse-compiled-call-plan';C=P/'runtime-controls';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
for name,key in [('preregistration.json','initialInputs'),('source-freeze-input-pins.json','inputs')]:
 for pin in load(D/name)[key]:assert sha(Path(pin['path']))==pin['sha256']
# Import defines data-only functions; main guard prevents any host/native action.
def module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
controls=module('static_controls',C/'run.py');abi=module('static_abi',P/'abi-wrapper.py');reg=load(C/'preregistration.json');cases=load(P/'cases.json');binding=load(P/'runtime-procedure/actual-admission-binding.json');records=load(P/'compiled-images/observer/records.json');images=load(P/'compiled-images/images.json');fuels=load(P/'schedule.json')['fuels'];assert len(fuels)==14 and len(reg['mutants'])==8
for p,h in reg['inputPins'].items():assert sha(Path(p))==h
assert load(P/'runtime-procedure/results/full-terminal.json')['status']=='PASS168pairs';attempt=load(P/'runtime-procedure/results/attempts.json');assert len(attempt['guestInvocations'])==336 and len(attempt['hostBuilds'])==9
coupling=[]
for caseid in [0,2,6,10]:
 e=cases[caseid];entry=images['candidate'][e['symbol']]['offset'];raw=(P/'compiled-images/candidate'/(e['symbol']+'.bin')).read_bytes();b,offset=controls.append_coupling(raw,entry,e['args'],e['expectedResultU64']);assert offset==len(raw)and b[:len(raw)]==raw
 words=list(struct.unpack('<%dI'%((len(b)-len(raw))//4),b[len(raw):]));assert len(words)==30 and words[0]==0xa9bf7bfd and words[-4:]==[0xeb10001f,0x9a9f07e0,0xa8c17bfd,0xd65f03c0]
 def val(group,reg):
  assert len(group)==4 and group[0]&0xffe0001f==0xd2800000|reg
  out=(group[0]>>5)&65535
  for k in[1,2,3]:assert group[k]&0xffe0001f==(0xf2800000|(k<<21)|reg);out|=((group[k]>>5)&65535)<<(16*k)
  return out
 for j in range(5):assert val(words[1+4*j:5+4*j],j)==(e['args'][j]&((1<<64)-1))
 assert val(words[22:26],16)==e['expectedResultU64']
 disp=words[21]&0x3ffffff;disp=disp-(1<<26)if disp&(1<<25)else disp;assert words[21]&0xfc000000==0x94000000 and (len(raw)//4+21+disp)*4==entry
 coupling.append({'case':caseid,'symbol':e['symbol'],'prefixExactBytes':len(raw),'appendedWords':30,'entryOffset':offset,'BLWordOffset':offset+84,'full64Expected':e['expectedResultU64'],'stack':'STP29/30 preindexSP-16; LDP29/30 postindexSP+16; aligned; LR restored','output':'CMPx0,x16 full64; CSETx0,NE thenRET. Loader sees0/1 low8, not rawresult normalization by low8 alone','x7':'untouched by shim; compiledprefix CTXsave preserved; no x7 use afterreturn except originalguest'}})
raw=(P/'compiled-images/candidate/call-live.bin').read_bytes();entry=images['candidate']['call-live']['offset'];sent,o=abi.append_sentinels(raw,entry);poison,po=abi.append_sentinels(raw,entry,True);sw=list(struct.unpack('<%dI'%((len(sent)-len(raw))//4),sent[len(raw):]));pw=list(struct.unpack('<%dI'%((len(poison)-len(raw))//4),poison[len(raw):]));assert sent[:len(raw)]==poison[:len(raw)]==raw and o==po==len(raw)and sw[0]==0xd10183ff and sw[-2:]==[0x910183ff,0xd65f03c0]
# Decode save/restore/check bank bindings; x29/x30 are saved/restored, not sentinel-compared.
for j in range(5):
 for op,word in [(0xa9000000,sw[1+j]),(0xa9400000,sw[-8+j])]:assert word&0xffc00000==op and word&31==19+2*j and(word>>10)&31==20+2*j and(word>>5)&31==31 and(word>>15)&127==2*j
assert sw[6]==0xa9057bfd and sw[-3]==0xa9457bfd
for j,r in enumerate(range(19,29)):assert sw[7+j]==0xd2800000|((700+r)<<5)|r
assert pw[18]==0xd2800013 # actual one x19zero afterBL; shifts all latercode one word.
mutants=[]
for f in reg['mutants']:
 e=cases[f['case']];assert e['symbol']==f['symbol'];raw=(P/'compiled-images/candidate'/(f['symbol']+'.bin')).read_bytes();site=next(s for s in binding['wrappers']if s['symbol']==f['symbol']);post=site['post'];core=next(x['fields']for x in records if x['tag']=='RFCORE'and x['fields'][4]==post[1]);name=f['id']
 if name=='callee-saved-clobber':mutants.append({'id':name,'case':f['case'],'sourceNativePrefixExact':True,'mutation':'afterBL x19zero in appendedsentinelwrapper','expectedDetectedReturn':0xbeefdead});continue
 ix,old,new={'pack-wrong-lane':(post[3]+2,0x4e0c1c80,0x4e0c1c40),'AESD-to-AESE':(post[3]+5,0x4e285820,0x4e284820),'AESIMC-to-AESMC':(post[3]+6,0x4e287800,0x4e286800),'truncate-key':(post[3]+8,0xca050200,0x4a050200),'truncate-mode':(post[1],0xb5000160,0x35000160),'missing-first-slow-publication':(core[3]+4,0xf90004f0,0xd503201f),'wrong-context-store':(core[0]+4,0xf90004f0,0xf9000510)}[name]
 assert struct.unpack_from('<I',raw,(ix-1)*4)[0]==old;b=controls.patch_word(raw,ix,old,new);assert b[:(ix-1)*4]==raw[:(ix-1)*4]and b[ix*4:]==raw[ix*4:]
 mutants.append({'id':name,'case':f['case'],'fuel':f['fuel'],'oneBasedIndex':ix,'byteOffset':(ix-1)*4,'old':hex(old),'new':hex(new),'exactOneWordChange':True,'registerBase':{'old':(old>>5)&31,'new':(new>>5)&31}if name=='wrong-context-store'else None})
text=(C/'run.py').read_text();assert "detected=out!=expected"in text and"assert all(x['detected'] for x in results['mutants'])"in text and"No retries/case search"in text;assert reg['overallGuestCap']==376 and reg['newHostCBuilds']==14 and reg['additionalGuestInvocations']==40
report={'status':'PASS STATIC GO for fixed40 control guest plan only','actualSourceSHA256':sha(C/'run.py'),'additionalGuests':40,'additionalBuilds':14,'original376Cap':True,'coupling':coupling,'ABI':'28 guests case10 over14existingfuelvalues ×default/candidate; x19..28 sentinels700+r,96B aligned frame,saved29/30, actualcompilerprefix unchanged. Checks returned integer and bank, not allSIMD/registers or generic publicABI.','actualLiveKey':'x19 capturedMOVx5,x19; EORx9,x9,x19 sourceconsumer actualbound separately','mutations':mutants,'fixedOutcomePolicy':'one fixedcase per mutation; retain nonproductive and fail gate, no retries/search. Wrongcontext[x8] actualfault/productivity not assumed.','wrongSTRBoundary':'Final supervised stdout/stderr/status/result/fuel comparison only, not asynchronousstoretrace/cycleequivalence','reviewerNativeSolverNetworkTiming':0,'remaining':'Owner actual14build/40guest execution and frozenretainedreceipt review pending; no runtimePASS yet'}
(D/'static-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in['coupling','mutations']},indent=2))
