from pathlib import Path
import json,re,hashlib,difflib,shutil
D=Path(__file__).resolve().parent;P=D.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reg=json.loads((D/'preregistration.json').read_text())
for n,pin in reg['inputPins'].items():assert sha(Path(n))==pin['sha256'],n
original=P/'team-inverse-native-images/continuation/sources/nettle-aes.kotoba';s=original.read_text();first=s.splitlines()[0]
assert first=='(ns embench.nettle-aes-full (:export [batch stage-cell test-nettle-aes]))'
newfirst='(ns embench.nettle-aes-full (:export [batch stage-cell test-nettle-aes call-forward call-inverse call-mode call-live]))'
wrappers='''
;; One-off diagnostic wrappers. Original functions and literals above unchanged.
;; Non-tail consumers retain a compiler-produced closed CALL; observer must prove it.
(defn call-forward [a :i64 b :i64 c :i64 d :i64 key :i64] :i64
  (bit-xor (table-round 0 a b c d key) 17))
(defn call-inverse [a :i64 b :i64 c :i64 d :i64 key :i64] :i64
  (bit-xor (table-round 1 a b c d key) 17))
(defn call-mode [mode :i64 a :i64 b :i64 c :i64 key :i64] :i64
  (bit-xor (table-round mode a b c -1 key) 17))
(defn call-live [a :i64 b :i64 c :i64 d :i64 key :i64] :i64
  (+ (bit-xor (table-round 1 a b c d key) key) 1))
'''
n=s.replace(first,newfirst,1)+wrappers;(D/'source.kotoba').write_text(n)
(D/'source.diff').write_text(''.join(difflib.unified_diff(s.splitlines(True),n.splitlines(True),fromfile=str(original),tofile='owned typed calibration')))
assert n.replace(newfirst,first,1)[:-len(wrappers)]==s
shutil.copy2(P/'native-controls/diagnostic-loader.c',D/'diagnostic-loader.c')
shutil.copy2(P/'native-controls/reporter-contract.json',D/'reporter-contract.json')
arrays={}
for kind in ['enc','dec']:
 arrays[kind]=[]
 for role in range(4):
  a=[]
  for half in range(2):
   m=re.search(r'\(def '+kind+r'-t'+str(role)+'-'+str(half)+r' \[([^\]]*)\]\)',s);assert m
   v=[int(x) for x in m[1].split()];assert len(v)==128 and all(0<=x<2**32 for x in v);a+=v
  arrays[kind].append(a)
MASK=2**64-1
cases=[
 ('f-zero','call-forward',[0,0,0,0,0]),
 ('f-high','call-forward',[-2**63,2**63-1,-1,0x87654321,-2**63]),
 ('i-zero','call-inverse',[0,0,0,0,0]),
 ('i-pattern','call-inverse',[0x01234567,0x89abcdef,0xfedcba98,0x76543210,0x123456789abcdef0]),
 ('i-high','call-inverse',[-2**63,2**63-1,-1,0x0100000000000000,-2**63]),
 ('i-allones','call-inverse',[-1,-1,-1,-1,-1]),
 ('m-zero','call-mode',[0,0x12345678,-1,-2**63,2**63-1]),
 ('m-one','call-mode',[1,0x12345678,-1,-2**63,2**63-1]),
 ('m-highword','call-mode',[2**32,0x12345678,-1,-2**63,2**63-1]),
 ('m-negative','call-mode',[-1,0x12345678,-1,-2**63,-2**63]),
 ('l-pattern','call-live',[0x01234567,0x89abcdef,0xfedcba98,0x76543210,0x123456789abcdef0]),
 ('l-high','call-live',[-1,-2**63,2**63-1,0x0100000000000000,-2**63])]
rows=[]
for ix,(name,sym,args) in enumerate(cases):
 if sym=='call-mode':mode,a,b,c,key=args;d=-1
 else:a,b,c,d,key=args;mode=0 if sym=='call-forward' else 1
 vals=[a,b,c,d];indices=[((v&MASK)>>(8*r))&255 for r,v in enumerate(vals)]
 table=arrays['enc' if mode==0 else 'dec'];raw=(key&MASK)
 for r,index in enumerate(indices):raw^=table[r][index]
 expected=(((raw^(key&MASK))+1)&MASK) if sym=='call-live' else (raw^17)
 rows.append({'id':ix,'tag':name,'symbol':sym,'args':args,'mode':mode,'state':[a,b,c,d],'key':key,'tableIndices':indices,'expectedRawRoundU64':raw,'expectedResultU64':expected,'oracle':'exact pinned original table literals + original table-round/xor5 + unchanged wrapper consumer; not hardware formula or guest execution'})
(D/'cases.json').write_text(json.dumps(rows,indent=2)+'\n')
fuels=list(range(10))+[2**32-1,2**63-1,2**63,2**64-1]
schedule=[{'case':e['id'],'fuel':f,'preflight':False} for e in rows for f in fuels]
# Preflight consumes existing rows once; does not add calls or permit outcome retry.
pre=[]
for sym in ['call-forward','call-inverse','call-mode','call-live']:
 e=next(e for e in rows if e['symbol']==sym)
 x=next(x for x in schedule if x['case']==e['id'] and x['fuel']==2**64-1);schedule.remove(x);x['preflight']=True;pre.append(x)
(D/'schedule.json').write_text(json.dumps({'pairs':pre+schedule,'fuels':fuels,'pairCount':168,'preflightSubsetCount':4,'preflightActualAdmissionRequired':True},indent=2)+'\n')
# Standard C source-literal reference. Authoring only: no compile or execution.
c='#include <stdint.h>\n#include <inttypes.h>\n#include <stdio.h>\n#include <stdlib.h>\n'
for kind in ['enc','dec']:
 c+='static const uint32_t '+kind+'[4][256] = {\n'+',\n'.join('{'+','.join(str(v)+'U' for v in a)+'}' for a in arrays[kind])+'};\n'
c+='''static uint64_t source_round(uint64_t mode,uint64_t a,uint64_t b,uint64_t c,uint64_t d,uint64_t key){
 const uint32_t (*t)[256]=mode==0?enc:dec;
 return key^t[0][a&255]^t[1][(b>>8)&255]^t[2][(c>>16)&255]^t[3][(d>>24)&255];
}
struct testcase { uint64_t mode,a,b,c,d,key,expected; unsigned live; };
static const struct testcase cases[]={\n'''
for e in rows:
 values=[e['mode'],*e['state'],e['key'],e['expectedResultU64']]
 c+='{'+','.join('UINT64_C('+str(v&MASK)+')' for v in values)+','+str(int(e['symbol']=='call-live'))+'},\n'
c+='''};
int main(int argc,char **argv){
 if(argc!=2)return 2; char *end; unsigned long i=strtoul(argv[1],&end,10);
 if(*end||i>=sizeof(cases)/sizeof(cases[0]))return 2;
 const struct testcase *t=&cases[i]; uint64_t x=source_round(t->mode,t->a,t->b,t->c,t->d,t->key);
 x=t->live?((x^t->key)+UINT64_C(1)):(x^UINT64_C(17));
 printf("ORACLE case=%lu result=%" PRIu64 " expected=%" PRIu64 "\\n",i,x,t->expected);
 return x==t->expected?0:1;
}
'''
(D/'source-oracle.c').write_text(c)
(D/'source-oracle-provenance.json').write_text(json.dumps({'sourceOrigin':str(original),'sourceSHA256':sha(original),'literalWordsCopied':2048,'literalWordRange':'zeroextendedu32','arithmetic':'unsignedu64 key xor original four source tables; wrapper xor17 or xororiginalkey+1 mod2^64','originalBodyReverseExact':True,'compilerOracle':'inverse-off compiler generates original generic nonzero table-round calls; independent C reference supplements and never substitutes compiler execution','full64DynamicModeScope':'call-mode has five exported inputs; state d fixed-1. call-inverse/forward take arbitrary d and full64 key with fixedmode1/0. No claimed arbitrary six-arg public wrapper.'},indent=2)+'\n')
print('AUTHORED source',sha(D/'source.kotoba'),'cases',len(rows),'pairs',len(schedule)+4)
