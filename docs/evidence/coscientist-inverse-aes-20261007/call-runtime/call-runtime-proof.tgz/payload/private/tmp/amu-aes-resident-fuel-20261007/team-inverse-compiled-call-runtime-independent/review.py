from pathlib import Path
import json,hashlib,re,functools
D=Path(__file__).parent;W=D.parent;P=W/'team-inverse-compiled-call-plan';R=P/'runtime-procedure/results';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());MASK=(1<<64)-1
for file in ['preregistration.json','terminal-output-input-pins.json']:
 for r in load(D/file)['inputs']:assert sha(Path(r['path']))==r['sha256']and Path(r['path']).stat().st_size==r['bytes']
root=load(W/'root/inverse-compiled-call-runtime-result.json');assert len(root['pins'])==386
for n,h in root['pins'].items():assert sha(R/n)==h['sha256']and(R/n).stat().st_size==h['bytes']
cases=load(P/'cases.json');schedule=load(P/'schedule.json')['pairs'];pairs=load(R/'pairs.json');attempt=load(R/'attempts.json');assert len(cases)==12 and len(schedule)==len(pairs)==168 and len(attempt['guestInvocations'])==336 and len(attempt['hostBuilds'])==9
src=(P/'source.kotoba').read_text();read=lambda n:sum([list(map(int,re.search(r'\(def '+n+'-'+str(k)+r' \[([^]]+)\]',src)[1].split()))for k in range(2)],[]);tables={kind:[read(kind+'-t'+str(k))for k in range(4)]for kind in ['enc','dec']}
expected={}
for c in cases:
 args=c['args'];symbol=c['symbol']
 if symbol=='call-mode':mode,a,b,cw,key=args;state=[a,b,cw,-1]
 else:a,b,cw,d,key=args;state=[a,b,cw,d];mode=0 if symbol=='call-forward'else 1
 assert c['mode']==mode and c['state']==state and c['key']==key
 idx=[((state[k]&MASK)>>(8*k))&255 for k in range(4)];assert idx==c['tableIndices'];t=tables['enc'if mode==0 else'dec'];value=(key&MASK)^functools.reduce(int.__xor__,[t[k][idx[k]]for k in range(4)]);result=(((value^(key&MASK))+1)&MASK)if symbol=='call-live'else value^17
 assert value==c['expectedRawRoundU64']and result==c['expectedResultU64'];expected[c['id']]=result
# Header fullbytes/offset/required6 source and executed loader bindings.
images=load(P/'compiled-images/images.json');labels=set()
for build in attempt['hostBuilds']:
 assert build['state']=='terminal'and build['returncode']==0 and build['label']not in labels;labels.add(build['label']);q=R/build['label'];assert(q/'build.stderr').read_text()==''
 if build['label']=='source-oracle':assert build['argv']==['clang','-O2','-std=c11',str(P/'source-oracle.c'),'-o',str(q/'oracle')];continue
 profile,symbol=build['label'].split('/');blob=(P/'compiled-images'/profile/(symbol+'.bin')).read_bytes();assert(q/'image.bin').read_bytes()==blob;header=(q/'embedded.h').read_text();assert sha(q/'embedded.h')==build['headerSHA256']and sha(q/'loader')==build['binarySHA256']and sha(P/'diagnostic-loader.c')==build['sourceSHA256'];assert build['argv']==['clang','-O2','-std=c11','-include',str(q/'embedded.h'),str(P/'diagnostic-loader.c'),'-o',str(q/'loader')]
 literal=re.search(r'static const unsigned char kexe_embedded_code\[\] = \{([^}]+)\};',header)[1];assert bytes(map(int,literal.split(',')))==blob
 for name,value in [('REQUIRED_HOST_FEATURES','6ULL'),('OFFSET',str(images[profile][symbol]['offset'])+'u'),('ARITY','0u'),('ISA','"aarch64"')]:assert f'#define KEXE_EMBEDDED_{name} {value}\n'in header
 assert '#define KEXE_EMBEDDED 1\n'in header and'KEXE_HOST_GATE_TEST'not in header
seen=set();trap=0;zero_remaining_completed=0
for j,(spec,pair)in enumerate(zip(schedule,pairs)):
 assert pair['case']==spec['case']and pair['fuel']==spec['fuel'];c=cases[spec['case']];fuel=spec['fuel'];base=pair['baseline'];cand=pair['candidate'];assert base==cand;assert not cand.get('timeout',False)
 for profile,receipt in [('default',base),('candidate',cand)]:
  event=attempt['guestInvocations'][2*j+(profile=='candidate')];label=profile+'/'+c['symbol'];tag='case'+str(c['id'])+'-fuel'+str(fuel);assert event['label']==label and event['tag']==tag and event['args']==c['args']and event['fuel']==fuel and event['state']=='terminal'and(label,tag)not in seen;seen.add((label,tag));p=R/label/(tag+'.json');assert load(p)==receipt and sha(p)==event['receiptSHA256']
 text=cand['stdout'];initial=int(re.search(r':initial (\d+)',text)[1]);remaining=int(re.search(r':remaining (\d+)',text)[1]);assert initial==fuel
 if fuel>=7:
  assert cand['exit']==0 and':status :ok'in text and cand['stderr']=='';assert(int(re.search(r':result (-?\d+)',text)[1])&MASK)==expected[c['id']]and remaining==fuel-7
  if remaining==0:zero_remaining_completed+=1
 else:
  assert cand['exit']==120 and':status :trap'in text and remaining==0 and cand['stderr']=='KEXE_TRAP {:kind :signal :signal :SIGTRAP}\nKEXE_TRAP {:kind :budget :reason :budget/fuel}\n';trap+=1
 for name,cap in [('heap',1048576),('string-pool',16777216),('vectors',131072),('vector-items',4194304)]:assert f':{name} {{:capacity {cap} :used 0}}'in text
oracle=load(R/'oracle-receipts.json');assert len(oracle)==12
for row in oracle:assert row['exit']==0 and row['stderr']==''and row['stdout']==f"ORACLE case={row['case']} result={expected[row['case']]} expected={expected[row['case']]}\n"
# Immutable source gate/ctx versus reviewed original. Scope is this owned diagnostic loader only.
loader=(P/'diagnostic-loader.c').read_text();frozen=Path('/private/tmp/amu-embedded-host-feature-gate-20261007/host-feature-loader.c').read_text();gate=lambda s:s[s.index('/* Experimental embedded-only immutable host-feature contract.'):s.index('int main(int argc, char **argv)')];assert gate(loader)==gate(frozen)
ctx=lambda s:re.search(r'struct kexe_context_v11 \{.*?\n\};',s,re.S)[0];assert ctx(loader)==ctx(frozen)
main=loader.index('int main(int argc, char **argv)');early=loader.index('if(!kexe_embedded_host_gate(KEXE_EMBEDDED_ISA))return 2;',main);assert early<loader.index('kexe_decisions_init();',main)<loader.index('HG_STAGE("RX")',main)<loader.index('pid_t child = fork();',main)<loader.index('HG_STAGE("ENTRY")',main)
assert loader.index('shared->context.fuel=f;',main)<loader.index('pid_t child = fork();',main)
report={'status':'PASS independent retained168pair observable runtime review only','pinnedRootResultFiles':386,'pairs':168,'guestReceipts':336,'COracleReceipts':12,'hostBuilds':9,'nativeRunsByReviewer':0,'sourceCasesDirectTableExpected':12,'exactFullHeaderBlobOffsetsRequiredMask6':8,'rawBaselineCandidateStatusErrorResultEqual':True,'semanticFuelCost':7,'trapPairsFuelBelow7':trap,'completedFuel7Remaining0Pairs':zero_remaining_completed,'finalReportedPoolUsedZero':True,'allAttemptsTerminalNoDuplicateRetry':True,'initialRuntimeFailures':0,'sourceEarlyInternalCPUDetectionGateExact':True,'diagnosticContextStructExact':True,'featureProvenance':'Each normal built loader executes reviewed early internal sysctl AES gate per process; successful execution binds passed source gate. No new external CPU query performed by reviewer, no raw sysctl1 printed by these loaders.','limits':['Reported stdout/stderr/status/fuel/pool counters exactly compared; NOT unreported fullM/arena byte contents or asynchronous publication timing','Parent-only diagnosticargs/rawu64fuel beyond packaged budget, embeddedarity0 entry; not public packagedargument admission','No independent dynamic ABI/sentinel/source-mutant/coupling proof in this runtime stage','No native/solver/network/timing/product edits by reviewer','No wholecandidate/product/performance qualification inferred']}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
