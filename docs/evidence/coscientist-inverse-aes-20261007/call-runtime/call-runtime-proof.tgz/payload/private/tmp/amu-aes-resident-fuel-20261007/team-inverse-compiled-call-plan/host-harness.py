"""Prepared evidence host helper. Import defines functions only; no compile/run.
Root must authorize each later finite run phase explicitly. Original diagnostic
loader is copied byte-exact; no new compiler or guest interpreter is introduced.
"""
from pathlib import Path
import subprocess,json,os,hashlib
D=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
class ScopedHost:
 def __init__(self,authorization,output):
  auth=json.loads(Path(authorization).read_text())
  assert auth.get('allowCompiledCallNative') is True
  assert auth['preregistrationSHA256']==sha(D/'preregistration.json')
  assert auth['fixtureSHA256']==sha(D/'source.kotoba')
  assert auth['actualAdmissionReviewPASS'] is True
  assert auth['hostBuildCap']==32 and auth['guestInvocationCap']==376
  self.output=Path(output);assert not self.output.exists();self.output.mkdir();self.builds=[];self.runs=[]
  (self.output/'authorization.json').write_text(json.dumps(auth,indent=2)+'\n')
 def build(self,label,blob,offset,frozen_source=None,fuel=1048576):
  assert len(self.builds)<32 and 0<=offset<len(blob) and offset%4==0
  p=self.output/label;p.mkdir(parents=True,exist_ok=False);(p/'image.bin').write_bytes(blob)
  # Same frozen feature gate + required6 contract. Args/fuel are initialized
  # only before fork by existing reviewed reporter; parent never resumes writer.
  source=Path(frozen_source) if frozen_source else D/'diagnostic-loader.c'
  vals={'REQUIRED_HOST_FEATURES':'6ULL','OFFSET':str(offset)+'u','ARITY':'0u','ISA':'"aarch64"','ALLOW':'"-"','SCOPE35':'""','SCOPE34':'""','SPAWN_PROGRAMS':'""','SPAWN_ENV':'""','SPAWN_PATH_LOOKUP':'0','STRING_POOL':'16777216u','FUEL':str(fuel)+'u','PAIRS':'1048576u','VECTORS':'131072u','VECTOR_ITEMS':'4194304u','CPU_SECONDS':'15u','WALL_SECONDS':'20u'}
  header='#define KEXE_EMBEDDED 1\n'+''.join('#define KEXE_EMBEDDED_'+k+' '+v+'\n' for k,v in vals.items())+'static const unsigned char kexe_embedded_code[] = {'+','.join(map(str,blob))+'};\n';(p/'embedded.h').write_text(header)
  cmd=['clang','-O2','-std=c11','-include',str(p/'embedded.h'),str(source),'-o',str(p/'loader')]
  row={'label':label,'argv':cmd,'sourceSHA256':sha(source),'headerSHA256':sha(p/'embedded.h'),'state':'started'};self.builds.append(row);self.save()
  q=subprocess.run(cmd,capture_output=True,timeout=1800);(p/'build.stdout').write_bytes(q.stdout);(p/'build.stderr').write_bytes(q.stderr);row.update(state='terminal',returncode=q.returncode);self.save()
  assert q.returncode==0,(label,q.stderr[-1000:]);row['binarySHA256']=sha(p/'loader');self.save();return p
 def capture(self,label,tag,args,fuel):
  assert len(args)<=5 and len(self.runs)<376
  p=self.output/label;assert not (p/(tag+'.json')).exists()
  env=dict(os.environ,KEXE_STRUCTURED_REPORT='1',DIAG_FUEL=str(fuel));env.update({'DIAG_ARG'+str(i):str(v) for i,v in enumerate(args)})
  row={'label':label,'tag':tag,'args':args,'fuel':fuel,'state':'started'};self.runs.append(row);self.save()
  # Retain any abnormal exit/trap as evidence; caller evaluates intended oracle.
  try:
   q=subprocess.run([str(p/'loader')],env=env,capture_output=True,timeout=30);out={'exit':q.returncode,'stdout':q.stdout.decode(errors='replace'),'stderr':q.stderr.decode(errors='replace')}
  except subprocess.TimeoutExpired as e:
   out={'exit':None,'timeout':True,'stdout':(e.stdout or b'').decode(errors='replace'),'stderr':(e.stderr or b'').decode(errors='replace')}
  (p/(tag+'.json')).write_text(json.dumps(out,indent=2)+'\n');row.update(state='terminal',receiptSHA256=sha(p/(tag+'.json')));self.save();return out
 def save(self):
  (self.output/'attempts.json').write_text(json.dumps({'hostBuilds':self.builds,'guestInvocations':self.runs},indent=2)+'\n')
if __name__=='__main__':raise SystemExit('Prepared helpers only. No implicit build/native execution. Root phase runner must supply authorization.')
