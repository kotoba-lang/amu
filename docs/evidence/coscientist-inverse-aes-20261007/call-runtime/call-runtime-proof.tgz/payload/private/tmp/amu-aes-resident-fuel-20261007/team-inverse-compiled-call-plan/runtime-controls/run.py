"""Later root-authorized isolated ABI/coupling/mutant orchestration only."""
from pathlib import Path
import json,hashlib,importlib.util,struct,sys,traceback,re
C=Path(__file__).resolve().parent;D=C.parent;W=C/'results';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def module(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
host=module('host_controls',D/'host-harness.py');abi=module('abi_controls',D/'abi-wrapper.py');check=module('check_controls',D/'check-results.py')
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def append_coupling(raw,entry,args,expected):
 assert len(raw)%4==0 and entry%4==0 and len(args)==5
 words=[0xa9bf7bfd] # saved LR/SP; original callee is nonleaf
 def imm64(reg,value):
  value&=(1<<64)-1
  return [0xd2800000|((value&65535)<<5)|reg]+[0xf2800000|(k<<21)|(((value>>(16*k))&65535)<<5)|reg for k in range(1,4)]
 for reg,val in enumerate(args):words+=imm64(reg,val)
 pos=len(raw)//4+len(words);words.append(0x94000000|((entry//4-pos)&0x3ffffff))
 words+=imm64(16,expected);words+=[0xeb10001f,0x9a9f07e0,0xa8c17bfd,0xd65f03c0]
 # Full64 compare before command loader truncates exit. 0 match /1 mismatch.
 return raw+b''.join(struct.pack('<I',v) for v in words),len(raw)
def patch_word(raw,index,old,new):
 at=(index-1)*4;assert at>=0 and at+4<=len(raw)
 assert struct.unpack_from('<I',raw,at)[0]==old,(index,old)
 return raw[:at]+struct.pack('<I',new)+raw[at+4:]
def main():
 if len(sys.argv)!=2:raise SystemExit('run.py ROOT_CONTROLS_AUTHORIZATION.json; no implicit execution')
 auth=json.loads(Path(sys.argv[1]).read_text());assert auth['allowCompiledCallNative'] is True and auth['actualAdmissionReviewPASS'] is True
 assert auth['runtimeControlsSHA256']==sha(Path(__file__)) and auth['controlsPreregistrationSHA256']==sha(C/'preregistration.json')
 assert auth['additionalGuestInvocationCap']==40 and auth['additionalHostBuildCap']==14
 reg=json.loads((C/'preregistration.json').read_text())
 for path,h in reg['inputPins'].items():assert sha(Path(path))==h,path
 N=D/'runtime-procedure/results';assert json.loads((N/'full-terminal.json').read_text())['status']=='PASS168pairs'
 initial=json.loads((N/'attempts.json').read_text());assert len(initial['guestInvocations'])==336 and len(initial['hostBuilds'])==9
 H=host.ScopedHost(sys.argv[1],W);save(W/'normalFrozenOrigin.json',{'path':str(N),'attemptsSHA256':sha(N/'attempts.json'),'pairsSHA256':sha(N/'pairs.json'),'fullTerminalSHA256':sha(N/'full-terminal.json')})
 cases=json.loads((D/'cases.json').read_text());images=json.loads((D/'compiled-images/images.json').read_text());fuels=json.loads((D/'schedule.json').read_text())['fuels'];normal=json.loads((N/'pairs.json').read_text());binding=json.loads((D/'runtime-procedure/actual-admission-binding.json').read_text());records=json.loads((D/'compiled-images/observer/records.json').read_text());results={'abi':[],'coupling':[],'mutants':[]}
 def blob(profile,symbol):
  p=D/'compiled-images'/profile/(symbol+'.bin');assert sha(p)==images[profile][symbol]['nativeSHA256'];return p.read_bytes(),images[profile][symbol]['offset']
 try:
  e=cases[10];assert e['symbol']=='call-live'
  for profile in ['default','candidate']:
   raw,off=blob(profile,e['symbol']);b,o=abi.append_sentinels(raw,off);H.build('abi/'+profile,b,o)
  for f in fuels:
   out=[H.capture('abi/'+profile,'fuel'+str(f),e['args'],f) for profile in ['default','candidate']]
   results['abi'].append({'case':10,'fuel':f,'baseline':out[0],'candidate':out[1]});save(W/'results.json',results);check.compare(e,f,*out)
  frozen=Path('/private/tmp/amu-embedded-host-feature-gate-20261007/host-feature-loader.c')
  for caseid in [0,2,6,10]:
   e=cases[caseid];raw,off=blob('candidate',e['symbol']);b,o=append_coupling(raw,off,e['args'],e['expectedResultU64']);H.build('coupling/'+e['symbol'],b,o,frozen_source=frozen)
   out=H.capture('coupling/'+e['symbol'],'one-call',[],1048576);results['coupling'].append({'case':caseid,'expectedFull64':e['expectedResultU64'],'normalization':'full64CMP thenCSET beforeexittruncation','outcome':out});save(W/'results.json',results)
   assert out['exit']==0 and ':status :ok' in out['stdout'] and ':result 0' in out['stdout'] and ':remaining 1048569' in out['stdout'] and not out['stderr'],out
  for fault in reg['mutants']:
   e=cases[fault['case']];raw,off=blob('candidate',fault['symbol']);site=next(x for x in binding['wrappers'] if x['symbol']==fault['symbol']);post=site['post'];core=next(x['fields'] for x in records if x['tag']=='RFCORE' and x['fields'][4]==post[1]);name=fault['id'];change={}
   if name=='callee-saved-clobber':b,o=abi.append_sentinels(raw,off,True);change={'postcallSentinelX19Clobber':True}
   else:
    o=off
    if name=='pack-wrong-lane':ix=post[3]+2;old=0x4e0c1c80;new=0x4e0c1c40
    elif name=='AESD-to-AESE':ix=post[3]+5;old=0x4e285820;new=0x4e284820
    elif name=='AESIMC-to-AESMC':ix=post[3]+6;old=0x4e287800;new=0x4e286800
    elif name=='truncate-key':ix=post[3]+8;old=0xca050200;new=0x4a050200
    elif name=='truncate-mode':ix=post[1];old=0xb5000160;new=0x35000160
    elif name=='missing-first-slow-publication':ix=core[3]+4;old=0xf90004f0;new=0xd503201f
    elif name=='wrong-context-store':ix=core[0]+4;old=0xf90004f0;new=0xf9000510
    else:raise AssertionError(name)
    b=patch_word(raw,ix,old,new);change={'oneBasedCodeIndex':ix,'byteOffset':(ix-1)*4,'originalWord':hex(old),'mutantWord':hex(new)}
   H.build('mutants/'+name,b,o);out=H.capture('mutants/'+name,'one-case',e['args'],fault['fuel']);expected=next(x['candidate'] for x in normal if x['case']==e['id'] and x['fuel']==fault['fuel'])
   detected=out!=expected
   if name=='callee-saved-clobber':detected=detected and re.search(r':result 3203391149\b',out['stdout']) is not None
   results['mutants'].append({'fault':fault,'change':change,'originalNativeSHA256':hashlib.sha256(raw).hexdigest(),'mutantNativeSHA256':hashlib.sha256(b).hexdigest(),'outcome':out,'normalOutcome':expected,'detected':detected});save(W/'results.json',results)
   # No retries/case search. Nonproductive controls retained and gate fails honestly.
  assert len(H.runs)==40 and len(H.builds)==14
  assert all(x['detected'] for x in results['mutants']),'at least one nonproductive control retained; no retry authorized'
  save(W/'report.json',{'status':'PASS finiteABI28/frozenloader4/fault8','guestInvocations':40,'hostBuilds':14,'normalPriorGuestInvocations':336,'overallGuestInvocations':376,'overallHostBuilds':23,'timing':0,'results':results,'trustBoundary':'Intentional copiedfaultimages diagnostic only; no productionadmission assertion; nativeprefix supervisorfinalstate plus boundRF46 not asyncstoretrace'})
 except BaseException as e:save(W/'failure.json',{'exception':repr(e),'traceback':traceback.format_exc(),'guestInvocations':len(H.runs),'hostBuilds':len(H.builds)});raise
 finally:save(W/'pins.json',{str(p.relative_to(W)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(W.rglob('*')) if p.is_file() and p.name not in ['pins.json','terminal.json']})
 save(W/'terminal.json',{'reportSHA256':sha(W/'report.json'),'pinsSHA256':sha(W/'pins.json'),'allWritesComplete':True})
if __name__=='__main__':main()
