"""Data-only A64 sentinel scaffold. Never invokes a compiler or guest."""
import struct
def append_sentinels(raw,entry_offset,clobber_control=False):
 assert len(raw)%4==0 and entry_offset%4==0 and 0<=entry_offset<len(raw)
 words=[0xd10183ff] # sub sp,sp,96; original stack alignment retained
 def stp(a,b,o):return 0xa9000000|((o//8)&127)<<15|(b<<10)|(31<<5)|a
 def ldp(a,b,o):return 0xa9400000|((o//8)&127)<<15|(b<<10)|(31<<5)|a
 for i in range(0,10,2):words.append(stp(19+i,20+i,i*8))
 words.append(stp(29,30,80))
 for r in range(19,29):words.append(0xd2800000|((700+r)<<5)|r)
 call=len(raw)//4+len(words);words.append(0x94000000|((entry_offset//4-call)&0x3ffffff))
 if clobber_control:words.append(0xd2800013)
 checks=[]
 for r in range(19,29):
  words.extend([0xd2800000|((700+r)<<5)|16,0xeb10001f|(r<<5)]);checks.append(len(words));words.append(0)
 jump=len(words);words.append(0);fail=len(words);words.extend([0xd2800000|(0xdead<<5),0xf2a00000|(0xbeef<<5)]);restore=len(words)
 for ix in checks:words[ix]=0x54000001|(((fail-ix)&0x7ffff)<<5)
 words[jump]=0x14000000|((restore-jump)&0x3ffffff)
 for i in range(0,10,2):words.append(ldp(19+i,20+i,i*8))
 words.extend([ldp(29,30,80),0x910183ff,0xd65f03c0])
 return raw+b''.join(struct.pack('<I',v) for v in words),len(raw)
