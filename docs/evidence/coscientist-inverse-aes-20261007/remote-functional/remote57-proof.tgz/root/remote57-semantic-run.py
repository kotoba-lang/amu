from pathlib import Path
import json,subprocess,hashlib
P=Path('/private/tmp/amu-aes-resident-fuel-20261007');E=P/'team-remote57-inverse-prep/sealed-envelope';W=P/'root/remote57-semantic-run-results'
s=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert s(E/'transport-and-authorizations.json')=='9fa15337cfd1ebafa63167b89b869b00df2d0d1857e395744bcbd1944c7e499e'
assert s(E/'remote57-package.tgz')=='d456ff754d42fd191d9a0584162d05e090b5041eccd815ad8731eb2b967aabe9'
t=json.loads((E/'transport-and-authorizations.json').read_text());assert not W.exists();W.mkdir();rows=[]
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
for label,timeout in [('semanticGOTransfer',180),('semantic57',1800)]:
 cmd=[str(P/'root/remote57-semantic-GO.json') if x=='ROOT_57_GO_LOCAL_JSON' else x for x in t['commands'][label]];row={'label':label,'argv':cmd,'state':'started'};rows.append(row);save(W/'attempts.json',rows)
 try:q=subprocess.run(cmd,capture_output=True,timeout=timeout);stdout,stderr,rc=q.stdout,q.stderr,q.returncode
 except subprocess.TimeoutExpired as e:stdout,stderr,rc=e.stdout or b'',e.stderr or b'',None
 (W/(label+'.stdout')).write_bytes(stdout);(W/(label+'.stderr')).write_bytes(stderr);row.update(state='terminal',returncode=rc);save(W/'attempts.json',rows);print(label,rc,flush=True);assert rc==0,(label,rc)
save(W/'report.json',{'status':'PASS semantic invocation only; inspect remote raw report','maximumRemoteGuestCalls':57,'timing':False});save(W/'pins.json',{p.name:{'sha256':s(p),'bytes':p.stat().st_size}for p in W.iterdir()if p.is_file()})
