"""One fresh singleBody campaign, one fresh admitted runners. No builds or retries."""
from pathlib import Path
import json,hashlib,subprocess,shutil,statistics,math
D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
go=json.loads((D/'ROOT-GO.json').read_text());pr=json.loads((D/'preregistration.json').read_text());bind=json.loads((D/'ROOT-CURRENT-INPUT-BINDING.json').read_text());P=Path(pr['remotePackage']);O=Path(pr['remoteOutput'])
assert str(D)==pr['remoteDriver'] and go['performanceAuthorized'] is True and go['maximumCampaigns']==1
assert go['preregistrationSHA256']==sha(D/'preregistration.json') and go['packageInputPinsSHA256']==sha(D/'package-input-pins.json') and go['currentInputBindingSHA256']==sha(D/'ROOT-CURRENT-INPUT-BINDING.json')
assert go['remoteSemanticReportSHA256']==sha(P/'semantic/report.json')==bind['semanticReportSHA256']
for n,h in json.loads((D/'package-input-pins.json').read_text()).items():assert sha(D/n)==h,n
for sub,k in [('', 'packagePins'),('built','builtPins'),('semantic','semanticPins')]:
 for n,h in bind[k].items():assert sha(P/sub/n)==h,(sub,n)
assert sha(P/'built/pins.json')==bind['builtPinsSHA256'] and sha(P/'semantic/pins.json')==bind['semanticPinsSHA256']
assert sha(P/'built/report.json')==bind['builtReportSHA256'];sr=json.loads((P/'semantic/report.json').read_text());assert sr['status']=='PASS3semantic only' and sr['calls']==3
assert not O.exists();O.mkdir();save(O/'root-GO.json',go);report={'status':'running ONE fresh AES-only','entries':[],'performanceCampaigns':1,'historicalStatisticsUsed':False,'noRetry':True};save(O/'campaign.json',report)
entries=json.loads((P/'built/report.json').read_text())['entries'];assert len(entries)==1
fixed=json.loads((D/'candidate-fixed-point.json').read_text());generations={str(g['generation']):g['sha256']for g in fixed['generations']};assert len(set(generations.values()))==1 and next(iter(generations.values()))==pr['candidateSeedSHA256']
for row in entries:
 name=row['workload'];src=P/name;out=O/name;out.mkdir();base=out/'baseline';(base/name).mkdir(parents=True);cand=out/'candidate';cand.mkdir()
 shutil.copy2(src/'baseline.bin',base/name/'native.bin');shutil.copy2(src/'c.dylib',base/name/'c.dylib');shutil.copy2(src/'candidate.bin',cand/'native.bin')
 save(base/'results.json',{'status':'prepared-current-input-descriptor','entries':[{'workload':name,'nativeSha256':row['baselineNativeSHA256'],'cDylibSha256':row['CbinarySHA256'],'offset':row['baselineOffset'],'cSymbol':row['Csymbol'],'iterationsPerCall':row['n']}],'runnerSha256':row['runnerSHA256'],'matrixSpecSha256':sha(D/'comparison-matrix.json'),'historicalStatisticsUsed':False})
 save(cand/'manifest.json',{'workload':name,'nativeSha256':row['candidateNativeSHA256'],'offset':row['candidateOffset'],'sourceSha256':row['sourceSHA256'],'baselineSourceSha256':row['sourceSHA256'],'compilerGenerationSha256':generations,'expectedFuelPerCall':row['expectedNativeFuelConsumed']})
 print('START',name,flush=True);cmd=['python3',str(D/'measure.py'),str(base),str(cand),str(P/'built'/name/'runner'),str(D/'paired-timing-spec.json'),str(out/'timing')]
 with (out/'measurement.log').open('w')as log:
  try:q=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=9000);rc=q.returncode
  except subprocess.TimeoutExpired:rc=None
 resultPath=out/'timing/results.json';result=json.loads(resultPath.read_text())if resultPath.exists()else{'status':'failed','failure':'Noresults; no restart'}
 report['entries'].append({'workload':name,'exit':rc,'status':result['status'],'acceptedTriples':result.get('acceptedTriples'),'attemptedTriples':result.get('attemptedTriples'),'summary':result.get('summary'),'failure':result.get('failure')});save(O/'campaign.json',report);print('FINISH',name,rc,flush=True)
report['status']='terminal ONE campaign AES-only attempted';complete=all(x['exit']==0 and x['acceptedTriples']==30 and x['summary']is not None for x in report['entries']);report['singleBodyComplete']=complete
if complete:
 report['descriptiveGeometricBaselineOverCandidate']=math.exp(statistics.mean(math.log(x['summary']['baselineOverCandidate'])for x in report['entries']))
 report['descriptiveGeometricCandidateOverC']=math.exp(statistics.mean(math.log(x['summary']['candidateOverC'])for x in report['entries']))
else:report['singleBodyAggregate']='NOT QUALIFIED incomplete; no fullaggregate'
save(O/'campaign.json',report);save(O/'pins.json',{str(p.relative_to(O)):sha(p)for p in O.rglob('*')if p.is_file()and p.name not in['pins.json','terminal.json']});save(O/'terminal.json',{'allWritesComplete':True,'campaignSHA256':sha(O/'campaign.json'),'pinsSHA256':sha(O/'pins.json'),'performanceCampaigns':1})
