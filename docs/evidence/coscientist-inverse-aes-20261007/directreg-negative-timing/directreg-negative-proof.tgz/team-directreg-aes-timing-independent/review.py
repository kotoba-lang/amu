from pathlib import Path
import json,hashlib,math,statistics
D=Path(__file__).parent;W=D.parent;P=W/'root/directreg-aes-timing-v2-results/results-v1';Prep=W/'root/directreg-aes-driver-v2/driver';E=W/'team-directreg-aes-remote-prep-v2/package';B=W/'root/directreg-aes-built-v2/built';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ld=lambda p:json.loads(p.read_text());close=lambda a,b:math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-8)
for p,h in ld(D/'preregistration.json')['inputs'].items():assert sha(Path(p))==h,p
pins=ld(P/'pins.json');assert sha(P/'pins.json')=='a47879537247eb49cb835886a335a4f977ab84e927e6310aea0a06727abef77d'
for n,h in pins.items():assert sha(P/n)==h,n
campaign=ld(P/'campaign.json');term=ld(P/'terminal.json');assert term['allWritesComplete'] and term['campaignSHA256']==sha(P/'campaign.json')=='d1e0869bc834fc1d3ecb837eea2c2c6430388810f475832c98bf4fbdc6826708' and term['pinsSHA256']==sha(P/'pins.json') and term['performanceCampaigns']==1
pr=ld(Prep/'preregistration.json');sp=ld(Prep/'paired-timing-spec.json');go=ld(P/'root-GO.json');assert go['performanceAuthorized'] and go['maximumCampaigns']==1
for key,path in [('preregistrationSHA256',Prep/'preregistration.json'),('packageInputPinsSHA256',Prep/'package-input-pins.json'),('currentInputBindingSHA256',Prep/'ROOT-CURRENT-INPUT-BINDING.json'),('remoteSemanticReportSHA256',W/'root/directreg-aes-semantic3-v2/semantic/report.json')]:assert go[key]==sha(path)
binding=ld(Prep/'ROOT-CURRENT-INPUT-BINDING.json')
for key,base,pin in [('packagePins',E,E/'package-input-pins.json'),('builtPins',B,B/'pins.json'),('semanticPins',W/'root/directreg-aes-semantic3-v2/semantic',W/'root/directreg-aes-semantic3-v2/semantic/pins.json')]:
 assert binding[key]==ld(pin)
 for n,h in binding[key].items():assert sha(base/n)==h,(key,n)
for n,h in ld(Prep/'package-input-pins.json').items():assert sha(Prep/n)==h,n
entries=ld(B/'report.json')['entries'];assert len(entries)==len(campaign['entries'])==1;allout=[];packetTotal=0;calTotal=0;attemptTotal=0;rejectTotal=0
remote=pr['remoteOutput'];remoteP=pr['remotePackage']
for entry,cr in zip(entries,campaign['entries']):
 name=entry['workload'];A=P/name;r=ld(A/'timing/results.json');assert name==cr['workload'] and cr['exit']==0 and r['status']=='complete-provisional-candidate-timing' and r['performanceMeasured'] and not r['officialEmbenchScore']
 assert r['host'].split('.')[0]==sp['host'] and r['specSha256']==sha(Prep/'paired-timing-spec.json') and r['runnerSha256']==sha(B/name/'runner')==entry['runnerSHA256']
 assert r['baselineResultsSha256']==sha(A/'baseline/results.json') and r['manifest']==ld(A/'candidate/manifest.json')
 for local,file,key in [(A/'baseline'/name/'native.bin','baseline.bin','baselineNativeSHA256'),(A/'candidate/native.bin','candidate.bin','candidateNativeSHA256'),(A/'baseline'/name/'c.dylib','c.dylib','CbinarySHA256')]:assert local.read_bytes()==(E/name/file).read_bytes() and sha(local)==entry[key]
 packets=r['samplePackets'];assert len(packets)<=285;packetTotal+=len(packets)
 def packetcheck(s,arm,capture):
  ix=s['rawPacketIndex'];p=packets[ix];assert p['index']==ix and p['arm']==arm and p['captureCPU']==capture and p['state']=='terminal' and p['exit']==0 and p['stderr']=='' and 'timeout'not in p
  raw=ldummy=json.loads(p['stdout']);assert all(s[k]==v for k,v in raw.items())
  assert raw['result']==1 and raw['calls']==p['calls'] and raw['warmupCalls']==1 and raw['elapsedNanoseconds']>0
  expected=0 if arm=='C' else entry['expectedNativeFuelConsumed'];assert raw['contextFuelConsumed']==expected and raw['contextFuelBefore']==16777216 and raw['contextFuelAfter']==16777216-expected and raw['fuelPerCall']==16777216
  paths={'baseline':('raw',remote+'/'+name+'/baseline/'+name+'/native.bin',str(entry['baselineOffset'])),'candidate':('raw',remote+'/'+name+'/candidate/native.bin',str(entry['candidateOffset'])),'C':('dylib',remote+'/'+name+'/baseline/'+name+'/c.dylib',entry['Csymbol'])};kind,path,symbol=paths[arm]
  assert raw['artifactKind']==kind and p['argv']==[remoteP+'/built/'+name+'/runner',kind,path,symbol,'aarch64',str(entry['n']),str(raw['calls']),'1','16777216']
  return ix
 seen=[]
 for arm in ['baseline','candidate','C']:
  cal=[s for s in r['calibrationRows']if s['arm']==arm];assert 1<=len(cal)<=5;calls=3
  for j,s in enumerate(cal):
   assert s['calibrationAttempt']==j and s['calls']==calls;seen.append(packetcheck(s,arm,False));elapsed=s['elapsedNanoseconds'];inside=sp['targetIntervalNs']*.75<=elapsed<=sp['targetIntervalNs']*1.5
   if j<len(cal)-1:assert not inside;calls=max(1,min(100000000,round(calls*sp['targetIntervalNs']/elapsed)))
   else:assert inside and calls==r['callsByArm'][arm]
  calTotal+=len(cal)
 rows=r['rows'];attempts=r['attemptedTriples'];assert len(rows)==3*attempts and 30<=attempts<=90;accepted=0
 for i in range(attempts):
  triple=rows[3*i:3*i+3];order=['baseline','candidate','C'];order=order[i%3:]+order[:i%3];assert [s['arm']for s in triple]==order
  for s in triple:
   arm=s['arm'];assert s['attempt']==i and s['calls']==r['callsByArm'][arm];seen.append(packetcheck(s,arm,True));c=s['cpuActivityEnvelope'];be=c['before'];af=c['after'];assert be['api']==af['api']=='host_processor_info/PROCESSOR_CPU_LOAD_INFO';assert be['processors']==af['processors']==c['logicalCpuCount']==10
   delta=[(y-x)&0xffffffff for x,y in zip(be['ticks'],af['ticks'])];assert delta==c['deltaTicks'] and sum(delta)>0;idle=100*delta[2]/sum(delta);env=af['monotonicNs']-be['monotonicNs'];assert env>0 and env==c['envelopeNs'] and close(idle,c['idlePercent'])
   child=c['childCpuNs'];assert type(child)==int and child>=0;share=100*child/(env*c['logicalCpuCount']);assert share<=100;background=min(100,idle+share);assert close(background,c['estimatedBackgroundIdlePercent'])
   reasons=[]
   if max(s['loadBefore'],s['loadAfter'])>sp['maximumLoad']:reasons.append('host-load')
   if s['elapsedNanoseconds']<sp['minimumIntervalNs']:reasons.append('short-interval')
   if background<sp['minimumBackgroundIdlePercent']:reasons.append('background-cpu')
   assert s['rejectionReasons']==reasons
  ok=all(not s['rejectionReasons']for s in triple);assert all(s['accepted']==ok for s in triple);accepted+=int(ok)
  if i<attempts-1:assert accepted<30
 assert accepted==r['acceptedTriples']==cr['acceptedTriples']==30 and cr['attemptedTriples']==attempts
 assert seen==list(range(len(packets))),('packet order/coverage',name)
 summary={}
 for arm in ['baseline','candidate','C']:
  vals=[s['elapsedNanoseconds']/(s['calls']*entry['n'])for s in rows if s['arm']==arm and s['accepted']];assert len(vals)==30;mu=statistics.mean(vals);sd=statistics.stdev(vals);summary[arm]={'meanNsPerBody':mu,'sdNs':sd,'relativeSd':sd/mu,'samples':30};assert all(close(summary[arm][k],r['summary'][arm][k])for k in summary[arm])
 b,c,ref=[summary[a]for a in['baseline','candidate','C']];stable=max(x['relativeSd']for x in summary.values())<=sp['maximumRelativeSd'];bm,cm,rm=[x['meanNsPerBody']for x in[b,c,ref]];bs,cs,rs=[x['sdNs']for x in[b,c,ref]]
 flags={'stable':stable,'baselineOverCandidate':bm/cm,'candidateOverC':cm/rm,'candidateImprovesBaseline':stable and bm/cm>=sp['minimumSpeedup']and bm-cm>bs+cs,'candidateRegressesBaseline':stable and cm/bm>=sp['minimumSpeedup']and cm-bm>bs+cs,'candidateQualifiedCOrBetter':stable and rm/cm>=sp['minimumSpeedup']and rm-cm>rs+cs}
 for k,v in flags.items():assert (v==r['summary'][k]if type(v)==bool else close(v,r['summary'][k])),(name,k)
 assert cr['summary']==r['summary'];allout.append({'workload':name,**summary,**flags,'acceptedTriples':30,'attemptedTriples':attempts,'timeReductionPercent':100*(1-cm/bm)})
 attemptTotal+=attempts;rejectTotal+=attempts-30
assert packetTotal<=285 and campaign['singleBodyComplete'] and campaign['historicalStatisticsUsed']==False and campaign['performanceCampaigns']==1
geom=math.exp(statistics.mean(math.log(x['baselineOverCandidate'])for x in allout));gc=math.exp(statistics.mean(math.log(x['candidateOverC'])for x in allout));assert close(geom,campaign['descriptiveGeometricBaselineOverCandidate'])and close(gc,campaign['descriptiveGeometricCandidateOverC'])
out={'status':'PASS independent ONE current AES-only raw timing audit','workloads':1,'acceptedTriples':30,'attemptedTriples':attemptTotal,'rejectedTriples':rejectTotal,'calibrationProcesses':calTotal,'runnerProcesses':packetTotal,'pinCount':len(pins),'qualifiedGains':[x['workload']for x in allout if x['candidateImprovesBaseline']],'qualifiedRegressions':[x['workload']for x in allout if x['candidateRegressesBaseline']],'qualifiedCOrBetter':[x['workload']for x in allout if x['candidateQualifiedCOrBetter']],'unstable':[x['workload']for x in allout if not x['stable']],'descriptiveGeometricBaselineOverCandidate':geom,'descriptiveGeometricCandidateOverC':gc,'rows':allout,'boundaries':['Onlycurrent campaign raw packets; no history pooling or reruns.','Background idle is raw tick idle plus childCPU envelope estimate, not isolated-core guarantee.','Original C compiler flags/version unknown; no official Embench score.','Singlebody ratio is not all19 improvement or C-or-better; seven removed moves not performance evidence.','Experimental directreg prototype not product/default adoption; fullM/posttake/general ABI gaps unchanged.'],'nativeSolverNetworkTimingRunsByReviewer':0}
(D/'report.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in['rows','boundaries']}))
