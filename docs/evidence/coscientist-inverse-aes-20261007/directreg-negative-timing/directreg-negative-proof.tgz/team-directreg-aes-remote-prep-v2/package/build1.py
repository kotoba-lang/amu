"""Exactly1 immutable-header host builds; no guest invocation."""
from pathlib import Path
import json,hashlib,subprocess,sys
P=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
if len(sys.argv)!=2:raise SystemExit('ROOT_BUILD_GO.json required')
a=json.loads(Path(sys.argv[1]).read_text());pr=json.loads((P/'preregistration.json').read_text())
assert a['allowHostBuild'] is True and a['allowGuestCalls'] is False and a['hostBuildCap']==1 and a['performanceAuthorized'] is False
assert a['preregistrationSHA256']==sha(P/'preregistration.json') and a['packageInputPinsSHA256']==sha(P/'package-input-pins.json')
assert str(P.parent)==pr['remoteRoot']
for n,h in json.loads((P/'package-input-pins.json').read_text()).items():assert sha(P/n)==h,n
W=P/'built';assert not W.exists();W.mkdir();save(W/'authorization.json',a);rows=[]
try:
 for row in json.loads((P/'manifest.json').read_text())['entries']:
  d=P/row['workload'];out=W/row['workload'];out.mkdir();cmd=['clang','-O2','-std=c11','-include',str(d/'immutable-header.h'),str(P/'timing-host.c'),'-o',str(out/'runner')]
  assert len(rows)<1;r={'workload':row['workload'],'argv':cmd,'state':'started','hostSourceSHA256':sha(P/'timing-host.c'),'headerSHA256':sha(d/'immutable-header.h')};rows.append(r);save(W/'attempts.json',rows)
  try:q=subprocess.run(cmd,capture_output=True,timeout=1800);stdout,stderr,rc=q.stdout,q.stderr,q.returncode
  except subprocess.TimeoutExpired as e:stdout,stderr,rc=e.stdout or b'',e.stderr or b'',None
  (out/'stdout').write_bytes(stdout);(out/'stderr').write_bytes(stderr);r.update(state='terminal',returncode=rc);save(W/'attempts.json',rows);assert rc==0,(row['workload'],rc)
  r['runnerSHA256']=sha(out/'runner');save(W/'attempts.json',rows);print('BUILT',row['workload'],flush=True)
 save(W/'report.json',{'status':'PASS1build only','builds':1,'guestCalls':0,'entries':[dict(r,runnerSHA256=next(x['runnerSHA256']for x in rows if x['workload']==r['workload']))for r in json.loads((P/'manifest.json').read_text())['entries']]})
except BaseException as e:save(W/'report.json',{'status':'FAIL firstoutcome no retry','exception':repr(e),'builds':len(rows),'guestCalls':0});raise
finally:
 save(W/'pins.json',{str(p.relative_to(W)):sha(p)for p in W.rglob('*')if p.is_file()and p.name not in ['pins.json','terminal.json']})
 save(W/'terminal.json',{'allWritesComplete':True,'reportSHA256':sha(W/'report.json'),'pinsSHA256':sha(W/'pins.json')})
