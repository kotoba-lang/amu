"""One3 finite semantic preflight; no performance campaign."""
from pathlib import Path
import json,hashlib,subprocess,sys,socket
P=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
if len(sys.argv)!=2:raise SystemExit('ROOT_3_GO.json required')
a=json.loads(Path(sys.argv[1]).read_text());pr=json.loads((P/'preregistration.json').read_text());B=P/'built'
assert a['semanticPreflightAuthorized'] is True and a['performanceAuthorized'] is False and a['maximumCalls']==3 and a['freshLocalFullBodyAccepted'] is True and a['compilerMQualificationAccepted'] is True
assert a['preregistrationSHA256']==sha(P/'preregistration.json') and a['packageInputPinsSHA256']==sha(P/'package-input-pins.json') and a['compiledInputPinsSHA256']==sha(B/'pins.json')
assert str(P.parent)==pr['remoteRoot'];assert socket.gethostname().split('.')[0]==pr['remoteHostname']
for n,h in json.loads((P/'package-input-pins.json').read_text()).items():assert sha(P/n)==h,n
for n,h in json.loads((B/'pins.json').read_text()).items():assert sha(B/n)==h,n
built=json.loads((B/'report.json').read_text());assert built['status']=='PASS1build only' and built['guestCalls']==0
W=P/'semantic';assert not W.exists();W.mkdir();save(W/'authorization.json',a)
f={}
for label,cmd in [('arch',['uname','-m']),('AES',['/usr/sbin/sysctl','-n','hw.optional.arm.FEAT_AES']),('CRC32',['/usr/sbin/sysctl','-n','hw.optional.arm.FEAT_CRC32']),('model',['/usr/sbin/sysctl','-n','hw.model']),('host',['hostname'])]:
 q=subprocess.run(cmd,capture_output=True,text=True);f[label]={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
save(W/'feature.json',f);assert f['arch']['stdout'].strip()=='arm64' and f['arch']['exit']==0
assert f['model']['exit']==0 and f['model']['stdout'].strip()==pr['remoteModel']
for k in ['AES','CRC32']:assert f[k]['exit']==0 and f[k]['stdout'].strip()=='1'
rows=[]
try:
 for row in built['entries']:
  d=P/row['workload'];runner=B/row['workload']/'runner';assert sha(runner)==row['runnerSHA256']
  for arm,kind,file,entry in [('baseline','raw','baseline.bin',str(row['baselineOffset'])),('candidate','raw','candidate.bin',str(row['candidateOffset'])),('C','dylib','c.dylib',row['Csymbol'])]:
   assert len(rows)<3;r={'workload':row['workload'],'arm':arm,'state':'started','n':row['n']};rows.append(r);save(W/'attempts.json',rows);cmd=[str(runner),kind,str(d/file),entry,'aarch64',str(row['n']),'1','0','16777216']
   try:q=subprocess.run(cmd,capture_output=True,text=True,timeout=30);raw={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
   except subprocess.TimeoutExpired as e:raw={'exit':None,'timeout':True,'stdout':(e.stdout or b'').decode(errors='replace'),'stderr':(e.stderr or b'').decode(errors='replace')}
   path=W/(row['workload']+'-'+arm+'.json');save(path,dict(raw,argv=cmd,diagnosticElapsedNotStatistics=True));r.update(state='terminal',receiptSHA256=sha(path));save(W/'attempts.json',rows)
   assert raw['exit']==0,raw;o=json.loads(raw['stdout']);expected=0 if arm=='C'else row['expectedNativeFuelConsumed'];assert o['result']==1 and o['calls']==1 and o['warmupCalls']==0
   assert o['contextFuelBefore']==16777216 and o['contextFuelConsumed']==expected and o['contextFuelAfter']==16777216-expected
   print('SEMANTIC',row['workload'],arm,flush=True)
 assert len(rows)==3;save(W/'report.json',{'status':'PASS3semantic only','calls':3,'performanceAuthorized':False,'historicalStatisticsUsed':False})
except BaseException as e:save(W/'report.json',{'status':'FAIL no retry','exception':repr(e),'calls':len(rows),'performanceAuthorized':False});raise
finally:
 save(W/'pins.json',{p.name:sha(p)for p in W.iterdir()if p.is_file()and p.name not in ['pins.json','terminal.json']});save(W/'terminal.json',{'allWritesComplete':True,'reportSHA256':sha(W/'report.json'),'pinsSHA256':sha(W/'pins.json')})
