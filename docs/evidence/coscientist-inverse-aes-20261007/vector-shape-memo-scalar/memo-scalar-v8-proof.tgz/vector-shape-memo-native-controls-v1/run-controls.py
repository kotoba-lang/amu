"""Future fixed25 native compiler/control calls. Exact parent GO required for each stage."""
from pathlib import Path
import json,hashlib,subprocess,os,re,sys,time
D=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(D/n).write_text(json.dumps(x,indent=2)+'\n')
def go(stage):
 p=json.loads((D/f'parent-{stage}-go.json').read_text());assert p['authorizedNativeCompilerOnly'] and not p['benchmarkTiming'] and p['maximumLoaderCalls']==25
 for path,h in p['frozenInputs'].items():assert sha(Path(path))==h,path
 return p
rows=json.loads((D/'attempts.json').read_text()) if (D/'attempts.json').exists() else []
def call(label,image,offset,args,seconds):
 assert len(rows)<25 and not any(r['label']==label for r in rows)
 cmd=[str(D/'kexe-loader'),str(image),str(offset),'0','aarch64','35,37,38,39','--',*args]
 env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(D),KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS=str(seconds),KEXE_WALL_SECONDS=str(seconds))
 row={'index':len(rows)+1,'label':label,'argv':cmd,'state':'started','caps':{'seconds':seconds,'vectorItems':134217728}};rows.append(row);save('attempts.json',rows)
 try:q=subprocess.run(cmd,env=env,capture_output=True,timeout=seconds+10);out,err,rc=q.stdout,q.stderr,q.returncode
 except subprocess.TimeoutExpired as e:out,err,rc=e.stdout or b'',e.stderr or b'',None
 (D/f'{label}.stdout').write_bytes(out);(D/f'{label}.stderr').write_bytes(err);row.update(state='terminal',returncode=rc);save('attempts.json',rows)
 assert rc==0 and not err,(label,rc,err[-1000:]);return out
stage=sys.argv[1];g=go(stage)
try:
 if stage=='build':
  assert not rows
  call('controls-compile',D/'producer.bin',int(g['producerOffset']),['compile',str(D/'unity-memo-controls.kotoba'),'--target','aarch64-macos','--output',str(D/'controls.kseed')],1800)
  log=call('controls-extract',D/'producer.bin',int(g['producerOffset']),['extract-native',str(D/'controls.kseed'),'--symbol','main','--output',str(D/'controls.bin')],1800)
  (D/'controls.offset').write_text(re.search(rb':offset (\d+)',log)[1].decode()+'\n')
 elif stage=='controls':
  assert len(rows)==2
  for c in range(21):
   call(f'case-{c}',D/'controls.bin',int((D/'controls.offset').read_text()),['probe',str(c)],120)
   subprocess.run([sys.executable,str(D/'validate-controls.py'),'single',str(c)],check=True)
 elif stage=='baseline':
  assert len(rows)==23
  subprocess.run([sys.executable,str(D/'validate-controls.py'),'all'],check=True)
  # Frozen noninstrumented V8 seed ONLY; parent GO pins the image and provenance.
  assert g['baselineSourceKernelSHA256']=='d1b628a3cfc3cc6c250936a0e75ba5bcd1758633da59f2ec73e38a5986e652ac'
  image=Path(g['baselineImage']);assert image.resolve()!=(D/'controls.bin').resolve()
  call('baseline-compile',image,int(g['baselineOffset']),['compile',str(D/'fixture.kotoba'),'--target','aarch64-macos','--output',str(D/'baseline.kseed')],1800)
  log=call('baseline-extract',image,int(g['baselineOffset']),['extract-native',str(D/'baseline.kseed'),'--symbol','bench','--output',str(D/'baseline.bin')],1800)
  (D/'baseline.offset').write_text(re.search(rb':offset (\d+)',log)[1].decode()+'\n')
  subprocess.run([sys.executable,str(D/'validate-controls.py'),'baseline'],check=True)
 else:raise ValueError(stage)
except BaseException as e:save(f'failure-{stage}.json',{'exception':repr(e),'loaderCalls':len(rows)});raise
finally:save(f'terminal-{stage}.json',{'allWritesComplete':True,'loaderCalls':len(rows),'diagnosticInvocations':sum(r['label'].startswith('case-') for r in rows),'benchmarkBodyInvocations':0,'benchmarkTiming':False,'failure':(D/f'failure-{stage}.json').exists()})
