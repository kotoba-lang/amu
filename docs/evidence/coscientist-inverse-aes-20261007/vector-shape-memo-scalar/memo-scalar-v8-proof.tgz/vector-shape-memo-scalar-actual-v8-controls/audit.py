from pathlib import Path
import json,hashlib,re,importlib.util
D=Path(__file__).resolve().parent;W=D.parent;A=W/'vector-shape-memo-native-controls-v3';C=W/'vector-shape-memo-native-controls-validator-v4';B=W/'vector-typed-analysis-v8'
pin=lambda p:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def load(p):return json.loads(p.read_text())
def relocated(p):
 p=Path(p)
 q=W/p.parent.name/p.name
 return q if q.exists() else p
prior=load(A/'attempts.json');rows=load(C/'attempts.json');assert rows[:3]==prior and len(prior)==3 and len(rows)==25
labels=['controls-compile','controls-extract']+[f'case-{c}' for c in range(21)]+['baseline-compile','baseline-extract']
assert [r['label'] for r in rows]==labels
inputpins={};gos=[A/'parent-build-go.json',A/'parent-controls-go.json',C/'parent-controls-go.json',C/'parent-baseline-go.json']
for p in gos:
 g=load(p);assert g['authorizedNativeCompilerOnly'] and not g['benchmarkTiming'] and g['maximumLoaderCalls']==25
 for f,h in g['frozenInputs'].items():
  q=relocated(f)
  if q==C/'attempts.json' and pin(q)['sha256']!=h:
   # Baseline GO froze the completed23-row prefix; final ledger adds only last2.
   historical=json.dumps(rows[:23],indent=2)+'\n'
   assert hashlib.sha256(historical.encode()).hexdigest()==h
   inputpins[str(q)]={'current':pin(q),'GOHistorical23RowsSHA256':h,'exactAppendOnlyPrefix':True}
  else:
   assert pin(q)['sha256']==h,q;inputpins[str(q)]=pin(q)
assert pin(A/'producer.bin')['sha256']=='2a0d9a3b47dab57ca8b52532e7ce5c9cff9b189de1e62af564b9436646dd239b'
assert load(W/'vector-typed-on-build-independent-v8-root/report.json')['nativeSHA256']==pin(A/'producer.bin')['sha256']
assert load(W/'vector-typed-on-build-independent-v8-root/report.json')['sourceSHA256']==pin(B/'unity-vector-analysis-on.kotoba')['sha256']
s=(A/'unity-memo-controls.kotoba').read_text();delta=load(A/'source-deltas.json');assert s.replace(delta['mainNew'],delta['mainOld'],1).replace(delta['insert'],'',1)==(B/'unity-vector-analysis-on.kotoba').read_text()
assert pin(A/'controls.bin')['sha256']=='1dcda8d18b98df568b0a2064ef0c301c023065c21c2e05f373506bbf6d05d50f'
assert load(A/'failure-controls.json')['loaderCalls']==3
assert load(W/'vector-shape-memo-scalar-actual-failure-v3-root/failure.json')
logpins={}
for i,r in enumerate(rows):
 assert r['index']==i+1 and r['state']=='terminal' and r['returncode']==0
 seconds=120 if r['label'].startswith('case-') else 1800
 assert r['caps']=={'seconds':seconds,'vectorItems':134217728}
 argv=r['argv'];assert Path(argv[0]).name=='kexe-loader' and argv[2:7]==['0','0','aarch64','35,37,38,39','--']
 if r['label'].startswith('case-'):
  c=int(r['label'].split('-')[1]);assert argv[7:]==['probe',str(c)] and Path(argv[1]).name=='controls.bin'
 else:
  assert Path(argv[1]).name=='producer.bin'
  if r['label'].endswith('compile'):
   name='unity-memo-controls.kotoba' if i==0 else 'fixture.kotoba';assert argv[7]=='compile' and Path(argv[8]).name==name and argv[9:12]==['--target','aarch64-macos','--output']
  else:assert argv[7]=='extract-native' and argv[9:11]==['--symbol','main' if i==1 else 'bench'] and argv[11]=='--output'
 root=A if i<3 else C
 for suffix in ['stdout','stderr']:
  p=root/(r['label']+'.'+suffix);logpins[str(p)]=pin(p)
  if suffix=='stderr':assert not p.read_bytes()
# Existing strict parser replay is offline; supplement independent actual receipt calculations.
spec=importlib.util.spec_from_file_location('scalar_validator',C/'validate-controls.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
parsed=[]
for c in range(21):
 p=A/'case-0.stdout' if c==0 else C/f'case-{c}.stdout';text=p.read_text();assert v.validate(text,c)['status']=='PASS';parsed.append(v.parse(text))
for c,r in enumerate(parsed):
 result=v.one(r,'RESULT');assert result==[c,7 if 1<=c<=3 else 0,8388608,6714137,147554,1,1,0 if 1<=c<=3 else 1,50689]
assert v.one(parsed[0],'ACTIVATION')==[0,0,1,1,1]
p=parsed[5];edgecount=sum(e[1]==3 for e in p['EDGE']);a,b=p['MEMO'];assert edgecount==2 and b[3]-a[3]==128*(6+5*edgecount)==2048 and v.one(p,'HIT')==[5,1]
for c,prefix in zip(range(13,19),[0,1,2,3,4,4]):
 b=parsed[c]['MEMO'][1];keys=[1,4096,9223372036854775807,2];assert b[3:6]==[268435456,1,0] and b[12:]==keys[:prefix]+[0]*(4-prefix)
for c in [10,20]:assert v.one(parsed[c],'GUARD')==[c,1,1,1]
assert (C/'baseline.bin').read_bytes()==(W/'vector-persistent-label-native-controls-v3-execution-v1/baseline.bin').read_bytes()
assert int((C/'baseline.offset').read_text())==int((W/'vector-persistent-label-native-controls-v3-execution-v1/baseline.offset').read_text())
for n in ['terminal-controls.json','terminal-baseline.json']:assert not load(C/n)['failure']
report={'status':'ACTUAL_SCALAR_FIXED_FIXTURE_COMPONENT_CONTROLS_PASS_ONLY','nativeByAuditor':0,'actualLoaderCalls':25,'compilerCompileExtractCalls':4,'diagnosticInvocations':21,'benchmarkBodyInvocations':0,'allGuestReturncodes':0,'allStrictCases':21,'ownedWordsSourceAndActual':50689,'fullScalarMComparisonCells':8388608,'GComparisonWords':147554,'originalValidatorFailureRetained':True,'reruns':0,'kernelReverseV8Exact':True,'neutralHit':{'caller':3,'outgoingEdges':2,'workDelta':2048,'current768Equality':True},'partialKeyPrefixes':[0,1,2,3,4,4],'baselineWholeBytesAndBenchOffsetExact':True,'claims':[
'Additional lower slots8193/8449/8704 dirty produce admission7 and exact fullM/G no-op; owned-zero false as expected.',
'Clean case0 runs actual vw-run twice on sameM, both restore complete original scalarM and allocatedG, all50689 owned words zero.',
'Phase5 genuine scalar pipeline and SIR/FREC-derived two outgoing calls establish neutral miss/publish/hit. Own four-key changes erase injected stale contribution and republish; no actual positive/zero vector contribution capture qualification.',
'Direct reset/query/key-save budget refusals leave valid0; keys partially written in observable exact prefixes. Failedinvalidate retains oldvalid1, but globalrefusal prevents reuse and768current/2048contrib/512lastkey banks remain unchanged.',
'Postadmit injected newbank cell and all component probes restore original fullM/G through mandatory cleanup. These direct probes do not establish production reachability.'
],'HOLD':['Genuine typed vector positive/zero/selfneutral capture, arbitraryM/externalarena and universal semantic theorem remain unqualified.','No runtime Embench measurement, C superiority, optimization adoption or usergoal completion claim.'],'sourceInputPins':inputpins,'actualRawPins':logpins}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'report':pin(D/'report.json'),'calls':25,'cases':21}))
