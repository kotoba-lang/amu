"""Offline archive replay only. No compiler/native/subprocess/network calls."""
from pathlib import Path
import json,hashlib,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent.parent
manifest=json.loads((W/'manifest.json').read_text());assert manifest['rawCap']==33554432 and manifest['compressedCap']==4194304
size=0
for row in manifest['files']:
 rel=Path(row['relativePath']);assert not rel.is_absolute() and '..' not in rel.parts
 p=W/rel;assert p.is_file() and not p.is_symlink()
 b=p.read_bytes();size+=len(b);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
assert size<=33554432
p=W/'vector-shape-memo-scalar-actual-v8-controls/audit.py';source=p.read_text()
old="(D/'report.json').write_text(json.dumps(report,indent=2)+'\\n')"
assert source.count(old)==1
source=source.replace(old,'REPLAY_REPORT=report',1)
# Preserve archived report; suppress its final hash print (which refers original snapshot).
source=source[:source.index("print(json.dumps({'report':")]
ns={'__file__':str(p),'__name__':'offline_archive_replay'};exec(compile(source,str(p),'exec'),ns)
r=ns['REPLAY_REPORT'];assert r['actualLoaderCalls']==25 and r['allStrictCases']==21
print(json.dumps({'status':r['status'],'actualRecordedCalls':25,'offlineRevalidatedCases':21,'nativeReplayCalls':0,'sourceAndArchiveMutations':0,'positiveZeroCapture':'HOLD'},indent=2))
