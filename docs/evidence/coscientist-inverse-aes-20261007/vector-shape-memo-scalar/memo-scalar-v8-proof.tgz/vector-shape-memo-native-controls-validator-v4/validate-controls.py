"""Offline strict validation; successful diagnostic process exit alone is never PASS."""
from pathlib import Path
import json,re,hashlib,sys
D=Path(__file__).resolve().parent;W=D.parent
WIDTHS={'SELECTOR':14,'COUNTS':2,'SIR':5,'FREC':17,'FNNAME':3,'ALLOC':6,'PRIME':8,'EDGE':5,'ASSERT':3,'MEMO':16,'POSTADMIT':2,'HIT':2,'GUARD':4,'ACTIVATION':5,'RESULT':9}
REF=W/'vector-persistent-label-native-controls-v3-execution-v1/case-0.stdout'
SRC=W/'vector-typed-analysis-v8/analysis.kotoba';UNITY=W/'vector-typed-analysis-v8/unity-vector-analysis-on.kotoba'
def parse(t,reference=False):
 rows={}
 for line in t.splitlines():
  fields=line.split();assert fields,'blank record'
  tag=fields[0]
  if reference and tag not in ['SELECTOR','COUNTS','SIR','FREC','FNNAME','ALLOC']:continue
  assert tag in WIDTHS,('unknown tag',tag);assert len(fields)==WIDTHS[tag]+1,('width',tag)
  assert all(re.fullmatch(r'-?\d+',v) for v in fields[1:]),'integer'
  rows.setdefault(tag,[]).append([int(v) for v in fields[1:]])
 return rows
def one(r,t):assert len(r.get(t,[]))==1,(t,'singleton');return r[t][0]
def constants():
 u=UNITY.read_text();get=lambda n:int(re.search(r'\(def '+re.escape(n)+r' (\d+)\)',u)[1]);s=SRC.read_text()
 assert '(vw-zero? M vw-labels (+ vw-labels 8705))' in s
 assert '(vw-clear vw-labels (+ vw-labels 8705))' in s
 assert '(def vw-end (+ vw-lp 33792))' in s
 assert s.count('(vw-zero? M vw-fns (+ vw-fns 2048))')==1
 assert s.count('(vw-zero? M vw-sites (+ vw-sites 2048))')==1
 assert s.count('(vw-zero? M vw-edges (+ vw-edges 2048))')==1
 assert s.count('(vw-zero? M vw-old (+ vw-old 2048))')==1
 return {'owned':8705+33792+4*2048,'words':get('gn-a-lp')+get('MM-LABEL-CAP')+82,'OPFN':get('OP-FN'),'OPCALL':get('OP-CALL'),'heap':get('MM-HEAP-BASE')}
def validate(text,c):
 assert 0<=c<=20; r=parse(text);ref=parse(REF.read_text(),True);k=constants()
 for t in ['SELECTOR','COUNTS','SIR','FREC','FNNAME']:assert r.get(t)==ref.get(t),(t,'pinned fixture mismatch')
 sn,fnn=one(r,'COUNTS');assert [x[0] for x in r['SIR']]==list(range(1,sn));assert [x[0] for x in r['FREC']]==list(range(1,fnn))
 pre,words,base,top,success,err=one(r,'ALLOC');assert [pre,words,base,top,success,err]==one(ref,'ALLOC')
 assert pre==base and base>=k['heap'] and top==base+words and top<=8388608 and words==k['words'] and success==1 and err==0
 result=one(r,'RESULT');assert result[0]==c and result[2:5]==[8388608,base,words] and result[8]==k['owned']
 dirty=1<=c<=3
 assert result[1]==(7 if dirty else 0);assert result[5:8]==([1,1,0] if dirty else [1,1,1])
 if c<4:
  assert not any(t in r for t in ['PRIME','EDGE','MEMO','ASSERT','HIT','POSTADMIT','GUARD'])
  assert r.get('ACTIVATION',[])==([[0,0,1,1,1]] if c==0 else [])
 else:
  assert 'ACTIVATION' not in r
  caller=0;expected=[]
  for j,op,a,b,z in r['SIR']:
   if op==k['OPFN']:caller=a
   if op==k['OPCALL']:expected.append([len(expected),caller,j,a,b])
  assert r.get('EDGE')==expected and expected
  prime=one(r,'PRIME');e,f,site,target,temp=expected[0]
  assert prime==[c,0,len(expected),f,site,target,temp,1]
  byfn={x[0]:x[1:] for x in r['FREC']};assert 0<f<fnn and 0<target<fnn
  # Function starts are independently tied to FF-SIR12 and actual OP-FN.
  start=byfn[f][12];sir={x[0]:x[1:] for x in r['SIR']};assert sir[start][0:2]==[k['OPFN'],f] and start<site
  assert sir[site]==[k['OPCALL'],target,temp,byfn[target][3]]
  assert r.get('ASSERT')==[[c,2,1],[c,3,1]]
  memo=r.get('MEMO',[]);assert len(memo)==2
  a,b=memo;assert a[:3]==[c,0,f] and b[:3]==[c,1,f]
  assert a[6:8]==[0,1] and a[8:12]==[0]*4
  skip=c in [4,11,12,13,14,15,16,17,18,19]
  assert a[4:6]==([0,0] if skip else [0,1])
  assert a[12:16]==[0]*4
  if 5<=c<=9:
   keys=[0]*4
   if c>=6:keys[c-6]=1
   assert b[4:8]==[0,1,0,1] and b[8:12]==keys and b[12:16]==keys
  elif c==4:assert b[4:8]==[0,0,0,1] and one(r,'POSTADMIT')==[4,919]
  elif c in [10,20]:assert b[4:8]==[1,1,0,1] and b[8:16]==[0]*8
  elif c==19:assert b[4:8]==[1,0,0,0]
  else:assert b[4:8]==[1,0,0,1]
  if 13<=c<=18:
   keys=[1,4096,9223372036854775807,2];written=[0,1,2,3,4,4][c-13]
   assert b[3]==268435456 and b[8:12]==keys and b[12:16]==keys[:written]+[0]*(4-written)
  if c==5:
   N=sum(edge[1]==f for edge in expected)
   assert one(r,'HIT')==[5,1] and b[3]-a[3]==128*(6+5*N)
  else:assert 'HIT' not in r
  if c in [10,20]:
   assert one(r,'GUARD')==[c,1,1,1]
   assert b[3]==(268435456 if c==10 else a[3])
  else:assert 'GUARD' not in r
  if c!=4:assert 'POSTADMIT' not in r
 return {'case':c,'status':'PASS','ownedSourceDerived':k['owned'],'componentOnly':c>=4,'positiveCapture':'HOLD'}
def logpath(c):return W/'vector-shape-memo-native-controls-v3/case-0.stdout' if c==0 else D/f'case-{c}.stdout'
if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='single':
  c=int(sys.argv[2]);out=validate(logpath(c).read_text(),c);(D/f'case-{c}-validation.json').write_text(json.dumps(out,indent=2)+'\n')
 elif mode=='all':
  out=[validate(logpath(c).read_text(),c) for c in range(21)];(D/'validation-all.json').write_text(json.dumps(out,indent=2)+'\n')
 elif mode=='baseline':
  R=W/'vector-persistent-label-native-controls-v3-execution-v1'
  assert (D/'baseline.bin').read_bytes()==(R/'baseline.bin').read_bytes()
  assert int((D/'baseline.offset').read_text())==int((R/'baseline.offset').read_text())
  (D/'validation-baseline.json').write_text(json.dumps({'status':'PASS','exactCODEAndBenchOffset':True})+'\n')
 else:raise ValueError(mode)
