from pathlib import Path
import importlib.util,json,copy
D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v',D/'validate-controls.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
ref=v.parse(v.REF.read_text(),True);k=v.constants();caller=0;edges=[]
for j,op,a,b,c in ref['SIR']:
 if op==k['OPFN']:caller=a
 if op==k['OPCALL']:edges.append([len(edges),caller,j,a,b])
f,site,target,temp=edges[0][1:];base=k['heap'];words=k['words']
def synth(c):
 r=copy.deepcopy(ref);r['ALLOC']=[[base,words,base,base+words,1,0]];r['RESULT']=[[c,7 if 1<=c<=3 else 0,8388608,base,words,1,1,0 if 1<=c<=3 else 1,k['owned']]]
 if c==0:r['ACTIVATION']=[[0,0,1,1,1]]
 if c>=4:
  r['PRIME']=[[c,0,len(edges),f,site,target,temp,1]];r['EDGE']=edges;r['ASSERT']=[[c,2,1],[c,3,1]]
  skip=c in [4,11,12,13,14,15,16,17,18,19]
  a=[c,0,f,1000,0,0 if skip else 1,0,1]+[0]*8;b=[c,1,f,2000,0,1,0,1]+[0]*8
  if 6<=c<=9:b[8+c-6]=1;b[12+c-6]=1
  if c==4:b[5]=0;r['POSTADMIT']=[[4,919]]
  if c in [10,20]:b[4]=1
  if 11<=c<=19:b[4]=1;b[5]=0
  if c==19:b[7]=0
  if 13<=c<=18:
   keys=[1,4096,9223372036854775807,2];n=[0,1,2,3,4,4][c-13];b[3]=268435456;b[8:12]=keys;b[12:16]=keys[:n]+[0]*(4-n)
  r['MEMO']=[a,b]
  if c==5:r['HIT']=[[5,1]]
 return r
def text(r):return '\n'.join(tag+' '+' '.join(map(str,row)) for tag,rows in r.items() for row in rows)+'\n'
for c in range(21):assert v.validate(text(synth(c)),c)['status']=='PASS'
mutants=[]
def reject(name,c,edit):
 r=synth(c);edit(r)
 try:v.validate(text(r),c)
 except (AssertionError,KeyError,IndexError):mutants.append(name);return
 raise AssertionError('accepted mutant '+name)
reject('partial-valid1',17,lambda r:r['MEMO'][1].__setitem__(5,1))
reject('partial-prefix-wrong',15,lambda r:r['MEMO'][1].__setitem__(14,9223372036854775807))
reject('dirty-zero-claimed',1,lambda r:r['RESULT'][0].__setitem__(7,1))
reject('dirty-not-noop',2,lambda r:r['RESULT'][0].__setitem__(5,0))
reject('cleanup-old-count',4,lambda r:r['RESULT'][0].__setitem__(8,50177))
reject('missing-firstactivation',0,lambda r:r.pop('ACTIVATION'))
reject('false-assert',5,lambda r:r['ASSERT'][1].__setitem__(2,0))
reject('wrong-prime-caller',5,lambda r:r['PRIME'][0].__setitem__(3,1))
reject('wrong-edge-target',5,lambda r:r['EDGE'][0].__setitem__(3,3))
reject('sir-mutated',5,lambda r:r['SIR'][0].__setitem__(2,99))
reject('extra-record',5,lambda r:r.update(BOGUS=[[1]]))
reject('wrong-FREC-width',5,lambda r:r['FREC'][0].pop())
(D/'validator-selftest-report.json').write_text(json.dumps({'status':'OFFLINE_SYNTHETIC_ONLY_PASS','native':0,'validCases':21,'rejectedMutants':mutants,'warning':'Synthetic records are parser tests, not executed harness evidence.'},indent=2)+'\n')
print(json.dumps({'valid':21,'reject':len(mutants)}))
