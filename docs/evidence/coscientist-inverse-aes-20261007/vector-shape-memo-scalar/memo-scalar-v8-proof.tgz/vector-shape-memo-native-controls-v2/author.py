from pathlib import Path
import json,hashlib,re
D=Path(__file__).resolve().parent;W=D.parent;B=W/'vector-typed-analysis-v8';P=W/'vector-shape-memo-native-controls-design-v1'
assert hashlib.sha256((P/'preregistration.json').read_bytes()).hexdigest()=='cc33b87b7fff79a22327d0e7d50dd7388af5a8fe306035b90cf6e5688430dfef'
p=json.loads((P/'preregistration.json').read_text())
s=(B/'unity-vector-analysis-on.kotoba').read_text();assert hashlib.sha256(s.encode()).hexdigest()==p['frozenUnitySHA256']
old=(W/'vector-persistent-label-native-controls-v3/control-helpers.kotoba').read_text(); prefix=old[:old.index('(defn- vc-mutate ')]
helpers=prefix+'''\n(defn- mc-prime [M :vector-i64] :vector-i64
 (let [m (-> M (vw-cs 2 (vector-at M MM-FN-N)) (vw-cs 16 1) (vw-cs 26 1))
       m1 (vw-index-fns m 1) m2 (vw-index-bodies (vw-stage m1 2) 1)
       m2i (if (= (vw-c m2 1) 0) (vw-out-build m2 (dec (vw-c m2 3))) m2)
       m2a (vw-index-labels (vw-stage m2i 3) 1) m3 (vw-domain-all m2a 1 1)
       m3a (if (= (vw-c m3 1) 0) (vw-zero-work m3 vw-lp (+ vw-lp 8193)) m3)
       m4 (if (= (vw-c m3a 16) 0) (vw-cs m3a 1 1) (vw-closure (vw-stage m3a 4) 0))
       m5 (if (= (vw-c m4 1) 0) (vw-alias-fixed (vw-cs m4 26 5) 0) m4)]
  (if (= (vw-c m5 1) 0) (vw-bounds-save (vw-cs m5 26 6) 1 0) m5)))
(defn- mc-neutral [M :vector-i64 f :i64 link :i64 previous :i64] :bool
 (let [checked (vw-out-checked M f link previous)]
  (cond (< checked 0) false (= checked 0) true
        :else (let [e (dec checked)]
          (and (= (gn-g M (+ vw-sites (* e 4))) -1)
               (= (gn-g M (+ vw-sites (* e 4) 1)) -1)
               (= (gn-g M (+ vw-sites (* e 4) 2)) -1)
               (= (gn-g M (+ vw-sites (* e 4) 3)) -1)
               (mc-neutral M f (gn-g M (+ vw-old 1280 e)) checked))))))
(defn- mc-keys [M :vector-i64 f :i64 k :i64] :bool
 (if (>= k 4) true (and (= (gn-g M (+ vw-old (* f 4) k)) (gn-g M (+ gn-a-lp 8193 (* f 4) k))) (mc-keys M f (inc k)))))
(defn- mc-state [M :vector-i64 c :i64 stage :i64 f :i64] :i64
 (vc-print "MEMO" [c stage f (vw-c M 0) (vw-c M 1) (gn-g M (+ vw-old 1792 f))
  (vw-f M f 14) (vw-f M f 15)
  (gn-g M (+ vw-old (* f 4))) (gn-g M (+ vw-old (* f 4) 1)) (gn-g M (+ vw-old (* f 4) 2)) (gn-g M (+ vw-old (* f 4) 3))
  (gn-g M (+ gn-a-lp 8193 (* f 4))) (gn-g M (+ gn-a-lp 8193 (* f 4) 1)) (gn-g M (+ gn-a-lp 8193 (* f 4) 2)) (gn-g M (+ gn-a-lp 8193 (* f 4) 3))]))
(defn- mc-components [M :vector-i64 c :i64] :vector-i64
 (let [m (mc-prime M) count (vw-c m 3) f (if (> count 0) (vw-e m 0 0) 0)
       site (if (> count 0) (vw-e m 0 1) 0) target (if (> count 0) (vw-e m 0 2) 0) base (if (> count 0) (vw-e m 0 3) 0)
       good (and (= (vw-c m 1) 0) (> count 0) (vw-memo-fn? m f) (vw-memo-fn? m target)
        (= (gn-op m site) OP-CALL) (= (gn-sir m site IF-A) target) (= (gn-sir m site IF-B) base)
        (= (vw-f m f 15) 1) (= (vw-f m f 14) 0) (= (vw-f m f 3) 1)
        (= (vw-f m f 10) 0) (= (vw-f m f 11) 0) (= (vw-f m f 12) 0) (= (vw-f m f 13) 0))
       receipt (vc-print "PRIME" [c (vw-c m 1) count f site target base (if good 1 0)])
       edges (loop [e 0] (if (>= e count) 0 (let [out (vc-print "EDGE" [e (vw-e m e 0) (vw-e m e 1) (vw-e m e 2) (vw-e m e 3)])] (recur (inc e)))))]
  (if (not good) (let [fail (vc-print "ASSERT" [c 1 0])] (vw-cs m 1 1))
   (let [head (vw-out-head m f)
         m0 (if (= c 4) (gn-gs m (+ gn-a-lp 8704) 919) m)
         pre (if (= c 4) (vc-print "POSTADMIT" [c (gn-g m0 (+ gn-a-lp 8704))]) 0)
         ;; Genuine miss fills all neutral contributions and publishes matching key.
         miss (if (or (= c 4) (= c 11) (= c 12) (and (>= c 13) (<= c 18)) (= c 19)) m0 (vw-memo-query m0 f))
         a (mc-state miss c 0 f)
         pub (if (or (= c 4) (= c 11) (= c 12) (and (>= c 13) (<= c 18)) (= c 19)) true
                (and (= (vw-c miss 1) 0) (= (gn-g miss (+ vw-old 1792 f)) 1) (mc-keys miss f 0) (mc-neutral miss f head 0)))
         p (vc-print "ASSERT" [c 2 (if pub 1 0)])
         snapshot (vc-copy miss)
         changed (if (and (>= c 6) (<= c 9))
           (gn-gs (gn-gs miss (+ vw-old (* f 4) (- c 6)) 1) (+ vw-sites (* (dec head) 4)) 313) miss)
         prepared (cond (= c 10) (vw-memo-valid-store (vw-cs changed 0 vw-work-cap) f 0)
                        (= c 11) (vw-memo-reset (vw-memo-valid-store (vw-cs changed 0 0) f 0) f head 0 0)
                        (= c 12) (vw-memo-valid-store (vw-cs changed 0 0) f 0)
                        (and (>= c 13) (<= c 18))
                         (-> (vw-memo-valid-store (vw-cs changed 0 0) f 0)
                             (gn-gs (+ vw-old (* f 4)) 1)
                             (gn-gs (+ vw-old (* f 4) 1) 4096)
                             (gn-gs (+ vw-old (* f 4) 2) 9223372036854775807)
                             (gn-gs (+ vw-old (* f 4) 3) 2))
                        (= c 19) (vw-fs changed f 15 0)
                        (= c 20) (vw-cs changed 1 1)
                        :else changed)
         ticks (cond (= c 13) 0 (= c 14) 2 (= c 15) 4 (= c 16) 6 (= c 17) 8 :else 9)
         result (cond (= c 4) prepared
                      (= c 11) (vw-memo-reset (vw-cs prepared 0 vw-work-cap) f head 0 0)
                      (= c 12) (vw-run-fn (vw-cs prepared 0 vw-work-cap) f 0 1)
                      (and (>= c 13) (<= c 18)) (vw-memo-key-save (vw-cs prepared 0 (- vw-work-cap (* 128 ticks))) f 0)
                      :else (vw-memo-query prepared f))
         z (mc-state result c 1 f)
         goodout (cond (= c 4) (= (gn-g result (+ gn-a-lp 8704)) 919)
                       (and (>= c 5) (<= c 9)) (and (= (vw-c result 1) 0) (= (gn-g result (+ vw-old 1792 f)) 1) (mc-keys result f 0) (mc-neutral result f head 0))
                       (= c 10) (and (= (vw-c result 1) 1) (= (gn-g result (+ vw-old 1792 f)) 1))
                       (and (>= c 11) (<= c 19)) (and (= (vw-c result 1) 1) (= (gn-g result (+ vw-old 1792 f)) 0))
                       :else (and (= (vw-c result 1) 1) (= (gn-g result (+ vw-old 1792 f)) 1)))
         out (vc-print "ASSERT" [c 3 (if goodout 1 0)])
         hit (if (= c 5) (vc-print "HIT" [c (if (vc-equal snapshot result (+ (vector-at result gn-cell) vw-current) (+ (vector-at result gn-cell) vw-control)) 1 0)]) 0)]
    result))))
'''
fixture=p['fixture'];helpers+='\n(def MC-FIXTURE '+json.dumps(fixture)+')\n'
probe='''
(defn- mc-probe [] :i64
 (let [c (vc-case) S MC-FIXTURE
       m0 (mem-set (mem-new) MM-SRC-LEN (string-length S))
       m1 (lx-run m0 S) m2 (if (= (vector-at m1 MM-ERR) 0) (rd-run m1 S) m1)
       m3 (if (= (vector-at m2 MM-ERR) 0) (nm-run m2 S) m2)
       m4 (if (= (vector-at m3 MM-ERR) 0) (ck-run m3 S) m3)
       m5 (if (= (vector-at m4 MM-ERR) 0) (lw-run m4) m4)]
  (if (or (< c 0) (> c 20) (not= (vector-at m5 MM-ERR) 0) (not (vc-struct-ok m5))) 90
   (let [witness (vc-witness m5) top (vector-at m5 MM-HEAP-TOP)
         a0 (if (< top MM-HEAP-BASE) (gn-put m5 MM-HEAP-TOP MM-HEAP-BASE) m5)
         pretop (vector-at a0 MM-HEAP-TOP) words (+ gn-a-lp MM-LABEL-CAP 82)
         a1 (mem-alloc a0 words) base (vector-at a1 MM-R0)
         alloc (vc-print "ALLOC" [pretop words base (vector-at a1 MM-HEAP-TOP) (vector-at a1 MM-R1) (vector-at a1 MM-ERR)])]
    (if (or (not= (vector-at a1 MM-ERR) 0) (not= (vector-at a1 MM-R1) 1) (not= base pretop)) 91
     (let [a2 (-> (gn-put a1 gn-cell base) (gn-gs gn-g-open 0) (gn-gs gn-g-open-n 0)
                  (gn-gs di-used 0) (gn-gs di-sites 0) (gn-gs as-used 0) (gn-gs as-sites 0))
           dirty (and (>= c 1) (<= c 3))
           a3 (if dirty (gn-gs a2 (+ gn-a-lp (cond (= c 1) 8193 (= c 2) 8449 :else 8704)) (+ 900 c)) a2)
           snapshot (vc-copy a3) status (vw-entry-status a3)
           first (if (< c 4) (vw-run a3) (mc-components a3 c))
           same1 (vc-equal snapshot first 0 (vector-count first))
           g1 (vc-equal snapshot first base (+ base words))
           r1 (if (= c 0) (vc-print "ACTIVATION" [0 status (if same1 1 0) (if g1 1 0) (if (vw-reserved-zero? first) 1 0)]) 0)
           result (cond (= c 0) (vw-run first) dirty first :else (vw-cleanup first))
           allsame (vc-equal snapshot result 0 (vector-count result))
           gsame (vc-equal snapshot result base (+ base words))
           zero (vw-reserved-zero? result)
           receipt (vc-print "RESULT" [c status (vector-count result) base words (if allsame 1 0) (if gsame 1 0) (if zero 1 0) 50689])]
      0))))))
'''
helpers+=probe
marker=';; the module entry: SIR -> CODE';assert s.count(marker)==1
out=s.replace(marker,helpers+'\n'+marker,1)
main='(defn- seed-main [] :i64 (drv-main))';replacement='(defn- seed-main [] :i64 (if (and (> (io-argc) 0) (string=? (io-arg 0) "probe")) (mc-probe) (drv-main)))'
assert out.count(main)==1;out=out.replace(main,replacement,1)
assert out.replace(replacement,main,1).replace(helpers+'\n','',1)==s
# Lexical balancing, no native/compiler invocation.
depth=0;string=comment=escape=False
for c in out:
 if comment:
  if c=='\n':comment=False
 elif string:
  if escape:escape=False
  elif c=='\\':escape=True
  elif c=='"':string=False
 elif c==';':comment=True
 elif c=='"':string=True
 elif c=='(':depth+=1
 elif c==')':depth-=1;assert depth>=0
assert depth==0 and not string
(D/'unity-memo-controls.kotoba').write_text(out);(D/'control-helpers.kotoba').write_text(helpers);(D/'fixture.kotoba').write_text(fixture)
(D/'source-deltas.json').write_text(json.dumps({'insertMarker':marker,'insert':helpers+'\n','mainOld':main,'mainNew':replacement,'fullReverseV8Exact':True},indent=2)+'\n')
(D/'cases.json').write_text((P/'cases.json').read_text())
pin=lambda x:{'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()}
(D/'report.json').write_text(json.dumps({'status':'SOURCE_ONLY_PENDING_REVIEW_NO_NATIVE_GO','native':0,'preregistration':pin(P/'preregistration.json'),'source':pin(D/'unity-memo-controls.kotoba'),'reverseV8Exact':True,'kernelChanges':0,'cases':21,'futureLoaderCallCap':25,'positiveCaptureQualification':'HOLD_TYPED_VECTOR_FIXTURE_NOT_AUTHORed','validator':'pending source review; assertions print outcomes, probe return0 doesnot implyPASS','timing':False},indent=2)+'\n')
print(json.dumps(pin(D/'report.json')))
