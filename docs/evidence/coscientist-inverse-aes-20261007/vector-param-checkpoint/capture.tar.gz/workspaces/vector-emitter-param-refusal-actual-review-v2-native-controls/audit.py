"""Offline raw audit. Root must confirm terminal before this script is run."""
from pathlib import Path
import hashlib,json,re,struct,importlib.util
D=Path(__file__).resolve().parent;W=D.parent;S=W/'vector-emitter-param-refusal-suite-v2-native-controls'
sha=lambda b:hashlib.sha256(b).hexdigest();seen={}
def need(x,m):
 if not x:raise AssertionError(m)
def read(p):
 p=Path(p);b=p.read_bytes();r={'sha256':sha(b),'bytes':len(b)}
 need(str(p) not in seen or seen[str(p)]==r,('changed',str(p)));seen[str(p)]=r;return b
def load(p):return json.loads(read(p))
def save(n,r):(D/n).write_text(json.dumps(r,indent=2)+'\n')
def pin(p,h,n=None):
 b=read(p);need(sha(b)==h,('hash',str(p)));need(n is None or len(b)==n,('size',str(p)));return b
class ActualFailure(Exception):pass
def valid(x,m):
 if not x:raise ActualFailure(m)
TAIL=(rb' :fuel \{:initial (\d+) :remaining (\d+)\}'+rb' :heap \{:capacity (\d+) :used (\d+)\}'+rb' :string-pool \{:capacity (\d+) :used (\d+)\}'+rb' :vectors \{:capacity (\d+) :used (\d+)\}'+rb' :vector-items \{:capacity (\d+) :used (\d+)\}\}\n')
def functional(q,expected):
 out,err,rc=q
 if expected=='SIGILL':
  valid(rc==120 and err==b'KEXE_TRAP {:kind :signal :signal :SIGILL}\n','exactSIGILL');m=re.fullmatch(rb'\{:status :trap :exit 120'+TAIL,out)
 else:
  valid(rc==0 and not err,'scalar success');m=re.fullmatch(rb'\{:status :ok :result (-?\d+)'+TAIL,out)
 valid(m is not None,'structured result');v=list(map(int,m.groups()))
 if expected!='SIGILL':valid(v.pop(0)==expected,'mathematical signed oracle')
 valid(v[0]==16777216 and 0<v[1]<=v[0],'positive fixed fuel');valid(v[6]==4096 and v[8]==65536,'fixedvectorcaps')
 valid(all(0<=u<=c for c,u in zip(v[2::2],v[3::2])),'arenabounds');return v

def audit():
 pin(D/'compare-frozen.py','3555359cb8274d8f895337184b850c8007004654ed2281da45a51d39aefc05b8')
 spec=importlib.util.spec_from_file_location('frozen_compare',D/'compare-frozen.py');cmp=importlib.util.module_from_spec(spec);spec.loader.exec_module(cmp)
 pin(S/'run.py','a6dcb0967e7f11944b40bd4853188d15ec21f7966a7ce06a01b69b8ea929189d')
 pin(S/'source-pins.json','d407e7db7e2e1083ead10b6ac62b823cbd1cc0905b20850ea230d968522ca973')
 for name,h in load(S/'source-pins.json').items():pin(S/name,h)
 cases=load(S/'cases.json');need(len(cases)==10,'fixed10')
 go=load(S/'parent-go.json');c=load(S/'candidate-input.json');pr=load(S/'preregistration.json')
 need(go['authorizeNative'] is True and go['maximumLoaderCalls']==150,'GO150');need(go['sourcePinsSHA256']==sha(read(S/'source-pins.json')) and go['candidateInputSHA256']==sha(read(S/'candidate-input.json')),'GObinds')
 need(c['parameterBridgeON'] is True and c['returnedOrExportedParameterRelaxation'] is False,'candidate scope')
 need(go['candidateSourceSHA256']==c['candidateSource']['sha256'] and go['sourceReviewReceiptSHA256']==c['sourceReviewReceipt']['sha256'],'GOsource')
 for r in [*pr['referencePins'].values(),*[c[k] for k in ['candidateProducer','candidateSource','candidateBuild','sourceReviewReceipt']]]:pin(r['path'],r['sha256'],r['bytes'])
 need(c['candidateProducer']['sha256']=='4158d7de2dfe4d922450b60788bb5f6a950ca129f92f0b841069aa4c0f76b509' and c['candidateSource']['sha256']=='ea8281843170b65999ff5a6460a2ba2b3474f04e8e5fda8abc616bf283a0acf5','actualcandidate')
 ledger=load(S/'attempts.json');term=load(S/'terminal.json');need(0<len(ledger)<=150 and term['loaderCalls']==len(ledger) and term['allCallsClosed'] is True,'closedledger')
 failure=(S/'failure.json').exists();need(term['failure']==failure,'failuremarker');failureRecord=load(S/'failure.json') if failure else None
 loader=pr['referencePins']['loader']['path'];arms=[('baseline',pr['referencePins']['baseline']['path']),('reference',pr['referencePins']['reference']['path']),('candidate',c['candidateProducer']['path'])]
 compiler={'KEXE_COMMAND':'1','KEXE_CAP_RESOURCES_35':str(S),'KEXE_STRING_POOL':'268435456','KEXE_VECTORS':'4194304','KEXE_PAIRS':'16777216','KEXE_VECTOR_ITEMS':'134217728','KEXE_CPU_SECONDS':'1800','KEXE_WALL_SECONDS':'1800'}
 guest={'KEXE_ARG_TYPES':'i64','KEXE_RESULT_TYPE':'i64','KEXE_STRUCTURED_REPORT':'1','KEXE_FUEL':'16777216','KEXE_VECTORS':'4096','KEXE_VECTOR_ITEMS':'65536','KEXE_CPU_SECONDS':'30','KEXE_WALL_SECONDS':'30'}
 # Rehash every saved raw/metadata/artifact, including unused failed-case files.
 for p in S.rglob('*'):
  if p.is_file() and (p.is_relative_to(S/'outputs') or p.name in ['cases-results.json','report.json','failure.json','terminal.json','attempts.json']):read(p)
 for i,r in enumerate(ledger,1):
  need(r['index']==i and r['state']=='terminal','indicesclosed');pin(S/'outputs'/(r['label']+'.stdout'),r['stdoutSHA256']);pin(S/'outputs'/(r['label']+'.stderr'),r['stderrSHA256']);pin(r['argv'][1],r['imageSHA256'])
 cursor=0;completed=[];location=None
 def call(label,argv,env,timeout):
  nonlocal cursor,location
  location=label;need(cursor<len(ledger),('missingexpectedcall',label));r=ledger[cursor];cursor+=1
  need(r['label']==label and r['argv']==argv and r['kexeEnvironment']==env and r['timeoutSeconds']==timeout,('argv/env',label))
  out=read(S/'outputs'/(label+'.stdout'));err=read(S/'outputs'/(label+'.stderr'));rc=r['returncode'];valid(rc is not None and rc>=0,'timeout/unsupervisedsignal');return out,err,rc
 def binary(arm,target,exports,out):
  offsets=re.findall(rb':offset (\d+)\b',out);valid(len(offsets)==1,'uniqueoffset');off=int(offsets[0]);raw=read(target/(arm+'.kseed'));b=read(target/(arm+'.bin'))
  head,sep,payload=raw.partition(b'\n\n');valid(bool(sep),'containerseparator');lines=head.decode('ascii').splitlines();m=re.fullmatch(r'KSEED1 (\d+) (\d+)',lines[0]);valid(m is not None,'containerheader');rows=[]
  for line in lines[1:]:
   z=re.fullmatch(r'(\S+) (\d+) (\d+)',line);valid(z is not None,'exportsyntax');rows.append((z[1],int(z[2]),int(z[3])))
  valid(len(rows)==int(m[2])==len(exports) and len(set(z[0] for z in rows))==len(rows),'exportcount');valid({z[0]:z[2] for z in rows}==exports,'exportarity');valid(next(z[1] for z in rows if z[0]=='bench')==off,'benchoffset')
  valid(len(payload)==int(m[1]) and payload==b and len(b)%4==0 and all(z[1]%4==0 and 0<=z[1]<len(b) for z in rows),'payload')
  return {'raw':raw,'bin':b,'offset':off,'words':list(struct.unpack('<'+'I'*(len(b)//4),b))}
 actualFailure=None
 try:
  for case in cases:
   name=case['name'];target=S/'outputs'/name;statuses=[];kind=None
   pin(S/case['fixture'],case['sha256'])
   for arm,image in arms:
    argv=[loader,image,'0','0','aarch64','35,37,38,39','--','compile',str(S/case['fixture']),'--target','aarch64-macos','--output',str(target/(arm+'.kseed'))]
    q=call(name+'-'+arm+'-compile',argv,compiler,1810);out,err,rc=q
    success=rc==0 and not err and b':ok true'in out and b':ok false'not in out
    refusal=case['allowMatchedCompilerRefusal'] and rc in (0,1,2) and not err and b':ok false'in out and b':ok true'not in out
    valid(success or refusal,'immediate unexpected compile failure');newkind='success' if success else 'refusal'
    valid(kind is None or kind==newkind,'immediate mixed compilekind');valid(newkind!='refusal' or not statuses or q==statuses[0],'immediate different refusaltuple');kind=newkind;statuses.append(q)
   if kind=='refusal':completed.append({'case':name,'status':'MATCHED_COMPILER_REFUSAL_NO_RUNTIME_QUALIFICATION','functionalCalls':0});continue
   artifacts={}
   for arm,image in arms:
    out,err,rc=call(name+'-'+arm+'-extract',[loader,image,'0','0','aarch64','35,37,38,39','--','extract-native',str(target/(arm+'.kseed')),'--symbol','bench','--output',str(target/(arm+'.bin'))],compiler,1810)
    valid(rc==0 and not err and b':ok true'in out,'extractsuccess');artifacts[arm]=binary(arm,target,case['exports'],out)
   b,r,cand=[artifacts[x] for x in ['baseline','reference','candidate']];valid(b['raw']==r['raw'] and b['bin']==r['bin'],'baseline/referencewholeparity')
   if case['expectSingleBoundsOmission']:
    try:cuts=[cmp.compare_words(ref['words'],cand['words'],ref['offset'],cand['offset']) for ref in [b,r]]
    except AssertionError as ex:raise ActualFailure('positive structural '+repr(ex))
    structural=cuts[0];valid(cuts[0]==cuts[1],'bothreferencecuts')
   else:valid(r['raw']==cand['raw'] and r['bin']==cand['bin'],'negativewholetriple');structural={'status':'WHOLE_TRIPLE_NATIVE_AND_CONTAINER_IDENTICAL'}
   obs=[]
   for n in case['inputs']:
    paired=[]
    for arm,_ in arms:
     a=artifacts[arm];q=call(name+'-'+arm+'-n'+str(n),[loader,str(target/(arm+'.bin')),str(a['offset']),'1','aarch64','-',str(n)],guest,40);v=functional(q,case['expected'][str(n)]);paired.append(q);obs.append({'arm':arm,'n':n,'receipt':{'expected':case['expected'][str(n)],'fuelAndArenas':v}})
    valid(paired[0]==paired[1]==paired[2],'fulltriplefunctionaltuple')
   completed.append({'case':name,'status':'FINITE_STRUCTURAL_AND_FUNCTIONAL_PARITY','structural':structural,'observations':obs,'causeGuardReached':'UNQUALIFIED_NO_INTERNAL_METADATA','sourceRuntimeLimit':case['runtimeLimit']})
 except ActualFailure as ex:actualFailure={'at':location,'reason':str(ex),'callsAtFirstKnownFailure':cursor}
 need(cursor==len(ledger),'unexpected attempts after first knownfailure orcaseend')
 need(failure==(actualFailure is not None),'driverfailure versus rawfirstfailure')
 if failure:need(failureRecord['loaderCalls']==cursor and failureRecord['policy']=='STOP_FIRST_FAILURE_NO_RETRY_OR_WEAKENING','failurecounter/policy')
 if (S/'cases-results.json').exists():need(load(S/'cases-results.json')==completed,'completedrecords')
 if not failure:
  need(len(completed)==10,'complete10');stored=load(S/'report.json');partial=any(x['status']=='MATCHED_COMPILER_REFUSAL_NO_RUNTIME_QUALIFICATION' for x in completed)
  need(stored['status']==('PARTIAL_RUNTIME_COVERAGE_WITH_PRESERVED_COMPILER_REFUSALS' if partial else 'PASS_FINITE_TEN_FIXTURE_PARITY_ONLY') and stored['loaderCalls']==cursor and stored['cases']==completed,'storedreportconsistent')
 for p,r in list(seen.items()):pin(p,r['sha256'],r['bytes'])
 save('input-pins.json',seen)
 save('report.json',{'status':'PASS_INDEPENDENT_RAW_AUDIT_PRESERVED_ACTUAL_FAILURE' if failure else 'PASS_INDEPENDENT_RAW_FINITE_SUITE_ONLY','actualSuiteResult':'FAIL_STOP_FIRST_FAILURE' if failure else ('PARTIAL_RUNTIME' if any(x['status'].startswith('MATCHED_') for x in completed) else 'PASS_FINITE_PARITY'),'recordedCalls':cursor,'maximumCalls':150,'nativeCallsByReviewer':0,'firstKnownFailure':actualFailure,'preservedDriverFailure':failureRecord,'completedCases':completed,'allSavedArtifactsRehashedAfterClosure':True,'inputPinsSHA256':sha((D/'input-pins.json').read_bytes()),'dirtyPartialSealQualified':False,'selfOnlyHelperExecuted':False,'original19Qualified':False,'timing':False,'CgainQualified':False,'runtimeCIDQualified':False,'productAdopted':False})
if __name__=='__main__':
 try:audit()
 except BaseException as ex:save('audit-failure.json',{'status':'HOLD_RAW_AUDIT_INTEGRITY','exception':repr(ex),'nativeCalls':0});raise
 print('OFFLINE_RAW_AUDIT_COMPLETE')
