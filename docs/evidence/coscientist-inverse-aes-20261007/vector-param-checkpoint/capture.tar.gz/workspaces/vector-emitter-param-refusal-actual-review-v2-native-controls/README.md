独立 raw 監査では保存済み evidence の整合性を確認した。対象スイート自体は FAIL のまま。先頭 3 ケースは計 45 呼び出しで構造・符号付き数値・trap・fuel・arena の 3 arm 一致を満たした。unequal-min は 536→524 B、唯一の 12 B bounds trio を省略し、両 reference と比較。short-zero と exported-target は全 KSEED/native が triple exact、負入力は SIGILL/rc120・正の残存 fuel を保存した。

46 番目の address-taken-direct baseline compile は rc1、空 stdout、E2102 stderr を返し、許容済み拒否契約に合わなかったため即停止。後続呼び出しなし。残る 6 ケースは未実行。対象の FAIL を PASS に読み替えていない。監査はネイティブ再実行なし。内部 dirty/partial seal、self-only helper 実行、元 19 workload、性能、CID runtime、製品採用は対象外。
