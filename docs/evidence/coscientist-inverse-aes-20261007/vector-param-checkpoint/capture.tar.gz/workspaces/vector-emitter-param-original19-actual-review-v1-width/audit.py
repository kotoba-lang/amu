from pathlib import Path
import json,hashlib,re,sys,importlib.util,struct
W=Path(__file__).resolve().parent;D=W.parent/'vector-emitter-param-original19-run-v1-root';P=W.parent/'vector-emitter-param-original19-plan-v1-controls';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());pins={}
def bind(p):pins[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size};return p.read_bytes()
def jl(p):bind(p);return load(p)
sp=jl(P/'source-pins.json');ip=jl(P/'input-pins.json');pr=jl(P/'preregistration.json');go=jl(D/'authorization.json')
assert sha(P/'source-pins.json')=='017e4f1eda44c2e45cb20e2854f32b144d1f145b90e964e3470efd6d96987a5c'
for n,h in sp.items():assert sha(P/n)==h;bind(P/n)
for f,r in ip.items():q=Path(f);assert sha(q)==r['sha256']and q.stat().st_size==r['bytes'];bind(q)
assert go['original19CompilationAuthorized'] is True and go['maximumLoaderCalls']==38 and go['sourcePinsSHA256']==sha(P/'source-pins.json') and go['outputDirectory']==str(D) and go['positiveActualIndependentAccepted'] is True and go['sourceResourceReviewsAccepted'] is True
for key in ['positiveIndependentReview','independentOriginal19SourceReview']:
 q=Path(go[key]);assert sha(q)==go[key+'SHA256'];bind(q)
t=jl(D/'terminal.json');assert t=={'allCallsClosed':True,'loaderCalls':38,'completedImages':19,'failure':False}and not(D/'failure.json').exists()
a=jl(D/'attempts.json');im=jl(D/'images.json');mat=jl(D/'source-materialization.json');ev=jl(D/'environment.json');published=jl(D/'machine-validation.json');assert len(a)==38 and len(im)==len(mat)==len(published)==len(pr['entries'])==19
B=Path(pr['candidateDirectory']);assert sha(B/'candidate.bin')==pr['candidateSHA256']and sha(B/'unity.kotoba')==pr['candidateSourceSHA256']
env={'KEXE_COMMAND':'1','KEXE_CAP_RESOURCES_35':str(D),'KEXE_CPU_SECONDS':'1800','KEXE_WALL_SECONDS':'1800','KEXE_STRING_POOL':'268435456','KEXE_VECTORS':'4194304','KEXE_PAIRS':'16777216','KEXE_VECTOR_ITEMS':'134217728'};assert ev['kexeEnvironment']==env and ev['scope35']==str(D) and all(x.startswith('KEXE_')for x in ev['allInheritedKexeRemoved'])
sys.dont_write_bytecode=True;sys.path.insert(0,str(P));spec=importlib.util.spec_from_file_location('frozen_machine',P/'machine.py');machine=importlib.util.module_from_spec(spec);spec.loader.exec_module(machine)
rows=[];computed=[];checks=[]
for ix,(e,image,m)in enumerate(zip(pr['entries'],im,mat)):
 n=e['workload'];d=D/'ports'/n;src=D/'sources'/(n+'.kotoba');origin=Path(e['source']);base=Path(e['baselineDirectory']);assert m=={'workload':n,'origin':str(origin),'copy':str(src),'sha256':sha(src)} and bind(src)==origin.read_bytes() and sha(src)==ip[str(origin)]['sha256']
 for j,stage in enumerate(['compile','extract']):
  r=a[ix*2+j];args=['compile',str(src),'--target','aarch64-macos','--output',str(d/'image.kseed')]if j==0 else['extract-native',str(d/'image.kseed'),'--symbol',e['symbol'],'--output',str(d/'native.bin')];cmd=[str(B/'kexe-loader'),str(B/'candidate.bin'),'0','0','aarch64','35,37,38,39','--',*args]
  assert r['index']==ix*2+j+1 and r['workload']==n and r['stage']==stage and r['argv']==cmd and r['kexeEnvironment']==env and r['removedInheritedKexeKeys']==ev['allInheritedKexeRemoved'] and r['producerSHA256']==pr['candidateSHA256'] and r['sourceSHA256']==sha(src) and r['timeoutSeconds']==1810 and r['state']=='terminal'and r['returncode']==0
  out=bind(d/(stage+'.stdout'));err=bind(d/(stage+'.stderr'));assert not err and b':ok true'in out and hashlib.sha256(out).hexdigest()==r['stdoutSHA256']and hashlib.sha256(err).hexdigest()==r['stderrSHA256']
 new,ne=machine.container(d/'image.kseed');old,oe=machine.container(base/'image.kseed');assert new==bind(d/'native.bin') and old==base.joinpath('native.bin').read_bytes();bind(d/'image.kseed');off=int(bind(d/'native.offset'));assert [x[1]for x in ne if x[0]==e['symbol']]==[off] and [(x[0],x[2])for x in ne]==[(x[0],x[2])for x in oe];matches=re.findall(rb':offset (\d+)\b',(d/'extract.stdout').read_bytes());assert len(matches)==1 and int(matches[0])==off
 expected={'workload':n,'symbol':e['symbol'],'sourceSHA256':sha(src),'nativeSHA256':sha(d/'native.bin'),'containerSHA256':sha(d/'image.kseed'),'bytes':len(new),'offset':off,'baselineNativeSHA256':sha(base/'native.bin'),'wholePayloadEqual':new==old};assert image==expected
 try:v=machine.folder_validation(base,d)
 except AssertionError as exc:v={'status':'HOLD_UNREGISTERED_OR_UNPROVEN_DIFFERENCE','reason':str(exc),'actualSites':'UNQUALIFIED'}
 computed.append({'workload':n,**v})
 if v['status']=='PASS_REGISTERED_MULTI_SITE_BOUNDS_ONLY':
  # Independently remap every retained instruction/export using exact published cuts.
  ow=struct.unpack('<'+'I'*(len(old)//4),old);nw=struct.unpack('<'+'I'*(len(new)//4),new);cuts=sorted((x['oldCutByte']//4,x['oldCutByte']//4+3)for x in v['cuts']);mapping=lambda i:i-sum(hi-lo for lo,hi in cuts if i>=hi);outwords=[];branchchanges=[]
  for pc,word in enumerate(ow):
   if any(lo<=pc<hi for lo,hi in cuts):continue
   if word&0x7c000000==0x14000000:bits,shift=26,0
   elif word&0xff000010==0x54000000:bits,shift=19,5
   elif word&0x7e000000==0x34000000:bits,shift=19,5
   elif word&0x7e000000==0x36000000:bits,shift=14,5
   else:outwords.append(word);continue
   mask=((1<<bits)-1)<<shift;vimm=(word&mask)>>shift;delta=vimm-(1<<bits)if vimm&(1<<(bits-1))else vimm;dest=pc+delta;assert not any(lo<=dest<hi for lo,hi in cuts);newdelta=mapping(dest)-mapping(pc);mapped=(word&~mask)|((newdelta&((1<<bits)-1))<<shift);outwords.append(mapped)
   if mapped!=word:branchchanges.append({'oldByte':pc*4,'oldWord':hex(word),'newWord':hex(mapped)})
  assert tuple(outwords)==nw and branchchanges==v['branchRelocations'] and [(name,mapping(of//4)*4,ar)for name,of,ar in oe]==ne
  for q in v['cuts']:
   lo=q['oldCutByte']//4;assert ow[lo:lo+3]==(0xeb00001f+(16<<16)+(q['ri']<<5),0x54000043,0);j=q['readWord'];nj=mapping(j);assert ow[j:j+9]+ow[j+12:j+15]==nw[nj:nj+12]
  checks.append({'workload':n,'sites':len(cuts),'allOtherWordsBranchesExportsAndHchkExactIndependent':True})
 rows.append(expected|{'exports':ne,'baselineExports':oe,'baselineBytes':len(old),'machineStatus':v['status']})
assert computed==published
holds=[{'workload':x['workload'],'reason':x['reason']}for x in computed if x['status'].startswith('HOLD')];accepted=[x for x in computed if x['status']=='PASS_REGISTERED_MULTI_SITE_BOUNDS_ONLY'];equal=[x['workload']for x in computed if x['status']=='PASS_WHOLE_PAYLOAD_AND_EXPORTS_EXACT_ZERO_OMISSIONS'];assert len(holds)==4 and len(equal)==12 and {x['workload']:x['actualSites']for x in accepted}=={'nettle-sha256':11,'tarfind':1,'ud':1}
rep=jl(D/'report.json');assert rep=={'status':'HOLD_MACHINE_QUALIFICATION_AFTER38_SUCCESSFUL_COMPILER_CALLS','loaderCalls':38,'images':19,'machineHolds':4,'actualRegisteredOmissions':13,'functionalCalls':0,'timing':False,'runtimeCID':False,'performanceQualified':False}
# Required terminal rebind entire originalsource/baseline/raw/candidate/plan sets.
for f,r in ip.items():q=Path(f);assert sha(q)==r['sha256']and q.stat().st_size==r['bytes']
for n,h in sp.items():assert sha(P/n)==h
r={'status':'PASS_INDEPENDENT_RAW38_AUDIT_WITH_FOUR_MACHINE_HOLDS_PRESERVED','nativeReruns':0,'loaderCalls':38,'originalModules':19,'terminalAllInputAndSourcePinsRebound':True,'candidateProducerSHA256':pr['candidateSHA256'],'candidateSourceSHA256':pr['candidateSourceSHA256'],'actualRegisteredOmissions':13,'acceptedOmissionsByWorkload':{'nettle-sha256':11,'tarfind':1,'ud':1},'wholePayloadExportEqual12':equal,'unqualifiedHolds4':holds,'independentAcceptedWholeWordMapping':checks,'rows':rows,'recomputedMachineValidation':computed,'scope':'compiler/extraction and registered machine evidence only; no fullcohort functional qualification','heldArtifactsEligibleForTiming':False,'functionalBenchmarkCalls':0,'timing':False,'Cperformance':False,'fullSelfhostProjectAdoption':False,'limitations':['13 certified machine deletions across3 workloads, not34/44analysispotential','HOLD4 remain unqualified; no relaxeddata/pool/unknownsite rules','ContextProof seal internals not directly observed; frozen source guard plus pinned baselinecertifiedsite linkage','no fulloriginal19 runtime/fuel/arena/Embench execution orCratio from38compilecalls'],'pins':pins};(W/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(sha(W/'report.json'))
