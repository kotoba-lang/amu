"""Prospective finite triple-arm source-only harness; root GO required."""
from pathlib import Path
import hashlib, json, os, re, struct, subprocess
import compare
D = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(ok, why):
    if not ok: raise AssertionError(why)
def save(name, value):
    (D/name).write_text(json.dumps(value, indent=2)+'\n')

def container(seed, binary, exports, offset):
    raw=seed.read_bytes(); header, payload=raw.split(b'\n\n',1)
    lines=header.decode('ascii').splitlines()
    m=re.fullmatch(r'KSEED1 (\d+) (\d+)',lines[0]); require(m,'container header')
    rows=[]
    for line in lines[1:]:
        z=re.fullmatch(r'(\S+) (\d+) (\d+)',line); require(z,'export syntax')
        rows.append((z[1],int(z[2]),int(z[3])))
    require(len(rows)==int(m[2]) and len(rows)==len(exports),'export count')
    require(len({z[0] for z in rows})==len(rows),'unique exports')
    require({z[0]:z[2] for z in rows}==exports,'exact export names/arities')
    require(next(z[1] for z in rows if z[0]=='bench')==offset,'bench offset')
    require(len(payload)==int(m[1]) and payload==binary.read_bytes(),'whole payload')
    require(len(payload)%4==0 and all(z[1]%4==0 and 0<=z[1]<len(payload) for z in rows),'export alignment/range')
    return list(struct.unpack('<'+'I'*(len(payload)//4),payload))

TAIL=(rb' :fuel \{:initial (\d+) :remaining (\d+)\}'
      rb' :heap \{:capacity (\d+) :used (\d+)\}'
      rb' :string-pool \{:capacity (\d+) :used (\d+)\}'
      rb' :vectors \{:capacity (\d+) :used (\d+)\}'
      rb' :vector-items \{:capacity (\d+) :used (\d+)\}\}\n')
def functional(out, err, rc, expected):
    if expected=='SIGILL':
        require(rc==120 and err==b'KEXE_TRAP {:kind :signal :signal :SIGILL}\n','exact expected vector trap')
        m=re.fullmatch(rb'\{:status :trap :exit 120'+TAIL,out)
    else:
        require(rc==0 and not err,'successful scalar call')
        m=re.fullmatch(rb'\{:status :ok :result (-?\d+)'+TAIL,out)
    require(m is not None,'exact metered structured report')
    values=list(map(int,m.groups()))
    if expected!='SIGILL':
        require(values[0]==expected,'independent mathematical oracle'); values=values[1:]
    require(values[0]==16777216 and 0<values[1]<=values[0],'fixed positive remaining fuel, no fuel exhaustion')
    require(values[6]==4096 and values[8]==65536,'fixed vector/item capacities')
    for cap,used in zip(values[2::2],values[3::2]): require(0<=used<=cap,'arena bounds')
    return {'expected':expected,'fuelAndArenas':values}

def execute():
    go=json.loads((D/'parent-go.json').read_text()); pins=json.loads((D/'source-pins.json').read_text())
    require(go.get('authorizeNative') is True and go.get('maximumLoaderCalls')==150,'root finite150 GO')
    require(go.get('sourcePinsSHA256')==sha(D/'source-pins.json'),'root binds frozen source')
    require(go.get('candidateInputSHA256')==sha(D/'candidate-input.json'),'root actual candidate pins')
    prereg=json.loads((D/'preregistration.json').read_text()); candidate=json.loads((D/'candidate-input.json').read_text())
    require(candidate.get('parameterBridgeON') is True and candidate.get('returnedOrExportedParameterRelaxation') is False,'parameter-only candidate')
    require(go.get('candidateSourceSHA256')==candidate['candidateSource']['sha256'],'root exact source approval')
    require(go.get('sourceReviewReceiptSHA256')==candidate['sourceReviewReceipt']['sha256'],'root exact source/resource review')
    fixed=[*prereg['referencePins'].values(),*[candidate[k] for k in ('candidateProducer','candidateSource','candidateBuild','sourceReviewReceipt')]]
    def guard():
        require(go['candidateInputSHA256']==sha(D/'candidate-input.json'),'actual candidate descriptor stays frozen')
        for name,h in pins.items(): require(sha(D/name)==h,('frozen source',name))
        for row in fixed:
            require(re.fullmatch(r'[0-9a-f]{64}',row['sha256']) and row['bytes']>0,'actual input schema')
            require(sha(row['path'])==row['sha256'] and Path(row['path']).stat().st_size==row['bytes'],'fixed input hash/size')
    guard(); require(not(D/'attempts.json').exists() and not(D/'outputs').exists(),'fresh no retries')
    (D/'outputs').mkdir(); rows=[]; completed=[]
    base={k:v for k,v in os.environ.items() if not k.startswith('KEXE_')}
    compiler={'KEXE_COMMAND':'1','KEXE_CAP_RESOURCES_35':str(D),'KEXE_STRING_POOL':'268435456','KEXE_VECTORS':'4194304','KEXE_PAIRS':'16777216','KEXE_VECTOR_ITEMS':'134217728','KEXE_CPU_SECONDS':'1800','KEXE_WALL_SECONDS':'1800'}
    guest={'KEXE_ARG_TYPES':'i64','KEXE_RESULT_TYPE':'i64','KEXE_STRUCTURED_REPORT':'1','KEXE_FUEL':'16777216','KEXE_VECTORS':'4096','KEXE_VECTOR_ITEMS':'65536','KEXE_CPU_SECONDS':'30','KEXE_WALL_SECONDS':'30'}
    loader=prereg['referencePins']['loader']['path']
    producers=[('baseline',prereg['referencePins']['baseline']['path']),('reference',prereg['referencePins']['reference']['path']),('candidate',candidate['candidateProducer']['path'])]
    def call(label, argv, env, timeout):
        guard(); require(len(rows)<150,'finite call cap')
        row={'index':len(rows)+1,'label':label,'argv':argv,'kexeEnvironment':env,'imageSHA256':sha(argv[1]),'state':'started','timeoutSeconds':timeout}
        rows.append(row); save('attempts.json',rows)
        try:
            p=subprocess.run(argv,env=base|env,capture_output=True,timeout=timeout);out,err,rc=p.stdout,p.stderr,p.returncode
        except subprocess.TimeoutExpired as e: out,err,rc=e.stdout or b'',e.stderr or b'',None
        (D/'outputs'/(label+'.stdout')).write_bytes(out);(D/'outputs'/(label+'.stderr')).write_bytes(err)
        row.update(state='terminal',returncode=rc,stdoutSHA256=hashlib.sha256(out).hexdigest(),stderrSHA256=hashlib.sha256(err).hexdigest());save('attempts.json',rows)
        guard(); require(rc is not None and rc>=0,'timeout or unsupervised compiler/loader signal')
        return out,err,rc
    try:
        for case in json.loads((D/'cases.json').read_text()):
            name=case['name']; target=D/'outputs'/name;target.mkdir(); status=[]; artifacts={}
            for arm,image in producers:
                argv=[loader,image,'0','0','aarch64','35,37,38,39','--','compile',str(D/case['fixture']),'--target','aarch64-macos','--output',str(target/(arm+'.kseed'))]
                status.append(call(name+'-'+arm+'-compile',argv,compiler,1810))
            if not all(rc==0 and not err and b':ok true' in out for out,err,rc in status):
                require(case['allowMatchedCompilerRefusal'] and status[0]==status[1]==status[2] and status[0][2] in (0,1,2) and not status[0][1] and b':ok false' in status[0][0] and b':ok true' not in status[0][0],'exact declared compiler refusal only')
                completed.append({'case':name,'status':'MATCHED_COMPILER_REFUSAL_NO_RUNTIME_QUALIFICATION','functionalCalls':0});save('cases-results.json',completed);continue
            for arm,image in producers:
                seed=target/(arm+'.kseed'); binary=target/(arm+'.bin')
                argv=[loader,image,'0','0','aarch64','35,37,38,39','--','extract-native',str(seed),'--symbol','bench','--output',str(binary)]
                out,err,rc=call(name+'-'+arm+'-extract',argv,compiler,1810)
                require(rc==0 and not err and b':ok true' in out,'successful extract')
                offsets=re.findall(rb':offset (\d+)\b',out);require(len(offsets)==1,'unique bench offset');offset=int(offsets[0])
                artifacts[arm]={'seed':seed,'binary':binary,'offset':offset,'words':container(seed,binary,case['exports'],offset)}
            b=artifacts['baseline'];r=artifacts['reference'];c=artifacts['candidate']
            require(b['seed'].read_bytes()==r['seed'].read_bytes() and b['binary'].read_bytes()==r['binary'].read_bytes(),'C2a and c75 exact fixture reference parity')
            if case['expectSingleBoundsOmission']:
                structural=compare.compare_words(r['words'],c['words'],r['offset'],c['offset'])
                require(case['exports']=={'bench':1},'positive solebench comparator contract')
            else:
                require(r['seed'].read_bytes()==c['seed'].read_bytes() and r['binary'].read_bytes()==c['binary'].read_bytes(),'refusal preserves whole original KSEED/native')
                structural={'status':'WHOLE_TRIPLE_NATIVE_AND_CONTAINER_IDENTICAL'}
            observations=[]
            for n in case['inputs']:
                paired=[]
                for arm,_ in producers:
                    x=artifacts[arm];q=call(name+'-'+arm+'-n'+str(n),[loader,str(x['binary']),str(x['offset']),'1','aarch64','-',str(n)],guest,40)
                    receipt=functional(*q,case['expected'][str(n)]);paired.append(q);observations.append({'arm':arm,'n':n,'receipt':receipt})
                require(paired[0]==paired[1]==paired[2],'exact triple status/stdout/stderr/fuel/arenas')
            completed.append({'case':name,'status':'FINITE_STRUCTURAL_AND_FUNCTIONAL_PARITY','structural':structural,'observations':observations,'causeGuardReached':'UNQUALIFIED_NO_INTERNAL_METADATA','sourceRuntimeLimit':case['runtimeLimit']});save('cases-results.json',completed)
        require(len(completed)==10,'fixed ten cases only')
        partial=any(x['status']=='MATCHED_COMPILER_REFUSAL_NO_RUNTIME_QUALIFICATION' for x in completed)
        save('report.json',{'status':'PARTIAL_RUNTIME_COVERAGE_WITH_PRESERVED_COMPILER_REFUSALS' if partial else 'PASS_FINITE_TEN_FIXTURE_PARITY_ONLY','loaderCalls':len(rows),'cases':completed,'internalDirtyPartialSealQualified':False,'original19Qualified':False,'timing':False,'performanceQualified':False,'CIDRuntimeQualified':False})
    except BaseException as e:
        save('failure.json',{'exception':repr(e),'loaderCalls':len(rows),'policy':'STOP_FIRST_FAILURE_NO_RETRY_OR_WEAKENING'});raise
    finally:
        save('terminal.json',{'allCallsClosed':all(x['state']=='terminal' for x in rows),'loaderCalls':len(rows),'failure':(D/'failure.json').exists()})
if __name__=='__main__': execute()
