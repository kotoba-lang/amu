import run, compare, json
s=compare.readseq(9,10,0)
old=[0x14000011]+s+[0xd65f03c0,0xd65f03c0]
new=[0x1400000e]+s[:9]+s[12:]+[0xd65f03c0,0xd65f03c0]
compare.compare_words(old,new,68,56)
rejected=[]
for i in (0,1,6,9,10,11,12,14):
 m=new.copy();m[i]^=1
 try: compare.compare_words(old,m,68,56)
 except AssertionError:rejected.append('structural-'+str(i))
 else:raise AssertionError('accepted structural mutation')
tail=b' :fuel {:initial 16777216 :remaining 16777000} :heap {:capacity 4096 :used 0} :string-pool {:capacity 65536 :used 0} :vectors {:capacity 4096 :used 1} :vector-items {:capacity 65536 :used 4}}\n'
ok=b'{:status :ok :result 28'+tail
trap=b'{:status :trap :exit 120'+tail
err=b'KEXE_TRAP {:kind :signal :signal :SIGILL}\n'
run.functional(ok,b'',0,28);run.functional(trap,err,120,'SIGILL')
for name,args in [
 ('wrong-oracle',(ok,b'',0,7)),('wrong-exit',(trap,err,123,'SIGILL')),
 ('missing-trapline',(trap,b'',120,'SIGILL')),('extra-trapline',(trap,err+err,120,'SIGILL')),
 ('wrong-signal',(trap,err.replace(b'SIGILL',b'SIGSEGV'),120,'SIGILL')),
 ('wrong-report',(ok,err,120,'SIGILL')),('duplicate-report',(trap+trap,err,120,'SIGILL')),
 ('budget-fuel',(trap.replace(b':remaining 16777000',b':remaining 0'),err,120,'SIGILL')),
 ('unmetered',(trap.replace(b':remaining 16777000}',b':remaining 16777000 :metered false}'),err,120,'SIGILL')),
 ('arena-overflow',(trap.replace(b':used 4}',b':used 65537}'),err,120,'SIGILL'))]:
 try:run.functional(*args)
 except AssertionError:rejected.append(name)
 else:raise AssertionError('accepted report mutation '+name)
print(json.dumps({'status':'PASS_OFFLINE_STRUCTURAL_SUCCESS_TRAP_VALIDATOR_TESTS','nativeCalls':0,'rejects':rejected},indent=2))
