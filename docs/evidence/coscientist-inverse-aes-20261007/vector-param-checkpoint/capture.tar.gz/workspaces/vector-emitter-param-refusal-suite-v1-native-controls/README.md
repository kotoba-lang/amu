この packet は SOURCE ONLY の有限計画です。ネイティブ実行、候補のコンパイル、実際の拒否理由の到達を認定していません。

10 fixture × 3 arm（固定 V8 C2a、固定 local c75、parameter ON の将来候補）。各 fixture は compile3 + extract3 + input3×guest3 = 最大15回、合計最大150回です。宣言済みの escaped/indirect fixture が全3 armで同じ :ok false を返す場合は compiler refusal として保存し、runtime を試しません。余った予算は転用しません。

unequal-min と self-neutral-grounded は1か所12 Bの実際の省略を要求します。普通の mode0になるかは仮説です。省略されなければ失敗で、同一 payload の結果へ基準を変更しません。残る拒否例は、3 arm の全 KSEED・native bytes の一致を要求します。全 fixture で baseline C2a と reference c75 の実際の全 bytes 一致を先に検査します。

runtime が実行される場合、成功は独立の数式期待値を満たし、trap は rc120 と SIGILL の1行、:trap :exit120 の metered report、正の remaining fuel、全 arena 境界を要求します。status/stdout/stderr/fuel/arena は3 armで完全一致を要求します。非定数 index は入力0/1/-1、他は0/7/-1に固定しています。

self-only-unreachable は helper がどこからも呼ばれない source と code の拒否対照です。benchだけを実行し、self helperの実行や trap を確認したとは言いません。address-taking/indirect の実際の lowered cause と最適化 guard 到達は、内部 metadata の独立証拠がないため未認定です。

未実施・未包含: dirty seal、途中の seal publication、work cap 境界、seal 改竄、typed ordinal/body/key の偽造、invalid handle、未対応 effect/CAP/CALLI の内部状態 probe。これらは別の登録・source review・root GOが要ります。original19/selfhost/CPU timing/C性能/CID実装の認定を含みません。

candidate-input.json と parent-go.json は意図的に存在しません。rootが actual candidate producer/source/build/source-review の hash+size を指定し、その descriptor・source・review・source manifest を結び付けた最大150回の GO を出すまで実行できません。全 inherited KEXE を除き、wire35はこの fixture/output folder のみ、機能呼出しは COMMANDなし/mask-です。途中の原稿を実行しないでください。
