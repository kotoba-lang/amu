from pathlib import Path
import json,hashlib,ast,re
W=Path(__file__).resolve().parent;D=W.parent/'vector-emitter-param-refusal-suite-v1-native-controls';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
c=load(D/'completion.json');assert sha(D/'completion.json')=='db60b8a07c22edf3686b0dfadd6c98df6719477c4413586b937d563026f88bde'
for n,row in c['files'].items():assert sha(D/n)==row['sha256'] and(D/n).stat().st_size==row['bytes']
pins=load(D/'source-pins.json')
for n,h in pins.items():assert sha(D/n)==h
cases=load(D/'cases.json');assert len(cases)==10 and sum(x['allowMatchedCompilerRefusal']for x in cases)==2
expected={'unequal-min':{'0':0,'7':28,'-1':-4},'short-zero':{'0':0,'7':14,'-1':'SIGILL'},'exported-target':{'0':0,'7':14,'-1':'SIGILL'},'address-taken-direct':{'0':0,'7':14,'-1':'SIGILL'},'indirect-unknown':{'0':0,'7':14,'-1':'SIGILL'},'external-root-unknown':{'0':0,'7':14,'-1':'SIGILL'},'self-neutral-grounded':{'0':0,'7':7,'-1':-1},'self-only-unreachable':{'0':0,'7':7,'-1':-1},'nonconstant-index':{'0':0,'1':0,'-1':'SIGILL'},'returned-origin':{'0':0,'7':14,'-1':-2}}
for case in cases:assert case['expected']==expected[case['name']] and sha(D/case['fixture'])==case['sha256']
tree=ast.parse((D/'run.py').read_text());selected=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in ['functional','require'] or isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='TAIL'for t in n.targets)];e={'re':re};exec(compile(ast.Module(body=selected,type_ignores=[]),'<offline-parser>','exec'),e)
positive=0;rejected=0
for case in cases:
 for value in case['expected'].values():
  tail=b' :fuel {:initial 16777216 :remaining 16777214} :heap {:capacity 4096 :used 0} :string-pool {:capacity 65536 :used 0} :vectors {:capacity 4096 :used 2} :vector-items {:capacity 65536 :used 6}}\n'
  if value=='SIGILL':out=b'{:status :trap :exit 120'+tail;err=b'KEXE_TRAP {:kind :signal :signal :SIGILL}\n';rc=120
  else:out=f'{{:status :ok :result {value}'.encode()+tail;err=b'';rc=0
  e['functional'](out,err,rc,value);positive+=1
  for a,b,c in [(out.replace(b':remaining 16777214',b':remaining 0'),err,rc),(out+b'x',err,rc),(out,err,1),(out.replace(b':used 6',b':used 65537'),err,rc)]:
   try:e['functional'](a,b,c,value)
   except AssertionError:rejected+=1
   else:raise AssertionError(case['name'])
r={'status':'HOLD_V1_STOP_FIRST_UNEXPECTED_COMPILE_FAILURE_POLICY_MISMATCH','nativeGO':False,'nativeCalls':0,'completionSHA256':sha(D/'completion.json'),'sourcePinsSHA256':sha(D/'source-pins.json'),'driverSHA256':sha(D/'run.py'),'frozenPins':pins,'veto':{'location':'run.py percase compile-arm loop before group status check','issue':'call only requires rc>=0. Unexpected compiler refusal/supervisedtrap/error is checked after completing all3 compile arms, so two furthercalls can occur after first unexpectedfailure.','correction':'Append-only v2 immediate percompile gate: success OR exact declared refusal candidate for only2 designated cases, rc0/1/2 emptyerr okfalse no oktrue; otherwise stop immediately. Declared all3 exactmatching remains PARTIAL.'},'sourceContractsReviewed':['10fixtures mathematicaloracles4n/2n/n/nonconstantzero/validshortvectorSIGILL independently checked','baseline2a/referencec75 entireKSEED/native equal beforecandidate; positive exactlysingle12B and retainedhchk wholeword branch oracle; negativefulltriplecontainer/native equal','sanitizedKEXE environment functionalCOMMANDabsent/mask-/arity1; exact structuredscalar orSIGILLrc120 stderrline trapreport with positivefuel; allstreams/status/fuel/arenas exacttriples','max150=60compiler/extract+90guest no budgetrepurposing afterdeclaredrefusal; no retries','only2 declaredcompilerrefusal cases can skipruntime; finalPARTIAL not runtimequalified','selfonlybody notexecuted and causeGuardReachedunqualified; address/indirectlowering notassumed','source/input/latecandidate pins guardbeforeafter; rootlatecandidateassembly/GO stillrequired'],'offlineParserPositiveCases':positive,'offlineParserRejectedMutants':rejected,'initialOfflineSchemaErrorPreservedSHA256':sha(W/'initial-offline-schema-error.json'),'limitations':['native/source mutation none','dirtyseal/partialpublication/key/type/body/invalidhandle/internalcause controls excluded','no original19/selfhost/Cperformance/CID/adoption proof']}
(W/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(sha(W/'report.json'))
