"""Independent stored-byte audit only; no execution/import of native or driver."""
from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent;W=D.parent
P=W/'vector-emitter-param-fixedpoint-plan-v1-root';A=W/'vector-emitter-param-fixedpoint-run-v1-root';C=W/'vector-emitter-param-native-build-v1-root'
sha=lambda b:hashlib.sha256(b).hexdigest()
seen={}
def read(p):
 p=Path(p); b=p.read_bytes();r={'sha256':sha(b),'bytes':len(b)}
 if str(p) in seen:assert seen[str(p)]==r,('input changed',p)
 seen[str(p)]=r;return b
def load(p):return json.loads(read(p))
def save(n,r):(D/n).write_text(json.dumps(r,indent=2)+'\n')
def pin(p,h,n=None):
 b=read(p);assert sha(b)==h,(p,'hash');assert n is None or len(b)==n,(p,'size');return b
SOURCE='ea8281843170b65999ff5a6460a2ba2b3474f04e8e5fda8abc616bf283a0acf5'
NATIVE='4158d7de2dfe4d922450b60788bb5f6a950ca129f92f0b841069aa4c0f76b509'
DRIVER='4dc302227148a7473c4be65723e82b46c3710991b161e40d6c469dc6c2a9dd03'
PR='f9f2491faac50bdfb387f4b3aff72b38f68ee251b0109a527bf51f8e8a98bfc1'
PINS='9df90a1d6bd8078964bc09359637484f0a857139f8fc8990a0d658eab683fc8e'
def audit():
 pin(P/'run-fixedpoint.py',DRIVER,5040);pin(P/'preregistration.json',PR,513);pin(P/'input-pins.json',PINS)
 pr=load(P/'preregistration.json');assert pr['maximumLoaderCalls']==6 and pr['candidateSHA256']==NATIVE and pr['candidateBytes']==943320 and pr['sourceSHA256']==SOURCE and pr['sourceBytes']==1137800 and pr['stopFirstFailure'] is True and pr['rerun'] is False
 for name,r in load(P/'input-pins.json').items():pin(name,r['sha256'],r['bytes'])
 go=load(A/'authorization.json')
 for k in ['fixedpointAuthorized','sourceResourceReviewAccepted','finitePositiveRawAccepted']:assert go[k] is True
 assert go['maximumLoaderCalls']==6 and go['preregistrationSHA256']==PR and go['driverSHA256']==DRIVER and go['inputPinsSHA256']==PINS
 pin(W/'vector-emitter-param-fixedpoint-source-review-v1-width/report.json',go['sourceReviewSHA256'])
 pin(W/'vector-emitter-param-positive-actual-review-v1-width/report.json',go['positiveRawReviewSHA256'])
 receipt=load(C/'source-review-receipt-v2.json');assert receipt['sourceSHA256']==SOURCE
 pin(W/'vector-emitter-param-source-review-v1-native-controls/report.json',receipt['semanticReviewSHA256'])
 pin(W/'vector-emitter-param-resource-review-v1-width/report-v2.json',receipt['resourceReviewSHA256'])
 pin(W/'vector-emitter-param-positive-source-review-v1-width/report.json',receipt['positiveDriverReviewSHA256'])
 pin(C/'report.json',receipt['candidateBuildReportSHA256'])
 pin(W/'vector-emitter-param-bounds-v1-controls/frozen-source-pins.json',receipt['frozenPinsSHA256'])
 src=pin(A/'unity.kotoba',SOURCE,1137800);assert src==read(C/'unity.kotoba')
 mat=load(A/'source-materialization.json');assert mat=={'origin':str(C/'unity.kotoba'),'copy':str(A/'unity.kotoba'),'sha256':SOURCE,'bytes':1137800,'sourceReadOnlyEnforced':False}
 initial=pin(A/'seed-0.bin',NATIVE,943320);assert initial==read(C/'candidate.bin')
 terminal=load(A/'terminal.json');assert terminal=={'allCallsClosed':True,'loaderCalls':6,'generations':3,'failure':False};assert not (A/'failure.json').exists()
 env={'KEXE_COMMAND':'1','KEXE_CAP_RESOURCES_35':str(A),'KEXE_CPU_SECONDS':'1800','KEXE_WALL_SECONDS':'1800','KEXE_STRING_POOL':'268435456','KEXE_VECTORS':'4194304','KEXE_PAIRS':'16777216','KEXE_VECTOR_ITEMS':'134217728'}
 e=load(A/'environment.json');assert e['kexeEnvironment']==env and e['wire35CombinedReadWriteScope']==str(A)
 removed=e['removedInheritedKexeKeys'];assert removed==sorted(set(removed)) and all(x.startswith('KEXE_') for x in removed)
 attempts=load(A/'attempts.json');assert len(attempts)==6
 generations=[];calls=[]
 for gen in range(1,4):
  seed=A/f'seed-{gen-1}.bin';image=A/f'seed-{gen}.kseed';native=A/f'seed-{gen}.bin'
  assert pin(seed,NATIVE,943320)==initial
  for stage,tail in [('compile',['compile',str(A/'unity.kotoba'),'--target','aarch64-macos','--output',str(image)]),('extract',['extract-native',str(image),'--symbol','main','--output',str(native)])]:
   idx=(gen-1)*2+(1 if stage=='compile' else 2);r=attempts[idx-1]
   expected=[str(C/'kexe-loader'),str(seed),'0','0','aarch64','35,37,38,39','--',*tail]
   assert r['index']==idx and r['generation']==gen and r['stage']==stage and r['argv']==expected
   assert r['state']=='terminal' and r['returncode']==0 and r['timeoutSeconds']==1810
   assert r['kexeEnvironment']==env and r['removedInheritedKexeKeys']==removed and r['sourceSHA256']==SOURCE and r['producerSHA256']==sha(read(seed))==NATIVE
   out=pin(A/f'seed-{gen}-{stage}.stdout',r['stdoutSHA256']);err=pin(A/f'seed-{gen}-{stage}.stderr',r['stderrSHA256']);assert err==b''
   expectedout=(f'{{:ok true, :target :aarch64-macos, :output "{image}", :bytes 943346}}\n' if stage=='compile' else f'{{:ok true, :output "{native}", :offset 0, :length 943320, :arity 0}}\n').encode()
   assert out==expectedout,('exact stdout',idx)
   calls.append({'index':idx,'generation':gen,'stage':stage,'argvExact':True,'producerRehashedAfterClosure':True,'rc':0,'stderrEmpty':True,'stdoutSHA256':sha(out)})
  b=pin(native,NATIVE,943320);assert b==initial
  raw=read(image);assert raw==b'KSEED1 943320 1\nmain 0 0\n\n'+b
  assert read(A/f'seed-{gen}.offset')==b'0\n'
  generations.append({'generation':gen,'nativeSHA256':sha(b),'bytes':len(b),'wholeKSEEDSHA256':sha(raw),'offset':0,'exports':[{'name':'main','offset':0,'arity':0}],'byteExactInitial':True})
 assert load(A/'generations.json')==generations
 stored=load(A/'report.json');assert stored=={'status':'PASS_CANDIDATE_THREE_GENERATION_FULL_BYTE_FIXEDPOINT_ONLY','loaderCalls':6,'generations':generations,'sourceSHA256':SOURCE,'functionalBenchmarkCalls':0,'timing':False,'CperformanceQualified':False,'productAdopted':False}
 # Initial candidate producer lineage: raw recorded two calls, independent hashes.
 prior=load(C/'attempts.json');assert len(prior)==2
 assert load(C/'terminal.json')=={'allCallsClosed':True,'loaderCalls':2,'failure':False}
 base=pin(C/'producer.bin','2a0d9a3b47dab57ca8b52532e7ce5c9cff9b189de1e62af564b9436646dd239b',929424)
 assert read(C/'candidate.kseed')==b'KSEED1 943320 1\nmain 0 0\n\n'+initial
 for idx,r in enumerate(prior,1):
  stage='compile' if idx==1 else 'extract';tail=['compile',str(C/'unity.kotoba'),'--target','aarch64-macos','--output',str(C/'candidate.kseed')] if idx==1 else ['extract-native',str(C/'candidate.kseed'),'--symbol','main','--output',str(C/'candidate.bin')]
  assert r['argv']==[str(C/'kexe-loader'),str(C/'producer.bin'),'0','0','aarch64','35,37,38,39','--',*tail]
  assert r['index']==idx and r['label']==stage and r['state']=='terminal' and r['returncode']==0 and r['timeoutSeconds']==1810 and r['producerSHA256']==sha(base) and r['sourceSHA256']==SOURCE
  assert r['kexeEnvironment']==dict(env,KEXE_CAP_RESOURCES_35=str(C)) and r['removedInheritedKexeKeys']==[]
  out=pin(C/(stage+'.stdout'),r['stdoutSHA256']);assert pin(C/(stage+'.stderr'),r['stderrSHA256'])==b''
  exp=(f'{{:ok true, :target :aarch64-macos, :output "{C}/candidate.kseed", :bytes 943346}}\n' if idx==1 else f'{{:ok true, :output "{C}/candidate.bin", :offset 0, :length 943320, :arity 0}}\n').encode();assert out==exp
 for p,r in list(seen.items()):pin(p,r['sha256'],r['bytes'])
 save('input-pins.json',seen)
 save('report.json',{'status':'PASS_INDEPENDENT_RAW_THREE_GENERATION_FIXEDPOINT_ONLY','nativeCallsByReviewer':0,'recordedFixedpointCalls':6,'initialProducerCallsSeparate':2,'allFinalSavedGenerationsIndividuallyRechecked':True,'sourceSHA256':SOURCE,'executedDriverSHA256':DRIVER,'nativeSHA256':NATIVE,'nativeBytes':943320,'generations':generations,'calls':calls,'inputPinsSHA256':sha((D/'input-pins.json').read_bytes()),'inheritedKexeRemoved':removed,'recordedEnvironmentExact':True,'unrecordedOSStateProven':False,'functionalBenchmarkQualified':False,'timing':False,'CperformanceQualified':False,'universalCorrectnessQualified':False,'persistentCIDCacheQualified':False,'productAdopted':False})
if __name__=='__main__':
 try:audit()
 except BaseException as e:save('failure.json',{'status':'HOLD_INDEPENDENT_RAW_AUDIT_FAILURE','exception':repr(e),'nativeCalls':0});raise
 print('PASS_INDEPENDENT_RAW_THREE_GENERATION_FIXEDPOINT_ONLY')
