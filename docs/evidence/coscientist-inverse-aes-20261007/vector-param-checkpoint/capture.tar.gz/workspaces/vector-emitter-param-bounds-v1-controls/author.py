from pathlib import Path
import hashlib,json,re,difflib
D=Path(__file__).resolve().parent;B=D.parent/'vector-emitter-local-bounds-v1-controls'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pr=json.loads((D/'preregistration.json').read_text())
for p,h in pr['inputs'].items():assert sha(Path(p))==h,p

def form(t,n):
 st=t.index('(defn- '+n+' ');depth=0;string=comment=escape=False
 for j in range(st,len(t)):
  c=t[j]
  if comment:
   if c=='\n':comment=False
  elif string:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':string=False
  elif c==';':comment=True
  elif c=='"':string=True
  elif c=='(':depth+=1
  elif c==')':
   depth-=1
   if depth==0:return t[st:j+1]
 raise AssertionError(n)

s=(B/'unity-vector-analysis-default.kotoba').read_text();changes=[]
def replace(n,v):
 u=form(s,n);assert u!=v,n;changes.append((n,u,v))
u=form(s,'vw-run');v=u.replace('m6a (if (= (vw-c m6 1) 0) (vw-zero-work m6 vw-sites (+ vw-sites 2048)) m6)', 'm6p (if (and (= ve-feature 1) (= (vw-c m6 1) 0)) (vp-context m6 1 0 true) m6)\n        m6a (if (= (vw-c m6p 1) 0) (vw-zero-work m6p vw-sites (+ vw-sites 2048)) m6p)',1)
v=v.replace('m8 (vw-publish (if (= (vw-c m7 1) 0) m7 (vw-cs m7 4 0)))', 'm7p (if (and (= ve-feature 1) (= (vw-c m7 1) 0)) (vp-context m7 1 0 false) m7)\n        m8 (vw-publish (if (= (vw-c m7p 1) 0) m7p (vw-cs m7p 4 0)))',1);replace('vw-run',v)
replace('ve-source-eligible?', '''(defn- ve-source-eligible? [M :vector-i64 n :i64] :bool
 (if (or (< n 0) (>= n (vw-c M 4)) (>= n 256)) false
  (let [p (+ vw-sites (* n 8)) f (gn-g M (+ p 1)) token (gn-g M (+ p 2)) sn (vector-at M MM-SIR-N)
        site (gn-g M p) L (gn-g M (+ p 3)) K (gn-g M (+ p 4)) base (gn-g M (+ p 5))]
   (and (> f 0) (< f (vector-at M MM-FN-N)) (< f 128)
    (= (vw-f M f 2) 1) (= (vw-f M f 3) 1) (= (vw-f M f 14) 0) (= (vw-f M f 15) 1)
    (= (gn-g M (+ p 6)) 1) (= (gn-g M (+ p 7)) 1)
    (if (> token 0)
     (and (vp-param-source? M f token L) (vp-record-ok? M site f token L K base (vw-f M f 0) (vw-f M f 1)))
     (and (< token 0) (> token (- 0 sn))
      (ve-record-ok? M site f (- 0 token) L K base (vw-f M f 0) (vw-f M f 1))))))))''')
# copy-fields is already a generic sign inversion with guarded FN/endpoints: unchanged.
replace('ve-export-sites', '''(defn- ve-export-sites [M :vector-i64 n :i64] :vector-i64
 (let [m (vw-tick M) count (vw-c m 4)]
  (cond (not= (vw-c m 1) 0) m
        (or (< count 0) (> count 256) (< n 0) (> n count)) (vw-cs m 1 1)
        (= n count) m
        :else (let [dst (gn-g m (+ ve-bank 1)) eligible (ve-source-eligible? m n)
                    param (> (gn-g m (+ vw-sites (* n 8) 2)) 0) slots (if param 2 1)]
          (if (or (< dst 0) (> dst 256)) (vw-cs m 1 1)
           (let [m1 (if eligible (if (> slots (- 256 dst)) (vw-cs m 1 1) (ve-copy-fields m n dst 0)) m)
                 m2 (if (and eligible param (= (vw-c m1 1) 0)) (vp-copy-context m1 n (inc dst) 0) m1)
                 m3 (if (and eligible (= (vw-c m2 1) 0)) (vw-write m2 (+ ve-bank 1) (+ dst slots)) m2)]
            (ve-export-sites m3 (inc n))))))))''')
u=form(s,'ve-export-header');replace('ve-export-header',u.replace('(= k 4) 1','(= k 4) 2',1))
replace('ve-record-admit?', '''(defn- ve-record-admit? [M :vector-i64 i :i64 t :i64 n :i64] :bool
 (if (or (< n 0) (>= n 256) (>= n (gn-g M (+ ve-bank 1)))) false
  (let [p (+ ve-bank 8 (* n 8)) site (gn-g M p) f (gn-g M (+ p 1)) origin (gn-g M (+ p 2))
        L (gn-g M (+ p 3)) K (gn-g M (+ p 4)) base (gn-g M (+ p 5)) start (gn-g M (+ p 6)) end (gn-g M (+ p 7))]
   (and (= site i) (= base t)
    (if (> origin 0) (ve-record-ok? M site f origin L K base start end)
     (and (< origin 0) (> origin -6) (< (inc n) (gn-g M (+ ve-bank 1)))
      (vp-record-ok? M site f (- 0 origin) L K base start end)
      (let [q (+ p 8)]
       (and (= (gn-g M q) 0) (= (gn-g M (+ q 1)) f) (= (gn-g M (+ q 2)) (- 0 origin))
        (>= (gn-g M (+ q 3)) L) (= (gn-g M (+ q 4)) start) (= (gn-g M (+ q 5)) end)
        (= (gn-g M (+ q 6)) 1) (= (gn-g M (+ q 7)) 0)))))
    (= (gn-high-start M i 8192) start) (= (gn-dv M (inc t)) K)))))''')
replace('ve-find', '''(defn- ve-find [M :vector-i64 i :i64 t :i64 n :i64 count :i64] :bool
 (cond (or (< count 0) (> count 256) (< n 0) (>= n count)) false
       (= (gn-g M (+ ve-bank 8 (* n 8))) i) (ve-record-admit? M i t n)
       :else (let [origin (gn-g M (+ ve-bank 10 (* n 8))) slots (if (< origin 0) 2 1)]
               (ve-find M i t (+ n slots) count))))''')
u=form(s,'ve-admit?');v=u.replace('(= (gn-g M (+ ve-bank 4)) 1)','(= (gn-g M (+ ve-bank 4)) 2)',1)
v=v.replace('(>= (gn-g M (+ ve-bank 6)) (gn-g M (+ ve-bank 1))) (<= (gn-g M (+ ve-bank 6)) 256)', '(> (gn-g M (+ ve-bank 6)) 0) (<= (gn-g M (+ ve-bank 6)) 256)\n  (<= (gn-g M (+ ve-bank 1)) (* 2 (gn-g M (+ ve-bank 6))))',1);replace('ve-admit?',v)
h=(D/'helpers.kotoba').read_text();names=re.findall(r'\(defn- (\S+) ',h);assert len(names)==8 and set(names)==set(z.split(' ')[0] for z in pr['newHelpers'])
actual=[x[0] for x in changes];assert set(actual)==set(pr['changedDefinitions'])-{'ve-copy-fields'}
for fn in ['41-vector-analysis-default.kotoba','41-vector-analysis-on.kotoba','unity-vector-analysis-default.kotoba','unity-vector-analysis-on.kotoba']:
 orig=(B/fn).read_text();t=orig
 for n,u,v in changes:assert t.count(u)==1,(fn,n);t=t.replace(u,v,1)
 marker='(defn- ve-record-ok? ';assert t.count(marker)==1;t=t.replace(marker,h+marker,1)
 rev=t.replace(h,'',1)
 for n,u,v in reversed(changes):assert rev.count(v)==1;rev=rev.replace(v,u,1)
 assert rev==orig,fn
 # lexical balance of brackets, strings and comments
 stack=[];string=comment=escape=False
 for c in t:
  if comment:
   if c=='\n':comment=False
  elif string:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':string=False
  elif c==';':comment=True
  elif c=='"':string=True
  elif c in '([{':stack.append(c)
  elif c in ')]}':assert stack and stack.pop()=={')':'(',']':'[','}':'{'}[c],(fn,'bracket')
 assert not stack and not string,fn
 (D/fn).write_text(t)
a=(B/'analysis.kotoba').read_text();u,v=next((u,v) for n,u,v in changes if n=='vw-run');assert a.count(u)==1;(D/'analysis.kotoba').write_text(a.replace(u,v,1))
(D/'source-deltas.json').write_text(json.dumps({'newHelpers':h,'insertMarker':marker,'changes':[{'name':n,'old':u,'new':v} for n,u,v in changes],'fourReverseFrozenEmitterExact':True,'registeredButUnchangedDefinition':'ve-copy-fields original generic token sign inversion retained'},indent=2)+'\n')
(D/'source.diff').write_text(''.join(difflib.unified_diff(s.splitlines(True),(D/'unity-vector-analysis-default.kotoba').read_text().splitlines(True),fromfile='frozenEmitterDefault',tofile='paramBridgeDefault')))
(D/'report.json').write_text(json.dumps({'status':'SOURCE_ONLY_HOLD_PENDING_INDEPENDENT_SEMANTIC_RESOURCE_REVIEW_NO_NATIVE_GO','native':0,'productEdits':0,'newHelpers':names,'changedDefinitions':actual,'registeredButUnchanged':'ve-copy-fields','fourExactReverseFrozenEmitter':True,'defaultFeature':0,'sealWords':2056,'maxSealRecords':256,'parameterRecordSlots':2,'analysisCleanup':50689,'workCap':268435456,'ownedContextMask':{'owner':'vw-old','start':896,'endExclusive':1024,'words':128},'variants':{fn:sha(D/fn) for fn in ['41-vector-analysis-default.kotoba','41-vector-analysis-on.kotoba','unity-vector-analysis-default.kotoba','unity-vector-analysis-on.kotoba']},'claimsExcluded':['native compilation','original19 rewrite count','functional correctness','selfhost','performance','ComputeCID/ResultCID runtime','returned origin','exported parameter','new effects/types']},indent=2)+'\n')
print(json.dumps({'reportSHA256':sha(D/'report.json'),'onUnitySHA256':sha(D/'unity-vector-analysis-on.kotoba')}))
