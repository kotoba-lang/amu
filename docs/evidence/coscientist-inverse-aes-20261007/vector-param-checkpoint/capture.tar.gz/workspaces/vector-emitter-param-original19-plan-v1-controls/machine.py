"""Offline multi-site oracle. Native payload data is never decoded as instructions."""
from pathlib import Path
import json,hashlib,re,struct,importlib.util
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('a64',P/'instruction-primitives.py');a64=importlib.util.module_from_spec(spec);spec.loader.exec_module(a64)
def need(x,msg):
 if not x:raise AssertionError(msg)
def container(p):
 raw=Path(p).read_bytes();header,b=raw.split(b'\n\n',1);lines=header.decode('ascii').splitlines();m=re.fullmatch(r'KSEED1 (\d+) (\d+)',lines[0]);need(m,'KSEED header')
 exports=[]
 for line in lines[1:]:
  z=re.fullmatch(r'(\S+) (\d+) (\d+)',line);need(z,'export syntax');exports.append((z[1],int(z[2]),int(z[3])))
 need(len(b)==int(m[1]) and len(exports)==int(m[2]),'container sizes');need(len(set(x[0] for x in exports))==len(exports),'unique names')
 for _,off,arity in exports:need(off%4==0 and 0<=off<len(b) and 0<=arity<=128,'export domain')
 return b,exports

def remap(i,cuts):
 for start,end in cuts:need(not start<=i<end,'target/export enters omitted trio')
 return i-sum(end-start for start,end in cuts if i>=end)

def branch(w,pc,cuts,n):
 if w&0x7c000000==0x14000000:bits,shift=26,0
 elif w&0xff000010==0x54000000:bits,shift=19,5
 elif w&0x7e000000==0x34000000:bits,shift=19,5
 elif w&0x7e000000==0x36000000:bits,shift=14,5
 else:
  need(w&0x9f000000 not in (0x10000000,0x90000000),'HOLD unsupported ADR/ADRP relocation')
  need(w&0x3b000000!=0x18000000,'HOLD unsupported literal LDR relocation')
  return w
 mask=((1<<bits)-1)<<shift;target=pc+a64.signed((w&mask)>>shift,bits);need(0<=target<n,'branch target within proven code')
 delta=remap(target,cuts)-remap(pc,cuts);need(-(1<<(bits-1))<=delta<(1<<(bits-1)),'branch displacement range')
 return (w&~mask)|((delta&((1<<bits)-1))<<shift)

def verify(old,new,oldexports,newexports,approved,codeend):
 need({(x[0],x[2]) for x in oldexports}=={(x[0],x[2]) for x in newexports},'export identity/arity')
 if old==new:
  need(oldexports==newexports,'unchanged offsets');return {'status':'PASS_WHOLE_PAYLOAD_AND_EXPORTS_EXACT_ZERO_OMISSIONS','cuts':[],'actualSites':0}
 need(codeend%4==0 and 0<codeend<=len(old),'proven old code end')
 # Changed pooled images need separately preregistered pool/ADR relocation.
 # Equality above compares data byte-for-byte; no tail bytes are instruction-decoded.
 need(codeend==len(old),'HOLD changed payload has literal/data tail; no registered pool relocation')
 need(len(new)%4==0 and len(new)<=len(old),'changed code-only sizes')
 ow=list(struct.unpack('<'+'I'*(len(old)//4),old));nw=list(struct.unpack('<'+'I'*(len(new)//4),new));starts={}
 for q in approved:
  j=q['readWord'];need(j not in starts,'unique certified baseline read location')
  need(ow[j:j+15]==a64.readseq(q['rv'],q['ri'],q['d']),'exact baseline15word read')
  starts[j]=q
 cuts=[];pc=cur=0
 while pc<len(ow):
  if pc in starts:
   q=starts[pc];seq=ow[pc:pc+15];kept=seq[:9]+seq[12:]
   if nw[cur:cur+12]==kept:cuts.append((pc+9,pc+12))
   else:need(nw[cur:cur+15]==seq,'registered read sequence neither exact retained nor exact bounds omission')
  if any(pc==lo for lo,_ in cuts):pc+=3;continue
  need(cur<len(nw),'candidate prematurely ends')
  pc+=1;cur+=1
 need(cur==len(nw) and len(ow)-len(nw)==3*len(cuts),'only declared threeword cuts')
 expected=[];reloc=[]
 for pc,w in enumerate(ow):
  if any(lo<=pc<hi for lo,hi in cuts):continue
  v=branch(w,pc,cuts,len(ow));expected.append(v)
  if w!=v:reloc.append({'oldByte':pc*4,'oldWord':hex(w),'newWord':hex(v)})
 need(expected==nw,'all other words exact after registered branch relocation')
 mapped=[(name,remap(off//4,cuts)*4,arity) for name,off,arity in oldexports]
 need(mapped==newexports,'ordered export table offset mapping')
 witnesses=[]
 for lo,hi in cuts:
  q=starts[lo-9];witnesses.append(q|{'removedBytes':12,'oldCutByte':lo*4,'newReadByte':remap(q['readWord'],cuts)*4,'retainedEightHandleWords':[hex(w) for w in ow[q['readWord']:q['readWord']+8]]})
 return {'status':'PASS_REGISTERED_MULTI_SITE_BOUNDS_ONLY','actualSites':len(cuts),'cuts':witnesses,'branchRelocations':reloc,'allOtherCodeDataExportsExact':True,'contextSealReceipt':'not observed; source-reviewed guard plus baseline certified site join only'}

def approved_reads(folder,old):
 records=json.loads((Path(folder)/'observer-records.json').read_text())
 def ix(tag):
  v=[x['fields'] for x in records if x['tag']==tag];z={x[0]:x for x in v};need(len(z)==len(v),'unique records');return z
 sir=ix('SIR');ff=ix('FREC');sites=ix('VWSITE');cache=ix('CACHE');em=ix('EMIT');vf=ix('VWFN')
 status=[x['fields'] for x in records if x['tag']=='VWSTATUS'];entry=[x['fields'] for x in records if x['tag']=='VWENTRY'];need(entry==[[0]] and len(status)==1 and status[0][0]==0 and status[0][1]==7,'complete unrefused final baseline certificates')
 need(em,'complete emitter records');codeend=(max(x[3] for x in em.values())-1)*4
 need(codeend<=len(old),'code range within baseline payload')
 words=list(struct.unpack('<'+'I'*(codeend//4),old[:codeend]));approved=[]
 for i,cert in sites.items():
  _,f,pos,L,K,t,c,h=cert
  if not(1<=pos<=5 and ff[f][3]==2 and ff[f][12]==0 and pos<=ff[f][4] and ff[f][5+pos]==4):continue
  if i not in cache or cache[i][1]!=0 or i not in em or em[i][1]!=0:continue
  need(sir[i][1:]==[14,176,t,2] and 0<=K<L and 0<=t<=5 and c==h==1,'certified read join')
  summary=vf[f][1:];need(summary[2]==summary[3]==summary[15]==1 and summary[14]==0,'complete supported certificate context')
  ordinals=[k for k in range(4) if summary[10+k]==pos];need(len(ordinals)==1 and L<=summary[6+ordinals[0]],'exact parameter ordinal/final length join')
  need(not any(v[1]==22 and v[3]==f for v in sir.values()),'no source address-taken parameter body')
  need(ff[f][13]==summary[0] and summary[0]<i<summary[1] and sir[summary[0]][1:3]==[1,f] and sir[summary[1]][1:3]==[2,f],'exact checked FN body and read identity')
  lo=em[i][2]-1;hi=em[i][3]-1;need(0<=lo<hi<=len(words),'owned code span')
  matches=[]
  for j in range(lo,max(lo,hi-14)):
   if words[j]!=a64.ldr(16,7,312):continue
   rv=(words[j+2]>>5)&31;ri=(words[j+9]>>5)&31;d=words[j+14]&31
   if words[j:j+15]==a64.readseq(rv,ri,d):matches.append((j,rv,ri,d))
  need(len(matches)==1,('HOLD certified ordinary span does not uniquely match actual15word read',i,matches))
  j,rv,ri,d=matches[0];start=ff[f][14]-1
  nextstarts=[v[14]-1 for v in ff.values() if v[14]-1>start];end=min(nextstarts) if nextstarts else len(words)
  need(start<=j and j+15<=end,'FN/body code range join')
  approved.append({'sir':i,'fn':f,'parameterPosition':pos,'length':L,'index':K,'tempBase':t,'readWord':j,'rv':rv,'ri':ri,'d':d,'baselineOwnedSpan':[lo*4,hi*4],'baselineFunctionCodeSpan':[start*4,end*4]})
 return approved,codeend

def folder_validation(oldfolder,newfolder):
 old,oe=container(Path(oldfolder)/'image.kseed');new,ne=container(Path(newfolder)/'image.kseed')
 need(old==(Path(oldfolder)/'native.bin').read_bytes() and new==(Path(newfolder)/'native.bin').read_bytes(),'whole native payloads')
 if old==new:return verify(old,new,oe,ne,[],len(old))
 approved,codeend=approved_reads(oldfolder,old)
 return verify(old,new,oe,ne,approved,codeend)
