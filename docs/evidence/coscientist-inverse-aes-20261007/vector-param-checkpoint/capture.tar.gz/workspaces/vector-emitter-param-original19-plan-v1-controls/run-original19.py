"""Explicit root GO required. Maximum38 native calls; this file's creation executes none."""
from pathlib import Path
import json,os,subprocess,hashlib,re,sys
import machine
P=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n')
def need(x,msg):
 if not x:raise AssertionError(msg)
def execute(go,output):
 g=load(go);pr=load(P/'preregistration.json');pins=load(P/'input-pins.json');sources=load(P/'source-pins.json')
 need(g.get('original19CompilationAuthorized') is True and g.get('maximumLoaderCalls')==38,'explicit root38-call GO')
 need(g.get('sourcePinsSHA256')==sha(P/'source-pins.json'),'root exact source freeze')
 for name,h in sources.items():need(sha(P/name)==h,('plan source',name))
 for path,e in pins.items():need(sha(path)==e['sha256'] and Path(path).stat().st_size==e['bytes'],('pinned input',path))
 need(g.get('sourceResourceReviewsAccepted') is True and g.get('positiveActualIndependentAccepted') is True,'independent source/resource/actual-positive acceptance')
 rp=Path(g['positiveIndependentReview']);need(sha(rp)==g['positiveIndependentReviewSHA256'],'independent positive review pin')
 q=load(pr['positiveReport']);need(q['status']=='PASS_INITIAL_SINGLE_PRIVATE_PARAMETER_BOUNDS_FIXTURE' and q['loaderCalls']==10 and q['functionalCalls']==6 and q['inputs']==[0,7,-1],'actual parameter positive gate')
 need(q['structural']['removedBytes']==12 and q['structural']['status']=='PASS_EXACT_SINGLE_BOUNDS_TRIO_OMISSION','actual registered omission')
 for n in (0,7,-1):need(q['results']['reference-n'+str(n)]==q['results']['candidate-n'+str(n)],'positive raw result/fuel/arena pair')
 B=Path(pr['candidateDirectory']);need(sha(B/'candidate.bin')==pr['candidateSHA256'] and sha(B/'unity.kotoba')==pr['candidateSourceSHA256'],'exact new producer/source')
 code,exp=machine.container(B/'candidate.kseed');need(code==(B/'candidate.bin').read_bytes() and exp==[('main',0,0)] and (B/'candidate.offset').read_bytes()==b'0\n','candidate producer full container main0')
 W=Path(output).resolve();need(str(W)==g['outputDirectory'] and W.is_relative_to(P.parent) and not W.exists(),'fresh root authorized output')
 W.mkdir();(W/'sources').mkdir();(W/'ports').mkdir();save(W/'authorization.json',g)
 copies=[]
 for e in pr['entries']:
  p=W/'sources'/(e['workload']+'.kotoba');p.write_bytes(Path(e['source']).read_bytes());need(sha(p)==sha(e['source']),'same source copy');copies.append({'workload':e['workload'],'origin':e['source'],'copy':str(p),'sha256':sha(p)})
 save(W/'source-materialization.json',copies)
 base={k:v for k,v in os.environ.items() if not k.startswith('KEXE_')};removed=sorted(k for k in os.environ if k.startswith('KEXE_'))
 env={'KEXE_COMMAND':'1','KEXE_CAP_RESOURCES_35':str(W),'KEXE_CPU_SECONDS':'1800','KEXE_WALL_SECONDS':'1800','KEXE_STRING_POOL':'268435456','KEXE_VECTORS':'4194304','KEXE_PAIRS':'16777216','KEXE_VECTOR_ITEMS':'134217728'}
 save(W/'environment.json',{'kexeEnvironment':env,'allInheritedKexeRemoved':removed,'scope35':str(W)})
 rows=[];images=[]
 def call(e,stage,args):
  need(len(rows)<38,'38-call cap');d=W/'ports'/e['workload'];label=stage
  argv=[str(B/'kexe-loader'),str(B/'candidate.bin'),'0','0','aarch64','35,37,38,39','--',*args]
  need(sha(B/'candidate.bin')==pr['candidateSHA256'],'producer before invocation')
  need(sha(W/'sources'/(e['workload']+'.kotoba'))==sha(e['source']),'source before invocation')
  row={'index':len(rows)+1,'workload':e['workload'],'stage':stage,'argv':argv,'state':'started','kexeEnvironment':env,'removedInheritedKexeKeys':removed,'producerSHA256':sha(B/'candidate.bin'),'sourceSHA256':sha(e['source']),'timeoutSeconds':1810};rows.append(row);save(W/'attempts.json',rows)
  try:t=subprocess.run(argv,env=base|env,capture_output=True,timeout=1810);out,err,rc=t.stdout,t.stderr,t.returncode
  except subprocess.TimeoutExpired as x:out,err,rc=x.stdout or b'',x.stderr or b'',None
  (d/(label+'.stdout')).write_bytes(out);(d/(label+'.stderr')).write_bytes(err);row.update(state='terminal',returncode=rc,stdoutSHA256=hashlib.sha256(out).hexdigest(),stderrSHA256=hashlib.sha256(err).hexdigest());save(W/'attempts.json',rows)
  need(sha(B/'candidate.bin')==pr['candidateSHA256'] and sha(W/'sources'/(e['workload']+'.kotoba'))==sha(e['source']),'producer/source after invocation')
  need(rc==0 and not err and b':ok true' in out,('invocation success',e['workload'],stage,rc));return out
 try:
  for e in pr['entries']:
   d=W/'ports'/e['workload'];d.mkdir();src=W/'sources'/(e['workload']+'.kotoba')
   call(e,'compile',['compile',str(src),'--target','aarch64-macos','--output',str(d/'image.kseed')])
   out=call(e,'extract',['extract-native',str(d/'image.kseed'),'--symbol',e['symbol'],'--output',str(d/'native.bin')])
   matches=re.findall(rb':offset (\d+)\b',out);need(len(matches)==1,'unique selected offset');off=int(matches[0]);(d/'native.offset').write_text(str(off)+'\n')
   new,ne=machine.container(d/'image.kseed');old,oe=machine.container(Path(e['baselineDirectory'])/'image.kseed')
   need(new==(d/'native.bin').read_bytes() and old==(Path(e['baselineDirectory'])/'native.bin').read_bytes(),'exact full native payloads')
   selected=[x for x in ne if x[0]==e['symbol']];need(len(selected)==1 and selected[0][1]==off,'selected export offset')
   need([(x[0],x[2]) for x in ne]==[(x[0],x[2]) for x in oe],'ordered export names/arity')
   images.append({'workload':e['workload'],'symbol':e['symbol'],'sourceSHA256':sha(src),'nativeSHA256':sha(d/'native.bin'),'containerSHA256':sha(d/'image.kseed'),'bytes':len(new),'offset':off,'baselineNativeSHA256':sha(Path(e['baselineDirectory'])/'native.bin'),'wholePayloadEqual':new==old});save(W/'images.json',images)
  need(len(rows)==38 and len(images)==19,'complete original19 fixed plan')
  # Compiler attempt ledger is closed before offline structural qualification.
  validation=[]
  for e in pr['entries']:
   try:result=machine.folder_validation(e['baselineDirectory'],W/'ports'/e['workload'])
   except AssertionError as x:result={'status':'HOLD_UNREGISTERED_OR_UNPROVEN_DIFFERENCE','reason':str(x),'actualSites':'UNQUALIFIED'}
   validation.append({'workload':e['workload'],**result})
  save(W/'machine-validation.json',validation);held=any(x['status'].startswith('HOLD') for x in validation)
  save(W/'report.json',{'status':'HOLD_MACHINE_QUALIFICATION_AFTER38_SUCCESSFUL_COMPILER_CALLS' if held else 'PASS_ORIGINAL19_REGISTERED_MACHINE_COMPARISON_ONLY','loaderCalls':38,'images':19,'machineHolds':sum(x['status'].startswith('HOLD') for x in validation),'actualRegisteredOmissions':sum(x.get('actualSites',0) for x in validation if isinstance(x.get('actualSites'),int)),'functionalCalls':0,'timing':False,'runtimeCID':False,'performanceQualified':False})
 except BaseException as x:save(W/'failure.json',{'exception':repr(x),'loaderCalls':len(rows),'completedImages':len(images),'policy':'STOP_FIRST_FAILURE_NO_RERUN'});raise
 finally:save(W/'terminal.json',{'allCallsClosed':all(x['state']=='terminal' for x in rows),'loaderCalls':len(rows),'completedImages':len(images),'failure':(W/'failure.json').exists()})
if __name__=='__main__':
 need(len(sys.argv)==3,'root GO and fresh output directory');execute(sys.argv[1],sys.argv[2])
