import machine,json
s=machine.a64.readseq(9,10,0)
own=[0x14000020]+s+s+[0xd65f03c0,0xd65f03c0]
new=[0x1400001a]+s[:9]+s[12:]+s[:9]+s[12:]+[0xd65f03c0,0xd65f03c0]
pack=lambda w:machine.struct.pack('<'+'I'*len(w),*w)
proof=[{'readWord':j,'rv':9,'ri':10,'d':0,'sir':k,'fn':1,'parameterPosition':1} for j,k in [(1,1),(16,2)]]
pos=machine.verify(pack(own),pack(new),[('bench',124,1)],[('bench',100,1)],proof,len(own)*4);assert pos['actualSites']==2
rejects=[]
for name,idx in [('hchk',1),('descriptor',9),('pool',10),('address',11),('load',12),('branch',0),('tailinstruction',26)]:
 mutant=new.copy();mutant[idx]^=1
 try:machine.verify(pack(own),pack(mutant),[('bench',124,1)],[('bench',100,1)],proof,len(own)*4)
 except AssertionError:rejects.append(name)
 else:raise AssertionError(name)
for name,args in [
 ('unknown-cut-proof', (pack(own),pack(new),[('bench',124,1)],[('bench',100,1)],proof[:1],len(own)*4)),
 ('export', (pack(own),pack(new),[('bench',124,1)],[('bench',104,1)],proof,len(own)*4)),
 ('data-tail', (pack(own)+b'arbitraryDATA',pack(new)+b'arbitraryDATA',[('bench',124,1)],[('bench',100,1)],proof,len(own)*4))]:
 try:machine.verify(*args)
 except AssertionError:rejects.append(name)
 else:raise AssertionError(name)
assert machine.verify(b'arbitrary data',b'arbitrary data',[('bench',0,1)],[('bench',0,1)],[],0)['actualSites']==0
print(json.dumps({'status':'PASS_OFFLINE_MULTI_SITE_ORACLE_SELFTEST','positiveCuts':pos['actualSites'],'rejectedMutants':rejects,'dataTailNotDecoded':True,'native':0},indent=2))
