#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/sysctl.h>
extern uint64_t inv_probe(uint64_t,uint64_t,uint64_t,uint64_t,uint64_t,uint64_t);
int main(int argc,char **argv){
 int aes=0;size_t size=sizeof(aes);
 if(sysctlbyname("hw.optional.arm.FEAT_AES",&aes,&size,0,0)!=0||size!=sizeof(aes)||aes!=1){fprintf(stderr,"FEATURE_REFUSED\n");return 2;}
 if(argc!=3)return 3;
 FILE*f=fopen(argv[1],"rb");if(!f)return 3;
 uint64_t q[8];int n=0,bad=0;
 while(fread(q,sizeof(q),1,f)==1){
  uint64_t v=inv_probe(q[1],q[2],q[3],q[4],q[5],q[6]);
  printf("%llu %llu\n",(unsigned long long)q[0],(unsigned long long)v);
  bad+=(v!=q[7]);n++;
 }
 int err=ferror(f);fclose(f);
 if(n!=277||err)return 3;
 fprintf(stderr,"AES=1 cases=%d mismatches=%d\n",n,bad);
 return (argv[2][0]=='p'&&bad)?4:0;
}
