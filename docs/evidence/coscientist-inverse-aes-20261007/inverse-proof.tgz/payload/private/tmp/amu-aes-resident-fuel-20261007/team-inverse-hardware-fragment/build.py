from pathlib import Path
import subprocess,json,hashlib,struct
D=Path(__file__).parent;r=json.loads((D/'preregistration.json').read_text());receipts=[]
for name in ['positive',*r['mutations']]:
 cmd=['/usr/bin/clang','-O2',str(D/'harness.c'),str(D/f'{name}.s'),'-o',str(D/name)]
 p=subprocess.run(cmd,capture_output=True,timeout=30);(D/f'build-{name}.stdout').write_bytes(p.stdout);(D/f'build-{name}.stderr').write_bytes(p.stderr)
 rec={'name':name,'command':cmd,'exit':p.returncode};receipts.append(rec);(D/'build-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');assert p.returncode==0
 b=(D/name).read_bytes();assert struct.unpack_from('<I',b)[0]==0xfeedfacf
 n=struct.unpack_from('<I',b,16)[0];pos=32;segments=[];sym=None
 for _ in range(n):
  kind,size=struct.unpack_from('<II',b,pos)
  if kind==0x19:
   vm,vs,fo,fs=struct.unpack_from('<4Q',b,pos+24);segments.append((vm,vs,fo,fs))
  if kind==2:sym=struct.unpack_from('<4I',b,pos+8)
  pos+=size
 so,sn,st,ss=sym;address=None
 for i in range(sn):
  ix,typ,sect,desc,value=struct.unpack_from('<IBBHQ',b,so+16*i)
  end=b.index(0,st+ix);label=b[st+ix:end]
  if label==b'_inv_probe':address=value
 assert address is not None
 offsets=[fo+address-vm for vm,vs,fo,fs in segments if vm<=address<vm+vs];assert len(offsets)==1
 words=list(struct.unpack_from('<10I',b,offsets[0]));expected=r['words'].copy()
 if name!='positive':
  for k,v in r['mutations'][name]['wordChanges'].items():expected[int(k)]=v
 assert words==expected
 rec.update({'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'functionFileOffset':offsets[0],'words':words,'exactWords':True})
 (D/'build-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
pins=[]
for p in sorted(D.iterdir()):
 if p.is_file():pins.append({'path':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(D/'pre-execution-pins.json').write_text(json.dumps(pins,indent=2)+'\n');print('four builds PASS exact ten words; pre-execution pins frozen')
