from pathlib import Path
import json,re,hashlib,struct,time
import z3 as z
D=Path(__file__).parent;pr=json.loads((D/'preregistration.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in pr['inputs'].items():assert sha(Path(p))==h
src=Path(next(p for p in pr['inputs']if p.endswith('/source.kotoba')));text=src.read_text();rawp=Path(next(p for p in pr['inputs']if p.endswith('/native.bin')));raw=rawp.read_bytes();words=[q[0]for q in struct.iter_unpack('<I',raw)];log=Path(next(p for p in pr['inputs']if p.endswith('/compile.log'))).read_text();sir={};fn={};fix={};emit={}
for l in log.splitlines():
 x=l.split()
 if x[0]=='SIR':sir[int(x[1])]=tuple(map(int,x[2:]))
 if x[0]=='FN':fn[int(x[1])]=tuple(map(int,x[2:]))
 if x[0]=='FIX':
  q=tuple(map(int,x[1:]));fix.setdefault(q[3],[]).append(q)
 if x[0]=='EMIT':emit[int(x[1])]=tuple(map(int,x[2:]))
read=lambda name:sum([list(map(int,re.search(r'\(def '+name+'-'+str(k)+r' \[([^]]+)\]',text)[1].split()))for k in range(2)],[])
T=[read('dec-t'+str(k))for k in range(4)];S=read('dec-sbox');E=read('enc-sbox');assert len(set(E))==256 and all(S[E[x]]==x for x in range(256))
cert=[]
for role,f in enumerate([21,24,27,30]):
 p=fn[f][0];end=next(j for j in range(p+1,max(sir)+1)if sir[j][0]==2);nodes=[(j,q)for j,q in sir.items()if p<j<end and q[0]==21];assert len(nodes)==2
 for part,(j,(op,t,lit,n))in enumerate(nodes):
  assert n==128;skip,lo,hi=emit[j];hits=[q for q in fix[lit]if q[2]==5 and lo<=q[1]<hi];assert len(hits)==1
  ix,at,k,target,aux=hits[0];w0,w1=words[at-1:at+1];assert w0&0xff80001f==0xd2800010 and w1&0xff80001f==0xf2800010 and (w0>>21)&3==0 and (w1>>21)&3==1
  offset=((w0>>5)&65535)|(((w1>>5)&65535)<<16);assert offset%8==0 and offset+8*n<=len(raw);pool=list(struct.unpack('<'+str(n)+'Q',raw[offset:offset+8*n]));assert pool==T[role][part*128:(part+1)*128]
  cert.append({'role':role,'fn':f,'sir':j,'literal':lit,'fixIndex':ix,'fixAt':at,'emitted':[lo,hi],'poolOffset':offset,'entries':n,'poolSHA256':hashlib.sha256(raw[offset:offset+8*n]).hexdigest(),'sourceHalfExact':True})
def mul(a,b,poly=0x11b):
 v=0
 for _ in range(8):
  if b&1:v^=a
  a=((a<<1)^(poly if a&128 else 0))&255;b>>=1
 return v
def sub(x):
 v=1;a=x;p=254
 for _ in range(8):
  if p&1:v=mul(v,a)
  a=mul(a,a);p>>=1
 q=v^99
 for k in range(1,5):q^=((v<<k)|(v>>(8-k)))&255
 return q&255
assert E==[sub(k)for k in range(256)]
for role in range(4):
 for x in range(256):
  s=S[x];w=sum(mul(s,c)<<(8*k)for k,c in enumerate([14,9,13,11]));out=w if role==0 else((w<<(8*role))|(w>>(32-8*role)))&0xffffffff;assert T[role][x]==out
(D/'finite-pool-certificate.json').write_text(json.dumps({'sourceSHA256':sha(src),'nativeSHA256':sha(rawp),'literalPools':cert,'inverseTableEntries':1024,'GFPolynomial':'0x11b','inverseSbox256Checked':True,'separateFromSMT':True},indent=2)+'\n')
# Exact checked source/type/byte-mask/table branch binding, separate from SMT.
p=fn[61][0];byteFn=sir[p+10][1];bp=fn[byteFn][0]
byteExpected=[(1,byteFn,2,2),(9,sir[bp+1][1],0,0),(4,0,1,0),(4,1,2,0),(6,9,0,0),(3,1,255,0),(6,5,0,0),(19,0,0,0),(2,byteFn,0,0)]
assert [sir[bp+k]for k in range(9)]==byteExpected
assert '(defn- byte-at [x :i64 n :i64] :i64 (bit-and (u64-shift-right x n) 255))'in text
bindings=[]
for role,f in enumerate([21,24,27,30]):
 start=fn[f][0];lit0=sir[start+8][2];lit1=sir[start+14][2];entry=sir[start+2][1];right=sir[start+10][1];after=sir[start+15][1];assert len({entry,right,after})==3
 expect=[(1,f,1,1),(18,0,0,0),(9,entry,0,0),(4,0,1,0),(3,1,128,0),(7,2,0,0),(11,0,right,0),(4,0,1,0),(21,0,lit0,128),(10,after,0,0),(9,right,0,0),(4,0,1,0),(3,1,128,0),(6,2,0,0),(21,0,lit1,128),(9,after,0,0),(19,0,0,0),(2,f,0,0)]
 assert [sir[start+k]for k in range(18)]==expect
 name='dec-t'+str(role);assert re.search(r'\(defn- '+name+r' \[i :i64\] :i64',text)
 j=p+4+15*role;t=role+1;assert sir[j+10]==(4,t,role+2,0)and sir[j+11]==(3,t+1,8*role,0)and sir[j+12]==(13,byteFn,t,2)and sir[j+13]==(13,f,t,1)
 indices=[]
 for k in range(256):
  # Actual canonical branch picks correct128entry literal half with original maskedbyte domain.
  half,index=(0,k)if k<128 else(1,k-128);pool=next(q for q in cert if q['role']==role and q['literal']==[lit0,lit1][half]);off=pool['poolOffset']+8*index;value=struct.unpack('<Q',raw[off:off+8])[0];assert value==T[role][k];s=S[k];word=sum(mul(s,c)<<(8*i)for i,c in enumerate([14,9,13,11]));val=word if role==0 else((word<<(8*role))|(word>>(32-8*role)))&0xffffffff;assert val==value;indices.append({'index':k,'half':half,'slot':index,'nativeByteOffset':off,'nativeValue':value,'inverseSubByte':s,'formulaValue':val})
 bindings.append({'role':role,'fn':f,'sourceTypedSignature':'i64→i64, private definition','SIRRange':[start,start+17],'canonicalSIR':expect,'actualByteFn':byteFn,'shift':8*role,'actualMask':255,'cases':indices})
finiteFaults=[]
mutated=bytearray(raw);q=cert[0];mutated[q['poolOffset']]^=1;actual=struct.unpack('<Q',mutated[q['poolOffset']:q['poolOffset']+8])[0];assert actual!=T[0][0];finiteFaults.append({'id':'poolwordmutation','byteOffset':q['poolOffset'],'index':0,'original':T[0][0],'mutated':actual,'certificateRejects':True})
wrong=list(byteExpected);wrong[5]=(3,1,254,0);assert wrong!=byteExpected;finiteFaults.append({'id':'indexmaskmutation','SIR':bp+5,'original':255,'mutated':254,'inputLowByte':255,'actualMutatedIndex':254,'sourceIndex':255,'certificateRejects':True})
(D/'typed-index-pool-certificate.json').write_text(json.dumps({'binding':bindings,'byteFunction':{'id':byteFn,'SIRRange':[bp,bp+8],'canonicalSIR':byteExpected,'type':'i64,i64→i64','indexDomain':'((u64state >>8*role)&255), role0..3; no undefined shift','cases':256},'finiteFaults':finiteFaults,'proofBoundary':'Closed typed source definitions/currentactualbody certificate; future compiler matcher must separately bind checkedNF/open/currentcall closure. This is not selector/emitter proof.'},indent=2)+'\n')
def xorall(xs):
 a=xs[0]
 for b in xs[1:]:a=a^b
 return a
def gm(x,k,poly=0x1b):
 result=z.BitVecVal(0,8)
 for bit in range(4):
  if(k>>bit)&1:result=result^x
  x=(x<<1)^z.If(z.Extract(7,7,x)==1,z.BitVecVal(poly,8),z.BitVecVal(0,8))
 return result
def contribution(x,role,poly=0x1b):
 q=z.Concat(gm(x,11,poly),gm(x,13,poly),gm(x,9,poly),gm(x,14,poly))
 return z.RotateLeft(q,8*role)
matrix=[[14,11,13,9],[9,14,11,13],[13,9,14,11],[11,13,9,14]]
def mix(xs,poly=0x1b):return z.Concat(*reversed([xorall([gm(xs[k],matrix[row][k],poly)for k in range(4)])for row in range(4)]))
x=z.BitVecs('substituted0 substituted1 substituted2 substituted3',8);tableAlgebra=xorall([contribution(x[k],k)for k in range(4)]);mixAlgebra=mix(x)
a,b,c,d,key,mode,forward=z.BitVecs('state_a state_b state_c state_d key mode retained_forward_result',64);states=[a,b,c,d];v=[z.Extract(31,0,q)for q in states];packed=z.Concat(v[1],v[2],v[3],v[0]);byte=lambda q,k:z.Extract(8*k+7,8*k,q);selected=[byte(packed,4*((-row)%4)+row)for row in range(4)];direct=[byte(states[k],k)for k in range(4)]
InvS=z.Function('InvSBox',z.BitVecSort(8),z.BitVecSort(8));directSub=[InvS(q)for q in direct];packSub=[InvS(q)for q in selected]
col=xorall([contribution(q,k)for k,q in enumerate(directSub)]);hwcol=mix(packSub);full=z.ZeroExt(32,hwcol)^key;masked=z.ZeroExt(32,mix([InvS(byte(q&z.BitVecVal(0xffffffff,64),k))for k,q in enumerate(states)]))^key
# Query3 assumes only already-proved exact lane equality via shared value lemma; no source table omitted from final checker.
lemma32=z.BitVec('proved_inverse_lane32',32);inverseValue=z.ZeroExt(32,lemma32)^key;spec=z.If(mode==0,forward,inverseValue);dispatch=z.If(mode!=0,inverseValue,forward)
ref=z.ZeroExt(32,tableAlgebra)^key
wrongLane=z.ZeroExt(32,mix([x[0],x[3],x[2],x[1]]))^key
keyphase=z.ZeroExt(32,mix([x[k]^byte(key,k)for k in range(4)]))^(key&z.BitVecVal(0xffffffff00000000,64))
wrongPoly=z.ZeroExt(32,mix(x,0x1d))^key;wrongMode=z.If(z.Extract(31,0,mode)==0,forward,inverseValue)
qs=[('independent-substituted-lane',[tableAlgebra!=mixAlgebra],'unsat',tableAlgebra,mixAlgebra),('full64-packing-and-key',[z.Or(col!=hwcol,full!=masked,z.Extract(63,32,full)!=z.Extract(63,32,key))],'unsat',z.ZeroExt(32,col)^key,full),('full64-mode-lemma-dispatch',[spec!=dispatch],'unsat',spec,dispatch),('wrong-lane-control',[ref!=wrongLane],'sat',ref,wrongLane),('wrong-poly-control',[ref!=wrongPoly],'sat',ref,wrongPoly),('wrong-keyphase-control',[ref!=keyphase],'sat',ref,keyphase),('mode32-control',[spec!=wrongMode],'sat',spec,wrongMode)];assert len(qs)==7
rows=[];version=z.get_version_string();(D/'solver-version.json').write_text(json.dumps({'z3':version,'module':z.__file__,'queryTimeoutMs':30000,'attempts':1},indent=2)+'\n')
for name,assertions,want,left,right in qs:
 sol=z.Solver();sol.set(timeout=30000);sol.add(*assertions);(D/(name+'.smt2')).write_text(sol.to_smt2());print('START',name,flush=True);begin=time.monotonic();got=str(sol.check());r={'query':name,'expected':want,'actual':got,'elapsedSeconds':time.monotonic()-begin,'attempts':1};stdout=got+'\n'
 if got=='sat':
  m=sol.model();ev=lambda q:m.eval(q,model_completion=True).as_long();ce={str(q):ev(q)for q in x+states+[key,mode,forward,lemma32]};ce['actualReferenceValue']=ev(left);ce['actualMutatedValue']=ev(right);ce['xorDifference']=ce['actualReferenceValue']^ce['actualMutatedValue'];assert ce['xorDifference'];ce['referenceBytes']=list(ce['actualReferenceValue'].to_bytes(8,'little'));ce['mutatedBytes']=list(ce['actualMutatedValue'].to_bytes(8,'little'));ce['differentByteIndices']=[k for k in range(8)if ce['referenceBytes'][k]!=ce['mutatedBytes'][k]];r['actualCounterexample']=ce;stdout+=m.sexpr()+'\n'
 elif got=='unknown':r['reason']=sol.reason_unknown();stdout+=r['reason']+'\n'
 (D/(name+'.stdout')).write_text(stdout);rows.append(r);print(json.dumps(r),flush=True)
# Explicit proof DAG. Exhaustive8-bit certificate + algebra + packing + XOR/dispatch congruence imply SAME original lookup law.
lookupTerms=[{'op':'literal-lookup','role':k,'index':{'op':'extract8','state':k,'bit':8*k}}for k in range(4)]
expanded=[{'op':'contribution','role':k,'value':{'op':'inverseSbox','index':q['index']}}for k,q in enumerate(lookupTerms)]
derivation={'originalTerms':lookupTerms,'expandedTerms':expanded,'rules':[{'id':'finite-domain-exhaustion','premise':'mask255⇒8-bitindex; all256 canonicalpool cases proved perrole','result':'lookupTk(index)=contribution(InvSbox(index),role)'},{'id':'xor-congruence','premise':'four exact certified equalities','result':'XOR four originallookups = XOR four contributions'},{'id':'independent-byte-algebra-instantiation','premise':'UNSATquery1 for ANY four8-bit outputs, instantiate x[k]=InvSbox(actualidx[k])','result':'XOR contributions = inverseMix selectedcolumn'},{'id':'packing-and-selection-congruence','premise':'UNSATquery2, exact pack[a,d,c,b], byte shifts0/8/16/24','result':'same selectedInverseSbox bytes as originalindices'},{'id':'zeroextension-key-XOR-congruence','premise':'same32bitcolumn; arbitrary full64key','result':'original andhardware formula same64value, highkey retained'},{'id':'fullmode-dispatch-congruence','premise':'UNSATquery3 universal32lane lemma, full64modeeq0','result':'mode0opaque unchanged; arbitrarynonzero inversevalue same'}],'queryHashes':{q[0]:{'smt2':sha(D/(q[0]+'.smt2')),'stdout':sha(D/(q[0]+'.stdout'))}for q in qs[:3]},'finiteCertificateSHA256':sha(D/'typed-index-pool-certificate.json'),'originalLawRestored':all(r['actual']==r['expected']for r in rows),'notOracleReplacement':True}
assert len(derivation['rules'])<=64
(D/'composition-certificate.json').write_text(json.dumps(derivation,indent=2)+'\n')
report={'status':'PASS exact compositional inverse value law'if all(r['actual']==r['expected']for r in rows)else'FAIL/UNKNOWN exact compositional inverse value law','sourceSHA256':sha(src),'nativePoolsSHA256':sha(rawp),'solverVersion':version,'queries':rows,'finiteFaults':finiteFaults,'compositionCertificateSHA256':sha(D/'composition-certificate.json'),'typedPoolIndexCertificateSHA256':sha(D/'typed-index-pool-certificate.json'),'sameOriginalLaw':'Original exactfourliteral lookups with actualmasked64-state bytes, full64key XORafter mix, full64mode dispatch. Finite8-bit allvalues plusuniversal strongerindependent8-bit algebra+packing substitution/transitivity, not a weaker oracle.','oldUnknownPreserved':True,'proofBoundary':['Explicitformula laws and checked finite certificate, not selector/matcher/emitter/encoding/hardware/fuel/trap/arena/ABI/OS proof','Source typed signatures/canonicalSIR bound; futurecompiler must separately bind checkedNF/open/currentcall identity','No native/compiler/network/timing or adoption decision']}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
for p,h in pr['inputs'].items():assert sha(Path(p))==h
print(report['status'],flush=True)
