from pathlib import Path
import subprocess,os,re,json,hashlib
W=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[]
for generation in range(1,5):
 previous=generation-1;off=(W/f'seed-{previous}.offset').read_text().strip()
 for label,args in [('compile',['compile',str(W/'unity-inverse-on.kotoba'),'--target','aarch64-macos','--output',str(W/f'seed-{generation}.kseed')]),('extract',['extract-native',str(W/f'seed-{generation}.kseed'),'--symbol','main','--output',str(W/f'seed-{generation}.bin')])]:
  q=subprocess.run([str(W/'kexe-loader'),str(W/f'seed-{previous}.bin'),off,'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(W/f'seed-{generation}-{label}.log').write_text(q.stdout+q.stderr);assert q.returncode==0,(generation,label,q.stdout[-2500:],q.stderr[-1000:])
  if label=='extract':offset=re.search(r':offset (\d+)',q.stdout).group(1);(W/f'seed-{generation}.offset').write_text(offset+'\n')
 rows.append({'generation':generation,'bytes':(W/f'seed-{generation}.bin').stat().st_size,'sha256':sha(W/f'seed-{generation}.bin'),'offset':int(offset)});print('PASS native generation',rows[-1],flush=True)
assert len({(x['sha256'],x['offset'],x['bytes']) for x in rows[1:]})==1
for p,h in json.loads((W/'preregistration.json').read_text())['inputs'].items():assert sha(W/p)==h
(W/'fixed-point.json').write_text(json.dumps({'status':'PASS experimental inverse-on native generations2/3/4 byte-fixed-point; no hardware/ABI/performance qualification','generations':rows,'notPerformanceClaim':True},indent=2)+'\n')
