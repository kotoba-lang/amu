from pathlib import Path
import json,struct,copy,hashlib,shutil
I=Path(__file__).resolve().parent;B=I/'qualified-baseline-observer'
if not B.exists():
 B.mkdir()
 for p in Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation/observer/ports').iterdir():
  d=B/p.name;d.mkdir()
  for n in ['compile.log','native.bin','extract.log']:shutil.copy2(p/n,d/n)
exec((I/'machine-decoder.py').read_text())
def aesload(p):
 d=parse(p)
 for tag,key in [('ASPRE','pre'),('ASPOST','post'),('ASARG','args')]:
  d[key]=[tuple(map(int,l.split()[1:])) for l in (p/'compile.log').read_text().splitlines() if l.startswith(tag+' ')]
 return d
def verify_sites(a,b):
 assert a['sir']==b['sir'] and a['fn'].keys()==b['fn'].keys()
 for f,v in a['fn'].items():assert v[:-1]==b['fn'][f][:-1],('frame/register/callee',f)
 assert len(b['pre'])==len(b['post']) and len(b['args'])==len(b['pre'])*6
 ea={v[0]:v for v in a['events']};eb={v[0]:v for v in b['events']};sites=[]
 charge=[0xf94004f0,0xf1000610,0x54000042,0xd4200000,0xf90004f0]
 hardware=[0x4f00e401,0x1e270020,0x4e0c1c40,0x4e141c60,0x4e1c1c80,0x4e284820,0x4e286800,0x0e043c10,0xca050200]
 for j,(pre,post) in enumerate(zip(b['pre'],b['post'])):
  i,f,t,start,fix,frame,height,ctx,vmode=pre;ii,guard,jump,fallback,after,end,words,fixafter=post
  assert i==ii and frame>0 and t>=0 and t+6<=height and frame<=4096 and ctx in [0,1] and words<=96
  assert eb[i]==(i,0,start,end) and ea[i][1]==0 and a['sir'][i]==(13,f,t,6)
  oldlo,oldhi=ea[i][2:];oldfix=[x for x in a['fix'] if oldlo<=x[1]<oldhi];newfix=[x for x in b['fix'] if start<=x[1]<end]
  assert len(oldfix)==len(newfix)==1 and oldfix[0][2:]==newfix[0][2:]==(4,f,0) and oldfix[0][0]==newfix[0][0]==fix and fixafter==fix+1
  oa=oldfix[0][1];assert newfix[0][1]==fallback and after==fallback+1 and jump+1==fallback
  assert a['words'][oldlo-1:oa-1]==b['words'][start-1:guard-1],('all argument/live/context prefix exact',i)
  assert a['words'][oa:oldhi-1]==b['words'][after-1:end-1],('all result finalization suffix exact',i)
  assert b['words'][guard:jump-1]==charge*6+hardware
  assert b['words'][guard-1]==0xb5000000|((fallback-guard)<<5)
  assert b['words'][jump-1]==0x14000000|(after-jump)
  assert oa+branch(a['words'][oa-1])[1]==a['fn'][f][-1]
  assert fallback+branch(b['words'][fallback-1])[1]==b['fn'][f][-1]
  assert words==end-start and end-start-(oldhi-oldlo)==41
  for k,(u,kind,value,r,home,offset) in enumerate(b['args'][6*j:6*j+6]):
   assert u==t+k and (r<0 or r==31 or 9<=r<=15 or 19<=r<=28)
   assert kind in [1,2,3,4] and home>0 and offset==frame-8*(home+1)
   if kind==1:assert r==(9+u if u<7 else -1)
  sites.append({'sir':i,'callee':f,'oldLo':oldlo,'oldHi':oldhi,'newLo':start,'newHi':end,'oldFix':oa,'newFix':fallback,'guard':guard,'jump':jump,'charged':6,'callerFrame':frame,'words':words})
 return sites
def normalized(d,sites,new):
 stream=[];pos={};edges=[];internal=set();lit={};regions={(s['newLo'] if new else s['oldLo']):(s['newHi'] if new else s['oldHi'],s) for s in sites}
 for ix,at,k,t,u in d['fix']:
  if k==5:lit[at]=(t,0);lit[at+1]=(t,1)
 i=1
 while i<d['n']:
  if i in regions:
   end,s=regions[i]
   for k in range(i,end):pos[k]=len(stream)
   internal.update(range(i+1,end));stream.append(('CERTIFIED-AES',s['sir'],s['callee']));i=end;continue
  pos[i]=len(stream);z=d['words'][i-1];q=branch(z)
  if q:stream.append(('BR',q[0]));edges.append((len(stream)-1,i+q[1]))
  elif i in lit:stream.append(('LIT',lit[i],z&~0x1fffe0))
  else:stream.append(('WORD',z))
  i+=1
 pos[d['n']]=len(stream)
 assert set(pos)==set(range(1,d['n']+1))
 for x,target in edges:assert target not in internal,('external incoming into replacement',target)
 return stream,pos,edges


def audit(a,b):
 sites=verify_sites(a,b);aa,pa,ea=normalized(a,sites,False);bb,pb,eb=normalized(b,sites,True)
 assert aa==bb,next(((i,x,y) for i,(x,y) in enumerate(zip(aa,bb)) if x!=y),(len(aa),len(bb)))
 assert len(ea)==len(eb)
 for x,y in zip(ea,eb):assert x[0]==y[0] and pa[x[1]]==pb[y[1]],('all projected branches/calls/ADR',x,y)
 for f,v in a['fn'].items():assert pa[v[-1]]==pb[b['fn'][f][-1]]
 assert len(a['events'])==len(b['events'])
 for x,y in zip(a['events'],b['events']):assert x[:2]==y[:2] and pa[x[2]]==pb[y[2]] and pa[x[3]]==pb[y[3]]
 assert len(a['fix'])==len(b['fix']);literal=private=0
 ap=((a['n']-1)*4+7)//8*8;bp=((b['n']-1)*4+7)//8*8
 for (ix,at,k,t,u),(iy,bt,l,s,v) in zip(a['fix'],b['fix']):
  assert (ix,k,t,u)==(iy,l,s,v) and pa[at]==pb[bt]
  if k==5:
   old=((a['words'][at-1]>>5)&65535)|(((a['words'][at]>>5)&65535)<<16);new=((b['words'][bt-1]>>5)&65535)|(((b['words'][bt]>>5)&65535)<<16);assert old-ap==new-bp and pa[at+1]==pb[bt+1];literal+=2
  if u:
   assert k==4 and u==1;oe=a['fn'][t][-1];ne=b['fn'][t][-1];assert a['words'][oe-1]==b['words'][ne-1]==0xd2800005
   assert at+branch(a['words'][at-1])[1]==oe+1 and bt+branch(b['words'][bt-1])[1]==ne+1;private+=1
 assert a['raw'][ap:]==b['raw'][bp:] and set(a['raw'][(a['n']-1)*4:ap])<={0} and set(b['raw'][(b['n']-1)*4:bp])<={0}
 assert b['n']-a['n']==sum(s['newHi']-s['newLo']-(s['oldHi']-s['oldLo']) for s in sites)
 return {'sites':sites,'remainingWords':len(aa),'remainingEdges':len(ea),'literalWords':literal,'privateAux1':private,'addedWords':b['n']-a['n']}
rows=[];data={}
for p in sorted((I/'observer/ports').iterdir()):
 a=aesload(B/p.name);b=aesload(p);r=audit(a,b);data[p.name]=(a,b);rows.append({'workload':p.name,**r});print('PASS AES fullmachine projection',p.name,flush=True)
a,b=data['nettle-aes'];site=next(x for x in rows if x['workload']=='nettle-aes')['sites'][0];controls=[]
for name,word,mask in [('mode guard',site['guard'],1),('firstcharge',site['guard']+2,1),('sixth publication',site['guard']+30,1),('wrongkeyphase',site['guard']+36,0x20),('wronglane',site['guard']+33,0x10000),('fullkey XOR',site['guard']+39,0x10000),('fallbacktarget',site['newFix'],1),('retainedgeneric',b['fn'][site['callee']][-1],1),('retainedordinary',site['newHi']+3,1)]:
 d=copy.deepcopy(b);d['words'][word-1]^=mask
 try:audit(a,d)
 except (AssertionError,KeyError,IndexError) as e:controls.append({'name':name,'status':'DETECTED','diagnostic':str(e)[:300]})
 else:raise AssertionError('fault accepted '+name)
(I/'machine-audit.json').write_text(json.dumps({'status':'PASS all19 exact wholemachine projection except four independently verified AES mode-guarded value spans','rows':rows,'controls':controls,'trustBoundary':'Typed checked SIR/fullbody+immutable table contract, actualargumentbank observations, exact hardware+6charge blocks, retainedgeneric bodies and fallbackBL, every remainingword/edge/fix/literalpool checked. No arbitrary opcode/constants mask. No timing.'},indent=2)+'\n')
