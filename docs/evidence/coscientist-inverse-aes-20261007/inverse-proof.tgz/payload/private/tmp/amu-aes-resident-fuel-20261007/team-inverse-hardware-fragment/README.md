Native inverse-AES fragment calibration

Preregistered four variants, sixteen processes, 277 fixed cases per group. All positive 1,108 cases match the unchanged original-source four-table oracle. Three fixed mutations detected with registered witnesses; all changed and unchanged cases retained. Each executable exact ten-word symbol binding is recorded in build-receipts.json. Each process confirms actual local AES feature before calling the fragment. Local host MacBookPro18,4, arm64, main-2.local.

This always-inverse standalone AAPCS fragment ignores mode. It does not establish compiled CALL capture, generic export/FADDR behavior, private host mask6, six original fuel publications, fullM, compiled mode dispatch, performance or product adoption. No compiler, source, oracle, solver, network or timing work was performed. First sandbox feature-read denial is retained separately; authorized read returned AES1 before probes.
