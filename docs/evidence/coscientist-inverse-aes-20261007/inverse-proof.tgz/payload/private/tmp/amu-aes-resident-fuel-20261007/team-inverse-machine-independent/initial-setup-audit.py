from pathlib import Path
import json,struct,copy,hashlib
D=Path(__file__).parent;H=D.parent;C=H/'team-inverse-native-images/continuation';B=H/'implementation';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in json.loads((D/'preregistration.json').read_text())['inputs'].items():assert sha(Path(p))==h,p
exec((H/'team-independent/machine-decoder.py').read_text().split('def parse')[0])
old=(H/'team-independent/baseline-machine-audit.py').read_text();exec('def normalized'+old.split('def normalized',1)[1].split('def audit',1)[0])
def load(p):
 log=(p/('compile.stdout' if(p/'compile.stdout').exists()else'compile.log')).read_text();r={}
 for line in log.splitlines():
  x=line.split()
  if x and x[0]in ['SIR','FN','FREC','EMIT','FIX','LIT','CACHE','ASPRE','ASPOST','ASARG','AIARG','AIPRE','AIPOST','RFCORE','TABLES']:
   r.setdefault(x[0],[]).append(tuple(map(int,x[1:])))
 d={'records':r,'sir':{x[0]:x[1:]for x in r['SIR']},'fn':{x[0]:x[1:]for x in r['FN']},'events':r['EMIT'],'fix':r['FIX'],'raw':(p/'native.bin').read_bytes()};d['n']=max(x[3]for x in d['events']);d['words']=list(struct.unpack('<%dI'%(d['n']-1),d['raw'][:4*(d['n']-1)]));return d
charge=[0xf94004f0,0xf1000610,0x54000042,0xd4200000,0xf90004f0];rf=[charge[0],0xf1001a1f,0x540001c3]+[charge[1],charge[4]]*6+[0x1400001f]+charge*6
fw=[0x4f00e401,0x1e270020,0x4e0c1c40,0x4e141c60,0x4e1c1c80,0x4e284820,0x4e286800,0x0e043c10,0xca050200];iv=[0x4f00e401,0x1e270020,0x4e0c1c80,0x4e141c60,0x4e1c1c40,0x4e285820,0x4e287800,0x0e043c10,0xca050200]
def sites(a,b):
 ra,rb=a['records'],b['records'];pre=rb.get('AIPRE',[]);post=rb.get('AIPOST',[]);assert len(pre)==len(post)==len(rb.get('RFCORE',[]));out=[]
 assert a['sir']==b['sir'] and a['fn'].keys()==b['fn'].keys()
 for f,v in a['fn'].items():assert v[:-1]==b['fn'][f][:-1],('frame/ns/dp/nsv/leaf',f)
 assert ra['CACHE']==rb['CACHE'];assert ra.get('ASARG',[])==rb.get('AIARG',[])
 for k,(p,q,r,op,oq)in enumerate(zip(pre,post,rb.get('RFCORE',[]),ra.get('ASPRE',[]),ra.get('ASPOST',[]))):
  i,f,t,lo,fix,frame,height,ctx,vm,used,count=p;ii,dispatch,jump,inverse,after,hi,words,fa,err=q;oi,og,oj,of,oa,oh,ow,ofa=oq;oldlo=op[3]
  assert p[:3]==op[:3] and p[5:9]==op[5:] and i==ii==oi and a['sir'][i]==(13,f,t,6)
  assert 0<=t<=1 and frame>0 and frame<=4096 and t+6<=height<=16 and ctx in[0,1] and vm==0 and err==0 and words==hi-lo==73<=95<96
  assert used==k*73 and count==k<64 and used+96<=4096 and lo+96<=524288 and fix==op[4]-k and fa==fix and ofa==op[4]+1
  core,guard,fjoin,slow,aftercharge,re=r;assert re==0 and(core,guard,fjoin,slow,aftercharge)==(dispatch-46,dispatch-44,dispatch-31,dispatch-30,dispatch)
  assert a['words'][oldlo-1:og-1]==b['words'][lo-1:core-1],('six capture/live/home/ctx exact',i)
  assert a['words'][og:oj-1]==rf+fw and b['words'][core-1:dispatch-1]==rf
  assert b['words'][dispatch-1]==0xb5000000|((inverse-dispatch)<<5) and inverse==jump+1 and jump==dispatch+10
  assert b['words'][dispatch:jump-1]==fw and b['words'][inverse-1:after-1]==iv and after==inverse+9
  assert b['words'][jump-1]==0x14000000|(after-jump)
  assert a['words'][oa-1:oh-1]==b['words'][after-1:hi-1],('cleanup/take exact',i)
  assert a['words'][og-1]==0xb5000000|((of-og)<<5) and a['words'][oj-1]==0x14000000|(oa-oj)
  assert of+branch(a['words'][of-1])[1]==a['fn'][f][-1]
  af=[x for x in a['fix']if oldlo<=x[1]<oh];bf=[x for x in b['fix']if lo<=x[1]<hi];assert len(af)==1 and not bf and af[0]==(op[4],of,4,f,0)
  for z,(u,kind,value,reg,home,offset)in enumerate(rb['AIARG'][6*k:6*k+6]):assert u==t+z and kind in[1,2,3,4]and(reg<0 or reg==31 or9<=reg<=15 or19<=reg<=28)and home>0 and offset==frame-8*(home+1)
  out.append({'sir':i,'callee':f,'oldLo':oldlo,'oldHi':oh,'newLo':lo,'newHi':hi,'oldFix':of,'dispatch':dispatch,'jump':jump,'inverse':inverse,'afterValues':after,'core':core,'words':words,'removedFixIndex':op[4],'frame':frame,'height':height,'priorUsed':used,'priorSites':count})
 assert len(out)==len(pre)==len(ra.get('ASPRE',[]));return out
def audit(a,b):
 ss=sites(a,b);aa,pa,ea=normalized(a,ss,False);bb,pb,eb=normalized(b,ss,True);assert aa==bb and len(ea)==len(eb)
 for x,y in zip(ea,eb):assert x[0]==y[0]and pa[x[1]]==pb[y[1]],('edge',x,y)
 for f,v in a['fn'].items():assert pa[v[-1]]==pb[b['fn'][f][-1]]
 for x,y in zip(a['events'],b['events']):assert x[:2]==y[:2]and pa[x[2]]==pb[y[2]]and pa[x[3]]==pb[y[3]]
 assert len(a['events'])==len(b['events']);removed={s['removedFixIndex']for s in ss};af=[x for x in a['fix']if x[0]not in removed];assert len(af)==len(b['fix'])
 ap=((a['n']-1)*4+7)//8*8;bp=((b['n']-1)*4+7)//8*8
 for(ix,at,k,t,u),(iy,bt,l,f,v)in zip(af,b['fix']):
  assert ix-sum(x<ix for x in removed)==iy and(k,t,u)==(l,f,v)and pa[at]==pb[bt]
  if k==5:
   get=lambda d,j:((d['words'][j-1]>>5)&65535)|(((d['words'][j]>>5)&65535)<<16)
   assert get(a,at)-ap==get(b,bt)-bp and pa[at+1]==pb[bt+1]
  if u:assert u==1 and k==4 and a['words'][a['fn'][t][-1]-1]==b['words'][b['fn'][t][-1]-1]==0xd2800005
 assert a['raw'][ap:]==b['raw'][bp:]and set(a['raw'][(a['n']-1)*4:ap])<={0}and set(b['raw'][(b['n']-1)*4:bp])<={0}
 assert b['n']-a['n']==sum(s['newHi']-s['newLo']-(s['oldHi']-s['oldLo'])for s in ss)
 return {'sites':ss,'remainingCanonicalWords':len(aa),'remainingCanonicalEdges':len(ea),'removedBLFixes':len(removed),'addedWords':b['n']-a['n'],'literalPoolBytes':len(b['raw'])-bp}
rows=[];data={}
for p in sorted((C/'on').iterdir()):
 name=p.name;a=load(B/'observer/ports'/name);b=load(C/'observer/ports'/name)
 assert b['raw']==(p/'native.bin').read_bytes();assert(B/'ports'/name/'native.bin').read_bytes()==(C/'default/ports'/name/'native.bin').read_bytes()==a['raw']
 for arm in[p,C/'observer/ports'/name]:assert(arm/'native.offset').read_bytes()==(p/'native.offset').read_bytes()
 assert(C/'default/ports'/name/'native.offset').read_bytes()==(B/'ports'/name/'native.offset').read_bytes()
 if name!='nettle-aes':assert a['raw']==b['raw']and(p/'native.offset').read_bytes()==(B/'ports'/name/'native.offset').read_bytes()
 rr=audit(a,b);rows.append({'workload':name,**rr});data[name]=(a,b);print('PASS',name,flush=True)
a,b=data['nettle-aes'];s=rows[[r['workload']for r in rows].index('nettle-aes')]['sites'][0];faults=[('wrong mode width',s['dispatch'],0x35000160),('wrong inverse packing',s['inverse']+2,0x4e0c1c40),('wrong AESD',s['inverse']+5,0x4e284820),('wrong AESIMC',s['inverse']+6,0x4e286800),('truncated key',s['inverse']+8,0x4a050200),('omitted publication',s['core']+4,0xd503201f),('bulk subtract6',s['core']+3,0xf1001a10),('corrupt join',s['jump'],0x14000009)];controls=[]
for name,at,value in faults:
 m=copy.deepcopy(b);m['words'][at-1]=value
 try:audit(a,m)
 except(AssertionError,KeyError,IndexError)as e:controls.append({'fault':name,'word':at,'originalWord':b['words'][at-1],'alteredWord':value,'status':'REJECTED','diagnostic':str(e)[:250]})
 else:raise AssertionError(('accepted fault',name))
out={'status':'PASS original19 actual wholemachine projection +8 actualword faults','rows':rows,'controls':controls,'newNativeSolverNetworkTiming':0,'boundary':'Offline actual machine/source projection only; no inverse execution/value/hardware/fuel-prefix/ABI/wholeM-error qualification. Baseline RF observer has no FREC/LIT records; SIR/FN/cache and exact source/pool bytes bind old inputs, new FREC/LIT are retained diagnostics, not claimed independently baseline-record compared.'};(D/'machine-report.json').write_text(json.dumps(out,indent=2)+'\n')
