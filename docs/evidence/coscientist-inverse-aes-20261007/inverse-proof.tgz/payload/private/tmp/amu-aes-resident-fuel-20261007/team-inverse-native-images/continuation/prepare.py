from pathlib import Path
import json,hashlib,shutil,stat
H=Path('/private/tmp/amu-aes-resident-fuel-20261007');D=Path(__file__).parent;V=H/'inverse-implementation-v2';B=H/'root-inverse-selfbuild-v2';I=H/'implementation';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pre=json.loads((D/'preregistration.json').read_text())
for p,v in {**pre['inputs'],**pre['originalSources']}.items():assert sha(Path(p))==v['sha256'] and Path(p).stat().st_size==v['bytes']
shutil.copyfile(V/'kexe-loader',D/'kexe-loader');(D/'kexe-loader').chmod(0o755)
shutil.copyfile(B/'seed-4.bin',D/'seed-on.bin');shutil.copyfile(B/'seed-4.offset',D/'seed-on.offset');shutil.copyfile(V/'unity-inverse-default.kotoba',D/'unity-default.kotoba')
shutil.copyfile(I/'ports-build.json',D/'RF-baseline19.json');shutil.copyfile(I/'source-snapshot/bench/embench/comparison-matrix.json',D/'comparison-matrix.json')
(D/'sources').mkdir();matrix=json.loads((D/'comparison-matrix.json').read_text())
for e in matrix['entries']:shutil.copyfile(H/'team-timing/remote-campaign-evidence'/e['workload']/'source.kotoba',D/'sources'/(e['workload']+'.kotoba'))
def form(s,name):
 a=s.index('(defn- '+name+' ');depth=0;quoted=False;escaped=False
 for j in range(a,len(s)):
  c=s[j]
  if quoted:
   if escaped:escaped=False
   elif c=='\\':escaped=True
   elif c=='"':quoted=False
  elif c=='"':quoted=True
  elif c=='(':depth+=1
  elif c==')':
   depth-=1
   if depth==0:return s[a:j+1]
 raise ValueError(name)
def out(tag,fields):
 s='"\\n"'
 for x in reversed(fields):s=f'(string-concat (string-from-i64 {x}) (string-concat " " {s}))'
 return f'(io-out (string-concat "{tag} " {s}))'
g=(V/'41-a64gen-inverse-on.kotoba').read_text();old=(I/'observer/41.kotoba').read_text()
for name in ['gn-op-fn','gn-op-fn2','gn-loop']:g=g.replace(form(g,name),form(old,name))
extra='\n'.join(form(old,n) for n in ['gn-census-snapshot','gn-census-fixes'])
extra+='\n(defn- ai-observe-args [M :vector-i64 t :i64 n :i64] :i64 (if (= n 0) 0 (let [printed '+out('AIARG',['t','(gn-dk M t)','(gn-dv M t)','(gn-sr M t 1)','(gn-home M t)','(gn-soff M (gn-home M t))'])+'] (ai-observe-args M (inc t) (dec n)))))\n'
extra+='\n(defn- ai-observe-fnrecords [M :vector-i64 f :i64] :i64 (if (>= f (vector-at M MM-FN-N)) 0 (let [printed '+out('FREC',['f']+[f'(gn-fnf M f {j})' for j in range(16)])+'] (ai-observe-fnrecords M (inc f)))))\n'
extra+='\n(defn- ai-observe-literals [M :vector-i64 k :i64] :i64 (if (>= k (vector-at M MM-LIT-N)) 0 (let [printed '+out('LIT',['k']+[f'(gn-litf M k {j})' for j in range(4)])+'] (ai-observe-literals M (inc k)))))\n'
g=g.replace('(defn- as-call [',extra+'\n(defn- as-call [')
# Keep the old as path available and observe it separately.
asform=form(g,'as-call');observed=asform.replace('(let [start (vector-at M MM-CODE-N) m0','(let [observed (ai-observe-args M t 6) start (vector-at M MM-CODE-N) pre '+out('ASPRE',['i','f','t','start','(vector-at M MM-FIX-N)','(gn-g M gn-f-fb)','(gn-g M gn-f-h)','(gn-g M gn-f-ctx)','(gn-g M gn-f-vmode)'])+' m0')
observed=observed.replace('words (- (vector-at m4 MM-CODE-N) start)]','words (- (vector-at m4 MM-CODE-N) start) post '+out('ASPOST',['i','guard','jump','fallback','after','(vector-at m4 MM-CODE-N)','words','(vector-at m4 MM-FIX-N)'])+']');g=g.replace(asform,observed)
rf=form(g,'rf-charges');rfnew=rf.replace('(let [m0 (-> M','(let [start (vector-at M MM-CODE-N) m0 (-> M').replace('after (vector-at m3 MM-CODE-N)]','after (vector-at m3 MM-CODE-N) observed '+out('RFCORE',['start','guard','jump','slow','after','(vector-at m3 MM-ERR)'])+']');g=g.replace(rf,rfnew)
ai=form(g,'ai-call');ainew=ai.replace('(let [start (vector-at M MM-CODE-N)','(let [args_observed (ai-observe-args M t 6) start (vector-at M MM-CODE-N) pre '+out('AIPRE',['i','f','t','start','(vector-at M MM-FIX-N)','(gn-g M gn-f-fb)','(gn-g M gn-f-h)','(gn-g M gn-f-ctx)','(gn-g M gn-f-vmode)','(gn-g M as-used)','(gn-g M as-sites)']))
ainew=ainew.replace('words (- (vector-at m4 MM-CODE-N) start)]','words (- (vector-at m4 MM-CODE-N) start) post '+out('AIPOST',['i','dispatch','jump','inverse','after','(vector-at m4 MM-CODE-N)','words','(vector-at m4 MM-FIX-N)','(vector-at m4 MM-ERR)'])+']');g=g.replace(ai,ainew)
g=g.replace('m1 (mem-alloc m0 (+ gn-a-lp MM-LABEL-CAP 82))','observed_sir (gn-census-snapshot m0 1) observed_lit (ai-observe-literals m0 1) observed_tables '+out('TABLES',['(vector-at m0 MM-SIR-N)','(vector-at m0 MM-FN-N)','(vector-at m0 MM-LIT-N)','(vector-at m0 MM-LITB-N)','(vector-at m0 MM-CODE-N)','(vector-at m0 MM-FIX-N)'])+' m1 (mem-alloc m0 (+ gn-a-lp MM-LABEL-CAP 82))')
g=g.replace('m3 (gn-loop m2 1)]','m3 (gn-loop m2 1) observed_fix (gn-census-fixes m3 1) observed_fn (ai-observe-fnrecords m3 1)]')
O=D/'observer';O.mkdir();(O/'41.kotoba').write_text(g);on=(V/'41-a64gen-inverse-on.kotoba').read_text();unity=(V/'unity-inverse-on.kotoba').read_text();assert unity.count(on)==1;(O/'unity.kotoba').write_text(unity.replace(on,g))
schemas={'AIARG':'temp descriptorKind descriptorValue actualRegister home frameByteOffset','AIPRE':'sir target temp start fixBefore frame height ctx vmode priorUsed priorSites','AIPOST':'sir dispatchWord jumpWord inverseStart afterValues finalWord fullSpanWords fixAfter MMERR','RFCORE':'chargeStart unsignedGuardWord fastJoinWord slowStart afterCharges MMERR','ASPRE':'sir target temp start fixBefore frame height ctx vmode','ASPOST':'sir modeGuard joinWord genericBL afterCall finalWord fullWords fixAfter','FN':'fnId sir frame ns dp nsv leaf firstCodeWord','FREC':'fnId all16FFfields0..15 aftergen','SIR':'index opcode a b c beforegen','FIX':'index at kind target aux aftergen','EMIT':'sir skippedSuccessors firstWord exclusiveLastWord','CACHE':'sir vmodeBefore vslotBefore vmodeAfter vslotAfter','LIT':'literalId all4fields0..3 beforegen','TABLES':'SIR_N FN_N LIT_N LITB_N CODE_N FIX_N beforegen'};(D/'observer-schemas.json').write_text(json.dumps(schemas,indent=2)+'\n')
fs=[p for p in D.rglob('*') if p.is_file() and p.name!='prepared-source-pins.json'];(D/'prepared-source-pins.json').write_text(json.dumps({str(p.relative_to(D)):{'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(stat.S_IMODE(p.stat().st_mode))} for p in sorted(fs)},indent=2)+'\n');print('prepared observer source',sha(O/'41.kotoba'));print('prepared observer unity',sha(O/'unity.kotoba'))
