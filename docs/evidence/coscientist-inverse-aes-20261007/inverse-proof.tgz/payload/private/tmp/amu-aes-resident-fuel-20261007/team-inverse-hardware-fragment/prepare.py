from pathlib import Path
import json,struct,hashlib
D=Path(__file__).parent;W=D.parent
r=json.loads((D/'preregistration.json').read_text());cases=json.loads((W/'team-inverse-native-calibration-plan/case-manifest.json').read_text())['cases']
(D/'host-feature.json').write_text(json.dumps({'AES':1,'model':'MacBookPro18,4','arch':'arm64','hostname':'main-2.local','verifiedReadOnlySysctl':True},indent=2)+'\n')
for g in range(4):
 c=[(i,c) for i,c in enumerate(cases) if c['group']==g];assert len(c)==277
 (D/f'group-{g}.bin').write_bytes(b''.join(struct.pack('<8Q',i,*c['argsUint64'],c['inverseFragmentExpectedUint64']) for i,c in c))
for name in ['positive',*r['mutations']]:
 words=r['words'].copy()
 if name!='positive':
  for k,v in r['mutations'][name]['wordChanges'].items():words[int(k)]=v
 (D/f'{name}.s').write_text('.text\n.p2align 2\n.globl _inv_probe\n_inv_probe:\n'+''.join(f' .long 0x{v:08x}\n' for v in words))
(D/'harness.c').write_text(r'''#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/sysctl.h>
extern uint64_t inv_probe(uint64_t,uint64_t,uint64_t,uint64_t,uint64_t,uint64_t);
int main(int argc,char **argv){
 int aes=0;size_t size=sizeof(aes);
 if(sysctlbyname("hw.optional.arm.FEAT_AES",&aes,&size,0,0)!=0||size!=sizeof(aes)||aes!=1){fprintf(stderr,"FEATURE_REFUSED\n");return 2;}
 if(argc!=3)return 3;
 FILE*f=fopen(argv[1],"rb");if(!f)return 3;
 uint64_t q[8];int n=0,bad=0;
 while(fread(q,sizeof(q),1,f)==1){
  uint64_t v=inv_probe(q[1],q[2],q[3],q[4],q[5],q[6]);
  printf("%llu %llu\n",(unsigned long long)q[0],(unsigned long long)v);
  bad+=(v!=q[7]);n++;
 }
 int err=ferror(f);fclose(f);
 if(n!=277||err)return 3;
 fprintf(stderr,"AES=1 cases=%d mismatches=%d\n",n,bad);
 return (argv[2][0]=='p'&&bad)?4:0;
}
''')
print('prepared four sources and four fixed groups')
