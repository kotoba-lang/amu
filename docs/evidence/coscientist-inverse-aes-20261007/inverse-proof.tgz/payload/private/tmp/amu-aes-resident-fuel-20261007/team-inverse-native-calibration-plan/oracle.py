from pathlib import Path
import json,re,hashlib
D=Path(__file__).parent;pr=json.loads((D/'preregistration.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in pr['inputs'].items():assert sha(Path(p))==h
src=Path(next(p for p in pr['inputs']if p.endswith('/source.kotoba')));s=src.read_text();read=lambda n:sum([list(map(int,re.search(r'\(def '+n+'-'+str(k)+r' \[([^]]+)\]',s)[1].split()))for k in range(2)],[]);T=[read('dec-t'+str(k))for k in range(4)];E=[read('enc-t'+str(k))for k in range(4)];S=read('dec-sbox');MASK=(1<<64)-1
sign=lambda q:q-(1<<64)if q&(1<<63)else q
xor=lambda vals:__import__('functools').reduce(lambda a,b:a^b,vals)
def mul(a,b,poly=0x11b):
 v=0
 for _ in range(8):
  if b&1:v^=a
  a=((a<<1)^(poly if a&128 else 0))&255;b>>=1
 return v
def mix(q,poly=0x11b,inv=True):
 mat=[[14,11,13,9],[9,14,11,13],[13,9,14,11],[11,13,9,14]]if inv else[[2,3,1,1],[1,2,3,1],[1,1,2,3],[3,1,1,2]]
 return sum(xor([mul(q[k],mat[row][k],poly)for k in range(4)])<<(8*row)for row in range(4))
def original(words,key,tables):return xor([tables[k][(words[k]>>(8*k))&255]for k in range(4)])^key
rows=[]
def add(id,mode,words,key,group):
 assert len(words)==4 and all(0<=q<=MASK for q in words+[key,mode]);idx=[(words[k]>>(8*k))&255 for k in range(4)];inverse=original(words,key,T);forward=original(words,key,E);sub=[S[q]for q in idx];formula=mix(sub)^key;assert formula==inverse
 wrongpack=mix([S[words[0]&255],S[(words[3]>>8)&255],S[(words[2]>>16)&255],S[(words[1]>>24)&255]])^key
 mutants={'wrongWholeWordBDpacking':wrongpack,'wrongMixPolynomial':mix(sub,0x11d)^key,'AESMCinsteadAESIMC':mix(sub,inv=False)^key,'keyBeforeInverseMix':mix([sub[k]^((key>>(8*k))&255)for k in range(4)])^(key&0xffffffff00000000),'mode32compare':forward if mode&0xffffffff==0 else inverse}
 actual=forward if mode==0 else inverse
 rows.append({'id':id,'group':group,'argsUint64':[mode]+words+[key],'argsI64':[sign(q)for q in [mode]+words+[key]],'originalByteIndices':idx,'reversedPackedWords32':[words[k]&0xffffffff for k in [0,3,2,1]],'inverseFragmentExpectedUint64':inverse,'inverseFragmentExpectedI64':sign(inverse),'compiledCALLExpectedUint64':actual,'compiledCALLExpectedI64':sign(actual),'actualForwardSourceResultUint64':forward,'actualInverseSourceResultUint64':inverse,'mutatedValuesUint64':mutants,'detectedAgainstInverse':[k for k,v in mutants.items()if k!='mode32compare'and v!=inverse],'mode32DetectedAgainstActualDispatch':mutants['mode32compare']!=actual})
for k in range(4):
 for x in range(256):
  w=[0]*4;w[k]=x<<(8*k);add('singlebyte-'+str(k)+'-'+str(x),1,w,0,k)
for mi,m in enumerate(pr['dataset']['matrix']['modes']):
 for wi,w in enumerate(pr['dataset']['matrix']['states']):
  for ki,k in enumerate(pr['dataset']['matrix']['keys']):add('matrix-'+str(mi)+'-'+str(wi)+'-'+str(ki),m,w,k,len(rows)%4)
wr=json.loads(Path(next(p for p in pr['inputs']if p.endswith('/realized-source-witnesses.json'))).read_text())['columnWitnesses'];assert len(wr)==3
for k,r in enumerate(wr):add('realized-source-column-'+str(k),1,r['sourceStates64'],r['key'],k)
add('mode32-original-source-witness',1<<32,wr[0]['sourceStates64'],wr[0]['key'],3)
assert len(rows)==1108 and max(sum(q['group']==k for q in rows)for k in range(4))<=278
witness=rows[-1];assert witness['mode32DetectedAgainstActualDispatch']
(D/'case-manifest.json').write_text(json.dumps({'status':'ORACLE ONLY, no casesexecuted','cases':rows,'count':1108,'sourceSHA256':sha(src),'abiWordMeaning':'Six uint64bit patterns interpreted as signed i64 by originalfunction; full64zero equality and u64shift semantics. Fragmentalwaysinverse evenmode0; actualcompiledcaller mode0forward/nonzeroinverse.'},indent=2)+'\n')
(D/'actual-mode32-source-witness.json').write_text(json.dumps({'sourceCase':witness,'meaning':'Actual source fourforward andfourinverse tables at fixedrealized64state values; no opaqueforward/arbitrarylane substitution. No native execution.'},indent=2)+'\n')
faults=[{'mutation':name,'fixedCase':next(q['id']for q in rows if name in q['detectedAgainstInverse'])}for name in ['wrongWholeWordBDpacking','AESMCinsteadAESIMC','keyBeforeInverseMix']]+[{'mutation':'mode32compare','fixedCase':'mode32-original-source-witness'}]
(D/'planned-native-faults.json').write_text(json.dumps({'status':'Plannednotexecuted','faults':faults,'selection':'Firstdeterministic mismatch in fixedpre-registered inputorder; no dataset/count replacements ornative outcome selection','limits':'Apply only ownedcopiedcode/source. Detect via exact source value oracle; mutationmechanics separately preregister before build.'},indent=2)+'\n')
print('ORACLE1108 fixed cases, actualmode32source witness:',witness['actualInverseSourceResultUint64'],witness['actualForwardSourceResultUint64'])
