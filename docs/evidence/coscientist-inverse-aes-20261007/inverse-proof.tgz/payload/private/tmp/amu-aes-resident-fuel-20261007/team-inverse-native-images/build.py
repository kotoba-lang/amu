from pathlib import Path
import subprocess,os,re,json,hashlib,time,traceback
D=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
assert not (D/'attempts.json').exists(),'one campaign only'
for rel,pin in json.loads((D/'prepared-source-pins.json').read_text()).items():
 p=D/rel; assert sha(p)==pin['sha256'] and p.stat().st_size==pin['bytes'],rel
write(D/'build-source-pin.json',{'sha256':sha(Path(__file__)),'bytes':Path(__file__).stat().st_size,'processCap':118,'outerTimeoutSeconds':1800})
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
attempts=[];allrows={};tags={'AIARG','AIPRE','AIPOST','RFCORE','ASPRE','ASPOST','FN','FREC','SIR','FIX','EMIT','CACHE','LIT','TABLES'}
def run(seed,off,out,label,args):
 assert len(attempts)<118
 cmd=[str(D/'kexe-loader'),str(seed),str(off),'0','aarch64','35,37,38,39','--',*args]
 row={'index':len(attempts)+1,'label':str(out.relative_to(D))+'/'+label,'argv':cmd,'state':'started','startedEpoch':time.time()};attempts.append(row);write(D/'attempts.json',attempts)
 try:
  q=subprocess.run(cmd,env=env,capture_output=True,timeout=1800); stdout=q.stdout;stderr=q.stderr;rc=q.returncode
 except subprocess.TimeoutExpired as e:
  stdout=e.stdout or b'';stderr=e.stderr or b'';rc=None;row['timeout']=True
 (out/(label+'.stdout')).write_bytes(stdout);(out/(label+'.stderr')).write_bytes(stderr)
 row.update(state='terminal',returncode=rc,elapsedSeconds=time.time()-row['startedEpoch'],stdoutSha256=sha(out/(label+'.stdout')),stderrSha256=sha(out/(label+'.stderr')))
 write(out/(label+'.status.json'),row);write(D/'attempts.json',attempts)
 assert rc==0,(row['label'],rc,stderr[-1500:],stdout[-1500:])
 return stdout.decode('utf8',errors='replace')
def build(seed,off,src,symbol,out):
 out.mkdir(parents=True,exist_ok=True)
 log=run(seed,off,out,'compile',['compile',str(src),'--target','aarch64-macos','--output',str(out/'image.kseed')])
 text=run(seed,off,out,'extract',['extract-native',str(out/'image.kseed'),'--symbol',symbol,'--output',str(out/'native.bin')])
 ofs=int(re.search(r':offset (\d+)',text)[1]);(out/'native.offset').write_text(str(ofs)+'\n')
 records=[]
 for line in log.splitlines():
  parts=line.split()
  if parts and parts[0] in tags:
   records.append({'tag':parts[0],'fields':[int(x) for x in parts[1:]]})
 if records:write(out/'observer-records.json',records)
 return {'bytes':(out/'native.bin').stat().st_size,'nativeSha256':sha(out/'native.bin'),'offset':ofs,'sourceSha256':sha(src),'observerRecords':len(records)}
entries=json.loads((D/'comparison-matrix.json').read_text())['entries'];base={e['workload']:e for e in json.loads((D/'RF-baseline19.json').read_text())['entries']}
def ports(profile,seed,off,root):
 rows=[]
 for e in entries:
  name=e['workload'];row=build(seed,off,D/'sources'/f'{name}.kotoba',e['symbol'],root/name);row['workload']=name
  reference=base[name] if profile!='observer' else next(x for x in allrows['on'] if x['workload']==name)
  exact=all(row[k]==reference[k] for k in ('bytes','nativeSha256','offset'));row['referenceExact']=exact
  if profile=='default' or profile=='observer' or name!='nettle-aes':assert exact,(profile,name,row,reference)
  rows.append(row);write(D/(profile+'-images.json'),rows);print(profile,name,row['bytes'],row['offset'],'exact',exact,flush=True)
 allrows[profile]=rows
try:
 ports('on',D/'seed-on.bin',0,D/'on')
 p=D/'default';row=build(D/'seed-on.bin',0,D/'unity-default.kotoba','main',p);assert row['offset']==0
 (p/'seed.bin').write_bytes((p/'native.bin').read_bytes());(p/'seed.offset').write_text('0\n')
 ports('default',p/'seed.bin',0,p/'ports')
 p=D/'observer';row=build(D/'seed-on.bin',0,p/'unity.kotoba','main',p);assert row['offset']==0
 (p/'seed.bin').write_bytes((p/'native.bin').read_bytes());(p/'seed.offset').write_text('0\n')
 ports('observer',p/'seed.bin',0,p/'ports')
 assert len(attempts)==118
 write(D/'report.json',{'status':'PASS compile-extract-only finite identity gates','nativeCompilerProcesses':len(attempts),'failedProcesses':0,'benchmarkGuestExecutions':0,'AESInstructionExecutions':0,'timingObservations':0,'solverRuns':0,'on18RFexact':True,'default19RFexact':True,'observer19OnExact':True,'images':allrows,'limitations':['No inverse workload execution, hardware result, publication-prefix, ABI or performance qualification in this phase.','Observer is diagnostic compiler instrumentation and requires independent machine projection review.']})
except BaseException as e:
 write(D/'failure.json',{'exception':repr(e),'traceback':traceback.format_exc(),'attempts':len(attempts),'benchmarkGuestExecutions':0});raise
finally:
 write(D/'artifact-pins.json',{str(p.relative_to(D)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(D.rglob('*')) if p.is_file() and p.name not in ('artifact-pins.json','terminal-report.json')})
write(D/'terminal-report.json',{'status':'PASS compile-extract-only','reportSha256':sha(D/'report.json'),'pinsSha256':sha(D/'artifact-pins.json'),'pinCount':len(json.loads((D/'artifact-pins.json').read_text())),'allWritesComplete':True})
print('TERMINAL PASS',len(attempts),flush=True)
