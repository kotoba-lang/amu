from pathlib import Path
import shutil,json,difflib,hashlib,stat
H=Path('/private/tmp/amu-aes-resident-fuel-20261007');B=H/'inverse-implementation';D=H/'inverse-implementation-v2';I=H/'implementation'
for f in ['baseline-41-a64gen-prototype.kotoba','baseline-aes-native.kotoba','baseline-feature-recipe.json','baseline-source-pins.json','42-layout-baseline.kotoba','seed-0.bin','seed-0.offset','kexe-loader','source-budget-refinement-preregistration.json','authoring-pool-bounds-refinement.json','planned-regions.json']:
 shutil.copyfile(B/f,D/f)
shutil.copytree(B/'source-snapshot',D/'source-snapshot');(D/'provenance-v1').mkdir()
for f in ['preregistration.json','report.json','terminal-report.json','artifact-pins.json','recipe.json','static-source-review.json']:
 shutil.copyfile(B/f,D/'provenance-v1'/f)
oldmode=stat.S_IMODE((D/'kexe-loader').stat().st_mode);(D/'kexe-loader').chmod(0o755)
s=(B/'inverse-native.kotoba').read_text();needle='(and (= ai-feature 1) (= (vector-at M MM-ERR) 0)';replacement='(and (= ai-feature 1) (= (vector-at M MM-ERR) 0)\n      (>= (vector-at M MM-CODE-N) 0) (<= (vector-at M MM-CODE-N) MM-CODE-CAP)\n      (<= 96 (- MM-CODE-CAP (vector-at M MM-CODE-N)))';assert s.count(needle)==1;s=s.replace(needle,replacement)
a=s.index('       m3 (-> m2',s.index('(defn- ai-call'));s=s[:a]+'''       m3 (-> m2 (gn-emit 0x4f00e401) (gn-emit 0x1e270020) (gn-emit 0x4e0c1c80) (gn-emit 0x4e141c60) (gn-emit 0x4e1c1c40)
                 (gn-emit 0x4e285820) (gn-emit 0x4e287800) (gn-emit 0x0e043c10) (gn-emit 0xca050200)) after (vector-at m3 MM-CODE-N)]
  (if (not= (vector-at m3 MM-ERR) 0) m3
   (let [m4 (-> m3 (gn-put (+ MM-CODE-BASE dispatch) (enc-cbnz 0 (- inverse dispatch)))
                  (gn-put (+ MM-CODE-BASE jump) (enc-b (- after jump)))
                  (gn-vclear) (gn-gs gn-f-ctx 0) (gn-take i t 0)) words (- (vector-at m4 MM-CODE-N) start)]
    (cond (not= (vector-at m4 MM-ERR) 0) m4
          (> words 96) (gn-err m4 E-GEN-OP OP-CALL)
          :else (-> m4 (gn-gs as-used (+ (gn-g m4 as-used) words)) (gn-gs as-sites (inc (gn-g m4 as-sites)))))))))
'''
(D/'inverse-native.kotoba').write_text(s);(D/'inverse-native-on.kotoba').write_text(s.replace('(def ai-feature 0)','(def ai-feature 1)'))
base41=(I/'41-a64gen-prototype.kotoba').read_text();source=base41.replace('(defn- gn-op-call [M :vector-i64',s+'\n(defn- gn-op-call [M :vector-i64').replace('dag (di-admit M i f t n) aes (as-admit M i f t n)]','dag (di-admit M i f t n) inverse (ai-admit M i f t n) aes (as-admit M i f t n)]').replace('(cond aes (as-call M i f t)', '(cond inverse (ai-call M i f t) aes (as-call M i f t)');on=source.replace('(def ai-feature 0)','(def ai-feature 1)')
(D/'41-a64gen-inverse-default.kotoba').write_text(source);(D/'41-a64gen-inverse-on.kotoba').write_text(on);unity=(I/'unity.kotoba').read_text();assert unity.count(base41)==1;(D/'unity-inverse-default.kotoba').write_text(unity.replace(base41,source));(D/'unity-inverse-on.kotoba').write_text(unity.replace(base41,on))
(D/'source-v1-v2.diff').write_text(''.join(difflib.unified_diff((B/'41-a64gen-inverse-default.kotoba').read_text().splitlines(True),source.splitlines(True),fromfile='frozen-v1-default',tofile='v2-default')))
(D/'source.diff').write_text(''.join(difflib.unified_diff(base41.splitlines(True),source.splitlines(True),fromfile='resident-e94',tofile='inverse-v2-default')))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r={'status':'copiedloader chmod0755 bytes unchanged','oldCopiedMode':oct(oldmode),'v1FrozenModeUnchanged':oct(stat.S_IMODE((B/'kexe-loader').stat().st_mode)),'newMode':oct(stat.S_IMODE((D/'kexe-loader').stat().st_mode)),'v1SHA256':sha(B/'kexe-loader'),'v2SHA256':sha(D/'kexe-loader'),'modeOnlyChange':True,'retainedRootSetupFailure':'PermissionError before firstguest becausev1copy0644; rootownsactualfailurelog','nativeRuns':0}
(D/'loader-mode-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print('sourceonSHA256',sha(D/'41-a64gen-inverse-on.kotoba'));print('unityonSHA256',sha(D/'unity-inverse-on.kotoba'))
