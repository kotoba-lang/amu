# Prospective inverse AES emitter contract

This is a read-only design audit of source e94ab4df / seed a236b3e8. No inverse emitter, machine image or native test has been created. The old inverse-column and full-mode queries returned UNKNOWN, and remain blockers. Finite tables and one upper-state/key UNSAT do not restore either universal law. A later compositional checker must establish the actual equality chain, substitutions and coverage; query statuses or an English DAG are insufficient.

## Exact edit boundaries

The owner should make a new isolated source recipe. Current sources remain immutable.

* `implementation/aes-native.kotoba` and its insertion into `41-a64gen-prototype.kotoba:1542` contain the specialized matcher/emitter. Keep `as-feature` and the resident profile independent from a new explicit `ai-feature`, whose default is 0.
* `as-table-word` at 1556 is the algebraic table generator. Retain roles 0..3 exactly. New roles 4..7 mean inverse S-box followed by the coefficient word [14,9,13,11], rotated left by 8*(role-4), masked to 32 bits. Inverse affine is rotl8(x,1) XOR rotl8(x,3) XOR rotl8(x,6) XOR5, then GF inverse exponent254 over polynomial0x11b. Root's finite256 design receipt supports only this generator choice.
* `as-lit-ok` at 1561 presently rejects role>3. Broaden only in the explicitly inverse-enabled path. Length=8*(hi-lo), bounded literal ID/base/end, byte0..255 and every complete 64-bit literal word must be checked. No table-name or workload-name recognition.
* `as-tree` at 1574, `as-fn` at 1607 and `as-table` at 1611 provide bounded exact-body, checked-NF signature, split tree and unique-label checks. Reuse these only with strict inverse role and literal verification; do not let an arity check substitute for a certificate.
* `as-group` at 1624 currently checks the nonzero target only for one parameter. Its `other` at j+13 must be certified as an exact closed inverse table for the same role+4 before inverse lowering. The four targets are actual f21/f24/f27/f30, SIR109..126/127..144/145..162/163..180. These IDs are evidence, not admission criteria.
* `as-callee` at 1631 must connect all four certified groups to the original exact six-i64-argument/i64-result function, xor5 and xor4 helpers. `as-admit` at 1642 preserves argument safety, open refusal, stack/frame limits and module/site budgets.
* `as-call` at 1659 / `gn-op-call` at 1669 are the local call selection/emission sites. Prefer a distinct inverse admission ahead of existing forward admission: when inverse certificate fails, current forward behavior can remain exact and every nonzero mode retains original generic BL. If the owner instead makes full-call inverse certification mandatory, the deliberate loss of forward optimization for malformed inverse bodies must be preregistered and tested; semantics still use the original BL. Never silently change the fallback contract.

No changes to original callee/export bodies, FADDR/open paths, default generic lowering, allocator/context layouts, liveness bank allocation, or runtime permissions are implied.

## Required certificate

The original four inverse table functions are each i64->i64, nslots1, depth2, one entry FUEL, a bounded unique-label tree covering exactly [0,256), RET then END with no extra SIR. Their eight literal halves have 128 entries each; source/table bytes, literal IDs, fix MOVZ/MOVK locations and actual pool spans are independently bound in the finite-pool certificate. A matching literal word is a zero-extended32 value stored as an eight-byte i64. Reject missing halves, out-of-range literal bytes, wrong role/polynomial/S-box, signed/high-bit content differences, duplicated/dangling labels, holes/overlap in tree coverage, extra FUEL/CAP/calls/writes/traps, bad return or checked-NF cycles/types, open contexts and insufficient budgets.

The outer callee is exact arity6/nslots6/depth6, six TY-I64 parameters and TY-I64 return, closed context. Each byte extractor is the existing exact two-argument unsigned shift +255 mask with no fuel; each table consumes one original charge. xor5 consumes the last original charge; xor4 consumes none. Thus six original charges are justified from the *actual closed body*, not an abstract table count. Check module SIR<=65536, fn count<=1024, body search<=2048, tree depth<=8, label-cap validity, sites<64, reserve/site<=96 and aggregate added-word budget4096. A new larger budget would require a prospective amendment. Guard failure must select canonical old lowering before emitting/increasing counters; allocator/error M must not be overwritten by new state initialization.

## Proposed emitted regions and observations

Capture mode,a,b,c,d,key into x0..x5 by the existing `gn-save 0 t`, `gn-args t 0 6`, then `gn-ctx` into x7. All six argument homes are captured before x16/v0/v1 scratch clobbers. Original key loads at SIR923/985/1047/1109 stay before CALL924/986/1048/1110. No later key/state access may be moved before an earlier store, failed fuel point or allocation.

A full both-arms closed certificate permits one shared `rf-charges`: actual unsigned F>=6 guard, six separate SUBSx16/STRctx fuel publications, insufficient-fuel exact original six-charge slow block. Then a **64-bit CBNZ x0** selects forward versus inverse. CBNZ sets no NZCV, so the sixth SUBS flags remain; x0 survives the fuel group. Mode=0 uses the existing nine AESE/AESMC words unchanged. Every other full64 mode, including 2^32 and negative/high-bit values, uses inverse. No mode1-only or W-register test. A CMP alternative would require `CMP x0,#0` word f100001f and B.NE, plus a separate flags/order audit; it is unnecessary in the shared-core design and must not be treated as equivalent without that audit.

Inverse packs `[low32(a),low32(d),low32(c),low32(b)]` into v0. Zero v1, apply AESD with that zero operand, then AESIMC. Extract lane0 to w16 (zero extending x16) and XOR the **full64 x5 key after mixing** into x0. Preserve x7/x8/x19..28, SP/LR and existing frame. Only x16 and caller-volatile v0/v1 are scratch. Keep `gn-vclear`, `gn-gs gn-f-ctx 0`, and `gn-take i t 0` exactly in their original return finalization. Original exported functions and all indirect/open calls remain generic.

A shared46-word fuel region +64-bit mode branch +forward9 +join branch +inverse9, with the existing capture/finalization, is *estimated* 73 words versus current65. The actual observer must prove the exact count, every join/branch target, FX/FN/literal relocation and unchanged prefix/suffix. This estimate is not permission to weaken the existing96-word reservation.

### Encoding candidates — not calibrated instructions

Existing frozen forward words bind MOVIv1=4f00e401, FMOVs0,w1=1e270020, INSv0.s[1],w2=4e0c1c40, INSv0.s[2],w3=4e141c60, INSv0.s[3],w4=4e1c1c80, AESEv0,v1=4e284820, AESMCv0,v0=4e286800, UMOVw16,v0.s[0]=0e043c10 and EORx0,x16,x5=ca050200.

Proposed inverse body words are 4f00e401,1e270020,**4e0c1c80**,4e141c60,**4e1c1c40**,**4e285820 (AESD v0.16b,v1.16b)**,**4e287800 (AESIMC v0.16b,v0.16b)**,0e043c10,ca050200. AESD/AESIMC are proposed encoding literals derived from the A64 encoding family, not actual emitted or assembled observations in this audit. Future independent official encoding/assembler and fresh feature-admitted native calibration must confirm every word. The saved Arm semantic source has no immutable manual bytepin. Do not describe these candidates as hardware-qualified.

## Location-tied fault controls

* Current AS sites: guard words1639/1776/1913/2050, fuel cores1640..1685/1777..1822/1914..1959/2051..2096, forward bodies1686..1694/1823..1831/1960..1968/2097..2105, generic BL1696/1833/1970/2107. These current locations bind the observer; new relative regions must be recorded afresh.
* Inverse body relative words2 and4: swap w2/w4 back to forward packing. Old SMT actual counterexample is available, but must be realized through the actual table chain and native fixture, not assumed.
* Relative words5/6: replace AESD/AESIMC with AESE/AESMC or wrong destination/source fields; move key into AESD before mixing. Relative word8: EORw instead of EORx / wrong keyregister. Detect with actual full64 key and upper-state values.
* Dispatch: change 64-bit CBNZ to 32-bit form b5000000->35000000 or compare mode1. Mode2^32 counterexample must use realizable source states; arbitrary opaque lane models alone are abstract controls.
* Admission: change one actual inverse literal pool word at role0 pool25432/index0 (original1353184337), role1 pool27480, role2 pool29528 or role3 pool31576; wrong high32 bits, polynomial, inverse/forward S-box, rotation, split index, literal length or helper body/type/label. Assert refusal with original generic result, rather than accept a hidden changed table.
* Fuel/context: unsigned guard->signed, bulkSUB6, any missing originalSTR, corrupted slowBRK, x16 clobber, wrong ctxoffset, mode register overwritten, moved key read; actual F0..9/u64-edge/publication-prefix/full-state/trap observers must detect. Keep previous nonproductive initial-LDR-omission finding distinct from purposeful failures.
* Liveness/return: skip gn-save, misorder args/capture, clobber x7/x8/x19..28, drop gn-take/vclear/ctx invalidation or corrupt join. Use actual live-home sentinels and whole-M/runtime state, not just final arithmetic equality.

## Gates and default profiles

Before any new timing: independently checked all64 original lookup equality chain with actual term substitutions, finite256/1024 pool certificates, signed/high64 mode/key controls, emitted encoding calibration, closed/generic/open/FADDR refusal, actual6-charge publicprefix and fullsharedstate/resource/ABI controls, compiler reusable-M/error behavior, four-generation fixed point, all19 exact machine projection, defaultoff parity, and current formal/permanent gates. Preserve both old UNKNOWN solver receipts. Finite algebra/native source examples cannot replace a missing universal law.

New inverse-off (`ai-feature0`, retaining as-feature1/rf-feature1) must reproduce RF a236 all19 byte/offset exact. Existing RF-off profile (`rf-feature0`, as-feature1) remains exact AESv2; this is a different profile, not a fully software-only image. Other18 workloads remain byteexact to RF. Keep original software/generic product entry/ABI separate. Mask6 is an experimentally private, single-thread exclusive-fuel-writer host recipe with actual AES admission before RX; no generic raw caller, automatic feature admission or product promotion follows from it. Recipe/provenance hashes are separate from source DefCID.
