"""Standard-library offline typed certificate checker. No solver/native execution."""
from pathlib import Path
import json,hashlib,re,struct,copy
D=Path(__file__).parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pr=load(D/'preregistration.json');cp=load(D/'checker-preregistration.json')
for p,h in pr['inputs'].items():assert sha(Path(p))==h
for n,h in cp['coreImmutable'].items():assert sha(D/n)==h
src=Path(next(p for p in pr['inputs']if p.endswith('/source.kotoba')));text=src.read_text();raw=Path(next(p for p in pr['inputs']if p.endswith('/native.bin'))).read_bytes();words=[v[0]for v in struct.iter_unpack('<I',raw)];log=Path(next(p for p in pr['inputs']if p.endswith('/compile.log'))).read_text();sir={};fn={};fix=[]
for l in log.splitlines():
 x=l.split()
 if x[0]=='SIR':sir[int(x[1])]=list(map(int,x[2:]))
 if x[0]=='FN':fn[int(x[1])]=list(map(int,x[2:]))
 if x[0]=='FIX':fix.append(list(map(int,x[1:])))
read=lambda name:sum([list(map(int,re.search(r'\(def '+name+'-'+str(k)+r' \[([^]]+)\]',text)[1].split()))for k in range(2)],[])
S=read('dec-sbox');E=read('enc-sbox');T=[read('dec-t'+str(k))for k in range(4)];assert len(set(E))==256 and all(S[E[k]]==k for k in range(256))
def mul(a,b,poly=0x11b):
 v=0
 for _ in range(8):
  if b&1:v^=a
  a=((a<<1)^(poly if a&128 else 0))&255;b>>=1
 return v
def word(v,k):
 q=sum(mul(v,c)<<(8*i)for i,c in enumerate([14,9,13,11]));return q if k==0 else((q<<(8*k))|(q>>(32-8*k)))&0xffffffff
cert=load(D/'typed-index-pool-certificate.json');poolcert=load(D/'finite-pool-certificate.json');bf=cert['byteFunction']['id'];bp=fn[bf][0];expect=[[1,bf,2,2],[9,sir[bp+1][1],0,0],[4,0,1,0],[4,1,2,0],[6,9,0,0],[3,1,255,0],[6,5,0,0],[19,0,0,0],[2,bf,0,0]];assert cert['byteFunction']['canonicalSIR']==expect==[sir[bp+i]for i in range(9)]
assert '(defn- byte-at [x :i64 n :i64] :i64 (bit-and (u64-shift-right x n) 255))'in text
rootp=fn[61][0]
for k,entry in enumerate(cert['binding']):
 f=entry['fn'];p=fn[f][0];assert f==[21,24,27,30][k]and fn[f][2:4]==[1,2];lit0=sir[p+8][2];lit1=sir[p+14][2];lab,right,end=sir[p+2][1],sir[p+10][1],sir[p+15][1];assert len({lab,right,end})==3
 exp=[[1,f,1,1],[18,0,0,0],[9,lab,0,0],[4,0,1,0],[3,1,128,0],[7,2,0,0],[11,0,right,0],[4,0,1,0],[21,0,lit0,128],[10,end,0,0],[9,right,0,0],[4,0,1,0],[3,1,128,0],[6,2,0,0],[21,0,lit1,128],[9,end,0,0],[19,0,0,0],[2,f,0,0]];assert entry['canonicalSIR']==exp==[sir[p+i]for i in range(18)]
 assert re.search(r'\(defn- dec-t'+str(k)+r' \[i :i64\] :i64',text)
 j=rootp+4+15*k;t=k+1
 assert sir[j+10]==[4,t,k+2,0]and sir[j+11]==[3,t+1,8*k,0]and sir[j+12]==[13,bf,t,2]and sir[j+13]==[13,f,t,1]
 assert len(entry['cases'])==256
 for x,r in enumerate(entry['cases']):
  half,ix=(0,x)if x<128 else(1,x-128);lit=[lit0,lit1][half];pool=next(q for q in poolcert['literalPools']if q['literal']==lit);fx=next(q for q in fix if q[0]==pool['fixIndex']);assert fx[1:]==[pool['fixAt'],5,lit,0];at=fx[1];lo,hi=words[at-1:at+1];assert lo&0xff80001f==0xd2800010 and hi&0xff80001f==0xf2800010 and((lo>>21)&3)==0 and((hi>>21)&3)==1;off=((lo>>5)&65535)|(((hi>>5)&65535)<<16);assert off==pool['poolOffset'];v=struct.unpack('<Q',raw[off+ix*8:off+ix*8+8])[0];assert r=={'index':x,'half':half,'slot':ix,'nativeByteOffset':off+ix*8,'nativeValue':v,'inverseSubByte':S[x],'formulaValue':word(S[x],k)}and v==T[k][x]
# Actual XORhelper bodies bind XOR flattening/commutativity to source value (fuel/effects excluded from proof).
x5=sir[rootp+64][1];xp=fn[x5][0];x4=sir[xp+8][1];yp=fn[x4][0]
assert [sir[yp+i]for i in range(11)]==[[1,x4,4,4],[9,sir[yp+1][1],0,0],[4,0,1,0],[4,1,2,0],[6,7,0,0],[4,1,3,0],[4,2,4,0],[6,7,1,0],[6,7,0,0],[19,0,0,0],[2,x4,0,0]]
assert [sir[xp+i]for i in range(12)]==[[1,x5,5,5],[18,0,0,0],[9,sir[xp+2][1],0,0]]+[[4,k,k+1,0]for k in range(5)]+[[13,x4,1,4],[6,7,0,0],[19,0,0,0],[2,x5,0,0]]
# Typed expression AST with proof rules, not English assertions.
V=lambda n,w:['var',n,w];states=[V('state_'+n,64)for n in ['a','b','c','d']];K=V('key',64);M=V('mode',64);F=V('forward',64)
idx=[['extract',8*k+7,8*k,states[k]]for k in range(4)];sub=[['invsub',q]for q in idx];coeff=[14,9,13,11]
con=lambda q,k:['rol32',8*k,['gfword',0x11b,coeff,q]]
look=[['lookup',k,['zext64',idx[k]]]for k in range(4)];cont=[con(q,k)for k,q in enumerate(sub)];orig=['xor32']+look;expanded=['xor32']+cont;imc=['imc32',0x11b]+sub
pack=['pack128']+[['extract',31,0,states[k]]for k in [0,3,2,1]];select=[['invshift8',k,pack]for k in range(4)];hw=['imc32',0x11b]+[['invsub',q]for q in select]
wrap=lambda t:['xor64',['zext64',t],K];dispatch=lambda t:['if64',['eqzero64',M],F,t]
symbols=[V('S'+str(k),8)for k in range(4)];lemmaL=['xor32']+[con(q,k)for k,q in enumerate(symbols)];lemmaR=['imc32',0x11b]+symbols
lemmas={'lane':{'query':'independent-substituted-lane','lhs':lemmaL,'rhs':lemmaR},'packing':{'query':'full64-packing-and-key'},'dispatch':{'query':'full64-mode-lemma-dispatch'}}
for v in lemmas.values():
 n=v['query'];v['smtSHA256']=sha(D/(n+'.smt2'));v['rawSHA256']=sha(D/(n+'.stdout'));assert(D/(n+'.stdout')).read_text().splitlines()[0]=='unsat'
def width(t):
 op=t[0]
 if op=='var':assert t[2]in[8,64];return t[2]
 if op=='extract':assert 0<=t[2]<=t[1]<width(t[3]);return t[1]-t[2]+1
 if op=='zext64':assert width(t[1])in[8,32];return 64
 if op=='lookup':assert 0<=t[1]<4 and width(t[2])==64;return 32
 if op=='invsub':assert width(t[1])==8;return 8
 if op=='gfword':assert t[1]==0x11b and t[2]==coeff and width(t[3])==8;return 32
 if op=='rol32':assert t[1]in[0,8,16,24]and width(t[2])==32;return 32
 if op=='xor32':assert len(t)==5 and all(width(q)==32 for q in t[1:]);return 32
 if op=='imc32':assert t[1]==0x11b and len(t)==6 and all(width(q)==8 for q in t[2:]);return 32
 if op=='pack128':assert len(t)==5 and all(width(q)==32 for q in t[1:]);return 128
 if op=='invshift8':assert t[1]in range(4)and width(t[2])==128;return 8
 if op=='xor64':assert width(t[1])==width(t[2])==64;return 64
 if op=='eqzero64':assert width(t[1])==64;return 1
 if op=='if64':assert width(t[1])==1 and width(t[2])==width(t[3])==64;return 64
 raise AssertionError(op)
def normalize(t):
 if t[0]=='invshift8':
  k=t[1];p=t[2];assert p[0]=='pack128';q=p[1+((-k)%4)];assert q[0]=='extract'and q[1:3]==[31,0];return['extract',8*k+7,8*k,q[3]]
 return[normalize(q)if isinstance(q,list)else q for q in t]
def substitute(t,env):
 if t[0]=='var'and t[1]in env:return env[t[1]]
 return[substitute(q,env)if isinstance(q,list)else q for q in t]
dag={'lemmas':lemmas,'nodes':[{'id':'table'+str(k),'rule':'finite-table','role':k,'lhs':look[k],'rhs':cont[k]}for k in range(4)]+[{'id':'xor','rule':'xor-congruence','deps':['table'+str(k)for k in range(4)],'lhs':orig,'rhs':expanded},{'id':'mix','rule':'lemma-instance','lemma':'lane','substitution':{'S'+str(k):sub[k]for k in range(4)},'lhs':expanded,'rhs':imc},{'id':'pack','rule':'packing-congruence','lemma':'packing','lhs':imc,'rhs':hw},{'id':'chain','rule':'transitivity','deps':['xor','mix','pack'],'lhs':orig,'rhs':hw},{'id':'key','rule':'zext-key-congruence','deps':['chain'],'lhs':wrap(orig),'rhs':wrap(hw)},{'id':'dispatch','rule':'dispatch-congruence','lemma':'dispatch','deps':['key'],'lhs':dispatch(wrap(orig)),'rhs':dispatch(wrap(hw))}],'goal':{'lhs':dispatch(wrap(orig)),'rhs':dispatch(wrap(hw))},'certificateSHA256':sha(D/'typed-index-pool-certificate.json')}
(D/'derivation-dag.json').write_text(json.dumps(dag,indent=2)+'\n')
def check(dag):
 assert dag['lemmas']==lemmas and dag['certificateSHA256']==sha(D/'typed-index-pool-certificate.json')and len(dag['nodes'])<=64;proved={}
 for n in dag['nodes']:
  a,b=n['lhs'],n['rhs'];assert width(a)==width(b)and n['id']not in proved;r=n['rule']
  if r=='finite-table':
   k=n['role'];assert a==look[k]and b==cont[k]
  elif r=='xor-congruence':assert a==['xor32']+[proved[k][0]for k in n['deps']]and b==['xor32']+[proved[k][1]for k in n['deps']]
  elif r=='lemma-instance':
   assert n['lemma']=='lane'and set(n['substitution'])=={'S'+str(k)for k in range(4)}and all(width(q)==8 for q in n['substitution'].values());assert a==substitute(lemmaL,n['substitution'])and b==substitute(lemmaR,n['substitution'])
  elif r=='packing-congruence':assert n['lemma']=='packing'and normalize(a)==normalize(b)
  elif r=='transitivity':
   eqs=[proved[k]for k in n['deps']];assert all(x[1]==y[0]for x,y in zip(eqs,eqs[1:]))and a==eqs[0][0]and b==eqs[-1][1]
  elif r=='zext-key-congruence':
   x,y=proved[n['deps'][0]];assert a==wrap(x)and b==wrap(y)
  elif r=='dispatch-congruence':
   x,y=proved[n['deps'][0]];assert n['lemma']=='dispatch'and a==dispatch(x)and b==dispatch(y)
  else:raise AssertionError(r)
  proved[n['id']]=(a,b)
 assert proved['dispatch']==(dag['goal']['lhs'],dag['goal']['rhs'])==(dispatch(wrap(orig)),dispatch(wrap(hw)))
 return True
assert check(load(D/'derivation-dag.json'))
mutants=[]
x=copy.deepcopy(dag);x['nodes'][5]['substitution']['S1']=sub[3];mutants.append(('broken-substitution',x))
x=copy.deepcopy(dag);x['nodes'][7]['deps']=['xor','pack'];mutants.append(('broken-transitivity',x))
faults=[]
for name,x in mutants:
 try:check(x)
 except AssertionError:faults.append({'id':name,'rejected':True})
 else:raise AssertionError('accepted '+name)
# Realize independent-byte witnesses at ACTUALsource indices via inverseSbox preimages; model state defaults are not source witnesses.
r=load(D/'report.json');realized=[]
matrix=[[14,11,13,9],[9,14,11,13],[13,9,14,11],[11,13,9,14]]
def imc(vals,poly=0x11b):return sum(__import__('functools').reduce(lambda a,b:a^b,[mul(vals[k],matrix[row][k],poly)for k in range(4)])<<(8*row)for row in range(4))
for name in ['wrong-lane-control','wrong-poly-control','wrong-keyphase-control']:
 q=next(q for q in r['queries']if q['query']==name);ce=q['actualCounterexample'];vals=[ce['substituted'+str(k)]for k in range(4)];states64=[E[v]<<(8*k)for k,v in enumerate(vals)];key=ce['key'];old=__import__('functools').reduce(lambda a,b:a^b,[T[k][(states64[k]>>(8*k))&255]for k in range(4)])^key
 if name=='wrong-lane-control':bad=imc([vals[0],vals[3],vals[2],vals[1]])^key
 elif name=='wrong-poly-control':bad=imc(vals,0x11d)^key
 else:bad=imc([vals[k]^((key>>(8*k))&255)for k in range(4)])^(key&0xffffffff00000000)
 assert old==ce['actualReferenceValue']and bad==ce['actualMutatedValue']and old!=bad
 realized.append({'query':name,'scope':'Actualsource64state realization of abstractcolumn witness, not native execution','sourceStates64':states64,'substitutedBytes':vals,'sourceIndices':[E[v]for v in vals],'mode':1,'key':key,'originalSourceLiteralValue':old,'actualMutantValue':bad,'differentBytes':[k for k in range(8)if((old>>(8*k))&255)!=((bad>>(8*k))&255)]})
(D/'realized-source-witnesses.json').write_text(json.dumps({'columnWitnesses':realized,'mode32Classification':'Abstractdispatch lemma counterexample only: arbitraryprovedlane variable is not claimed to be the actualsource output at report defaultzero state values.','initialReportAndRawUnchanged':True},indent=2)+'\n')
report={'status':'PASS offline typedDAG original inverse law composition','finiteNativeSourceEntriesRechecked':1024,'canonicalTypedByteAndFourTableClosures':True,'actualXorHelpersBound':True,'DAGNodes':len(dag['nodes']),'DAGFaults':faults,'sourceColumnRealizations':3,'mode32AbstractOnly':True,'solverReruns':0,'native':0,'network':0,'timing':0,'derivationSHA256':sha(D/'derivation-dag.json'),'witnessSHA256':sha(D/'realized-source-witnesses.json'),'limits':['Trusted saved solverUNSAT for pinnedexactmodel lemmas; no independent solver rerun','Typedsource/canonicalactualSIR bound, but futureselector mustbind checkedNF/open/currentcallee identities','No native/encoding/fuel/trap/ABI/OS proof']};(D/'checker-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
