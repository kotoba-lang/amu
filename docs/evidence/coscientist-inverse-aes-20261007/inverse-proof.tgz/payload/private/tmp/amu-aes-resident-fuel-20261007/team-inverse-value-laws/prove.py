from pathlib import Path
import json,re,hashlib,struct,time
import z3 as z
D=Path(__file__).parent;pr=json.loads((D/'preregistration.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in pr['inputs'].items():assert sha(Path(p))==h
src=Path(next(p for p in pr['inputs']if p.endswith('/source.kotoba')));text=src.read_text();rawp=Path(next(p for p in pr['inputs']if p.endswith('/native.bin')));raw=rawp.read_bytes();words=[q[0]for q in struct.iter_unpack('<I',raw)];log=Path(next(p for p in pr['inputs']if p.endswith('/compile.log'))).read_text();sir={};fn={};fix={};emit={}
for l in log.splitlines():
 x=l.split()
 if x[0]=='SIR':sir[int(x[1])]=tuple(map(int,x[2:]))
 if x[0]=='FN':fn[int(x[1])]=tuple(map(int,x[2:]))
 if x[0]=='FIX':
  q=tuple(map(int,x[1:]));fix.setdefault(q[3],[]).append(q)
 if x[0]=='EMIT':emit[int(x[1])]=tuple(map(int,x[2:]))
read=lambda name:sum([list(map(int,re.search(r'\(def '+name+'-'+str(k)+r' \[([^]]+)\]',text)[1].split()))for k in range(2)],[])
T=[read('dec-t'+str(k))for k in range(4)];S=read('dec-sbox');E=read('enc-sbox');assert len(set(E))==256 and all(S[E[x]]==x for x in range(256))
cert=[]
for role,f in enumerate([21,24,27,30]):
 p=fn[f][0];end=next(j for j in range(p+1,max(sir)+1)if sir[j][0]==2);nodes=[(j,q)for j,q in sir.items()if p<j<end and q[0]==21];assert len(nodes)==2
 for part,(j,(op,t,lit,n))in enumerate(nodes):
  assert n==128;skip,lo,hi=emit[j];hits=[q for q in fix[lit]if q[2]==5 and lo<=q[1]<hi];assert len(hits)==1
  ix,at,k,target,aux=hits[0];w0,w1=words[at-1:at+1];assert w0&0xff80001f==0xd2800010 and w1&0xff80001f==0xf2800010 and (w0>>21)&3==0 and (w1>>21)&3==1
  offset=((w0>>5)&65535)|(((w1>>5)&65535)<<16);assert offset%8==0 and offset+8*n<=len(raw);pool=list(struct.unpack('<'+str(n)+'Q',raw[offset:offset+8*n]));assert pool==T[role][part*128:(part+1)*128]
  cert.append({'role':role,'fn':f,'sir':j,'literal':lit,'fixIndex':ix,'fixAt':at,'emitted':[lo,hi],'poolOffset':offset,'entries':n,'poolSHA256':hashlib.sha256(raw[offset:offset+8*n]).hexdigest(),'sourceHalfExact':True})
def mul(a,b,poly=0x11b):
 v=0
 for _ in range(8):
  if b&1:v^=a
  a=((a<<1)^(poly if a&128 else 0))&255;b>>=1
 return v
def sub(x):
 v=1;a=x;p=254
 for _ in range(8):
  if p&1:v=mul(v,a)
  a=mul(a,a);p>>=1
 q=v^99
 for k in range(1,5):q^=((v<<k)|(v>>(8-k)))&255
 return q&255
assert E==[sub(k)for k in range(256)]
for role in range(4):
 for x in range(256):
  s=S[x];w=sum(mul(s,c)<<(8*k)for k,c in enumerate([14,9,13,11]));out=w if role==0 else((w<<(8*role))|(w>>(32-8*role)))&0xffffffff;assert T[role][x]==out
(D/'finite-pool-certificate.json').write_text(json.dumps({'sourceSHA256':sha(src),'nativeSHA256':sha(rawp),'literalPools':cert,'inverseTableEntries':1024,'GFPolynomial':'0x11b','inverseSbox256Checked':True,'separateFromSMT':True},indent=2)+'\n')
def lookup(values,index,width):
 def tree(lo,hi,bit):
  if hi-lo==1:return z.BitVecVal(values[lo],width)
  mid=(lo+hi)//2;return z.If(z.Extract(bit,bit,index)==0,tree(lo,mid,bit-1),tree(mid,hi,bit-1))
 return tree(0,256,7)
def xorall(xs):
 a=xs[0]
 for b in xs[1:]:a=a^b
 return a
def gm(x,k,poly=0x1b):
 result=z.BitVecVal(0,8)
 for bit in range(4):
  if(k>>bit)&1:result=result^x
  x=(x<<1)^z.If(z.Extract(7,7,x)==1,z.BitVecVal(poly,8),z.BitVecVal(0,8))
 return result
a,b,c,d,key,mode,forward=z.BitVecs('state_a state_b state_c state_d key mode retained_forward_result',64);states=[a,b,c,d]
def pack(states,correct=True):
 v=[z.Extract(31,0,x)for x in states];v=[v[0],v[3],v[2],v[1]]if correct else v
 return z.Concat(*reversed(v))
def aesd_zero(v):
 # AESInvSubBytes(AESInvShiftRows(v)); column-major 16-byte state.
 inp=[z.Extract(8*k+7,8*k,v)for k in range(16)]
 out=[lookup(S,inp[4*((col-row)%4)+row],8)for col in range(4)for row in range(4)]
 return z.Concat(*reversed(out))
matrix=[[14,11,13,9],[9,14,11,13],[13,9,14,11],[11,13,9,14]]
def imc(v,poly=0x1b):
 inp=[z.Extract(8*k+7,8*k,v)for k in range(16)];out=[xorall([gm(inp[4*col+j],matrix[row][j],poly)for j in range(4)])for col in range(4)for row in range(4)]
 return z.Concat(*reversed(out))
def hardware(states,poly=0x1b,correct=True,keyphase=False):
 v=aesd_zero(pack(states,correct))
 if keyphase:v=v^z.ZeroExt(96,z.Extract(31,0,key))
 low=z.Extract(31,0,imc(v,poly))
 return z.ZeroExt(32,low)^(key&z.BitVecVal(0xffffffff00000000,64)if keyphase else key)
idx=[z.Extract(8*k+7,8*k,x)for k,x in enumerate(states)];old32=xorall([lookup(T[k],idx[k],32)for k in range(4)]);old=z.ZeroExt(32,old32)^key;hw=hardware(states);masked=hardware([x&z.BitVecVal(0xffffffff,64)for x in states]);spec=z.If(mode==0,forward,old);candidate=z.If(mode==0,forward,hw)
queries=[('inverse-column-all-i64',[old!=hw],'unsat',old,hw),('upper-state-and-full-key',[z.Or(hw!=masked,z.Extract(63,32,hw)!=z.Extract(63,32,key))],'unsat',hw,masked),('full-mode-dispatch',[spec!=candidate],'unsat',spec,candidate),('wrong-b-d-packing',[old!=hardware(states,correct=False)],'sat',old,hardware(states,correct=False)),('key-before-inverseMix',[old!=hardware(states,keyphase=True)],'sat',old,hardware(states,keyphase=True)),('wrong-polynomial',[old!=hardware(states,poly=0x1d)],'sat',old,hardware(states,poly=0x1d)),('mode32compare',[spec!=z.If(z.Extract(31,0,mode)==0,forward,hw)],'sat',spec,z.If(z.Extract(31,0,mode)==0,forward,hw))];assert len(queries)==7
rows=[];version=z.get_version_string();(D/'solver-version.json').write_text(json.dumps({'z3':version,'module':z.__file__,'timeoutMs':60000,'oneAttemptPerQuery':True},indent=2)+'\n')
for name,assertions,want,reference,altered in queries:
 sol=z.Solver();sol.set(timeout=60000);sol.add(*assertions);(D/(name+'.smt2')).write_text(sol.to_smt2());print('START',name,flush=True);begin=time.monotonic();got=str(sol.check());row={'query':name,'expected':want,'actual':got,'elapsedSeconds':time.monotonic()-begin,'attempts':1};rawlog=got+'\n'
 if got=='sat':
  model=sol.model();rawlog+=model.sexpr()+'\n';ev=lambda q:model.eval(q,model_completion=True).as_long();witness={str(x):ev(x)for x in states+[key,mode,forward]};witness['referenceValue']=ev(reference);witness['actualMutatedValue']=ev(altered);witness['xorDifference']=witness['referenceValue']^witness['actualMutatedValue'];witness['referenceBytesLittleEndian']=list(witness['referenceValue'].to_bytes(8,'little'));witness['actualMutatedBytesLittleEndian']=list(witness['actualMutatedValue'].to_bytes(8,'little'));witness['differentByteIndices']=[k for k in range(8)if witness['referenceBytesLittleEndian'][k]!=witness['actualMutatedBytesLittleEndian'][k]];assert witness['xorDifference']!=0;row['actualCounterexample']=witness
 elif got=='unknown':row['reason']=sol.reason_unknown();rawlog+=row['reason']+'\n'
 (D/(name+'.stdout')).write_text(rawlog);rows.append(row);(D/'partial-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
report={'status':'PASS bounded explicit inverse AES value laws'if all(x['actual']==x['expected']for x in rows)else'FAIL/UNKNOWN retained bounded inverse AES value laws','preregistrationSHA256':sha(D/'preregistration.json'),'sourceSHA256':sha(src),'finiteLiteralPoolCertificateSHA256':sha(D/'finite-pool-certificate.json'),'solverVersion':version,'queries':rows,'model':'128-bit littleendianwordpacking[a,d,c,b], AESInvShiftRows then independently-derivedInverseSbox, inverseMixGF0x11b; lane0 zeroextend32 XOR full64key AFTERmix. Source4×256literaltable entries bound toactualmachineMOVZ/MOVKfixpoolbytes and originalsource. Full64mode0 opaqueunchangedforward; arbitrarynonzero inverse.','officialSemanticInput':str(D.parent/'team-next-AES-inverse-research/official-ISA-source.json'),'limits':['Explicit universal bitvector formula laws, not wholecompiler/hardware proof','Finitepool/sourcecertificate separate fromsymbolic laws','No instructionencoding/native/selector/call/fuel/trap/arena/ABI/OS proof','Baselineadoption and newemitter remain pending; no performance orofficialscores'],'newNative':0,'compilerEdits':0,'timing':0,'network':0}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
for p,h in pr['inputs'].items():assert sha(Path(p))==h
print(report['status'],flush=True)
