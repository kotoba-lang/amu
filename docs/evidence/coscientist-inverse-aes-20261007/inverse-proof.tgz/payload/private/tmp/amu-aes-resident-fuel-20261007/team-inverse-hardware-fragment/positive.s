.text
.p2align 2
.globl _inv_probe
_inv_probe:
 .long 0x4f00e401
 .long 0x1e270020
 .long 0x4e0c1c80
 .long 0x4e141c60
 .long 0x4e1c1c40
 .long 0x4e285820
 .long 0x4e287800
 .long 0x0e043c10
 .long 0xca050200
 .long 0xd65f03c0
