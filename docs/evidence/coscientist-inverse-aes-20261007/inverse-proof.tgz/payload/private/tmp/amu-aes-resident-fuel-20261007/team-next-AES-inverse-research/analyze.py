from pathlib import Path
import json,re,hashlib,struct
D=Path(__file__).parent;W=D.parent;src=W/'team-timing/timing-package/nettle-aes/source.kotoba';text=src.read_text();pins={str(src):hashlib.sha256(src.read_bytes()).hexdigest()}
def mul(a,b,poly=0x11b):
 v=0
 for _ in range(8):
  if b&1:v^=a
  a=((a<<1)^(poly if a&128 else 0))&255;b>>=1
 return v
def sb(x):
 v=1;a=x;p=254
 for _ in range(8):
  if p&1:v=mul(v,a)
  a=mul(a,a);p>>=1
  # loops are bounded by8
 y=v^99
 for k in range(1,5):y^=((v<<k)|(v>>(8-k)))&255
 return y&255
enc=[sb(k)for k in range(256)];inverse=[0]*256
for k,v in enumerate(enc):inverse[v]=k
read=lambda prefix:sum([list(map(int,re.search(r'\(def '+prefix+'-'+str(j)+r' \[([^]]+)\]',text)[1].split()))for j in range(2)],[])
assert enc==read('enc-sbox')and inverse==read('dec-sbox');tabs=[read('dec-t'+str(k))for k in range(4)];assert all(len(t)==256 for t in tabs)
def word(x,k):
 s=inverse[x];a=mul(s,14)|(mul(s,9)<<8)|(mul(s,13)<<16)|(mul(s,11)<<24);return a if k==0 else((a<<(8*k))|(a>>(32-8*k)))&0xffffffff
for k in range(4):assert tabs[k]==[word(x,k)for x in range(256)]
# Finite fault witnesses only; not SMT or execution of Arm instructions.
faults=[]
def badword(x,k,sbox,poly):
 v=sbox[x];a=sum(mul(v,c,poly)<<(8*i)for i,c in enumerate([14,9,13,11]));return a if k==0 else((a<<(8*k))|(a>>(32-8*k)))&0xffffffff
for name,fn in [('forwardSbox',lambda x,k:badword(x,k,enc,0x11b)),('wrongpoly',lambda x,k:badword(x,k,inverse,0x11d)),('wrongrole',lambda x,k:word(x,(k+1)%4))]:
 k,x=next((k,x)for k in range(4)for x in range(256)if tabs[k][x]!=fn(x,k));faults.append({'id':name,'role':k,'index':x,'original':tabs[k][x],'altered':fn(x,k)})
base=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation/observer/ports/nettle-aes');ae=Path('/private/tmp/amu-hardware-aes-20261006/implementation-v2/observer/ports/nettle-aes');rf=W/'implementation/observer/ports/nettle-aes'
def parsed(p):
 for n in ['compile.log','native.bin','extract.log']:pins[str(p/n)]=hashlib.sha256((p/n).read_bytes()).hexdigest()
 sir={};fn={};fix=[]
 for l in(p/'compile.log').read_text().splitlines():
  x=l.split()
  if x[0]=='SIR':sir[int(x[1])]=tuple(map(int,x[2:]))
  if x[0]=='FN':fn[int(x[1])]=tuple(map(int,x[2:]))
  if x[0]=='FIX':fix.append(tuple(map(int,x[1:])))
 return sir,fn,fix
s,f,fx=parsed(rf);bs,bf,bfx=parsed(base);as_,af,afx=parsed(ae);assert s==bs==as_;assert {k:v[:-1]for k,v in f.items()}=={k:v[:-1]for k,v in bf.items()}=={k:v[:-1]for k,v in af.items()}
p=f[61][0];inverseFns=[];groups=[]
for role in range(4):
 j=p+4+15*role;forward=s[j+7][1];inv=s[j+13][1];inverseFns.append(inv);fv=f[inv];a=fv[0];end=next(i for i in range(a+1,max(s)+1)if s[i][0]==2)
 assert s[a]==(1,inv,1,1)and s[a+1]==(18,0,0,0);ops=[q for i,q in s.items()if a<i<end];assert all(q[0]in [3,4,6,7,9,10,11,18,19,21]for q in ops)
 groups.append({'role':role,'forwardFn':forward,'inverseFn':inv,'inverseSIR':[a,end],'FNMetadata':fv,'oneOriginalFUEL':sum(q[0]==18 for q in ops),'bodyOpcodes':sorted(set(q[0]for q in ops))})
assert len(set(inverseFns))==4
xor=s[p+64][1];xp=f[xor][0];xe=next(i for i in range(xp+1,max(s)+1)if s[i][0]==2);xfuels=sum(q[0]==18 for i,q in s.items()if xp<i<xe);assert xfuels==1
sites=[924,986,1048,1110];generic=[x for x in fx if x[2:]==(4,61,0)];assert len(generic)==4
words=[q[0]for q in struct.iter_unpack('<I',(rf/'native.bin').read_bytes())];aese=sum(z==0x4e284820 for z in words);aesmc=sum(z==0x4e286800 for z in words)
for p in [Path('/private/tmp/amu-hardware-aes-20261006/implementation-v2/aes-native.kotoba'),W/'implementation/aes-native.kotoba',Path('/private/tmp/amu-hardware-aes-20261006/team-value-laws/report.json'),Path('/Users/junkawasaki/github/wt/amu-seed17/seed/00-ns.kotoba'),W/'team-next-AES-state-research/census.json']:
 pins[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
r={'finiteInverseTableEntriesChecked':1024,'inverseSboxEntriesChecked':256,'tableCoefficients':[14,9,13,11],'GFPolynomial':'0x11b','roleRotation':'rol32(word,8*role)','groups':groups,'xor5Fn':xor,'xor5EntryFUEL':xfuels,'tableRoundEntryFUEL':1,'sixOriginalCharges':1+4+xfuels,'genericFallbackFixes':generic,'currentStaticAESE':aese,'currentStaticAESMC':aesmc,'currentInverseHardwareEmission':0,'perBodySourceCountsConditional':{'encryptBlocks':16,'decryptBlocks':16,'middleRoundsPerBlock':13,'wordProjectionsPerRound':4,'mode0MiddleProjections':16*13*4,'nonzeroMiddleProjections':16*13*4,'mode0AESEGroupsCurrentIfComplete':16*13*4,'mode0AESEGroupsSharedHypothesisIfComplete':16*13,'groupsRemovedSharedHypothesis':16*13*3,'inverseSoftwareProjectionsPotentiallyLowered':16*13*4},'finiteFaultWitnesses':faults,'interpretation':'Counts derive successful source controlflow body, not measured dynamic profile or time shares. Early trap/failed allocation/fuel exhaustion stops sourcepath and invalidates total count assumptions.'}
(D/'census.json').write_text(json.dumps(r,indent=2)+'\n');(D/'input-pins.json').write_text(json.dumps(pins,indent=2)+'\n');print('PASS bounded1024 inverse tables+256 inverseSbox;4 actual inverse closures;6 originalcharges;4 retainedgenericBL')
