from pathlib import Path
import subprocess,json,hashlib
D=Path(__file__).parent;W=D.parent;r=json.loads((D/'preregistration.json').read_text());cases=json.loads((W/'team-inverse-native-calibration-plan/case-manifest.json').read_text())['cases'];receipts=[];reports={}
for pin in json.loads((D/'pre-execution-pins.json').read_text()):assert hashlib.sha256((D/pin['path']).read_bytes()).hexdigest()==pin['sha256']
for name in ['positive',*r['mutations']]:
 actual={}
 for group in range(4):
  cmd=[str(D/name),str(D/f'group-{group}.bin'),name]
  try:p=subprocess.run(cmd,capture_output=True,timeout=30)
  except subprocess.TimeoutExpired as e:
   (D/f'{name}-{group}.stdout').write_bytes(e.stdout or b'');(D/f'{name}-{group}.stderr').write_bytes(e.stderr or b'');raise
  (D/f'{name}-{group}.stdout').write_bytes(p.stdout);(D/f'{name}-{group}.stderr').write_bytes(p.stderr)
  rec={'variant':name,'group':group,'exit':p.returncode,'command':cmd};receipts.append(rec);(D/'execution-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
  assert p.returncode==0,(name,group,p.returncode)
  lines=p.stdout.decode().splitlines();assert len(lines)==277
  for line in lines:
   i,v=map(int,line.split());assert i not in actual and cases[i]['group']==group;actual[i]=v
 assert len(actual)==1108
 rows=[{'index':i,'id':c['id'],'argsUint64':c['argsUint64'],'expected':c['inverseFragmentExpectedUint64'],'actual':actual[i],'same':actual[i]==c['inverseFragmentExpectedUint64']} for i,c in enumerate(cases)]
 (D/f'{name}-actual.json').write_text(json.dumps(rows,indent=2)+'\n')
 diff=[x for x in rows if not x['same']]
 if name=='positive':assert not diff
 else:
  witness=r['mutations'][name]['witness'];x=next(x for x in rows if x['id']==witness);assert not x['same'];assert diff
  reports[name]={'cases':1108,'changed':len(diff),'nonproductive':1108-len(diff),'registeredWitness':x}
reports['positive']={'cases':1108,'same':1108}
(D/'native-results.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps(reports,indent=2))
