; benchmark generated from python API
(set-info :status unknown)
(declare-fun key () (_ BitVec 64))
(declare-fun proved_inverse_lane32 () (_ BitVec 32))
(declare-fun retained_forward_result () (_ BitVec 64))
(declare-fun mode () (_ BitVec 64))
(assert
 (let ((?x533 (bvxor ((_ zero_extend 32) proved_inverse_lane32) key)))
(let (($x780 (= ((_ extract 31 0) mode) (_ bv0 32))))
(let ((?x781 (ite $x780 retained_forward_result ?x533)))
(let (($x535 (= mode (_ bv0 64))))
(let ((?x536 (ite $x535 retained_forward_result ?x533)))
(and (distinct ?x536 ?x781) true)))))))
(check-sat)
