from pathlib import Path
import sys,json,hashlib,re
sys.path.insert(0,'/private/tmp/amu-rewrite-proof-deps');import z3 as z
D=Path(__file__).parent;Q=D/'copied-certificate';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
# Independently build the stated 8-bit linear GF algebra, packing and mode predicates.
def bxor(xs):
 out=xs[0]
 for x in xs[1:]:out=out^x
 return out
def gf(x,coefficient):
 result=z.BitVecVal(0,8)
 for bit in range(4):
  if coefficient&(1<<bit):result=result^x
  x=(x<<1)^z.If(z.Extract(7,7,x)==1,z.BitVecVal(0x1b,8),z.BitVecVal(0,8))
 return result
def contribution(x,role):return z.RotateLeft(z.Concat(gf(x,11),gf(x,13),gf(x,9),gf(x,14)),8*role)
mat=[[14,11,13,9],[9,14,11,13],[13,9,14,11],[11,13,9,14]]
def mix(xs):return z.Concat(*reversed([bxor([gf(xs[k],mat[row][k])for k in range(4)])for row in range(4)]))
x=z.BitVecs('substituted0 substituted1 substituted2 substituted3',8);states=z.BitVecs('state_a state_b state_c state_d',64);key,mode,forward=z.BitVecs('key mode retained_forward_result',64);lane=z.BitVec('proved_inverse_lane32',32)
packing=z.Concat(z.Extract(31,0,states[1]),z.Extract(31,0,states[2]),z.Extract(31,0,states[3]),z.Extract(31,0,states[0]))
I=z.Function('InvSBox',z.BitVecSort(8),z.BitVecSort(8));direct=[I(z.Extract(8*k+7,8*k,states[k]))for k in range(4)];selected=[I(z.Extract(8*(4*((-k)%4)+k)+7,8*(4*((-k)%4)+k),packing))for k in range(4)]
col=bxor([contribution(v,k)for k,v in enumerate(direct)]);hw=mix(selected);full=z.ZeroExt(32,hw)^key;masked=z.ZeroExt(32,mix([I(z.Extract(8*k+7,8*k,states[k]&z.BitVecVal(0xffffffff,64)))for k in range(4)]))^key
inv=z.ZeroExt(32,lane)^key
expected={'independent-substituted-lane':bxor([contribution(v,k)for k,v in enumerate(x)])!=mix(x),'full64-packing-and-key':z.Or(col!=hw,full!=masked,z.Extract(63,32,full)!=z.Extract(63,32,key)),'full64-mode-lemma-dispatch':z.If(mode==0,forward,inv)!=z.If(mode!=0,inv,forward)}
rows=[]
for name,formula in expected.items():
 actual=z.parse_smt2_file(str(Q/(name+'.smt2')));assert len(actual)==1
 # Only deterministic AST normalization, not a solver query or satisfaction check.
 left=z.simplify(actual[0]);right=z.simplify(formula);assert z.eq(left,right),(name,left.sexpr()[:100],right.sexpr()[:100])
 assert (Q/(name+'.stdout')).read_text().splitlines()[0]=='unsat'
 rows.append({'query':name,'storedFormulaSha256':sha(Q/(name+'.smt2')),'savedRawSha256':sha(Q/(name+'.stdout')),'independentExpectedParsedASTExactAfterDeterministicNormalization':True,'normalizedASTSha256':hashlib.sha256(left.sexpr().encode()).hexdigest()})
# Recheck finite pool values equal formula, rather than merely matching separate fields.
cert=load(Q/'typed-index-pool-certificate.json');pp=load(Q/'preregistration.json');src=Path(next(p for p in pp['inputs']if p.endswith('/source.kotoba'))).read_text()
read=lambda name:sum([list(map(int,re.search(r'\(def '+name+'-'+str(k)+r' \[([^]]+)\]',src)[1].split()))for k in range(2)],[])
S=read('dec-sbox');E=read('enc-sbox');T=[read('dec-t'+str(k))for k in range(4)];assert len(S)==len(E)==256 and len(set(E))==256 and all(S[E[i]]==i for i in range(256))
def mul(a,b):
 out=0
 for _ in range(8):
  if b&1:out^=a
  a=((a<<1)^(0x11b if a&128 else 0))&255;b>>=1
 return out
def w(v,k):
 a=sum(mul(v,c)<<(8*j)for j,c in enumerate([14,9,13,11]));return a if k==0 else((a<<(8*k))|(a>>(32-8*k)))&0xffffffff
for role,b in enumerate(cert['binding']):
 for index,c in enumerate(b['cases']):assert c['index']==index and c['nativeValue']==c['formulaValue']==T[role][index]==w(S[index],role) and 0<=c['nativeValue']<=0xffffffff
# Verify AST proof bindings correspond to the newly checked exact coefficient/packing formulas.
dag=load(Q/'derivation-dag.json');assert dag['lemmas']['lane']['lhs']==['xor32']+[['rol32',8*k,['gfword',0x11b,[14,9,13,11],['var','S'+str(k),8]]]for k in range(4)] and dag['lemmas']['lane']['rhs']==['imc32',0x11b]+[['var','S'+str(k),8]for k in range(4)]
for n in dag['nodes']:
 if n['rule']=='packing-congruence':
  terms=n['rhs'][2:];assert [t[1][1]for t in terms]==[0,1,2,3]
  for t in terms:assert [q[3][1]for q in t[1][2][1:]]==['state_a','state_d','state_c','state_b']
print(json.dumps({'status':'PASS exactstored3SMTAST + finite1024 formula equality + typedDAG coefficient/packing binding','rows':rows,'z3VersionUsedForASTParsingOnly':z.get_version_string(),'finiteTableCases':1024,'solverQueries':0,'solverCheckCalls':0,'native':0,'network':0,'timing':0},indent=2))
