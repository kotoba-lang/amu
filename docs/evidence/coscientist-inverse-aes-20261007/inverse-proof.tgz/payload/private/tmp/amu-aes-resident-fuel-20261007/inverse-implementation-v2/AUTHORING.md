# Inverse AES authoring v2 — no builds

Frozen v1 and its50 original pins remain intact. The missing inverse-only CODE-capacity guard was a concrete pre-build blocker. Root's first v1 build attempt failed at loaderPermissionError (copied0644) before any guest; this source owner performed no native calls.

V2 changes only the new ai path: admission checks0<=CODE-N<=CODE-CAP before subtracting and reserves96 whole words. With the already registered t<=1 source bound93+2t<=95, normally admitted emission cannot hit CODE-CAP. Admission failure retains the unchanged old forward/generic fallback. The ai-call checks MM-ERR before its dispatch/join patches, and after finalization before its two existing shared counter writes. FailedM and first error are returned intact at these guards.

Scope: the inherited rf helper/capture/code emitter can continue writing within the owned CODE region after an unexpected encoder error; this repair does not claim all inherited emission is silent after any error. It prevents new ai dispatch/join patches and shared counters after such an error. The capacity proof is conditional on the earlier static bound and canonical generator descriptor/frame invariants; actual observer and boundary/mutant tests remain pending. No new M/G fields, allocator changes, budgets, oldas/rf changes or native words were introduced. Loader0755 is a mode-only repair with identical bytes.

Default/on sources and full unity profiles are pinned separately. This authoring owner stopped before compile/build/native/solver/network/timing and did not edit the repository or product. Independent source review and root prospective native-build registration are required next.
