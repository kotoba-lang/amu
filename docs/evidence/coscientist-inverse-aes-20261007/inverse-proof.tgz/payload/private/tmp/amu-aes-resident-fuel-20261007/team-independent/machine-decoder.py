from pathlib import Path
import struct
def branch(z):
 def sg(n,b):return n-(1<<b) if n&(1<<(b-1)) else n
 if z&0x7c000000==0x14000000:return z&0xfc000000,sg(z&0x3ffffff,26)
 if z&0xff000010==0x54000000:return z&0xff00001f,sg((z>>5)&0x7ffff,19)
 if z&0x7e000000==0x34000000:return z&0xff00001f,sg((z>>5)&0x7ffff,19)
 if z&0x7e000000==0x36000000:return z&0xfff8001f,sg((z>>5)&0x3fff,14)
 if z&0x9f000000==0x10000000:return z&0x9f00001f,sg(((z>>5)&0x7ffff)*4+((z>>29)&3),21)/4
 return None
def parse(p):
 d={'sir':{},'fn':{},'events':[],'fix':[],'raw':(p/'native.bin').read_bytes()}
 for l in (p/'compile.log').read_text().splitlines():
  x=l.split()
  if not x:continue
  if x[0]=='SIR':d['sir'][int(x[1])]=tuple(map(int,x[2:]))
  if x[0]=='FN':d['fn'][int(x[1])]=tuple(map(int,x[2:]))
  if x[0]=='EMIT':d['events'].append(tuple(map(int,x[1:])))
  if x[0]=='FIX':d['fix'].append(tuple(map(int,x[1:])))
 d['n']=max(e[3] for e in d['events']);d['words']=[x[0] for x in struct.iter_unpack('<I',d['raw'][:4*(d['n']-1)])];return d
