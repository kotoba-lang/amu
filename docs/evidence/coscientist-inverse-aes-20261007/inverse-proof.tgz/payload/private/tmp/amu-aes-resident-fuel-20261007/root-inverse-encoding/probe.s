.text
.globl _inverse_encoding_probe
_inverse_encoding_probe:
 movi v1.16b, #0
 fmov s0, w1
 ins v0.s[1], w4
 ins v0.s[2], w3
 ins v0.s[3], w2
 aesd v0.16b, v1.16b
 aesimc v0.16b, v0.16b
 umov w16, v0.s[0]
 eor x0, x16, x5
 ret
