from pathlib import Path
import re,json,hashlib,time
import z3 as z
D=Path(__file__).resolve().parent;I=D.parent/'implementation';src=Path('/Users/junkawasaki/github/wt/amu-seed17/bench/embench/batch-ports/nettle-aes.kotoba');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=src.read_text();tables=[sum((list(map(int,re.search(r'\(def enc-t'+str(k)+'-'+str(j)+r' \[([^]]+)\]',s)[1].split())) for j in range(2)),[]) for k in range(4)];assert all(len(t)==256 for t in tables)
def mul(a,b,poly=0x11b):
 v=0
 for _ in range(8):
  if b&1:v^=a
  a=((a<<1)^ (poly if a&128 else 0))&255;b>>=1
 return v
def sub(x):
 v=1;a=x;p=254
 for _ in range(8):
  if p&1:v=mul(v,a)
  a=mul(a,a);p>>=1
 y=v^99
 for k in range(1,5):y^=((v<<k)|(v>>(8-k)))&255
 return y&255
sb=[sub(i) for i in range(256)];assert sb==sum((list(map(int,re.search(r'\(def enc-sbox-'+str(j)+r' \[([^]]+)\]',s)[1].split()))for j in range(2)),[])
def lookup(values,index):
 assert len(values)==256
 def node(lo,hi,bit):
  if hi-lo==1:return z.BitVecVal(values[lo],32 if max(values)>255 else 8)
  mid=(lo+hi)//2
  return z.If(z.Extract(bit,bit,index)==0,node(lo,mid,bit-1),node(mid,hi,bit-1))
 return node(0,256,7)
T=tables;S=sb
def xt(x,poly=0x1b):return (x<<1)^z.If(z.Extract(7,7,x)==1,z.BitVecVal(poly,8),z.BitVecVal(0,8))
def word_for(x,role,poly=0x1b):
 # little-endian mix column first contribution 2*s,s,s,3*s; each successive row rotates by8
 q=z.Concat(xt(x,poly)^x,x,x,xt(x,poly))
 return z.RotateLeft(q,8*role)
a,b,c,d,key,mode=z.BitVecs('state_a state_b state_c state_d key mode',64);state=[a,b,c,d];idx=[z.Extract(8*k+7,8*k,x) for k,x in enumerate(state)]
def xorall(xs):
 v=xs[0]
 for x in xs[1:]:v=v^x
 return v
old32=xorall([lookup(T[k],idx[k]) for k in range(4)]);old=z.ZeroExt(32,old32)^key
# ARM AESE(state,zero): byte substitution and ShiftRows selects a.byte0,b.byte1,c.byte2,d.byte3
# AESMC: output first-column littleendian bytes use Rijndael field0x11b and row coefficients.
hw32=xorall([word_for(lookup(S,idx[k]),k) for k in range(4)]);hw=z.ZeroExt(32,hw32)^key
index=z.BitVec('single_table_index',8)
queries=[]
for k in range(4):queries.append(('table-role-'+str(k),[lookup(T[k],index)!=word_for(lookup(S,index),k)],'unsat'))
queries += [('whole-four-table-all-i64-key',[old!=hw],'unsat'),('upper-state-bits-irrelevant',[hw != (z.ZeroExt(32,xorall([word_for(lookup(S,z.Extract(8*k+7,8*k,x & z.BitVecVal(0xffffffff,64))),k) for k,x in enumerate(state)]))^key)],'unsat'),('full-key-upper-retained',[z.Extract(63,32,hw)!=z.Extract(63,32,key)],'unsat')]
generic=z.BitVec('retained_generic_nonzero_mode_result',64)
queries.append(('dynamic-mode-zero-only',[z.If(mode==0,old,generic)!=z.If(mode==0,hw,generic)],'unsat'))
wronglane=z.ZeroExt(32,xorall([word_for(lookup(S,z.Extract(7,0,b) if k==1 else idx[k]),k)for k in range(4)]))^key
wrongpoly=z.ZeroExt(32,xorall([word_for(lookup(S,idx[k]),k,0x1d)for k in range(4)]))^key
keyfirst=z.ZeroExt(32,xorall([word_for(lookup(S,idx[k]^(z.Extract(8*k+7,8*k,key) if k==0 else z.BitVecVal(0,8))),k)for k in range(4)]))
queries += [('wrong-lane-control',[old!=wronglane],'sat'),('wrong-mix-polynomial-control',[old!=wrongpoly],'sat'),('wrong-key-before-AESE-control',[old!=keyfirst],'sat'),('truncated-full-key-control',[old!=(z.ZeroExt(32,hw32)^z.ZeroExt(32,z.Extract(31,0,key)))],'sat'),('unsafe-nonzero-mode-control',[mode!=0,z.If(mode==0,old,generic)!=hw],'sat')]
rows=[]
for name,assertions,want in queries:
 solver=z.Solver();solver.set(timeout=30000);solver.add(*assertions);(D/(name+'.smt2')).write_text(solver.to_smt2());print('START',name,flush=True);start=time.monotonic();got=str(solver.check());row={'query':name,'expected':want,'actual':got,'solverElapsedSeconds':time.monotonic()-start}
 raw=got+'\n'
 if got=='sat':
  model=solver.model();raw+=model.sexpr()+'\n';row['counterexample']={str(x):model.eval(x,model_completion=True).as_long() for x in [a,b,c,d,key,mode,generic,index]}
 elif got=='unknown':raw+=solver.reason_unknown()+'\n'
 (D/(name+'.stdout')).write_text(raw);rows.append(row);print(json.dumps(row),flush=True);assert got==want,row
report={'status':'PASS explicit AES value-model SMT laws, not general compiler proof','source':str(src),'sourceSha256':sha(src),'candidateSourceSha256':sha(I/'41-a64gen-prototype.kotoba'),'candidateNativeSha256':sha(I/'seed-4.bin'),'tableEntries':1024,'sboxEntries':256,'solver':z.get_version_string(),'officialSpecification':'https://documentation-service.arm.com/static/6023d61995978b529036da45','officialPages':[603,605],'model':'Littleendian4x32 packing; AESE withzero key: GF0x11b AES Sbox+ShiftRows; AESMC firstcolumn contribution coefficients2,1,1,3 rotatingby8*row. Four complete immutable source lookup tables. Full64bit inputs arbitrary, only byte0/1/2/3 observed; XOR full64bit key AFTER mix; dynamicmode!=0 uses unchanged opaquegeneric result.','queries':rows,'boundary':'UNSAT proves these explicitly modeled value formulas at arbitrary bitvector inputs; independently derived finite Sbox standard verified full256. Formal ARM operational model/encoding simulation, fuel/trap/arena/ABI/CFG/matcher/capability soundness are separate. Native132ISA controls bind selected finite execution values/opcodes, not exhaustive instruction hardwareproof. Existing primary2756pins remain unchanged. No timings/nativeexecution here.'}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'])
pins={str(p.relative_to(D)):sha(p) for p in sorted(D.iterdir()) if p.is_file() and p.name not in ['artifact-pins.json','terminal-report.json']};(D/'artifact-pins.json').write_text(json.dumps(pins,indent=2)+'\n');(D/'terminal-report.json').write_text(json.dumps({'status':report['status'],'reportSha256':sha(D/'report.json'),'artifactPins':len(pins),'artifactPinsSha256':sha(D/'artifact-pins.json'),'primaryUnchanged':True},indent=2)+'\n')
