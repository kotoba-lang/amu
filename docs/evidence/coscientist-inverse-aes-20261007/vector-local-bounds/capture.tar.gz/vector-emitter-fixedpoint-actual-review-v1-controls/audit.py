from pathlib import Path
import json, hashlib, re
D=Path(__file__).resolve().parent;W=D.parent;N=W/'vector-emitter-fixedpoint-native-v1-root';P=W/'vector-emitter-fixedpoint-plan-v1-width';B=W/'vector-emitter-local-bounds-native-build-v1-root'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def need(x,msg):
 if not x:raise AssertionError(msg)
def save(n,x):(D/n).write_text(json.dumps(x,indent=2)+'\n')
try:
 terminal=json.loads((N/'terminal.json').read_text());need(terminal=={'allCallsClosed':True,'loaderCalls':6,'generations':3,'failure':False},'terminal exactly six calls closed without failure')
 auth=json.loads((N/'authorization.json').read_text());need(auth['fixedpointAuthorized'] is True and auth['maximumLoaderCalls']==6,'root six-call authority')
 for key,file in [('preregistrationSHA256','preregistration.json'),('inputPinsSHA256','input-pins.json'),('driverSHA256','run-fixedpoint.py')]:need(auth[key]==sha(P/file),('authorization pin',key))
 pins=json.loads((P/'input-pins.json').read_text())
 for path,entry in pins.items():
  p=Path(path);need(sha(p)==entry['sha256'] and p.stat().st_size==entry['bytes'],('input pin',path))
 src='d9cfe46b781ff57235d2e0284682d1a745bd166e0fc3a698399d5e3f9a3475eb';seed='c75d41f758231844be1c1ca49124068eeed85e72a073803d73ba5ae00783289c'
 need(sha(N/'unity.kotoba')==sha(B/'unity.kotoba')==src,'current source and exact original source')
 need((N/'unity.kotoba').read_bytes()==(B/'unity.kotoba').read_bytes(),'full source equality')
 need(sha(N/'seed-0.bin')==sha(B/'candidate.bin')==seed,'seed0 exact candidate')
 need(sha(B/'kexe-loader')=='8fc787ca556773b6991b44f51e0d4fdec52cf93ef37673cb289eb726c98dff64','frozen loader')
 env={'KEXE_COMMAND':'1','KEXE_CAP_RESOURCES_35':str(N),'KEXE_CPU_SECONDS':'1800','KEXE_WALL_SECONDS':'1800','KEXE_STRING_POOL':'268435456','KEXE_VECTORS':'4194304','KEXE_PAIRS':'16777216','KEXE_VECTOR_ITEMS':'134217728'}
 e=json.loads((N/'environment.json').read_text());need(e['kexeEnvironment']==env and e['wire35CombinedReadWriteScope']==str(N),'sanitized environment fixed resource scope')
 material=json.loads((N/'source-materialization.json').read_text());need(material['origin']==str(B/'unity.kotoba') and material['copy']==str(N/'unity.kotoba') and material['sha256']==src and material['bytes']==1130881,'source materialization provenance')
 need(material['sourceReadOnlyEnforced'] is False,'no nonexistent readonly guarantee')
 attempts=json.loads((N/'attempts.json').read_text());need(len(attempts)==6,'exact cap')
 generations=[];rpaths=[p for p in N.iterdir() if p.is_file()]
 for generation in (1,2,3):
  prefix=[str(B/'kexe-loader'),str(N/f'seed-{generation-1}.bin'),'0','0','aarch64','35,37,38,39','--']
  cmds={'compile':prefix+['compile',str(N/'unity.kotoba'),'--target','aarch64-macos','--output',str(N/f'seed-{generation}.kseed')],
        'extract':prefix+['extract-native',str(N/f'seed-{generation}.kseed'),'--symbol','main','--output',str(N/f'seed-{generation}.bin')]}
  for stage in ('compile','extract'):
   index=(generation-1)*2+(1 if stage=='compile' else 2);row=attempts[index-1]
   need(row['index']==index and row['generation']==generation and row['stage']==stage,'order')
   need(row['argv']==cmds[stage],'exact chained argv')
   need(row['kexeEnvironment']==env and row['removedInheritedKexeKeys']==e['removedInheritedKexeKeys'],'exact sanitized env per invocation')
   need(row['producerSHA256']==sha(N/f'seed-{generation-1}.bin')==seed and row['sourceSHA256']==src,'per-call producer/source chain')
   need(row['state']=='terminal' and row['returncode']==0 and row['timeoutSeconds']==1810,'successful bounded terminal')
   out=N/f'seed-{generation}-{stage}.stdout';err=N/f'seed-{generation}-{stage}.stderr'
   need(sha(out)==row['stdoutSHA256'] and sha(err)==row['stderrSHA256'] and err.read_bytes()==b'','raw stdout/stderr hashes')
   if stage=='compile':
    expected='{:ok true, :target :aarch64-macos, :output "'+str(N/f'seed-{generation}.kseed')+'", :bytes 936714}\n'
   else:expected='{:ok true, :output "'+str(N/f'seed-{generation}.bin')+'", :offset 0, :length 936688, :arity 0}\n'
   need(out.read_text()==expected,'exact own output receipt')
  raw=(N/f'seed-{generation}.kseed').read_bytes();header,payload=raw.split(b'\n\n',1)
  need(header==b'KSEED1 936688 1\nmain 0 0' and len(payload)==936688,'whole header main0 arity0')
  need((N/f'seed-{generation}.offset').read_bytes()==b'0\n','own offset0')
  native=(N/f'seed-{generation}.bin').read_bytes()
  need(payload==native==(N/'seed-0.bin').read_bytes(),'each whole payload native initial candidate byte equality')
  need(raw==(B/'candidate.kseed').read_bytes(),'whole KSEED initial candidate equality')
  generations.append({'generation':generation,'producerSHA256':sha(N/f'seed-{generation-1}.bin'),'nativeSHA256':sha(N/f'seed-{generation}.bin'),'kseedSHA256':sha(N/f'seed-{generation}.kseed'),'offset':0,'arity':0,'bytes':len(native),'wholeSourceNativeKseedEquality':True})
 need(not(N/'failure.json').exists(),'no hidden failure file')
 save('report.json',{'status':'PASS_INDEPENDENT_RAW_THREE_GENERATION_FIXEDPOINT','loaderCallsByRoot':6,'nativeCallsByReviewer':0,'generations':generations,'sourceSHA256':src,'loaderSHA256':sha(B/'kexe-loader'),'exactSixArgv':True,'sanitizedEnvironmentReceipts':True,'allRawLogsAndHeadersChecked':True,'noRerunsInLedger':True,'limits':['Evidence is the fixed compiler compile/extract chain; no new benchmark functional calls.','Before/after source hashes are producer receipts plus current exact source; OS readonly enforcement was not enabled.','This does not qualify performance, product adoption or broader optimization coverage.']})
 save('artifact-pins.json',{'raw':{str(p):sha(p) for p in rpaths},'plan':{str(p):sha(p) for p in [P/'preregistration.json',P/'input-pins.json',P/'run-fixedpoint.py']},'auditSHA256':sha(D/'audit.py'),'reportSHA256':sha(D/'report.json')})
 print('PASS independent raw three-generation fixedpoint; six root calls; reviewer native 0')
except BaseException as exc:
 save('offline-audit-failure.json',{'exception':repr(exc),'nativeCalls':0});raise
