from pathlib import Path
import json,hashlib,re
W=Path(__file__).resolve().parent;D=W.parent/'vector-emitter-original19-native-v1-root';P=W.parent/'vector-emitter-original19-plan-v2-width';C=W.parent/'vector-emitter-local-bounds-native-build-v1-root'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());pins={}
def bind(p):pins[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size};return p.read_bytes()
def jl(p):bind(p);return load(p)
def container(p):
 h,b=bind(p).split(b'\n\n',1);lines=h.decode().splitlines();v,n,ec=lines[0].split();assert v=='KSEED1' and int(n)==len(b) and int(ec)==len(lines)-1
 e=[]
 for line in lines[1:]:
  name,offset,arity=line.split();offset=int(offset);arity=int(arity);assert 0<=offset<len(b) and offset%4==0 and arity>=0;e.append({'name':name,'offset':offset,'arity':arity})
 assert len({x['name']for x in e})==len(e);return b,e
pr=jl(P/'preregistration.json');ip=jl(P/'input-pins.json');go=jl(D/'authorization.json');assert go['preregistrationSHA256']==sha(P/'preregistration.json') and go['inputPinsSHA256']==sha(P/'input-pins.json') and go['driverSHA256']==sha(P/'run-original19.py');bind(P/'run-original19.py')
assert go['original19CompilationAuthorized'] is True and go['maximumCalls']==38 and go['machinePositiveQualificationAccepted'] is True and go['sourceResourceReviewsAccepted'] is True and go['qualifiedMachineSites']==1
mp=Path(go['machineQualificationReport']);assert sha(mp)==go['machineQualificationSHA256'];bind(mp)
for name,r in ip.items():
 p=Path(name);assert sha(p)==r['sha256'] and p.stat().st_size==r['bytes'];bind(p)
t=jl(D/'terminal.json');assert t=={'allWritesComplete':True,'attempts':38,'images':19,'failure':False} and not(D/'failure.json').exists()
a=jl(D/'attempts.json');images=jl(D/'images.json');mat=jl(D/'source-materialization.json');ev=jl(D/'environment.json');assert len(a)==38 and len(images)==len(mat)==len(pr['entries'])==19
expectedEnv={'KEXE_COMMAND':'1','KEXE_CAP_RESOURCES_35':str(D),'KEXE_CPU_SECONDS':'1800','KEXE_WALL_SECONDS':'1800','KEXE_STRING_POOL':'268435456','KEXE_VECTORS':'4194304','KEXE_PAIRS':'16777216','KEXE_VECTOR_ITEMS':'134217728'}
assert ev['kexeEnvironment']==expectedEnv and ev['resource35CombinedReadWriteBoundary']==str(D) and ev['externalSourcesGranted'] is False and ev['copyReadOnlyEnforced'] is False
assert all(k.startswith('KEXE_')for k in ev['removedInheritedKexeKeys'])
rows=[]
for ix,(e,im,m)in enumerate(zip(pr['entries'],images,mat)):
 name=e['workload'];d=D/'ports'/name;src=D/'sources'/(name+'.kotoba');orig=Path(e['source']);b=Path(e['baselineDirectory']);assert name==im['workload']==m['workload'] and m['origin']==str(orig) and m['copy']==str(src) and bind(src)==orig.read_bytes() and sha(src)==m['sha256']==ip[str(orig)]['sha256'] and src.stat().st_size==m['bytes']
 for si,stage in enumerate(['compile','extract']):
  r=a[ix*2+si];suffix=['compile',str(src),'--target','aarch64-macos','--output',str(d/'image.kseed')]if si==0 else['extract-native',str(d/'image.kseed'),'--symbol',e['symbol'],'--output',str(d/'native.bin')]
  cmd=[str(C/'kexe-loader'),str(C/'candidate.bin'),'0','0','aarch64','35,37,38,39','--',*suffix]
  assert r['index']==ix*2+si+1 and r['workload']==name and r['stage']==stage and r['argv']==cmd and r['state']=='terminal' and r['returncode']==0 and r['kexeEnvironment']==expectedEnv and r['removedInheritedKexeKeys']==ev['removedInheritedKexeKeys'] and r['sourceSHA256']==sha(src) and r['timeoutSeconds']==1810
  out=bind(d/(stage+'.stdout'));assert bind(d/(stage+'.stderr'))==b'' and b':ok true' in out
 code,exports=container(d/'image.kseed');old,oe=container(b/'image.kseed');assert code==bind(d/'native.bin')==old==bind(b/'native.bin') and bind(d/'image.kseed')==b.joinpath('image.kseed').read_bytes() and exports==oe
 off=int(bind(d/'native.offset'));bo=int(bind(b/'native.offset'));assert off==bo and [x for x in exports if x['name']==e['symbol']]==[{'name':e['symbol'],'offset':off,'arity':next(x['arity']for x in exports if x['name']==e['symbol'])}]
 ex=re.findall(rb':offset (\d+)\b',(d/'extract.stdout').read_bytes());assert len(ex)==1 and int(ex[0])==off
 expected={'workload':name,'sourceSHA256':sha(src),'nativeSHA256':sha(d/'native.bin'),'containerSHA256':sha(d/'image.kseed'),'bytes':len(code),'offset':off,'exports':exports,'baselineNativeSHA256':sha(b/'native.bin'),'baselineContainerSHA256':sha(b/'image.kseed'),'baselineExports':oe,'baselineBytes':len(old),'wholeNativeEqual':True,'wholeContainerEqual':True,'coverage':'NOT_INFERRED_FROM_BYTE_DIFF','functional':'NOT_RUN','performance':'NOT_RUN'};assert im==expected;rows.append(expected)
report=jl(D/'report.json');assert report['calls']==38 and report['images']==19
r={'status':'PASS_INDEPENDENT_ORIGINAL19_COMPILATION_REGRESSION_ONLY','nativeReruns':0,'compilerExtractionCalls':38,'originalModules':19,'all19WholeNativeAndKSEEDByteEqualV8':True,'allExportTablesAndOffsetsExactV8':True,'sourceCopiesExactPinnedOriginal19':True,'sanitizedKexeEnvironmentAndExactArgvVerified':True,'changedNativeModules':0,'changedContainerModules':0,'rows':rows,'performance':'NO_IMPROVEMENT_EVIDENCE; identical native cannot substantiate runtime gain','machineOmissionCoverage':'not inferred from containers; root census0 is separate prospective eligibility evidence','functionalBenchmarkCalls':0,'selfhostFixedPoint':'NOT_TESTED_BY_THIS38','limits':['38 compilation/extraction receipts, no benchmark execution or C comparison','wire35 combines read/write inside freshworkspace; source integrity checked, no read-only guarantee','no performance/timing/ComputeCID/ResultCID/adoption claim'],'pins':pins}
(W/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(sha(W/'report.json'))
