from pathlib import Path
import struct, json, hashlib, re

def require(x, why):
    if not x: raise AssertionError(why)

def container(path, native, offset):
    raw=Path(path).read_bytes(); head,payload=raw.split(b'\n\n',1)
    lines=head.decode('ascii').splitlines(); m=re.fullmatch(r'KSEED1 (\d+) (\d+)',lines[0]); require(m,'header')
    exports=[]
    for line in lines[1:]:
        z=re.fullmatch(r'(\S+) (\d+) (\d+)',line); require(z,'export syntax')
        exports.append((z[1],int(z[2]),int(z[3])))
    require(len(payload)==int(m[1]) and len(exports)==int(m[2]),'container lengths')
    require(exports==[('bench',offset,1)],'exact sole bench export')
    require(payload==Path(native).read_bytes(),'whole native payload')
    require(len(payload)%4==0 and offset%4==0 and 0<=offset<len(payload),'native alignment')
    return list(struct.unpack('<'+'I'*(len(payload)//4),payload))

def ldr(rt,rn,off):return 0xf9400000+(off//8<<10)+(rn<<5)+rt

def readseq(rv,ri,d):
    return [ldr(16,7,312),ldr(16,16,0),0xd1000000+(1<<10)+(rv<<5)+17,
            0xeb00001f+(16<<16)+(17<<5),0x54000043,0,
            ldr(16,7,320),0x8b000000+(17<<16)+(4<<10)+(16<<5)+16,
            0xa9400000+(16<<10)+(16<<5)+17,
            0xeb00001f+(16<<16)+(ri<<5),0x54000043,0,
            ldr(16,7,328),0x8b000000+(ri<<16)+(17<<5)+17,
            0xf8607800+(17<<16)+(16<<5)+d]

def signed(x,bits):return x-(1<<bits) if x&(1<<(bits-1)) else x

def relocation(w,pc,cut):
    start,end=cut
    def move(i):
        require(not start<=i<end,'branch enters deleted bounds trio')
        return i-3 if i>=end else i
    if w&0x7c000000==0x14000000:bits,shift=26,0
    elif w&0xff000010==0x54000000:bits,shift=19,5
    elif w&0x7e000000==0x34000000:bits,shift=19,5
    elif w&0x7e000000==0x36000000:bits,shift=14,5
    else:
        require(w&0x9f000000 not in (0x10000000,0x90000000),'unsupported ADR/ADRP')
        require(w&0x3b000000!=0x18000000,'unsupported literal LDR')
        return w,None
    mask=((1<<bits)-1)<<shift; target=pc+signed((w&mask)>>shift,bits)
    delta=move(target)-move(pc)
    require(-(1<<(bits-1))<=delta<(1<<(bits-1)),'relocation range')
    return (w&~mask)|((delta&((1<<bits)-1))<<shift),target

def compare_words(old,new,old_offset,new_offset):
    matches=[]
    for j in range(len(old)-14):
        if old[j]!=ldr(16,7,312):continue
        rv=(old[j+2]>>5)&31;ri=(old[j+9]>>5)&31;d=old[j+14]&31
        if old[j:j+15]==readseq(rv,ri,d):matches.append((j,rv,ri,d))
    require(len(matches)==1,('unique genuine read pattern',matches))
    j,rv,ri,d=matches[0];cut=(j+9,j+12)
    require(len(old)-len(new)==3,'actual 12-byte omission required by initial gate')
    expected=[];relocated=[]
    for pc,w in enumerate(old):
        if cut[0]<=pc<cut[1]:continue
        nw,target=relocation(w,pc,cut)
        if target is not None:
            require(0<=target<len(old),'branch target outside native payload')
        if nw!=w:relocated.append({'oldPC':pc*4,'oldWord':hex(w),'newWord':hex(nw),'target':target*4})
        expected.append(nw)
    require(expected==new,'all words exact after sole deletion and registered branch relocation')
    require(not cut[0]*4<=old_offset<cut[1]*4,'export points into removed trio')
    require(new_offset==old_offset-(12 if old_offset>=cut[1]*4 else 0),'exact export relocation')
    preserved=old[j:j+9]+old[j+12:j+15]
    require(new[j:j+12]==preserved,'retained handle descriptor pool address load sequence')
    return {'status':'PASS_EXACT_SINGLE_BOUNDS_TRIO_OMISSION','referenceBytes':len(old)*4,'candidateBytes':len(new)*4,
            'removedBytes':12,'readByteOffset':j*4,'removedByteOffset':cut[0]*4,
            'removedWords':[hex(x) for x in old[cut[0]:cut[1]]],'registers':{'vector':rv,'index':ri,'destination':d},
            'retainedWords':[hex(x) for x in preserved],'branchRelocations':relocated,'allOtherWordsExact':True}

def compare_folder(d):
    d=Path(d); offsets=[int((d/(v+'.offset')).read_text()) for v in ('reference','candidate')]
    words=[container(d/(v+'.kseed'),d/(v+'.bin'),o) for v,o in zip(('reference','candidate'),offsets)]
    result=compare_words(*words,*offsets)
    result['exports']={'reference':offsets[0],'candidate':offsets[1],'symbol':'bench','arity':1}
    return result

if __name__=='__main__':
    import sys
    print(json.dumps(compare_folder(sys.argv[1]),indent=2))
