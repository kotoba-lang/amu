from pathlib import Path
import json,hashlib,collections
D=Path(__file__).resolve().parent;W=D.parent;N=W/'vector-typed-observer-native-v8'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=json.loads((D/'preregistration.json').read_text())
for path,h in p['inputs'].items():assert sha(Path(path))==h,path
WIDTHS={'VWENTRY':1,'VWSTATUS':6,'VWSITE':8,'VWFN':17,'SIR':5,'FREC':17,'CACHE':5,'EMIT':4,'TABLES':6,'FIX':5,'LIT':5}
rows=[]
for image in json.loads((N/'images.json').read_text()):
 name=image['workload'];folder=N/'ports'/name
 raw=json.loads((folder/'observer-records.json').read_text()); parsed=[]
 for line in (folder/'compile.stdout').read_text().splitlines():
  words=line.split()
  if words and words[0] in WIDTHS:
   assert len(words)==1+WIDTHS[words[0]],line
   parsed.append({'tag':words[0],'fields':list(map(int,words[1:]))})
 assert parsed==raw,'raw stdout/filtered records exact'
 def index(tag):
  a=[x['fields'] for x in raw if x['tag']==tag];z={x[0]:x for x in a};assert len(a)==len(z);return z
 sir=index('SIR');ff=index('FREC');vf=index('VWFN');sites=index('VWSITE');cache=index('CACHE');emit=index('EMIT')
 table=[x['fields'] for x in raw if x['tag']=='TABLES'];assert len(table)==1
 sn,fnn,*_=table[0];assert set(sir)==set(range(1,sn));assert set(ff)==set(range(1,fnn))
 starts={};ends={};owner={};active=None
 for i,v in sir.items():
  if v[1]==1:active=v[2];starts[active]=i
  if active is not None:owner[i]=active
  if v[1]==2:assert v[2]==active;ends[active]=i;active=None
 assert active is None
 entry=[x['fields'][0] for x in raw if x['tag']=='VWENTRY'];status=[x['fields'] for x in raw if x['tag']=='VWSTATUS'];assert len(entry)==1
 refusal=status[0][0] if status else entry[0];assert len(status)==(1 if entry[0]==0 else 0)
 joins=[];allreads=[];allocs=[]
 for i,v in sir.items():
  if v[1:3]==[14,200]:
   f=owner[i];prev=sir.get(i-1);constant=bool(prev and prev[1]==3 and prev[2]==v[3] and prev[4]==0 and prev[3]>0)
   allocs.append({'sir':i,'fn':f,'private':ff[f][3]==2 and ff[f][12]==0,'arity':v[4],'previousCONST':prev,'immediatePositiveConstant':constant})
  if v[1:3]==[14,176]:
   allreads.append({'sir':i,'fn':owner[i],'temp':v[3],'arity':v[4],'certificate':sites.get(i),'CACHE':cache.get(i),'EMIT':emit.get(i)})
 for i,cert in sites.items():
  site,f,token,L,K,base,cmpkeep,hkeep=cert;assert site==i
  start=starts[f];end=ends[f];origin=-token;reasons=[]
  family='parameter' if token>0 else 'returned-allocation' if token<=-65536 else 'direct-allocation'
  creation=-token-65536 if family=='returned-allocation' else -token if family=='direct-allocation' else None
  def check(condition,reason):
   if not condition:reasons.append(reason)
  check(refusal==0,'global-refusal');check(1<fnn<=128 and 1<sn<=65536,'whole-module-limits')
  check(0<f<fnn and f<128,'fn-range');check(token<0 and token>-sn,'not-direct-local-allocation-token')
  check(ff[f][3]==2 and ff[f][12]==0,'not-private-unexported-function')
  check(ff[f][13]==start and sir[start][1:3]==[1,f] and sir[end][1:3]==[2,f],'body-record-mismatch')
  check(origin>start+1 and origin<i<end,'allocation-not-earlier-same-body')
  check(L>0 and 0<=K<L and 0<=base<=5,'length-index-base')
  check(sir[i][1:]==[14,176,base,2],'read-wire-arity-base')
  a=sir.get(origin);prev=sir.get(origin-1)
  check(bool(a and a[1:3]==[14,200] and a[4]==1 and 0<=a[3]<128),'origin-not-RT200-arity1')
  check(bool(a and prev and prev[1]==3 and prev[2]==a[3] and prev[4]==0 and prev[3]>=L),'origin-missing-immediate-CONST-length')
  q=vf[f][1:];check(q[2]==1 and q[3]==1 and q[14]==0 and q[15]==1,'function-summary-not-supported-complete')
  check(cmpkeep==hkeep==1,'certificate-original-check-flags')
  emitter_reasons=[]
  if i not in cache or cache[i][1]!=0:emitter_reasons.append('actual-before-mode-not-zero')
  if i not in emit:emitter_reasons.append('no-owned-emission')
  elif emit[i][1]!=0 or emit[i][3]<=emit[i][2]:emitter_reasons.append('fused-or-empty-owned-emission')
  joins.append({'sir':i,'fn':f,'FN':ff[f],'VWFN':vf[f],'start':start,'end':end,'originToken':token,'originFamily':family,'creationOrCallSIR':sir.get(creation),'originSIR':a,'previousSIR':prev,'length':L,'index':K,'tempBase':base,'readSIR':sir[i],'CACHE':cache.get(i),'EMIT':emit.get(i),'sourceSealEligible':not reasons,'sourceRefusals':reasons,'observedOrdinaryEmitterCandidate':not reasons and not emitter_reasons,'emitterRefusals':emitter_reasons,'currentIndexKindAndValue':'UNOBSERVED; consumer gn-k-const plus exact gn-dv=K still required','actualRewriteQualified':False})
 rows.append({'workload':name,'entry':entry[0],'refusal':refusal,'allRT176Reads':allreads,'allRT200Allocations':allocs,'certificateJoins':joins,'semanticCertificates':len(joins),'sourceSealable':sum(x['sourceSealEligible'] for x in joins),'ordinaryEmitterCandidates':sum(x['observedOrdinaryEmitterCandidate'] for x in joins)})
assert len(rows)==19
reasons=collections.Counter(z for r in rows for x in r['certificateJoins'] for z in x['sourceRefusals'])
r={'status':'PASS_OFFLINE_ACTUAL19_ELIGIBILITY_CENSUS_NOT_REWRITE_QUALIFICATION','rows':rows,'totals':{'workloads':len(rows),'reads':sum(len(r['allRT176Reads']) for r in rows),'allocations':sum(len(r['allRT200Allocations']) for r in rows),'semanticCertificates':sum(r['semanticCertificates'] for r in rows),'sourceSealable':sum(r['sourceSealable'] for r in rows),'ordinaryEmitterCandidates':sum(r['ordinaryEmitterCandidates'] for r in rows),'sourceRefusalReasons':dict(reasons),'originFamilies':dict(collections.Counter(x['originFamily'] for r in rows for x in r['certificateJoins']))},'limits':['No native/compiler calls or changed product/source.','Existing V8 ordinary emitter mode observations do not guarantee enabled candidate keeps that mode after any changed instruction widths.','Current index-kind/value, future seal resource cost, and actual machine rewrite are unobserved and still mandatory gates.','This census is not a performance measurement or broader admission proof.']}
(D/'report.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'totals':r['totals'],'perWorkload':[{k:x[k] for k in ('workload','semanticCertificates','sourceSealable','ordinaryEmitterCandidates')} for x in rows]},indent=2))
