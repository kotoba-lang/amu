"""Source-only future six-call fixedpoint gate; explicit root GO required."""
from pathlib import Path
import os,json,hashlib,subprocess,re,sys
P=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
def save(p,r):p.write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':
 assert len(sys.argv)==3,'ROOT_GO.json and fresh output directory required'
 g=load(Path(sys.argv[1]));pr=load(P/'preregistration.json');pins=load(P/'input-pins.json')
 assert g['fixedpointAuthorized'] is True and g['maximumLoaderCalls']==6 and g['sourceResourceReviewAccepted'] is True and g['original19RawRegressionAccepted'] is True and g['finitePositiveRawAccepted'] is True
 for field,f in [('preregistrationSHA256','preregistration.json'),('inputPinsSHA256','input-pins.json'),('driverSHA256','run-fixedpoint.py')]:assert g[field]==sha(P/f)
 for name,r in pins.items():
  q=Path(name);assert sha(q)==r['sha256'] and q.stat().st_size==r['bytes'],name
 C=P.parent/'vector-emitter-local-bounds-native-build-v1-root';W=Path(sys.argv[2]).resolve();assert W.is_relative_to(P.parent) and not W.exists();W.mkdir();save(W/'authorization.json',g)
 src=W/'unity.kotoba';src.write_bytes((C/'unity.kotoba').read_bytes());initial=W/'seed-0.bin';initial.write_bytes((C/'candidate.bin').read_bytes());assert sha(src)==pr['sourceSHA256'] and sha(initial)==pr['candidateSHA256']
 base={k:v for k,v in os.environ.items() if not k.startswith('KEXE_')};removed=sorted(k for k in os.environ if k.startswith('KEXE_'))
 overrides={'KEXE_COMMAND':'1','KEXE_CAP_RESOURCES_35':str(W),'KEXE_CPU_SECONDS':'1800','KEXE_WALL_SECONDS':'1800','KEXE_STRING_POOL':'268435456','KEXE_VECTORS':'4194304','KEXE_PAIRS':'16777216','KEXE_VECTOR_ITEMS':'134217728'};env=base|overrides
 assert {k:v for k,v in env.items()if k.startswith('KEXE_')}==overrides
 save(W/'source-materialization.json',{'origin':str(C/'unity.kotoba'),'copy':str(src),'sha256':sha(src),'bytes':src.stat().st_size,'sourceReadOnlyEnforced':False})
 save(W/'environment.json',{'kexeEnvironment':overrides,'removedInheritedKexeKeys':removed,'wire35CombinedReadWriteScope':str(W)})
 attempts=[];generations=[]
 def guard():
  assert sha(src)==pr['sourceSHA256'] and src.stat().st_size==pr['sourceBytes'] and sha(initial)==pr['candidateSHA256']
  for row in generations:
   num=row['generation'];nb=W/f'seed-{num}.bin';kb=W/f'seed-{num}.kseed'
   assert sha(nb)==pr['candidateSHA256'] and nb.read_bytes()==initial.read_bytes() and sha(kb)==row['wholeKSEEDSHA256']
 def run(gen,seed,stage,args):
  guard();assert len(attempts)<6 and sha(seed)==pr['candidateSHA256']
  label=f'seed-{gen}-{stage}';cmd=[str(C/'kexe-loader'),str(seed),'0','0','aarch64','35,37,38,39','--',*args]
  r={'index':len(attempts)+1,'generation':gen,'stage':stage,'argv':cmd,'state':'started','kexeEnvironment':overrides,'removedInheritedKexeKeys':removed,'producerSHA256':sha(seed),'sourceSHA256':sha(src),'timeoutSeconds':1810};attempts.append(r);save(W/'attempts.json',attempts)
  try:t=subprocess.run(cmd,env=env,capture_output=True,timeout=1810);out,err,rc=t.stdout,t.stderr,t.returncode
  except subprocess.TimeoutExpired as e:out,err,rc=e.stdout or b'',e.stderr or b'',None
  (W/(label+'.stdout')).write_bytes(out);(W/(label+'.stderr')).write_bytes(err);r.update(state='terminal',returncode=rc,stdoutSHA256=hashlib.sha256(out).hexdigest(),stderrSHA256=hashlib.sha256(err).hexdigest());save(W/'attempts.json',attempts);guard();assert sha(seed)==pr['candidateSHA256']
  assert rc==0 and not err and b':ok true'in out,(gen,stage,rc)
  return out
 try:
  for gen in range(1,4):
   seed=W/f'seed-{gen-1}.bin';image=W/f'seed-{gen}.kseed';native=W/f'seed-{gen}.bin'
   run(gen,seed,'compile',['compile',str(src),'--target','aarch64-macos','--output',str(image)])
   out=run(gen,seed,'extract',['extract-native',str(image),'--symbol','main','--output',str(native)])
   offsets=re.findall(rb':offset (\d+)\b',out);assert len(offsets)==1 and int(offsets[0])==0;(W/f'seed-{gen}.offset').write_text('0\n')
   b=native.read_bytes();assert len(b)==pr['candidateBytes'] and sha(native)==pr['candidateSHA256'] and b==initial.read_bytes()
   assert image.read_bytes()==f'KSEED1 {len(b)} 1\nmain 0 0\n\n'.encode()+b
   row={'generation':gen,'nativeSHA256':sha(native),'bytes':len(b),'wholeKSEEDSHA256':sha(image),'offset':0,'exports':[{'name':'main','offset':0,'arity':0}],'byteExactInitial':True};generations.append(row);save(W/'generations.json',generations)
  guard();assert len(attempts)==6 and len(generations)==3
  save(W/'report.json',{'status':'PASS_CANDIDATE_THREE_GENERATION_FULL_BYTE_FIXEDPOINT_ONLY','loaderCalls':6,'generations':generations,'sourceSHA256':sha(src),'functionalBenchmarkCalls':0,'timing':False,'CperformanceQualified':False,'productAdopted':False})
 except BaseException as e:save(W/'failure.json',{'exception':repr(e),'calls':len(attempts),'completedGenerations':len(generations),'policy':'STOP_FIRST_FAILURE_NO_RERUN'});raise
 finally:save(W/'terminal.json',{'allCallsClosed':all(r['state']=='terminal'for r in attempts),'loaderCalls':len(attempts),'generations':len(generations),'failure':(W/'failure.json').exists()})
