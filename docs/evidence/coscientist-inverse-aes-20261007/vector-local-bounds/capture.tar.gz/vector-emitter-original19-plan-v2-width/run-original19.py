"""Prospective 38-call driver. No execution authorized by its creation."""
from pathlib import Path
import os,json,hashlib,subprocess,sys,re
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def container(p):
 b=p.read_bytes();h,code=b.split(b'\n\n',1);lines=h.decode().splitlines();v,n,ec=lines[0].split()
 assert v=='KSEED1' and int(n)==len(code) and int(ec)==len(lines)-1
 exports=[]
 for line in lines[1:]:
  name,off,arity=line.split();off=int(off);arity=int(arity);assert off>=0 and off<len(code) and off%4==0 and arity>=0
  exports.append({'name':name,'offset':off,'arity':arity})
 assert len({x['name']for x in exports})==len(exports)
 return code,exports
if __name__=='__main__':
 assert len(sys.argv)==3,'ROOT_GO.json and fresh output directory required'
 a=load(Path(sys.argv[1]));pr=load(P/'preregistration.json')
 assert a['original19CompilationAuthorized'] is True and a['maximumCalls']==38
 assert a['preregistrationSHA256']==sha(P/'preregistration.json') and a['inputPinsSHA256']==sha(P/'input-pins.json') and a['driverSHA256']==sha(Path(__file__))
 assert a['machinePositiveQualificationAccepted'] is True and a['sourceResourceReviewsAccepted'] is True
 q=Path(a['machineQualificationReport']);assert sha(q)==a['machineQualificationSHA256']
 assert a['qualifiedMachineSites']>0 # Root must validate actual per-site report; analysis44 is insufficient.
 for name,r in load(P/'input-pins.json').items():
  p=Path(name);assert sha(p)==r['sha256'] and p.stat().st_size==r['bytes'],name
 W=Path(sys.argv[2]).resolve();assert W.is_relative_to(P.parent) and not W.exists();W.mkdir();save(W/'authorization.json',a)
 C=P.parent/'vector-emitter-local-bounds-native-build-v1-root'
 inheritedRemoved=sorted(k for k in os.environ if k.startswith('KEXE_'))
 base={k:v for k,v in os.environ.items() if not k.startswith('KEXE_')}
 compilerEnv={'KEXE_COMMAND':'1','KEXE_CAP_RESOURCES_35':str(W),'KEXE_CPU_SECONDS':'1800','KEXE_WALL_SECONDS':'1800','KEXE_STRING_POOL':'268435456','KEXE_VECTORS':'4194304','KEXE_PAIRS':'16777216','KEXE_VECTOR_ITEMS':'134217728'}
 env=base|compilerEnv
 assert {k:v for k,v in env.items() if k.startswith('KEXE_')}==compilerEnv
 sourceDir=W/'sources';sourceDir.mkdir();sourceCopies={};sourceReceipts=[]
 for e in pr['entries']:
  origin=Path(e['source']);dest=sourceDir/(e['workload']+'.kotoba');dest.write_bytes(origin.read_bytes());pin=load(P/'input-pins.json')[str(origin)];h=pin['sha256'];assert sha(dest)==h and dest.stat().st_size==pin['bytes'] and sha(origin)==h
  sourceCopies[e['workload']]=(dest,h)
  sourceReceipts.append({'workload':e['workload'],'origin':str(origin),'copy':str(dest),'sha256':h,'bytes':dest.stat().st_size})
 assert len(sourceCopies)==19
 save(W/'source-materialization.json',sourceReceipts)
 save(W/'environment.json',{'kexeEnvironment':compilerEnv,'removedInheritedKexeKeys':inheritedRemoved,'resource35CombinedReadWriteBoundary':str(W),'externalSourcesGranted':False,'copyReadOnlyEnforced':False,'copyIntegrityChecks':'before and after every loader call'})
 def checkSources():
  for dest,h in sourceCopies.values():assert sha(dest)==h,('source copy changed',str(dest))
 checkSources()
 attempts=[];images=[]
 def run(d,stage,args):
  assert len(attempts)<38
  cmd=[str(C/'kexe-loader'),str(C/'candidate.bin'),'0','0','aarch64','35,37,38,39','--',*args]
  checkSources()
  r={'index':len(attempts)+1,'workload':d.name,'stage':stage,'argv':cmd,'state':'started','kexeEnvironment':compilerEnv,'removedInheritedKexeKeys':inheritedRemoved,'sourceSHA256':sourceCopies[d.name][1],'timeoutSeconds':1810};attempts.append(r);save(W/'attempts.json',attempts)
  try:
   t=subprocess.run(cmd,env=env,capture_output=True,timeout=1810);out,err,rc=t.stdout,t.stderr,t.returncode
  except subprocess.TimeoutExpired as e:out,err,rc=e.stdout or b'',e.stderr or b'',None
  (d/(stage+'.stdout')).write_bytes(out);(d/(stage+'.stderr')).write_bytes(err);r.update(state='terminal',returncode=rc);save(W/'attempts.json',attempts)
  checkSources()
  assert rc==0 and err==b'' and b':ok true' in out,(d.name,stage,rc)
  return out.decode()
 try:
  for e in pr['entries']:
   d=W/'ports'/e['workload'];d.mkdir(parents=True);src=sourceCopies[e['workload']][0];image=d/'image.kseed';native=d/'native.bin'
   run(d,'compile',['compile',str(src),'--target','aarch64-macos','--output',str(image)])
   out=run(d,'extract',['extract-native',str(image),'--symbol',e['symbol'],'--output',str(native)])
   matches=re.findall(r':offset (\d+)\b',out);assert len(matches)==1;off=int(matches[0]);(d/'native.offset').write_text(str(off)+'\n')
   code,exports=container(image);assert code==native.read_bytes();selected=[x for x in exports if x['name']==e['symbol']];assert len(selected)==1 and selected[0]['offset']==off
   b=Path(e['baselineDirectory'])
   for baselineFile in ['image.kseed','native.bin','native.offset']:
    bf=b/baselineFile;pin=load(P/'input-pins.json')[str(bf)];assert sha(bf)==pin['sha256'] and bf.stat().st_size==pin['bytes']
   old,oe=container(b/'image.kseed');assert old==(b/'native.bin').read_bytes()
   assert {(x['name'],x['arity'])for x in exports}=={(x['name'],x['arity'])for x in oe}
   row={'workload':e['workload'],'sourceSHA256':sha(src),'nativeSHA256':sha(native),'containerSHA256':sha(image),'bytes':len(code),'offset':off,'exports':exports,'baselineNativeSHA256':sha(b/'native.bin'),'baselineContainerSHA256':sha(b/'image.kseed'),'baselineExports':oe,'baselineBytes':len(old),'wholeNativeEqual':code==old,'wholeContainerEqual':image.read_bytes()==(b/'image.kseed').read_bytes(),'coverage':'NOT_INFERRED_FROM_BYTE_DIFF','functional':'NOT_RUN','performance':'NOT_RUN'}
   images.append(row);save(W/'images.json',images)
  assert len(attempts)==38 and len(images)==19
  save(W/'report.json',{'status':'PASS19 compilation/extraction and exportidentity ONLY','calls':38,'images':19,'machineCoverage':'requires separate per-site joined receipts','functional':'HOLD','performance':'HOLD','selfhostFixedPoint':'HOLD'})
 except BaseException as exc:save(W/'failure.json',{'error':repr(exc),'calls':len(attempts),'images':len(images)});raise
 finally:save(W/'terminal.json',{'allWritesComplete':True,'attempts':len(attempts),'images':len(images),'failure':(W/'failure.json').exists()})
