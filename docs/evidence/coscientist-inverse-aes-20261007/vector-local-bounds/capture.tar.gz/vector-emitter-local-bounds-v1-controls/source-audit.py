from pathlib import Path
import json,re,hashlib
D=Path(__file__).resolve().parent;W=D.parent;B=W/'vector-typed-analysis-v8'
pin=lambda p:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def forms(t):
 out={}
 for m in re.finditer(r'(?m)^\(defn- ([^\s]+) ',t):
  d=0;st=co=esc=False
  for j in range(m.start(),len(t)):
   c=t[j]
   if co:
    if c=='\n':co=False
   elif st:
    if esc:esc=False
    elif c=='\\':esc=True
    elif c=='"':st=False
   elif c==';':co=True
   elif c=='"':st=True
   elif c=='(':d+=1
   elif c==')':
    d-=1
    if d==0:out[m.group(1)]=t[m.start():j+1];break
  else:raise AssertionError(m.group(1))
 return out
old=(B/'unity-vector-analysis-default.kotoba').read_text();new=(D/'unity-vector-analysis-default.kotoba').read_text();fo,fn=forms(old),forms(new)
added=sorted(set(fn)-set(fo));changed=sorted(n for n in fo if fo[n]!=fn[n]);assert len(added)==13 and changed==sorted(['gn-rt-at','vw-publish','vw-entry-status','vw-run','gn-run-open'])
assert all(fo[n]==fn[n] for n in ['vw-cleanup','vw-certificates','vw-read-certificate','vw-shape-fixed','gn-loop','gn-ins','gn-op-rt','gn-hchk','gn-vidx','gn-ctx','gn-pin','gn-ldt','gn-fin','gn-chain-read','gn-vread','sl-read'])
def closure(roots):
 seen=set();todo=roots[:]
 while todo:
  n=todo.pop()
  if n in seen:continue
  seen.add(n)
  todo.extend(x for x in re.findall(r'\(([^\s()]+)',fn[n]) if x in fn and x not in seen)
 return sorted(seen)
prep=closure(['gn-pin','gn-src','gn-co','gn-dreg','gn-protect','gn-ctx','gn-ldt'])
assert 'gn-vmode' not in prep and not any('(gn-gs M gn-f-vmode' in fn[n] for n in prep)
# The only original emitter heap allocator call is module entry. No later bump can make absent seal bank appear owned.
emitterSegment=old[old.index('(def gn-cell '):old.index('(def vw-feature 0)')]
assert emitterSegment.count('(mem-alloc ')==0
moduleEntry=fo['gn-run-open'];assert moduleEntry.count('(mem-alloc ')==1
assert fn['gn-run-open'].count('(mem-alloc ')==1 and fn['gn-run-open'].index('enlarged (and')<fn['gn-run-open'].index('(mem-alloc ')
# Existing label table address strictly ends before module vars and new bank.
labelEnd=16400+131072;bank=labelEnd+82;end=bank+2056
assert labelEnd==147472 and bank==147554 and end==149610
assert bank>147553 and bank>66576
# Inspect all old accesses to module-wide cells, retaining full source as authority.
moduleCellLines=[x for x in emitterSegment.splitlines() if 'gn-g-open' in x or 'gn-g-open-n' in x]
# Finite allocator boundary model mirrors preflight choice; no failed-new-then-retry transition exists.
alloc=[]
for remaining in [-1,0,147553,147554,149609,149610,149611]:
 for enabled in [False,True]:
  enlarged=enabled and remaining>=149610
  choice=149610 if enlarged else 147554
  ok=remaining>=choice
  assert not enlarged or ok
  assert not(enabled and 147554<=remaining<149610) or (choice==147554 and ok)
  alloc.append({'remaining':remaining,'enabled':enabled,'requestedOnce':choice,'success':ok})
# Valid-last component publication transitions: capped writes fail closed and bankclear removes every partial prefix.
publication=[]
for remaining in range(12):
 valid=0;fields=[0]*8;refused=False
 for k in range(8):
  if remaining<=0:refused=True;break
  remaining-=1;fields[k]=k+1
 if not refused:
  if remaining<=0:refused=True
  else:remaining-=1;valid=1
 if refused:fields=[0]*8;valid=0
 assert not refused or (valid==0 and fields==[0]*8)
 publication.append({'refused':refused,'validAfterClear':valid})
# Exact original gn-vidx remaining sequence in ve-read, with original hchk and load.
read=fn['ve-read'];assert '(gn-hchk rv 312 320)' in read
for x in ['(enc-ldp 17 16 16 0)','(enc-ldr 16 7 328)','(enc-add-r 17 17 ri)','(gn-e-ldrr d 16 17 1)']:assert x in read
assert 'enc-cmp-' not in read and 'enc-bcond' not in read and 'gn-e-udf' not in read
r={'status':'AUTHOR_SOURCE_SEMANTIC_RESOURCE_AUDIT_ONLY_HOLD_FOR_INDEPENDENT_REVIEW','native':0,'changed':changed,'added':added,'prePinPreparationClosure':prep,'vmodeUnchangedThroughPreparation':True,'sealBankG':[bank,end],'sealWords':2056,'originalAnalysisOwnedWords':50689,'allocationFiniteBoundaries':alloc,'abstractPublicationBoundaryCases':len(publication),'originalModuleCellSourceLines':moduleCellLines,'writeOwnership':[
'Only original module allocator bumps heap; GNloop doesnot allocate additional compile-time heap. New span is chosenbefore oneallocation or oldfallback remains absent through emitter.',
'Original G arrays16..16399 and labelslots16401..147471 endbelow147472; original module state offsets0..81 end147553. New header/records147554..149609 are disjoint all original G writes for validated input; no borrowing LPgap.',
'Init and denied-entry clear are uncapped2056 ownerwrites. Export field/header writes use inherited capped vw-write; valid flag last. Globalrefusal/partialpublish clearsseal beforeanalysiscleanup. PostGNloop clear checksstructuralrange without MMERR guard and clears2056 evenemittererror.',
'Analysispreflight/cleanup50689 unchanged; enabled preflight alsorequires extendedspan+zeroseal. Denied admission mayclearonlynewsealowner; therefore olddirtywholeM-no-op contract mustexcludeexplicitsealownerchange.',
'Consumer scans <=256records and each candidate currentbodybackscan<=8192. This is a compiletime finitework bound, not128CPU-instructionmeter theorem. No runtimecache/pointer table or newABIfields.'
],'semanticBoundary':[
'Consumer predicate evaluatedbeforepinning; original pin/context/protect/load preparation doesnot change vmode; knownconstant index is materializedby the original path. RT176 mode0/t<=5 only.',
'Record creation onlysameprivatebodyRT200 immediatelyprecededmatchingOPCONSTlength>=L>0; certificate index0<=K<L. NoOPVECP length inference or parameter identity accepted.',
'Ve-read retains unchangedgn-hchk thenoriginaldescriptor offset/pool/address/load; onlygn-vidx CMP/B.LO/UDF absent. NoSIR mutation, opcode addition, targetABI/frame/fuel/trap speculative move.',
'Postcleanseal immutable exceptmandatoryclears; staleheader deniedentry clear. Source-record checks complementtrustedcompleteV8facts; this is notuniversal verifier proof.'
],'limits':[
'All lexical balancing/reversal only; compileracceptance/native/CODEdeltas/defaultOFFfixturebyteidentity/selfhostfixedpoint and result/trap/fuel parity pending rootGO.',
'Newhelper bodies change candidatecompiler image evenOFF. Disabled compiledinput baseline identity remains experimental gate, not source assertion.',
'Enabled candidate may exceed128functions forselfhost; conservativeanalysis refusal and oldemission fallback are allowed ifactualfixedpointstillpasses.',
'No arbitraryM/forgedheap ownership/concurrency/globalcompilerproof/performance/Csuperiority claim.'
],'inputPins':{'frozenV8':pin(B/'unity-vector-analysis-default.kotoba'),'newDefault':pin(D/'unity-vector-analysis-default.kotoba'),'newOn':pin(D/'unity-vector-analysis-on.kotoba')}}
(D/'author-source-audit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'report':pin(D/'author-source-audit.json'),'prepHelpers':len(prep)}))
