from pathlib import Path
import json,hashlib,re,difflib
D=Path(__file__).resolve().parent;W=D.parent;B=W/'vector-typed-analysis-v8'
pin=lambda p:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
assert pin(D/'source-appendix-prospective.json')['sha256']=='1cc3b3fc575a5f807b7e75427e2ef1aa84c8272e028cd0a5bd0e6ca95b355508'
def form(t,n):
 st=t.index('(defn- '+n+' ');depth=0;string=comment=escape=False
 for j in range(st,len(t)):
  c=t[j]
  if comment:
   if c=='\n':comment=False
  elif string:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':string=False
  elif c==';':comment=True
  elif c=='"':string=True
  elif c=='(':depth+=1
  elif c==')':
   depth-=1
   if depth==0:return t[st:j+1]
 raise AssertionError(n)
s=(B/'unity-vector-analysis-default.kotoba').read_text();helpers=(D/'helpers.kotoba').read_text();changes=[]
u=form(s,'gn-rt-at')
v=u.replace('(let [slot ', '(let [certified (ve-admit? M i t)\n        slot ',1)
v=v.replace('    (-> M1 (gn-protect t s) (gn-ctx) (gn-ldt t 17 0) (gn-chain-read rv ri d slot) (gn-fin t s d))))', '''    (let [m2 (-> M1 (gn-protect t s) (gn-ctx) (gn-ldt t 17 0))
          m3 (if certified (ve-read m2 rv ri d) (gn-chain-read m2 rv ri d slot))]
      (gn-fin m3 t s d)))))''',1)
assert v!=u and '(ve-read m2 rv ri d)' in v;changes.append(('gn-rt-at',u,v))
u=form(s,'vw-publish');v='(defn- vw-publish [M :vector-i64] :vector-i64 (ve-publish M))';changes.append(('vw-publish',u,v))
u=form(s,'vw-entry-status');v=u.replace('need (+ gn-a-lp MM-LABEL-CAP 82)', 'need (+ gn-a-lp MM-LABEL-CAP 82 (if (= ve-feature 1) 2056 0))',1).replace('(not (vw-reserved-zero? M)) 7 :else 0','(not (vw-reserved-zero? M)) 7\n                (and (= ve-feature 1) (not (ve-bank-zero? M))) 7 :else 0',1);assert v!=u;changes.append(('vw-entry-status',u,v))
u=form(s,'vw-run');v=u.replace('(if (not= (vw-entry-status M) 0) M','(if (not= (vw-entry-status M) 0) (ve-clear M)',1);assert v!=u;changes.append(('vw-run',u,v))
u=form(s,'gn-run-open')
v='''(defn- gn-run-open [M :vector-i64 first :i64 count :i64] :vector-i64
 (let [top (vector-at M MM-HEAP-TOP) m0 (if (< top MM-HEAP-BASE) (gn-put M MM-HEAP-TOP MM-HEAP-BASE) M)
       b (vector-at m0 MM-HEAP-TOP) oldneed (+ gn-a-lp MM-LABEL-CAP 82) newneed (+ oldneed 2056)
       enlarged (and (= ve-feature 1) (= (mem-fits b (+ b newneed) newneed) 1) (<= b (vector-count m0)) (<= newneed (- (vector-count m0) b)))
       m1 (mem-alloc m0 (if enlarged newneed oldneed))]
  (if (not= (vector-at m1 MM-ERR) 0) m1
   (let [m2 (-> (gn-put m1 gn-cell (vector-at m1 MM-R0)) (gn-gs gn-g-open first) (gn-gs gn-g-open-n count)
                  (gn-gs di-used 0) (gn-gs di-sites 0) (gn-gs as-used 0) (gn-gs as-sites 0))
         m2a (ve-clear m2)
         m3 (gn-loop (if (= vw-feature 1) (vw-run m2a) m2a) 1)
         m4 (ve-clear m3)]
    (gn-put m4 MM-R0 (- (vector-at m4 MM-CODE-N) 1))))))'''
changes.append(('gn-run-open',u,v))
for n in ['41-vector-analysis-default.kotoba','41-vector-analysis-on.kotoba','unity-vector-analysis-default.kotoba','unity-vector-analysis-on.kotoba']:
 t=(B/n).read_text();reps=[]
 for name,old,new in changes:
  assert t.count(old)==1,(n,name);t=t.replace(old,new,1);reps.append((old,new))
 h=helpers if 'default' in n else helpers.replace('(def ve-feature 0)','(def ve-feature 1)')
 marker='(defn- gn-rt-at ';assert t.count(marker)==1;t=t.replace(marker,h+marker,1)
 rev=t.replace(h,'',1)
 for old,new in reversed(reps):assert rev.count(new)==1;rev=rev.replace(new,old,1)
 assert rev==(B/n).read_text(),n
 # Lexical syntax only; compiler/native intentionally absent.
 depth=0;string=comment=escape=False
 for c in t:
  if comment:
   if c=='\n':comment=False
  elif string:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c=='"':string=False
  elif c==';':comment=True
  elif c=='"':string=True
  elif c=='(':depth+=1
  elif c==')':depth-=1;assert depth>=0,(n,'negative')
 assert depth==0 and not string,(n,depth)
 (D/n).write_text(t)
a=(B/'analysis.kotoba').read_text();kernel=a
for name,old,new in changes:
 if name.startswith('vw-'):assert kernel.count(old)==1;kernel=kernel.replace(old,new,1)
(D/'analysis.kotoba').write_text(kernel)
(D/'source.diff').write_text(''.join(difflib.unified_diff(s.splitlines(True),(D/'unity-vector-analysis-default.kotoba').read_text().splitlines(True),fromfile='frozenV8default',tofile='isolatedVEdefault')))
(D/'source-deltas.json').write_text(json.dumps({'helpers':helpers,'insertMarker':'(defn- gn-rt-at ','changes':[{'name':n,'old':a,'new':b} for n,a,b in changes],'reverseFourVariantsExactV8':True},indent=2)+'\n')
(D/'report.json').write_text(json.dumps({'status':'SOURCE_ONLY_HOLD_PENDING_INDEPENDENT_REVIEW_NO_NATIVE_GO','native':0,'productEdits':0,'fourReverseV8Exact':True,'lexicalBalance':True,'featureDefault':0,'helpers':13,'changedDefinitions':[n for n,a,b in changes],'bankWords':2056,'enabledGWords':149610,'analysisCleanupWords':50689,'fallback':'preflight choosesold147554 before singlememalloc; analysisentry6/inactivebank originalemitter fallback','kernel':pin(D/'analysis.kotoba'),'variants':{n:pin(D/n) for n in ['41-vector-analysis-default.kotoba','41-vector-analysis-on.kotoba','unity-vector-analysis-default.kotoba','unity-vector-analysis-on.kotoba']},'candidate':'sameprivatebody RT200 only, precedingmatchingOPCONST; gn-rt-at mode0 knownconstantindex; retainedhchk removedbounds3 only','runtimePerformance':False,'actualEligibleSitesUnknown':True},indent=2)+'\n')
print(json.dumps({'report':pin(D/'report.json'),'onUnity':pin(D/'unity-vector-analysis-on.kotoba')}))
