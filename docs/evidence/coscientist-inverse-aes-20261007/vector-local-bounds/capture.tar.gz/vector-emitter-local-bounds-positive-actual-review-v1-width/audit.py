from pathlib import Path
import json,hashlib,re,struct,runpy
W=Path(__file__).resolve().parent;D=W.parent/'vector-emitter-local-bounds-positive-v1-controls';P=W.parent/'vector-emitter-local-bounds-native-build-v1-root'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());pins={}
def bind(p):pins[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size};return p.read_bytes()
def jl(p):bind(p);return load(p)
pr=jl(D/'preregistration.json');sp=jl(D/'source-pins.json');assert sha(D/'source-pins.json')=='f0efa52cc26c5b716972845a733581349af9243068594dd86538b9fde1e042b9'
for n,h in sp.items():assert sha(D/n)==h;bind(D/n)
for k in ['referenceProducer','candidateProducer','candidateBuild','candidateSource','loader']:
 p=Path(pr[k]['path']);assert sha(p)==pr[k]['sha256'] and p.stat().st_size==pr[k]['bytes'];bind(p)
g=jl(D/'parent-go.json');assert g['authorizeNative'] is True and g['maximumLoaderCalls']==10 and g['sourcePinsSHA256']==sha(D/'source-pins.json') and g['timingAuthorized'] is False and g['original19Authorized'] is False
review=W.parent/'vector-emitter-local-bounds-positive-review-v1-width/report.json';assert sha(review)==g['widthSourceReviewSHA256'];bind(review)
t=jl(D/'terminal.json');assert t=={'allCallsClosed':True,'loaderCalls':10,'failure':False} and not(D/'failure.json').exists()
a=jl(D/'attempts.json');assert len(a)==10
ce={'KEXE_COMMAND':'1','KEXE_CAP_RESOURCES_35':str(D),'KEXE_STRING_POOL':'268435456','KEXE_VECTORS':'4194304','KEXE_PAIRS':'16777216','KEXE_VECTOR_ITEMS':'134217728','KEXE_CPU_SECONDS':'1800','KEXE_WALL_SECONDS':'1800'}
fe={'KEXE_ARG_TYPES':'i64','KEXE_CPU_SECONDS':'30','KEXE_FUEL':'16777216','KEXE_RESULT_TYPE':'i64','KEXE_STRUCTURED_REPORT':'1','KEXE_VECTORS':'4096','KEXE_VECTOR_ITEMS':'65536','KEXE_WALL_SECONDS':'30'}
expected=[]
for v,b in [('reference','producer.bin'),('candidate','candidate.bin')]:
 pre=[str(P/'kexe-loader'),str(P/b),'0','0','aarch64','35,37,38,39','--']
 expected +=[(v+'-compile',pre+['compile',str(D/'fixture.kotoba'),'--target','aarch64-macos','--output',str(D/(v+'.kseed'))],ce,1810),(v+'-extract',pre+['extract-native',str(D/(v+'.kseed')),'--symbol','bench','--output',str(D/(v+'.bin'))],ce,1810)]
for n in [0,7,-1]:
 for v in ['reference','candidate']:
  expected.append((v+'-n'+str(n),[str(P/'kexe-loader'),str(D/(v+'.bin')),(D/(v+'.offset')).read_text().strip(),'1','aarch64','-',str(n)],fe,40))
results={}
for i,(row,(label,argv,env,timeout))in enumerate(zip(a,expected),1):
 assert row['index']==i and row['label']==label and row['argv']==argv and row['kexeEnvironment']==env and row['timeoutSeconds']==timeout and row['state']=='terminal' and row['returncode']==0
 assert all(x.startswith('KEXE_')for x in row['inheritedKexeRemoved']) and sha(Path(argv[1]))==row['imageSHA256']
 out=bind(D/(label+'.stdout'));err=bind(D/(label+'.stderr'));assert err==b'' and hashlib.sha256(out).hexdigest()==row['stdoutSHA256'] and hashlib.sha256(err).hexdigest()==row['stderrSHA256']
 if i<=4:assert b':ok true' in out
 else:
  n=int(argv[-1]);expect=(f'{{:status :ok :result {n} :fuel {{:initial 16777216 :remaining 16777214}} :heap {{:capacity 4096 :used 0}} :string-pool {{:capacity 65536 :used 0}} :vectors {{:capacity 4096 :used 1}} :vector-items {{:capacity 65536 :used 4}}}}\n').encode();assert out==expect
  assert 'KEXE_COMMAND' not in env;results[label]={'result':n,'initialFuel':16777216,'remainingFuel':16777214,'heap':[4096,0],'stringPool':[65536,0],'vectors':[4096,1],'vectorItems':[65536,4]}
words={};exports={}
for v,sz,off in [('reference',260,232),('candidate',248,220)]:
 b=bind(D/(v+'.bin'));kb=bind(D/(v+'.kseed'));actualoff=int(bind(D/(v+'.offset')));assert len(b)==sz and actualoff==off
 h,code=kb.split(b'\n\n',1);assert code==b and h==f'KSEED1 {sz} 1\nbench {off} 1'.encode()
 words[v]=struct.unpack('<'+'I'*(sz//4),b);exports[v]={'symbol':'bench','arity':1,'offset':off}
old,new=words['reference'],words['candidate'];assert old[45:48]==(0xeb10015f,0x54000043,0)
expected=list(old[:45]+old[48:]);assert len(expected)==len(new)
changed=[]
for ni,(ow,nw)in enumerate(zip(expected,new)):
 oi=ni if ni<45 else ni+3
 if ow!=nw:
  assert oi==63 and ni==60 and ow==0x17ffffc1 and nw==0x17ffffc4
  sign=lambda z:z-(1<<26)if z&(1<<25)else z
  ot=oi+sign(ow&0x3ffffff);nt=ni+sign(nw&0x3ffffff);assert ot==nt==0
  changed.append({'oldPC':252,'newPC':240,'target':0,'oldWord':hex(ow),'newWord':hex(nw)})
assert len(changed)==1
assert tuple(new[36:48])==old[36:45]+old[48:51]
# Replay frozen pure comparator without source mutation or invoking its main.
comp=runpy.run_path(str(D/'compare.py'));recomputed=comp['compare_folder'](D);published=jl(D/'structural-validation.json');assert recomputed==published
report=jl(D/'report.json');assert report['results']==results and report['structural']==recomputed and report['loaderCalls']==10 and report['functionalCalls']==6
r={'status':'PASS_INDEPENDENT_ACTUAL_SINGLE_POSITIVE10_ONLY','nativeReruns':0,'compilerCalls':4,'functionalCalls':6,'sourceFixtureSHA256':sha(D/'fixture.kotoba'),'referenceBytes':260,'candidateBytes':248,'actualSingleReadByteOffset':144,'actualDeletedByteOffset':180,'removedWords':[hex(x)for x in old[45:48]],'retainedHchk8DescriptorPoolAddressLoadExact':True,'allOtherWordsExactExceptOneBranchRelocation':changed,'exports':exports,'functionalResults':results,'fuelConsumedEach':2,'commandModeAbsentFunctional':True,'allStatusRcStderrArgvEnvCapsPinsExact':True,'limitations':['single localallocation4 private read0 only','no invalidhandle/index runtime trapcases','no original19 coverage/C performance/timing/selfhost/adoption qualification','native state observations are structured fuel/arena receipts, not universal memory proof'],'pins':pins}
(W/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(sha(W/'report.json'))
