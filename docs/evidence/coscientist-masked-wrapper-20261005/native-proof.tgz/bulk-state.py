from pathlib import Path
import subprocess,os,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-masked-wrapper-20261005');base=Path('/private/tmp/amu-wrapper-prototype-20261005');src=w/'picojpeg-state-observer.kotoba'
s=(r/'bench/embench/picojpeg-full.kotoba').read_text().replace('(:export [bench repeated-state bounds-probe])','(:export [main])',1)
s+='''\n;; Experimental observation only; canonical timed source is unchanged.
(defn- emit-cells [v :vector-i64 i :i64] :i64
  (if (= i 4096) 0
      (let [out (typed-cap-call :io/write :string :string (string-concat (string-from-i64 (vector-at v i)) "\\n"))]
        (emit-cells v (inc i)))))
(defn main [] :i64
  (let [v (repeated-bodies (vector-alloc 4096) 1 0) a (emit-cells v 0)
        u (repeated-bodies (vector-alloc 4096) 2 0) b (emit-cells u 0)] (+ a b)))
''';src.write_text(s)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');loader=str(w/'kexe-loader');rows=[]
for label,seed in [('baseline',base/'seed-4.bin'),('candidate',w/'seed-4.bin')]:
 d=w/('bulk-'+label);d.mkdir(exist_ok=True);out=d/'image.kseed'
 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(out)]),('extract',['extract-native',str(out),'--symbol','main','--output',str(d/'native.bin')])]:
  p=subprocess.run([loader,str(seed),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(mode+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(mode,p.stdout,p.stderr)
  if mode=='extract':off=re.search(r':offset (\d+)',p.stdout).group(1)
 p=subprocess.run([loader,str(d/'native.bin'),off,'0','aarch64','37','--'],env=env,capture_output=True,text=True);(d/'stdout').write_text(p.stdout);(d/'stderr').write_text(p.stderr);assert p.returncode==0,(label,p.returncode,p.stderr);assert len(p.stdout.splitlines())==8192
 rows.append(p.stdout);print('PASS bulk cells',label,len(p.stdout.splitlines()),flush=True)
assert rows[0]==rows[1]
(w/'bulk-state.json').write_text(json.dumps({'status':'complete-exact-8192-cell-parity','bodies':[1,2],'cellsPerBody':4096,'stdoutSha256':hashlib.sha256(rows[0].encode()).hexdigest(),'observerSourceSha256':hashlib.sha256(src.read_bytes()).hexdigest(),'timedSourceUnchanged':True},indent=2)+'\n')
