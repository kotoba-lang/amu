from pathlib import Path
import json,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-scatter-zero-20261005');g=(r/'seed/41-a64gen.kotoba').read_text();prior=Path('/private/tmp/amu-index-write-20261005/41-a64gen-prototype.kotoba').read_text();fuel=prior[prior.index('(defn- gn-index-fuel'):prior.index('(defn- gn-index-sign')];write=prior[prior.index('(defn- gn-index-write'):prior.index('(defn- gn-index-wrapper')]
# Pure proof of a dependency tree, independent of traversal/function order.
tree=g[g.index('(defn- gn-tree-end'):g.index('(defn- gn-tree-data')]
tree=tree.replace('gn-tree-end','gn-scatter-tree-end').replace('gn-tree-value','gn-scatter-tree-value').replace('[M :vector-i64 p :i64 depth :i64]','[M :vector-i64 p :i64 depth :i64 lo :i64 hi :i64]').replace('[M :vector-i64 p :i64 x :i64]','[M :vector-i64 p :i64 x :i64 lo :i64 hi :i64]').replace('(inc depth))','(inc depth) lo hi)').replace('(gn-lpos M le)','(gn-scatter-pos M lo hi le lo 0)').replace('(gn-lpos M lx)','(gn-scatter-pos M lo hi lx lo 0)').replace('(gn-lpos M (gn-sir M (+ p 3) IF-B))','(gn-scatter-pos M lo hi (gn-sir M (+ p 3) IF-B) lo 0)').replace('))) x)))','))) x lo hi)))')
helper=''';; Exact dependency labels are resolved inside the callee, not the caller's prescan.
(defn- gn-scatter-pos [M :vector-i64 lo :i64 hi :i64 l :i64 j :i64 acc :i64] :i64
  (if (>= j hi) acc (gn-scatter-pos M lo hi l (inc j) (if (and (= (gn-op M j) OP-LABEL) (= (gn-sir M j IF-A) l)) j acc))))
(defn- gn-scatter-end [M :vector-i64 a :i64 j :i64] :i64
  (cond (or (>= j (vector-at M MM-SIR-N)) (> (- j a) 1024) (= (gn-op M j) OP-FN)) 0
        (= (gn-op M j) OP-END) j
        :else (gn-scatter-end M a (inc j))))
'''+tree+'''
(defn- gn-scatter-range [M :vector-i64 p :i64 lo :i64 hi :i64 x :i64] :bool
  (if (= x 64) true (let [v (gn-scatter-tree-value M p x lo hi)]
    (and (>= v 0) (< v 64) (gn-scatter-range M p lo hi (inc x))))))
(defn- gn-scatter-root [M :vector-i64 f :i64] :i64
  (let [a (gn-fnf M f FF-SIR) hi (gn-scatter-end M a (inc a)) charge (if (= (gn-op M (inc a)) OP-FUEL) 1 0)
        label (+ a 1 charge) p (inc label)]
    (if (and (> a 0) (> hi 0) (= (gn-op M a) OP-FN) (= (gn-sir M a IF-A) f) (= (gn-sir M a IF-B) 1)
             (gn-index-fuel M a) (= (gn-op M label) OP-LABEL) (= (gn-sir M label IF-B) 0) (= (gn-sir M label IF-C) 0))
      (let [end (gn-scatter-tree-end M p 0 a hi)]
        (if (and (> (- end p) 128) (= (inc end) hi) (= (gn-op M end) OP-RET)
                 (= (gn-sir M end IF-A) 0) (= (gn-sir M end IF-B) 0) (= (gn-sir M end IF-C) 0)
                 (= (gn-sir M hi IF-A) f) (= (gn-sir M hi IF-B) 0) (= (gn-sir M hi IF-C) 0)
                 (gn-scatter-range M p a hi 0)) p 0)) 0)))
(defn- gn-scatter-regs [M :vector-i64 k :i64] :bool
  (if (> k 3) true (and (>= (gn-sreg M k) 19) (<= (gn-sreg M k) 28) (gn-scatter-regs M (inc k)))))
'''
shape=[('OP-LGET',0,2,0),('OP-LGET',1,3,0),('OP-CMP','CC-EQ',0,0),('OP-BRZ',0,'le',0),('OP-LGET',0,1,0),('OP-BR','lx',0,0),('OP-LABEL','le',0,0),('OP-LGET',0,1,0),('OP-CONST',1,'base',0),('OP-LGET',2,2,0),('OP-CALL','mf',2,1),('OP-BIN','BOP-ADD',1,0),('OP-CONST',2,0,0),('OP-CALL','wf',0,3),('OP-LGET',1,2,0),('OP-CONST',2,1,0),('OP-BIN','BOP-ADD',1,0),('OP-LGET',2,3,0),('OP-LSET',1,0,0),('OP-LSET',2,1,0),('OP-LSET',3,2,0),('OP-FUEL',0,0,0),('OP-BR','loop',0,0),('OP-LABEL','lx',0,0),('OP-RET',0,0,0),('OP-END','f',0,0)]
checks='\n                 '.join(f'(and (= (gn-op M (+ q {j})) {op}) (= (gn-sir M (+ q {j}) IF-A) {a}) (= (gn-sir M (+ q {j}) IF-B) {b}) (= (gn-sir M (+ q {j}) IF-C) {c}))' for j,(op,a,b,c) in enumerate(shape))
helper+=''';; Exact scatter-zero recurrence. The token is its SIR expression start.
(defn- gn-scatter-wrapper [M :vector-i64 f :i64] :i64
  (let [p (gn-fnf M f FF-SIR)]
    (if (or (< p 1) (not= (gn-op M p) OP-FN) (not= (gn-sir M p IF-A) f)
            (not= (gn-sir M p IF-B) 3) (not (gn-index-fuel M p))
            (not= (gn-g M gn-f-leaf) 0) (not= (gn-g M gn-f-freg) 0) (not (gn-scatter-regs M 1))) 0
      (let [charge (if (= (gn-op M (inc p)) OP-FUEL) 1 0) lab (+ p 1 charge) q (inc lab)
            loop (gn-sir M lab IF-A) le (gn-sir M (+ q 3) IF-B) lx (gn-sir M (+ q 5) IF-A)
            mf (gn-sir M (+ q 10) IF-A) wf (gn-sir M (+ q 13) IF-A) base (gn-sir M (+ q 8) IF-B)]
        (if (and (= (gn-op M lab) OP-LABEL) (> loop 0) (= (gn-sir M lab IF-B) 0) (= (gn-sir M lab IF-C) 0)
                 (> le 0) (> lx 0) (not= loop le) (not= loop lx) (not= le lx) (> mf 0) (> wf 0) (not= mf f) (not= wf f)
                 (>= base 0) (<= base 4095)
                 CHECKS
                 (> (gn-index-write M wf) 0) (> (gn-scatter-root M mf) 0)) q 0)))))
'''.replace('CHECKS',checks)
asm=''';; Original optional mapper leaf transaction commits only after its pure lookup.
(defn- gn-scatter-map-fuel [M :vector-i64] :vector-i64
  (-> M (gn-emit (enc-ldr 8 7 CTX-FUEL)) (gn-emit (enc-subs-i 8 8 1)) (gn-emit (enc-bcond (enc-cond-hs) 3))
        (gn-emit (enc-str 31 7 CTX-FUEL)) (gn-emit (enc-brk 0))))
;; Guards precede any charge or write. Original loop remains on all failures.
(defn- gn-scatter-data [M :vector-i64 p :i64 lo :i64 hi :i64 x :i64] :vector-i64
  (if (= x 64) M (let [v (gn-scatter-tree-value M p x lo hi)]
    (gn-scatter-data (-> M (gn-emit v) (gn-emit 0)) p lo hi (inc x)))))
(defn- gn-scatter-fast [M :vector-i64 f :i64 q :i64] :vector-i64
  (let [rv (gn-sreg M 1) rk (gn-sreg M 2) re (gn-sreg M 3)
        mf (gn-sir M (+ q 10) IF-A) wf (gn-sir M (+ q 13) IF-A) base (gn-sir M (+ q 8) IF-B)
        a (gn-fnf M mf FF-SIR) hi (gn-scatter-end M a (inc a)) p (gn-scatter-root M mf)
        cf (if (= (gn-op M (inc (gn-fnf M f FF-SIR))) OP-FUEL) 1 0)
        cm (if (= (gn-op M (inc a)) OP-FUEL) 1 0) cw (dec (gn-index-write M wf))
        M0 (gn-emit M (enc-cmp-i re 64)) f0 (vector-at M0 MM-CODE-N)
        M1 (-> M0 (gn-emit (enc-bcond 8 0)) (gn-emit (enc-cmp-r rk re))) f1 (vector-at M1 MM-CODE-N)
        M2 (-> M1 (gn-emit (enc-bcond 8 0)) (gn-emit (enc-ldr 16 7 312)) (gn-emit (enc-ldr 16 16 0))
               (gn-emit (enc-sub-i 17 rv 1)) (gn-emit (enc-cmp-r 17 16))) f2 (vector-at M2 MM-CODE-N)
        M3 (-> M2 (gn-emit (enc-bcond (enc-cond-hs) 0)) (gn-emit (enc-ldr 16 7 320))
               (gn-emit (gn-e-addsl 16 16 17 4)) (gn-emit (enc-ldp 17 16 16 0)) (gn-mov 9 17)
               (gn-mov-imm 17 (+ base 64)) (gn-emit (enc-cmp-r 16 17))) f3 (vector-at M3 MM-CODE-N)
        M4 (-> M3 (gn-emit (enc-bcond (enc-cond-lo) 0)) (gn-emit (enc-ldr 16 7 328))
               (gn-emit (gn-e-addsl 9 16 9 3)) (gn-mov-imm 16 (* base 8)) (gn-emit (enc-add-r 9 9 16))
               (gn-mov 11 rk) (gn-mov 12 re) (cond-> (= cf 1) (gn-op-fuel))) adr (vector-at M4 MM-CODE-N)
        M5 (gn-emit M4 (gn-e-adr 10)) loop (vector-at M5 MM-CODE-N)
        M6 (gn-emit M5 (enc-cmp-r 11 12)) done (vector-at M6 MM-CODE-N)
        M7 (-> M6 (gn-emit (enc-bcond (enc-cond-eq) 0)) (cond-> (= cm 1) (gn-scatter-map-fuel))
               (gn-emit (gn-e-ldrr 13 10 11 1)) (cond-> (= cm 1) (gn-emit (enc-str 8 7 CTX-FUEL))) (cond-> (= cw 1) (gn-op-fuel))
               (gn-emit (gn-e-strr3 31 9 13)) (gn-emit (enc-add-i 11 11 1)) (gn-op-fuel)) back (vector-at M7 MM-CODE-N)
        M8 (gn-emit M7 (enc-b (- loop back))) end (vector-at M8 MM-CODE-N)
        M9 (-> M8 (gn-mov 0 rv) (gn-epilogue) (gn-gs gn-f-dead 0)) table (vector-at M9 MM-CODE-N)
        M10 (gn-scatter-data M9 p a hi 0) fallback (vector-at M10 MM-CODE-N) delta (* (- table adr) 4)]
    (-> M10 (gn-put (+ MM-CODE-BASE f0) (enc-bcond 8 (- fallback f0)))
         (gn-put (+ MM-CODE-BASE f1) (enc-bcond 8 (- fallback f1)))
         (gn-put (+ MM-CODE-BASE f2) (enc-bcond (enc-cond-hs) (- fallback f2)))
         (gn-put (+ MM-CODE-BASE f3) (enc-bcond (enc-cond-lo) (- fallback f3)))
         (gn-put (+ MM-CODE-BASE done) (enc-bcond (enc-cond-eq) (- end done)))
         (gn-put (+ MM-CODE-BASE adr) (+ (gn-e-adr 10) (i64-shift-left (bit-and delta 3) 29) (i64-shift-left (i64-shift-right delta 2) 5))))))
(defn- gn-scatter-entry [M :vector-i64 f :i64] :vector-i64
  (let [q (gn-scatter-wrapper M f)] (if (= q 0) M (gn-scatter-fast M f q))))
'''
a=';; ---- FLOAT (agent FLOAT';assert g.count(a)==1;g=g.replace(a,fuel+write+helper+asm+'\n'+a)
a='(gn-gs gn-f-h 0) (gn-tree-entry f)))))))';assert g.count(a)==1;g=g.replace(a,'(gn-gs gn-f-h 0) (gn-tree-entry f) (gn-scatter-entry f)))))))')
(w/'41-a64gen-prototype.kotoba').write_text(g);files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
for ext in ['bin','offset']:shutil.copyfile(Path('/private/tmp/amu-scalar-tree-20261005')/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile('/private/tmp/amu-scalar-tree-20261005/kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['build.py','check-ports.py','bulk-state.py']:
 s=Path('/private/tmp/amu-scalar-tree-20261005',name).read_text().replace('amu-scalar-tree-20261005','amu-scatter-zero-20261005').replace("base=Path('/private/tmp/amu-sign-wrapper-20261005')","base=Path('/private/tmp/amu-scalar-tree-20261005')").replace("pathlib.Path('/private/tmp/amu-sign-wrapper-20261005/ports-correctness.json')","pathlib.Path('/private/tmp/amu-scalar-tree-20261005/ports-correctness.json')");(w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'hypothesis':'Prove complete bounded scatter-zero recurrence and pure threshold-tree dependency (values0..63) plus in-place writer. Guard0<=k<=end<=64, valid vector handle and len>=base+64. Hoist descriptor/bounds and emit native table loads and zero stores with no calls, retaining original optional entry/map/write and every backedge fuel checkpoint. Otherwise execute original loop before any charge/mutation.','promotion':'Fresh30 quiet rotating triples; >=1.05 speedup and gap>sumSD; unchanged original source, 3gen fixedpoint, exact results/fuel/traps/resources/partial state.','sourceHead':'fd57ac1099a7c5fa0eb5674256e8db84ffe37ac2','exception':'One-off compiler algorithm authoring, not mechanical refactoring'},indent=2)+'\n')
