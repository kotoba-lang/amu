from pathlib import Path
w=Path('/private/tmp/amu-scatter-zero-20261005');s=Path('/private/tmp/amu-scalar-tree-20261005/fixture-proof.py').read_text();prefix=s[:s.index('leaves=')].replace('amu-scalar-tree-20261005','amu-scatter-zero-20261005');tail=s[s.index('env=dict('):s.index("for name in ['tree0")]
body='''def mapping(name,lo,hi):
 if hi-lo==1:return [('CONST',0,(lo*17)%64)]
 mid=(lo+hi)//2;le=f'{name}_{lo}_{hi}_else';lx=f'{name}_{lo}_{hi}_end'
 return [('LGET',0,1),('CONST',1,mid),('CMP','CC-LT',0),('BRZ',0,le)]+mapping(name,lo,mid)+[('BR',lx),('LABEL',le)]+mapping(name,mid,hi)+[('LABEL',lx)]
for c in [0,1]:
 name=f'sc_map{c}';m.fx(name,1,1,([('FUEL',)] if c else [])+[('LABEL',name+'_root')]+mapping(name,0,64)+[('RET',0)])
 m.fx(f'sc_put{c}',3,3,([('FUEL',)] if c else [])+[('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('RET',0)])
for cf in [0,1]:
 for cm in [0,1]:
  for cw in [0,1]:
   name=f'sc{cf}{cm}{cw}';mf=f'sc_map{cm}';wf=f'sc_put{cw}';loop=name+'_loop';le=name+'_else';lx=name+'_exit'
   rows=([('FUEL',)] if cf else [])+[('LABEL',loop),('LGET',0,2),('LGET',1,3),('CMP','CC-EQ',0),('BRZ',0,le),('LGET',0,1),('BR',lx),('LABEL',le),('LGET',0,1),('CONST',1,16),('LGET',2,2),('CALL',mf,2,1),('BIN','BOP-ADD',1),('CONST',2,0),('CALL',wf,0,3),('LGET',1,2),('CONST',2,1),('BIN','BOP-ADD',1),('LGET',2,3),('LSET',1,0),('LSET',2,1),('LSET',3,2),('FUEL',),('BR',loop),('LABEL',lx),('RET',0)];m.fx(name,3,3,rows)
   # The same proof must work for a callee that follows the loop in SIR order.
   if name=='sc111':m.fx('sc_forward',3,3,[tuple('sc_map_later' if x=='sc_map1' else 'sc_put_later' if x=='sc_put1' else 'sc_forward'+x[len(name):] if isinstance(x,str) and x.startswith(name+'_') else x for x in row) for row in rows])
   for tag,length,k,end,kind in [('full',96,0,64,'ok'),('partial',96,32,64,'ok'),('terminal',96,64,64,'ok'),('tight',80,0,64,'ok'),('negative',96,-1,2,'ok'),('beyond',96,63,65,'ok'),('short',79,16,64,'ok'),('bad',79,0,64,'trap'),('empty',0,0,1,'trap')]:
    caller=f'call_{name}_{tag}';rows=[('FUEL',),('FUEL',),('CONST',0,length),('RT','RT-VECTOR-ALLOC',0,1),('LSET',2,0)]
    for j in range(length):rows += [('LGET',0,2),('CONST',1,j),('LGET',2,1),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3)]
    rows += [('LGET',0,2),('CONST',1,k),('CONST',2,end),('CALL',name,0,3),('CONST',0,0),('LSET',3,0)]
    for j in range(length):rows += [('LGET',0,2),('CONST',1,j),('RT','RT-VECTOR-AT',0,2),('CONST',1,j+1),('BIN','BOP-MUL',0),('LGET',1,3),('BIN','BOP-ADD',0),('LSET',3,0)]
    rows += [('LGET',0,3),('RET',0)];m.fx(caller,1,3,rows);touched={16+((min(max(i,0),63)*17)%64) for i in range(k,end)};budget=2+cf+(end-k)*(1+cm+cw)
    for x in [m.MIN,m.MIN+1,-1,1,m.MAX]:m.run(caller,[x],'trap' if kind=='trap' else m.s64(x*sum(j+1 for j in range(length) if j not in touched)),fuel=budget)
    if tag=='full':
     for fuel in range(1,budget):m.run(caller,[1],'trap',fuel=fuel)
   for k,end in [(0,0),(0,1)]:
    fn=f'handle0_{name}_{end}';m.fx(fn,0,0,[('FUEL',),('FUEL',),('CONST',0,0),('CONST',1,k),('CONST',2,end),('CALL',name,0,3),('RET',0)]);m.run(fn,[],0 if k==end else 'trap',fuel=128)
# Forward dependency definitions intentionally follow sc_forward.
m.fx('sc_map_later',1,1,[('FUEL',),('LABEL','sc_map_later_root')]+mapping('sc_map_later',0,64)+[('RET',0)]);m.fx('sc_put_later',3,3,[('FUEL',),('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('RET',0)])
m.fx('call_sc_forward',0,0,[('FUEL',),('CONST',0,96),('RT','RT-VECTOR-ALLOC',0,1),('CONST',1,0),('CONST',2,64),('CALL','sc_forward',0,3),('CONST',1,16),('RT','RT-VECTOR-AT',0,2),('RET',0)]);m.run('call_sc_forward',[],0,fuel=194)
'''
audit='''for name in ['sc000','sc111','sc101','sc_forward']:
 f=names.index(name)+1;end=fns[f+1];code=blob[fns[f]:end];words=struct.unpack('<'+'I'*(len(code)//4),code);adrs=[i for i,x in enumerate(words) if (x&0x9f000000)==0x10000000 and (x&31)==10];assert len(adrs)==1,(name,adrs);j=adrs[0];v=words[j];delta=(((v>>5)&0x7ffff)<<2)|((v>>29)&3);delta=delta-(1<<21) if delta&(1<<20) else delta;table=j*4+delta;data=struct.unpack('<64q',code[table:table+512]);assert list(data)==[(i*17)%64 for i in range(64)],name;fast=words[:table//4];fallback=words[(table+512)//4:];bl=sum((x&0xfc000000)==0x94000000 for x in fast);blr=sum((x&0xfffffc1f)==0xd63f0000 for x in fast);assert bl==blr==0 and sum(x==0xd65f03c0 for x in fast)==1;assert 0xf86b794d in fast and 0xf82d793f in fast;assert sum((x&0xfc000000)==0x94000000 for x in fallback)==1;audit[name]={'fastBL':bl,'fastBLR':blr,'tableValuesIndependentlyChecked':True,'tableEntries':64,'fallbackBL':1,'bytes':len(code),'fastInstructionBytes':table}
(w/'fixture-proof.json').write_text(json.dumps({'runs':len(m.RUNS),'fixtures':len(m.FIX),'realTestLayoutIdentical':True,'instructionAudit':audit},indent=2)+'\\n');print('PASS scatter table, fast/fallback and forward dependency audits',flush=True)
'''
(w/'fixture-proof.py').write_text(prefix+body+tail+audit)
