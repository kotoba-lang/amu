from pathlib import Path
import subprocess,os,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-scatter-zero-20261005'); base=Path('/private/tmp/amu-scalar-tree-20261005')
loader=w/'kexe-loader';runner=Path('/private/tmp/amu-embench-compare-20261004/runner');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
report={'hypothesis':'proved scatter zero loop','rows':[]};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def compile(seed,src,d,symbols):
 d.mkdir(exist_ok=True,parents=True);out=d/'image.kseed'
 p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--','compile',str(src),'--target','aarch64-macos','--output',str(out)],env=env,capture_output=True,text=True);(d/'compile.log').write_text(p.stdout+p.stderr);assert p.returncode==0,(src,p.stdout,p.stderr)
 offsets={}
 for symbol in symbols:
  p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--','extract-native',str(out),'--symbol',symbol,'--output',str(d/'native.bin')],env=env,capture_output=True,text=True);(d/(symbol+'.extract.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(symbol,p.stderr);offsets[symbol]=int(re.search(r':offset (\d+)',p.stdout).group(1))
 return offsets
def run(d,off,n,fuel=16777216):
 e=dict(env,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
 p=subprocess.run([str(w/'vector-state-loader'),str(d/'native.bin'),str(off),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True)
 if p.returncode==0:
  m=re.search(r':result (-?\d+)',p.stdout);assert m,(n,fuel,p.stdout);value={'result':int(m.group(1))}
 else:
  assert 'KEXE_TRAP' in p.stderr,(n,fuel,p.returncode,p.stdout,p.stderr)
  value=None
 m=re.search(r':fuel \{:initial (\d+) :remaining (\d+)\}',p.stdout);assert m,(n,fuel,p.stdout,p.stderr);consumed=int(m.group(1))-int(m.group(2));state=re.search(r'^DIAG_VECTOR_ITEMS (\d+)(.*)$',p.stderr,re.M);assert state,(n,fuel,p.stderr);items=list(map(int,state.group(2).split()));assert len(items)==int(state.group(1));return {'items':items,'exit':p.returncode,'value':value,'fuelConsumed':consumed,'structuredReport':p.stdout.strip(),'traps':re.findall(r'^KEXE_TRAP.*$',p.stderr,re.M)}



MIN=-(1<<63);MAX=(1<<63)-1
def val(i,mode):
 if mode=='duplicate':return 7
 if mode=='big' and i==0:return 64
 if mode=='negative' and i==0:return -1
 return (i*17)%64

def tree(lo,hi,mode='normal',outer=False):
 if hi-lo==1:return str(val(lo,mode))
 mid=(lo+hi)//2;t=65 if mode=='threshold' and outer else mid
 return f'(if (< i {t}) {tree(lo,mid,mode)} {tree(mid,hi,mode)})'
def index(i,lo=0,hi=64,mode='normal',outer=True):
 if hi-lo==1:return val(lo,mode)
 mid=(lo+hi)//2;t=65 if mode=='threshold' and outer else mid
 return index(i,lo,mid,mode,False) if i<t else index(i,mid,hi,mode,False)
forms=['(defn- put [v :vector-i64 i :i64 x :i64] :vector-i64 (vector-assoc! v i x))','(defn- copy-put [v :vector-i64 i :i64 x :i64] :vector-i64 (vector-assoc v i x))','(defn- init [v :vector-i64 i :i64 x :i64] :vector-i64 (if (= i (vector-count v)) v (init (vector-assoc! v i x) (+ i 1) x)))','(defn- checksum [v :vector-i64 i :i64 a :i64] :i64 (if (= i (vector-count v)) a (checksum v (+ i 1) (+ a (* (+ i 1) (vector-at v i))))))']
for mode in ['normal','duplicate','big','negative','threshold']:forms.append(f'(defn- map-{mode} [i :i64] :i64 {tree(0,64,mode,True)})')
for mode,step,v,writer in [('normal',1,0,'put'),('duplicate',1,0,'put'),('big',1,0,'put'),('negative',1,0,'put'),('threshold',1,0,'put'),('step2',2,0,'put'),('value1',1,1,'put'),('copy',1,0,'copy-put')]:
 mf='normal' if mode in ['step2','value1','copy'] else mode
 forms.append(f'(defn- fill-{mode} [v :vector-i64 k :i64 end :i64] :vector-i64 (if (= k end) v (fill-{mode} ({writer} v (+ 16 (map-{mf} k)) {v}) (+ k {step}) end)))')
cases=[('full',96,0,64,'normal','ok'),('partial',96,32,64,'normal','ok'),('last',96,63,64,'normal','ok'),('terminal',96,64,64,'normal','ok'),('zero-terminal',0,0,0,'normal','ok'),('tight',80,0,64,'normal','ok'),('short-valid-fallback',79,0,63,'normal','ok'),('duplicate',96,0,64,'duplicate','ok'),('big-map-fallback',96,0,64,'big','ok'),('negative-map-fallback',96,0,64,'negative','ok'),('threshold-fallback',96,0,64,'threshold','ok'),('step2',96,0,64,'step2','ok'),('value1',96,0,64,'value1','ok'),('copy',96,0,2,'copy','ok'),('empty',0,0,1,'normal','trap'),('bad-last',79,0,64,'normal','trap'),('negative-start',96,-1,2,'normal','ok'),('beyond64',96,63,65,'normal','ok'),('negative-terminal',96,-1,-1,'normal','ok'),('past-end',96,3,2,'normal','budget')]
symbols=[x[0] for x in cases]
for name,length,k,end,mode,_ in cases:forms.append(f'(defn {name} [x :i64] :i64 (let [v (init (vector-alloc {length}) 0 x) a (fill-{mode} v {k} {end})] (checksum a 0 0)))')
src=w/'probe.kotoba';src.write_text('(ns probe (:export ['+' '.join(symbols)+']))\n'+'\n'.join(forms)+'\n')
a=w/'probe-baseline';b=w/'probe-candidate';oa=compile(base/'seed-4.bin',src,a,symbols);ob=compile(w/'seed-4.bin',src,b,symbols)
values=[MIN,MIN+1,-65537,-1,0,1,65535,MAX]
for symbol,length,k,end,mode,kind in cases:
 for n in values:
  for fuel in [1,2,3,80,96,97,98,99,100,101,102,127,128,160,200,300,16777216] if kind!='budget' else [1,2,3,80,96,97,98,99,100,101,102,127,128,160,200,300,512]:
   x=run(a,oa[symbol],n,fuel);y=run(b,ob[symbol],n,fuel);assert x==y,(symbol,n,fuel,x,y)
   if fuel==16777216:
    if kind=='trap':assert x['exit']!=0 and any('SIGILL' in z for z in x['traps']),(symbol,n,x)
    else:
     arr=[n]*length;allitems=list(arr);i=k;mf='normal' if mode in ['step2','value1','copy'] else mode
     while i!=end:
      j=16+index(i,mode=mf);assert 0<=j<length
      arr=list(arr);arr[j]=1 if mode=='value1' else 0;i+=2 if mode=='step2' else 1
      if mode=='copy':allitems+=arr
     if mode!='copy':allitems=arr
     expected=sum((i+1)*v for i,v in enumerate(arr))&((1<<64)-1);expected=expected-(1<<64) if expected>>63 else expected
     assert x['exit']==0 and x['value']['result']==expected and x['items']==allitems,(symbol,n,x,expected,allitems)
   report['rows'].append({'symbol':symbol,'input':n,'fuel':fuel,**x})
 print('PASS signed scatter source and full/partial state',symbol,flush=True);report['status']='in-progress';(w/'correctness.json').write_text(json.dumps(report,indent=2)+'\n')
report['status']='complete-signed-exact-fuel-trap-resource-and-partial-vector-state-parity';report['sourceSha256']=sha(src);(w/'correctness.json').write_text(json.dumps(report,indent=2)+'\n')
