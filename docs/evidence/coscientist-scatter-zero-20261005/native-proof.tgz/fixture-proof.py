from pathlib import Path
import importlib.util,subprocess,os,re,json,types,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-scatter-zero-20261005');sp=importlib.util.spec_from_file_location('fx',r/'scripts/seed/a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)

m.fx('sc_init',3,4,[('CONST',0,0),('LSET',4,0),('LABEL','sc_init_loop'),('LGET',0,4),('LGET',1,2),('CMP','CC-EQ',0),('BRZ',0,'sc_init_body'),('LGET',0,1),('RET',0),('LABEL','sc_init_body'),('LGET',0,1),('LGET',1,4),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('LGET',0,4),('CONST',1,1),('BIN','BOP-ADD',0),('LSET',4,0),('BR','sc_init_loop')]);m.fx('sc_checksum',1,3,[('CONST',0,0),('LSET',2,0),('LSET',3,0),('LABEL','sc_checksum_loop'),('LGET',0,2),('LGET',1,1),('RT','RT-VECTOR-COUNT',1,1),('CMP','CC-EQ',0),('BRZ',0,'sc_checksum_body'),('LGET',0,3),('RET',0),('LABEL','sc_checksum_body'),('LGET',0,1),('LGET',1,2),('RT','RT-VECTOR-AT',0,2),('LGET',1,2),('CONST',2,1),('BIN','BOP-ADD',1),('BIN','BOP-MUL',0),('LGET',1,3),('BIN','BOP-ADD',0),('LSET',3,0),('LGET',0,2),('CONST',1,1),('BIN','BOP-ADD',0),('LSET',2,0),('BR','sc_checksum_loop')])
def mapping(name,lo,hi):
 if hi-lo==1:return [('CONST',0,(lo*17)%64)]
 mid=(lo+hi)//2;le=f'{name}_{lo}_{hi}_else';lx=f'{name}_{lo}_{hi}_end'
 return [('LGET',0,1),('CONST',1,mid),('CMP','CC-LT',0),('BRZ',0,le)]+mapping(name,lo,mid)+[('BR',lx),('LABEL',le)]+mapping(name,mid,hi)+[('LABEL',lx)]
for c in [0,1]:
 name=f'sc_map{c}';m.fx(name,1,1,([('FUEL',)] if c else [])+[('LABEL',name+'_root')]+mapping(name,0,64)+[('RET',0)])
 m.fx(f'sc_put{c}',3,3,([('FUEL',)] if c else [])+[('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('RET',0)])
for cf in [0,1]:
 for cm in [0,1]:
  for cw in [0,1]:
   name=f'sc{cf}{cm}{cw}';mf=f'sc_map{cm}';wf=f'sc_put{cw}';loop=name+'_loop';le=name+'_else';lx=name+'_exit'
   rows=([('FUEL',)] if cf else [])+[('LABEL',loop),('LGET',0,2),('LGET',1,3),('CMP','CC-EQ',0),('BRZ',0,le),('LGET',0,1),('BR',lx),('LABEL',le),('LGET',0,1),('CONST',1,16),('LGET',2,2),('CALL',mf,2,1),('BIN','BOP-ADD',1),('CONST',2,0),('CALL',wf,0,3),('LGET',1,2),('CONST',2,1),('BIN','BOP-ADD',1),('LGET',2,3),('LSET',1,0),('LSET',2,1),('LSET',3,2),('FUEL',),('BR',loop),('LABEL',lx),('RET',0)];m.fx(name,3,3,rows)
   # The same proof must work for a callee that follows the loop in SIR order.
   if name=='sc111':m.fx('sc_forward',3,3,[tuple('sc_map_later' if x=='sc_map1' else 'sc_put_later' if x=='sc_put1' else 'sc_forward'+x[len(name):] if isinstance(x,str) and x.startswith(name+'_') else x for x in row) for row in rows])
   for tag,length,k,end,kind in [('full',96,0,64,'ok'),('partial',96,32,64,'ok'),('terminal',96,64,64,'ok'),('tight',80,0,64,'ok'),('negative',96,-1,2,'ok'),('beyond',96,63,65,'ok'),('short',79,16,64,'ok'),('bad',79,0,64,'trap'),('empty',0,0,1,'trap')]:
    caller=f'call_{name}_{tag}';rows=[('FUEL',),('FUEL',),('CONST',0,length),('RT','RT-VECTOR-ALLOC',0,1),('LSET',2,0)]
    rows += [('LGET',0,2),('CONST',1,length),('LGET',2,1),('CALL','sc_init',0,3)]
    rows += [('LGET',0,2),('CONST',1,k),('CONST',2,end),('CALL',name,0,3),('CONST',0,0),('LSET',3,0)]
    rows += [('LGET',0,2),('CALL','sc_checksum',0,1),('RET',0)];m.fx(caller,1,3,rows);touched={16+((min(max(i,0),63)*17)%64) for i in range(k,end)};budget=2+cf+(end-k)*(1+cm+cw)
    for x in [m.MIN,m.MIN+1,-1,1,m.MAX]:m.run(caller,[x],'trap' if kind=='trap' else m.s64(x*sum(j+1 for j in range(length) if j not in touched)),fuel=budget)
    if tag=='full':
     for fuel in range(1,budget):m.run(caller,[1],'trap',fuel=fuel)
   for k,end in [(0,0),(0,1)]:
    fn=f'handle0_{name}_{end}';m.fx(fn,0,0,[('FUEL',),('FUEL',),('CONST',0,0),('CONST',1,k),('CONST',2,end),('CALL',name,0,3),('RET',0)]);m.run(fn,[],0 if k==end else 'trap',fuel=128)
# Forward dependency definitions intentionally follow sc_forward.
m.fx('sc_map_later',1,1,[('FUEL',),('LABEL','sc_map_later_root')]+mapping('sc_map_later',0,64)+[('RET',0)]);m.fx('sc_put_later',3,3,[('FUEL',),('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('RET',0)])
m.fx('call_sc_forward',0,0,[('FUEL',),('CONST',0,96),('RT','RT-VECTOR-ALLOC',0,1),('CONST',1,0),('CONST',2,64),('CALL','sc_forward',0,3),('CONST',1,16),('RT','RT-VECTOR-AT',0,2),('RET',0)]);m.run('call_sc_forward',[],0,fuel=194)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800');loader=str(w/'kexe-loader');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];chunks=[]
for real in [False,True]:
 prefix='fixture-real' if real else 'fixture-test';src=w/(prefix+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real))
 for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(prefix+'.kseed'))]),('extract',['extract-native',str(w/(prefix+'.kseed')),'--symbol','main','--output',str(w/(prefix+'.bin'))])]:
  p=subprocess.run([loader,str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(prefix+'-'+label+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(label,p.stdout,p.stderr)
  if label=='extract':off=re.search(r':offset (\d+)',p.stdout).group(1)
 p=subprocess.run([loader,str(w/(prefix+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(prefix+'.stdout')).write_text(p.stdout);assert p.returncode==0,p.stderr;chunks.append(p.stdout)
assert m.blob_from(chunks[0])[0].rstrip(b'\0')==m.blob_from(chunks[1])[0].rstrip(b'\0') and m.blob_from(chunks[0])[1]==m.blob_from(chunks[1])[1]
d=w/'fixture-run/unit/41-a64gen';d.mkdir(parents=True,exist_ok=True);(d/'stdout').write_text(chunks[1]);os.environ['SEED_BUILD']=str(w/'fixture-run');original=m.subprocess.run

def run(args,**kw):
 if args[:2]==['zsh',m.R+'/scripts/seed/unit.sh']:return types.SimpleNamespace(returncode=0,stdout='native experimental fixture emitter already verified; byte golden untouched',stderr='')
 return original(args,**kw)
m.subprocess.run=run;assert m.runs(False)==0
blob,fns=m.blob_from(chunks[1]);names=[f[0] for f in m.FIX];audit={}
for name in ['sc000','sc111','sc101','sc_forward']:
 f=names.index(name)+1;end=fns[f+1];code=blob[fns[f]:end];words=struct.unpack('<'+'I'*(len(code)//4),code);adrs=[i for i,x in enumerate(words) if (x&0x9f000000)==0x10000000 and (x&31)==10];assert len(adrs)==1,(name,adrs);j=adrs[0];v=words[j];delta=(((v>>5)&0x7ffff)<<2)|((v>>29)&3);delta=delta-(1<<21) if delta&(1<<20) else delta;table=j*4+delta;data=struct.unpack('<64q',code[table:table+512]);assert list(data)==[(i*17)%64 for i in range(64)],name;fast=words[:table//4];fallback=words[(table+512)//4:];bl=sum((x&0xfc000000)==0x94000000 for x in fast);blr=sum((x&0xfffffc1f)==0xd63f0000 for x in fast);assert bl==blr==0 and sum(x==0xd65f03c0 for x in fast)==1;assert 0xf86b794d in fast and 0xf82d793f in fast;assert sum((x&0xfc000000)==0x94000000 for x in fallback)==1;
 if name in ['sc111','sc_forward']:
  lookup=fast.index(0xf86b794d);load=fast.index(0xf94004e8);commit=fast.index(0xf90004e8);write=fast.index(0xf82d793f);assert load<lookup<commit<write,(name,load,lookup,commit,write)
 audit[name]={'fastBL':bl,'fastBLR':blr,'tableValuesIndependentlyChecked':True,'tableEntries':64,'fallbackBL':1,'bytes':len(code),'fastInstructionBytes':table}
(w/'fixture-proof.json').write_text(json.dumps({'runs':len(m.RUNS),'fixtures':len(m.FIX),'realTestLayoutIdentical':True,'instructionAudit':audit},indent=2)+'\n');print('PASS scatter table, fast/fallback and forward dependency audits',flush=True)
