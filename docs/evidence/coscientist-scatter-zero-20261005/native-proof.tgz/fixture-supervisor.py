from pathlib import Path
import subprocess,os,json,re
w=Path('/private/tmp/amu-scatter-zero-20261005');scope={};s=(w/'fixture-proof.py').read_text();exec(s[:s.index('env=dict(')],scope);m=scope['m'];r=scope['r'];prefix='fixture-baseline-real';src=w/(prefix+'.kotoba');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba','seed/41-a64gen.kotoba','seed/42-layout.kotoba'];src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+m.kotoba(True));loader=str(w/'kexe-loader');seed='/private/tmp/amu-scalar-tree-20261005/seed-4.bin';env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800')
for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(prefix+'.kseed'))]),('extract',['extract-native',str(w/(prefix+'.kseed')),'--symbol','main','--output',str(w/(prefix+'.bin'))])]:
 p=subprocess.run([loader,seed,'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(prefix+'-'+stage+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(stage,p.stdout,p.stderr)
 if stage=='extract':off=re.search(r':offset (\d+)',p.stdout).group(1)
p=subprocess.run([loader,str(w/(prefix+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(prefix+'.stdout')).write_text(p.stdout);assert p.returncode==0,p.stderr
base,fa=m.blob_from(p.stdout);cand,fb=m.blob_from((w/'fixture-real.stdout').read_text());(w/'fixture-baseline-code.bin').write_bytes(base);(w/'fixture-candidate-code.bin').write_bytes(cand);names=[f[0] for f in m.FIX];rows=[]
def run(path,off,args,budget):
 e=dict(os.environ,KEXE_FUEL=str(budget),KEXE_STRUCTURED_REPORT='1')
 p=subprocess.run([str(w/'vector-state-loader'),str(path),str(off),str(len(args)),'aarch64','-',*map(str,args)],env=e,capture_output=True,text=True);q=re.search(r':fuel \{:initial (\d+) :remaining (\d+)\}',p.stdout);assert q,(path,args,budget,p.stdout,p.stderr)
 if p.returncode:assert 'KEXE_TRAP' in p.stderr,(path,p.stderr)
 state=re.search(r'^DIAG_VECTOR_ITEMS (\d+)(.*)$',p.stderr,re.M);assert state,(args,budget,p.stderr);items=list(map(int,state.group(2).split()));assert len(items)==int(state.group(1));return {'items':items,'exit':p.returncode,'report':p.stdout.strip(),'fuelConsumed':int(q.group(1))-int(q.group(2)),'traps':re.findall(r'^KEXE_TRAP.*$',p.stderr,re.M)}
for cf in [0,1]:
 for cm in [0,1]:
  for cw in [0,1]:
   name=f'sc{cf}{cm}{cw}'
   targets=[(f'call_{name}_{tag}',[m.MIN+1]) for tag in ['full','partial','terminal','tight','negative','beyond','short','bad','empty']]+[(f'handle0_{name}_{end}',[]) for end in [0,1]]
   for fn,args in targets:
    f=names.index(fn)+1;budgets=[*range(1,197),16777216] if fn.endswith('_full') else [1,2,3,4,5,6,7,8,16,32,33,64,65,128,129,192,193,194,195,196,16777216]
    for budget in budgets:
     a=run(w/'fixture-baseline-code.bin',fa[f],args,budget);b=run(w/'fixture-candidate-code.bin',fb[f],args,budget);assert a==b,(fn,args,budget,a,b);rows.append({'function':fn,'args':args,'fuel':budget,**a})
   print('PASS exact supervisor/partial arena',name,flush=True)
(w/'fixture-supervisor.json').write_text(json.dumps({'status':'complete-handwritten-baseline-candidate-exact-supervisor-and-partial-state-parity','comparisons':len(rows),'rows':rows},indent=2)+'\n')
