/* BOOTSTRAP-TOOL: unchanged original codewords/frame + placement snapshots.
 * Copyright 2014-2019 Embecosm/Bristol, qrduino contributors; GPL-3.0-or-later. */
#include <stdint.h>
#include <limits.h>
#include "beebsc.h"
#include "../upstream/src/qrduino/qrencode.c"
static unsigned char heap[8192] __attribute__((aligned));
static unsigned char images[353][100],positions[353][4];
static const char *payloads[]={"http://www.mageec.com","AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","","0123456789012345678901234567890123456789"};
static void snapshot(int n,int x,int y,int dy,int hv){memcpy(images[n],qrframe,100);positions[n][0]=x;positions[n][1]=y;positions[n][2]=dy;positions[n][3]=hv;}
static int prepare(int c){memset(heap,0,sizeof(heap));init_heap_beebs(heap,8192);initeccsize(1,22);memcpy(strinbuf,payloads[c],strlen(payloads[c])+1);initframe();stringtoqr();return VERSION==2&&WD==25&&WDB==4;}
static void observed(void){int bits=0;

  int i;
  unsigned char d, j;
  unsigned char x, y, ffdecy, ffgohv;

  memcpy_P (qrframe, framebase, WDB * WD);
  x = y = WD - 1;
  ffdecy = 1;			// up, minus
  ffgohv = 1;
  snapshot(0,x,y,ffdecy,ffgohv);

  /* inteleaved data and ecc codes */
  for (i = 0; i < ((datablkw + eccblkwid) * (neccblk1 + neccblk2) + neccblk2);
       i++)
    {
      d = strinbuf[i];
      for (j = 0; j < 8; j++, d <<= 1)
	{
	  if (0x80 & d)
	    SETQRBIT (x, y);
	  do
	    {			// find next fill position
	      if (ffgohv)
		x--;
	      else
		{
		  x++;
		  if (ffdecy)
		    {
		      if (y != 0)
			y--;
		      else
			{
			  x -= 2;
			  ffdecy = !ffdecy;
			  if (x == 6)
			    {
			      x--;
			      y = 9;
			    }
			}
		    }
		  else
		    {
		      if (y != WD - 1)
			y++;
		      else
			{
			  x -= 2;
			  ffdecy = !ffdecy;
			  if (x == 6)
			    {
			      x--;
			      y -= 8;
			    }
			}
		    }
		}
	      ffgohv = !ffgohv;
	    }
	  while (ismasked (x, y));
  snapshot(++bits,x,y,ffdecy,ffgohv);
	}
    }

}
#define EXTRA int64_t x1,int64_t x2,int64_t x3,int64_t x4,int64_t x5,int64_t x6,int64_t ctx
int64_t observe(int64_t encoded,EXTRA){int c=encoded/1048576,code=encoded%1048576,n=code/2048,cell=code%2048;
 if(encoded<0||c>3||n>352||!prepare(c))return INT64_MIN;observed();
 if(cell>=768&&cell<868)return images[n][cell-768];if(cell>=1760&&cell<1764)return positions[n][cell-1760];
 if(cell<44)return strinbuf[cell];if(cell>=1536&&cell<1636)return framebase[cell-1536];if(cell>=1664&&cell<1705)return framask[cell-1664];return INT64_MIN;}
int64_t oracle_selfcheck(int64_t c,EXTRA){if(c<0||c>3||!prepare(c))return 0;observed();unsigned char saved[100];memcpy(saved,images[352],100);
 if(!prepare(c))return 0;fillframe();return memcmp(saved,qrframe,100)==0&&check_heap_beebs(heap);}
