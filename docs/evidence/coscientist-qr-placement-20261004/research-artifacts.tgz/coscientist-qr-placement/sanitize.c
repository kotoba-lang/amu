#include "c-bridge.c"
#include <stdio.h>
int main(void){int reads=0;for(int c=0;c<4;c++){
 if(oracle_selfcheck(c,0,0,0,0,0,0,0)!=1)return 1;
 for(int n=0;n<=352;n++)for(int cell=1760;cell<1764;cell++){if(observe(c*1048576+n*2048+cell,0,0,0,0,0,0,0)==INT64_MIN)return 2;reads++;}
 for(int cell=768;cell<868;cell++){if(observe(c*1048576+352*2048+cell,0,0,0,0,0,0,0)==INT64_MIN)return 3;reads++;}
}printf("PASS 4 unchanged fillframe selfchecks, %d initialized placement reads\n",reads);return 0;}
