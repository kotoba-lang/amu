from pathlib import Path
import subprocess,os,re,json
w=Path('/private/tmp/amu-loop-descriptor-20261006');b=Path('/private/tmp/amu-affine-reader-20261005');load=lambda p:json.loads(p.read_text());pc=load(w/'ports-correctness.json');pb=load(b/'ports-correctness.json');rows=[]
for e in pc['entries']:
 name=e['workload'];old=next(x for x in pb['entries'] if x['workload']==name);ns=[x['n'] for x in e['runs'] if x['n'] in [0,1,2]];cases=[(n,16777216) for n in ns]+[(1,f) for f in [1,2,3,4,31,32,33,257]]
 for n,fuel in cases:
  obs={}
  for label,root,off in [('baseline',b,old['offset']),('candidate',w,e['offset'])]:
   env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');env.pop('KEXE_COMMAND',None);q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(root/'ports-2'/name/'native.bin'),str(off),'1','aarch64','-',str(n)],env=env,capture_output=True,text=True);assert ':fuel ' in q.stdout,(name,n,fuel,label,q.stdout,q.stderr);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
   if fuel==16777216:
    expect=next(x for x in e['runs'] if x['n']==n);assert q.returncode==0 and re.search(r':result '+str(expect['result'])+r'(?:\s|})',q.stdout),(name,n,label,q.stdout,q.stderr[-400:]);assert f":remaining {fuel-expect['fuelConsumed']}" in q.stdout,(name,n,label,q.stdout)
  assert obs['baseline']==obs['candidate'],(name,n,fuel,obs);rows.append({'workload':name,'n':n,'fuel':fuel,**obs})
 print('PASS original full-state and partial-fuel',name,flush=True)
(w/'ports-state.json').write_text(json.dumps({'status':'complete-original19-full-and-partial-native-supervisor-state-parity','comparisons':len(rows),'workloads':19,'diagnosticContextClobberingAllocator':True,'runs':rows},indent=2)+'\n');print('PASS',len(rows),'original19 full-state comparisons',flush=True)
