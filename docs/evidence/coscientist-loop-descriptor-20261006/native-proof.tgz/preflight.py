from pathlib import Path
import json,hashlib,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-loop-descriptor-20261006');b=Path('/private/tmp/amu-affine-reader-20261005');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();g=load(w/'generations.json');assert len(g)==4 and len(set(x['sha256'] for x in g[1:]))==1;assert all(sha(w/('seed-'+str(x['generation'])+'.bin'))==x['sha256'] for x in g)
counts={};pins={}
for name,key,n in [('loop-state-proof.json','comparisons',2304),('leaf-proof.json','comparisons',900),('import-proof.json','comparisons',72),('resource-proof.json','comparisons',12),('effect-proof.json','comparisons',24),('regression-proof.json','runs',4196)]:
 s=load(w/name);assert s[key]==n;rows=s['observations'] if name=='regression-proof.json' else s['runs'];assert len(rows)==n;counts[name]=n;pins[name]=sha(w/name)
 if name=='loop-state-proof.json':assert len({(x['caller'],x['first'],x['second'],x['fuel']) for x in rows})==n
 if name=='leaf-proof.json':assert len({(x['leaf'],x['handle'],x['index'],x['fuel']) for x in rows})==n
 if name=='regression-proof.json':assert len({x['index'] for x in rows})==n
 for row in rows:
  if name in ['loop-state-proof.json','resource-proof.json']:assert row['baseline-loop']==row['candidate-loop']
  if name=='leaf-proof.json':assert row['baseline-leaf']==row['candidate-leaf']
  if name=='import-proof.json':assert row['baseline-open']==row['candidate-open']
  if name=='effect-proof.json':assert row['baseline-effect']==row['candidate-effect']
pa=load(w/'ports-correctness.json');pb=load(b/'ports-correctness.json');assert len(pa['entries'])==19;ch=load(w/'code-change.json');changed=[x['workload'] for x in ch if x['changed']];assert len(changed)==17
for x in pa['entries']:
 y=next(z for z in pb['entries'] if z['workload']==x['workload']);assert x['runs']==y['runs'] and x['fuelTrapReturncode']==y['fuelTrapReturncode'] and x['sourceSha256']==y['sourceSha256'];assert sha(w/'ports-2'/x['workload']/'native.bin')==x['nativeSha256']
ob=load(w/'observer-byte-audit.json');assert len(ob['entries'])==19 and all(x['diagnosticTargetByteIdentical'] for x in ob['entries']);assert (r/'seed/41-a64gen.kotoba').read_bytes()==(w/'baseline-41-a64gen.kotoba').read_bytes()
s={'status':'complete-native-semantic-proof-before-timing','fixedpointGenerations':[2,3,4],'firstGenerationDiffers':True,'originalWorkloads':19,'changedGuests':changed,'freshNativeCounts':counts,'proofPins':pins,'fullSupervisorComparisons':3312,'productUnchanged':True,'mayPromote':False,'productGatesAndIntegratedProofStillRequired':True,'officialEmbenchScore':False};assert sum(v for k,v in counts.items() if k!='regression-proof.json')==3312;(w/'preflight-audit.json').write_text(json.dumps(s,indent=2)+'\n');p=w/'timing-package';p.mkdir();hyp=load(w/'hypothesis.json')
for name in changed:
 d=p/name;c=d/'candidate';c.mkdir(parents=True);x=next(z for z in pa['entries'] if z['workload']==name);y=next(z for z in pb['entries'] if z['workload']==name);shutil.copyfile(w/'ports-2'/name/'native.bin',c/'native.bin');shutil.copyfile(b/'ports-2'/name/'native.bin',d/'baseline-native.bin');mf={'workload':name,'sourceSha256':x['sourceSha256'],'baselineSourceSha256':y['sourceSha256'],'nativeSha256':x['nativeSha256'],'offset':x['offset'],'baselineNativeSha256':y['nativeSha256'],'baselineOffset':y['offset'],'compilerGenerationSha256':{str(x['generation']):x['sha256'] for x in g[1:]},'hypothesis':hyp['hypothesis'],'sourceHead':hyp['sourceCommit']};(c/'manifest.json').write_text(json.dumps(mf,indent=2)+'\n')
for src,name in [(b/'ports-correctness.json','product-proof.json'),(w/'ports-correctness.json','candidate-proof.json'),(w/'preflight-audit.json','preflight.json'),(w/'generations.json','generations.json'),(w/'observer-byte-audit.json','observer-byte-audit.json'),(w/'code-change.json','code-change.json')]:shutil.copyfile(src,p/name)
for name in pins:shutil.copyfile(w/name,p/name)
for name in ['comparison-matrix.json','paired-timing-spec.json']:shutil.copyfile(r/'bench/embench'/name,p/name)
shutil.copyfile('/private/tmp/amu-context-call-20261005/measure-native-candidate-v2.py',p/'measure-native-candidate-v2.py');print('PASS3312fullstate+4196regression proof sealed; all17 changed guests require fresh timing')
