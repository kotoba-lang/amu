from pathlib import Path
import os,subprocess,re,json,struct
w=Path('/private/tmp/amu-loop-descriptor-20261006');scope={};s=(w/'loop-proof.py').read_text();exec(s[:s.index('env=dict(')],scope);m=scope['m'];r=scope['r'];cs=[]
for ns in [3,4,5,6,7]:
 leaf=f'lc_raw_leaf_{ns}';body=[('FUEL',),('LABEL',leaf+'_loop'),('LGET',0,2),('CONST',1,2),('CMP','CC-LT',0),('BRZ',0,leaf+'_end'),('LGET',0,1),('LGET',1,2),('RT','RT-VECTOR-AT',0,2),('LGET',1,3),('BIN','BOP-ADD',0),('LSET',3,0),('LGET',0,2),('CONST',1,1),('BIN','BOP-ADD',0),('LSET',2,0),('FUEL',),('BR',leaf+'_loop'),('LABEL',leaf+'_end'),('LGET',0,3)]
 for slot in range(4,ns+1):body += [('LGET',1,slot),('BIN','BOP-ADD',0)]
 body += [('RET',0)];m.fx(leaf,ns,ns,body);name=f'lc_raw_caller_{ns}';m.fx(name,3,3,[('FUEL',)]+[('CONST',j,11-3*j) for j in range(8)]+[('VEC',0,8),('CONST',0,99),('VEC',0,1),('LGET',0,1),('LGET',1,2),('LGET',2,3)]+[('CONST',j,70+j) for j in range(3,ns)]+[('CALL',leaf,0,ns),('RET',0)]);cs.append({'leaf':leaf,'caller':name,'slots':ns})
ids={x[0]:j+1 for j,x in enumerate(m.FIX)};env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];images={};audit=[]
for label,gen in [('baseline-leaf','baseline-41-a64gen.kotoba'),('candidate-leaf','41-a64gen-prototype.kotoba')]:
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/gen).read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+scope['text'](True))
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-400:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0;(w/(label+'.stdout')).write_text(q.stdout);blob,fc=m.blob_from(q.stdout);bp=w/(label+'-fixture.bin');bp.write_bytes(blob);images[label]=(bp,fc)
 if label=='candidate-leaf':
  for c in cs:
   f=ids[c['leaf']];end=fc[f+1];words=struct.unpack('<'+'I'*((end-fc[f])//4),blob[fc[f]:end]);hits=words.count(0xb4000065);assert hits==int(c['slots']==3),(c,hits);audit.append({**c,'cacheGuardSites':hits})
rows=[];initial=[11-3*j for j in range(8)]+[99]
for c in cs:
 for handle in [0,1,2,3,m.MIN,m.MAX]:
  for index in [m.MIN,-1,0,1,2,m.MAX]:
   for fuel in [1,2,3,4,16777216]:
    published=fuel-1;remaining=published;answer=None;acc=37;failed=False
    if remaining<1:remaining=0;failed=True
    else:
     private=remaining-1;idx=index
     while idx<2:
      n=8 if handle==1 else 1 if handle==2 else 0;off=0 if handle==1 else 8
      if not 0<=idx<n:failed=True;break
      acc=m.s64(acc+initial[off+idx]);idx+=1
      if private<1:remaining=0;failed=True;break
      private-=1
     if not failed:remaining=private;answer=m.s64(acc+sum(70+j for j in range(3,c['slots'])))
    obs={}
    for label,(bp,fc) in images.items():
     e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(bp),str(fc[ids[c['caller']]]),'3','aarch64','-',str(handle),str(index),'37'],env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
     if answer is None:assert q.returncode!=0,(c,handle,index,fuel,q.stdout)
     else:assert q.returncode==0 and re.search(r':result '+str(answer)+r'(?:\s|})',q.stdout),(c,handle,index,fuel,answer,q.stdout)
     assert f':remaining {remaining}' in q.stdout and ':vectors {:capacity 4096 :used 2}' in q.stdout and ':vector-items {:capacity 65536 :used 9}' in q.stdout,(c,handle,index,fuel,remaining,q.stdout)
     assert obs[label]['items']==['DIAG_VECTOR_ITEMS 9 '+' '.join(map(str,initial))]
    assert obs['baseline-leaf']==obs['candidate-leaf'],(c,handle,index,fuel,obs);rows.append({**c,'handle':handle,'index':index,'fuel':fuel,'expect':answer,'expectRemaining':remaining,**obs})
 print('PASS native leaf ownership',c['slots'],flush=True)
(w/'leaf-proof.json').write_text(json.dumps({'status':'complete-native-free-register-ownership-and-leaf-fuel-hand-proof','comparisons':len(rows),'instructionAudit':audit,'runs':rows},indent=2)+'\n');print('PASS',len(rows),'rawhandle/leaf ownership comparisons',flush=True)
