from pathlib import Path
import json,shutil,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-loop-descriptor-20261006');b=Path('/private/tmp/amu-affine-reader-20261005');g=(r/'seed/41-a64gen.kotoba').read_text();(w/'baseline-41-a64gen.kotoba').write_text(g)
helpers=''';; Experimental loop cache: x3=length, x4=data base, x5=positive key;0=invalid.
;; Dynamic handle checks cover joins/reassignment. Unknown returning calls clear.
;; x3..5 are free only in nonleaf functions or <=3-local leaves.
(defn- gn-vloop-scan [M :vector-i64 j :i64 reads :i64 back :bool work :i64] :bool
 (if (or (<= work 0) (>= j (vector-at M MM-SIR-N))) false
  (let [op (gn-op M j) a (gn-sir M j IF-A) b (gn-sir M j IF-B) c (gn-sir M j IF-C)
        target (if (= op OP-BR) a (if (or (= op OP-BRZ) (= op OP-BRNZ)) b 0))
        p (if (> target 0) (gn-lpos M target) 0)
        rd (or (and (= op OP-RT) (= a RT-VECTOR-AT) (= c 2) (<= b 5))
               (and (= op OP-CALL) (or (> (gn-affine-reader M j a c) 0)
                  (= (bit-and (gn-call-wrapper M j a b c) 255) RT-VECTOR-AT))))]
   (if (= op OP-END) (and (> reads 0) back)
    (gn-vloop-scan M (inc j) (+ reads (if rd 1 0))
      (or back (and (> p 0) (< p j))) (dec work))))))
(defn- gn-vmode [M :vector-i64 i :i64] :vector-i64
 (gn-gs M 8 (if (and (or (= (gn-g M gn-f-leaf) 0) (<= (gn-g M gn-f-ns) 3))
                     (gn-vloop-scan M (inc i) 0 false 8192)) 1 0)))
(defn- gn-vclear [M :vector-i64] :vector-i64
 (if (= (gn-g M 8) 1) (gn-mov-imm M 5 0) M))
;; Hit requires nonzero key from a prior original handle check. Miss captures
;; descriptor at the original access, before its index check. No trap/charge
;; speculation. RV/RI/D cannot collide with x3..5 under the register proof.
(defn- gn-vread [M :vector-i64 rv :i64 ri :i64 d :i64] :vector-i64
 (if (= (gn-g M 8) 0)
  (-> M (gn-hchk rv 312 320) (gn-vidx ri) (gn-emit (gn-e-ldrr d 16 17 1)))
  (-> M
   (gn-emit (enc-cbz 5 3)) (gn-emit (enc-cmp-r rv 5)) (gn-emit (enc-bcond (enc-cond-eq) 13))
   (gn-mov 5 rv) (gn-hchk 5 312 320)
   (gn-emit (enc-ldp 17 3 16 0)) (gn-emit (enc-ldr 4 7 328)) (gn-emit (gn-e-addsl 4 4 17 3))
   (gn-emit (enc-cmp-r ri 3)) (gn-emit (enc-bcond (enc-cond-lo) 2)) (gn-emit (gn-e-udf))
   (gn-emit (gn-e-ldrr d 4 ri 1)))))
'''
pos=g.index(';; ---- register assignment');g=g[:pos]+helpers+'\n'+g[pos:]
replacements=[('M2 (gn-assign M1)','M2 (gn-vmode (gn-assign M1) i)'),('(gn-gs gn-f-h 0) (gn-tree-entry f)','(gn-gs gn-f-h 0) (gn-vclear) (gn-tree-entry f)'),('(gn-hchk 0 312 320) (gn-vidx 1) (gn-emit (gn-e-ldrr 0 16 17 1))','(gn-vread 0 1 0)'),('(gn-hchk rv 312 320) (gn-vidx ri) (gn-emit (gn-e-ldrr d 16 17 1)) (gn-fin t s d)','(gn-vread rv ri d) (gn-fin t s d)'),('(gn-emit (enc-bl 0))\n      (gn-gs gn-f-ctx','(gn-emit (enc-bl 0))\n      (gn-vclear)\n      (gn-gs gn-f-ctx')]
for a,z in replacements:assert g.count(a)==1,a;g=g.replace(a,z,1)
assert g.count('(gn-emit (enc-blr 16))')==3
g=g.replace('(gn-emit (enc-blr 16))','(gn-emit (enc-blr 16)) (gn-vclear)')
(w/'41-a64gen-prototype.kotoba').write_text(g)
parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in parts))
for ext in ['bin','offset']:shutil.copyfile(b/('seed-4.'+ext),w/('seed-0.'+ext))
shutil.copyfile(b/'kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for n in ['build.py','check-ports.py']:(w/n).write_text(Path('/private/tmp/amu-vector-validity-20261006',n).read_text().replace('amu-vector-validity-20261006','amu-loop-descriptor-20261006'))
(w/'hypothesis.json').write_text(json.dumps({'status':'registered-before-native-build-and-timing','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'hypothesis':'Loop-bearing functions can keep checked vector length/data base in proven free x3/x4 and positive key x5. Each access dynamically validates nonzero/same key, otherwise original handle check. Retain every unsigned index trap and exact fuel boundary. Unknown actual runtime/guest calls clear key after return.','admission':'Function has inlined vector read and actual backward branch within bounded8192 SIR scan; only nonleaf or <=3-local leaf so x3..5 cannot be locals. Ordinary/affine reader, no workload names.','regionChange':'Caller scratch registers with exact emitted-call invalidation rather than displacing10rankedlocals. Dynamic equality replaces unchanged-local assumption.','requiredProof':'All19 originals; native fixedpoint; hand loop/branch/keyswitch/invalidhandle/index/fuel/writes/importclobbers/resourcepartial state. Freshquiet30rotatingtriples everychangedguest,1.05+sumSD, thenfullgates/integrated3gen/corpus beforepromotion.','exception':'One-off new Kotoba compiler algorithm/diagnostic authoring; no mechanical AST rule. Product unchanged.','authoringCorrection':'Initial creator wrongly expected one BLR16 site. Source has runtime, indirectguest and ASCII slowpath; all3 invalidate, with slowpath DONE at same old instruction position before inserted clear.'},indent=2)+'\n');print('registered dynamic-key loop descriptor candidate')
