from pathlib import Path
import os,subprocess,re,json,hashlib,importlib.util,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-loop-descriptor-20261006');sp=importlib.util.spec_from_file_location('m',w/'baseline-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);first=len(m.FIX)+1;cases=[];leaves=[]
for k in [1,2,-1,m.MIN]:
 for ch in [0,1]:
  leaf=f'lc_leaf_{k}_{ch}';leaves.append(leaf);m.fx(leaf,2,2,([('FUEL',)] if ch else [])+[('LABEL',leaf+'_entry'),('LGET',0,1),('LGET',1,2),('CONST',2,k),('BIN','BOP-MUL',1),('RT','RT-VECTOR-AT',0,2),('RET',0)])
# Leaves with7 params force actual caller scratch x3..5 to1,0,1; no allocator noise.
m.fx('lc_clobber',7,7,[('FUEL',),('CONST',0,77),('RET',0)])
m.fx('lc_alloc',0,0,[('FUEL',),('CONST',0,1),('RT','RT-VECTOR-ALLOC',0,1),('CONST',0,77),('RET',0)])
variants=[(1,1,t,mode) for t in [0,7] for mode in ['none','write','switch','switch-loop','selfassign','reassign','call','alloc','conj-old','conj-new','skip','invalid-skip']]+[(k,ch,t,'none') for k in [2,-1,m.MIN] for ch in [0,1] for t in [0,7]]
for k,ch,t,mode in variants:
 name=f'lc_case_{len(cases)}';leaf=f'lc_leaf_{k}_{ch}';body=[('FUEL',)]+[('CONST',j,11-3*j) for j in range(8)]+[('VEC',0,8),('LSET',4,0),('CONST',0,99),('VEC',0,1),('LSET',5,0),('CONST',0,2),('LSET',7,0),('CONST',0,0),('LSET',8,0)]
 if mode=='invalid-skip':body += [('CONST',0,0),('LSET',4,0)]
 body += [('LABEL',name+'_loop'),('LGET',0,7),('BRZ',0,name+'_end')]+[('CONST',j,100+j) for j in range(t)]
 if mode in ['skip','invalid-skip']:body += [('LGET',t,1),('BRZ',t,name+'_skip')]
 body += [('LGET',t,4),('LGET',t+1,1),('CALL',leaf,t,2),('LSET',6,t)]
 if mode in ['skip','invalid-skip']:body += [('BR',name+'_join'),('LABEL',name+'_skip'),('CONST',t,17),('LSET',6,t),('LABEL',name+'_join')]
 if mode=='write':body += [('LGET',t,4),('CONST',t+1,0),('CONST',t+2,77),('RT','RT-VECTOR-ASSOC-IN-PLACE',t,3)]
 if mode=='call':body += [('LGET',t,4)]+[('CONST',t+j,v) for j,v in enumerate([99,98,1,0,1,66],1)]+[('CALL','lc_clobber',t,7)]
 if mode=='alloc':body += [('CALL','lc_alloc',t,0)]
 if mode.startswith('conj'):body += [('LGET',t,4),('CONST',t+1,99),('RT','RT-VECTOR-CONJ',t,2),('LSET',4 if mode=='conj-new' else 9,t)]
 if mode=='selfassign':body += [('LGET',t,4),('LSET',4,t)]
 if mode=='reassign':body += [('CONST',t,0),('LSET',4,t)]
 body += [ ('LGET',t,5 if mode=='switch' else 4),('LGET',t+1,2),('CALL',leaf,t,2)]+[('BIN','BOP-ADD',j) for j in range(t-1,-1,-1)]+[('LGET',1,6),('BIN','BOP-ADD',0),('LGET',1,8),('BIN','BOP-ADD',0),('LSET',8,0)]
 if mode=='switch-loop':body += [('LGET',0,5),('LSET',4,0)]
 body += [('LGET',0,7),('CONST',1,1),('BIN','BOP-SUB',0),('LSET',7,0),('FUEL',),('BR',name+'_loop'),('LABEL',name+'_end'),('LGET',0,8),('LGET',1,3),('BIN','BOP-ADD',0),('RET',0)]
 m.fx(name,3,9,body);cases.append({'name':name,'k':k,'charge':ch,'t':t,'mode':mode})
ids={x[0]:j+1 for j,x in enumerate(m.FIX)};leafform='(or '+' '.join('(= f %d)'%ids[n] for n in leaves)+')'
typed='''(defn- lc-types [M :vector-i64 f :i64] :vector-i64
 (if (>= f LAST) M
  (lc-types (-> M (t-put (+ MM-FN-BASE (* f MM-FN-W) FF-PT0) (if LEAVES TY-VEC TY-I64))
                 (t-put (+ MM-FN-BASE (* f MM-FN-W) (+ FF-PT0 1)) TY-I64)
                 (t-put (+ MM-FN-BASE (* f MM-FN-W) FF-RTYPE) TY-I64)) (inc f))))
'''.replace('LAST',str(len(m.FIX)+1)).replace('LEAVES',leafform)
def text(real):
 tx=m.kotoba(real).replace('(defn- seed-main [] :i64',typed+'(defn- seed-main [] :i64',1);needle='        M0 (t-put MR (+ MM-FN-BASE (* %d MM-FN-W) FF-PT0) TY-I64)'%ids['reader_refuse_wrong-type'];assert tx.count(needle)==1;return tx.replace(needle,needle.replace('M0','MD')+f'\n        M0 (lc-types MD {first})')
(w/'loop-cases.json').write_text(json.dumps(cases,indent=2)+'\n');(w/'loop-ids.json').write_text(json.dumps(ids,indent=2)+'\n')
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];images={};chunks={}
for label,gen,real in [('baseline-loop','baseline-41-a64gen.kotoba',True),('candidate-loop','41-a64gen-prototype.kotoba',True),('candidate-loop-test','41-a64gen-prototype.kotoba',False)]:
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/gen).read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+text(real))
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-400:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0;(w/(label+'.stdout')).write_text(q.stdout);blob,fc=m.blob_from(q.stdout);bp=w/(label+'-fixture.bin');bp.write_bytes(blob);images[label]=(bp,fc);chunks[label]=(blob,fc)
a=chunks['candidate-loop-test'];b=chunks['candidate-loop'];assert a[1]==b[1] and a[0][:len(b[0])]==b[0] and not any(a[0][len(b[0]):]) and 0<=len(a[0])-len(b[0])<=7
for c in cases:
 f=ids[c['name']];end=b[1][f+1] if f+1 in b[1] else int(re.search(r'words (\d+)',(w/'candidate-loop.stdout').read_text()).group(1))*4;words=struct.unpack('<'+'I'*((end-b[1][f])//4),b[0][b[1][f]:end]);assert words.count(0xb4000065)==2,(c,words.count(0xb4000065))
(w/'loop-layout-audit.json').write_text(json.dumps({'status':'complete-native-new-real-test-layout-and-cache-guard-audit','fixtures':len(m.FIX),'callers':len(cases),'cacheGuardSitesPerCaller':2,'codeAndLiteralsEqual':True,'fnOffsetsEqual':True,'testOnlyPaddingBytes':len(a[0])-len(b[0])},indent=2)+'\n')
rows=[];pairs=[(0,0),(1,2),(0,8),(-1,0),(0,-1),(m.MIN,0),(0,m.MAX),(m.MAX,0)];fuels=[1,2,3,4,5,6,7,16777216]
for c in cases:
 for ia,ib in pairs:
  for fuel in fuels:
   remaining=fuel;items=[11-3*j for j in range(8)]+[99];descs=[(0,8),(8,1)];regions={};handle=0 if c['mode']=='invalid-skip' else 1;sumval=0;failed=False;answer=None
   def charge(n):
    global remaining,failed
    if remaining<n:remaining=0;failed=True;return False
    remaining-=n;return True
   def read(h,index):
    global remaining,failed
    saved=remaining
    if not charge(c['charge']):return None
    if not 1<=h<=len(descs):remaining=saved;failed=True;return None
    off,n=descs[h-1];ix=m.s64(index*c['k'])
    if not 0<=ix<n:remaining=saved;failed=True;return None
    return items[off+ix]
   if charge(1):
    for iteration in range(2):
     firstval=17 if c['mode'] in ['skip','invalid-skip'] and ia==0 else read(handle,ia)
     if failed:break
     mode=c['mode']
     if mode in ['call','alloc'] and not charge(1):break
     if mode=='alloc':descs.append((len(items),1));items.append(0)
     if mode=='write':items[descs[handle-1][0]]=77
     if mode.startswith('conj'):
      off,n=descs[handle-1];region=regions.get(handle)
      if region is not None and off+n==region[0] and region[0]<region[1]:
       items[region[0]]=99;region[0]+=1;descs.append((off,n+1));regions[len(descs)]=region
      elif off+n==len(items):items.append(99);descs.append((off,n+1))
      else:
       newoff=len(items);capacity=max(4,2*(n+1));items.extend(items[off:off+n]+[99]+[0]*(capacity-n-1));descs.append((newoff,n+1));regions[len(descs)]=[newoff+n+1,newoff+capacity]
      if mode=='conj-new':handle=len(descs)
     if mode=='reassign':handle=0
     secondval=read(2 if mode=='switch' else handle,ib)
     if failed:break
     sumval=m.s64(sumval+firstval+secondval+sum(100+j for j in range(c['t'])))
     if mode=='switch-loop':handle=2
     if not charge(1):break
    if not failed:answer=m.s64(sumval+37)
   obs={}
   for label in ['baseline-loop','candidate-loop']:
    bp,fc=images[label];e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(bp),str(fc[ids[c['name']]]),'3','aarch64','-',str(ia),str(ib),'37'],env=e,capture_output=True,text=True)
    obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
    if answer is None:assert q.returncode!=0,(c,ia,ib,fuel,q.stdout)
    else:assert q.returncode==0 and re.search(r':result '+str(answer)+r'(?:\s|})',q.stdout),(c,ia,ib,fuel,answer,q.stdout,q.stderr)
    assert f':remaining {remaining}' in q.stdout and f':vectors {{:capacity 4096 :used {len(descs)}}}' in q.stdout and f':vector-items {{:capacity 65536 :used {len(items)}}}' in q.stdout,(label,c,ia,ib,fuel,remaining,descs,items,q.stdout,q.stderr)
    assert obs[label]['items']==['DIAG_VECTOR_ITEMS '+str(len(items))+' '+' '.join(map(str,items))],(label,c,ia,ib,fuel,items,q.stderr)
   assert obs['baseline-loop']==obs['candidate-loop'],(c,ia,ib,fuel,obs);rows.append({'caller':c['name'],'mode':c['mode'],'first':ia,'second':ib,'fuel':fuel,'expect':answer,'expectRemaining':remaining,'expectItems':items,**obs})
 print('PASS native loop hand-state',c['name'],c['mode'],flush=True)
(w/'loop-state-proof.json').write_text(json.dumps({'status':'complete-native-loop-key-branch-mutation-clobber-hand-state-proof','comparisons':len(rows),'callers':len(cases),'runs':rows},indent=2)+'\n');print('PASS',len(rows),'loop state comparisons',flush=True)
