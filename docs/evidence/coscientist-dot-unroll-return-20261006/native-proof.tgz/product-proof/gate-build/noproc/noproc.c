#include <fcntl.h>
#include <spawn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static void np_log(const char *what, const char *path) {
  const char *f = getenv("NOPROC_LOG");
  if (!f) return;
  int fd = open(f, O_WRONLY | O_APPEND | O_CREAT, 0644);
  if (fd < 0) return;
  char b[1200];
  int n = snprintf(b, sizeof b, "%d %s %s\n", (int)getpid(), what, path ? path : "-");
  if (n > 0) write(fd, b, (size_t)(n < (int)sizeof b ? n : (int)sizeof b - 1));
  close(fd);
}
__attribute__((constructor)) static void np_init(void) { np_log("loaded", getprogname()); }
static int np_execve(const char *p, char *const a[], char *const e[]) { np_log("execve", p); return execve(p, a, e); }
static int np_execv(const char *p, char *const a[]) { np_log("execv", p); return execv(p, a); }
static int np_execvp(const char *p, char *const a[]) { np_log("execvp", p); return execvp(p, a); }
static int np_execvP(const char *p, const char *s, char *const a[]) { np_log("execvP", p); return execvP(p, s, a); }
static int np_spawn(pid_t *pid, const char *p, const posix_spawn_file_actions_t *fa, const posix_spawnattr_t *at,
                    char *const a[], char *const e[]) { np_log("posix_spawn", p); return posix_spawn(pid, p, fa, at, a, e); }
static int np_spawnp(pid_t *pid, const char *p, const posix_spawn_file_actions_t *fa, const posix_spawnattr_t *at,
                     char *const a[], char *const e[]) { np_log("posix_spawnp", p); return posix_spawnp(pid, p, fa, at, a, e); }
static pid_t np_fork(void) { np_log("fork", "-"); return fork(); }
static pid_t np_vfork(void) { np_log("vfork", "-"); return fork(); }
static int np_system(const char *c) { np_log("system", c); return system(c); }
static FILE *np_popen(const char *c, const char *m) { np_log("popen", c); return popen(c, m); }
#define NP(n, o) __attribute__((used)) static struct { const void *r; const void *o; } np_i_##o \
  __attribute__((section("__DATA,__interpose"))) = { (const void *)(n), (const void *)(o) };
NP(np_execve, execve) NP(np_execv, execv) NP(np_execvp, execvp) NP(np_execvP, execvP)
NP(np_spawn, posix_spawn) NP(np_spawnp, posix_spawnp) NP(np_fork, fork) NP(np_vfork, vfork)
NP(np_system, system) NP(np_popen, popen)
