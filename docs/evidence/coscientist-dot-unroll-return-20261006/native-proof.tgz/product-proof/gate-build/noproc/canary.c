#include <spawn.h>
#include <sys/wait.h>
#include <unistd.h>
extern char **environ;
int main(void) {
  pid_t p; int st; char *a[] = {"true", 0};
  if (posix_spawn(&p, "/usr/bin/true", 0, 0, a, environ) == 0) waitpid(p, &st, 0);
  pid_t c = fork();
  if (c == 0) { execve("/usr/bin/true", a, environ); _exit(1); }
  waitpid(c, &st, 0);
  return 0;
}
