from pathlib import Path
import json,hashlib,tarfile,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-dot-unroll-return-20261006');p=Path('/private/tmp/amu-dot-unroll-return-product-20261006');i=Path('/private/tmp/amu-dot-unroll-return-integrated-20261006');a=Path('/private/tmp/amu-dot-unroll-return-integrated-20261006-parity');out=r/'docs/evidence/coscientist-dot-unroll-return-20261006';out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for root,names in [(p,['summary.json','gate-summary.json','permanent-prefix-audit.json','normal-unit-independent-audit.json','integrated-summary.json','per-case-output-audit.json','promotion-source-audit.json','next-hypothesis.json']),(w,['hypothesis.json','timing-artifact-audit.json','preflight-audit.json','instruction-audit.json','guard-proof.json','dispatch-correction.json'])]:
 for name in names:shutil.copyfile(root/name,out/name)
def archive(name,roots,exclude):
 target=out/name
 with tarfile.open(target,'w:gz') as tar:
  for root,label in roots:
   for f in sorted(root.rglob('*')):
    if not f.is_file() or '__pycache__' in f.parts or exclude(root,f):continue
    tar.add(f,arcname=label+'/'+str(f.relative_to(root)),recursive=False)
 assert target.stat().st_size<100000000
 print('ARCHIVE',name,target.stat().st_size,sha(target),flush=True)
archive('native-proof.tgz',[(w,'dot-return'),(p,'product-proof')],lambda root,f:root==w and f.relative_to(root).parts[0] in ['remote-evidence','timing-package'])
archive('timing.tgz',[(w/'remote-evidence','remote-timing')],lambda root,f:False)
archive('integrated-proof.tgz',[(i,'integrated'),(a,'parity')],lambda root,f:False)
for name,required in [('native-proof.tgz',['dot-return/41-a64gen-prototype.kotoba','dot-return/seed-4.bin','dot-return/preflight-audit.json','dot-return/hand-proof.json','dot-return/guard-proof.json','product-proof/permanent-regression-proof.json','product-proof/committed-source/seed/41-a64gen.kotoba','product-proof/gate-summary.json']),('timing.tgz',['remote-timing/timing-package/matmult-int/timing/results.json','remote-timing/timing-package/matmult-int/baseline/matmult-int/c.dylib']),('integrated-proof.tgz',['integrated/g3/amu','integrated/inputs.sha256','integrated/objects3.sha','parity/check.tsv','parity/compile.tsv','parity/exports.tsv'])]:
 with tarfile.open(out/name,'r:gz') as tar:
  names=set(tar.getnames())
  for item in required:assert item in names,(name,item)
  if name=='integrated-proof.tgz':
   images=[tar.extractfile('integrated/g'+str(g)+'/amu').read() for g in [1,2,3]];assert images[0]==images[1]==images[2]==(i/'g3/amu').read_bytes()
  if name=='native-proof.tgz':assert tar.extractfile('dot-return/41-a64gen-prototype.kotoba').read()==tar.extractfile('product-proof/committed-source/seed/41-a64gen.kotoba').read()==(r/'seed/41-a64gen.kotoba').read_bytes()
(out/'checksums.sha256').write_text('\n'.join(sha(f)+'  '+f.name for f in sorted(out.iterdir()) if f.name!='checksums.sha256')+'\n')
print('PASS full archives, native measured-source linkage and critical receipts verified',flush=True)
