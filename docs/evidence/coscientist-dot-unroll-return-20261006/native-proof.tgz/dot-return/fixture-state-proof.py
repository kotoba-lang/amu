from pathlib import Path
import json,os,subprocess,re
w=Path('/private/tmp/amu-dot-unroll-return-20261006');g=json.loads((w/'guard-proof.json').read_text());hp=json.loads((w/'hand-proof.json').read_text());offset=g['fnOffsets'][str(g['wrapperFn'])];rows=[]
for row in hp['runs']:
 if row['variant']!='three':continue
 e=dict(os.environ,KEXE_FUEL=str(row['fuel']),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
 q=subprocess.run([str(w/'clobber-full-state-loader'),str(w/'guard-fixture.bin'),str(offset),'3','aarch64','-',*map(str,row['args'])],env=e,capture_output=True,text=True);obs={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
 assert obs==row['baseline']==row['candidate'],(row['args'],row['fuel'],obs,row['baseline']);rows.append({'args':row['args'],'fuel':row['fuel'],'expected':row['expect'],'observation':obs})
assert len(rows)>100
(w/'fixture-state-proof.json').write_text(json.dumps({'status':'complete-native-independent-SIR-real-test-layout-guest-hand-oracle-state-parity','comparisons':len(rows),'matchesNativeFrontendBaselineAndCandidate':True,'runs':rows},indent=2)+'\n');print('PASS',len(rows),'independently authoredSIR wrapper runtime states',flush=True)
