from pathlib import Path
import ast,hashlib,json
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-dot-unroll-return-20261006');p=Path('/private/tmp/amu-dot-unroll-20261006');g=r/'seed/41-a64gen.kotoba';assert g.read_bytes()==(w/'baseline-41-a64gen.kotoba').read_bytes();(w/'committed-before-a64gen-fixtures.py').write_bytes((r/'scripts/seed/a64gen-fixtures.py').read_bytes())
# New compiler algorithm and independent semantic hand fixtures: one-off authoring exception.
g.write_bytes((w/'41-a64gen-prototype.kotoba').read_bytes());q=r/'scripts/seed/a64gen-fixtures.py';s=q.read_text();needle='\n\ndef kotoba(real_layout=False):';assert s.count(needle)==1
node=next(n for n in ast.parse((p/'create.py').read_text()).body if isinstance(n,ast.Assign) and any(isinstance(a,ast.Name) and a.id=='T' for a in n.targets));T=ast.literal_eval(node.value)
block='''
# Guarded whole-dot expansion: independent i64/vector/fuel oracle.
DOT_UNROLL_TEMPLATE = '''+repr(T)+'''
DOT_UNROLL_CASES = []
for _name,_n,_sa,_sb,_oa,_ob,_length in [
 ('du_small',3,3,3,0,0,9),('du_overlap',3,1,1,0,0,9),
 ('du_wide',64,64,64,4095,4095,8192),('du_refused',65,1,1,0,0,129)]:
 _values={j:v for j,v in enumerate([MIN,MAX,-1,0,1,7,-3,9,11])}
 if _name=='du_wide':
  _values={4095+j:v for j,v in enumerate([MIN,MAX,-1,0,1,7,-3,9,11])}
  _values.update({4095+64*j:v for j,v in enumerate([MIN,MAX,-1,0,1,7,-3,9,11]) if j>0})
 _capture={'n':_n,'sa':_sa,'sb':_sb,'oa':_oa,'ob':_ob,
           'head':_name+'_head','body':_name+'_body','exit':_name+'_exit'}
 _body=[tuple([ins[0][3:]]+[_capture.get(x,x) for x in ins[1:]]) for ins in DOT_UNROLL_TEMPLATE[1:-1]]
 fx(_name,5,5,_body)
 _wrapper=[('FUEL',),('CONST',0,_length),('RT','RT-VECTOR-ALLOC',0,1),('LSET',4,0)]
 for _ix,_v in sorted(_values.items()):
  _wrapper += [('LGET',0,4),('CONST',1,_ix),('CONST',2,_v),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3)]
 _wrapper += [('LGET',0,4),('LGET',1,1),('LGET',2,2),('LGET',3,3),('CONST',4,MAX),('CALL',_name,0,5),('RET',0)]
 fx(_name+'_run',3,4,_wrapper)
 DOT_UNROLL_CASES.append({'name':_name,'trip':_n,'sa':_sa,'sb':_sb,'oa':_oa,'ob':_ob,'length':_length,'values':_values})

def _du_answer(c,row,col,k,fuel):
 # No native generator is consulted. Charge the wrapper and dot entries first.
 if fuel<2:return 'trap'
 fuel-=2;total=MAX
 for _ in range(c['length']+5):
  if k==c['trip']:return total
  a=s64(c['oa']+s64(s64(row*c['sa'])+k));b=s64(c['ob']+s64(s64(k*c['sb'])+col))
  if not (0<=a<c['length'] and 0<=b<c['length']):return 'trap'
  total=s64(total+s64(c['values'].get(a,0)*c['values'].get(b,0)));k=s64(k+1)
  if fuel==0:return 'trap'
  fuel-=1
 raise AssertionError('dot oracle did not reach its bounded range or fuel trap')

for c in DOT_UNROLL_CASES:
 n=c['trip']
 for row,col,k in [(0,0,0),(0,n-1,0),(n-1,0,0),(n-1,n-1,0),(1,1,0),
                   (n,0,0),(-1,0,0),(MIN,MAX,0),(MAX,MIN,0),
                   (0,0,n),(0,0,1),(0,0,n-1),(0,0,n+1),(0,0,-1),
                   (0,0,MIN),(0,0,MAX),(0,MIN,0),(0,MAX,0)]:
  for fuel in sorted(set([1,2,3,n+1,n+2,n+3,16777216,(1<<53)-1])):
   run(c['name']+'_run',[row,col,k],_du_answer(c,row,col,k,fuel),fuel=fuel)
fx('du_bad_handle',3,3,[('FUEL',),('LGET',0,1),('CONST',1,0),('CONST',2,0),
                      ('LGET',3,2),('LGET',4,3),('CALL','du_small',0,5),('RET',0)])
for h in [MIN,-1,0,1,MAX]:
 for k in [0,3,-1,MAX]:
  for fuel in [1,2,3,16777216]:
   run('du_bad_handle',[h,k,MAX],MAX if fuel>=2 and k==3 else 'trap',fuel=fuel)
_du_sentinel=next(f for f in FIX if f[0]=='ht_cold_control')
FIX.append(('du_cold_sentinel',*_du_sentinel[1:]))
'''
s=s.replace(needle,'\n'+block+needle,1)
needle="    o += ['(defn- t-reader-types [M :vector-i64 f :i64] :vector-i64',";assert s.count(needle)==1
helper='''    du_ids=[fns[c['name']] for c in DOT_UNROLL_CASES]
    du_members='(or '+' '.join('(= f %d)'%f for f in du_ids)+')'
    o += ['(defn- t-du-types [M :vector-i64 f :i64] :vector-i64',
          ' (if (>= f (vector-at M MM-FN-N)) M',
          '  (let [b (+ MM-FN-BASE (* f MM-FN-W))',
          '        M1 (if %s (-> M (t-put (+ b FF-PT0) TY-VEC)'%du_members,
          '              (t-put (+ b FF-PT0 1) TY-I64) (t-put (+ b FF-PT0 2) TY-I64)',
          '              (t-put (+ b FF-PT0 3) TY-I64) (t-put (+ b FF-PT0 4) TY-I64)',
          '              (t-put (+ b FF-RTYPE) TY-I64)) M)] (t-du-types M1 (inc f)))))']
'''
s=s.replace(needle,helper+needle,1);needle="'        M0 (t-put MR (+ MM-FN-BASE (* %d MM-FN-W) FF-PT0) TY-I64)'";assert s.count(needle)==1;s=s.replace(needle,"'        M0 (t-put (t-du-types MR 1) (+ MM-FN-BASE (* %d MM-FN-W) FF-PT0) TY-I64)'",1);q.write_text(s)
(w/'promotion-preparation.json').write_text(json.dumps({'status':'qualified-prototype-applied-to-research-source-native-unit-and-gates-pending','sourceSha256':hashlib.sha256(g.read_bytes()).hexdigest(),'measurementQualified':True,'productPromoted':False,'authoringException':'New native guarded loop-return algorithm and independently authored semantic fixtures; no existing AST refactor rule. Generated unit files must use authoritative generator after independent native proof.'},indent=2)+'\n');print('PASS one-off algorithm and independent durable fixtures prepared; no promotion claim')
