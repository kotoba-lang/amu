from pathlib import Path
import json,importlib.util,ast,re,os,subprocess,hashlib,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-dot-unroll-return-20261006');sp=importlib.util.spec_from_file_location('m',w/'permanent-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
node=next(n for n in ast.parse(Path('/private/tmp/amu-dot-unroll-20261006/create.py').read_text()).body if isinstance(n,ast.Assign) and any(isinstance(a,ast.Name) and a.id=='T' for a in n.targets));T=ast.literal_eval(node.value);values={'n':3,'oa':0,'ob':0,'sa':3,'sb':3,'head':'dg_head','body':'dg_body','exit':'dg_exit'};body=[tuple([x[0][3:]]+[values.get(a,a) for a in x[1:]]) for x in T[1:-1]];m.fx('dg_dot',5,5,body)
m.fx('dg_wrapper',3,4,[('FUEL',)]+[('CONST',j,v) for j,v in enumerate([m.MIN,m.MAX,-1,0,1,7,-3,9,11])]+[('VEC',0,9),('LSET',4,0),('LGET',0,4),('LGET',1,1),('LGET',2,2),('LGET',3,3),('CONST',4,m.MAX),('CALL','dg_dot',0,5),('RET',0)])
sentinel=next(x for x in m.FIX if x[0]=='ht_cold_control');m.FIX.append(('dg_cold_sentinel',*sentinel[1:]));fns,labels,lits,sir,frec=m.layout_tables();f=fns['dg_dot'];p=next(j for j,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==f);assert len(T)==47 and next(x for x in frec if x[0]==f)[-1]==10
base=m.C['MM-FN-BASE']+f*m.C['MM-FN-W'];types='(defn- t-dot-types [M :vector-i64] :vector-i64\n (-> M '+' '.join('(t-put '+str(base+m.C['FF-PT0']+j)+' '+('TY-VEC' if j==0 else 'TY-I64')+')' for j in range(5))+' (t-put '+str(base+m.C['FF-RTYPE'])+' TY-I64)))\n'
probe='''(defn- t-dot-mut [M :vector-i64 at :i64 want :bool] :bool
 (let [old (vector-at M at) MM (t-put M at (inc old)) got (gn-dot? MM '''+str(p+1)+''') restore (t-put MM at old)] (= got want)))
(defn- t-dot-fields [M :vector-i64 k :i64] :bool
 (if (= k 188) true
  (let [off (quot k 4) fld (rem k 4) at (+ MM-SIR-BASE (* (+ '''+str(p)+''' off) MM-SIR-W) fld)
        want (and (= fld IF-B) (or (= off 4) (= off 18) (= off 20) (= off 27) (= off 29)))]
   (and (t-dot-mut M at want) (t-dot-fields M (inc k))))))
(defn probe [] :i64
 (let [M0 (t-dot-types (t-load (t-init))) M1 (gn-run M0) M (gn-op-fn M1 '''+str(p)+' '+str(f)+''' 5)
       accepted (gn-dot? M '''+str(p+1)+''') fields (t-dot-fields M 0)
       meta (and '''+' '.join('(t-dot-mut M '+str(base+m.C[c]+delta)+' false)' for c,delta in [('FF-SIR',0),('FF-NPARAMS',0),('FF-NSLOTS',0),('FF-DEPTH',0),('FF-RTYPE',0)]+[('FF-PT0',j) for j in range(5)])+''')
       open (gn-dot? (gn-gs M gn-g-open '''+str(f)+''') '''+str(p+1)+''')
       open_n (gn-dot? (gn-gs M gn-g-open-n 1) '''+str(p+1)+''')
       reset (gn-gs M gn-g-open 0)
       local_old (gn-g M (+ gn-a-sreg 1))
       local (not (gn-dot? (gn-gs M (+ gn-a-sreg 1) 0) '''+str(p+1)+'''))
       local_restore (gn-gs M (+ gn-a-sreg 1) local_old)
       lab (and '''+' '.join('(t-dot-mut M (+ (vector-at M gn-cell) gn-a-lp '+str(labels[x])+') false)' for x in ['dg_head','dg_body','dg_exit'])+''')]
  (if (and accepted fields meta (not open_n) local lab) (let [o (t-out "DOT_GUARDS PASS\\n")] 0) 1)))
'''
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');chunks=[]
for label,real in [('guard-real',True),('guard-test',False)]:
 unit=m.kotoba(real);needle='        M0 (t-put MR ';assert unit.count(needle)==1;unit=unit.replace(needle,'        M0 (t-put (t-dot-types MR) ',1)
 source='\n'.join((r/x).read_text().replace('(:export [main])','(:export [main probe])') if x=='seed/00-ns.kotoba' else (r/x).read_text() for x in ['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'])+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+types+unit+probe
 (w/(label+'.kotoba')).write_text(source)
 for stage,args in [('compile',['compile',str(w/(label+'.kotoba')),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-300:],q.stderr)
 off=re.search(r':offset (\d+)',q.stdout).group(1);q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'.stdout')).write_text(q.stdout);assert q.returncode==0,(label,q.stdout[-100:],q.stderr);chunks.append(m.blob_from(q.stdout))
 if real:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--','extract-native',str(w/(label+'.kseed')),'--symbol','probe','--output',str(w/'guard-probe.bin')],env=env,capture_output=True,text=True);assert q.returncode==0,q.stderr;off=re.search(r':offset (\d+)',q.stdout).group(1)
  q=subprocess.run([str(w/'kexe-loader'),str(w/'guard-probe.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/'guard-probe.stdout').write_text(q.stdout+q.stderr);assert q.returncode==0 and 'DOT_GUARDS PASS' in q.stdout,(q.returncode,q.stdout,q.stderr)
a,b=chunks;short=min(len(a[0]),len(b[0]));assert a[1]==b[1] and a[0][:short]==b[0][:short] and not any(a[0][short:]+b[0][short:]) and abs(len(a[0])-len(b[0]))<=7
(w/'guard-fixture.bin').write_bytes(b[0]);(w/'guard-proof.json').write_text(json.dumps({'status':'complete-native-exact-SIR-mutations-types-open-range-label-slot-and-independent-layout-proof','all188SIRFieldsMutatedAndRestored':True,'typeAndMetadataRefusals':10,'foreignLabelRefusals':3,'openReplacementRefuses':True,'invalidLocalRegisterRefuses':True,'realTestCodeAndLiteralBytesEqual':True,'realTestFnOffsetsEqual':True,'fnOffsets':b[1],'dotFn':f,'wrapperFn':fns['dg_wrapper'],'realMinusTestPaddingBytes':len(a[0])-len(b[0]),'prototypeSha256':hashlib.sha256((w/'41-a64gen-prototype.kotoba').read_bytes()).hexdigest()},indent=2)+'\n');print('PASS all188SIR fields,10metadata,3labels,open/local guards and real/testlayout',flush=True)
