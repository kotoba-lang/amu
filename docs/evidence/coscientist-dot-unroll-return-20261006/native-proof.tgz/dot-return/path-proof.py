from pathlib import Path
import json,struct,os,re,subprocess
w=Path('/private/tmp/amu-dot-unroll-return-20261006');rows=[]
for name,n in [('one',1),('three',3),('short',3),('twenty',20),('sixtyfour',64)]:
 d=w/'hand2'/name;mf=next(x for x in json.loads((w/'hand-proof.json').read_text())['images'] if x['variant']==name);blob=bytearray((d/'candidate.bin').read_bytes());words=[x[0] for x in struct.iter_unpack('<I',blob)];pos=[j+2 for j in range(len(words)-2) if words[j:j+3]==[0xf9400009,0xf940002a,0x9b0a0922]];assert len(pos)==1,(name,pos);struct.pack_into('<I',blob,pos[0]*4,0xd4200000);(d/'hit-trap.bin').write_bytes(blob)
 for a,c,k,fuel,hit in [(0,0,0,16777216,True),(0,0,n,16777216,False),(0,0,1,16777216,False),(0,0,0,2,False),(-1,0,0,16777216,False),(n,0,0,16777216,False)]:
  if n==1 and k==1:hit=False
  obs={}
  for label,path in [('normal',d/'candidate.bin'),('sentinel',d/'hit-trap.bin')]:
   e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'clobber-full-state-loader'),str(path),str(mf['images']['candidate']['offset']),'3','aarch64','-',str(a),str(c),str(k)],env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
  if hit:assert obs['normal']['exit']==0 and ':SIGTRAP' in ' '.join(obs['sentinel']['traps']),(name,a,c,k,fuel,obs)
  else:assert obs['normal']==obs['sentinel'],(name,a,c,k,fuel,obs)
  rows.append({'variant':name,'args':[a,c,k],'fuel':fuel,'hitExpected':hit,**obs})
 print('PASS actual guarded-path coverage and original-path controls',name,flush=True)
(w/'path-proof.json').write_text(json.dumps({'status':'complete-native-actual-fast-madd-hit-and-fallback-path-diagnostic','diagnosticOnlyNeverTimed':True,'comparisons':len(rows),'runs':rows},indent=2)+'\n')
