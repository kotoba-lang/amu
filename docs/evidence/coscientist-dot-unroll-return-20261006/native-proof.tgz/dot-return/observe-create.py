from pathlib import Path
import shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-dot-unroll-return-20261006');o=w/'observer';o.mkdir();g=(w/'41-a64gen-prototype.kotoba').read_text();a='(defn- gn-dot? [';assert g.count(a)==1;g=g.replace(a,'(defn- gn-dot-test? [',1);wrapper='''(defn- gn-dot? [M :vector-i64 i :i64] :bool
 (let [answer (gn-dot-test? M i)
       printed (if answer (io-out (string-concat "DOT_POS " (string-concat (string-from-i64 i) (string-concat " " (string-concat (string-from-i64 (gn-sir M (dec i) IF-A)) "\\n"))))) 0)] answer))
''';a='(defn- gn-dot-expand [';assert g.count(a)==1;g=g.replace(a,wrapper+a,1)
parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(o/'observer-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in parts));(o/'observer-41-a64gen.kotoba').write_text(g)
for a,b in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader')]:shutil.copy2(w/a,o/b)
s=Path('/private/tmp/amu-loop-composition-census-20261006/observe.py').read_text().replace('amu-loop-composition-census-20261006','amu-dot-unroll-return-20261006/observer').replace('amu-same-local-read-20261006/ports-correctness.json','amu-dot-unroll-return-20261006/ports-correctness.json');(o/'observe.py').write_text(s)
