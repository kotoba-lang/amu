from pathlib import Path
import json,hashlib,struct
w=Path('/private/tmp/amu-dot-unroll-return-20261006');b=Path('/private/tmp/amu-same-local-read-20261006');parent=Path('/private/tmp/amu-dot-unroll-20261006');load=lambda p:json.loads(p.read_text());pc=load(w/'ports-correctness.json');old=load(b/'ports-correctness.json');rows=[]
for e in pc['entries']:
 o=next(x for x in old['entries'] if x['workload']==e['workload']);changed=e['nativeSha256']!=o['nativeSha256'];assert changed==(e['workload']=='matmult-int');rows.append({'workload':e['workload'],'changed':changed,'sha256':e['nativeSha256'],'offset':e['offset']})
a=(b/'ports-2/matmult-int/native.bin').read_bytes();z=(w/'ports-2/matmult-int/native.bin').read_bytes();start=(2163-1)*4;prefix=18*4;growth=len(z)-len(a);assert growth==408
assert a[start:start+prefix]==z[start:start+prefix]
assert a[start+prefix:start+73*4]==z[start+prefix+growth:start+73*4+growth]
words=[x[0] for x in struct.iter_unpack('<I',z[start+prefix:start+prefix+growth])];assert len(words)==102;group=next(j for j in range(len(words)-2) if words[j:j+3]==[0xf9400009,0xf940002a,0x9b0a0922])
for j in range(20):assert words[group+3*j:group+3*j+3]==[0xf9400009+(j<<10),0xf940002a+(j*20<<10),0x9b0a0922]
oldwords=[x[0] for x in struct.iter_unpack('<I',a[start:start+73*4])];assert words[group+60+2]==0xaa0203e0 and words[group+60+3:group+60+9]==oldwords[-7:-1]
assert z!=(parent/'ports-2/matmult-int/native.bin').read_bytes()
(w/'instruction-audit.json').write_text(json.dumps({'status':'complete-original19-and-actual-distinct-direct-return-native-frame-fallback-audit','onlyMatmultChanged':True,'distinctFromRejectedParentMachine':True,'originalFn5Prefix18WordsExact':True,'originalFn5Tail55WordsExact':True,'original192ByteFrameAndAll5ParamPlacementsExact':True,'originalEntryFuelWordsExact':True,'expanded20GroupsExact':True,'successfulFastReturnUsesExactOriginal6WordFrameCalleeRestoration':True,'extraWords':102,'entries':rows},indent=2)+'\n');print('PASS distinctnewmatmult; originalframe/params/entryfuel/fallback55words exact;20groups+exact6wordepilogue')
