from pathlib import Path
import json,subprocess,os,re,hashlib,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-dot-unroll-return-20261006');b=Path('/private/tmp/amu-same-local-read-20261006');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');MIN=-(1<<63);MAX=(1<<63)-1;vals=[MIN,MAX,-1,0,1,7,-3,9,11];wrap=lambda x:((x+(1<<63))%(1<<64))-(1<<63)
variants=[('one',1,1,1,0,0,9),('two',2,2,2,0,0,9),('three',3,3,3,0,0,9),('short',3,3,3,0,0,8),('offset',3,1,2,1,2,9),('overlap',3,1,1,0,0,9),('twenty',20,20,20,800,1200,2001),('sixtyfour',64,64,64,4095,4095,8192),('stride-refuse',3,65,65,0,0,512),('offset-refuse',3,3,3,-1,0,9),('trip-refuse',65,1,1,0,0,512)]
rows=[];images=[];maddmask=lambda words:sum((x&0xff000000)==0x9b000000 and ((x>>10)&31)!=31 for x in words)
for name,n,sa,sb,oa,ob,length in variants:
 d=w/'hand2'/name;d.mkdir(parents=True,exist_ok=True)
 src=d/'source.kotoba';src.write_text('(ns dot-proof.'+name+' (:export [run dot]))\n(defn dot [v :vector-i64 row :i64 col :i64 k :i64 sum :i64] :i64\n (if (= k '+str(n)+') sum (dot v row col (+ k 1) (+ sum (* (vector-at v (+ '+str(oa)+' (+ (* row '+str(sa)+') k))) (vector-at v (+ '+str(ob)+' (+ (* k '+str(sb)+') col))))))))\n(defn run [encoded :i64 col :i64 k :i64] :i64\n (let [v0 (vector-alloc '+str(length)+')\n'+''.join('       v'+str(j+1)+' (vector-assoc! v'+str(j)+' '+str(j)+' '+str(value)+')\n' for j,value in enumerate(vals[:min(length,9)]))+ '       row encoded]\n  (dot v'+str(min(length,9))+' row col k '+str(MAX)+')))\n')
 paths={};offs={}
 for label,root in [('baseline',b),('candidate',w)]:
  for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(d/(label+'.kseed'))]),('extract',['extract-native',str(d/(label+'.kseed')),'--symbol','run','--output',str(d/(label+'.bin'))])]:
   q=subprocess.run([str(w/'kexe-loader'),str(root/'seed-4.bin'),(root/'seed-4.offset').read_text().strip(),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,label,stage,q.stdout,q.stderr)
  offs[label]=int(re.search(r':offset (\d+)',q.stdout).group(1));paths[label]=d/(label+'.bin')
 words={label:list(x[0] for x in struct.iter_unpack('<I',paths[label].read_bytes())) for label in paths};growth=maddmask(words['candidate'])-maddmask(words['baseline']);accepted=n<=64 and sa<=64 and sb<=64 and 0<=oa<=4095 and 0<=ob<=4095
 assert growth==(n if accepted else 0),(name,accepted,growth)
 images.append({'variant':name,'trip':n,'accepted':accepted,'extraMaddWords':growth,'sourceSha256':hashlib.sha256(src.read_bytes()).hexdigest(),'images':{label:{'sha256':hashlib.sha256(paths[label].read_bytes()).hexdigest(),'offset':offs[label]} for label in paths}})
 args=[(0,0,0),(0,n-1,0),(n-1,0,0),(n-1,n-1,0),(n,0,0),(-1,0,0),(MIN,MAX,0),(MAX,MIN,0),(0,0,n),(1000,0,n),(2000,0,n),(1000,0,0),(2000,0,0),(0,-1,0),(0,n,0),(0,MAX,0),(0,MIN,0),(0,0,1),(0,0,n-1),(0,0,n+1),(0,0,-1),(0,0,MIN),(0,0,MAX)]
 for encoded,col,k in args:
  handle=1;row=encoded
  for fuel in sorted(set([1,2,3,n+1,n+2,n+3,16777216,(1<<53)-1])):
   remaining=fuel;answer=None;v=[0]*length;allocated=False;trap=False
   def charge():
    global remaining,trap
    if remaining==0:trap=True;return False
    remaining-=1;return True
   if charge():
    allocated=True;v[:min(length,9)]=vals[:min(length,9)]
    if charge():
     j=k;total=MAX
     for step in range(length+5):
      if j==n:answer=total;break
      ai=wrap(oa+wrap(wrap(row*sa)+j));bi=wrap(ob+wrap(wrap(j*sb)+col))
      if handle!=1 or not 0<=ai<length:trap=True;break
      av=v[ai]
      if not 0<=bi<length:trap=True;break
      total=wrap(total+wrap(av*v[bi]));j=wrap(j+1)
      if not charge():break
     else:raise AssertionError(('oracle bound exhausted',name,encoded,col,k))
   obs={}
   for label in paths:
    e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
    q=subprocess.run([str(w/'clobber-full-state-loader'),str(paths[label]),str(offs[label]),'3','aarch64','-',str(encoded),str(col),str(k)],env=e,capture_output=True,text=True)
    obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
    assert (q.returncode==0)==(answer is not None),(name,label,encoded,col,k,fuel,answer,q.stdout,q.stderr[-200:])
    if answer is not None:assert re.search(r':result '+str(answer)+r'(?:\s|})',q.stdout),(name,label,answer,q.stdout)
    assert f':remaining {remaining}' in q.stdout,(name,label,fuel,remaining,q.stdout)
    assert f':vectors {{:capacity 4096 :used {int(allocated)}}}' in q.stdout and f':vector-items {{:capacity 65536 :used {length if allocated else 0}}}' in q.stdout,(name,label,fuel,q.stdout)
    expected=['DIAG_VECTOR_ITEMS '+str(length)+' '+' '.join(map(str,v))] if allocated else ['DIAG_VECTOR_ITEMS 0']
    assert obs[label]['items']==expected,(name,label,fuel,expected[:1],obs[label]['items'][:1])
   assert obs['baseline']==obs['candidate'],(name,encoded,col,k,fuel,obs);rows.append({'variant':name,'args':[encoded,col,k],'fuel':fuel,'expect':answer,'remaining':remaining,**obs})
 print('PASS independent native whole-dot state',name,flush=True)
(w/'hand-proof.json').write_text(json.dumps({'status':'complete-native-whole-dot-hand-oracle-and-refusal-proof','comparisons':len(rows),'variants':len(variants),'originalFrameAuditPending':True,'candidateRealTestLayoutPending':True,'images':images,'runs':rows},indent=2)+'\n');print('PASS',len(rows),'native whole-dot hand full-state comparisons',flush=True)
