from pathlib import Path
import json,subprocess,os,hashlib
W=Path('/private/tmp/amu-stable-vector-loop-20261006/implementation');D=W.parent/'team-resource';OLD=Path('/private/tmp/amu-private-length-clones-20261006');prior=json.loads((OLD/'ports-state.json').read_text());current=json.loads((W/'ports-build.json').read_text());baseline=json.loads((OLD/'ports-correctness.json').read_text());rows=[]
for r in prior['rows']:
 name=r['workload'];new=next(e for e in current['entries'] if e['workload']==name);old=next(e for e in baseline['entries'] if e['workload']==name)
 obs={}
 for label,path,off in [('product',OLD/'baseline-native'/(name+'.bin'),old['offset']),('candidate',W/'ports'/name/'native.bin',new['offset'])]:
  env=dict(os.environ,KEXE_FUEL=str(r['fuel']),KEXE_STRUCTURED_REPORT='1');env.pop('KEXE_COMMAND',None)
  q=subprocess.run([str(OLD/'full-state-loader'),str(path),str(off),'1','aarch64','-',str(r['n'])],env=env,capture_output=True,text=True);obs[label]={'exit':q.returncode,'stdout':q.stdout.strip(),'stderr':q.stderr.strip()}
 assert obs['product']==obs['candidate'],(name,r['n'],r['fuel'],obs);rows.append({'workload':name,'n':r['n'],'fuel':r['fuel'],**obs})
 if len(rows)%11==0:print('PASS fresh fuel fullstates',len(rows),flush=True)
(D/'fuel-states.json').write_text(json.dumps({'status':'PASS original19 209 fuel/trap/partial-state pairs','pairs':len(rows),'trappedPairs':sum(r['product']['exit']!=0 for r in rows),'rows':rows},indent=2)+'\n')
