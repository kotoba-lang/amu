from pathlib import Path
import struct,json,os,subprocess,hashlib
D=Path(__file__).resolve().parent;W=D.parent;C=W/'team-constructor';OLD=Path('/private/tmp/amu-private-length-clones-20261006')
def wrap(raw,off):
 words=[0xa9bf7bfd,0x910003fd,0xd10143ff]
 for i in range(0,10,2):words.append(0xa9000000|((8*i//8)<<15)|((20+i)<<10)|(31<<5)|(19+i))
 for r in range(19,29):words.append(0xd2800000|((0x100+r)<<5)|r)
 words += [0xf9400000|((384//8)<<10)|(7<<5)|16,0xd2800000|((off&65535)<<5)|17,0xf2a00000|(((off>>16)&65535)<<5)|17,0x8b110210,0xd63f0200]
 branches=[]
 for r in range(19,29):words.append(0xf100001f|((0x100+r)<<10)|(r<<5));branches.append(len(words));words.append(0)
 # Success skips only failure result materialization.
 words.append(0x14000002);fail=len(words);words.append(0xd2800000|(999<<5))
 for i in range(0,10,2):words.append(0xa9400000|((8*i//8)<<15)|((20+i)<<10)|(31<<5)|(19+i))
 words += [0x910003bf,0xa8c17bfd,0xd65f03c0]
 for at in branches:words[at]=0x54000001|(((fail-at)&0x7ffff)<<5)
 padded=raw+b'\0'*((-len(raw))%4);return padded+struct.pack('<'+'I'*len(words),*words),len(padded)
rows=[]
for case in ['dominated-loop','loop-first-read','conditional-first','both-first-join']:
 p=C/case/'candidate-walk.bin';off=int((C/case/'candidate-walk.offset').read_text());raw=p.read_bytes();blob,at=wrap(raw,off);out=D/(case+'-callee.bin');out.write_bytes(blob)
 for n in [0,1,2,4]:
  env=dict(os.environ,KEXE_FUEL='1048576',KEXE_STRUCTURED_REPORT='1',KEXE_ARG_TYPES='vector-i64,i64');env.pop('KEXE_COMMAND',None)
  obs={}
  for label,path,offset in [('direct',p,off),('sentinels',out,at)]:
   q=subprocess.run([str(OLD/'full-state-loader'),str(path),str(offset),'2','aarch64','-','vi:11,13,17',str(n)],env=env,capture_output=True,text=True);obs[label]={'exit':q.returncode,'stdout':q.stdout.strip(),'stderr':q.stderr.strip()}
  assert obs['direct']==obs['sentinels'] and obs['direct']['exit']==0,(case,n,obs);rows.append({'case':case,'n':n,**obs})
 print('PASS exact callee register sentinel preservation',case,flush=True)
# Actual machine mutant: remove the restore of cache's last register (x21)
# after a successful original first access, while retaining result/array reads.
p=C/'dominated-loop/candidate-walk.bin';raw=p.read_bytes();words=[x[0] for x in struct.iter_unpack('<I',raw[:len(raw)//4*4])]
restore=[i for i,z in enumerate(words) if (z&0xffc003ff)==(0xf9400000|(31<<5)|21)]
assert restore, 'x21 cache restore missing';atword=restore[-1];mut=bytearray(raw);mut[atword*4:atword*4+4]=struct.pack('<I',0xd503201f);blob,off=wrap(bytes(mut),int((C/'dominated-loop/candidate-walk.offset').read_text()));p=D/'no-cache-register-restore.bin';p.write_bytes(blob)
env=dict(os.environ,KEXE_FUEL='1048576',KEXE_STRUCTURED_REPORT='1',KEXE_ARG_TYPES='vector-i64,i64');q=subprocess.run([str(OLD/'full-state-loader'),str(p),str(off),'2','aarch64','-','vi:11,13,17','1'],env=env,capture_output=True,text=True);(D/'no-cache-register-restore.log').write_text(q.stdout+q.stderr);assert q.returncode==0 and ':result 999 ' in q.stdout,(q.returncode,q.stdout,q.stderr)
# Actual stale-witness initialization mutant under a nonzero incoming callee sentinel.
init=[i for i,z in enumerate(words) if z==0xd2800015];assert len(init)==1,init
mut=bytearray(raw);mut[init[0]*4:init[0]*4+4]=struct.pack('<I',0xd503201f);blob,off=wrap(bytes(mut),int((C/'dominated-loop/candidate-walk.offset').read_text()));p=D/'no-cache-flag-init.bin';p.write_bytes(blob)
q2=subprocess.run([str(OLD/'full-state-loader'),str(p),str(off),'2','aarch64','-','vi:11,13,17','1'],env=env,capture_output=True,text=True);(D/'no-cache-flag-init.log').write_text(q2.stdout+q2.stderr);assert q2.returncode!=0,(q2.returncode,q2.stdout,q2.stderr)
(D/'callee-proof.json').write_text(json.dumps({'status':'PASS actual exported stable-loop native callee-preservation sentinels x19..x28 and two machine restore/flag-init mutants detected','pairs':len(rows),'mutantWord':atword,'flagInitMutantWord':init[0],'flagInitMutantExit':q2.returncode,'actualMachineMutantsDetected':2,'rows':rows,'limits':'Checked public success returns; no claim callee values survive a terminal trap or OS stack ceiling.'},indent=2)+'\n')
