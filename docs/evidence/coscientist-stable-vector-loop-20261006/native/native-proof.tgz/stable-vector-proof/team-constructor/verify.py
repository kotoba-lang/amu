exec((__import__('pathlib').Path('/private/tmp/amu-stable-vector-loop-20261006/team-constructor/baseline.py')).read_text().split('rows=[]')[0])
I=D.parent/'implementation';rows=[];public=[]
for name in json.loads((D/'cases.json').read_text()):
 d=D/name
 for stage,args in [('compile',['compile',str(D/(name+'.kotoba')),'--target','aarch64-macos','--output',str(d/'candidate.kseed')]),('extract',['extract-native',str(d/'candidate.kseed'),'--symbol','run','--output',str(d/'candidate.bin')])]:
  q=subprocess.run([str(O/'kexe-loader'),str(I/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/('candidate-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,stage,q.stdout,q.stderr)
  if stage=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1]);(d/'candidate.offset').write_text(str(off)+'\n')
 for x in [r for r in json.loads((D/'baseline.json').read_text())['rows'] if r['case']==name]:
  e=dict(os.environ,KEXE_FUEL=str(x['fuel']),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
  q=subprocess.run([str(O/'full-state-loader'),str(d/'candidate.bin'),str(off),'1','aarch64','-',str(x['n'])],env=e,capture_output=True,text=True)
  assert q.returncode==x['exit'] and q.stdout==x['stdout'] and q.stderr==x['stderr'],(name,x,q.returncode,q.stdout,q.stderr)
  rows.append({'baseline':x,'candidate':{'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}})
 q=subprocess.run([str(O/'kexe-loader'),str(I/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--','extract-native',str(d/'candidate.kseed'),'--symbol','walk','--output',str(d/'candidate-walk.bin')],env=env,capture_output=True,text=True);assert q.returncode==0;(d/'candidate-walk-extract.log').write_text(q.stdout+q.stderr);off=int(re.search(r':offset (\d+)',q.stdout)[1]);(d/'candidate-walk.offset').write_text(str(off)+'\n')
 for x in [r for r in json.loads((D/'public-baseline.json').read_text())['rows'] if r['case']==name]:
  e=dict(os.environ,KEXE_FUEL=str(x['fuel']),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
  q=subprocess.run([str(O/'full-state-loader'),str(d/'candidate-walk.bin'),str(off),'2','aarch64','-',str(x['handle']),str(x['n'])],env=e,capture_output=True,text=True)
  assert q.returncode==x['exit'] and q.stdout==x['stdout'] and q.stderr==x['stderr'],(name,x,q.returncode,q.stdout,q.stderr)
  public.append({'baseline':x,'candidate':{'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}})
 print('PASS actual stable candidate',name,flush=True)
(D/'semantic.json').write_text(json.dumps({'status':'PASS','ordinaryComparisons':len(rows),'publicFirstReadComparisons':len(public),'rows':rows,'publicRows':public},indent=2)+'\n')
