#include <sys/mman.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libkern/OSCacheControl.h>
extern void stable_invoke(void*,void*,uint64_t*);
struct vec {uint64_t offset,len;};
int main(int argc,char**argv){if(argc!=3)return 9;uint64_t fuel[2],ref=0;unsigned pass=0,detected=0;
for(unsigned arm=0;arm<3;arm++){
 const char *path=argv[arm?2:1];FILE*f=fopen(path,"rb");if(!f)return 10;fseek(f,0,SEEK_END);size_t n=ftell(f);rewind(f);uint8_t*raw=malloc(n);fread(raw,1,n,f);fclose(f);
 uint32_t*code=mmap(0,(n+4095)&~4095,PROT_READ|PROT_WRITE|PROT_EXEC,MAP_PRIVATE|MAP_ANON|MAP_JIT,-1,0);if(code==MAP_FAILED)return 11;
 pthread_jit_write_protect_np(0);memcpy(code,raw,n);if(arm==2){if(code[3]!=0xa90053f3 || code[4]!=0xf9000bf5)return 12;code[3]=code[4]=0xd503201f;}pthread_jit_write_protect_np(1);sys_icache_invalidate(code,n);
 uint64_t used=1,ctx[50]={0},items[3]={11,13,17},out[27]={0};struct vec vector={0,3};ctx[1]=1048576;ctx[39]=(uint64_t)&used;ctx[40]=(uint64_t)&vector;ctx[41]=(uint64_t)items;stable_invoke(code,ctx,out);
 int good=out[0]==37;for(unsigned j=0;j<10;j++)if(out[16+j]!=119+j)good=0;for(unsigned j=0;j<3;j++)if(items[j]!=(j==0?11:j==1?13:17))good=0;
 if(arm<2){if(!good)return 2;fuel[arm]=ctx[1];if(arm==1&&fuel[0]!=fuel[1])return 3;pass++;}else{if(good)return 4;detected++;}
 printf("{\"arm\":%u,\"result\":%llu,\"fuel\":%llu,\"calleePreserved\":%s}\n",arm,(unsigned long long)out[0],(unsigned long long)ctx[1],good?"true":"false");
}
printf("{\"status\":\"PASS\",\"actualBaselineCandidateABIPairs\":1,\"actualNativeCalleeSaveMutantsDetected\":%u,\"calleeRegisters\":\"x19..28\"}\n",detected);return 0;}
