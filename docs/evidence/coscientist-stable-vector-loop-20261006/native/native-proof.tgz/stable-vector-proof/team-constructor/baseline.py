from pathlib import Path
import subprocess,os,re,json
D=Path(__file__).resolve().parent;O=Path('/private/tmp/amu-private-length-clones-20261006');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/private/tmp:/Users/junkawasaki/github/wt/amu-seed17',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTOR_ITEMS='134217728',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216')
rows=[]
for name,c in json.loads((D/'cases.json').read_text()).items():
 d=D/name;d.mkdir(exist_ok=True)
 for stage,args in [('compile',['compile',str(D/(name+'.kotoba')),'--target','aarch64-macos','--output',str(d/'baseline.kseed')]),('extract',['extract-native',str(d/'baseline.kseed'),'--symbol','run','--output',str(d/'baseline.bin')])]:
  q=subprocess.run([str(O/'kexe-loader'),str(O/'seed-0.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,stage,q.stdout,q.stderr)
  if stage=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1]);(d/'baseline.offset').write_text(str(off)+'\n')
 for n in [0,1,2,4]:
  for fuel in [1,2,3,7,31,1048576]:
   e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
   q=subprocess.run([str(O/'full-state-loader'),str(d/'baseline.bin'),str(off),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True)
   rows.append({'case':name,'n':n,'fuel':fuel,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
 print('PASS baseline',name,flush=True)
(D/'baseline.json').write_text(json.dumps({'rows':rows},indent=2)+'\n')
