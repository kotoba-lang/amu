exec((__import__('pathlib').Path('/private/tmp/amu-stable-vector-loop-20261006/team-constructor/verify.py')).read_text().split('I=D.parent')[0])
import hashlib
I=D.parent/'implementation';base=(I/'unity.kotoba').read_text();MD=D/'mutants';MD.mkdir(exist_ok=True)
def build(src,compiler,out,symbol):
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(out.with_suffix('.kseed'))]),('extract',['extract-native',str(out.with_suffix('.kseed')),'--symbol',symbol,'--output',str(out)])]:
  q=subprocess.run([str(O/'kexe-loader'),str(compiler),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(MD/(out.stem+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(stage,q.stdout[-300:],q.stderr[-300:])
  if stage=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1])
 return off
variants=[('flag-initialized-valid', [('(enc-movz (sl-flag M) 0 0)','(enc-movz (sl-flag M) 1 0)')],'dominated-loop',0),
 ('false-dominance-through-joins', [('(if (not= (gn-g M gn-f-vmode) 2) (gn-vstep M op a)','(if (not= (gn-g M gn-f-vmode) 2) (if (= (gn-g M gn-f-vmode) 3) M (gn-vstep M op a))')],'independent-condition',2),
 ('bad-stable-local-admission', [('(if (> chosen 0) 0 (sl-pick M f np (inc k) (inc k)))','(if (> chosen 0) (sl-pick M f np (inc k) chosen) (sl-pick M f np (inc k) (inc k)))'),('(= (sl-origin M (dec j) (inc start) b) slot))\n                    (= op OP-LABEL)','true)\n                    (= op OP-LABEL)'),('(if (not= slot (gn-g M 15)) (gn-err M E-GEN-OP OP-RT)','(if false (gn-err M E-GEN-OP OP-RT)')],'two-vector',1)]
records=[]
for name,replacements,case,n in variants:
 source=base
 for old,new in replacements:assert source.count(old)==1,(name,old,source.count(old));source=source.replace(old,new,1)
 src=MD/(name+'-compiler.kotoba');src.write_text(source);compiler=MD/(name+'-compiler.bin');assert build(src,O/'seed-0.bin',compiler,'main')==0
 target=MD/(name+'-target.bin');off=build(D/(case+'.kotoba'),compiler,target,'run');e=dict(os.environ,KEXE_FUEL='1048576',KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
 q=subprocess.run([str(O/'full-state-loader'),str(target),str(off),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True);ref=next((r for r in json.loads((D/'baseline.json').read_text())['rows'] if r['case']==case and r['n']==n and r['fuel']==1048576),None)
 if ref is None:
  untraced=MD/'two-vector-baseline.bin';boff=build(D/'two-vector.kotoba',O/'seed-0.bin',untraced,'run');bq=subprocess.run([str(O/'full-state-loader'),str(untraced),str(boff),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True);ref={'case':case,'n':n,'fuel':1048576,'exit':bq.returncode,'stdout':bq.stdout,'stderr':bq.stderr};assert bq.returncode!=0 and 'KEXE_TRAP' in bq.stderr
  safe=MD/'two-vector-candidate.bin';soff=build(D/'two-vector.kotoba',I/'seed-4.bin',safe,'run');sq=subprocess.run([str(O/'full-state-loader'),str(safe),str(soff),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True);assert (sq.returncode,sq.stdout,sq.stderr)==(bq.returncode,bq.stdout,bq.stderr)
 actual={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};assert actual!={k:ref[k] for k in actual},(name,actual)
 records.append({'mutant':name,'case':case,'n':n,'detected':True,'compilerSha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'baseline':ref,'mutantObservation':actual});print('PASS actual native source mutant detected',name,flush=True)
(D/'mutants.json').write_text(json.dumps({'status':'PASS','records':records},indent=2)+'\n')
