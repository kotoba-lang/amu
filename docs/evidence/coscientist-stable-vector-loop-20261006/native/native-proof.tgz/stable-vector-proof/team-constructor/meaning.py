from pathlib import Path
import json,re
D=Path(__file__).resolve().parent;rows=json.loads((D/'baseline.json').read_text())['rows'];checks=[]
for r in rows:
 if r['fuel']!=1048576:continue
 name=r['case'];n=r['n'];want=None
 if name in ['dominated-loop','same-vector-phi']:want=11+13*n
 elif name=='loop-first-read':want=30*n
 elif name=='conditional-first':want=0 if n==0 else 11+13*n
 elif name=='independent-condition':want=(0 if n%2==0 else 11)+13*n
 elif name=='both-first-join':want=11 if n==0 else 17+13*n
 elif name=='vector-local-change':want=0 if n==0 else 13 if n==1 else 'trap'
 elif name=='write-loop':want=11+n*(n-1)//2
 elif name=='alloc-callee':want=11+15*n
 elif name=='cap-loop':want=11 if n==0 else 'trap'
 elif name=='direct-callee':want=11+13*n+n*(n+1)//2
 elif name=='indirect-callee':want=11+13*n+n*(n+1)//2
 elif name in ['negative-index','upper-index']:want=11 if n==0 else 'trap'
 assert want is not None
 if want=='trap':assert r['exit']!=0 and 'KEXE_TRAP' in r['stderr'],r
 else:assert r['exit']==0 and int(re.search(r':result (-?\d+)',r['stdout'])[1])==want,r
 checks.append({'case':name,'n':n,'independentExpected':want})
(D/'meaning.json').write_text(json.dumps({'status':'PASS source-level independent mathematical result/trap oracle','checks':checks,'finiteInputs':[0,1,2,4],'timing':False},indent=2)+'\n');print('PASS source-level meaning',len(checks))
