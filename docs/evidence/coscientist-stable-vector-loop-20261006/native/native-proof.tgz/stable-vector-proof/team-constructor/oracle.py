from pathlib import Path
from collections import deque
import subprocess,os,re,json
D=Path(__file__).resolve().parent;O=Path('/private/tmp/amu-private-length-clones-20261006');unity=(O/'unity.kotoba').read_text();C={n:int(v) for n,v in re.findall(r'\(def ([A-Z][A-Z0-9-]*) (-?\d+)\)',unity)};OP=lambda n:C['OP-'+n]
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/private/tmp:/Users/junkawasaki/github/wt/amu-seed17',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTOR_ITEMS='134217728',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216');rows=[]
for name in json.loads((D/'cases.json').read_text()):
 target=D/name/'observer.kseed';q=subprocess.run([str(O/'kexe-loader'),str(O/'observer/seed.bin'),'0','0','aarch64','35,37,38,39','--','compile',str(D/(name+'.kotoba')),'--target','aarch64-macos','--output',str(target)],env=env,capture_output=True,text=True);assert q.returncode==0,(name,q.stderr);log=q.stdout+q.stderr;(D/name/'observer-compile.log').write_text(log);section=log.split('PCPHASE ')[1];sir={};ff={}
 for l in section.splitlines():
  tok=l.split()
  if tok and tok[0]=='SIR':sir[int(tok[1])]=tuple(map(int,tok[2:]))
  if tok and tok[0]=='PCFF':f,k,v=map(int,tok[1:]);ff.setdefault(f,{})[k]=v
 for f,meta in ff.items():
  p=meta[C['FF-SIR']];np=meta[C['FF-NPARAMS']];ns=meta[C['FF-NSLOTS']];dp=meta[C['FF-DEPTH']]
  if not np or meta[C['FF-PT0']]!=C['TY-VEC']:continue
  end=next(i for i in range(p+1,max(sir)+1) if sir[i][0]==OP('END'))
  labels={a:i for i,(op,a,b,c) in sir.items() if p<i<end and op==OP('LABEL')};reasons=[]
  for i in range(p+1,end):
   op,a,b,c=sir[i]
   if op in [OP(x) for x in ['CALL','CALLI','CAP','VEC','VECP','STR','FADDR']]:reasons.append(['effect-or-call',i,op])
   if op==OP('RT') and a not in [C['RT-VECTOR-AT'],C['RT-VECTOR-COUNT']]:reasons.append(['non-readonly-runtime',i,a])
   if op==OP('LSET') and a==1:reasons.append(['root-vector-local-written',i])
  eligible=not reasons and ns<=16 and dp<=16
  incoming={p+1:((True,)+(False,)*(max(ns,np)-1),(False,)*dp,False)};work=deque([p+1]);steps=0
  def meet(node,state):
   old=incoming.get(node)
   if old is None:new=state
   else:new=(tuple(x and y for x,y in zip(old[0],state[0])),tuple(x and y for x,y in zip(old[1],state[1])),old[2] and state[2])
   if new!=old:incoming[node]=new;work.append(node)
  while work:
   steps+=1;assert steps<=128*(end-p)
   i=work.popleft();op,a,b,c=sir[i];ll,tt,w=incoming[i];l=list(ll);t=list(tt)
   if op in [OP('RET'),OP('END')]:continue
   if op==OP('LGET'):t[a]=l[b-1]
   elif op==OP('LSET'):l[a-1]=t[b];w=w if a!=1 or t[b] else False
   elif op==OP('CONST'):t[a]=False
   elif op in [OP('BIN'),OP('CMP'),OP('UN')]:t[b]=False
   elif op==OP('RT'):
    if a==C['RT-VECTOR-AT'] and t[b]:w=True
    elif a not in [C['RT-VECTOR-AT'],C['RT-VECTOR-COUNT']]:w=False;l=[False]*len(l)
    t[b]=False
   elif op in [OP('CALL'),OP('CALLI'),OP('CAP'),OP('VEC'),OP('VECP')]:w=False;l=[False]*len(l);t=[False]*len(t)
   state=(tuple(l),tuple(t),w)
   if op==OP('BR'):meet(labels[a],state)
   elif op in [OP('BRZ'),OP('BRNZ')]:meet(labels[b],state);meet(i+1,state)
   else:meet(i+1,state)
  accesses=[]
  for i,state in sorted(incoming.items()):
   op,a,b,c=sir[i]
   if op==OP('RT') and a==C['RT-VECTOR-AT']:accesses.append({'site':i,'rootVectorInput':state[1][b],'mustValidatedBefore':state[2],'semanticReusePermitted':eligible and state[1][b] and state[2]})
  rows.append({'case':name,'function':f,'sourceRange':[p,end],'semanticReadOnlyStableAdmission':eligible,'reasons':reasons,'steps':steps,'accesses':accesses,'registerAdmissionNotAssessedHere':True})
 print('PASS finite original SIR witness',name,flush=True)
(D/'oracle.json').write_text(json.dumps({'status':'PASS independent must-CFG root-vector validation witness oracle','rows':rows,'finiteBudget':'128 * actual source-body nodes','notCompilerRegisterOrCodegenAdmission':True},indent=2)+'\n')
