exec((__import__('pathlib').Path('/private/tmp/amu-stable-vector-loop-20261006/team-constructor/verify.py')).read_text().split('I=D.parent')[0])
import struct,hashlib
I=D.parent/'implementation';ad=json.loads((D/'admission.json').read_text())['rows'];rows=[]
for name in json.loads((D/'cases.json').read_text()):
 d=D/name
 for stage,args in [('compile',['compile',str(D/(name+'.kotoba')),'--target','aarch64-macos','--output',str(d/'candidate-observer.kseed')]),('extract',['extract-native',str(d/'candidate-observer.kseed'),'--symbol','run','--output',str(d/'candidate-observer.bin')])]:
  q=subprocess.run([str(O/'kexe-loader'),str(I/'observer/seed.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/('candidate-observer-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,stage,q.stderr)
  if stage=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1])
 assert (d/'candidate-observer.bin').read_bytes()==(d/'candidate.bin').read_bytes() and off==int((d/'candidate.offset').read_text())
 events=[list(map(int,l.split()[1:])) for l in (d/'candidate-observer-compile.log').read_text().splitlines() if l.startswith('SLADMIT ')]
 expected=[r['function'] for r in ad if r['case']==name and r['structuralCandidateShape']];assert [e[0] for e in events]==expected,(name,expected,events)
 words=list(struct.unpack('<'+'I'*((d/'candidate.bin').stat().st_size//4),(d/'candidate.bin').read_bytes()[:(d/'candidate.bin').stat().st_size//4*4]));checks=[]
 for e in events:
  f,site,slot,old,new,frame,end=e;length=16+new;base=17+new;flag=18+new
  refs=[i for i,w in enumerate(words) if w==0xb5000000|(13<<5)|flag]
  # Every actual retained flag guard jumps exactly over original handle check + capture.
  for i in refs:
   assert words[i+1]&0xffc00000==0xf9400000
   assert words[i+13]&0xff20001f==0xeb00001f
   assert words[i+14]==0x54000043 and words[i+15]==0
   assert words[i+12]==0xd2800000|(1<<5)|flag
  original=next(r for r in ad if r['case']==name and r['function']==f);assert len(refs)==original['readCount'],(name,original,refs)
  checks.append({'function':f,'oldNsv':old,'newNsv':new,'cacheRegs':[length,base,flag],'guardSitesWords':refs,'allBoundsChecksAndZeroUdfRemain':True,'ordinaryReadSitesAlwaysRetainFlagGuard':True})
 rows.append({'case':name,'observerBytesAndOffsetEqual':True,'expectedStructuralFunctions':expected,'actualAdmit':events,'machineGuardChecks':checks});print('PASS actual admission/flagguard',name,len(events),flush=True)
(D/'emit-check.json').write_text(json.dumps({'status':'PASS independent original-SIR structural oracle vs byte-exact actual admission and flag guards','rows':rows,'omittedOrdinaryRtGuards':0},indent=2)+'\n')
