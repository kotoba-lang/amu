exec((__import__('pathlib').Path(__file__).resolve().parent/'oracle-portable.py').read_text().split('for name in json.loads')[0])
rows=[]
for name in json.loads((D/'cases.json').read_text()):
 log=(D/name/'observer-compile.log').read_text().split('PCPHASE ')[1];sir={};ff={}
 for line in log.splitlines():
  q=line.split()
  if q and q[0]=='SIR':sir[int(q[1])]=tuple(map(int,q[2:]))
  if q and q[0]=='PCFF':f,k,v=map(int,q[1:]);ff.setdefault(f,{})[k]=v
 for f,m in ff.items():
  np=m[C['FF-NPARAMS']];vecs=[k+1 for k in range(np) if m.get(C['FF-PT0']+k)==C['TY-VEC']]
  if not vecs:continue
  slot=vecs[0];start=m[C['FF-SIR']];end=next(i for i in range(start+1,max(sir)+1) if sir[i][0]==OP('END'));reasons=[];reads=0;backs=0;defs={};labels={}
  for i in range(start+1,end):
   op,a,b,c=sir[i]
   if op==OP('LABEL'):labels.setdefault(a,[]).append(i)
  for i in range(start+1,end):
   op,a,b,c=sir[i];good=True
   if op in [OP(x) for x in ['LABEL','BR','BRZ','BRNZ']]:
    target=a if op in [OP('LABEL'),OP('BR')] else b;good=target in labels and len(labels[target])==1 and 0<target<C['MM-LABEL-CAP'];backs+=int(op!=OP('LABEL') and good and labels[target][0]<i);defs.clear()
   elif op==OP('LSET'):good=a!=slot or defs.get(b)==slot
   elif op==OP('RT'):reads+=1;good=a==C['RT-VECTOR-AT'] and c==2 and 0<=b<=5 and defs.get(b)==slot;defs[b]=None
   elif op==OP('LGET'):defs[a]=b
   elif op==OP('CONST'):defs[a]=None
   elif op in [OP('BIN'),OP('CMP'),OP('UN')]:good=a<C[{'BIN':'BOP-F64-ADD','CMP':'CC-F64-EQ','UN':'UOP-F64-NEG'}[next(n for n in ['BIN','CMP','UN'] if op==OP(n))]];defs[b]=None
   elif op in [OP('RET'),OP('FUEL')]:pass
   else:good=False;defs.clear()
   if not good:reasons.append({'site':i,'op':op,'operands':[a,b,c]})
  structural=(1<=np<=5 and len(vecs)==1 and all(m.get(C['FF-PT0']+k) in [C['TY-VEC'],C['TY-I64'],C['TY-BOOL']] for k in range(np)) and end-start<=8192 and reads>=2 and backs>0 and not reasons)
  rows.append({'case':name,'function':f,'chosenVectorParameter':slot,'structuralCandidateShape':structural,'readCount':reads,'localBackedges':backs,'invalidSites':reasons,'oldMachineLeafFrameAndOwnershipAdmissionPending':True})
(D/'admission.json').write_text(json.dumps({'status':'PASS independent forward-block reaching-origin structural admission oracle','rows':rows,'matchesFrozenSourceContract':'semantic/SIR part only; machine leaf/frame/ownership separate'},indent=2)+'\n');print([(r['case'],r['structuralCandidateShape']) for r in rows])
