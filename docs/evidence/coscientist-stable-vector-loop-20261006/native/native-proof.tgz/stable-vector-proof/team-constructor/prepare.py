from pathlib import Path
import json
D=Path(__file__).resolve().parent
cases={
'dominated-loop':'(defn- walk [v :vector-i64 n :i64] :i64 (let [first (vector-at v 0)] (loop [i 0 s first] (if (= i n) s (recur (+ i 1) (+ s (vector-at v 1)))))))',
'loop-first-read':'(defn- walk [v :vector-i64 n :i64] :i64 (loop [i 0 s 0] (if (= i n) s (recur (+ i 1) (+ s (vector-at v 1) (vector-at v 2))))))',
'conditional-first':'(defn- walk [v :vector-i64 n :i64] :i64 (let [first (if (= n 0) 0 (vector-at v 0))] (loop [i 0 s first] (if (= i n) s (recur (+ i 1) (+ s (vector-at v 1)))))))',
'both-first-join':'(defn- walk [v :vector-i64 n :i64] :i64 (let [first (if (= n 0) (vector-at v 0) (vector-at v 2))] (loop [i 0 s first] (if (= i n) s (recur (+ i 1) (+ s (vector-at v 1)))))))',
'vector-local-change':'(defn- walk [v :vector-i64 n :i64] :i64 (loop [v v i 0 s 0] (if (= i n) s (recur (if (= i 0) [7] v) (+ i 1) (+ s (vector-at v 1))))))',
'write-loop':'(defn- walk [v :vector-i64 n :i64] :i64 (let [first (vector-at v 0)] (loop [i 0 s first] (if (= i n) s (let [changed (vector-assoc! v 1 i)] (recur (+ i 1) (+ s (vector-at changed 1))))))))',
'alloc-callee':'(defn- fresh [n :i64] :vector-i64 (vector-alloc n))\n(defn- walk [v :vector-i64 n :i64] :i64 (let [first (vector-at v 0)] (loop [i 0 s first] (if (= i n) s (let [other (fresh 2)] (recur (+ i 1) (+ s (vector-at v 1) (vector-count other))))))))',
'indirect-callee':'(defn- invoke [f [:fn [[:i64] :i64]] n :i64] :i64 (f n))\n(defn- walk [v :vector-i64 n :i64] :i64 (let [first (vector-at v 0)] (loop [i 0 s first] (if (= i n) s (recur (+ i 1) (+ s (vector-at v 1) (invoke (fn [x] (+ x 1)) i)))))))',
'negative-index':'(defn- walk [v :vector-i64 n :i64] :i64 (let [first (vector-at v 0)] (loop [i 0 s first] (if (= i n) s (recur (+ i 1) (+ s (vector-at v -1)))))))',
'upper-index':'(defn- walk [v :vector-i64 n :i64] :i64 (let [first (vector-at v 0)] (loop [i 0 s first] (if (= i n) s (recur (+ i 1) (+ s (vector-at v 3)))))))',
}
for name,defs in cases.items():
 src='(ns stable.'+name+' (:export [run walk]))\n'+defs+'\n(defn run [n :i64] :i64 (walk [11 13 17] n))\n';(D/(name+'.kotoba')).write_text(src)
(D/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
