from pathlib import Path
import json,re,struct,collections,copy
W=Path(__file__).resolve().parent;B=Path('/private/tmp/amu-static-vector-chain-20261006/observer/meta-ports')
def branch(z):
 def sg(n,b):return n-(1<<b) if n&(1<<(b-1)) else n
 if z&0x7c000000==0x14000000:return z&0xfc000000,sg(z&0x3ffffff,26)
 if z&0xff000010==0x54000000:return z&0xff00001f,sg((z>>5)&0x7ffff,19)
 if z&0x7e000000==0x34000000:return z&0xff00001f,sg((z>>5)&0x7ffff,19)
 if z&0x7e000000==0x36000000:return z&0xfff8001f,sg((z>>5)&0x3fff,14)
 if z&0x9f000000==0x10000000:return z&0x9f00001f,sg(((z>>5)&0x7ffff)*4+((z>>29)&3),21)/4
 return None
def parse(p):
 d={'sir':{},'fn':{},'events':[],'fix':[],'raw':(p/'native.bin').read_bytes()}
 for l in (p/'compile.log').read_text().splitlines():
  x=l.split()
  if not x:continue
  if x[0]=='SIR':d['sir'][int(x[1])]=tuple(map(int,x[2:]))
  if x[0]=='FN':d['fn'][int(x[1])]=tuple(map(int,x[2:]))
  if x[0]=='EMIT':d['events'].append(tuple(map(int,x[1:])))
  if x[0]=='FIX':d['fix'].append(tuple(map(int,x[1:])))
 d['n']=max(e[3] for e in d['events']);d['words']=[x[0] for x in struct.iter_unpack('<I',d['raw'][:4*(d['n']-1)])];return d
def block(f):return [0xf940c8f0,0xd2800011|(f<<5),0x8b110e10,0xf9400211,0x91000631,0xf9000211]
def normalized(d,traced):
 words=d['words'];stream=[];pos={};edges=[];blocks=[];fnbycode={v[-1]:f for f,v in d['fn'].items()};lit={}
 for ix,at,kind,t,aux in d['fix']:
  if kind==5:lit[at]=(t,0);lit[at+1]=(t,1)
 i=1
 while i<d['n']:
  if traced and i+5<d['n'] and words[i-1:i+5]==block((words[i]>>5)&65535):
   f=(words[i]>>5)&65535;assert f in d['fn'];start=d['fn'][f][-1]
   fn_event=next(e for e in d['events'] if d['sir'][e[0]][:2]==(1,f))
   assert fn_event[2]<=i and i+6<=fn_event[3],(f,i,'entry range')
   if words[start-1]==0xd2800005:assert i>=start+1
   for k in range(6):pos[i+k]=len(stream)
   blocks.append((f,i));i+=6;continue
  pos[i]=len(stream);z=words[i-1];q=branch(z)
  if q:stream.append(('BR',q[0]));edges.append((len(stream)-1,i+q[1]))
  elif i in lit:stream.append(('LIT',lit[i],z&~0x1fffe0))
  else:stream.append(('WORD',z))
  i+=1
 pos[d['n']]=len(stream);return stream,pos,edges,blocks

def audit(a,b):
 assert a['sir']==b['sir'];assert a['fn'].keys()==b['fn'].keys()
 for f,v in a['fn'].items():assert v[:-1]==b['fn'][f][:-1]
 assert [(x[0],x[1]) for x in a['events']]==[(x[0],x[1]) for x in b['events']]
 aa,pa,ea,ba=normalized(a,False);bb,pb,eb,blocks=normalized(b,True);assert aa==bb,next(((i,x,y) for i,(x,y) in enumerate(zip(aa,bb)) if x!=y),(len(aa),len(bb)))
 assert len(blocks)==len(a['fn']) and len({f for f,i in blocks})==len(blocks)
 for f,v in a['fn'].items():assert pa[v[-1]]==pb[b['fn'][f][-1]]
 for x,y in zip(ea,eb):assert x[0]==y[0] and pa[x[1]]==pb[y[1]],('edge',x,y)
 assert len(ea)==len(eb)
 for x,y in zip(a['events'],b['events']):assert pa[x[2]]==pb[y[2]] and pa[x[3]]==pb[y[3]]
 assert len(a['fix'])==len(b['fix']);private=0;literal=0
 ap=(a['n']-1)*4;bp=(b['n']-1)*4;ap=(ap+7)//8*8;bp=(bp+7)//8*8
 for x,y in zip(a['fix'],b['fix']):
  ix,at,k,t,u=x;iy,bt,l,s,v=y;assert (ix,k,t,u)==(iy,l,s,v) and pa[at]==pb[bt]
  if k==5:
   assert pa[at+1]==pb[bt+1]
   old=((a['words'][at-1]>>5)&65535)|(((a['words'][at]>>5)&65535)<<16);new=((b['words'][bt-1]>>5)&65535)|(((b['words'][bt]>>5)&65535)<<16);assert old-ap==new-bp;literal+=2
  if u:
   assert k==4 and u==1;oe=a['fn'][t][-1];ne=b['fn'][t][-1];assert a['words'][oe-1]==b['words'][ne-1]==0xd2800005
   assert at+branch(a['words'][at-1])[1]==oe+1 and bt+branch(b['words'][bt-1])[1]==ne+1;assert (t,ne+1) in blocks;private+=1
 assert a['raw'][ap:]==b['raw'][bp:];assert set(a['raw'][(a['n']-1)*4:ap])<= {0};assert set(b['raw'][(b['n']-1)*4:bp])<= {0}
 assert b['n']-a['n']==6*len(blocks)
 return {'entryBlocks':len(blocks),'addedWords':6*len(blocks),'retainedWords':len(aa),'branchTargets':len(ea),'literalWords':literal,'privateAux1':private,'blocks':blocks}
rows=[];tot=collections.Counter();details={}
for p in sorted((W/'ports').iterdir()):
 a=parse(B/p.name);b=parse(p/'observer');r=audit(a,b);details[p.name]=r;tot.update({k:v for k,v in r.items() if isinstance(v,int)});rows.append({'workload':p.name,**{k:v for k,v in r.items() if k!='blocks'}});print('PASS entry normalized all words/edges/fixups',p.name,flush=True)
controls=[];a=parse(B/'statemate');b=parse(W/'ports/statemate/observer')
for name,word,mask in [('trace opcode',details['statemate']['blocks'][0][1],1),('trace slot',details['statemate']['blocks'][0][1]+1,32),('flag setting increment',details['statemate']['blocks'][0][1]+4,0x20000000),('private marker',b['fn'][363][-1],1)]:
 d=copy.deepcopy(b);d['words'][word-1]^=mask
 try:audit(a,d)
 except (AssertionError,KeyError,IndexError) as e:controls.append({'name':name,'status':'REFUSED','diagnostic':str(e)[:300]})
 else:raise AssertionError('fault accepted '+name)
(W/'machine-audit.json').write_text(json.dumps({'status':'PASS all19 actual native full normalized machine/CFG/private/literal/entry-contract audit','totals':dict(tot),'rows':rows,'controls':controls,'limits':'Only actual six-word bounded nonflag x16/17 entry blocks removed. Typed source/runtime supervisor validity and reserved entry scratch contracts assumed; physical counts not cost. All emitted SIR/fusion ranges and FN frame/register/leaf metadata preserved.'},indent=2)+'\n');(W/'entry-blocks.json').write_text(json.dumps(details,indent=2)+'\n');print('PASS totals',dict(tot),flush=True)
