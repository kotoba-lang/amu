; benchmark generated from python API
(set-info :status unknown)
(declare-fun count () (_ BitVec 64))
(declare-fun h () (_ BitVec 64))
(declare-fun cached_length () (_ BitVec 64))
(declare-fun length () (_ BitVec 64))
(declare-fun cached_base () (_ BitVec 64))
(declare-fun base () (_ BitVec 64))
(declare-fun i () (_ BitVec 64))
(declare-fun items () (Array (_ BitVec 64) (_ BitVec 64)))
(assert
 (and (and (distinct h (_ bv0 64)) true) (bvult (bvsub h (_ bv1 64)) count)))
(assert
 (= length cached_length))
(assert
 (= base cached_base))
(assert
 (let ((?x28 (select items (bvadd cached_base (bvshl i (_ bv3 64))))))
(let ((?x26 (select items (bvadd base (bvshl i (_ bv3 64))))))
(let (($x21 (bvult i cached_length)))
(let (($x20 (bvult i length)))
(let (($x19 (and (and (distinct h (_ bv0 64)) true) (bvult (bvsub h (_ bv1 64)) count))))
(let (($x22 (and $x19 $x20)))
(or (and (distinct $x22 $x21) true) (and $x22 $x21 (and (distinct ?x26 ?x28) true))))))))))
(check-sat)
