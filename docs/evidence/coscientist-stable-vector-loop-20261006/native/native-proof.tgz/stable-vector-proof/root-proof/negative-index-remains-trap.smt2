; benchmark generated from python API
(set-info :status unknown)
(declare-fun length () (_ BitVec 64))
(declare-fun i () (_ BitVec 64))
(assert
 (bvsle length (_ bv1024 64)))
(assert
 (bvsge length (_ bv0 64)))
(assert
 (bvslt i (_ bv0 64)))
(assert
 (bvult i length))
(check-sat)
