; benchmark generated from python API
(set-info :status unknown)
(declare-fun fuel () (_ BitVec 64))
(declare-fun length () (_ BitVec 64))
(declare-fun i () (_ BitVec 64))
(declare-fun count () (_ BitVec 64))
(declare-fun h () (_ BitVec 64))
(assert
 (= fuel (_ bv0 64)))
(assert
 (let (($x20 (bvult i length)))
 (let (($x19 (and (and (distinct h (_ bv0 64)) true) (bvult (bvsub h (_ bv1 64)) count))))
 (and $x19 $x20))))
(assert
 (let (($x56 (= fuel (_ bv0 64))))
(let (($x20 (bvult i length)))
(let (($x19 (and (and (distinct h (_ bv0 64)) true) (bvult (bvsub h (_ bv1 64)) count))))
(let (($x22 (and $x19 $x20)))
(and $x22 $x56))))))
(check-sat)
