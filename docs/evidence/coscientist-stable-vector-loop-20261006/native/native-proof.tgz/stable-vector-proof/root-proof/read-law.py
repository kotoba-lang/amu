"""Specific bitvector read law under an explicit successful-validation witness."""
from pathlib import Path
import json
import z3 as z

D = Path(__file__).resolve().parent
h, count, i, length, cached_length, base, cached_base, fuel = z.BitVecs(
    'h count i length cached_length base cached_base fuel', 64)
items = z.Array('items', z.BitVecSort(64), z.BitVecSort(64))
handle_ok = z.And(h != 0, z.ULT(h - 1, count))
old_bounds, new_bounds = z.ULT(i, length), z.ULT(i, cached_length)
old_ok = z.And(handle_ok, old_bounds)
new_ok = new_bounds
old_result = z.Select(items, base + (i << 3))
new_result = z.Select(items, cached_base + (i << 3))
different = z.Or(old_ok != new_ok, z.And(old_ok, new_ok, old_result != new_result))
checks = []

def run(name, assumptions, bad, expected):
    s = z.Solver()
    s.add(*assumptions, bad)
    status = str(s.check())
    assert status == expected, (name, status)
    row = {'name': name, 'status': status}
    if status == 'sat': row['counterexample'] = str(s.model())
    checks.append(row)
    (D / (name + '.smt2')).write_text(s.to_smt2())

contract = [handle_ok, length == cached_length, base == cached_base]
run('validated-stable-descriptor', contract, different, 'unsat')
run('unsafe-no-validation', contract[1:], different, 'sat')
run('unsafe-length-change', [handle_ok, base == cached_base], different, 'sat')
run('unsafe-base-change', [handle_ok, length == cached_length], different, 'sat')
run('negative-index-remains-trap', [length <= 1024, length >= 0, i < 0],
    old_bounds, 'unsat')
# Same array at the current read is required. A cached element is not this rule.
cached_items = z.Array('cached_items', z.BitVecSort(64), z.BitVecSort(64))
run('unsafe-element-memoization', contract + [old_ok],
    old_result != z.Select(cached_items, cached_base + (i << 3)), 'sat')
# The law is local to a read after the same original charge, not a reordering law.
run('unsafe-fuel-check-erasure', [fuel == 0, old_ok],
    z.And(old_ok, fuel == 0), 'sat')
report = {'status': 'PASS-specific-stable-descriptor-read-law', 'checks': checks,
          'requiredWitness': 'Original successful handle validation, same stable handle, immutable descriptor length/base along dominated path',
          'freshCurrentItemsRead': True, 'unsignedIndexCheckRetained': True,
          'fuelAndTrapOrder': 'Original charge and first validation remain at original sites; not proved by this local law',
          'notProven': ['actual admission CFG/dominance', 'actual register and code layout',
                        'universal loop/compiler correctness', 'performance'],
          'TLCorTLAPSExecuted': False}
(D / 'read-law.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'checks': len(checks)}))
