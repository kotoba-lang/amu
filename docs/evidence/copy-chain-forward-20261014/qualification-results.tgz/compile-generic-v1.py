from pathlib import Path
import json,hashlib,subprocess,os,importlib.util
W=Path(__file__).parent;D=W/'generic-controls-v1';P=json.loads((D/'preparation.json').read_text());spec=importlib.util.spec_from_file_location('copy_gate',W/'native-gate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def pin(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
inputs=[P['source'],P['loader'],*P['producers'].values()]
for r in inputs:assert pin(r['path'])==r
E={k:v for k,v in os.environ.items()if not k.startswith('KEXE_')};E.update(KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(D),KEXE_FUEL='off',KEXE_VECTORS='4194304',KEXE_VECTOR_ITEMS='134217728',KEXE_STRING_POOL='268435456',KEXE_PAIRS='16777216',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',TMPDIR=str(D));arms={};calls=[]
for tag,r in P['producers'].items():
 k=D/(tag+'.kseed');b=D/(tag+'.bin');assert not k.exists()and not b.exists()
 for cmd,args in [('compile',['compile',P['source']['path'],'--target','aarch64-macos','--output',k]),('extract',['extract-native',k,'--symbol','probe','--output',b])]:
  z=subprocess.run(list(map(str,[P['loader']['path'],r['path'],'0','0','aarch64','35,37,38,39','--',*args])),cwd=D,env=E,capture_output=True,timeout=1800);(D/'raw'/(tag+'-'+cmd+'.stdout')).write_bytes(z.stdout);(D/'raw'/(tag+'-'+cmd+'.stderr')).write_bytes(z.stderr);calls.append(dict(tag=tag,cmd=cmd,exit=z.returncode));(D/'compiler-calls.json').write_text(json.dumps(calls,indent=2)+'\n');assert z.returncode==0 and not z.stderr
 h,p=k.read_bytes().split(b'\n\n',1);assert p==b.read_bytes();ex={n:[int(o),int(a)]for n,o,a in map(str.split,h.decode().splitlines()[1:])};assert ex['probe'][1]==1;arms[tag]=dict(source=P['source'],native=pin(b),container=pin(k),exports=ex)
for r in inputs:assert pin(r['path'])==r
review=m.audit(arms['OFF'],arms['ON']);assert review['changed'];(D/'physical-review.json').write_text(json.dumps(review,indent=2)+'\n');(D/'arms.json').write_text(json.dumps(arms,indent=2)+'\n');print('PASS_GENERIC_COPY_CHAINS_PHYSICAL',review['forwardedLoads'],review['omittedNarrow'])
