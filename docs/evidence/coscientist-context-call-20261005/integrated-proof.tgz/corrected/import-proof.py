from pathlib import Path
import importlib.util,subprocess,os,re,json,struct,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-context-call-sealed-20261005');old=Path('/private/tmp/amu-context-call-20261005')
sp=importlib.util.spec_from_file_location('fx',r/'scripts/seed/a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
names=[x[0] for x in m.FIX];sid=names.index('cp_scalar')+1;aid=names.index('cp_alloc')+1
parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba','seed/41-a64gen.kotoba','seed/42-layout.kotoba']
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_VECTOR_ITEMS='134217728',KEXE_PAIRS='16777216',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536');images={};rows=[]
for label in ['closed','open']:
 test=m.kotoba(True)
 if label=='open':test=test.replace('(gn-run M0)',f'(gn-run-open M0 {sid} 1)').replace('(>= closed 0)', '(= closed -1)')
 src=w/f'import-{label}.kotoba';src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+test)
 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/f'import-{label}.kseed')]),('extract',['extract-native',str(w/f'import-{label}.kseed'),'--symbol','main','--output',str(w/f'import-{label}.bin')])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/f'import-{label}-{mode}.log').write_text(q.stdout+q.stderr);assert q.returncode==0,(label,mode,q.stderr)
  if mode=='extract':offset=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/f'import-{label}.bin'),offset,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0,(label,q.stderr);(w/f'import-{label}.stdout').write_text(q.stdout)
 blob,fc=m.blob_from(q.stdout);mutated=bytearray(blob);at=fc[sid]//4;delta=(fc[aid]-fc[sid])//4;struct.pack_into('<I',mutated,at*4,0x14000000|(delta&0x03ffffff));path=w/f'import-{label}-linked.bin';path.write_bytes(mutated);images[label]=(path,fc)
for caller in ['call_cp_scalar','call_cp_chain0']:
 for args in [[0,1],[1,2],[2,4]]:
  pair={}
  for label,(path,fc) in images.items():
   e=dict(os.environ,KEXE_FUEL='16777216',KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
   q=subprocess.run([str(old/'clobber-state-loader'),str(path),str(fc[names.index(caller)+1]),'2','aarch64','-',*map(str,args)],env=e,capture_output=True,text=True,timeout=35)
   pair[label]={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
  assert pair['open']['exit']==0 and ':status :ok' in pair['open']['stdout'],(caller,args,pair)
  assert pair['closed']['exit']!=0 and 'KEXE_TRAP' in pair['closed']['stderr'],(caller,args,pair)
  rows.append({'caller':caller,'args':args,**pair})
out={'status':'complete-import-substitution-clobber-regression','mechanism':'Replace first instruction of a statically scalar typed stub with B to an allocating implementation, exactly like project linking. Diagnostic allocator poisons x7. Both direct and transitive callers succeed with explicit open-import boundary; closed-body assumption fails. This is a diagnostic control and never measured.','stubFN':sid,'realTargetFN':aid,'runs':rows,'pins':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [r/'seed/41-a64gen.kotoba',r/'seed/60-proj.kotoba',old/'clobber-state-loader',*(v[0] for v in images.values())]}}
(w/'import-proof.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS 6 actual linked-body substitutions, direct/transitive open calls succeed, closed assumption fails',flush=True)
