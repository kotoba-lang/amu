from pathlib import Path
import shutil,json
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-context-call-20261005');base=Path('/private/tmp/amu-masked-writer-20261005');g=(r/'seed/41-a64gen.kotoba').read_text()
helper=''';; Bounded structural proof that a direct callee returns with input x7.
;; A shared remaining-work budget counts all transitive SIR instructions; it
;; prevents exponential rescanning. Unknown effects/operations fail closed.
;; Caller frame, real call and every fuel/trap/publication boundary remain.
(defn- gn-ctx-safe [M :vector-i64 f :i64 n :i64 depth :i64 work :i64] :i64
  (let [p (gn-fnf M f FF-SIR)]
    (if (and (> f 0) (< f (vector-at M MM-FN-N)) (> p 0) (> depth 0) (> work 0)
             (<= n 7) (= (gn-op M p) OP-FN) (= (gn-sir M p IF-A) f) (= (gn-sir M p IF-B) n))
      (gn-ctx-scan M (inc p) f depth (dec work)) -1)))
(defn- gn-ctx-scan [M :vector-i64 j :i64 f :i64 depth :i64 work :i64] :i64
  (if (or (>= j (vector-at M MM-SIR-N)) (<= work 0)) -1
    (let [op (gn-op M j) a (gn-sir M j IF-A) b (gn-sir M j IF-B) c (gn-sir M j IF-C)
          left (dec work)]
      (case op
        OP-END (if (= a f) left -1)
        (OP-CONST OP-LGET OP-LSET OP-BIN OP-CMP OP-UN OP-LABEL OP-BR OP-BRZ OP-BRNZ OP-FUEL OP-RET OP-RET2 OP-RES2 OP-TRAP OP-TAB OP-FADDR)
        (gn-ctx-scan M (inc j) f depth left)
        OP-RT (if (gn-inl a b c) (gn-ctx-scan M (inc j) f depth left) -1)
        OP-CALL (let [remain (gn-ctx-safe M a c (dec depth) left)]
                  (if (< remain 0) -1 (gn-ctx-scan M (inc j) f depth remain)))
        -1))))

'''
a='(defn- gn-op-call [M';assert g.count(a)==1;g=g.replace(a,helper+a)
a='(gn-emit (enc-bl 0))\n      (gn-gs gn-f-ctx 0)';assert g.count(a)==1;g=g.replace(a,'(gn-emit (enc-bl 0))\n      (gn-gs gn-f-ctx (if (>= (gn-ctx-safe M f n 8 512) 0) 1 0))')
(w/'41-a64gen-prototype.kotoba').write_text(g);files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
for ext in ['bin','offset']:shutil.copyfile(base/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile(base/'kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['build.py','check-ports.py','bulk-state.py','prepare-timing.py','remote-all.py']:
 s=(base/name).read_text().replace('amu-masked-writer-20261005','amu-context-call-20261005').replace('amu-zebulun-masked-writer-20261005','amu-zebulun-context-call-20261005').replace('1d04fda6b354ba7463201b86a72e42f23626bbf8','533e1daa15a0fd2e502cdd55bf24bca30cca140c').replace('amu-scalar-tree-20261005','amu-masked-writer-20261005');(w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'sourceHead':'533e1daa15a0fd2e502cdd55bf24bca30cca140c','hypothesis':'Structural transitive direct-callee x7 preservation fact; keep gn-f-ctx known only when exact whitelisted SIR and all called dependencies pass, <=7 parameters, depth8 and shared512total instruction-work budget. No names or inferred textual effects. Caller classification/frame, actual calls, fuel/traps remain unchanged. Allocation/capabilities/unknown runtime/indirect calls and cycles without finite proof fall back.','promotion':'Native fixedpoint; original19 result/exactfuel/exhaustion and fullPico state; full supervisor proof and clobbering-call fallback/actual restoration audits; freshquiet30 changed originalC triples >=5% and gain>sumSD, no separated regressions.','exception':'One-off compiler algorithm authoring, not mechanical refactor'},indent=2)+'\n')
