from pathlib import Path
import importlib.util,subprocess,os,re,json,types,struct,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-context-call-20261005');sp=importlib.util.spec_from_file_location('fx',r/'scripts/seed/a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
targets=[];audits=[]
m.fx('fr_unknown',2,2,[('LGET',0,1),('LGET',1,2),('BIN','BOP-ADD',0),('RET',0)])
for charged in [0,1]:
 writer='fr_write'+str(charged);m.fx(writer,3,3,([('FUEL',)] if charged else [])+[('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('RET',0)])
 for nonleaf in [0,1]:
  for count in [3,7]:
   for trap in ['none','bounds','division','read']:
    name=f'fr_{charged}{nonleaf}_{count}_{trap}';body=[]
    if nonleaf:body+=[('CONST',0,1),('CONST',1,2),('CALL','fr_unknown',0,2)]
    for k in range(count):
     body+=[('FUEL',),('LGET',0,1)]
     body+=[('LGET',1,2)] if trap=='bounds' and k==1 else [('CONST',1,k%4)]
     if trap=='read' and k==1:
      body+=[('LGET',1,2),('RT','RT-VECTOR-AT',0,2),('LSET',4,0),('LGET',0,1),('CONST',1,1)]
     if trap=='division' and k==2:body+=[('CONST',2,m.MIN),('LGET',3,3),('BIN','BOP-QUOT',2)]
     else:body+=[('CONST',2,99-k)]
     body+=[('CALL',writer,0,3)]
    body+=[('LGET',0,1),('RT','RT-VECTOR-COUNT',0,1),('RET',0)];m.fx(name,3,4,body)
    caller='call_'+name;m.fx(caller,2,3,[('CONST',0,11),('CONST',1,-22),('CONST',2,33),('CONST',3,-44),('VEC',0,4),('LSET',3,0),('LGET',0,3),('LGET',1,1),('LGET',2,2),('CALL',name,0,3),('RET',0)])
    cost=count*(charged+1);targets.append((caller,cost,trap));audits.append((name,cost,not nonleaf))
# Boundaries and refused neighborhoods. Region charge3 is intentionally split.
for tag,mid in [('label',[('LABEL','fr_label')]),('unknown',[('CONST',0,1),('CONST',1,2),('CALL','fr_unknown',0,2)]),('allocation',[('CONST',0,2),('RT','RT-VECTOR-ALLOC',0,1)]),('cap',[('CONST',0,2)]*128)]:
 name='fr_barrier_'+tag;m.fx(name,0,0,[('FUEL',)]+mid+[('FUEL',),('FUEL',),('CONST',0,17),('RET',0)]);targets.append((name,3,'none'))
for count in [3,7]:
 name='fr_deep'+str(count);m.fx(name,1,1,[('CONST',j,10+j) for j in range(8)]+[('FUEL',),('LGET',8,1),('BIN','BOP-ADD',7)]+[('FUEL',)]*(count-1)+[('BIN','BOP-ADD',j) for j in range(6,-1,-1)]+[('RET',0)]);targets.append((name,count,'scalar'));audits.append((name,count,True))
# Context preservation facts, refused effects/depth/work neighborhoods.
m.fx('cp_scalar',1,1,[('FUEL',),('LGET',0,1),('CONST',1,1),('BIN','BOP-ADD',0),('RET',0)])
m.fx('cp_vector',2,2,[('FUEL',),('LGET',0,1),('LGET',1,2),('RT','RT-VECTOR-AT',0,2),('CONST',1,1),('BIN','BOP-ADD',0),('RET',0)])
m.fx('cp_alloc',1,1,[('LGET',0,1),('RT','RT-VECTOR-ALLOC',0,1),('RET',0)])
m.fx('cp_cap',1,1,[('LGET',0,1),('CAP',39,1,0),('RET',0)])
m.fx('cp_indirect',1,1,[('LGET',0,1),('FADDR',1,next(i+1 for i,x in enumerate(m.FIX) if x[0]=='cp_scalar')),('CALLI',0,0,1),('RET',0)])
m.fx('cp_cycle',1,1,[('CONST',0,0),('BRZ',0,'cp_cycle_done'),('LGET',0,1),('CALL','cp_cycle',0,1),('LABEL','cp_cycle_done'),('CONST',0,17),('RET',0)])
m.fx('cp_big',1,1,[('CONST',0,k) for k in range(520)]+[('RET',0)])
for k in range(9):m.fx('cp_chain'+str(k),1,1,[('LGET',0,1),('CALL','cp_scalar' if k==0 else 'cp_chain'+str(k-1),0,1),('RET',0)])
cp_targets=[]
for callee,admitted in [('cp_scalar',True),('cp_vector',True),('cp_alloc',False),('cp_cap',False),('cp_indirect',False),('cp_cycle',False),('cp_big',False),('cp_chain0',True),('cp_chain8',False)]:
 name='call_'+callee;body=[('CONST',0,11),('CONST',1,-22),('VEC',0,2),('LSET',3,0)]
 body+=([('LGET',0,3),('LGET',1,1)] if callee=='cp_vector' else [('LGET',0,2)])+[('CALL',callee,0,2 if callee=='cp_vector' else 1),('LSET',4,0),('FUEL',),('LGET',0,3),('RT','RT-VECTOR-COUNT',0,1),('LGET',1,4),('BIN','BOP-ADD',0),('RET',0)]
 m.fx(name,2,4,body);cp_targets.append((name,callee,admitted))
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800');loader=str(w/'kexe-loader');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];chunks={}
for label,real,seed,backend in [('candidate-test',False,w/'seed-4.bin',w/'41-a64gen-prototype.kotoba'),('candidate-real',True,w/'seed-4.bin',w/'41-a64gen-prototype.kotoba'),('baseline-real',True,Path('/private/tmp/amu-masked-writer-20261005/seed-4.bin'),r/'seed/41-a64gen.kotoba')]:
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+backend.read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real).replace('          (= k FX-CB19)', '          (= k FX-ADR19) (t-patch1 M at (enc-patch-imm19 w (- fnc at)))\n          (= k FX-CB19)'))
 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  p=subprocess.run([loader,str(seed),seed.with_suffix('.offset').read_text().strip(),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+mode+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(label,mode,p.stdout,p.stderr)
  if mode=='extract':off=re.search(r':offset (\d+)',p.stdout).group(1)
 p=subprocess.run([loader,str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'.stdout')).write_text(p.stdout);assert p.returncode==0,p.stderr;chunks[label]=p.stdout
assert m.blob_from(chunks['candidate-test'])[0].rstrip(b'\0')==m.blob_from(chunks['candidate-real'])[0].rstrip(b'\0') and m.blob_from(chunks['candidate-test'])[1]==m.blob_from(chunks['candidate-real'])[1]
d=w/'fixture-run/unit/41-a64gen';d.mkdir(parents=True,exist_ok=True);(d/'stdout').write_text(chunks['candidate-real']);os.environ['SEED_BUILD']=str(w/'fixture-run');original=m.subprocess.run
def bypass(args,**kw):
 if args[:2]==['zsh',m.R+'/scripts/seed/unit.sh']:return types.SimpleNamespace(returncode=0,stdout='native test/real fixture emitter already verified; product golden unchanged',stderr='')
 return original(args,**kw)
m.subprocess.run=bypass;assert m.runs(False)==0;m.subprocess.run=original
names=[f[0] for f in m.FIX];blob,fc=m.blob_from(chunks['candidate-real']);base,fb=m.blob_from(chunks['baseline-real']);(w/'fixture-candidate-code.bin').write_bytes(blob);(w/'fixture-baseline-code.bin').write_bytes(base)
code_end=4*sum(len(line.split())-1 for line in chunks['candidate-real'].splitlines() if line.startswith('w '))
audit={}
for name,callee,admitted in cp_targets:
 f=names.index(name)+1;target=names.index(callee)+1;out={}
 for label,image,locs in [('baseline',base,fb),('candidate',blob,fc)]:
  start=locs[f]//4;end=locs.get(f+1,4*sum(len(line.split())-1 for line in chunks[label+'-real'].splitlines() if line.startswith('w ')))//4;words=list(struct.unpack('<'+'I'*(end-start),image[start*4:end*4]));bl=[]
  for j,x in enumerate(words):
   if x&0xfc000000==0x94000000:
    delta=x&0x03ffffff;delta-=1<<26 if delta&(1<<25) else 0
    if 4*(start+j+delta)==locs[target]:bl.append(j)
  assert len(bl)==1,(name,label,bl,'actual real direct call retained')
  after=words[bl[0]+1:];stop=after.index(0xf1000610);reloads=[x for x in after[:stop] if x&0xffc003ff==0xf94003e7];out[label]={'contextReloadsBeforeNextFuel':len(reloads),'directCallRetained':True}
 assert out['baseline']['contextReloadsBeforeNextFuel']==1,(name,out)
 assert out['candidate']['contextReloadsBeforeNextFuel']==(0 if admitted else 1),(name,out)
 audit[name]={'admitted':admitted,**out}

shutil.copyfile('/private/tmp/amu-scatter-zero-20261005/vector-state-loader',w/'vector-state-loader');(w/'vector-state-loader').chmod(0o755);rows=[]
def run(path,off,args,budget):
 e=dict(os.environ,KEXE_FUEL=str(budget),KEXE_STRUCTURED_REPORT='1',KEXE_CPU_SECONDS='30',KEXE_WALL_SECONDS='30');e.pop('KEXE_COMMAND',None)
 p=subprocess.run([str(w/'vector-state-loader'),str(path),str(off),str(len(args)),'aarch64','-',*map(str,args)],env=e,capture_output=True,text=True,timeout=35);q=re.search(r':fuel \{:initial (\d+) :remaining (\d+)\}',p.stdout);assert q,(args,budget,p.stdout,p.stderr);state=re.search(r'^DIAG_VECTOR_ITEMS (\d+)(.*)$',p.stderr,re.M);assert state,(args,budget,p.stderr);items=list(map(int,state.group(2).split()));assert len(items)==int(state.group(1));return {'items':items,'exit':p.returncode,'report':p.stdout.strip(),'fuelConsumed':int(q.group(1))-int(q.group(2)),'traps':re.findall(r'^KEXE_TRAP.*$',p.stderr,re.M)}
for name,cost,kind in targets:
 f=names.index(name)+1;argslist=[[0,1],[1,1],[-1,1],[4,1],[m.MIN,1],[m.MAX,1],[1,0],[1,-1]] if name.startswith('call_') else [[m.MIN],[-1],[0],[m.MAX]] if kind=='scalar' else [[]]
 for args in argslist:
  for budget in [*range(1,cost+3),16777216]:
   a=run(w/'fixture-baseline-code.bin',fb[f],args,budget);b=run(w/'fixture-candidate-code.bin',fc[f],args,budget);assert a==b,(name,args,budget,a,b);rows.append({'function':name,'args':args,'fuel':budget,**a})
 print('PASS exact fuel/trap/partial arena',name,flush=True)
for name,callee,admitted in cp_targets:
 f=names.index(name)+1
 for args in [[-1,1],[0,0],[0,1],[1,2],[2,4],[m.MIN,1],[m.MAX,1]]:
  for budget in [1,2,3,4,5,16777216]:
   a=run(w/'fixture-baseline-code.bin',fb[f],args,budget);b=run(w/'fixture-candidate-code.bin',fc[f],args,budget);assert a==b,(name,args,budget,a,b);rows.append({'function':name,'args':args,'fuel':budget,**a})
 print('PASS exact contextcall state',name,flush=True)
# Adversarial runtime always poisons x7 at vector_alloc return; fallback and
# actual restoration are tested, not inferred from incidental C allocation.
original_loader=w/'vector-state-loader';shutil.copyfile(w/'clobber-state-loader',original_loader)
for name,callee,admitted in cp_targets:
 f=names.index(name)+1
 for args in [[0,0],[1,2],[2,4]]:
  for budget in [1,2,3,16777216]:
   a=run(w/'fixture-baseline-code.bin',fb[f],args,budget);b=run(w/'fixture-candidate-code.bin',fc[f],args,budget);assert a==b,(name,args,budget,a,b);rows.append({'function':name,'args':args,'fuel':budget,'adversarialX7Clobber':True,**a})
 print('PASS actual runtime x7 clobber/restoration',name,flush=True)
(w/'fixture-proof.json').write_text(json.dumps({'status':'complete-native-fixture-and-exact-supervisor-parity','canonicalRuns':len(m.RUNS),'fixtures':len(m.FIX),'realTestLayoutIdentical':True,'instructionAudit':audit,'supervisorComparisons':len(rows),'rows':rows},indent=2)+'\n')
