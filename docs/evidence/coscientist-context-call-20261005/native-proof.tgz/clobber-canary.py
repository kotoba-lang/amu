from pathlib import Path
import os,subprocess,json,struct,re,hashlib
w=Path('/private/tmp/amu-context-call-20261005');scope={};s=(w/'fixture-proof.py').read_text();exec(s[:s.index('env=dict(os.environ')],scope);m=scope['m'];names=[x[0] for x in m.FIX];blob,fc=m.blob_from((w/'candidate-real.stdout').read_text());f=names.index('call_cp_alloc')+1;target=names.index('cp_alloc')+1;start=fc[f]//4;end=fc[f+1]//4;words=list(struct.unpack('<'+'I'*((end-start)),blob[start*4:end*4]));bl=[]
for j,x in enumerate(words):
 if x&0xfc000000==0x94000000:
  delta=x&0x3ffffff;delta-=1<<26 if delta&(1<<25) else 0
  if 4*(start+j+delta)==fc[target]:bl.append(j)
assert len(bl)==1
j=bl[0]+1
while words[j]&0xffc003ff!=0xf94003e7:j+=1
control=bytearray(blob);control[(start+j)*4:(start+j+1)*4]=struct.pack('<I',0xd503201f);(w/'missing-restoration-canary.bin').write_bytes(control)
def run(p):
 env=dict(os.environ,KEXE_FUEL='16777216',KEXE_STRUCTURED_REPORT='1',KEXE_CPU_SECONDS='30',KEXE_WALL_SECONDS='30');env.pop('KEXE_COMMAND',None)
 q=subprocess.run([str(w/'clobber-state-loader'),str(p),str(fc[f]),'2','aarch64','-','1','2'],env=env,text=True,capture_output=True,timeout=35);return {'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
good=run(w/'fixture-candidate-code.bin');bad=run(w/'missing-restoration-canary.bin');assert good['exit']==0 and ':status :ok' in good['stdout'];assert bad['exit']!=0 and 'KEXE_TRAP' in bad['stderr'] and good!=bad
out={'status':'complete-adversarial-x7-clobber-canary','mechanism':'Native diagnostic allocation veneer performs original allocation, then sets caller-saved x7 to0x7bad. Deliberately NOP the exact retained restore after real cp_alloc only in this diagnostic control binary. Product/candidate remain unchanged.','offset':fc[f],'removedInstructionOffset':(start+j)*4,'exactCandidateRestorationOpcode':hex(words[j]),'unmodified':good,'missingRestorationControl':bad,'diagnosticLoaderSha256':hashlib.sha256((w/'clobber-state-loader').read_bytes()).hexdigest()};(w/'clobber-canary.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS adversarial clobber active, missing restoration fails, candidate succeeds',flush=True)
