from pathlib import Path
w=Path('/private/tmp/amu-context-call-20261005');s=Path('/private/tmp/amu-masked-writer-20261005/fixture-proof.py').read_text().replace('amu-masked-writer-20261005','amu-context-call-20261005').replace("Path('/private/tmp/amu-scalar-tree-20261005/seed-4.bin')","Path('/private/tmp/amu-masked-writer-20261005/seed-4.bin')")
a=s.index('# Exact admitted shape');b=s.index('env=dict(os.environ',a)
extra='''# Context preservation facts, refused effects/depth/work neighborhoods.
m.fx('cp_scalar',1,1,[('FUEL',),('LGET',0,1),('CONST',1,1),('BIN','BOP-ADD',0),('RET',0)])
m.fx('cp_vector',2,2,[('FUEL',),('LGET',0,1),('LGET',1,2),('RT','RT-VECTOR-AT',0,2),('CONST',1,1),('BIN','BOP-ADD',0),('RET',0)])
m.fx('cp_alloc',1,1,[('LGET',0,1),('RT','RT-VECTOR-ALLOC',0,1),('RET',0)])
m.fx('cp_cap',1,1,[('LGET',0,1),('CAP',39,'CK-STRING',0),('RET',0)])
m.fx('cp_indirect',1,1,[('LGET',0,1),('FADDR',1,'cp_scalar'),('CALLI',0,0,1),('RET',0)])
m.fx('cp_cycle',1,1,[('CONST',0,0),('BRZ',0,'cp_cycle_done'),('LGET',0,1),('CALL','cp_cycle',0,1),('LABEL','cp_cycle_done'),('CONST',0,17),('RET',0)])
m.fx('cp_big',1,1,[('CONST',0,k) for k in range(520)]+[('RET',0)])
for k in range(9):m.fx('cp_chain'+str(k),1,1,[('LGET',0,1),('CALL','cp_scalar' if k==0 else 'cp_chain'+str(k-1),0,1),('RET',0)])
cp_targets=[]
for callee,admitted in [('cp_scalar',True),('cp_vector',True),('cp_alloc',False),('cp_cap',False),('cp_indirect',False),('cp_cycle',False),('cp_big',False),('cp_chain0',True),('cp_chain8',False)]:
 name='call_'+callee;body=[('CONST',0,11),('CONST',1,-22),('VEC',0,2),('LSET',3,0)]
 body+=([('LGET',0,3),('LGET',1,1)] if callee=='cp_vector' else [('LGET',0,2)])+[('CALL',callee,0,2 if callee=='cp_vector' else 1),('LSET',4,0),('FUEL',),('LGET',0,3),('RT','RT-VECTOR-COUNT',0,1),('LGET',1,4),('BIN','BOP-ADD',0),('RET',0)]
 m.fx(name,2,4,body);cp_targets.append((name,callee,admitted))
'''
s=s[:a]+extra+s[b:];a=s.index('audit={}');b=s.index("shutil.copyfile('/private/tmp/amu-scatter",a)
audit='''audit={}
for name,callee,admitted in cp_targets:
 f=names.index(name)+1;target=names.index(callee)+1;out={}
 for label,image,locs in [('baseline',base,fb),('candidate',blob,fc)]:
  start=locs[f]//4;end=locs.get(f+1,code_end)//4;words=list(struct.unpack('<'+'I'*(end-start),image[start*4:end*4]));bl=[]
  for j,x in enumerate(words):
   if x&0xfc000000==0x94000000:
    delta=x&0x03ffffff;delta-=1<<26 if delta&(1<<25) else 0
    if 4*(start+j+delta)==locs[target]:bl.append(j)
  assert len(bl)==1,(name,label,bl,'actual real direct call retained')
  after=words[bl[0]+1:];stop=after.index(0xf1000610);reloads=[x for x in after[:stop] if x&0xffc003ff==0xf94003e7];out[label]={'contextReloadsBeforeNextFuel':len(reloads),'directCallRetained':True}
 assert out['baseline']['contextReloadsBeforeNextFuel']==1,(name,out)
 assert out['candidate']['contextReloadsBeforeNextFuel']==(0 if admitted else 1),(name,out)
 audit[name]={'admitted':admitted,**out}

'''
s=s[:a]+audit+s[b:];a=s.index('for name,admitted,restore in masktargets:');b=s.index("(w/'fixture-proof.json').write_text",a)
more='''for name,callee,admitted in cp_targets:
 f=names.index(name)+1
 for args in [[-1,1],[0,0],[0,1],[1,2],[2,4],[m.MIN,1],[m.MAX,1]]:
  for budget in [1,2,3,4,5,16777216]:
   a=run(w/'fixture-baseline-code.bin',fb[f],args,budget);b=run(w/'fixture-candidate-code.bin',fc[f],args,budget);assert a==b,(name,args,budget,a,b);rows.append({'function':name,'args':args,'fuel':budget,**a})
 print('PASS exact contextcall state',name,flush=True)
# Adversarial runtime always poisons x7 at vector_alloc return; fallback and
# actual restoration are tested, not inferred from incidental C allocation.
original_loader=w/'vector-state-loader';shutil.copyfile(w/'clobber-state-loader',original_loader)
for name,callee,admitted in cp_targets:
 f=names.index(name)+1
 for args in [[0,0],[1,2],[2,4]]:
  for budget in [1,2,3,16777216]:
   a=run(w/'fixture-baseline-code.bin',fb[f],args,budget);b=run(w/'fixture-candidate-code.bin',fc[f],args,budget);assert a==b,(name,args,budget,a,b);rows.append({'function':name,'args':args,'fuel':budget,'adversarialX7Clobber':True,**a})
 print('PASS actual runtime x7 clobber/restoration',name,flush=True)
'''
s=s[:a]+more+s[b:];s=s.replace('d.mkdir(parents=True);','d.mkdir(parents=True,exist_ok=True);');(w/'fixture-proof.py').write_text(s)
# Diagnostic only: current loader with exact vector-state observation and a
# native ABI-valid vector_alloc veneer that deliberately clobbers caller-saved x7.
r=Path('/Users/junkawasaki/github/wt/amu-seed17');c=(r/'tools/kexe_loader.c').read_text();old=Path('/private/tmp/amu-scatter-zero-20261005/vector-state-loader.c').read_text();a=old.index('  /* Diagnostic only: exact state');b=old.index('  if (child_status == 0',a);obs=old[a:b];anchor='  if (child_status == 0 && shared->completed == 1) {';assert c.count(anchor)==1;c=c.replace(anchor,obs+anchor)
c=c.replace('static int64_t checked_vector_alloc(', 'static __attribute__((used)) int64_t checked_vector_alloc(')
anchor='/* ABI v4: the same update';veneer='''/* Diagnostic only: real allocation, then deliberately clobber caller-saved x7. */
__attribute__((naked,noinline)) static int64_t diagnostic_vector_alloc(struct kexe_context_v11 *context, int64_t count) {
 __asm__ volatile("stp x29,x30,[sp,#-16]!\\nmov x29,sp\\nbl _checked_vector_alloc\\nmov x7,#0x7bad\\nldp x29,x30,[sp],#16\\nret\\n");
}

''';assert c.count(anchor)==1;c=c.replace(anchor,veneer+anchor).replace('shared->context.vector_alloc = checked_vector_alloc;','shared->context.vector_alloc = diagnostic_vector_alloc;');(w/'clobber-state-loader.c').write_text(c)
