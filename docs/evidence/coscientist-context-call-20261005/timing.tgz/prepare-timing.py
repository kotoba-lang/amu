from pathlib import Path
import json,hashlib,shutil
w=Path('/private/tmp/amu-context-call-20261005');base=Path('/private/tmp/amu-masked-writer-20261005');b=json.loads((base/'ports-correctness.json').read_text());c=json.loads((w/'ports-correctness.json').read_text());gen=json.loads((w/'generations.json').read_text());package=w/'timing-package';package.mkdir();names=[]
for e in c['entries']:
 old=next(x for x in b['entries'] if x['workload']==e['workload'])
 if e['nativeSha256']==old['nativeSha256']:continue
 name=e['workload'];names.append(name);d=package/name;candidate=d/'candidate';candidate.mkdir(parents=True);shutil.copyfile(w/'ports-2'/name/'native.bin',candidate/'native.bin');shutil.copyfile(base/'ports-2'/name/'native.bin',d/'baseline-native.bin')
 (candidate/'manifest.json').write_text(json.dumps({'workload':name,'sourceSha256':e['sourceSha256'],'baselineSourceSha256':old['sourceSha256'],'nativeSha256':e['nativeSha256'],'offset':e['offset'],'baselineNativeSha256':old['nativeSha256'],'baselineOffset':old['offset'],'compilerGenerationSha256':{str(x['generation']):x['sha256'] for x in gen[1:]},'producerCompilerSha256':hashlib.sha256((base/'seed-4.bin').read_bytes()).hexdigest(),'hypothesis':'Exact bounded direct-callee context-register preservation fact; retain actual calls, frame, fuel/trap/publication; only elide proved redundant restoration','sourceHead':'533e1daa15a0fd2e502cdd55bf24bca30cca140c'},indent=2)+'\n')
names.sort(key=lambda x:(x!='picojpeg',x));(package/'workloads.json').write_text(json.dumps(names,indent=2)+'\n');shutil.copyfile(base/'ports-correctness.json',package/'product-proof.json');shutil.copyfile(w/'ports-correctness.json',package/'candidate-proof.json');shutil.copyfile(w/'fixture-proof.json',package/'fixture-proof.json');shutil.copyfile(w/'bulk-state.json',package/'bulk-state.json');shutil.copyfile(w/'generations.json',package/'generations.json')
shutil.copyfile(w/'clobber-canary.json',package/'clobber-canary.json')
