from pathlib import Path
import importlib.util,subprocess,os,re,json,types,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-bounded-fill-20261005');sp=importlib.util.spec_from_file_location('fx',r/'scripts/seed/a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)


sign=[('LGET',0,1),('CONST',1,65535),('BIN','BOP-AND',0),('LSET',2,0),('LGET',0,2),('CONST',1,32768),('CMP','CC-GE',0),('BRZ',0,'sg_else'),('LGET',0,2),('CONST',1,65536),('BIN','BOP-SUB',0),('BR','sg_exit'),('LABEL','sg_else'),('LGET',0,2),('LABEL','sg_exit'),('RET',0)]
def narrow(x):
 x&=65535
 return x-65536 if x>=32768 else x
for charge in [0,1]:
 name='sg'+str(charge);m.fx(name,1,2,([('FUEL',)] if charge else [])+[tuple(name+'_'+x if isinstance(x,str) and x.startswith('sg_') else x for x in row) for row in sign]);m.fx('wr'+str(charge),3,3,([('FUEL',)] if charge else [])+[('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('RET',0)])
for c in [0,1]:
 for s in [0,1]:
  for z in [0,1]:
   name=f'iw{c}{s}{z}';chain=[('LGET',0,1),('LGET',1,2),('LGET',2,3),('LGET',3,4),('BIN','BOP-MUL',2),('BIN','BOP-ADD',1),('LGET',2,5),('CALL','sg'+str(s),2,1),('CALL','wr'+str(z),0,3),('RET',0)];m.fx(name,5,5,([('FUEL',)] if c else [])+chain)
   for entry in [0,1]:
    fl=f'fl{entry}_{c}{s}{z}';loop=fl+'_loop';le=fl+'_else';lx=fl+'_end';rows=([('FUEL',)] if entry else [])+[('LABEL',loop),('LGET',0,4),('CONST',1,8),('CMP','CC-EQ',0),('BRZ',0,le),('LGET',0,1),('BR',lx),('LABEL',le),('LGET',0,1),('LGET',1,2),('LGET',2,3),('LGET',3,4),('LGET',4,5),('CALL',name,0,5),('LGET',1,2),('LGET',2,3),('LGET',3,4),('CONST',4,1),('BIN','BOP-ADD',3),('LGET',4,5),('LSET',1,0),('LSET',2,1),('LSET',3,2),('LSET',4,3),('LSET',5,4),('FUEL',),('BR',loop),('LABEL',lx),('RET',0)];m.fx(fl,5,5,rows)
    for tag,length,base,stride,k in [('full',128,1,2,0),('partial',128,1,2,3),('terminal',128,1,2,8),('zero',128,7,0,0),('neg',128,15,-2,0),('tight',16,0,2,0)]:
     caller=f'call_{fl}_{tag}';indices=list(range(k,8));touched={base+stride*j for j in indices};reads=sorted(touched | {0,length-1});rows=[('FUEL',),('FUEL',),('CONST',0,length),('RT','RT-VECTOR-ALLOC',0,1),('LSET',2,0),('CONST',0,0),('LSET',3,0),('LGET',0,2),('CONST',1,base),('CONST',2,stride),('CONST',3,k),('LGET',4,1),('CALL',fl,0,5)]
     for idx in reads:rows += [('LGET',0,2),('CONST',1,idx),('RT','RT-VECTOR-AT',0,2),('CONST',1,idx+1),('BIN','BOP-MUL',0),('LGET',1,3),('BIN','BOP-ADD',0),('LSET',3,0)]
     rows += [('LGET',0,3),('RET',0)];m.fx(caller,1,3,rows);budget=2+entry+(8-k)*(1+c+s+z)
     for x in [m.MIN,m.MIN+1,-32769,-1,0,32767,m.MAX]:m.run(caller,[x],m.s64(narrow(x)*sum(idx+1 for idx in touched)),fuel=budget)
     if tag=='full':
      for fuel in range(1,budget):m.run(caller,[1],'trap',fuel=fuel)
    for tag,length,base,stride,k in [('empty',0,0,1,0),('last',15,1,2,0),('negativek',128,0,1,-1),('badstride',128,0,m.MAX,0)]:
     caller=f'bad_{fl}_{tag}';m.fx(caller,1,2,[('FUEL',),('FUEL',),('CONST',0,length),('RT','RT-VECTOR-ALLOC',0,1),('CONST',1,base),('CONST',2,stride),('CONST',3,k),('LGET',4,1),('CALL',fl,0,5),('RET',0)]);m.run(caller,[m.MIN],'trap',fuel=128)
    for k in [0,8]:
     caller=f'handle0_{fl}_{k}';m.fx(caller,0,0,[('FUEL',),('FUEL',),('CONST',0,0),('CONST',1,0),('CONST',2,1),('CONST',3,k),('CONST',4,0),('CALL',fl,0,5),('RET',0)]);m.run(caller,[],'trap' if k==0 else 0,fuel=128)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800');loader=str(w/'kexe-loader');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];chunks=[]
for real in [False,True]:
 prefix='fixture-real' if real else 'fixture-test';src=w/(prefix+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real))
 for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(prefix+'.kseed'))]),('extract',['extract-native',str(w/(prefix+'.kseed')),'--symbol','main','--output',str(w/(prefix+'.bin'))])]:
  p=subprocess.run([loader,str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(prefix+'-'+label+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(label,p.stdout,p.stderr)
  if label=='extract':off=re.search(r':offset (\d+)',p.stdout).group(1)
 p=subprocess.run([loader,str(w/(prefix+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(prefix+'.stdout')).write_text(p.stdout);assert p.returncode==0,p.stderr;chunks.append(p.stdout)
assert m.blob_from(chunks[0])[0].rstrip(b'\0')==m.blob_from(chunks[1])[0].rstrip(b'\0') and m.blob_from(chunks[0])[1]==m.blob_from(chunks[1])[1]
d=w/'fixture-run/unit/41-a64gen';d.mkdir(parents=True,exist_ok=True);(d/'stdout').write_text(chunks[1]);os.environ['SEED_BUILD']=str(w/'fixture-run');original=m.subprocess.run

def run(args,**kw):
 if args[:2]==['zsh',m.R+'/scripts/seed/unit.sh']:return types.SimpleNamespace(returncode=0,stdout='native experimental fixture emitter already verified; byte golden untouched',stderr='')
 return original(args,**kw)
m.subprocess.run=run;assert m.runs(False)==0
blob,fns=m.blob_from(chunks[1]);names=[f[0] for f in m.FIX];audit={}
for name in ['fl0_000','fl1_111','fl1_101']:
 f=names.index(name)+1;end=fns.get(f+1,int(re.search(r'words (\d+)',chunks[1]).group(1))*4);words=struct.unpack('<'+'I'*((end-fns[f])//4),blob[fns[f]:end]);rets=[i for i,x in enumerate(words) if x==0xd65f03c0];assert len(rets)==2,(name,rets);fast=words[:rets[0]+1];fallback=words[rets[0]+1:];bl=sum((x&0xfc000000)==0x94000000 for x in fast);blr=sum((x&0xfffffc1f)==0xd63f0000 for x in fast);udf=sum(x==0 for x in fast);assert bl==blr==udf==0,(name,bl,blr,udf);assert sum((x&0xfc000000)==0x94000000 for x in fallback)==1
 audit[name]={'fastDirectBL':bl,'fastIndirectBLR':blr,'fastUDF':udf,'returnPaths':len(rets),'fallbackBL':1,'fastBytes':len(fast)*4,'fallbackBytes':len(fallback)*4}
(w/'fixture-proof.json').write_text(json.dumps({'runs':len(m.RUNS),'fixtures':len(m.FIX),'realTestLayoutIdentical':True,'instructionAudit':audit},indent=2)+'\n');print('PASS bounded-fill fast/fallback instruction audits',flush=True)
