from pathlib import Path
import json,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-bounded-fill-20261005');old=(r/'seed/41-a64gen.kotoba').read_text();g=old;prior=Path('/private/tmp/amu-index-write-20261005/41-a64gen-prototype.kotoba').read_text();proof=prior[prior.index(';; Exact index-write dependency proof'):prior.index('(defn- gn-call-wrapper')]
shape=[('OP-LGET',0,4,0),('OP-CONST',1,8,0),('OP-CMP','CC-EQ',0,0),('OP-BRZ',0,'le',0),('OP-LGET',0,1,0),('OP-BR','lx',0,0),('OP-LABEL','le',0,0),('OP-LGET',0,1,0),('OP-LGET',1,2,0),('OP-LGET',2,3,0),('OP-LGET',3,4,0),('OP-LGET',4,5,0),('OP-CALL','wf',0,5),('OP-LGET',1,2,0),('OP-LGET',2,3,0),('OP-LGET',3,4,0),('OP-CONST',4,1,0),('OP-BIN','BOP-ADD',3,0),('OP-LGET',4,5,0),('OP-LSET',1,0,0),('OP-LSET',2,1,0),('OP-LSET',3,2,0),('OP-LSET',4,3,0),('OP-LSET',5,4,0),('OP-FUEL',0,0,0),('OP-BR','loop',0,0),('OP-LABEL','lx',0,0),('OP-RET',0,0,0),('OP-END','f',0,0)]
checks='\n                 '.join(f'(and (= (gn-op M (+ q {j})) {op}) (= (gn-sir M (+ q {j}) IF-A) {a}) (= (gn-sir M (+ q {j}) IF-B) {b}) (= (gn-sir M (+ q {j}) IF-C) {c}))' for j,(op,a,b,c) in enumerate(shape))
helper=''';; Exact bound8 loop, natural parameter updates and fully proved index writer.
;; Token8192+16*entryCharge+helperCharges; no names, unknown shape ->0.
(defn- gn-fill-regs [M :vector-i64 k :i64] :bool
  (if (> k 5) true (and (>= (gn-sreg M k) 19) (<= (gn-sreg M k) 28) (gn-fill-regs M (inc k)))))
(defn- gn-fill-wrapper [M :vector-i64 f :i64] :i64
  (let [p (gn-fnf M f FF-SIR)]
    (if (or (< p 1) (not= (gn-op M p) OP-FN) (not= (gn-sir M p IF-A) f)
            (not= (gn-sir M p IF-B) 5) (not (gn-index-fuel M p))
            (not= (gn-g M gn-f-leaf) 0) (not= (gn-g M gn-f-freg) 0) (not (gn-fill-regs M 1))) 0
      (let [fuel (if (= (gn-op M (inc p)) OP-FUEL) 1 0) lab (+ p 1 fuel) q (inc lab)
            loop (gn-sir M lab IF-A) le (gn-sir M (+ q 3) IF-B) lx (gn-sir M (+ q 5) IF-A)
            wf (gn-sir M (+ q 12) IF-A)]
        (if (and (= (gn-op M lab) OP-LABEL) (> loop 0)
                 (= (gn-sir M lab IF-B) 0) (= (gn-sir M lab IF-C) 0)
                 (> le 0) (> lx 0) (not= loop le) (not= loop lx) (not= le lx) (> wf 0) (not= wf f)
                 CHECKS)
          (let [z (gn-index-wrapper M wf 0 5)]
            (if (>= z 4096) (+ 8192 (* fuel 16) (- z 4096)) 0)) 0)))))
'''.replace('CHECKS',checks)
a='(defn- gn-call-wrapper';assert g.count(a)==1;g=g.replace(a,proof+helper+a)
a='(gn-gs gn-f-h 0)))))))';b='(gn-gs gn-f-h 0)\n                  (gn-fill-entry f)))))))';assert g.count(a)==1;g=g.replace(a,b)
asm=''';; Runtime guards are total and branch to the original body on failure.
;; x9 pointer, x11 byte stride, x12 narrowed value, x13 loop k; x8 is the
;; original helper's leaf fuel transaction and commits after each write.
(defn- gn-fill-helper-fuel [M :vector-i64 n :i64] :vector-i64
  (if (= n 0) M (gn-fill-helper-fuel
    (-> M (gn-emit (enc-subs-i 8 8 1)) (gn-emit (enc-bcond (enc-cond-hs) 3))
          (gn-emit (enc-str 31 7 CTX-FUEL)) (gn-emit (enc-brk 0))) (dec n))))
(defn- gn-fill-fast [M :vector-i64 w :i64] :vector-i64
  (let [rv (gn-sreg M 1) rb (gn-sreg M 2) rs (gn-sreg M 3) rk (gn-sreg M 4) rx (gn-sreg M 5)
        n (bit-and w 15)
        M0 (gn-emit M (enc-cmp-i rk 8)) f0 (vector-at M0 MM-CODE-N)
        M1 (-> M0 (gn-emit (enc-bcond 8 0)) (gn-emit (enc-cmp-i rs 0))) f1 (vector-at M1 MM-CODE-N)
        M2 (-> M1 (gn-emit (enc-bcond (enc-cond-lt) 0))
               (gn-emit (enc-ldr 16 7 312)) (gn-emit (enc-ldr 16 16 0))
               (gn-emit (enc-sub-i 17 rv 1)) (gn-emit (enc-cmp-r 17 16))) f2 (vector-at M2 MM-CODE-N)
        M3 (-> M2 (gn-emit (enc-bcond (enc-cond-hs) 0))
               (gn-emit (enc-ldr 16 7 320)) (gn-emit (gn-e-addsl 16 16 17 4))
               (gn-emit (enc-ldp 17 16 16 0)) (gn-mov 9 17) (gn-mov 10 16)
               (gn-emit (enc-cmp-r rb 10))) f3 (vector-at M3 MM-CODE-N)
        M4 (-> M3 (gn-emit (enc-bcond (enc-cond-hs) 0))
               (gn-emit (enc-sub-r 16 10 rb)) (gn-emit (enc-sub-i 16 16 1))
               (gn-emit (gn-e-bf 0xd3400000 16 16 3 63))
               (gn-emit (enc-cmp-r rs 16))) f4 (vector-at M4 MM-CODE-N)
        M5 (-> M4 (gn-emit (enc-bcond 8 0))
               (gn-emit (enc-ldr 16 7 328)) (gn-emit (gn-e-addsl 9 16 9 3))
               (gn-emit (enc-mul 10 rs rk)) (gn-emit (enc-add-r 10 10 rb))
               (gn-emit (gn-e-addsl 9 9 10 3))
               (gn-emit (gn-e-bf 0xd3400000 11 rs 61 60))
               (gn-emit (gn-e-bf 0x93400000 12 rx 0 15)) (gn-mov 13 rk)
               (cond-> (= (bit-and w 16) 16) (gn-op-fuel)))
        loop (vector-at M5 MM-CODE-N)
        M6 (gn-emit M5 (enc-cmp-i 13 8)) done (vector-at M6 MM-CODE-N)
        M7 (-> M6 (gn-emit (enc-bcond (enc-cond-eq) 0))
               (cond-> (> n 0) (gn-emit (enc-ldr 8 7 CTX-FUEL)))
               (gn-fill-helper-fuel n)
               (gn-emit (enc-str 12 9 0))
               (cond-> (> n 0) (gn-emit (enc-str 8 7 CTX-FUEL)))
               (gn-emit (enc-add-r 9 9 11)) (gn-emit (enc-add-i 13 13 1)) (gn-op-fuel))
        back (vector-at M7 MM-CODE-N)
        M8 (gn-emit M7 (enc-b (- loop back))) end (vector-at M8 MM-CODE-N)
        M9 (-> M8 (gn-mov 0 rv) (gn-epilogue) (gn-gs gn-f-dead 0)) fallback (vector-at M9 MM-CODE-N)]
    (-> M9 (gn-put (+ MM-CODE-BASE f0) (enc-bcond 8 (- fallback f0)))
        (gn-put (+ MM-CODE-BASE f1) (enc-bcond (enc-cond-lt) (- fallback f1)))
        (gn-put (+ MM-CODE-BASE f2) (enc-bcond (enc-cond-hs) (- fallback f2)))
        (gn-put (+ MM-CODE-BASE f3) (enc-bcond (enc-cond-hs) (- fallback f3)))
        (gn-put (+ MM-CODE-BASE f4) (enc-bcond 8 (- fallback f4)))
        (gn-put (+ MM-CODE-BASE done) (enc-bcond (enc-cond-eq) (- end done))))))
(defn- gn-fill-entry [M :vector-i64 f :i64] :vector-i64
  (let [w (gn-fill-wrapper M f)] (if (= w 0) M (gn-fill-fast M w))))
\n'''
a=';; ---- FLOAT (agent FLOAT';assert g.count(a)==1;g=g.replace(a,asm+a)
(w/'41-a64gen-prototype.kotoba').write_text(g);files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];u=''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files);(w/'seed-unity.kotoba').write_text(u)
for ext in ['bin','offset']:shutil.copyfile(Path('/private/tmp/amu-sign-wrapper-20261005')/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile('/private/tmp/amu-sign-wrapper-20261005/kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['check-ports.py','bulk-state.py','remote.py','build.py']:
 s=Path('/private/tmp/amu-index-write-20261005',name).read_text().replace('/private/tmp/amu-index-write-20261005','/private/tmp/amu-bounded-fill-20261005').replace('/private/tmp/amu-zebulun-index-write-20261005','/private/tmp/amu-zebulun-bounded-fill-20261005');(w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'hypothesis':'Exact bound8 vector-fill loop and proved wrapped index/sign/write dependencies allow guarded fast path with descriptor check once, scalar writes and no helper calls. Guard0<=k<=8, valid handle, base<len, stride>=0 and stride<=(len-1-base)>>3. Otherwise original loop. Each loop charge/backedge and helper leaf fuel transaction kept, with checkpoint after each write.','promotion':'Fresh30 rotating quiet baseline/candidate/C triples; >=5% speedup and gap>sumSD after native correctness/exactfuel/traps/state/fixedpoint.','sourceHead':'03e147c3c1e70a80e8bea72ba3bcb11594d47b44','exception':'One-off new compiler algorithm authoring, not mechanical refactoring'},indent=2)+'\n')
