from pathlib import Path
import subprocess
w=Path('/private/tmp/amu-bounded-fill-20261005');r=Path('/Users/junkawasaki/github/wt/amu-seed17');c=(r/'tools/kexe_loader.c').read_text();start=c.index('static int write_supervisor_report(');body=c.index('{',start);c=c[:body+1]+'''
  /* Diagnostic only: exact state of small test-owned vector arenas, including
     failed guest runs. This mechanism never participates in timed execution. */
  fprintf(stderr, "DIAG_VECTOR_ITEMS %" PRIu64, shared->vector_item_used);
  if (shared->vector_item_used > 512) { fprintf(stderr, " overflow\\n"); return 2; }
  for (uint64_t i = 0; i < shared->vector_item_used; ++i)
    fprintf(stderr, " %" PRId64, shared->vector_items[i]);
  fprintf(stderr, "\\n");
'''+c[body+1:];(w/'vector-state-loader.c').write_text(c);p=subprocess.run(['clang','-O2','-Wno-deprecated-declarations',str(w/'vector-state-loader.c'),'-o',str(w/'vector-state-loader')],capture_output=True,text=True);(w/'vector-state-loader.cc.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
s=Path('/private/tmp/amu-index-write-20261005/check-probe.py').read_text();prefix=s[:s.index('forms=')].replace('/private/tmp/amu-index-write-20261005','/private/tmp/amu-bounded-fill-20261005').replace('checked index-write fusion','guarded bounded vector fill');prefix=prefix.replace("p=subprocess.run([str(loader),str(d/'native.bin'),str(off),'1','aarch64','-',str(n)]","p=subprocess.run([str(w/'vector-state-loader'),str(d/'native.bin'),str(off),'1','aarch64','-',str(n)]");prefix=prefix.replace("return {'exit':p.returncode", "state=re.search(r'^DIAG_VECTOR_ITEMS (\\d+)(.*)$',p.stderr,re.M);assert state,(n,fuel,p.stderr);items=list(map(int,state.group(2).split()));assert len(items)==int(state.group(1));return {'items':items,'exit':p.returncode")
rest='''
forms=['(defn- i16 [x :i64] :i64 (let [n (bit-and x 65535)] (if (>= n 32768) (- n 65536) n)))','(defn- i8 [x :i64] :i64 (let [n (bit-and x 255)] (if (>= n 128) (- n 256) n)))','(defn- put [v :vector-i64 i :i64 x :i64] :vector-i64 (vector-assoc! v i x))','(defn- writer [v :vector-i64 base :i64 stride :i64 k :i64 x :i64] :vector-i64 (put v (+ base (* stride k)) (i16 x)))','(defn- writer8 [v :vector-i64 base :i64 stride :i64 k :i64 x :i64] :vector-i64 (put v (+ base (* stride k)) (i8 x)))','(defn- fill [v :vector-i64 base :i64 stride :i64 k :i64 x :i64] :vector-i64 (if (= k 8) v (fill (writer v base stride k x) base stride (+ k 1) x)))','(defn- fill7 [v :vector-i64 base :i64 stride :i64 k :i64 x :i64] :vector-i64 (if (= k 7) v (fill7 (writer v base stride k x) base stride (+ k 1) x)))','(defn- fill-step2 [v :vector-i64 base :i64 stride :i64 k :i64 x :i64] :vector-i64 (if (= k 8) v (fill-step2 (writer v base stride k x) base stride (+ k 2) x)))','(defn- fill-change [v :vector-i64 base :i64 stride :i64 k :i64 x :i64] :vector-i64 (if (= k 8) v (fill-change (writer v base stride k x) base stride (+ k 1) (+ x 1))))','(defn- fill-wrong [v :vector-i64 base :i64 stride :i64 k :i64 x :i64] :vector-i64 (if (= k 8) v (fill-wrong (writer8 v base stride k x) base stride (+ k 1) x)))','(defn- checksum [v :vector-i64 i :i64 a :i64] :i64 (if (= i (vector-count v)) a (checksum v (+ i 1) (+ a (* (+ i 1) (vector-at v i))))))']
cases=[('full',128,1,2,0,'fill','ok'),('partial',128,1,2,3,'fill','ok'),('last',128,1,2,7,'fill','ok'),('terminal',128,1,2,8,'fill','ok'),('zero-stride',128,7,0,0,'fill','ok'),('last-index-zero-stride',128,127,0,0,'fill','ok'),('empty-terminal',0,0,1,8,'fill','ok'),('negative-stride',128,15,-2,0,'fill','ok'),('conservative-fallback',16,0,2,0,'fill','ok'),('bound7',128,1,2,0,'fill7','ok'),('step2',128,1,2,0,'fill-step2','ok'),('changing-value',128,1,2,0,'fill-change','ok'),('wrong-width',128,1,2,0,'fill-wrong','ok'),('empty',0,0,1,0,'fill','trap'),('bad-base',128,-1,1,0,'fill','trap'),('bad-last',16,1,2,0,'fill','trap'),('wrap-base',128,-9223372036854775808,-9223372036854775808,0,'fill','trap'),('wrap-stride',128,0,9223372036854775807,0,'fill','trap'),('negative-k',128,0,1,-1,'fill','trap'),('past-terminal',128,7,0,9,'fill','budget')]
symbols=[c[0] for c in cases]
for name,length,basev,stride,k,fn,_ in cases:forms.append(f'(defn {name} [x :i64] :i64 (let [v (vector-alloc {length}) a ({fn} v {basev} {stride} {k} x)] (checksum a 0 0)))')
src=w/'probe.kotoba';src.write_text('(ns probe (:export ['+' '.join(symbols)+']))\\n'+'\\n'.join(forms)+'\\n')
def signed(x):
 x&=(1<<64)-1
 return x-(1<<64) if x>>63 else x
def narrow(x,width=16):
 x&=(1<<width)-1
 return x-(1<<width) if x>=(1<<(width-1)) else x
values=[-(1<<63),-(1<<63)+1,-65537,-32769,-32768,-257,-129,-128,-1,0,1,127,128,255,256,32767,32768,65535,65536,(1<<63)-1]
a=w/'probe-baseline';b=w/'probe-candidate';oa=compile(base/'seed-4.bin',src,a,symbols);ob=compile(w/'seed-4.bin',src,b,symbols)
for symbol,length,basev,stride,k,fn,kind in cases:
 for n in values if kind=='ok' else [-(1<<63),-1,0,1,(1<<63)-1]:
  for fuel in [1,2,3,4,5,8,10,24,25,26,27,30,100,16777216] if kind!='budget' else [1,2,3,4,5,8,10,24,25,26,27,30,100,128]:
   x=run(a,oa[symbol],n,fuel);y=run(b,ob[symbol],n,fuel);assert x==y,(symbol,n,fuel,x,y)
   if fuel==16777216:
    if kind=='trap':assert x['exit']!=0 and any('SIGILL' in t for t in x['traps']),(symbol,n,x)
    else:
     items=[0]*length;bound=7 if fn=='fill7' else 8;step=2 if fn=='fill-step2' else 1;val=n;it=k
     while it!=bound:
      idx=signed(basev+signed(stride*it));assert 0<=idx<length;items[idx]=narrow(val,8 if fn=='fill-wrong' else 16);it+=step
      if fn=='fill-change':val=signed(val+1)
     expected=signed(sum((i+1)*v for i,v in enumerate(items)));assert x['exit']==0 and x['value']['result']==expected and x['items']==items,(symbol,n,x,expected,items)
   report['rows'].append({'symbol':symbol,'input':n,'fuel':fuel,**x})
 print('PASS',symbol,flush=True);report['status']='in-progress';(w/'correctness.json').write_text(json.dumps(report,indent=2)+'\\n')
report['status']='complete-signed-exact-fuel-trap-resource-and-partial-vector-state-parity';report['sourceSha256']=sha(src);report['executionAdapter']='Diagnostic-only native C loader supervisor prints all small test-owned arena cells after success/trap. Never used for performance. Full structured reports and partial state compared.';report['baselineBytes']=(a/'native.bin').stat().st_size;report['candidateBytes']=(b/'native.bin').stat().st_size;(w/'correctness.json').write_text(json.dumps(report,indent=2)+'\\n')
'''
(w/'check-probe.py').write_text(prefix+rest)
