from pathlib import Path
import subprocess,os,re,json,hashlib
W=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def out(prefix,fields):
 s='"\\n"'
 for x in reversed(fields):s=f'(string-concat (string-from-i64 {x}) (string-concat " " {s}))'
 return f'(io-out (string-concat "{prefix} " {s}))'
helper=(W/'descriptor-native.kotoba').read_text()
# Print finite callclosure certificate without mutating emitted generator state.
helper=helper.replace('Q1 (dc-end M (vector-assoc! Q 2 (dec top)) p f) end (vector-at Q1 6)]','Q1 (dc-end M (vector-assoc! Q 2 (dec top)) p f) end (vector-at Q1 6) printed '+out('DCCLOSURE',['root','f','p','end','(vector-at Q1 0)','(vector-at Q1 1)'])+']')
helper=helper.replace('proof (dc-closure M (dc-push S f) i)]','proof (dc-closure M (dc-push S f) i) printed '+out('DCCERT',['i','f','np','nsv','nf','(gn-g M gn-f-fb)','frame','(vector-at proof 0)','(vector-at proof 1)','(vector-at proof 4)','(vector-at proof 5)','(vector-at proof 2)'])+']')
g=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation/observer/41.kotoba').read_text()
prepare=(W/'prepare.py').read_text();ops=prepare[prepare.index("g=g.replace("):prepare.index("(W/'41-a64gen-prototype.kotoba').write_text")]
ctx={'g':g,'helper':helper};exec(ops,ctx);g=ctx['g']
o=W/'observer';o.mkdir(exist_ok=True);(o/'41.kotoba').write_text(g)
parts=[p.strip() for p in (R/'seed/MANIFEST').read_text().splitlines() if p.strip() and not p.lstrip().startswith('#')];(o/'unity.kotoba').write_text('\n'.join(g if p=='seed/41-a64gen.kotoba' else (W/'source-snapshot'/p).read_text() for p in parts))
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for label,args in [('compile',['compile',str(o/'unity.kotoba'),'--target','aarch64-macos','--output',str(o/'image.kseed')]),('extract',['extract-native',str(o/'image.kseed'),'--symbol','main','--output',str(o/'seed.bin')])]:
 q=subprocess.run([str(W/'kexe-loader'),str(W/'seed-0.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(o/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout[-2000:],q.stderr[-1000:])
 if label=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1);(o/'seed.offset').write_text(off+'\n')
rows=[];base=json.loads((W/'ports-build.json').read_text())['entries']
for e in json.loads((R/'bench/embench/comparison-matrix.json').read_text())['entries']:
 d=o/'ports'/e['workload'];d.mkdir(parents=True,exist_ok=True)
 for label,args in [('compile',['compile',str(R/e['source']),'--target','aarch64-macos','--output',str(d/'image.kseed')]),('extract',['extract-native',str(d/'image.kseed'),'--symbol',e['symbol'],'--output',str(d/'native.bin')])]:
  q=subprocess.run([str(W/'kexe-loader'),str(o/'seed.bin'),off,'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(e['workload'],label,q.stdout[-2000:],q.stderr[-1000:])
  if label=='extract':offset=int(re.search(r':offset (\d+)',q.stdout).group(1))
 old=next(x for x in base if x['workload']==e['workload']);assert sha(d/'native.bin')==old['nativeSha256'] and offset==old['offset']
 records=[list(map(int,l.split()[1:])) for l in (d/'compile.log').read_text().splitlines() if l.startswith('DCCERT ')];rows.append({'workload':e['workload'],'nativeSha256':sha(d/'native.bin'),'offset':offset,'admissions':records});print('PASS byte-exactobserver',e['workload'],'descriptorAdmissions',sum(r[8]==1 and r[9]>=2 and r[10]>0 for r in records),flush=True)
(o/'admission.json').write_text(json.dumps({'status':'PASS read-only observer byte+offset exact all19','schema':{'DCCERT':'i f np oldNSV fnCount oldFrame newFrame remainingBudget valid ownReads ownCalls pendingStack','DCCLOSURE':'rootSir f fnSir endSir remainingBudget valid','DIPRE':'i f t n end code fix frame ns dp h ctx vmode used sites','DIARGS':'temp descriptorKind descriptorValue sourceRegister homeSlot homeByteOffset','DIBODY':'calleeSir op a b firstWord afterWord skip','DIRESULT':'i f t n end code firstBody afterBody afterFinish fullSpanWords accepted priorUsed priorSites'},'entries':rows},indent=2)+'\n')
