from pathlib import Path
import subprocess,os,re,json,hashlib
W=Path(__file__).resolve().parent;D=W/'proof-controls';D.mkdir(exist_ok=True)
base=(W/'unity.kotoba').read_text().replace('(ns seed (:export [main]))','(ns seed (:export [main probe]))',1)
probe='''
(defn- cp-put [M :vector-i64 i :i64 op :i64 a :i64 b :i64 c :i64] :vector-i64
 (let [x (+ MM-SIR-BASE (* i MM-SIR-W))]
  (-> M (vector-assoc! x op) (vector-assoc! (+ x 1) a) (vector-assoc! (+ x 2) b) (vector-assoc! (+ x 3) c))))
(defn probe [case :i64] :i64
 (let [g 1000 f1 (+ MM-FN-BASE MM-FN-W) f2 (+ MM-FN-BASE (* 2 MM-FN-W))
       M (-> (vector-alloc (+ MM-SIR-BASE (* 20 MM-SIR-W)))
        (vector-assoc! gn-cell g) (vector-assoc! MM-FN-N (if (= case 18) 2049 3)) (vector-assoc! MM-SIR-N 15)
        (vector-assoc! (+ f1 FF-NPARAMS) 2) (vector-assoc! (+ f1 FF-NSLOTS) 2) (vector-assoc! (+ f1 FF-SIR) 1)
        (vector-assoc! (+ f2 FF-NPARAMS) (if (= case 15) 2 1)) (vector-assoc! (+ f2 FF-NSLOTS) 2) (vector-assoc! (+ f2 FF-SIR) (if (= case 14) 0 9))
        (gn-gs gn-f-leaf (if (= case 12) 1 0)) (gn-gs gn-f-fb (cond (= case 13) 0 (= case 8) 32768 (= case 28) 32736 (= case 29) 32752 :else 64))
        (gn-gs gn-f-nsv (cond (= case 7) 8 (= case 26) 7 (= case 27) -1 :else 0)) (gn-gs gn-f-vmode (cond (= case 9) 1 (= case 10) 2 (= case 11) 3 :else 0))
        (gn-gs gn-g-open (if (= case 6) 2 0)) (gn-gs gn-g-open-n (if (= case 6) 1 0))
        (cp-put 1 OP-FN 1 2 2) (cp-put 2 OP-RT RT-VECTOR-AT 0 2)
        (cp-put 3 OP-CALL 2 0 1) (cp-put 4 OP-RT RT-VECTOR-AT 0 2)
        (cp-put 5 (if (= case 17) OP-BR OP-LABEL) (if (= case 17) 77 1) 0 0)
        (cp-put 6 OP-LABEL (if (= case 16) 1 2) 0 0) (cp-put 7 OP-RET 0 0 0) (cp-put 8 OP-END 1 0 0)
        (cp-put 9 OP-FN 2 (if (= case 15) 2 1) 2)
        (cp-put 10 (cond (= case 2) OP-CALLI (= case 3) OP-CAP (= case 5) OP-FADDR (= case 19) OP-CALL (= case 22) OP-VEC :else OP-RT)
          (cond (= case 1) 232 (= case 4) 999 (= case 19) 1 (= case 23) 208 (= case 24) 48 (= case 25) 128 :else 224)
          0 (if (= case 19) 2 1))
        (cp-put 11 OP-CONST 0 0 0) (cp-put 12 OP-RET 0 0 0) (cp-put 13 OP-END (if (= case 20) 1 2) 0 0))
       result (dc-assign M 1 1 2)]
  (gn-g result gn-f-vmode)))
'''
expected=[4,0,0,0,0,0,0,0,0,1,2,3,0,0,0,0,0,0,0,4,0,4,4,4,0,0,4,0,4,0]
variants=[('pristine',None,None),('allow-reset','(56 64 72 112','(232 56 64 72 112'),('ignore-open','(defn- dc-target [M :vector-i64 f :i64 n :i64] :bool\n (if (or (<= f 0) (>= f (vector-at M MM-FN-N)) (gn-clamp-open M f)) false','(defn- dc-target [M :vector-i64 f :i64 n :i64] :bool\n (if (or (<= f 0) (>= f (vector-at M MM-FN-N)) false) false'),('allow-unknown-rt','(dc-runtime a)','true'),('allow-indirect','ordinary (case op','ordinary (case op'),('ignore-bank-pressure','(>= nsv 0) (<= nsv 7)','(>= nsv 0) true'),('ignore-frame-limit','(<= nsv 7) (<= frame 32768)\n           (> nf 1)','(<= nsv 7) true\n           (> nf 1)'),('skip-closure','proof (dc-closure M (dc-push S f) i)','proof (-> S (vector-assoc! 4 2) (vector-assoc! 5 1))')]
variants=[v for v in variants if v[0]!='allow-indirect']+[('one-visit-budget','(vector-alloc (+ 8 (* 2 nf))) (vector-assoc! 0 131072)','(vector-alloc (+ 8 (* 2 nf))) (vector-assoc! 0 1)')]
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/private/tmp:/Users/junkawasaki/github/wt/amu-seed17',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[]
for name,needle,replacement in variants:
 d=D/name;d.mkdir(exist_ok=True);source=base
 if needle is not None:assert source.count(needle)==1,(name,source.count(needle));source=source.replace(needle,replacement)
 (d/'source.kotoba').write_text(source+probe)
 for step,args in [('compile',['compile',str(d/'source.kotoba'),'--target','aarch64-macos','--output',str(d/'image.kseed')]),('extract',['extract-native',str(d/'image.kseed'),'--symbol','probe','--output',str(d/'native.bin')])]:
  q=subprocess.run([str(W/'kexe-loader'),str(W/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(step+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,step,q.stdout[-2000:],q.stderr[-2000:])
  if step=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1]);(d/'native.offset').write_text(str(off)+'\n')
 outcomes=[]
 for case in range(len(expected)):
  e=dict(os.environ,KEXE_STRUCTURED_REPORT='1',KEXE_FUEL='100000000',KEXE_VECTOR_ITEMS='134217728');e.pop('KEXE_COMMAND',None)
  q=subprocess.run([str(W/'kexe-loader'),str(d/'native.bin'),str(off),'1','aarch64','-',str(case)],env=e,capture_output=True,text=True);(d/f'case-{case}.stdout').write_text(q.stdout);(d/f'case-{case}.stderr').write_text(q.stderr);assert q.returncode==0,(name,case,q.stdout,q.stderr)
  outcomes.append(int(re.search(r':result (-?\d+)',q.stdout)[1]))
 if name=='pristine':assert outcomes==expected,(outcomes,expected)
 elif name=='one-visit-budget':assert outcomes==[1 if i==9 else 2 if i==10 else 3 if i==11 else 0 for i in range(len(expected))],outcomes
 else:assert outcomes!=expected,(name,'undetected')
 rows.append({'variant':name,'outcomes':outcomes,'status':'PASS finite budget fallback' if name=='one-visit-budget' else 'PASS pristine' if name=='pristine' else 'MUTATION DETECTED','nativeSha256':hashlib.sha256((d/'native.bin').read_bytes()).hexdigest()});print(name,outcomes,flush=True)
(D/'report.json').write_text(json.dumps({'status':'PASS actual native admission30cases and6actualsource mutation calibrations and actual one-visit fallback','nativeExecutions':len(expected)*len(variants),'rows':rows,'limits':'Synthetic SIR+generator-state predicate controls; not typed-source or whole compiler proof. Mutation artifacts separate from immutable primary.'},indent=2)+'\n')
