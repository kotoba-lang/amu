from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
g=(W/'baseline-41-a64gen.kotoba').read_text();helper=(W/'descriptor-native.kotoba').read_text()
g=g.replace('(defn- gn-chain-read [',helper+'\n(defn- gn-chain-read [',1)
g=g.replace('(if (= (gn-g M gn-f-vmode) 3) (gn-emit M (enc-movz (sl-flag M) 0 0)) (gn-vclear M))','(if (or (= (gn-g M gn-f-vmode) 3) (= (gn-g M gn-f-vmode) 4)) (gn-emit M (enc-movz (sl-flag M) 0 0)) (gn-vclear M))',1)
g=g.replace('(if (> (gn-g M gn-f-vmode) 0) (gn-mov-imm M 5 0) M)','(if (and (> (gn-g M gn-f-vmode) 0) (not= (gn-g M gn-f-vmode) 4)) (gn-mov-imm M 5 0) M)',1)
g=g.replace('(if (= (gn-g M gn-f-vmode) 0)\n  (-> M (gn-hchk rv 312 320)', '(if (= (gn-g M gn-f-vmode) 4) (dc-read M rv ri d)\n (if (= (gn-g M gn-f-vmode) 0)\n  (-> M (gn-hchk rv 312 320)',1)
a=g.index('(defn- gn-vread [');b=g.index(';; Compile-time witness only.',a);section=g[a:b];assert section.count('(gn-emit (gn-e-ldrr d 4 ri 1)))))')==1;g=g[:a]+section.replace('(gn-emit (gn-e-ldrr d 4 ri 1)))))','(gn-emit (gn-e-ldrr d 4 ri 1))))))',1)+g[b:]
g=g.replace('M2 (sl-assign (gn-vmode (gn-assign MM) i) i f np)','M2 (dc-assign (sl-assign (gn-vmode (gn-assign MM) i) i f np) i f np)',1)
assert g.count('(defn- dc-assign [')==1 and g.count('(dc-read M rv ri d)')==1 and g.count('(dc-assign (sl-assign')==1
(W/'41-a64gen-prototype.kotoba').write_text(g)
parts=[p.strip() for p in (R/'seed/MANIFEST').read_text().splitlines() if p.strip() and not p.lstrip().startswith('#')]
(W/'unity.kotoba').write_text('\n'.join(g if p=='seed/41-a64gen.kotoba' else (R/p).read_text() for p in parts))
for rel in parts+['seed/MANIFEST','seed/SIR','seed/HEADS','seed/MEMORY-MAP','bench/embench/comparison-matrix.json']:
 p=W/'source-snapshot'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(g if rel=='seed/41-a64gen.kotoba' else (R/rel).read_text())
(W/'source-pins.json').write_text(json.dumps({p.name:sha(p) for p in [W/'descriptor-native.kotoba',W/'41-a64gen-prototype.kotoba',W/'unity.kotoba']},indent=2)+'\n')
print('Separate preregistered descriptor candidate source prepared')
