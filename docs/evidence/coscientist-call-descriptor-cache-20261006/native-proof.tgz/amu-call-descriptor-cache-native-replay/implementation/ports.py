from pathlib import Path
import subprocess,os,re,json,hashlib
W=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[];off=(W/'seed-4.offset').read_text().strip()
for e in json.loads((R/'bench/embench/comparison-matrix.json').read_text())['entries']:
 name=e['workload'];d=W/'ports'/name;d.mkdir(parents=True,exist_ok=True);src=R/e['source'];assert sha(src)==e['expectedSourceSha256']
 for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(d/'image.kseed')]),('extract',['extract-native',str(d/'image.kseed'),'--symbol',e['symbol'],'--output',str(d/'native.bin')])]:
  q=subprocess.run([str(W/'kexe-loader'),str(W/'seed-4.bin'),off,'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,label,q.stdout[-1000:],q.stderr)
  if label=='extract':offset=int(re.search(r':offset (\d+)',q.stdout).group(1))
 base=next(x for x in json.loads((Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation/ports-build.json')).read_text())['entries'] if x['workload']==name)
 rows.append({'workload':name,'bytes':(d/'native.bin').stat().st_size,'nativeSha256':sha(d/'native.bin'),'offset':offset,'productByteIdentical':sha(d/'native.bin')==base['nativeSha256'],'iterations':e['iterations']});print(name,rows[-1]['bytes'],rows[-1]['productByteIdentical'],flush=True)
(W/'ports-build.json').write_text(json.dumps({'status':'complete-native-original19-candidate-build-only','semanticProofComplete':False,'entries':rows},indent=2)+'\n')
