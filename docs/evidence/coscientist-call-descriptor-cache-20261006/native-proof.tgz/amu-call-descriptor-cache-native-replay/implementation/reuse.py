from pathlib import Path
import re,json,os,subprocess
W=Path(__file__).resolve().parent;D=W/'reuse-control';D.mkdir(exist_ok=True);base=(W/'unity.kotoba').read_text().replace('(ns seed (:export [main]))','(ns seed (:export [main reuse]))',1)
C={k:int(v) for k,v in re.findall(r'\(def ([A-Z][A-Z0-9-]*) (-?\d+)\)',base)}
fn={1:{'NPARAMS':2,'NSLOTS':3,'DEPTH':2,'SIR':1,'PT0':C['TY-VEC'],'RTYPE':C['TY-I64']},2:{'NPARAMS':2,'NSLOTS':2,'DEPTH':2,'SIR':17,'PT0':C['TY-I64'],'RTYPE':C['TY-I64']}}
ops=[('FN',1,2,3),('FUEL',0,0,0),('LGET',0,1,0),('LGET',1,2,0),('RT',176,0,2),('LGET',1,2,0),('CALL',2,0,2),('LSET',3,0,0),('LGET',0,1,0),('LGET',1,2,0),('RT',176,0,2),('LGET',1,3,0),('BIN',C['BOP-ADD'],0,0),('RET',0,0,0),('CONST',0,0,0),('END',1,0,0),('FN',2,2,2),('FUEL',0,0,0),('LGET',0,1,0),('LGET',1,2,0),('BIN',C['BOP-ADD'],0,0),('RET',0,0,0),('END',2,0,0)]
sets={C['MM-FN-N']:3,C['MM-SIR-N']:24,C['MM-CODE-N']:1,C['MM-FIX-N']:1,C['MM-LABEL-N']:1}
for f,fields in fn.items():
 for k,v in fields.items():sets[C['MM-FN-BASE']+f*C['MM-FN-W']+C['FF-'+k]]=v
 sets[C['MM-FN-BASE']+f*C['MM-FN-W']+C['FF-PT0']+1]=C['TY-I64']
for i,(op,a,b,c) in enumerate(ops,1):
 for k,v in enumerate([C['OP-'+op],a,b,c]):sets[C['MM-SIR-BASE']+i*C['MM-SIR-W']+k]=v
loads='(defn- rr-init [M :vector-i64] :vector-i64 (-> M\n'+'\n'.join(f' (mem-set {k} {v})' for k,v in sets.items())+'))\n'
probe='''
(defn- rr-copy [M :vector-i64 V :vector-i64 base :i64 i :i64 n :i64] :vector-i64 (if (= i n) V (rr-copy M (mem-set V i (vector-at M (+ base i))) base (inc i) n)))
(defn- rr-equal [M :vector-i64 V :vector-i64 base :i64 i :i64 n :i64] :bool (if (= i n) true (and (= (vector-at V i) (vector-at M (+ base i))) (rr-equal M V base (inc i) n))))
(defn- rr-key [M :vector-i64 i :i64 end :i64] :bool (if (>= i end) false (or (= (vector-at M (+ MM-CODE-BASE i)) (enc-movz 24 0 0)) (rr-key M (inc i) end))))
(defn reuse [unused :i64] :i64
 (let [M (rr-init (vector-alloc MM-WORDS)) sn (* 4 (vector-at M MM-SIR-N)) S (rr-copy M (vector-alloc sn) MM-SIR-BASE 0 sn)
       a (gn-run M) cn (vector-at a MM-CODE-N) V (rr-copy a (vector-alloc cn) MM-CODE-BASE 0 cn)
       source1 (rr-equal a S MM-SIR-BASE 0 sn) key1 (rr-key a (gn-fnf a 1 FF-CODE) (gn-fnf a 2 FF-CODE))
       o (gn-run-open (-> a (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1) (mem-set MM-LABEL-N 1)) 2 1)
       source2 (rr-equal o S MM-SIR-BASE 0 sn) key2 (rr-key o (gn-fnf o 1 FF-CODE) (gn-fnf o 2 FF-CODE))
       b (gn-run (-> o (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1) (mem-set MM-LABEL-N 1)))
       source3 (rr-equal b S MM-SIR-BASE 0 sn) code3 (and (= cn (vector-at b MM-CODE-N)) (rr-equal b V MM-CODE-BASE 0 cn))]
  (if (not= (vector-at b MM-ERR) 0) -1
   (+ (if source1 1 0) (if source2 2 0) (if source3 4 0) (if key1 8 0) (if (not key2) 16 0) (if code3 32 0)))))
'''
(D/'source.kotoba').write_text(base+loads+probe);env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/private/tmp:/Users/junkawasaki/github/wt/amu-seed17',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for stage,args in [('compile',['compile',str(D/'source.kotoba'),'--target','aarch64-macos','--output',str(D/'image.kseed')]),('extract',['extract-native',str(D/'image.kseed'),'--symbol','reuse','--output',str(D/'native.bin')])]:
 q=subprocess.run([str(W/'kexe-loader'),str(W/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(D/(stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(stage,q.stdout[-1000:],q.stderr)
 if stage=='extract':off=re.search(r':offset (\d+)',q.stdout)[1]
env.pop('KEXE_COMMAND');env['KEXE_STRUCTURED_REPORT']='1';env['KEXE_FUEL']='100000000';q=subprocess.run([str(W/'kexe-loader'),str(D/'native.bin'),off,'1','aarch64','-','0'],env=env,capture_output=True,text=True);(D/'stdout').write_text(q.stdout);(D/'stderr').write_text(q.stderr);assert q.returncode==0 and re.search(r':result 63\b',q.stdout),(q.returncode,q.stdout,q.stderr)
(D/'report.json').write_text(json.dumps({'status':'PASS actual native same-M closed/open/closed descriptor cache code+source restoration','result':63,'sourceOriginalCallsUnchanged':True,'closedContainsSavedKeyInitialization':True,'openExcludedTargetRemovesSavedKeyInitialization':True,'closedAgainCodeByteIdentical':True,'limitations':'Synthetic well-formed SIR native generator control; code produced here is compared, not itself executed. Runtime typed semantic controls remain independent.'},indent=2)+'\n');print('PASS same-M mode4 closed/open/closed',flush=True)
