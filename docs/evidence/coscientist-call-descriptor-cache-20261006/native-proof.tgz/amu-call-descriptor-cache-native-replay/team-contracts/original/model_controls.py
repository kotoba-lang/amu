from pathlib import Path
import json,hashlib,itertools
W=Path(__file__).resolve().parent
I=W.parent/'implementation'
rows=[]
def test(name,fn):
 fn();rows.append({'name':name,'status':'PASS'})
class Arena:
 def __init__(self):self.rows=[];self.items=[]
 def alloc(self,x):
  off=len(self.items);self.items+=x;self.rows.append((off,len(x)));return len(self.rows)
 def read(self,h,i):
  if not 1<=h<=len(self.rows):return 'handle-trap'
  off,n=self.rows[h-1]
  if not 0<=i<n:return 'index-trap'
  return self.items[off+i]
class Cache:
 def __init__(self):self.key=0;self.length=0;self.base=0
 def read(self,a,h,i):
  if not self.key or h!=self.key:
   self.key=h
   if not 1<=h<=len(a.rows):return 'handle-trap'
   self.base,self.length=a.rows[h-1]
  if not 0<=i<self.length:return 'index-trap'
  return a.items[self.base+i]
def exhaustive():
 for x,y in itertools.product(range(4),repeat=2):
  a=Arena();h=a.alloc(list(range(x)));q=a.alloc(list(range(10,10+y)));c=Cache()
  for handle,index in itertools.product([0,h,q,q+1,-1],range(-1,5)):
   # A trap is terminal; never reuse a failed validation witness.
   z=c.read(a,handle,index);assert z==a.read(handle,index)
   if isinstance(z,str):c=Cache()
   if a.items:a.items[0]+=1
   r=a.alloc([99]);assert c.read(a,r,0)==a.read(r,0)
def writes():
 a=Arena();h=a.alloc([2,3]);c=Cache();assert c.read(a,h,0)==2
 a.items[0]=99;assert c.read(a,h,0)==99
 q=a.alloc([8]);assert c.read(a,q,0)==8 and c.read(a,h,1)==3
def unsafe_reset():
 a=Arena();h=a.alloc([1,2,3]);c=Cache();assert c.read(a,h,2)==3
 a.rows=[(0,1)];a.items[0]=9;q=1;assert q==h
 assert c.read(a,q,1)!=a.read(q,1) # detects stale length and base after recycle
# Abstract whole-body closure, deliberately independent of native execution.
def admitted(bodies,root=0,open_targets=(),cap=1000):
 todo=[root];seen={root}
 while todo:
  f=todo.pop()
  if f in open_targets or f not in bodies:return False
  body=bodies[f]
  if len(body)>8192:return False
  labels=[x[1] for x in body if x[0]=='label']
  for x in body:
   cap-=1
   if cap<0:return False
   if x[0]=='call':
    if x[1] not in bodies or x[1] in open_targets:return False
    if x[1] not in seen:seen.add(x[1]);todo.append(x[1])
   elif x[0]=='rt':
    if x[1] not in {56,64,72,112,120,136,144,152,160,168,176,184,192,200,208,216,224,240,352,360,368,376}:return False
   elif x[0] in {'label','branch'}:
    if x[1]<=0 or labels.count(x[1])!=1:return False
   elif x[0] not in {'arith','ret','read','write','fuel','trap'}:return False
 return True
def closure_controls():
 safe={0:[('read',),('call',1),('read',),('ret',)],1:[('rt',208),('ret',)]}
 assert admitted(safe)
 for bad in [('rt',232),('rt',48),('rt',128),('rt',999),('indirect',),('faddr',),('cap',)]:
  d={**safe,1:safe[1]+[bad]};assert not admitted(d)
 # Unsafe operations after return/unreachable labels are still scanned.
 assert not admitted({0:[('ret',),('rt',232)]})
 assert not admitted(safe,open_targets=(1,))
 assert not admitted({0:[('call',2)]})
 assert admitted({0:[('call',1)],1:[('call',0)]})
 assert not admitted(safe,cap=1)
 assert admitted({0:[('branch',4),('label',4),('call',1)],1:[]})
 assert not admitted({0:[('branch',4)],1:[]})
 assert not admitted({0:[('label',4),('label',4)]})
def banks():
 for old in range(8):
  bank={19+old,20+old,21+old};assert max(bank)<=28
  assert not bank.intersection(range(19,19+old))
  assert not bank.intersection(range(19))
  for frame in range(16,32769,16):
   delta=((8*(old+3)+15)//16*16)-((8*old+15)//16*16)
   new=frame+delta
   if new<=32768:assert delta in (16,32) and new%16==0
 assert 8+3>10 # pressure beyond oldNSV7 refused
for name,fn in [('finite-all-read-handle-index-append',exhaustive),('fresh-item-write-new-length-handle-reassignment',writes),('unsafe-reset-recycled-key-counterexample',unsafe_reset),('transitive-whole-body-path-join-cycle-budget-controls',closure_controls),('register-bank-and-frame-boundary-enumeration',banks)]:test(name,fn)
pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [I/'descriptor-native.kotoba',I/'41-a64gen-prototype.kotoba',I/'seed-4.bin',Path('/Users/junkawasaki/github/wt/amu-seed17/tools/kexe_loader.c')]}
out={'status':'PASS independent finite contract controls; native binding pending','controls':rows,'pins':pins,'nativeExecutions':0,'limitations':['Independent abstract models do not prove source/native compiler semantics.','Trap is terminal; failed validation cannot be reused.','Trusted loader slot implementations and native AAPCS preservation are required.','Compiler proof scratch allocation and increased OS stack budget equivalence unproved.']}
(W/'model-controls.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
