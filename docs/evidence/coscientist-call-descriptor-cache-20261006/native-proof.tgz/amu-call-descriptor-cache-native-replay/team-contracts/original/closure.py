from pathlib import Path
import json
W=Path(__file__).resolve().parent;I=W.parent/'implementation'
ordinary={3,4,5,6,7,8,16,17,18,19,20,21,24,25,26}
# Derive opcode numbers from pinned source definitions, no diagnostic table assumptions.
import re
ns=Path('/Users/junkawasaki/github/wt/amu-seed17/seed/00-ns.kotoba').read_text()
ops={k:int(v) for k,v in re.findall(r'\(def (OP-[A-Z0-9-]+) (\d+)\)',ns)}
ordinary={ops['OP-'+k] for k in ['CONST','LGET','LSET','BIN','CMP','UN','STR','VEC','VECP','FUEL','RET','RET2','RES2','TRAP','TAB']}
allowed={56,64,72,112,120,136,144,152,160,168,176,184,192,200,208,216,224,240,352,360,368,376}
rows=[]
for p in sorted((I/'observer/ports').iterdir()):
 sir={};cert={};closures={};cache={}
 for line in (p/'compile.log').read_text().splitlines():
  q=line.split()
  if q and q[0] in ('SIR','DCCERT','DCCLOSURE','CACHE'):
   v=list(map(int,q[1:]))
   if q[0]=='SIR':sir[v[0]]=v[1:]
   if q[0]=='DCCERT':cert[v[0]]=v
   if q[0]=='DCCLOSURE':closures.setdefault(v[0],[]).append(v)
   if q[0]=='CACHE':cache[v[0]]=v
 starts={op[1]:i for i,op in sir.items() if op[0]==1}
 count=visits=0
 for root,v in cert.items():
  if cache[root][3]!=4:continue
  count+=1;pending=[sir[root][1]];seen=set(pending);budget=131072;reads=calls=0;walk=[]
  while pending:
   f=pending.pop();start=starts[f];end=start+1
   while sir[end][0]!=2:
    assert end-start<=8192 and sir[end][0]!=1;end+=1
   assert sir[end][1:]==[f,0,0]
   budget-=end-start
   walk.append((root,f,start,end,budget,1))
   labels=[op[1] for i,op in sir.items() if start<i<end and op[0]==9]
   for i in range(start+1,end):
    op,a,b,c=sir[i];budget-=1
    if start==root:
     reads+=op==14 and a==176 and c==2;calls+=op==13
    if op in ordinary:continue
    if op==14:assert a in allowed
    elif op==13:
     assert a in starts and sir[starts[a]][2]==c and 0<=c<=16
     if a not in seen:seen.add(a);pending.append(a)
    elif op in (9,10,11,12):
     lab=a if op in (9,10) else b
     assert 0<lab<65536 and labels.count(lab)==1 and c==0
     if op in (9,10):assert b==0
     budget-=end-start-1
    else:raise AssertionError((p.name,root,i,op))
  assert walk==[tuple(x) for x in closures[root]],(p.name,root,walk,closures[root])
  assert budget==v[7] and reads==v[9] and calls==v[10] and budget>=0
  visits+=131072-budget
 rows.append({'workload':p.name,'admittedClosures':count,'accountedScanLabelVisits':visits})
(W/'closure-report.json').write_text(json.dumps({'status':'PASS exact whole-body SIR closure and shared visit budget replay all97admissions','rows':rows,'limits':['Open-target marker guarded by frozen native source; observer SIR cannot independently infer import-open MM state.','Upstream verified SIR/type integrity and actual ABI preservation required; not arbitrary malformed IR proof.']},indent=2)+'\n');print(rows)
