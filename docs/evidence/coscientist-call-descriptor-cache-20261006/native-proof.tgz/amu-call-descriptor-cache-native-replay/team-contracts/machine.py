from pathlib import Path
import struct,json,collections,copy,hashlib
W=Path(__file__).resolve().parent;I=W.parent/'implementation';B=W.parent/'baseline/observer/ports'
def branch(z):
 def sg(n,b):return n-(1<<b) if n&(1<<(b-1)) else n
 if z&0x7c000000==0x14000000:return z&0xfc000000,sg(z&0x3ffffff,26)
 if z&0xff000010==0x54000000:return z&0xff00001f,sg((z>>5)&0x7ffff,19)
 if z&0x7e000000==0x34000000:return z&0xff00001f,sg((z>>5)&0x7ffff,19)
 if z&0x7e000000==0x36000000:return z&0xfff8001f,sg((z>>5)&0x3fff,14)
 if z&0x9f000000==0x10000000:return z&0x9f00001f,sg(((z>>5)&0x7ffff)*4+((z>>29)&3),21)/4
 return None
def parse(p):
 d={'sir':{},'fn':{},'events':[],'fix':[],'raw':(p/'native.bin').read_bytes()}
 for l in (p/'compile.log').read_text().splitlines():
  x=l.split()
  if not x:continue
  if x[0]=='SIR':d['sir'][int(x[1])]=tuple(map(int,x[2:]))
  if x[0]=='FN':d['fn'][int(x[1])]=tuple(map(int,x[2:]))
  if x[0]=='EMIT':d['events'].append(tuple(map(int,x[1:])))
  if x[0]=='FIX':d['fix'].append(tuple(map(int,x[1:])))
 d['n']=max(e[3] for e in d['events']);d['words']=[x[0] for x in struct.iter_unpack('<I',d['raw'][:4*(d['n']-1)])];return d

# Independent encoders for the precise rewritten sequence.
def pair(n,ld,out=0):
 return [(0xa9400000 if ld else 0xa9000000)|(((out+j*8)//8&127)<<15)|((20+j)<<10)|(31<<5)|(19+j) for j in range(0,n-1,2)]+([] if n%2==0 else [(0xf9400000 if ld else 0xf9000000)|(((out+8*(n-1))//8)<<10)|(31<<5)|(18+n)])
def subsp(f):return ([0xd14003ff|((f//4096)<<10)] if f//4096 else [])+([0xd10003ff|((f%4096)<<10)] if f%4096 else [])
def addsp(f):return ([0x914003ff|((f//4096)<<10)] if f//4096 else [])+([0x910003ff|((f%4096)<<10)] if f%4096 else [])
def readblocks(old,nsv):
 # Exact final15 words of the ordinary inline read. Prefix argument/context moves remain.
 h=old[-15:];assert len(h)==15 and h[0]==0xf9409cf0 and h[1]==0xf9400210 and h[4]==0x54000043 and h[5]==0
 rv=(h[2]>>5)&31;ri=(h[9]>>5)&31;d=h[14]&31
 assert h==[0xf9409cf0,0xf9400210,0xd1000400|(rv<<5)|17,0xeb10023f,0x54000043,0,0xf940a0f0,0x8b111210,0xa9404211,0xeb10001f|(ri<<5),0x54000043,0,0xf940a4f0,0x8b000231|(ri<<16),0xf8717a00|d],('ordinary-read',h)
 le,ba,ke=19+nsv,20+nsv,21+nsv
 assert all(r<19+nsv for r in (rv,ri,d))
 new=[0xb4000060|ke,0xeb00001f|(ke<<16)|(rv<<5),0x540001a0]
 if ke!=rv:new+=[0xaa0003e0|(rv<<16)|ke]
 new += [0xf9409cf0,0xf9400210,0xd1000400|(ke<<5)|17,0xeb10023f,0x54000043,0,0xf940a0f0,0x8b111210,0xa9400211|(le<<10),0xf940a4e0|ba,0x8b110c00|(ba<<5)|ba,0xeb00001f|(le<<16)|(ri<<5),0x54000043,0,0xf8607800|(ri<<16)|(ba<<5)|d]
 return h,new

def load(p):
 d=parse(p);d['cache']={};d['cert']={};d['closure']=collections.defaultdict(list)
 for line in (p/'compile.log').read_text().splitlines():
  q=line.split()
  if not q:continue
  v=tuple(map(int,q[1:])) if q[0] in ('CACHE','DCCERT','DCCLOSURE') else ()
  if q[0]=='CACHE':d['cache'][v[0]]=v
  if q[0]=='DCCERT':d['cert'][v[0]]=v
  if q[0]=='DCCLOSURE':d['closure'][v[0]].append(v)
 return d

def audit(a,b):
 assert a['sir']==b['sir'] and a['fn'].keys()==b['fn'].keys()
 changed={};outgoing={};owner={};f=0
 for i,op in a['sir'].items():
  if op[0]==1:f=op[1]
  owner[i]=f
 for f,x in a['fn'].items():
  y=b['fn'][f]
  if x[:-1]!=y[:-1]:
   si,frame,ns,dp,nsv,leaf,code=x;assert 0<=nsv<=7 and leaf==0
   delta=((8*(nsv+3)+15)//16*16)-((8*nsv+15)//16*16)
   assert y[:-1]==(si,frame+delta,ns,dp,nsv+3,leaf)
   cert=b['cert'][si];assert cert[:7]==(si,f,a['sir'][si][2],nsv,cert[4],frame,frame+delta)
   assert cert[8:]==(1,cert[9],cert[10],0) and cert[9]>=2 and cert[10]>0
   assert b['cache'][si][3]==4 and a['cache'][si][3]==0
   changed[f]=(nsv,frame,delta)
   pro=next(e for e in b['events'] if e[0]==si);zw=b['words'][pro[2]-1+2+len(subsp(frame+delta))];outgoing[f]=((zw>>15)&127)*8
 # Canonical whole-stream projection using event ranges.
 stream=[[],[]];positions=[{},{}];edges=[[],[]];removed=[set(),set()];readcount=0
 assert [(e[0],e[1]) for e in a['events']]==[(e[0],e[1]) for e in b['events']]
 for ea,eb in zip(a['events'],b['events']):
  si=ea[0];op=a['sir'][si];f=owner[si];xx=a['words'][ea[2]-1:ea[3]-1];yy=b['words'][eb[2]-1:eb[3]-1];replacements=[{},{}]
  if f in changed:
   nsv,fr,de=changed[f]
   if op[0]==1:
    prefix=[0xa9bf7bfd,0x910003fd];assert xx[:2]==yy[:2]==prefix
    old=prefix+subsp(fr)+pair(nsv,False,outgoing[f]);new=prefix+subsp(fr+de)+pair(nsv+3,False,outgoing[f])
    assert xx[:len(old)]==old and yy[:len(new)]==new, (si,f,xx,yy,old,new)
    assert yy[-1]==0xd2800000|(21+nsv)
    replacements[0][0]=(len(old),('PROLOGUE',f));replacements[1][0]=(len(new),('PROLOGUE',f));replacements[1][len(yy)-1]=(1,None)
   if xx and (xx[-1]==0xd65f03c0 or (branch(xx[-1]) and xx[-1]&0xfc000000==0x14000000)) and 0x910003bf in xx:
    old=pair(nsv,True,outgoing[f])+[0x910003bf,0xa8c17bfd];new=pair(nsv+3,True,outgoing[f])+[0x910003bf,0xa8c17bfd]
    assert xx[-len(old)-1:-1]==old and yy[-len(new)-1:-1]==new, (si,op,xx,yy,old,new)
    replacements[0][len(xx)-len(old)-1]=(len(old),('EPILOGUE',f));replacements[1][len(yy)-len(new)-1]=(len(new),('EPILOGUE',f))
   if xx and op[0]==14 and op[1]==176 and op[3]==2 and any(xx[j:j+2]==[0xf9409cf0,0xf9400210] for j in range(len(xx)-14)):
    assert any(xx[j:j+2]==[0xf9409cf0,0xf9400210] for j in range(len(xx)-14)),(si,ea,xx,yy)
    rstart=next(j for j in range(len(xx)-14) if xx[j:j+2]==[0xf9409cf0,0xf9400210]);old,new=readblocks(xx[rstart:rstart+15],nsv);ystart=next(j for j in range(len(yy)) if yy[j]==(0xb4000060|(21+nsv)));assert yy[ystart:ystart+len(new)]==new,('new-read',si,yy,new)
    replacements[0][rstart]=(len(old),('READ',si));replacements[1][ystart]=(len(new),('READ',si));readcount+=1
  for k,(d,e,words) in enumerate(((a,ea,xx),(b,eb,yy))):
   j=0;lit={at:(t,u) for ix,at,kind,t,u in d['fix'] if kind==5}
   while j<len(words):
    at=e[2]+j;positions[k][at]=len(stream[k])
    if j in replacements[k]:
     count,token=replacements[k][j]
     for z in range(count):positions[k][at+z]=len(stream[k]);removed[k].add(at+z)
     if token is not None:stream[k].append(token)
     j+=count;continue
    z=words[j];br=branch(z)
    if br:stream[k].append(('BR',br[0]));edges[k].append((len(stream[k])-1,at+br[1]))
    elif at in lit or at-1 in lit:stream[k].append(('LIT',lit.get(at,lit.get(at-1)),z&~0x1fffe0))
    else:
     # All SP-relative scalar homes shift by frame growth; original argument outgoing area stays fixed.
     if k and f in changed and z&0xffc003e0 in (0xf94003e0,0xf90003e0):
      off=((z>>10)&4095)*8
      if off>=outgoing[f]+((8*(changed[f][0]+3)+15)//16*16):z-= (changed[f][2]//8)<<10
     stream[k].append(('WORD',z))
    j+=1
   positions[k][e[3]]=len(stream[k])
 
 if stream[0]!=stream[1]:
  ix=next(i for i,(x,y) in enumerate(zip(*stream)) if x!=y)
  print('DIAGNOSTIC',[(k,[(e,a['sir'][e[0]]) for e in a['events'] if any(positions[k].get(j)==ix for j in range(e[2],e[3]))][:5]) for k in (0,1)])
 assert stream[0]==stream[1],next(((i,x,y) for i,(x,y) in enumerate(zip(*stream)) if x!=y),(len(stream[0]),len(stream[1])))
 assert len(edges[0])==len(edges[1])
 for x,y in zip(*edges):assert x[0]==y[0] and positions[0][x[1]]==positions[1][y[1]],('edge',x,y)
 for f,x in a['fn'].items():assert positions[0][x[-1]]==positions[1][b['fn'][f][-1]]
 for ea,eb in zip(a['events'],b['events']):assert positions[0][ea[2]]==positions[1][eb[2]] and positions[0][ea[3]]==positions[1][eb[3]]
 assert len(a['fix'])==len(b['fix'])
 pool=[((d['n']-1)*4+7)//8*8 for d in (a,b)]
 for x,y in zip(a['fix'],b['fix']):
  ix,at,kind,t,u=x;iy,bt,l,s,v=y;assert (ix,kind,t,u)==(iy,l,s,v) and positions[0][at]==positions[1][bt]
  if kind==5:
   val=lambda d,q:((d['words'][q-1]>>5)&65535)|(((d['words'][q]>>5)&65535)<<16)
   assert val(a,at)-pool[0]==val(b,bt)-pool[1]
 assert a['raw'][pool[0]:]==b['raw'][pool[1]:]
 for d,po in zip((a,b),pool):assert set(d['raw'][(d['n']-1)*4:po])<={0}
 return {'admittedFunctions':len(changed),'reads':readcount,'remainingTokens':len(stream[0]),'remainingEdges':len(edges[0]),'addedWords':b['n']-a['n']}
rows=[];datasets={}
for p in sorted((I/'observer/ports').iterdir()):
 a=load(B/p.name);b=load(p);assert a['raw']==(B.parent.parent/'ports'/p.name/'native.bin').read_bytes();assert b['raw']==(I/'ports'/p.name/'native.bin').read_bytes();datasets[p.name]=(a,b);r=audit(a,b);rows.append({'workload':p.name,**r});print(p.name,r,flush=True)
controls=[]
a,b=datasets['edn'];events={e[0]:e for e in b['events']};si=442;rd=447;start=events[rd][2];pro=events[si][2]
faults=[('key-initialization',events[si][3]-1,1),('bank-prologue-save',pro+4,32),('first-read-key-guard',start+2,1),('first-read-descriptor-length',start+14,1024),('fresh-item-load',events[rd][3]-1,32),('ordinary-arithmetic',events[454][3]-1,1),('home-offset',events[452][2],1024),('original-direct-call-edge',events[452][3]-2,4)]
for name,at,mask in faults:
 d=copy.deepcopy(b);d['words'][at-1]^=mask
 try:audit(a,d)
 except (AssertionError,KeyError,IndexError,StopIteration) as e:controls.append({'name':name,'status':'REFUSED','word':at,'diagnostic':str(e)[:200]})
 else:raise AssertionError('undetected fault '+name)
(W/'machine-report.json').write_text(json.dumps({'status':'PASS all19 complete machine projection','rows':rows,'controls':controls,'totals':dict(sum((collections.Counter({k:v for k,v in r.items() if isinstance(v,int)}) for r in rows),collections.Counter())),'limits':['Exact source emission blocks checked and replaced only for whole-stream projection; this is not a full compiler semantics proof.','SP home shifts normalized only above unchanged outgoing plus new saved-bank area.','All original fixups, projected branch edges and literal-pool bytes retained.']},indent=2)+'\n')
