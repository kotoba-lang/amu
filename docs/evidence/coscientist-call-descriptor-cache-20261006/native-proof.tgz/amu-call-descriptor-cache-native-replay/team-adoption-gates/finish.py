from pathlib import Path
import json,hashlib,shutil
D=Path(__file__).resolve().parent;I=D.parent/'implementation';S=D/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());U=D/'unit-build/unit/41-a64gen';old=Path('/private/tmp/amu-scalar-dag-inline-20261006/root-proof/unit-build/unit/41-a64gen/stdout');expected=S/'seed/tests/unit/41-a64gen.expected';actual=U/'stdout';assert actual.read_bytes()==expected.read_bytes()==old.read_bytes();assert len(actual.read_text().splitlines())==5227
# Independently reconstruct the unit's actual emitted word/pool and public offsets.
def blob_from(stdout):
 words=[];lits=[];fns={};end=None
 for line in stdout.splitlines():
  p=line.split()
  if not p:continue
  if p[0]=='w':words += [int(x,16) for x in p[1:]]
  elif p[0]=='lit':lits.append((int(p[1]),bytes.fromhex(p[2]) if len(p)>2 else b''))
  elif p[0]=='fn':fns[int(p[1])]=int(p[2])
  elif p[0]=='end':end=int(p[1])
 blob=bytearray(b''.join(w.to_bytes(4,'little') for w in words));blob+=b'\0'*(end-len(blob))
 for off,bs in lits:blob[off:off+len(bs)]=bs
 return bytes(blob),fns
b,f=blob_from(actual.read_text());ob,of=blob_from(old.read_text());eb,ef=blob_from(expected.read_text());assert b==ob==eb and f==of==ef;(D/'unit-generated-blob.bin').write_bytes(b);(D/'unit-generated-offsets.json').write_text(json.dumps(f,indent=2)+'\n')
rows=[l.split('\t') for l in (D/'gate-build/gates/r6m/summary.tsv').read_text().splitlines()];assert set(r[0] for r in rows)=={'BUILD','ERR','G1','G2','G3','G4','G5'} and all(r[1]=='PASS' for r in rows);ex=load(D/'execution-status.json');assert len(ex)==4 and all(r['status']==0 for r in ex)
F=D.parent/'team-fixture-regressions';fr=load(F/'report.json');assert sha(F/'report.json')=='46c07202e9752acb5dbfcf33ca5d4ce321115da45c529faacd5432d7f2cba9c6';assert fr['seedSha256']==sha(I/'seed-4.bin') and fr['nativeObservations']==435
ref={}
for name in ['report.json','readonly/report.json','scalar/report.json']:
 p=F/name;q=D/'referenced-fresh-fixtures'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);ref[name]={'path':str(p),'sha256':sha(p)}
for rel,h in fr['committedSourcePins'].items():assert sha(S/rel)==h,(rel,'standalone source differs')
report={'status':'PASS terminal first-run pre-adoption formal module5227 and all7 BUILD ERR G1-G5 gates','writesComplete':True,'candidateSeedSha256':sha(I/'seed-4.bin'),'candidateBytes':(I/'seed-4.bin').stat().st_size,'sourceLineage':load(D/'source-lineage.json'),'formalUnit':{'module':'41-a64gen','status':0,'lines':5227,'stdoutBytes':actual.stat().st_size,'stdoutSha256':sha(actual),'trackedGoldenSha256':sha(expected),'previousAdoptedActualSha256':sha(old),'fullRawGoldenAndPreviousByteIdentical':True,'unitProgramSha256':sha(U/'unit.bin'),'unitProgramOffset':int((U/'unit.offset').read_text()),'generatedCodeBlobSha256':sha(D/'unit-generated-blob.bin'),'generatedCodeBytes':len(b),'generatedFunctions':len(f),'allGeneratedCodePoolAndOffsetsExactPrevious':True},'requiredGates':rows,'firstRunRawReceipts':ex,'setupFailures':0,'realOracleFailures':0,'reruns':0,'goldenChanges':0,'standaloneFreshFixtureReceipts':ref,'standaloneCurrentCandidateObservations':435,'standaloneReadonlyObservations':117,'standaloneScalarObservations':318,'standalonePhysicalChecks':28,'duplicateStandaloneExecution':False,'allStandaloneFixtureSourcesBoundToOwned44bfSnapshot':True,'limits':['Formal generation lineage maps current frozen native generations2/3/4 to gatecompiler0/1/2; compiler0 is not stage0.','G2 unchanged registered result65/66 equal to stage0 and1frontend refusal; not universal stage0 acceptance parity.','Formal G1 uses correct single-iteration ports; measured batch19 timing provenance is separate.','Gate durations and kexe-benchmark numbers are validation diagnostics, not performance claims.','No timing campaign, SSH, product/expected/source edits outside owned snapshot, adoption, main merge, release or full-goal-complete claim.']};(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
pins={str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in D.rglob('*') if p.is_file() and p.name!='artifact-pins.json' and '__pycache__' not in p.parts};(D/'artifact-pins.json').write_text(json.dumps(pins,indent=2)+'\n');print(json.dumps({'reportSha256':sha(D/'report.json'),'artifactPinsSha256':sha(D/'artifact-pins.json'),'pinCount':len(pins),'unitBlobBytes':len(b),'unitFunctionCount':len(f)},indent=2))
