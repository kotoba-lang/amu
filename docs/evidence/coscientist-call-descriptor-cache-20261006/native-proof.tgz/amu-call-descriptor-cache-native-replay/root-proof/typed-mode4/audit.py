from pathlib import Path
import json,re,struct,os,subprocess,hashlib
D=Path(__file__).resolve().parent;W=D.parent.parent/'implementation';B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation');L=Path('/private/tmp/amu-private-length-clones-20261006/full-state-loader');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ns={'struct':struct};s=Path('/private/tmp/amu-stable-vector-cfg-20261006/team-resource/callee.py').read_text().split('def wrap(raw,off):',1)[1].split('rows=[]',1)[0];exec('def wrap(raw,off):'+s,ns);wrap=ns['wrap'];rows=[];env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/private/tmp:/Users/junkawasaki/github/wt/amu-seed17',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
# One authoring exception: existing measured public entries are unary; this
# five-arg fixture combines argument order, alias write, append allocation,
# loop/join and genuine closed call in one demonstrably admitted function.
(D/'authoring-exception.json').write_text(json.dumps({'authorization':'Root explicitly assigned one-time typed mode4 fixture authoring; reuse prioritized','reason':'Existing measured entry points are unary; a single five-argument fixture is needed to test argument order and live caller temps across an alias-writing allocating loop callee','newFixtures':1,'baselineOracleUnchanged':True,'noMeasurements':True},indent=2)+'\n')
fixture={}
for lab,compiler,offset in [('baseline',B/'seed-4.bin','0'),('candidate',W/'seed-4.bin','0'),('observer',W/'observer/seed.bin',(W/'observer/seed.offset').read_text().strip())]:
 p=D/lab;p.mkdir(exist_ok=True)
 for stage,args in [('compile',['compile',str(D/'read-call-write.kotoba'),'--target','aarch64-macos','--output',str(p/'image.kseed')]),('extract',['extract-native',str(p/'image.kseed'),'--symbol','walk','--output',str(p/'native.bin')])]:
  q=subprocess.run([str(W/'kexe-loader'),str(compiler),offset,'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(p/(stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(lab,stage,q.stdout,q.stderr)
  if stage=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1]);(p/'native.offset').write_text(str(off)+'\n')
 fixture[lab]=(p/'native.bin',off)
assert fixture['observer'][0].read_bytes()==fixture['candidate'][0].read_bytes() and fixture['observer'][1]==fixture['candidate'][1]
cert=[list(map(int,l.split()[1:])) for l in (D/'observer/compile.log').read_text().splitlines() if l.startswith('DCCERT ')];accepted=[r for r in cert if r[8]==1 and r[9]>=2 and r[10]>0];assert accepted,cert
# Preserve independent typed baseline/candidate full state including fuel and
# prefix traps/partial writes, and sentinel all newly reserved banks on success.
argslist=[(0,1,2,3,4),(1,2,3,4,5),(-1,7,-11,13,-17),(9223372036854775807,-9223372036854775808,0,-1,1),(-9223372036854775808,9223372036854775807,17,-17,9)]
def run(p,off,args,fuel):
 e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
 q=subprocess.run([str(L),str(p),str(off),str(len(args)),'aarch64','-',*map(str,args)],env=e,capture_output=True,text=True);return {'exit':q.returncode,'stdout':q.stdout.strip(),'stderr':q.stderr.strip()}
for args in argslist:
 for fuel in [1,2,3,4,5,6,7,8,16,64,1048576]:
  obs={lab:run(p,off,args,fuel) for lab,(p,off) in fixture.items() if lab!='observer'};assert obs['baseline']==obs['candidate'],(args,fuel,obs);rows.append({'args':args,'fuel':fuel,**obs})
sentinels=[];blob,at=wrap(fixture['candidate'][0].read_bytes(),fixture['candidate'][1]);p=D/'fixture-sentinels.bin';p.write_bytes(blob)
for args in argslist:
 a=run(*fixture['candidate'],args,1048576);b=run(p,at,args,1048576);assert a==b and a['exit']==0,(args,a,b);sentinels.append({'kind':'typed-five-arg','args':args,'direct':a,'sentinels':b})
# Reuse all12 changed native measured typed entries for saved-register checks.
for e in json.loads((W/'ports-build.json').read_text())['entries']:
 if e['productByteIdentical']:continue
 raw=W/'ports'/e['workload']/'native.bin';blob,off=wrap(raw.read_bytes(),e['offset']);p=D/(e['workload']+'-sentinels.bin');p.write_bytes(blob)
 for n in [1,4,8,32]:
  a=run(raw,e['offset'],(n,),16777216);b=run(p,off,(n,),16777216);assert a==b and a['exit']==0,(e['workload'],n,a,b);sentinels.append({'kind':'reused-original19','workload':e['workload'],'n':n,'direct':a,'sentinels':b})
(D/'report.json').write_text(json.dumps({'status':'PASS actual typed admitted mode4 read-call-write fullstate and original12 changed ABI sentinel controls','typedPairs':len(rows),'typedTrapPairs':sum(x['baseline']['exit']!=0 for x in rows),'sentinelPairs':len(sentinels),'acceptedCertificates':accepted,'fixtureSha256':sha(D/'read-call-write.kotoba'),'rows':rows,'sentinels':sentinels,'noMeasurements':True,'limitations':['Existing97 source admissions independently reviewed; sentinel inputs exercise returned public paths, not proof every admitted function/path executes.','ABI preserves x19..28 on successful returns; OS stack-limit universal parity not proved.']},indent=2)+'\n');print('PASS typed',len(rows),'sentinels',len(sentinels),'admissions',accepted,flush=True)
