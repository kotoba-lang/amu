from pathlib import Path
import hashlib,json,subprocess,re,sys,struct,importlib.util
R=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());pins=load(R/'selected-payload-pins.json')
for n,h in pins.items():assert sha(R/n)==h,n
origins=load(R/'origin-pins.json')
for n,x in origins.items():assert sha(R/n)==x['sha256'],n
I=R/'implementation';fixed=load(I/'fixed-point.json');seed='1177930937d2951e4e96463a58dd9b897a995496fcb280db4c78a231b6b6395e'
for g in fixed['generations'][1:]:assert sha(I/f"seed-{g['generation']}.bin")==g['sha256']==seed and int((I/f"seed-{g['generation']}.offset").read_text())==0
for n,h in load(I/'source-pins.json').items():assert sha(I/n)==h,n
log=[]
for name in ['model_controls.py','closure.py','machine.py']:
 q=subprocess.run([sys.executable,str(R/'team-contracts'/name)],capture_output=True,text=True);assert q.returncode==0,(name,q.stderr);log.append({'script':name,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
for name in ['machine-report.json','closure-report.json']:
 assert load(R/'team-contracts'/name)==load(R/'team-contracts/original'/name),name
matrix=load(R/'root-proof/ports-semantic.json');baseline=load(R/'baseline/ports-semantic.json');assert len(matrix['entries'])==19
for e in matrix['entries']:
 n=e['workload'];b=next(x for x in baseline['entries'] if x['workload']==n);assert sha(R/'original19-source'/(n+'.kotoba'))==e['sourceSha256']==b['sourceSha256'];assert sha(I/'ports'/n/'native.bin')==e['nativeSha256'];assert sha(R/'baseline/ports'/n/'native.bin')==b['nativeSha256'];assert e['runs']==b['runs'] and e['fuelTrapReturncode']==b['fuelTrapReturncode']
resource=[]
for name,number in [('resource-states.json',161),('fuel-states.json',209),('ordinary-states.json',57)]:
 x=load(I/'resource-proofs'/name);assert len(x['rows'])==number
 for row in x['rows']:assert row['product']==row['candidate'],(name,row)
 resource.append({'file':name,'retainedExactPairs':number})
x=load(R/'root-proof/typed-mode4/report.json');assert len(x['rows'])==55 and len(x['sentinels'])==53
for row in x['rows']:assert row['baseline']==row['candidate']
for row in x['sentinels']:assert row['direct']==row['sentinels']
fault=load(R/'root-proof/typed-mode4/fault-proof.json');assert fault['detected'] and ':result 999 ' in fault['stdout']
x=load(I/'proof-controls/report.json');assert x['nativeExecutions']==240 and len(x['rows'])==8
pristine=x['rows'][0];assert pristine['variant']=='pristine' and len(pristine['outcomes'])==30
for row in x['rows']:
 d=I/'proof-controls'/row['variant'];assert sha(d/'native.bin')==row['nativeSha256']
 got=[]
 for k in range(30):
  raw=(d/f'case-{k}.stdout').read_text();assert (d/f'case-{k}.stderr').exists();got.append(int(re.search(r':result (-?\d+)',raw)[1]))
 assert got==row['outcomes']
 if row['variant'] not in ('pristine','one-visit-budget'):assert got!=pristine['outcomes']
fallback=next(z for z in x['rows'] if z['variant']=='one-visit-budget');assert fallback['outcomes']==[0 if z==4 else z for z in pristine['outcomes']]
reuse=load(I/'reuse-control/report.json');assert reuse['result']==63 and int(re.search(r':result (-?\d+)',(I/'reuse-control/stdout').read_text())[1])==63
pf=load(R/'root-proof/adoption-permanent-proof.json');assert pf['fixtures']==593 and pf['runs']==25658 and len(pf['observations'])==25658 and pf['realTestCodeAndLiteralBytesEqual'] and pf['realTestFnOffsetsEqual']
sys.path.insert(0,str(R/'original-harnesses'));spec=importlib.util.spec_from_file_location('permanent_records',R/'original-harnesses/permanent-portable.py');permanent=importlib.util.module_from_spec(spec);spec.loader.exec_module(permanent);assert len(permanent.FIX)==593 and len(permanent.RUNS)==25658
for row,(name,args,want,opts) in zip(pf['observations'],permanent.RUNS):
 assert (row['fixture'],row['args'],row['expect'])==(name,list(args),want)
 if want=='trap':assert row['exit']!=0 and 'KEXE_TRAP' in row['stderr']
 elif 'cmd' in opts:assert row['exit']==(want&255)
 elif 'fuel_remaining' in opts:assert row['exit']==0 and int(re.search(r':result (-?\d+)',row['stdout'])[1])==want
 else:assert row['exit']==0 and row['stdout'].splitlines()[-1]==str(want)
 if 'fuel_remaining' in opts:assert int(re.search(r':remaining (-?\d+)',row['stdout'])[1])==opts['fuel_remaining']
 if 'stdout' in opts:assert row['stdout'].startswith(opts['stdout'])
 if 'file' in opts:assert (R/'root-proof/adoption-permanent-run'/opts['file'][0]).read_bytes()==opts['file'][1]
for name,n in [('readonly',117),('scalar',318)]:
 x=load(R/'team-fixture-regressions'/name/'report.json');assert x['seedSha256']==seed
 controls=x.get('controls',x.get('observations'));assert len(controls)==n
 for row in controls:
  want=row.get('expected',row.get('want'))
  if want is not None:
   assert row['exit']==0 and int(re.search(r':result (-?\d+)',row['stdout'])[1])==want
   if row.get('expectedConsumed') is not None:
    fuel=re.search(r':initial (\d+) :remaining (\d+)',row['stdout']);assert int(fuel[1])-int(fuel[2])==row['expectedConsumed']
  else:assert row['exit']!=0 and 'KEXE_TRAP' in row['stderr']
# Pure original-source interpreter and physical native call-span checks; no guest execution.
spec=importlib.util.spec_from_file_location('retained_scalar',R/'original-harnesses/a64gen_scalar_dag_fixtures.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
scalar=load(R/'team-fixture-regressions/scalar/report.json')
for row in scalar['observations']:
 name=row['case'];generic=name.endswith('-generic-entry');base=name.removesuffix('-generic-entry');prog=module.Program(R/'fixtures/scalar-dag'/(base+'.kotoba'));callee=('mix' if base=='five-args' else 'scalar') if generic else 'run'
 try:meaning=prog.call(callee,row['args'])
 except module.Trap:meaning=None
 trace=''.join(prog.trace)
 consumed=0 if generic else 3 if base=='site-budget' else 2 if base in ['effect-refuse','indirect','five-args'] else 1+(row['args'][0]&3) if base=='fuel-refuse' else 1
 if row['fuel']==1 and consumed>1:meaning=None;trace=''
 assert meaning==row['expected'] and trace==row['expectedEffectTrace'] and row['stdout'].startswith(trace),(name,row['args'],row['fuel'],meaning,row['expected'],trace,row['expectedEffectTrace'])
def nativebody(raw,offset):
 end=offset
 while end+4<=len(raw):
  end+=4
  if struct.unpack_from('<I',raw,end-4)[0]==0xd65f03c0:return raw[offset:end]
 raise AssertionError('missing native RET')
for x in scalar['physicalChecks']:
 d=R/'team-fixture-regressions/scalar'/x['case'];raw=(d/(x['caller']+'.bin')).read_bytes();body=nativebody(raw,x['callerOffset']);targets=[]
 for i,(word,) in enumerate(struct.iter_unpack('<I',body)):
  if word&0xfc000000==0x94000000:
   delta=word&0x3ffffff;delta=delta-(1<<26) if delta&(1<<25) else delta;targets.append(x['callerOffset']+4*i+4*delta)
 assert (x['helperOffset'] in targets)==x['genericBL'] and x['genericBL']!=x['inlineExpected']
 if x['inlineExpected']:assert nativebody(raw,x['helperOffset'])[:-4] in body
for x in load(R/'team-fixture-regressions/readonly/report.json')['physicalChecks']:
 raw=(R/'team-fixture-regressions/readonly'/x['case']/'run.bin').read_bytes();words=struct.unpack('<'+'I'*(len(raw)//4),raw[:len(raw)//4*4]);sites=[]
 for i in range(len(words)-16):
  flag=words[i]&31
  if words[i]!=0xb5000000|(13<<5)|flag or not 22<=flag<=28:continue
  if words[i+12]==0xd2800000|32|flag and words[i+14]==0x54000043 and words[i+15]==0:
   assert words[i+13]&0xff20001f==0xeb00001f and (words[i+13]>>16)&31==flag-2 and words[i+16]&0xffe00c00==0xf8600800 and 0xd2800000|flag in words;sites.append(i)
 assert sites==x['physicalGuardSites'] and bool(sites)==x['expectedAdmitted']
g=load(R/'team-adoption-gates/report.json');assert g['candidateSeedSha256']==seed and g['formalUnit']['status']==0 and g['formalUnit']['lines']==5227 and g['formalUnit']['fullRawGoldenAndPreviousByteIdentical'];assert sha(R/'team-adoption-gates/unit-build/unit/41-a64gen/stdout')==g['formalUnit']['stdoutSha256'];assert sha(R/'team-adoption-gates/source/seed/tests/unit/41-a64gen.expected')==g['formalUnit']['trackedGoldenSha256'];assert sha(R/'team-adoption-gates/unit-generated-blob.bin')==g['formalUnit']['generatedCodeBlobSha256'];assert len(load(R/'team-adoption-gates/unit-generated-offsets.json'))==593
assert len(g['requiredGates'])==7 and {x[0] for x in g['requiredGates']}=={'BUILD','ERR','G1','G2','G3','G4','G5'} and all(x[1]=='PASS' for x in g['requiredGates'])
report={'status':'PASS selected native proof offline hash/machine/closure/model/retained-state replay','selectedPayloadFiles':len(pins),'originFiles':len(origins),'nativeExecutions':0,'compilerExecutions':0,'solverExecutions':0,'newMeasurements':0,'originalWorkloads':19,'machineProjection':load(R/'team-contracts/machine-report.json')['totals'],'resource':resource,'typedRetainedPairs':55,'sentinelRetainedPairs':53,'admissionRetainedRuns':240,'permanentFixtures':593,'permanentRetainedRuns':25658,'readonlyRetainedObservations':117,'scalarRetainedObservations':318,'formalUnitLines':5227,'gateNames':[x[0] for x in g['requiredGates']],'logs':log,'limitations':'Retained observations replay; not fresh native testing, arbitrary compiler equivalence or universal stack/allocation-boundary proof. Candidate unadopted and C-or-better unachieved.'};(R/'offline-replay-report.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS native offline replay',len(pins),'payload files; no native execution/new measurement')
