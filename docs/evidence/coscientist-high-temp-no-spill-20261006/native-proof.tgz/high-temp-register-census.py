from pathlib import Path
import json,hashlib
w=Path('/private/tmp/amu-high-temp-no-spill-20261006');c=Path('/private/tmp/amu-loop-region-census-20261006');a=json.loads((c/'observer-byte-audit.json').read_text());assert len(a['entries'])==19 and all(x['diagnosticTargetByteIdentical'] for x in a['entries']);rows=[]
for e in a['entries']:
 p=c/'meta-ports'/e['workload']/'compile.log';fns=[]
 for line in p.read_text().splitlines():
  if line.startswith('FN '):
   f,i,ns,dp,nsv,leaf=map(int,line.split()[1:]);count=min(max(dp-7,0),10-nsv)
   if count:fns.append({'fn':f,'sir':i,'locals':ns,'depth':dp,'localCalleeRegisters':nsv,'leaf':leaf,'availableHighTempRegisters':count,'firstTemp':7,'lastTemp':6+count,'firstRegister':19+nsv,'lastRegister':18+nsv+count})
 rows.append({'workload':e['workload'],'functionsWithHighTempsAndUnusedCalleeRegisters':len(fns),'functions':fns,'nativeCensusLogSha256':hashlib.sha256(p.read_bytes()).hexdigest()})
s={'status':'complete-existing-native-census-unused-callee-high-temp-register-analysis','observerGuestsEqualProduct':True,'countsAreNotTimeShares':True,'proposal':'Retain original frame size and local allocation; save unused callee registers in homes of mapped high temps. Those homes cease to store expression values. Use only disjoint x19..x28 after current local allocation, preserve original save/restore/fuel/effect contracts.','entries':rows};(w/'high-temp-register-census.json').write_text(json.dumps(s,indent=2)+'\n');print([(x['workload'],x['functionsWithHighTempsAndUnusedCalleeRegisters']) for x in rows])
