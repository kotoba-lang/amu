from pathlib import Path
import os,subprocess,re,json,importlib.util,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-high-temp-no-spill-20261006');sp=importlib.util.spec_from_file_location('m',w/'baseline-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);cs=[]
for t in [6,7,10,31]:
 for mode in ['raw','coalesced-alias','join']:
  raw=f'ns_raw_{t}_{mode}';caller=raw+'_caller';body=[('FUEL',)]+[('LGET',j,3 if j%2==0 else 4) for j in range(t)]
  if mode=='join':body += [('LGET',t,3),('BRZ',t,raw+'_zero'),('CONST',t,5),('BIN','BOP-ADD',t-1),('BR',raw+'_join'),('LABEL',raw+'_zero'),('CONST',t-1,-7),('LABEL',raw+'_join')]
  body += [('LGET',t,1),('LGET',t+1,2),('RT','RT-VECTOR-AT',t,2)]
  if mode=='coalesced-alias':body += [('LSET',3,t),('LGET',t,3)]
  body += [('BIN','BOP-ADD',j) for j in range(t-1,-1,-1)]+[('LGET',1,3),('BIN','BOP-ADD',0),('RET',0)];m.fx(raw,4,4,body)
  wrapper=[('FUEL',)]+[('CONST',j,11-3*j) for j in range(8)]+[('VEC',0,8),('CONST',0,99),('VEC',0,1)]+[('LGET',j,j+1) for j in range(4)]+[('CALL',raw,0,4),('RET',0)];m.fx(caller,4,4,wrapper);cs.append({'raw':raw,'caller':caller,'t':t,'mode':mode})
ids={x[0]:j+1 for j,x in enumerate(m.FIX)};parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');images={};audits=[]
pat=struct.pack('<15I',0xf9409cf0,0xf9400210,0xd1000411,0xeb10023f,0x54000043,0,0xf940a0f0,0x8b111210,0xa9404211,0xeb10003f,0x54000043,0,0xf940a4f0,0x8b010231,0xf8717a00)
for label,gen in [('baseline-own','baseline-41-a64gen.kotoba'),('candidate-own','41-a64gen-prototype.kotoba')]:
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/gen).read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+m.kotoba(True))
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-300:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0;(w/(label+'.stdout')).write_text(q.stdout);blob,fc=m.blob_from(q.stdout);bp=w/(label+'-fixture.bin');bp.write_bytes(blob);images[label]=(bp,fc)
 for c in cs:
  i=ids[c['raw']];chunk=blob[fc[i]:fc[i+1]];assert chunk.count(pat)==(1 if label=='candidate-own' else 0),(label,c)
  words=struct.unpack('<'+'I'*(len(chunk)//4),chunk);assert words[0]==0xa9bf7bfd,(label,c,'must retain original nonleaf frame',hex(words[0]));audits.append({'compiler':label,'raw':c['raw'],'nonleafPrologueRetained':True,'orderedInlineReadTemplates':chunk.count(pat)})
rows=[]
for c in cs:
 for handle,index in [(1,0),(1,7),(1,8),(2,0),(2,1),(0,0),(m.MIN,0),(m.MAX,m.MAX)]:
  for live,other in [(m.MIN,37),(0,m.MAX),(37,m.MAX)]:
   for fuel in [1,2,3,16777216]:
    vals=[11-3*j for j in range(8)]+[99];valid=fuel>=2 and ((handle==1 and 0<=index<8) or (handle==2 and index==0));value=(vals[index] if handle==1 else 99) if valid else None;prefix=m.s64(sum(live if j%2==0 else other for j in range(c['t'])))
    if c['mode']=='join':prefix=m.s64(prefix+5) if live!=0 else m.s64(prefix-(live if (c['t']-1)%2==0 else other)-7)
    answer=m.s64(prefix+value+(value if c['mode']=='coalesced-alias' else live)) if valid else None;remaining=max(0,fuel-2);obs={}
    for label,(bp,fc) in images.items():
     e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(bp),str(fc[ids[c['caller']]]),'4','aarch64','-',str(handle),str(index),str(live),str(other)],env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
     assert (q.returncode==0)==valid,(label,c,handle,index,live,other,fuel,q.stdout,q.stderr)
     if valid:assert re.search(r':result '+str(answer)+r'(?:\s|})',q.stdout),(label,c,handle,index,live,other,fuel,answer,q.stdout)
     assert f':remaining {remaining}' in q.stdout and ':vectors {:capacity 4096 :used 2}' in q.stdout and ':vector-items {:capacity 65536 :used 9}' in q.stdout,(label,c,fuel,q.stdout)
     assert obs[label]['items']==['DIAG_VECTOR_ITEMS 9 '+' '.join(map(str,vals))]
    assert obs['baseline-own']==obs['candidate-own'];rows.append({'caller':c['caller'],'mode':c['mode'],'handle':handle,'index':index,'live':live,'other':other,'fuel':fuel,'expect':answer,'expectRemaining':remaining,**obs})
 print('PASS raw/nonleaf/local-alias/join',c,flush=True)
(w/'ownership-proof.json').write_text(json.dumps({'status':'complete-native-no-spill-raw-nonleaf-local-alias-and-join-hand-state-proof','comparisons':len(rows),'callers':len(cs),'instructionAudit':audits,'runs':rows},indent=2)+'\n');print('PASS',len(rows),'native register ownership/local alias/join state comparisons')
