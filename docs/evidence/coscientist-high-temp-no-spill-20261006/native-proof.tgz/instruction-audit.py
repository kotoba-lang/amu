from pathlib import Path
import struct,json,importlib.util
w=Path('/private/tmp/amu-high-temp-no-spill-20261006');b=Path('/private/tmp/amu-affine-reader-20261005');words=[0xf9409cf0,0xf9400210,0xd1000411,0xeb10023f,0x54000043,0,0xf940a0f0,0x8b111210,0xa9404211,0xeb10003f,0x54000043,0,0xf940a4f0,0x8b010231,0xf8717a00];pat=struct.pack('<15I',*words);rows=[]
for x in json.loads((w/'meta-admission.json').read_text())['entries']:
 n=x['workload'];a=(b/'ports-2'/n/'native.bin').read_bytes().count(pat);c=(w/'ports-2'/n/'native.bin').read_bytes().count(pat);assert c-a==x['highTempReadSites'],(n,a,c,x);rows.append({'workload':n,'baselineTemplates':a,'candidateTemplates':c,'addedTemplates':c-a})
sp=importlib.util.spec_from_file_location('m',w/'baseline-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);ids=json.loads((w/'hand-ids.json').read_text());cases=json.loads((w/'hand-cases.json').read_text());hand=[]
for label in ['baseline-hand','candidate-hand']:
 blob,fc=m.blob_from((w/(label+'.stdout')).read_text())
 for x in cases:
  i=ids[x['name']];count=blob[fc[i]:fc.get(i+1,len(blob))].count(pat);want=(2 if x['mode']=='alias' else 1) if label=='candidate-hand' else 0;assert count==want,(label,x,count,want);hand.append({'compiler':label,'caller':x['name'],'templates':count})
(w/'instruction-audit.json').write_text(json.dumps({'status':'complete-independent-exact-ordered-handle-index-check-and-load-native-template-audit','wordsHex':[hex(x) for x in words],'originalWorkloads':rows,'handCallers':hand,'auditAfterTiming':False},indent=2)+'\n');print('PASS 6 actual workload sites and all33 hand callers exact15-instruction template audit')
