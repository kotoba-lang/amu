from pathlib import Path
import json,os,re,subprocess,struct,importlib.util
w=Path('/private/tmp/amu-high-temp-no-spill-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');sp=importlib.util.spec_from_file_location('m',w/'baseline-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
# Reconstruct the exact authored hand fixture definitions without rerunning its build or cases.
scope={'__name__':'import_fixture_definitions'};s=(w/'hand-proof.py').read_text();exec(s[:s.index('env=dict(')],scope);m=scope['m'];cs=[x for x in scope['cases'] if x['mode']=='beforecall'];target=scope['ids']['ht_clobber'];m.fx('ht_open_allocate',7,7,[('FUEL',),('CONST',0,1),('RT','RT-VECTOR-ALLOC',0,1),('CONST',0,77),('RET',0)]);replacement=len(m.FIX);ids={x[0]:j+1 for j,x in enumerate(m.FIX)};test=m.kotoba(True);assert test.count('(gn-run M0)')==1;test=test.replace('(gn-run M0)',f'(gn-run-open M0 {target} 1)');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');images={}
for label,gen in [('baseline-open','baseline-41-a64gen.kotoba'),('candidate-open','41-a64gen-prototype.kotoba')]:
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/gen).read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+test)
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-400:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0;(w/(label+'.stdout')).write_text(q.stdout);blob,fc=m.blob_from(q.stdout);patched=bytearray(blob);struct.pack_into('<I',patched,fc[target],0x14000000|(((fc[replacement]-fc[target])//4)&0x3ffffff));bp=w/(label+'-linked.bin');bp.write_bytes(patched);images[label]=(bp,fc)
rows=[]
for c in cs:
 for handle,index in [(1,0),(1,7),(1,8),(2,0),(3,0),(0,0)]:
  for fuel in [1,2,3,16777216]:
   remaining=max(0,fuel-2);allocated=fuel>=2;items=[11-3*j for j in range(8)]+[99]+([0] if allocated else []);valid=allocated and ((handle==1 and 0<=index<8) or(handle in [2,3] and index==0));value=(items[index] if handle==1 else items[8] if handle==2 else 0) if valid else None;prefix=m.s64(sum(m.s64((m.MIN if j%2==0 else 37)+(-19+7*j)) for j in range(c['t'])));answer=m.s64(prefix+value) if valid else None;obs={}
   for label,(bp,fc) in images.items():
    e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(bp),str(fc[ids[c['name']]]),'4','aarch64','-',str(handle),str(index),str(m.MIN),'37'],env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
    assert (q.returncode==0)==valid,(c,handle,index,fuel,label,q.stdout,q.stderr)
    if valid:assert re.search(r':result '+str(answer)+r'(?:\s|})',q.stdout),(c,handle,index,fuel,answer,q.stdout)
    assert f':remaining {remaining}' in q.stdout and f':vectors {{:capacity 4096 :used {2+int(allocated)}}}' in q.stdout and f':vector-items {{:capacity 65536 :used {len(items)}}}' in q.stdout,(c,handle,index,fuel,q.stdout)
    assert obs[label]['items']==['DIAG_VECTOR_ITEMS '+str(len(items))+' '+' '.join(map(str,items))]
   assert obs['baseline-open']==obs['candidate-open'];rows.append({'caller':c['name'],'handle':handle,'index':index,'fuel':fuel,'expect':answer,'expectRemaining':remaining,'expectItems':items,**obs})
(w/'import-proof.json').write_text(json.dumps({'status':'complete-native-high-temp-after-actual-open-allocating-import-hand-state-proof','comparisons':len(rows),'actualOpenImport':True,'replacement':'np7;chargesonefuel;allocatesone;returns77;diagnosticallocatorclobbersx7','runs':rows},indent=2)+'\n');print('PASS',len(rows),'actual open import full-state comparisons')
