from pathlib import Path
import json
w=Path('/private/tmp/amu-high-temp-no-spill-20261006');c=Path('/private/tmp/amu-loop-region-census-20261006');rows=[]
for e in json.loads((w/'meta-admission.json').read_text())['entries']:
 sir={};fn=[]
 for line in (c/'meta-ports'/e['workload']/'compile.log').read_text().splitlines():
  if line.startswith('SIR '):
   i,op,a,b,n=map(int,line.split()[1:]);sir[i]=(op,a,b,n)
  if line.startswith('FN '):fn.append(list(map(int,line.split()[1:])))
 for i,t in e['sites']:
  start=max(x[1] for x in fn if x[1]<i);end=min(j for j,(op,_,_,_) in sir.items() if j>i and op==2);loops=[]
  for j in range(i+1,end):
   op,a,b,n=sir[j];target=a if op==10 else b if op in [11,12] else 0
   if target:
    ps=[p for p in range(start+1,j) if sir[p][0]==9 and sir[p][1]==target]
    if ps and ps[0]<=i:loops.append({'header':ps[0],'backedge':j,'label':target})
  rows.append({'workload':e['workload'],'sir':i,'temp':t,'fnStart':start,'fnEnd':end,'enclosingBackedges':loops,'loopContained':bool(loops)})
assert len(rows)==6 and [x['workload'] for x in rows if x['loopContained']]==['matmult-int'];(w/'loop-containment-census.json').write_text(json.dumps({'status':'complete-actual-original19-high-temp-read-loop-containment-census','countsAreNotTimeShares':True,'entries':rows},indent=2)+'\n');print(rows)
