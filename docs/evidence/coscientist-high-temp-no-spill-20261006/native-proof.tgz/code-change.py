from pathlib import Path
import json,hashlib
w=Path('/private/tmp/amu-high-temp-no-spill-20261006');b=Path('/private/tmp/amu-affine-reader-20261005');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=json.loads((w/'ports-correctness.json').read_text());old=json.loads((b/'ports-correctness.json').read_text());rows=[]
for x in a['entries']:
 y=next(t for t in old['entries'] if t['workload']==x['workload']);assert x['runs']==y['runs'] and x['sourceSha256']==y['sourceSha256'] and x['fuelTrapReturncode']==y['fuelTrapReturncode'];p=w/'ports-2'/x['workload']/'native.bin';q=b/'ports-2'/x['workload']/'native.bin';assert sha(p)==x['nativeSha256'] and sha(q)==y['nativeSha256'];rows.append({'workload':x['workload'],'changed':p.read_bytes()!=q.read_bytes(),'baselineBytes':q.stat().st_size,'candidateBytes':p.stat().st_size,'baselineSha256':sha(q),'candidateSha256':sha(p)})
assert [x['workload'] for x in rows if x['changed']]==['matmult-int','nettle-sha256'];(w/'code-change.json').write_text(json.dumps(rows,indent=2)+'\n');print([x for x in rows if x['changed']])
