; benchmark generated from python API
(set-info :status unknown)
(declare-fun slot () (_ BitVec 64))
(assert
 (bvult slot (_ bv8192 64)))
(assert
 (and (distinct (bvand (bvshl slot (_ bv3 64)) (_ bv7 64)) (_ bv0 64)) true))
(check-sat)
