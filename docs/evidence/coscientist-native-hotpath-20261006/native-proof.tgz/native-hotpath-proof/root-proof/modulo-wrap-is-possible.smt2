; benchmark generated from python API
(set-info :status unknown)
(declare-fun count () (_ BitVec 64))
(assert
 (bvult (bvadd count (_ bv1 64)) count))
(check-sat)
