"""Supplementary arithmetic proof; does not prove compiler or loader correctness."""
import json
from pathlib import Path
import z3

out = Path(__file__).resolve().parent
slot = z3.BitVec('slot', 64)
base = z3.BitVec('base', 64)
index = slot << 3
checks = []

def prove(name, premises, bad, expected):
    s = z3.Solver()
    s.add(*premises, bad)
    result = str(s.check())
    assert result == expected, (name, result)
    row = {'name': name, 'result': result}
    if result == 'sat':
        row['counterexample'] = str(s.model())
    checks.append(row)
    (out / (name + '.smt2')).write_text(s.to_smt2())

bounded = [z3.ULT(slot, 8192)]
prove('bounded-index', bounded, z3.UGT(index, 65528), 'unsat')
prove('bounded-index-alignment', bounded, index & 7 != 0, 'unsat')
prove('no-address-wrap', bounded + [z3.ULE(base, (1 << 64) - 65536)],
      z3.ULT(base + index + 7, base), 'unsat')
other = z3.BitVec('other', 64)
prove('distinct-slots', bounded + [z3.ULT(other, 8192), other != slot],
      index == other << 3, 'unsat')
prove('unsafe-no-slot-bound', [], z3.UGT(index, 65528), 'sat')
prove('unsafe-no-base-bound', bounded, z3.ULT(base + index + 7, base), 'sat')
count = z3.BitVec('count', 64)
prove('modulo-wrap-is-possible', [], z3.ULT(count + 1, count), 'sat')
report = {
    'status': 'PASS-supplementary-counter-address-model',
    'checks': checks,
    'assumptions': ['8192 consecutive initialized uint64 slots',
                    'base mapping has 65536 addressable bytes without wrap',
                    'slot checked against actual native function metadata',
                    'single guest thread and mapping lifetime encompasses run'],
    'notProven': ['actual emitted instructions', 'live register/NZCV preservation',
                  'loader mapping ownership', 'guest state equivalence',
                  'absence of counter wrap in executions'],
    'counterSemantics': 'uint64 modulo; wrapped execution cannot be called exact',
    'performanceEvidence': False,
}
(out / 'counter-contract.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'checks': len(checks)}))
