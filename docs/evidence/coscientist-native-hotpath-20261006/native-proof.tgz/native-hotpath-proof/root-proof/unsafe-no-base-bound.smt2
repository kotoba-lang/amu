; benchmark generated from python API
(set-info :status unknown)
(declare-fun slot () (_ BitVec 64))
(declare-fun base () (_ BitVec 64))
(assert
 (bvult slot (_ bv8192 64)))
(assert
 (bvult (bvadd (bvadd base (bvshl slot (_ bv3 64))) (_ bv7 64)) base))
(check-sat)
