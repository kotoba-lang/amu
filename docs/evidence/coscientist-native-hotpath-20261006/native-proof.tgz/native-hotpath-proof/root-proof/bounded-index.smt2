; benchmark generated from python API
(set-info :status unknown)
(declare-fun slot () (_ BitVec 64))
(assert
 (bvult slot (_ bv8192 64)))
(assert
 (let ((?x8 (bvshl slot (_ bv3 64))))
(bvugt ?x8 (_ bv65528 64))))
(check-sat)
