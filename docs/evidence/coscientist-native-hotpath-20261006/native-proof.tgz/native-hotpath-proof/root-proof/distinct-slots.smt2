; benchmark generated from python API
(set-info :status unknown)
(declare-fun slot () (_ BitVec 64))
(declare-fun other () (_ BitVec 64))
(assert
 (bvult slot (_ bv8192 64)))
(assert
 (bvult other (_ bv8192 64)))
(assert
 (and (distinct other slot) true))
(assert
 (let ((?x8 (bvshl slot (_ bv3 64))))
(= ?x8 (bvshl other (_ bv3 64)))))
(check-sat)
