"""Independent retained-receipt replay: no native execution or timing."""
from pathlib import Path
import hashlib, importlib.util, json, re

W = Path(__file__).resolve().parent.parent
I = W / 'implementation'
B = W / 'baseline-inputs/meta-ports'
if not B.exists():
    B = Path('/private/tmp/amu-static-vector-chain-20261006/observer/meta-ports')
spec = importlib.util.spec_from_file_location('validator', W / 'team-resource/trace-validator.py')
validator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(validator)
profiles = json.loads((I / 'dynamic-profile.json').read_text())['profiles']
build = json.loads((I / 'ports-build.json').read_text())['entries']
blocks = json.loads((I / 'entry-blocks.json').read_text())
rows = []
for e in build:
    name = e['workload']
    baseline = json.loads((B / name / 'census.json').read_text())
    assert hashlib.sha256((B / name / 'native.bin').read_bytes()).hexdigest() == e['quiet']['sha256']
    assert hashlib.sha256((I / 'ports' / name / 'diagnostic/native.bin').read_bytes()).hexdigest() == e['diagnostic']['sha256']
    allowed = {f for f, _ in blocks[name]['blocks']}
    grouped = [p for p in profiles if p['workload'] == name]
    assert sorted(p['n'] for p in grouped) == sorted(e['iterations'])
    for p in grouped:
        d = I / 'traces' / name / ('n-' + str(p['n']))
        ps, ds = [(d / (arm + '.stdout')).read_text() for arm in ['product', 'diagnostic']]
        pe, de = [(d / (arm + '.stderr')).read_text() for arm in ['product', 'diagnostic']]
        assert ':status :ok' in ps and ps == ds
        stripped = '\n'.join(l for l in de.splitlines() if not l.startswith(('ENTRY_COUNT ', 'ENTRY_TRACE ')))
        assert pe.strip() == stripped.strip(), (name, p['n'])
        accepted = validator.validate(de, 0, True, allowed_ids=allowed)
        assert accepted['state'] == 'complete' == p['state']
        ranked = p['mappedRanking']
        assert accepted['counts'] == {r['fn']: r['countModuloU64'] for r in ranked}
        assert len(accepted['counts']) == p['activeFunctions']
        assert sum(accepted['counts'].values()) == p['nativeInvocationCountModulo']
        assert p['sourceSha256'] == e['sourceSha256']
        assert p['diagnosticNativeSha256'] == e['diagnostic']['sha256']
        for r in ranked:
            f = baseline['functions'][str(r['fn'])]
            for key, actual in [('sourceStart', 'start'), ('sourceEnd', 'end'),
                                ('codeWordStart', 'codeWordStart'), ('emittedWords', 'emittedWords'),
                                ('leaf', 'leaf'), ('frameBytes', 'frameBytes')]:
                assert r[key] == f[actual], (name, r['fn'], key)
        fuel = re.search(r':initial (\d+) :remaining (\d+)', ps)
        assert int(fuel[1]) - int(fuel[2]) == p['fuelConsumed']
    largest = max(grouped, key=lambda p: p['n'])
    rows.append({'workload': name, 'n': largest['n'],
                 'nativeInvocationCountModulo': largest['nativeInvocationCountModulo'],
                 'activeFunctions': largest['activeFunctions'],
                 'emittedFunctions': len(allowed),
                 'topPhysicalEntries': largest['mappedRanking'][:3]})
assert len(rows) == 19 and len(profiles) == 95
report = {'status': 'PASS-independent-original19-retained-trace-mapping',
          'workloads': 19, 'runs': 95, 'summary': rows,
          'freshNativeExecutions': 0, 'timing': False,
          'limits': 'Modulo physical entry counts only. Not time shares, loop-body counts or wrap-free theorem.'}
(W / 'root-proof/cross-profile.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k:v for k,v in report.items() if k != 'summary'}))
