"""Freeze completed owned receipts and original input content for review."""
from pathlib import Path
import hashlib, json, shutil, tarfile

W = Path('/private/tmp/amu-native-hotpath-20261006')
B = Path('/private/tmp/amu-static-vector-chain-20261006')
R = Path('/Users/junkawasaki/github/wt/amu-seed17')
P = W / 'review-package'
assert not P.exists(), 'Never overwrite a frozen package'
P.mkdir()
for name in ['implementation', 'team-constructor', 'team-resource', 'root-proof']:
    shutil.copytree(W / name, P / name, ignore=shutil.ignore_patterns('__pycache__'))
base = P / 'baseline-inputs'
base.mkdir()
shutil.copytree(B / 'observer/meta-ports', base / 'meta-ports')
for name in ['41-a64gen-prototype.kotoba', '42-layout-prototype.kotoba',
             'ports-correctness.json', 'ports-state.json']:
    shutil.copy2(B / name, base / name)
matrix = json.loads((R / 'bench/embench/comparison-matrix.json').read_text())
shutil.copy2(R / 'bench/embench/comparison-matrix.json', base / 'comparison-matrix.json')
for entry in matrix['entries']:
    src = R / entry['source']
    assert hashlib.sha256(src.read_bytes()).hexdigest() == entry['expectedSourceSha256']
    dst = base / 'sources' / entry['workload'] / src.name
    dst.parent.mkdir(parents=True)
    shutil.copy2(src, dst)
files = {}
for f in sorted(P.rglob('*')):
    if f.is_file():
        assert not f.is_symlink()
        files[str(f.relative_to(P))] = {'bytes': f.stat().st_size,
                                      'sha256': hashlib.sha256(f.read_bytes()).hexdigest()}
(P / 'manifest.json').write_text(json.dumps({'files': files}, indent=2) + '\n')
archive = W / 'native-proof.tgz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    t.add(P, arcname='native-hotpath-proof')
(W / 'archive-manifest.json').write_text(json.dumps({
    'artifact': archive.name, 'bytes': archive.stat().st_size,
    'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'pinnedFiles': len(files), 'freshNativeExecutionsByPackager': 0
}, indent=2) + '\n')
print('Frozen', len(files), 'files', archive.stat().st_size, 'bytes')
