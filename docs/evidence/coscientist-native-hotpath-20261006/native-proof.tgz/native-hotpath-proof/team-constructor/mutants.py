exec((__import__('pathlib').Path('/private/tmp/amu-native-hotpath-20261006/team-constructor/trace.py')).read_text().split("base=json.loads")[0])
import struct
name='private-aux1';d=D/name;p=d/'diagnostic.bin';raw=p.read_bytes();words=list(struct.unpack('<'+'I'*(len(raw)//4),raw));matches=[]
for i in range(len(words)-6):
 if words[i]==0xf940c8f0 and words[i+2:i+6]==[0x8b110e10,0xf9400211,0x91000631,0xf9000211]:matches.append((i,(words[i+1]>>5)&65535))
assert len(matches)==4,matches
inner=next(i for i,f in matches if f==2);assert words[inner-1]==0xd2800005,('expected public mode2 marker',hex(words[inner-1]))
off=int((d/'diagnostic.offset').read_text());good=trace(p,off,1,1048576);assert good['counts']=={1:1,2:1,3:1,4:1}
variants=[]
# Actual machine emitted block mutations, maintaining size and actual guest semantics where possible.
a=words.copy();a[inner+1]=0xd2800011;variants.append(('wrong-id',a))
a=words.copy();a[inner+5]=0xd503201f;variants.append(('omitted-private-increment',a))
# Identify actual private tail branch to FF-CODE+1, which enters counter after marker.
bs=[]
for i,w in enumerate(words):
 if w>>26==5:
  imm=w&0x3ffffff;imm=imm-(1<<26) if imm&(1<<25) else imm
  if i+imm==inner:bs.append(i)
assert len(bs)==1,('private aux1 inbound branches',bs,inner)
a=words.copy();site=bs[0];a[site]=(a[site]&0xfc000000)|((inner+6-site)&0x3ffffff);variants.append(('wrong-private-aux1-skips-increment',a))
records=[]
for label,ws in variants:
 target=d/(label+'.bin');target.write_bytes(struct.pack('<'+'I'*len(ws),*ws));q=trace(target,off,1,1048576);assert q['counts']!={1:1,2:1,3:1,4:1},(label,q)
 assert q['exit']==good['exit'] and q['stdout']==good['stdout'],(label,'mutant expected unchanged semantic result',q,good)
 records.append({'mutant':label,'detected':True,'resultFuelAndStatePreserved':True,'counts':q['counts'],'expectedCounts':good['counts']})
(D/'mutants.json').write_text(json.dumps({'status':'PASS','physicalEntryBlockSitesWords':matches,'privateAux1BranchWord':bs[0],'publicMarkerWord':inner-1,'records':records},indent=2)+'\n');print('PASS actual native trace machine mutants',len(records),flush=True)
# direct exported public entry invalid handles, trace prefix has read2 fid1 once before trap
public=[]
pub=D/'public-vector'/'diagnostic-public.bin';poff=build(D/'public-vector.kotoba',pub,symbol='read2')
basepub=D/'public-vector'/'baseline-public.bin';boff=build(D/'public-vector.kotoba',basepub,comp=O/'seed-0.bin',ld=O/'kexe-loader',symbol='read2')
for n in [0,1,-1,9223372036854775807]:
 q=trace(pub,poff,n,1048576);assert q['completion']=='prefix' and q['counts']=={1:1} and q['exit']!=0,(n,q);ref=trace(basepub,boff,n,1048576);assert q['exit']==ref['exit'] and q['stdout']==ref['stdout'];assert re.findall(r'^KEXE_TRAP.*$',q['stderr'],re.M)==re.findall(r'^KEXE_TRAP.*$',ref['stderr'],re.M);public.append({'handle':n,'trace':q,'baseline':ref})
(D/'public-entry.json').write_text(json.dumps({'status':'PASS','rows':public},indent=2)+'\n')
