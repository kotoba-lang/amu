from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent
cases={
'leaf':{'defs':'','body':'(+ n 9)','n':[0,1,4],'logical':{'run':1}},
'direct-return':{'defs':'(defn- add7 [n :i64] :i64 (+ n 7))','body':'(+ (add7 n) 3)','n':[0,1,4],'logical':{'run':1,'add7':1}},
'direct-tail':{'defs':'(defn- add7 [n :i64] :i64 (+ n 7))','body':'(add7 n)','n':[0,1,4],'logical':{'run':1,'add7':1}},
'recursive':{'defs':'(defn- countdown [n :i64] :i64 (if (= n 0) 23 (countdown (- n 1))))','body':'(countdown n)','n':[0,1,4],'logicalFormula':'run=1,countdown=n+1'},
'diamond':{'defs':'(defn- left [n :i64] :i64 (+ n 11))\n(defn- right [n :i64] :i64 (+ n 17))','body':'(if (= n 0) (left n) (right n))','n':[0,1,4],'logicalFormula':'run=1,left=(n==0),right=(n!=0)'},
'vector-tail':{'defs':'(defn- read2 [v :vector-i64] :i64 (vector-at v 2))','body':'(read2 (vector-assoc! (vector-alloc 3) 2 n))','n':[0,1,4],'logical':{'run':1,'read2':1}},
'vector-return':{'defs':'(defn- read2 [v :vector-i64] :i64 (vector-at v 2))','body':'(+ (read2 (vector-assoc! (vector-alloc 3) 2 n)) 8)','n':[0,1,4],'logical':{'run':1,'read2':1}},
'vector-oob':{'defs':'(defn- read3 [v :vector-i64] :i64 (vector-at v 3))','body':'(read3 (vector-alloc 3))','n':[0,1,4],'logical':{'run':1,'read3':1}},
'public-vector':{'defs':'(defn read2 [v :vector-i64] :i64 (vector-at v 2))','body':'(read2 (vector-assoc! (vector-alloc 3) 2 n))','n':[0,1,4],'logical':{'run':1,'read2':1}},
}
for name,c in cases.items():
 src='(ns trace.'+name+' (:export [run'+(' read2' if name=='public-vector' else '')+']))\n'+c['defs']+'\n(defn run [n :i64] :i64 '+c['body']+')\n';(D/(name+'.kotoba')).write_text(src)
(D/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
