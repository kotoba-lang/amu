exec((__import__('pathlib').Path('/private/tmp/amu-native-hotpath-20261006/team-constructor/baseline.py')).read_text().split('rows=[]')[0])
I=D.parent/'implementation';loader=I/'diagnostic-loader';compiler=I/'diagnostic-seed-4.bin'
def build(src,out,comp=compiler,ld=loader,symbol='run'):
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(out.with_suffix('.kseed'))]),('extract',['extract-native',str(out.with_suffix('.kseed')),'--symbol',symbol,'--output',str(out)])]:
  q=subprocess.run([str(ld),str(comp),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(out.parent/(out.stem+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(stage,q.stdout[-1000:],q.stderr[-1000:])
  if stage=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1])
 return off

def trace(p,off,n,fuel):
 e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
 q=subprocess.run([str(loader),str(p),str(off),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True)
 counts={int(f):int(c) for f,c in re.findall(r'^ENTRY_COUNT (\d+) (\d+)$',q.stderr,re.M)}
 header=re.search(r'^ENTRY_TRACE (complete|prefix) child=(-?\d+) semantics=modulo-u64$',q.stderr,re.M);assert header,(q.stdout,q.stderr)
 return {'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr,'counts':counts,'completion':header[1]}
base=json.loads((D/'baseline.json').read_text())['rows'];cases=json.loads((D/'cases.json').read_text());rows=[]
for name,c in cases.items():
 p=D/name/'diagnostic.bin';off=build(D/(name+'.kotoba'),p);(D/name/'diagnostic.offset').write_text(str(off)+'\n')
 for x in [v for v in base if v['case']==name]:
  q=trace(p,off,x['n'],x['fuel']);assert q['exit']==x['exit'] and q['stdout']==x['stdout'],(name,x,q)
  for pref in ['DIAG_VECTOR_ITEMS','KEXE_TRAP']:
   assert re.findall('^'+pref+'.*$',q['stderr'],re.M)==re.findall('^'+pref+'.*$',x['stderr'],re.M),(name,pref,x,q)
  assert q['completion']==('complete' if q['exit']==0 else 'prefix')
  if x['fuel']==1048576:
   n=x['n'];expect=({2:1} if name=='inline-wrapper' else {1:1,2:1,3:1,4:1} if name=='private-aux1' else {1:1} if name=='leaf' else {1:1,2:1} if name=='recursive' else {1:n//2+1,3:1,**({2:(n+1)//2} if n else {})} if name=='mutual' else {3:1,(1 if n==0 else 2):1} if name=='diamond' else {1:1,2:1})
   assert q['counts']==expect,(name,n,'expected physical entries',expect,q)
  rows.append({**x,'diagnostic':q})
 print('PASS trace',name,'counts',rows[-1]['diagnostic']['counts'],flush=True)
(D/'trace.json').write_text(json.dumps({'status':'PASS','comparisons':len(rows),'rows':rows},indent=2)+'\n')
