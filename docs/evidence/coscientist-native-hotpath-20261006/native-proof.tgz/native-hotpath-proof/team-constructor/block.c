#include <sys/mman.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <libkern/OSCacheControl.h>
extern void trace_invoke(void*,void*,uint64_t*);
int main(void){
 uint64_t counters[8192],ctx[51],out[27];
 uint32_t *code=mmap(0,4096,PROT_READ|PROT_WRITE|PROT_EXEC,MAP_PRIVATE|MAP_ANON|MAP_JIT,-1,0);if(code==MAP_FAILED)return 9;
 unsigned ids[]={1,4095,4096,8191};unsigned pass=0,detected=0;
 for(unsigned k=0;k<4;k++)for(unsigned mutant=0;mutant<7;mutant++){
  unsigned id=ids[k],actual=mutant==1?id-1:id;memset(counters,0,sizeof counters);memset(ctx,0,sizeof ctx);ctx[50]=(uint64_t)counters;memset(out,0,sizeof out);
  uint32_t block[]={0xf940c8f0,0xd2800011|(actual<<5),0x8b110e10,0xf9400211,mutant==2?0xb1000631:0x91000631,0xf9000211,0xd65f03c0};
  pthread_jit_write_protect_np(0);memcpy(code,block,sizeof block);
  if(mutant>=3){code[6]=0xd2800000|((unsigned)(mutant==3?3:mutant==4?5:mutant==5?8:7));code[7]=0xd65f03c0;}
  pthread_jit_write_protect_np(1);sys_icache_invalidate(code,32);trace_invoke(code,ctx,out);
  int good=counters[id]==1;for(unsigned j=0;j<8192;j++)if(j!=id&&counters[j])good=0;
  for(unsigned j=0;j<16;j++)if(out[j]!=(j==7?(uint64_t)ctx:100+j))good=0;
  for(unsigned j=0;j<10;j++)if(out[16+j]!=119+j)good=0;if(out[26]!=0xa0000000)good=0;
  if(mutant){if(good){fprintf(stderr,"undetected %u %u\n",id,mutant);return 3;}detected++;}else{if(!good){fprintf(stderr,"bad %u\n",id);return 2;}pass++;}
 }
 printf("{\"status\":\"PASS\",\"actualNativeBoundaryIds\":[1,4095,4096,8191],\"validBlocks\":%u,\"actualNativeMutantsDetected\":%u,\"preservedRegisters\":\"x0..15 excluding16/17,x19..28,x7 context,x3..5 cache,x8 fuel\",\"NZCV\":\"preserved\",\"mutants\":[\"wrong id\",\"ADDS clobbers flags\",\"x3 clobber\",\"x5 clobber\",\"x8 clobber\",\"x7 clobber\"]}\n",pass,detected);return 0;
}
