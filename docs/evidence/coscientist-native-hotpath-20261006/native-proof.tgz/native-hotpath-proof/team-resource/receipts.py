from pathlib import Path
import importlib.util,json,hashlib
D=Path(__file__).resolve().parent;I=D.parent/'implementation'
sp=importlib.util.spec_from_file_location('v',D/'trace-validator.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
proof=json.loads((I/'machine-audit.json').read_text());assert proof['status'].startswith('PASS')
build=json.loads((I/'ports-build.json').read_text())
for e in build['entries']:assert hashlib.sha256((I/'ports'/e['workload']/'diagnostic/native.bin').read_bytes()).hexdigest()==e['diagnostic']['sha256']
blocks=json.loads((I/'entry-blocks.json').read_text());table={name:{b[0] for b in record['blocks']} for name,record in blocks.items()};states=json.loads((D/'resource-states.json').read_text());rows=[]
for r in states['rows']:
 t=v.validate('\n'.join(r['counters']),r['diagnostic']['exit'],True,allowed_ids=table[r['workload']]);rows.append({'workload':r['workload'],'resource':r['resource'],'capacity':r['capacity'],'trace':t})
(D/'accepted-receipts.json').write_text(json.dumps({'status':'PASS independent bounded-run trace validation after native machine/source artifact gates','rows':rows,'complete':sum(r['trace']['state']=='complete' for r in rows),'prefix':sum(r['trace']['state']=='prefix' for r in rows)},indent=2)+'\n');print('PASS',len(rows),'qualified bounded-run receipts')
