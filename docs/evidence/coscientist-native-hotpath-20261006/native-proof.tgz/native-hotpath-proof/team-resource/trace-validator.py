"""Independent bounded-run receipt checker; trace provenance is a mandatory input."""
import re,json
from pathlib import Path
D=Path(__file__).resolve().parent

def validate(stderr,exitcode,qualified,expected=None,allowed_ids=None):
 if not qualified:raise ValueError('unqualified artifact')
 traces=[x for x in stderr.splitlines() if x.startswith('ENTRY_TRACE')]
 if len(traces)!=1:raise ValueError('missing/duplicate trace')
 t=re.fullmatch(r'ENTRY_TRACE (complete|prefix) child=(-?\d+) semantics=modulo-u64',traces[0])
 if not t or int(t[2])!=exitcode or (t[1]=='complete')!=(exitcode==0):raise ValueError('publication state')
 counts={}
 for line in stderr.splitlines():
  if not line.startswith('ENTRY_COUNT'):continue
  m=re.fullmatch(r'ENTRY_COUNT (\d+) (\d+)',line)
  if not m:raise ValueError('count format')
  fid,n=map(int,m.groups())
  if not 1<=fid<8192 or not 0<n<2**64 or fid in counts:raise ValueError('count bound/duplicate')
  counts[fid]=n
 if allowed_ids is not None and not set(counts)<=set(allowed_ids):raise ValueError('unknown artifact function')
 if not counts:raise ValueError('missing bounded-run entry evidence')
 if expected is not None and counts!=expected:raise ValueError('calibration mismatch')
 return {'state':t[1],'counts':counts}
if __name__=='__main__':
 good='ENTRY_TRACE complete child=0 semantics=modulo-u64\nENTRY_COUNT 1 1\n';bad={'unqualified-source':(good,0,False),'missing':('ENTRY_TRACE complete child=0 semantics=modulo-u64\n',0,True),'out-of-bounds':(good.replace('COUNT 1 1','COUNT 8192 1'),0,True),'duplicate':(good+'ENTRY_COUNT 1 1\n',0,True),'wrong-publication':(good.replace('complete','prefix'),0,True),'bad-number':(good.replace('COUNT 1 1','COUNT 1 -1'),0,True),'wrapped-value':(good.replace('COUNT 1 1','COUNT 1 18446744073709551616'),0,True)}
 assert validate(good,0,True,{1:1})['state']=='complete'
 assert validate(good.replace('complete child=0','prefix child=132'),132,True,{1:1})['state']=='prefix'
 rows=[]
 for name,args in bad.items():
  try:validate(*args);raise AssertionError(name)
  except ValueError as e:rows.append({'fault':name,'refused':str(e)})
 try:validate(good.replace('COUNT 1 1','COUNT 8000 1'),0,True,allowed_ids={1});raise AssertionError('unknown function')
 except ValueError as e:rows.append({'fault':'unknown-function-within-array','refused':str(e)})
 (D/'trace-validator-controls.json').write_text(json.dumps({'status':'PASS independent receipt acceptance controls','rows':rows,'scope':'Applied to these bounded native runs with trusted machine-audited artifact pins; raw blobs are calibration only, never production traces. A modulo-u64 trace is not exact unbounded counts or runtime correctness proof.'},indent=2)+'\n')
