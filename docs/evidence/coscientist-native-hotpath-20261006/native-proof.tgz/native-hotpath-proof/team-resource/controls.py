from pathlib import Path
import subprocess,struct,json,re,os,hashlib
W=Path('/private/tmp/amu-native-hotpath-20261006');D=W/'team-resource';I=W/'implementation';src=(I/'diagnostic-loader.c').read_text()
# Exact raw entry contract calibration; separate from original19 semantic proof.
def blob(fid,trap=False,pointer_offset=400):
 words=[0xf9400000|((pointer_offset//8)<<10)|(7<<5)|16,0xd2800000|(fid<<5)|17,0x8b000000|(17<<16)|(3<<10)|(16<<5)|16,0xf9400211,0x91000631,0xf9000211,0xd2800540,0xd4200000 if trap else 0xd65f03c0];return struct.pack('<'+'I'*len(words),*words)
for name,fid,trap,off in [('entry1',1,False,400),('entry8191',8191,False,400),('prefix1',1,True,400),('wrong-offset',1,False,392),('out-of-range-slot',8192,False,400)]: (D/(name+'.bin')).write_bytes(blob(fid,trap,off))
variants={'correct':src,'null-pointer':src.replace('shared->context.diagnostic_counters = shared->diagnostic_counters;','shared->context.diagnostic_counters = NULL;'),'past-array-pointer':src.replace('shared->context.diagnostic_counters = shared->diagnostic_counters;','shared->context.diagnostic_counters = shared->diagnostic_counters + 8192;'),'wrong-publication':src.replace('shared->result = result;','shared->result = result + 1;'),'resource-accounting':src.replace('kexe_vector_item_budget, (s)->vector_item_used','kexe_vector_item_budget + 1, (s)->vector_item_used')}
rows=[]
for name,version in variants.items():
 if name=='correct':loader=I/'diagnostic-loader'
 else:
  p=D/(name+'.c');p.write_text(version);loader=D/name;q=subprocess.run(['clang','-O2','-std=c11',str(p),'-o',str(loader)],capture_output=True,text=True);(D/(name+'-build.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,q.stderr[-2000:])
 for case in (['entry1','entry8191','prefix1','wrong-offset','out-of-range-slot'] if name=='correct' else ['entry1']):
  env=dict(os.environ,KEXE_STRUCTURED_REPORT='1');q=subprocess.run([str(loader),str(D/(case+'.bin')),'0','0','aarch64','-'],env=env,capture_output=True,text=True);(D/(name+'-'+case+'.log')).write_text(q.stdout+q.stderr)
  wantedfid=8191 if case=='entry8191' else 1
  good=q.returncode==0 and ':result 42 ' in q.stdout and f'ENTRY_COUNT {wantedfid} 1\n' in q.stderr and 'ENTRY_TRACE complete' in q.stderr and ':vector-items {:capacity 65536 :used 0}' in q.stdout
  if case=='prefix1':good=q.returncode!=0 and 'ENTRY_TRACE prefix' in q.stderr and 'ENTRY_COUNT 1 1\n' in q.stderr
  expected=name=='correct' and case in ['entry1','entry8191','prefix1'];assert good==expected,(name,case,q.returncode,q.stdout,q.stderr)
  rows.append({'loader':name,'case':case,'exit':q.returncode,'good':good,'expected':expected,'stdout':q.stdout,'stderr':q.stderr});print(name,case,'ACCEPTED' if good else 'DETECTED',flush=True)
(D/'counter-controls.json').write_text(json.dumps({'status':'PASS actual raw-native counter boundary and four compiled loader mutants','rows':rows,'limits':'Wrong raw slot/offset outside checked instrumentation contract; detected by oracle, not guaranteed memory guard.'},indent=2)+'\n')
