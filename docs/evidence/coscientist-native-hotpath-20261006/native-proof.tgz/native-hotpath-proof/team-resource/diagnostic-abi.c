#define main resource_original_main
#include "/private/tmp/amu-native-hotpath-20261006/implementation/diagnostic-loader.c"
#undef main
_Static_assert(sizeof(struct kexe_context_v11)==408,"size");
_Static_assert(offsetof(struct kexe_context_v11,diagnostic_counters)==400,"pointer");
_Static_assert(offsetof(struct kexe_shared_v11,diagnostic_counters)==408,"array");
_Static_assert(sizeof(((struct kexe_shared_v11*)0)->diagnostic_counters)==65536,"8192slots");
_Static_assert(offsetof(struct kexe_shared_v11,result)==65944,"result moved past owned array");
int main(void){
printf("ctx version %zu\n",offsetof(struct kexe_context_v11,version));
printf("ctx fuel %zu\n",offsetof(struct kexe_context_v11,fuel));
printf("ctx allow %zu\n",offsetof(struct kexe_context_v11,allow));
printf("ctx code_base %zu\n",offsetof(struct kexe_context_v11,code_base));
printf("ctx code_length %zu\n",offsetof(struct kexe_context_v11,code_length));
printf("ctx vector_items_base %zu\n",offsetof(struct kexe_context_v11,vector_items_base));
printf("shared result %zu\n",offsetof(struct kexe_shared_v11,result));
printf("shared completed %zu\n",offsetof(struct kexe_shared_v11,completed));
printf("shared budget_exhausted %zu\n",offsetof(struct kexe_shared_v11,budget_exhausted));
printf("shared value_trap %zu\n",offsetof(struct kexe_shared_v11,value_trap));
printf("shared pairs %zu\n",offsetof(struct kexe_shared_v11,pairs));
printf("shared vectors %zu\n",offsetof(struct kexe_shared_v11,vectors));
printf("shared vector_items %zu\n",offsetof(struct kexe_shared_v11,vector_items));
printf("shared string_pool %zu\n",offsetof(struct kexe_shared_v11,string_pool));
printf("arenas %zu %zu %zu %zu\n",sizeof(((struct kexe_shared_v11*)0)->pairs),sizeof(((struct kexe_shared_v11*)0)->vectors),sizeof(((struct kexe_shared_v11*)0)->vector_items),sizeof(((struct kexe_shared_v11*)0)->string_pool));printf("budgets %llu %llu %llu %llu\n",(unsigned long long)kexe_pair_budget,(unsigned long long)kexe_vector_budget,(unsigned long long)kexe_vector_item_budget,(unsigned long long)kexe_string_pool_budget);return 0;}
