from pathlib import Path
import subprocess,re,json
W=Path('/private/tmp/amu-native-hotpath-20261006');D=W/'team-resource';I=W/'implementation';product=Path('/private/tmp/amu-private-length-clones-20261006/source-snapshot/tools/kexe_loader.c');owned=I/'diagnostic-loader.c'
fields=['version','fuel','allow','code_base','code_length','vector_items_base'];shared=['result','completed','budget_exhausted','value_trap','pairs','vectors','vector_items','string_pool']
rows={}
for label,path,size in [('product',product,400),('diagnostic',owned,408)]:
 src='#define main resource_original_main\n#include "'+str(path)+'"\n#undef main\n_Static_assert(sizeof(struct kexe_context_v11)=='+str(size)+',"size");\n'
 if label=='diagnostic':src+='''_Static_assert(offsetof(struct kexe_context_v11,diagnostic_counters)==400,"pointer");
_Static_assert(offsetof(struct kexe_shared_v11,diagnostic_counters)==408,"array");
_Static_assert(sizeof(((struct kexe_shared_v11*)0)->diagnostic_counters)==65536,"8192slots");
_Static_assert(offsetof(struct kexe_shared_v11,result)==65944,"result moved past owned array");
'''
 src+='int main(void){\n'+''.join('printf("ctx %s %%zu\\n",offsetof(struct kexe_context_v11,%s));\n'%(x,x) for x in fields)+''.join('printf("shared %s %%zu\\n",offsetof(struct kexe_shared_v11,%s));\n'%(x,x) for x in shared)+'printf("arenas %zu %zu %zu %zu\\n",sizeof(((struct kexe_shared_v11*)0)->pairs),sizeof(((struct kexe_shared_v11*)0)->vectors),sizeof(((struct kexe_shared_v11*)0)->vector_items),sizeof(((struct kexe_shared_v11*)0)->string_pool));printf("budgets %llu %llu %llu %llu\\n",(unsigned long long)kexe_pair_budget,(unsigned long long)kexe_vector_budget,(unsigned long long)kexe_vector_item_budget,(unsigned long long)kexe_string_pool_budget);return 0;}\n'
 p=D/(label+'-abi.c');p.write_text(src);q=subprocess.run(['clang','-O2','-std=c11',str(p),'-o',str(D/(label+'-abi'))],capture_output=True,text=True);(D/(label+'-abi-build.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stderr[-3000:]);q=subprocess.run([str(D/(label+'-abi'))],capture_output=True,text=True);assert q.returncode==0;rows[label]=q.stdout;(D/(label+'-abi.log')).write_text(q.stdout)
a=rows['product'].splitlines();b=rows['diagnostic'].splitlines();assert a[:len(fields)]==b[:len(fields)] and a[-2:]==b[-2:]
for aa,bb in zip(a[len(fields):-2],b[len(fields):-2]):assert int(bb.split()[-1])-int(aa.split()[-1])==65544,(aa,bb)
# Exact complete declaration prefix modulo comments and whitespace.
def prefix(p):
 s=p.read_text().split('struct kexe_context_v11 {',1)[1].split('\n};',1)[0];s=s.split('uint64_t *diagnostic_counters;',1)[0];return re.sub(r'\s+','',re.sub(r'/\*.*?\*/','',s,flags=re.S))
assert prefix(product)==prefix(owned)
report={'status':'PASS compiled ABI sizes offsets and complete400-byte declaration prefix equality','contextPrefixSize':400,'ownedContextSize':408,'counterPointerOffset':400,'counterArrayOffset':408,'counterSlots':8192,'sharedResultOffset':65944,'allSharedSuffixFieldsMovedBy':65544,'arenaBudgetDefaultsEqual':True,'arenaFixedArrayCapacitiesEqual':True,'rows':rows,'lifetimeReview':'Counter array resides in MAP_SHARED owned supervisor struct allocated and zero-initialized before pointer publication/fork; parent reads after waitpid, mapping released after report. Guest arena accounting excludes diagnostic storage and keeps its existing limits.'}
(D/'abi-proof.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'])
