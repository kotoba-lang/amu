from pathlib import Path
import importlib.util
sp=importlib.util.spec_from_file_location('validator',Path(__file__).resolve().parent/'trace-validator.py');validator=importlib.util.module_from_spec(sp);sp.loader.exec_module(validator)
import json,os,re,subprocess,hashlib
W=Path('/private/tmp/amu-native-hotpath-20261006');D=W/'team-resource';OLD=Path('/private/tmp/amu-private-length-clones-20261006');B=Path('/private/tmp/amu-static-vector-chain-20261006');prior=json.loads((OLD/'ports-state.json').read_text());current=json.loads((B/'ports-correctness.json').read_text());rows=[]
resources={'heap':'KEXE_PAIRS','string-pool':'KEXE_STRING_POOL','vectors':'KEXE_VECTORS','vector-items':'KEXE_VECTOR_ITEMS'}
# Paths become available only after machine owner's freeze receipt.
def run(diagnostic_loader,entries):
 for e in entries:
  name=e['workload'];old=next(x for x in current['entries'] if x['workload']==name);p=next(x for x in prior['rows'] if x['workload']==name and x['n']==1 and x['fuel']==16777216);cases=[]
  for res,envkey in resources.items():
   used=int(re.search(':'+res+r' \{:capacity \d+ :used (\d+)\}',p['product']['report'])[1]);caps=sorted(set([1]+[max(1,used+x) for x in [-1,0,1]]))
   for cap in caps:cases.append((res,envkey,cap,used))
  for res,envkey,cap,used in cases:
   obs={}
   for label,loader,path,off in [('product',OLD/'full-state-loader',B/'ports-2'/name/'native.bin',old['offset']),('diagnostic',diagnostic_loader,Path(e['bin']),e['offset'])]:
    env=dict(os.environ,KEXE_FUEL='16777216',KEXE_STRUCTURED_REPORT='1',**{envkey:str(cap)});env.pop('KEXE_COMMAND',None)
    q=subprocess.run([str(loader),str(path),str(off),'1','aarch64','-','1'],env=env,capture_output=True,text=True)
    counters=[x for x in q.stderr.splitlines() if x.startswith(('DIAG_COUNT ','HOTPATH_COUNT ','ENTRY_COUNT ','ENTRY_TRACE '))]
    stderr='\n'.join(x for x in q.stderr.splitlines() if not x.startswith(('DIAG_COUNT ','HOTPATH_COUNT ','ENTRY_COUNT ','ENTRY_TRACE ')))
    obs[label]={'exit':q.returncode,'stdout':q.stdout.strip(),'stderr':stderr.strip()}
    if label=='diagnostic':
     obs['counters']=counters
     obs['validatedTrace']=validator.validate(q.stderr,q.returncode,True)
   assert obs['product']==obs['diagnostic'],(name,res,cap,obs)
   assert ':fuel ' in obs['diagnostic']['stdout'],(name,res,cap,obs)
   rows.append({'workload':name,'resource':res,'capacity':cap,'nominalUsed':used,**obs})
  print('PASS resource boundary',name,len(cases),flush=True)
 (D/'resource-states.json').write_text(json.dumps({'status':'PASS','fullStatePairs':len(rows),'trappedPairs':sum(r['product']['exit']!=0 for r in rows),'rows':rows},indent=2)+'\n')

if __name__=='__main__':
 I=W/'implementation';proof=json.loads((I/'machine-audit.json').read_text());assert proof['status'].startswith('PASS')
 build=json.loads((I/'ports-build.json').read_text());entries=[]
 for e in build['entries']:
  p=I/'ports'/e['workload']/'diagnostic/native.bin';assert hashlib.sha256(p.read_bytes()).hexdigest()==e['diagnostic']['sha256'];entries.append({'workload':e['workload'],'bin':str(p),'offset':e['diagnostic']['offset']})
 pins=json.loads((I/'source-pins.json').read_text())
 for p,v in pins.items():assert hashlib.sha256((I/p).read_bytes()).hexdigest()==v
 run(I/'diagnostic-loader',entries)
