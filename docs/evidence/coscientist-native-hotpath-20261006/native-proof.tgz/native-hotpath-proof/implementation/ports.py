from pathlib import Path
import subprocess,os,re,json,hashlib
W=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17');B=Path('/private/tmp/amu-static-vector-chain-20261006');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[]
parts=[p.strip() for p in (R/'seed/MANIFEST').read_text().splitlines() if p.strip() and not p.lstrip().startswith('#')];og=(B/'observer/observer-41-a64gen.kotoba').read_text();helper=(W/'entry-native.kotoba').read_text();og=og.replace('(defn- gn-op-fn2 [',helper+'\n(defn- gn-op-fn2 [');needle='(gn-gs gn-f-vslot (if (= (gn-g M2 gn-f-vmode) 2) -1 0)) (gn-tree-entry f)';assert og.count(needle)==1;og=og.replace(needle,'(gn-gs gn-f-vslot (if (= (gn-g M2 gn-f-vmode) 2) -1 0)) (gn-entry-record f) (gn-tree-entry f)');(W/'observer-41.kotoba').write_text(og);(W/'observer-unity.kotoba').write_text('\n'.join(og if p=='seed/41-a64gen.kotoba' else (R/p).read_text() for p in parts))
for label,args in [('compile',['compile',str(W/'observer-unity.kotoba'),'--target','aarch64-macos','--output',str(W/'observer-seed.kseed')]),('extract',['extract-native',str(W/'observer-seed.kseed'),'--symbol','main','--output',str(W/'observer-seed.bin')])]:
 q=subprocess.run([str(W/'kexe-loader'),str(W/'seed-0.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(W/('observer-'+label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout[-1500:],q.stderr[-1500:])
 if label=='extract':observeroff=re.search(r':offset (\d+)',q.stdout).group(1)
for e in json.loads((R/'bench/embench/comparison-matrix.json').read_text())['entries']:
 name=e['workload'];src=R/e['source'];assert sha(src)==e['expectedSourceSha256'];item={'workload':name,'sourceSha256':sha(src),'symbol':e['symbol'],'iterations':e['iterations']}
 for arm in ['quiet','diagnostic','observer']:
  d=W/'ports'/name/arm;d.mkdir(parents=True,exist_ok=True);seed=W/('observer-seed.bin' if arm=='observer' else f'{arm}-seed-1.bin');off=observeroff if arm=='observer' else '0'
  for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(d/'image.kseed')]),('extract',['extract-native',str(d/'image.kseed'),'--symbol',e['symbol'],'--output',str(d/'native.bin')])]:
   q=subprocess.run([str(W/'kexe-loader'),str(seed),off,'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,arm,label,q.stdout[-1500:],q.stderr[-1500:])
   if label=='extract':offset=int(re.search(r':offset (\d+)',q.stdout).group(1))
  item[arm]={'bytes':(d/'native.bin').stat().st_size,'sha256':sha(d/'native.bin'),'offset':offset}
 base=next(x for x in json.loads((B/'ports-correctness.json').read_text())['entries'] if x['workload']==name)
 assert item['quiet']['sha256']==base['nativeSha256'] and item['quiet']['offset']==base['offset'];assert item['diagnostic']==item['observer'];rows.append(item);print('PASS quiet byte/offset and observer exact diagnostic',name,flush=True)
(W/'ports-build.json').write_text(json.dumps({'status':'PASS all19 disabled product exact and actual diagnostic observer byte/offset parity; not yet trace execution','entries':rows},indent=2)+'\n')
