from pathlib import Path
import subprocess,struct,json
W=Path(__file__).resolve().parent;b=(W/'entry-register').read_bytes();ncmd=struct.unpack_from('<I',b,16)[0];pos=32;syms=None;text=None
for _ in range(ncmd):
 cmd,size=struct.unpack_from('<II',b,pos)
 if cmd==2:syms=struct.unpack_from('<IIII',b,pos+8)
 if cmd==0x19:
  ns=struct.unpack_from('<I',b,pos+64)[0]
  for j in range(ns):
   p=pos+72+j*80
   if b[p:p+16].split(b'\0')[0]==b'__text':text=struct.unpack_from('<QQI',b,p+32)
 pos+=size
assert text and syms;symoff,nsyms,stroff,strsize=syms;symbols={}
for k in range(nsyms):
 sx,ty,se,desc,value=struct.unpack_from('<IBBHQ',b,symoff+k*16);name=b[stroff+sx:].split(b'\0')[0].decode();symbols[name]=value
rows=[]
for f in [1,2,17,363,539,4095,4096,8191]:
 at=symbols['_entry_'+str(f)]-text[0]+text[2];actual=list(struct.unpack_from('<6I',b,at));expected=[0xf940c8f0,0xd2800011|(f<<5),0x8b110e10,0xf9400211,0x91000631,0xf9000211];assert actual==expected;rows.append({'fn':f,'words':[hex(x) for x in actual]})
controls=[];source=(W/'entry-register.s').read_text()
for name,needle,replacement in [('live-x3-clobber',' str x17,[x16]',' str x17,[x16]\n mov x3,#303'),('NZCV-clobber',' add x17,x17,#1',' adds x17,x17,#1'),('wrong-slot',' movz x17,#1\n',' movz x17,#2\n')]:
 d=W/'register-mutants'/name;d.mkdir(parents=True,exist_ok=True);(d/'probe.s').write_text(source.replace(needle,replacement));q=subprocess.run(['clang','-O2','-o',str(d/'probe'),str(W/'entry-register.c'),str(d/'probe.s')],capture_output=True,text=True);(d/'build.log').write_text(q.stdout+q.stderr);assert q.returncode==0
 q=subprocess.run([str(d/'probe')],capture_output=True,text=True);(d/'run.log').write_text(q.stdout+q.stderr);assert q.returncode!=0;controls.append({'mutant':name,'exit':q.returncode,'diagnostic':q.stderr.strip()})
(W/'entry-register-proof.json').write_text(json.dumps({'status':'PASS independent assembler actual-byte and24 native register/NZCV/SP/fuel/assigned-slot probes;3 native faults refused','actualAssemblerBlocks':rows,'nativeControls':controls,'limits':'Entry reserved x16/17 clobbers permitted; index bounds/pointer capacity separately assumed/proved. Not mid-body scratch contract or timing.'},indent=2)+'\n');print('PASS assembler actual bytes and native fault calibration')
