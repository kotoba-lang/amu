from pathlib import Path
import subprocess,os,re,json,hashlib
W=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[]
for arm,ngen in [('quiet',1),('diagnostic',4)]:
 for generation in range(1,ngen+1):
  prev=W/'seed-0.bin' if generation==1 else W/f'{arm}-seed-{generation-1}.bin';off=(W/'seed-0.offset').read_text().strip() if generation==1 else (W/f'{arm}-seed-{generation-1}.offset').read_text().strip();loader=W/('diagnostic-loader' if generation>=3 and arm=='diagnostic' else 'kexe-loader')
  for label,args in [('compile',['compile',str(W/(arm+'-unity.kotoba')),'--target','aarch64-macos','--output',str(W/f'{arm}-seed-{generation}.kseed')]),('extract',['extract-native',str(W/f'{arm}-seed-{generation}.kseed'),'--symbol','main','--output',str(W/f'{arm}-seed-{generation}.bin')])]:
   q=subprocess.run([str(loader),str(prev),off,'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(W/f'{arm}-seed-{generation}-{label}.log').write_text(q.stdout+q.stderr);assert q.returncode==0,(arm,generation,label,q.stdout[-1500:],q.stderr[-1500:])
   if label=='extract':offset=re.search(r':offset (\d+)',q.stdout).group(1);(W/f'{arm}-seed-{generation}.offset').write_text(offset+'\n')
  rows.append({'arm':arm,'generation':generation,'bytes':(W/f'{arm}-seed-{generation}.bin').stat().st_size,'sha256':sha(W/f'{arm}-seed-{generation}.bin'),'offset':int(offset)});print('PASS native',rows[-1],flush=True)
assert len({(x['sha256'],x['offset']) for x in rows if x['arm']=='diagnostic' and x['generation']>=2})==1
(W/'build-proof.json').write_text(json.dumps({'status':'PASS diagnostic-native generations2/3/4 fixedpoint; quietgen1','entries':rows},indent=2)+'\n')
