from pathlib import Path
import hashlib,json,shutil
W=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17');B=Path('/private/tmp/amu-static-vector-chain-20261006');P=Path('/private/tmp/amu-statemate-fuel-census-20261006');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(B/'seed-4.bin')=='f00e38312ac7278b1b597207054cba521fafa28f30f03d20d237a07fd59647e2'
g=(B/'41-a64gen-prototype.kotoba').read_text();assert g==(R/'seed/41-a64gen.kotoba').read_text();(W/'baseline-41-a64gen.kotoba').write_text(g)
helper='''
;; Distinct diagnostic only: physical entry before original entry fuel.
;; x16/x17 reserved scratch here; all args/locals materialized, x7=context.
;; Nonflag modulo increment; no stack, fuel, arena or original trap change.
(def gn-entry-observe true)
(defn- gn-entry-record [M :vector-i64 f :i64] :vector-i64
 (if (not gn-entry-observe) M
  (if (or (< f 1) (>= f MM-FN-CAP)) (gn-err M E-GEN-OP OP-FN)
   (-> M (gn-emit (enc-ldr 16 7 400))
         (gn-emit (enc-movz 17 f 0))
         (gn-emit (gn-e-addsl 16 16 17 3))
         (gn-emit (enc-ldr 17 16 0))
         (gn-emit (enc-add-i 17 17 1))
         (gn-emit (enc-str 17 16 0))))))
'''
g=g.replace('(defn- gn-op-fn2 [',helper+'\n(defn- gn-op-fn2 [');needle='(gn-gs gn-f-vslot (if (= (gn-g M2 gn-f-vmode) 2) -1 0)) (gn-tree-entry f)';assert g.count(needle)==1;g=g.replace(needle,'(gn-gs gn-f-vslot (if (= (gn-g M2 gn-f-vmode) 2) -1 0)) (gn-entry-record f) (gn-tree-entry f)')
(W/'41-a64gen-diagnostic.kotoba').write_text(g);(W/'41-a64gen-quiet.kotoba').write_text(g.replace('(def gn-entry-observe true)','(def gn-entry-observe false)'));(W/'entry-native.kotoba').write_text(helper)
parts=[p.strip() for p in (R/'seed/MANIFEST').read_text().splitlines() if p.strip() and not p.lstrip().startswith('#')]
for arm,source in [('diagnostic',g),('quiet',g.replace('(def gn-entry-observe true)','(def gn-entry-observe false)'))]:
 (W/(arm+'-unity.kotoba')).write_text('\n'.join(source if p=='seed/41-a64gen.kotoba' else (R/p).read_text() for p in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader')]:shutil.copy2(B/src,W/dst)
c=(P/'diagnostic-loader.c').read_text();assert c.count('diagnostic_counters[65536]')==1 and c.count('d < 65536')==1;c=c.replace('diagnostic_counters[65536]','diagnostic_counters[8192]').replace('d < 65536','d < 8192').replace('DIAG_COUNT %u %llu','ENTRY_COUNT %u %llu')
needle='for (unsigned d = 0; d < 8192; ++d) if (shared->diagnostic_counters[d]) fprintf(stderr, "ENTRY_COUNT %u %llu\\n", d, (unsigned long long)shared->diagnostic_counters[d]);'
assert c.count(needle)==1;c=c.replace(needle,'fprintf(stderr, "ENTRY_TRACE %s child=%d semantics=modulo-u64\\n", child_status == 0 && shared->completed == 1 ? "complete" : "prefix", child_status);\n  '+needle)
c+='\n_Static_assert(sizeof(struct kexe_context_v11) == 408, "owned diagnostic context size");\n_Static_assert(sizeof(((struct kexe_shared_v11 *)0)->diagnostic_counters) == 8192u*8u, "owned diagnostic slot bound");\n'
(W/'diagnostic-loader.c').write_text(c)
(W/'hypothesis.json').write_text(json.dumps({'status':'registered before actual native builds','diagnosticOnly':True,'entrySemantics':'physical native function arrival before original entry fuel; u64 modular counters; complete/prefix labelled; inline-eliminated wrappers not logical counted','capacity':8192,'requiredABI':{'ownedCounterPointerOffset':400,'ownedContextSize':408,'prefixUnchanged':True,'privateAux1MarkerAndSkipUnchanged':True},'proofBeforeOriginal19Trace':['quiet all19 byte/offset parity','normalized full actual opcode/branch/fixup/literal/entry marker audit','entry register contract/control tests; fullstate/resource controls by team'],'authoringException':'Excluded new diagnostic native algorithm and owned supervisor, not mechanical product refactor','timingPerformed':False,'promotion':False},indent=2)+'\n')
inputs=[B/'41-a64gen-prototype.kotoba',B/'42-layout-prototype.kotoba',B/'seed-4.bin',P/'diagnostic-loader.c',R/'seed/MANIFEST'];(W/'input-pins.json').write_text(json.dumps({str(p):sha(p) for p in inputs},indent=2)+'\n');(W/'source-pins.json').write_text(json.dumps({p.name:sha(p) for p in [W/'41-a64gen-diagnostic.kotoba',W/'41-a64gen-quiet.kotoba',W/'diagnostic-loader.c',W/'diagnostic-unity.kotoba',W/'quiet-unity.kotoba']},indent=2)+'\n')
print('PASS diagnostic source frozen')
