.text
.globl _entry_probe
.p2align 2
_entry_probe:
 stp x19,x20,[sp,#-16]!
 stp x29,x30,[sp,#-16]!
 mov x29,sp
 mov x19,x0
 mov x20,x2
 mov x7,x1
 mov x0,#100
 mov x1,#101
 mov x2,#102
 mov x3,#103
 mov x4,#104
 mov x5,#105
 mov x6,#106
 mov x8,#108
 mov x9,#109
 mov x10,#110
 mov x11,#111
 mov x12,#112
 mov x13,#113
 mov x14,#114
 mov x15,#115
 cmp xzr,xzr
 mrs x16,nzcv
 str x16,[x20,#128]
 mov x16,sp
 str x16,[x20,#144]
 mov x16,#116
 mov x17,#117
 blr x19
 stp x0,x1,[x20,#0]
 stp x2,x3,[x20,#16]
 stp x4,x5,[x20,#32]
 stp x6,x7,[x20,#48]
 stp x8,x9,[x20,#64]
 stp x10,x11,[x20,#80]
 stp x12,x13,[x20,#96]
 stp x14,x15,[x20,#112]
 mrs x16,nzcv
 str x16,[x20,#136]
 mov x16,sp
 str x16,[x20,#152]
 mov sp,x29
 ldp x29,x30,[sp],#16
 ldp x19,x20,[sp],#16
 ret
.globl _entry_1
.p2align 2
_entry_1:
 ldr x16,[x7,#400]
 movz x17,#1
 add x16,x16,x17,lsl #3
 ldr x17,[x16]
 adds x17,x17,#1
 str x17,[x16]
 ret
.globl _entry_2
.p2align 2
_entry_2:
 ldr x16,[x7,#400]
 movz x17,#2
 add x16,x16,x17,lsl #3
 ldr x17,[x16]
 adds x17,x17,#1
 str x17,[x16]
 ret
.globl _entry_17
.p2align 2
_entry_17:
 ldr x16,[x7,#400]
 movz x17,#17
 add x16,x16,x17,lsl #3
 ldr x17,[x16]
 adds x17,x17,#1
 str x17,[x16]
 ret
.globl _entry_363
.p2align 2
_entry_363:
 ldr x16,[x7,#400]
 movz x17,#363
 add x16,x16,x17,lsl #3
 ldr x17,[x16]
 adds x17,x17,#1
 str x17,[x16]
 ret
.globl _entry_539
.p2align 2
_entry_539:
 ldr x16,[x7,#400]
 movz x17,#539
 add x16,x16,x17,lsl #3
 ldr x17,[x16]
 adds x17,x17,#1
 str x17,[x16]
 ret
.globl _entry_4095
.p2align 2
_entry_4095:
 ldr x16,[x7,#400]
 movz x17,#4095
 add x16,x16,x17,lsl #3
 ldr x17,[x16]
 adds x17,x17,#1
 str x17,[x16]
 ret
.globl _entry_4096
.p2align 2
_entry_4096:
 ldr x16,[x7,#400]
 movz x17,#4096
 add x16,x16,x17,lsl #3
 ldr x17,[x16]
 adds x17,x17,#1
 str x17,[x16]
 ret
.globl _entry_8191
.p2align 2
_entry_8191:
 ldr x16,[x7,#400]
 movz x17,#8191
 add x16,x16,x17,lsl #3
 ldr x17,[x16]
 adds x17,x17,#1
 str x17,[x16]
 ret
