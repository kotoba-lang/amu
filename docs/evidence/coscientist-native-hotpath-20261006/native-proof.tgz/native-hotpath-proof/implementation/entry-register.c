#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
extern void entry_probe(void *,void *,uint64_t *);
extern void entry_1(void),entry_2(void),entry_17(void),entry_363(void),entry_539(void),entry_4095(void),entry_4096(void),entry_8191(void);
int main(void) {
 uint64_t *c=calloc(8192,sizeof(uint64_t));uint8_t context[408]={0};memcpy(context+400,&c,8);uint64_t fuel=123456;memcpy(context+8,&fuel,8);
 unsigned ids[]={1,2,17,363,539,4095,4096,8191};void *funcs[]={entry_1,entry_2,entry_17,entry_363,entry_539,entry_4095,entry_4096,entry_8191};
 for(unsigned i=0;i<8;i++)for(unsigned rep=0;rep<3;rep++) {uint64_t out[20]={0};entry_probe(funcs[i],context,out);for(unsigned r=0;r<16;r++){uint64_t expected=r==7?(uintptr_t)context:100+r;if(out[r]!=expected){fprintf(stderr,"register fault id%u x%u\n",ids[i],r);return 1;}}if(out[16]!=out[17]||out[18]!=out[19]||memcmp(context+8,&fuel,8)||c[ids[i]]!=rep+1){fprintf(stderr,"state fault id%u\n",ids[i]);return 1;}}
 unsigned nonzero=0;for(unsigned i=0;i<8192;i++)if(c[i])nonzero++;if(nonzero!=8)return 1;puts("PASS 24 native entry blocks preserve x0..15 (x7 ctx, x8 live fuel), NZCV/SP/context fuel; index4096/8191 covered; only assigned slot increments");free(c);return 0;
}
