from pathlib import Path
import json,re,hashlib,shutil,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-copy-forward-20261006');w.mkdir();b=Path('/private/tmp/amu-dot-unroll-return-20261006');c=Path('/private/tmp/amu-residual-write-census-20261006');g=(r/'seed/41-a64gen.kotoba').read_text();C={}
for n in ['seed/SIR','seed/HEADS','seed/MEMORY-MAP']:
 for m in re.finditer(r'\[:c (\S+) (-?\d+)',(r/n).read_text()):C[m[1]]=int(m[2])
ops={v:k for k,v in C.items() if k.startswith('OP-')};T=[]
for l in (c/'meta-ports/matmult-int/compile.log').read_text().splitlines():
 if l.startswith('SIR '):
  i,op,a,z,k=map(int,l.split()[1:])
  if 3244<=i<=3271:T.append([ops[op],a,z,k])
subs={(0,1):'f',(2,1):'head',(4,2):'n',(5,1):'CC-EQ',(6,2):'body',(8,1):'exit',(9,1):'body',(11,2):'dest',(13,1):'BOP-ADD',(16,1):'RT-VECTOR-AT',(17,1):'writer',(20,1):'BOP-ADD',(24,1):'head',(25,1):'exit',(27,1):'f'}
for (j,k),v in subs.items():T[j][k]=v
(w/'template.json').write_text(json.dumps(T,indent=2)+'\n')
shape='\n'.join('    '+str(j)+' (gn-dot-at? M (+ p '+str(j)+') '+' '.join(map(str,t))+')' for j,t in enumerate(T))
s=''';; Guarded exact closed forward-copy leaf; original fallback and fuel remain.
(defn- gn-copy-writer? [M :vector-i64 f :i64] :bool
 (let [p (gn-fnf M f FF-SIR)]
  (and (> f 0) (< f (vector-at M MM-FN-N)) (> p 0) (< (+ p 8) (vector-at M MM-SIR-N))
       (not (gn-clamp-open M f)) (= (gn-fnf M f FF-NPARAMS) 3) (= (gn-fnf M f FF-NSLOTS) 3)
       (= (gn-fnf M f FF-DEPTH) 3) (= (gn-fnf M f FF-PT0) TY-VEC)
       (= (gn-fnf M f (+ FF-PT0 1)) TY-I64) (= (gn-fnf M f (+ FF-PT0 2)) TY-I64)
       (= (gn-fnf M f FF-RTYPE) TY-VEC)
       (gn-dot-at? M p OP-FN f 3 3) (gn-dot-at? M (+ p 1) OP-FUEL 0 0 0)
       (gn-dot-at? M (+ p 2) OP-LGET 0 1 0) (gn-dot-at? M (+ p 3) OP-LGET 1 2 0)
       (gn-dot-at? M (+ p 4) OP-LGET 2 3 0) (gn-dot-at? M (+ p 5) OP-RT RT-VECTOR-ASSOC-IN-PLACE 0 3)
       (gn-dot-at? M (+ p 6) OP-RET 0 0 0) (gn-dot-at? M (+ p 7) OP-END f 0 0))))
(defn- gn-copy-shape [M :vector-i64 p :i64 f :i64 k :i64] :bool
 (if (= k 28) true
  (let [head (gn-sir M (+ p 2) IF-A) body (gn-sir M (+ p 6) IF-B)
        exit (gn-sir M (+ p 8) IF-A) n (gn-sir M (+ p 4) IF-B)
        dest (gn-sir M (+ p 11) IF-B) writer (gn-sir M (+ p 17) IF-A)]
   (and (case k
SHAPE
    false) (gn-copy-shape M p f (inc k))))))
(defn- gn-copy? [M :vector-i64 i :i64] :bool
 (let [p (dec i) f (gn-sir M p IF-A)]
  (and (> p 0) (< (+ p 27) (vector-at M MM-SIR-N)) (= (gn-op M p) OP-FN)
       (> f 0) (< f (vector-at M MM-FN-N)) (not (gn-clamp-open M f))
       (= (gn-fnf M f FF-SIR) p) (= (gn-fnf M f FF-NPARAMS) 2) (= (gn-fnf M f FF-NSLOTS) 2)
       (= (gn-fnf M f FF-DEPTH) 4) (= (gn-fnf M f FF-PT0) TY-VEC)
       (= (gn-fnf M f (+ FF-PT0 1)) TY-I64) (= (gn-fnf M f FF-RTYPE) TY-VEC)
       (= (gn-g M gn-f-leaf) 1) (= (gn-g M gn-f-fb) 0) (= (gn-g M gn-f-freg) 1)
       (= (gn-g M gn-f-h) 0) (= (gn-sreg M 1) 0) (= (gn-sreg M 2) 1)
       (>= (gn-sir M (+ p 4) IF-B) 1) (<= (gn-sir M (+ p 4) IF-B) 2047)
       (>= (gn-sir M (+ p 11) IF-B) 0) (<= (gn-sir M (+ p 11) IF-B) 2047)
       (> (gn-sir M (+ p 2) IF-A) 0) (> (gn-sir M (+ p 6) IF-B) 0) (> (gn-sir M (+ p 8) IF-A) 0)
       (not= (gn-sir M (+ p 2) IF-A) (gn-sir M (+ p 6) IF-B))
       (not= (gn-sir M (+ p 2) IF-A) (gn-sir M (+ p 8) IF-A))
       (not= (gn-sir M (+ p 6) IF-B) (gn-sir M (+ p 8) IF-A))
       (= (gn-lpos M (gn-sir M (+ p 2) IF-A)) (+ p 2))
       (= (gn-lpos M (gn-sir M (+ p 6) IF-B)) (+ p 9))
       (= (gn-lpos M (gn-sir M (+ p 8) IF-A)) (+ p 25))
       (gn-copy-writer? M (gn-sir M (+ p 17) IF-A)) (gn-copy-shape M p f 0))))
(defn- gn-copy-entry [M :vector-i64 i :i64] :vector-i64
 (if (not (gn-copy? M i)) M
  (let [p (dec i) n (gn-sir M (+ p 4) IF-B) dest (gn-sir M (+ p 11) IF-B)
        M0 (gn-emit M (enc-cmp-i 1 0)) b0 (vector-at M0 MM-CODE-N)
        M1 (-> M0 (gn-emit (enc-bcond (enc-cond-ne) 0)) (gn-emit (enc-cmp-i 8 (* 2 n)))) b1 (vector-at M1 MM-CODE-N)
        M2 (-> M1 (gn-emit (enc-bcond (enc-cond-lo) 0)) (gn-emit (enc-ldr 16 7 312))
                  (gn-emit (enc-ldr 16 16 0)) (gn-emit (enc-sub-i 17 0 1)) (gn-emit (enc-cmp-r 17 16))) b2 (vector-at M2 MM-CODE-N)
        M3 (-> M2 (gn-emit (enc-bcond (enc-cond-hs) 0)) (gn-emit (enc-ldr 16 7 320))
                  (gn-emit (gn-e-addsl 16 16 17 4)) (gn-emit (enc-ldp 17 4 16 0))
                  (gn-mov-imm 16 (+ dest (dec n))) (gn-emit (enc-cmp-r 16 4))) b3 (vector-at M3 MM-CODE-N)
        M4 (-> M3 (gn-emit (enc-bcond (enc-cond-hs) 0)) (gn-emit (enc-cmp-i 4 (dec n)))) b4 (vector-at M4 MM-CODE-N)
        M5 (-> M4 (gn-emit (enc-bcond (enc-cond-ls) 0)) (gn-emit (enc-ldr 2 7 328))
                  (gn-emit (gn-e-addsl 2 2 17 3)) (gn-mov-imm 16 (* 8 dest))
                  (gn-emit (enc-add-r 3 2 16)) (gn-mov-imm 4 n)) loop (vector-at M5 MM-CODE-N)
        M6 (-> M5 (gn-emit (enc-ldr 9 2 0)) (gn-emit (enc-str 9 3 0))
                  (gn-emit (enc-add-i 2 2 8)) (gn-emit (enc-add-i 3 3 8))
                  (gn-emit (enc-subs-i 4 4 1))) branch (vector-at M6 MM-CODE-N)
        M7 (-> M6 (gn-emit (enc-bcond (enc-cond-ne) (- loop branch)))
                  (gn-emit (enc-sub-i 8 8 (* 2 n))) (gn-epilogue) (gn-gs gn-f-dead 0))
        end (vector-at M7 MM-CODE-N)]
   (-> M7 (gn-dot-patch b0 end (enc-cond-ne)) (gn-dot-patch b1 end (enc-cond-lo))
          (gn-dot-patch b2 end (enc-cond-hs)) (gn-dot-patch b3 end (enc-cond-hs))
          (gn-dot-patch b4 end (enc-cond-ls))))))
'''.replace('SHAPE',shape)
# Correct exact writer total: FN+FUEL+3LGET+RT+RET+END=8.
s=s.replace('(< (+ p 8) (vector-at M MM-SIR-N))','(< (+ p 7) (vector-at M MM-SIR-N))')
assert g.count(';; one SIR instruction (unreachable')==1;g=g.replace(';; one SIR instruction (unreachable',s+'\n;; one SIR instruction (unreachable',1)
a='OP-FUEL (gn-dot-entry (gn-op-fuel M) i)';assert g.count(a)==1;g=g.replace(a,'OP-FUEL (gn-copy-entry (gn-dot-entry (gn-op-fuel M) i) i)',1)
(w/'41-a64gen-prototype.kotoba').write_text(g);(w/'baseline-41-a64gen.kotoba').write_bytes((r/'seed/41-a64gen.kotoba').read_bytes());parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader')]:shutil.copy2(b/src,w/dst)
shutil.copy2(Path('/private/tmp/amu-same-local-read-20261006/clobber-full-state-loader'),w/'clobber-full-state-loader')
for name in ['build.py','check-ports.py','ports-state.py','resource-proof.py','permanent-regression.py']:(w/name).write_text((b/name).read_text().replace(str(b),str(w)))
(w/'hypothesis.json').write_text(json.dumps({'status':'registered-before-native-build-and-timing','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'hypothesis':'Checked forward affine writes compose an exact closed frameless copy leaf with a closed typed writer. If initial index0, whole source/destination range and all2n remaining charges are valid, copy in original forward scalar order and publish leaf private fuel through original return. Otherwise preserve original loop and partial writes.','prototypeSha256':hashlib.sha256(g.encode()).hexdigest(),'admission':'Exact28quadruples, exact8quadruple closed typed writer, original frameless leaf x0/x1 slots and x8 private fuel, actual same-function labels, n1..2047 destination0..2047','observedOriginalMatmult':'FN4 copy loop46 words per iteration: read15/writecall19/backedgefuel4; no claim these static counts are runtime shares','fullProofRequiredBeforeTiming':'real/test layout, independent forward-copy full supervisor-state oracle including overlapping destinations, invalid handle/range, partial budgets/resources, native field/type/open mutations, observed successful hit/fallback controls, all19 bytes/results/fuel,480/11843 unchanged permanent expectations and fourgen fixedpoint','promotionCriteria':{'acceptedTriples':30,'maxRsdPercent':10,'minImprovementPercent':5,'meanGapExceedsSumSd':True,'sameQuietHostRunnerCSource':True},'productChanged':False,'officialEmbenchScore':False,'authoringException':'New one-off whole-copy algorithm and independent diagnostic/semantic fixtures, no existing AST refactor rule; prototype only.'},indent=2)+'\n');print('PASS prospective copy prototype registration')
