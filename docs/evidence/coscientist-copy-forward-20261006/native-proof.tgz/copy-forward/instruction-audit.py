from pathlib import Path
import json,struct,hashlib
w=Path('/private/tmp/amu-copy-forward-20261006');b=Path('/private/tmp/amu-residual-write-census-20261006');load=lambda p:json.loads(p.read_text());old=load(b/'meta-ports/matmult-int/census.json');new=load(w/'observer/meta-ports/matmult-int/census.json');ob=(b/'meta-ports/matmult-int/native.bin').read_bytes();nb=(w/'ports-2/matmult-int/native.bin').read_bytes()
def region(info,f):
 es=[e for e in info['events'] if e['fn']==f];return (es[0]['firstWord']-1)*4,(es[-1]['afterWord']-1)*4
sa,ea=region(old,4);sz,ez=region(new,4);oa=ob[sa:ea];na=nb[sz:ez];assert len(oa)==55*4;prefix=5*4;assert oa[:prefix]==na[:prefix] and oa[prefix:]==na[-len(oa[prefix:]):]
extra=na[prefix:-len(oa[prefix:])];words=[x[0] for x in struct.iter_unpack('<I',extra)];assert words.count(0xf9000069)==1 and words.count(0xf9400049)==1
store=words.index(0xf9000069);assert words[store-1]==0xf9400049
assert words[store+1:store+4]==[0x91002042,0x91002063,0xf1000484]
assert words[store+4]&0xff00001f==0x54000001
assert words[-2:]==[0xf90004e8,0xd65f03c0]
assert old['functions']['4']['frameBytes']==new['functions']['4']['frameBytes']==0
pa=load(w/'ports-correctness.json');pb=load(Path('/private/tmp/amu-dot-unroll-return-20261006/ports-correctness.json'));changed=[]
for a,z in zip(pa['entries'],pb['entries']):
 assert a['workload']==z['workload'] and a['runs']==z['runs'] and a['fuelTrapReturncode']==z['fuelTrapReturncode'] and a['sourceSha256']==z['sourceSha256']
 if a['nativeSha256']!=z['nativeSha256']:changed.append(a['workload'])
assert changed==['matmult-int','md5sum']
(w/'instruction-audit.json').write_text(json.dumps({'status':'complete-current-native-copy-frame-fuel-fallback-scalar-order-and-19-code-audit','oldCopyWords':len(oa)//4,'newCopyWords':len(na)//4,'addedWords':len(extra)//4,'originalFiveWordPrivateFuelEntryExact':True,'originalFiftyWordFallbackAndReturnTailExact':True,'sourceLoadThenDestinationStoreThenPointerIncrementsThenCounter':True,'originalPrivateFuelPublicationAndReturnExact':True,'originalFrameBytes':0,'changedGuests':changed,'prototypeSha256':hashlib.sha256((w/'41-a64gen-prototype.kotoba').read_bytes()).hexdigest()},indent=2)+'\n');print('PASS original five-word entry,50-word fallback,scalar write order/private fuel and19 parity',flush=True)
