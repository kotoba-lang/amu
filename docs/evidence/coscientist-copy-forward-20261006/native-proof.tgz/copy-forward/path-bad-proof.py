from pathlib import Path
import subprocess,os,json,re,struct
w=Path('/private/tmp/amu-copy-forward-20261006');loader=w/'clobber-full-state-loader';env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');images=[]
for label in ['baseline','candidate']:
 q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--','extract-native',str(w/'hand/small'/(label+'.kseed')),'--symbol','copy','--output',str(w/('bad-'+label+'.bin'))],env=env,capture_output=True,text=True);assert q.returncode==0,q.stderr;images.append((label,w/('bad-'+label+'.bin'),int(re.search(r':offset (\d+)',q.stdout).group(1))))
def observe(path,off,args,fuel):
 e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run([str(loader),str(path),str(off),str(len(args)),'aarch64','-',*map(str,args)],env=e,capture_output=True,text=True);return {'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
rows=[]
for h in [-(1<<63),-1,0,1,(1<<63)-1]:
 for i in [0,1,3,-1,(1<<63)-1]:
  for fuel in [1,2,3,7,(1<<53)-1]:
   obs={label:observe(path,off,[h,i],fuel) for label,path,off in images};assert obs['baseline']==obs['candidate'],(h,i,fuel,obs);success=i==3
   assert (obs['candidate']['exit']==0)==success,(h,i,fuel,obs)
   if success:assert re.search(r':result '+str(h)+r'(?:\s|})',obs['candidate']['report']) and f':remaining {fuel-1}' in obs['candidate']['report'],obs
   else:assert f':remaining {fuel}' in obs['candidate']['report'],obs
   assert obs['candidate']['items']==['DIAG_VECTOR_ITEMS 0'];rows.append({'handle':h,'i':i,'fuel':fuel,**obs})
(w/'bad-handle-proof.json').write_text(json.dumps({'status':'complete125-native-direct-invalid-or-unused-handle-private-fuel-states','comparisons':len(rows),'runs':rows},indent=2)+'\n');print('PASS125 invalid/unused direct handle states',flush=True)
hand=json.loads((w/'hand-proof.json').read_text());rows=[]
for name in ['small','overlap','wide','short-dest','short-source']:
 a=next(x for x in hand['images'] if x['variant']==name);d=w/'hand'/name;raw=(d/'candidate.bin').read_bytes();words=list(struct.iter_unpack('<I',raw));loc=[j for j,x in enumerate(words) if x[0]==0xf9000069];assert len(loc)==1;bad=bytearray(raw);bad[loc[0]*4:loc[0]*4+4]=(0xd4207aa0).to_bytes(4,'little');sent=d/'hit-sentinel.bin';sent.write_bytes(bad);off=a['images']['candidate']['offset'];n=a['trip'];full=a['length']>=a['dest']+n
 for i,fuel,expect in [(0,16777216,full),(0,2*n+2,full),(0,2*n+1,False),(n,16777216,False),(1,16777216,False),(-1,16777216,False)]:
  normal=observe(d/'candidate.bin',off,[i,0,0],fuel);diagnostic=observe(sent,off,[i,0,0],fuel)
  if expect:assert normal['exit']==0 and diagnostic['exit']!=0 and normal!=diagnostic,(name,i,fuel,normal,diagnostic)
  else:assert normal==diagnostic,(name,i,fuel,normal,diagnostic)
  rows.append({'variant':name,'i':i,'fuel':fuel,'expectedActualStoreHit':expect,'normal':normal,'diagnostic':diagnostic})
(w/'path-proof.json').write_text(json.dumps({'status':'complete30-actual-native-store-hit-and-fallback-controls','controls':len(rows),'neverTimed':True,'runs':rows},indent=2)+'\n');print('PASS30 actual store-hit/fallback controls',flush=True)
