from pathlib import Path
import subprocess,os,re,json,hashlib,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-copy-forward-20261006');b=Path('/private/tmp/amu-dot-unroll-return-20261006');MIN=-(1<<63);MAX=(1<<63)-1;wrap=lambda v:(v+(1<<63))%(1<<64)-(1<<63);vals=[MIN,MAX,-1,0,1,7,-3,9,11,37,-99,47,67,-101,127,257];rows=[];images=[]
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
variants=[('one',1,1,2),('small',3,3,8),('same',3,0,8),('overlap',8,1,10),('short-dest',8,5,10),('short-source',8,0,4),('zero-length',3,0,0),('twenty',20,20,42),('original',800,800,2001),('wide',2047,2047,4094),('trip-refuse',2048,0,2048),('dest-refuse',3,2048,2051),('dest-negative',3,-1,4)]
for name,n,dest,length in variants:
 d=w/'hand'/name;d.mkdir(parents=True,exist_ok=True);src=d/'source.kotoba';count=min(length,len(vals))
 src.write_text('(ns copy-proof.'+name+' (:export [run copy]))\n(defn- put [v :vector-i64 i :i64 x :i64] :vector-i64 (vector-assoc! v i x))\n(defn copy [v :vector-i64 i :i64] :vector-i64\n (if (= i '+str(n)+') v (copy (put v (+ '+str(dest)+' i) (vector-at v i)) (+ i 1))))\n(defn run [i :i64 a :i64 z :i64] :i64\n (let [v0 (vector-alloc '+str(length)+')\n'+''.join('       v'+str(j+1)+' (vector-assoc! v'+str(j)+' '+str(j)+' '+str(value)+')\n' for j,value in enumerate(vals[:count]))+'       v (copy v'+str(count)+' i)] (vector-count v)))\n')
 paths={};offs={}
 for label,root in [('baseline',b),('candidate',w)]:
  for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(d/(label+'.kseed'))]),('extract',['extract-native',str(d/(label+'.kseed')),'--symbol','run','--output',str(d/(label+'.bin'))])]:
   q=subprocess.run([str(w/'kexe-loader'),str(root/'seed-4.bin'),(root/'seed-4.offset').read_text().strip(),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,label,stage,q.stdout,q.stderr)
  offs[label]=int(re.search(r':offset (\d+)',q.stdout).group(1));paths[label]=d/(label+'.bin')
 hitword=0xf9000069;countfast=lambda p:sum(x[0]==hitword for x in struct.iter_unpack('<I',p.read_bytes()));added=countfast(paths['candidate'])-countfast(paths['baseline']);accepted=1<=n<=2047 and 0<=dest<=2047
 assert added==int(accepted),(name,accepted,added)
 images.append({'variant':name,'trip':n,'dest':dest,'length':length,'accepted':accepted,'extraForwardScalarStoreWords':added,'sourceSha256':hashlib.sha256(src.read_bytes()).hexdigest(),'images':{label:{'sha256':hashlib.sha256(paths[label].read_bytes()).hexdigest(),'offset':offs[label]} for label in paths}})
 for ix in sorted(set([0,1,n-1,n,n+1,-1,MIN,MAX])):
  for fuel in sorted(set([1,2,3,4,5,6,2*n,2*n+1,2*n+2,2*n+3,16777216,(1<<53)-1])):
   vector=[0]*length;vector[:count]=vals[:count];answer=None;remaining=fuel-1;private=remaining;trap=False
   if private==0:trap=True;remaining=0
   else:
    private-=1;i=ix
    for steps in range(length+4):
     if i==n:answer=length;remaining=private;break
     if not 0<=i<length:trap=True;break
     value=vector[i]
     if private==0:trap=True;remaining=0;break
     private-=1;j=wrap(dest+i)
     if not 0<=j<length:trap=True;break
     vector[j]=value
     if private==0:trap=True;remaining=0;break
     private-=1;i=wrap(i+1)
    else:raise AssertionError(('unbounded oracle',name,ix,fuel))
   obs={}
   for label in paths:
    e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'clobber-full-state-loader'),str(paths[label]),str(offs[label]),'3','aarch64','-',str(ix),'0','0'],env=e,capture_output=True,text=True)
    obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
    assert (q.returncode==0)==(answer is not None),(name,label,ix,fuel,answer,q.stdout,q.stderr[-200:])
    if answer is not None:assert re.search(r':result '+str(answer)+r'(?:\s|})',q.stdout),(name,label,answer,q.stdout)
    assert f':remaining {remaining}' in q.stdout,(name,label,ix,fuel,remaining,q.stdout)
    expected=['DIAG_VECTOR_ITEMS '+str(length)+(' '+' '.join(map(str,vector)) if length else '')]
    assert obs[label]['items']==expected,(name,label,ix,fuel,expected[0][:200],obs[label]['items'][:1])
   assert obs['baseline']==obs['candidate'],(name,ix,fuel,obs);rows.append({'variant':name,'i':ix,'fuel':fuel,'expected':answer,'remaining':remaining,**obs})
 print('PASS independent original-forward-order copy fullstate',name,flush=True)
(w/'hand-proof.json').write_text(json.dumps({'status':'complete-independent-native-forward-copy-oracle','comparisons':len(rows),'variants':len(variants),'images':images,'runs':rows},indent=2)+'\n');print('PASS',len(rows),'copy full-state oracle comparisons',flush=True)
