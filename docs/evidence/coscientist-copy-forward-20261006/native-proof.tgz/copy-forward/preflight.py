from pathlib import Path
import json,hashlib,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-copy-forward-20261006');b=Path('/private/tmp/amu-dot-unroll-return-20261006');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();g=load(w/'generations.json');assert len(g)==4 and len({x['sha256'] for x in g})==1
for x in g:assert sha(w/f"seed-{x['generation']}.bin")==x['sha256']
counts={};pins={}
for name,n in [('hand-proof.json',1160),('bad-handle-proof.json',125),('ports-state.json',209),('resource-proof.json',38)]:
 v=load(w/name);assert v['comparisons']==n and len(v['runs'])==n;counts[name]=n;pins[name]=sha(w/name)
 for row in v['runs']:assert row['baseline']==row['candidate']
per=load(w/'permanent-regression-proof.json');assert per['fixtures']==480 and per['runs']==11843 and len(per['observations'])==11843;pins['permanent-regression-proof.json']=sha(w/'permanent-regression-proof.json')
guard=load(w/'guard-proof.json');assert guard['copySIRFields']==112 and guard['writerSIRFields']==36 and guard['bothOpenReplacementsRefuse'] and guard['realTestCodeAndLiteralBytesEqual'];assert load(w/'path-proof.json')['controls']==30
ob=load(w/'observer/observer-byte-audit.json');assert len(ob['entries'])==19 and all(x['diagnosticTargetByteIdentical'] for x in ob['entries']);shutil.copyfile(w/'observer/observer-byte-audit.json',w/'observer-byte-audit.json')
for name in ['guard-proof.json','path-proof.json','instruction-audit.json','observer-byte-audit.json','hypothesis.json','41-a64gen-prototype.kotoba']:pins[name]=sha(w/name)
pa=load(w/'ports-correctness.json');pb=load(b/'ports-correctness.json');assert len(pa['entries'])==len(pb['entries'])==19;changed=[]
for x,y in zip(pa['entries'],pb['entries']):
 assert x['workload']==y['workload'] and x['runs']==y['runs'] and x['fuelTrapReturncode']==y['fuelTrapReturncode'] and x['sourceSha256']==y['sourceSha256'];assert sha(w/'ports-2'/x['workload']/'native.bin')==x['nativeSha256']
 if x['nativeSha256']!=y['nativeSha256']:changed.append(x['workload'])
assert changed==['matmult-int','md5sum'];assert (r/'seed/41-a64gen.kotoba').read_bytes()==(w/'baseline-41-a64gen.kotoba').read_bytes();assert sha(w/'41-a64gen-prototype.kotoba')==load(w/'hypothesis.json')['prototypeSha256']
pre={'status':'complete-native-semantic-proof-before-timing','fixedpointGenerations':[1,2,3,4],'originalWorkloads':19,'changedGuests':changed,'freshNativeCounts':counts,'permanentFixtures':480,'permanentNativeExecutions':11843,'proofPins':pins,'fullSupervisorComparisons':1532,'diagnosticPathControls':30,'guardFields':148,'productUnchanged':True,'mayPromote':False,'productGatesAndIntegratedProofStillRequired':True,'promotionPerChangedGuest':'Both changed original workloads must independently meet the unchanged stability and improvement rules. Preserve non-improvement results; do not narrow by benchmark name.','officialEmbenchScore':False};(w/'preflight-audit.json').write_text(json.dumps(pre,indent=2)+'\n');p=w/'timing-package';p.mkdir();hyp=load(w/'hypothesis.json')
for name in changed:
 d=p/name;c=d/'candidate';c.mkdir(parents=True);x=next(z for z in pa['entries'] if z['workload']==name);y=next(z for z in pb['entries'] if z['workload']==name);shutil.copyfile(w/'ports-2'/name/'native.bin',c/'native.bin');shutil.copyfile(b/'ports-2'/name/'native.bin',d/'baseline-native.bin');mf={'workload':name,'sourceSha256':x['sourceSha256'],'baselineSourceSha256':y['sourceSha256'],'nativeSha256':x['nativeSha256'],'offset':x['offset'],'baselineNativeSha256':y['nativeSha256'],'baselineOffset':y['offset'],'compilerGenerationSha256':{str(x['generation']):x['sha256'] for x in g},'hypothesis':hyp['hypothesis'],'sourceHead':hyp['sourceCommit'],'finalPrototypeSha256':sha(w/'41-a64gen-prototype.kotoba')};(c/'manifest.json').write_text(json.dumps(mf,indent=2)+'\n')
for src,name in [(b/'ports-correctness.json','product-proof.json'),(w/'ports-correctness.json','candidate-proof.json'),(w/'preflight-audit.json','preflight.json'),(w/'generations.json','generations.json')]:shutil.copyfile(src,p/name)
for name in pins:shutil.copyfile(w/name,p/name)
for name in ['comparison-matrix.json','paired-timing-spec.json']:shutil.copyfile(r/'bench/embench'/name,p/name)
shutil.copyfile('/private/tmp/amu-context-call-20261005/measure-native-candidate-v2.py',p/'measure-native-candidate-v2.py')
s=(b/'remote-timing.py').read_text().replace('amu-zebulun-dot-unroll-return-20261006','amu-zebulun-copy-forward-20261006').replace("pre['fullSupervisorComparisons']==2786","pre['fullSupervisorComparisons']==1532").replace("len(pre['changedGuests'])==1","len(pre['changedGuests'])==2").replace('Current qualified dominated same-local read product','Current qualified guarded whole-dot direct-return product');(w/'remote-timing.py').write_text(s)
print('PASS1532fullstate,30path,148fields,480/11843native and19 frozen before timing BOTH changed guests',flush=True)
