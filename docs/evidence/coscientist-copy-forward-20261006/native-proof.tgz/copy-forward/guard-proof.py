from pathlib import Path
import json,importlib.util,os,subprocess,re,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-copy-forward-20261006');sp=importlib.util.spec_from_file_location('m',w/'permanent-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
T=json.loads((w/'template.json').read_text());values={'n':3,'dest':1,'writer':'cg_writer','head':'cg_head','body':'cg_body','exit':'cg_exit'}
m.fx('cg_writer',3,3,[('FUEL',),('LABEL','cg_entry'),('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('RET',0)])
m.fx('cg_copy',2,2,[tuple([x[0][3:]]+[values.get(a,a) for a in x[1:]]) for x in T[1:-1]])
sentinel=next(x for x in m.FIX if x[0]=='ht_cold_control');m.FIX.append(('cg_cold_sentinel',*sentinel[1:]));fns,labels,lits,sir,frec=m.layout_tables();f=fns['cg_copy'];target=fns['cg_writer'];p=next(j for j,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==f);tp=next(j for j,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==target);assert len(T)==28 and next(x for x in frec if x[0]==f)[-1]==4
bases=[m.C['MM-FN-BASE']+ff*m.C['MM-FN-W'] for ff in [f,target]];types='(defn- t-copy-types [M :vector-i64] :vector-i64\n (-> M '+' '.join('(t-put '+str(base+m.C['FF-PT0']+j)+' '+('TY-VEC' if j==0 else 'TY-I64')+')' for base,n in zip(bases,[2,3]) for j in range(n))+' '+' '.join('(t-put '+str(base+m.C['FF-RTYPE'])+' TY-VEC)' for base in bases)+'))\n'
metas=[base+m.C[c]+delta for base,n in zip(bases,[2,3]) for c,delta in [('FF-SIR',0),('FF-NPARAMS',0),('FF-NSLOTS',0),('FF-DEPTH',0),('FF-RTYPE',0)]+[('FF-PT0',j) for j in range(n)]]
probe='''(defn- t-copy-mut [M :vector-i64 at :i64 want :bool] :bool
 (let [old (vector-at M at) MM (t-put M at (inc old)) got (gn-copy? MM '''+str(p+1)+''') restore (t-put MM at old)] (= got want)))
(defn- t-copy-fields [M :vector-i64 k :i64 start :i64 total :i64 writer :bool] :bool
 (if (= k total) true
  (let [off (quot k 4) fld (rem k 4) at (+ MM-SIR-BASE (* (+ start off) MM-SIR-W) fld)
        want (and (not writer) (= fld IF-B) (or (= off 4) (= off 11)))]
   (and (t-copy-mut M at want) (t-copy-fields M (inc k) start total writer)))))
(defn- t-copy-open [M :vector-i64 f :i64] :bool
 (let [old (gn-g M gn-g-open) old_n (gn-g M gn-g-open-n)
       set (-> M (gn-gs gn-g-open f) (gn-gs gn-g-open-n 1))
       got (gn-copy? set '''+str(p+1)+''') reset (-> set (gn-gs gn-g-open old) (gn-gs gn-g-open-n old_n))] (not got)))
(defn probe [] :i64
 (let [M0 (t-copy-types (t-load (t-init))) M1 (gn-run M0) M (gn-op-fn M1 '''+str(p)+' '+str(f)+''' 2)
       accepted (gn-copy? M '''+str(p+1)+''')
       fields (t-copy-fields M 0 '''+str(p)+''' 112 false)
       writer (t-copy-fields M 0 '''+str(tp)+''' 36 true)
       meta (and '''+' '.join('(t-copy-mut M '+str(a)+' false)' for a in metas)+''')
       open (and (t-copy-open M '''+str(f)+''') (t-copy-open M '''+str(target)+'''))
       labs (and '''+' '.join('(t-copy-mut M (+ (vector-at M gn-cell) gn-a-lp '+str(labels[x])+') false)' for x in ['cg_head','cg_body','cg_exit','cg_entry'])+''')
       local_old (gn-g M (+ gn-a-sreg 1)) local (not (gn-copy? (gn-gs M (+ gn-a-sreg 1) 0) '''+str(p+1)+''')) restore (gn-gs M (+ gn-a-sreg 1) local_old)]
  (if (and accepted fields writer meta open labs local) (let [o (t-out "COPY_GUARDS PASS\\n")] 0) 1)))
'''
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');chunks=[]
for label,real in [('guard-real',True),('guard-test',False)]:
 unit=m.kotoba(real);needle='(t-put (t-du-types MR 1) ';assert unit.count(needle)==1;unit=unit.replace(needle,'(t-put (t-copy-types (t-du-types MR 1)) ',1)
 source='\n'.join((r/x).read_text().replace('(:export [main])','(:export [main probe])') if x=='seed/00-ns.kotoba' else (r/x).read_text() for x in ['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'])+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+types+unit+probe
 (w/(label+'.kotoba')).write_text(source)
 for stage,args in [('compile',['compile',str(w/(label+'.kotoba')),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-300:],q.stderr)
 off=re.search(r':offset (\d+)',q.stdout).group(1);q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'.stdout')).write_text(q.stdout);assert q.returncode==0,(label,q.stdout[-100:],q.stderr);chunks.append(m.blob_from(q.stdout))
 if real:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--','extract-native',str(w/(label+'.kseed')),'--symbol','probe','--output',str(w/'guard-probe.bin')],env=env,capture_output=True,text=True);assert q.returncode==0,q.stderr;off=re.search(r':offset (\d+)',q.stdout).group(1);q=subprocess.run([str(w/'kexe-loader'),str(w/'guard-probe.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/'guard-probe.stdout').write_text(q.stdout+q.stderr);assert q.returncode==0 and 'COPY_GUARDS PASS' in q.stdout,(q.returncode,q.stdout,q.stderr)
a,b=chunks;short=min(len(a[0]),len(b[0]));assert a[1]==b[1] and a[0][:short]==b[0][:short] and not any(a[0][short:]+b[0][short:]) and abs(len(a[0])-len(b[0]))<=7
(w/'guard-fixture.bin').write_bytes(b[0]);(w/'guard-proof.json').write_text(json.dumps({'status':'complete-native-copy-writer-SIR-mutations-metadata-open-label-and-independent-layout-proof','copySIRFields':112,'writerSIRFields':36,'typeAndMetadataRefusals':len(metas),'foreignLabelRefusals':4,'bothOpenReplacementsRefuse':True,'invalidLocalRegisterRefuses':True,'realTestCodeAndLiteralBytesEqual':True,'realTestFnOffsetsEqual':True,'prototypeSha256':hashlib.sha256((w/'41-a64gen-prototype.kotoba').read_bytes()).hexdigest()},indent=2)+'\n');print('PASS112copy/36writer fields,',len(metas),'metadata,4labels,both open/local guards and real/testlayout',flush=True)
