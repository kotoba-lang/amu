The native rebuild previously embedded an older seed, and Kotoba/C comparisons mixed original Embench bodies with simplified kernels. This branch pins rebuild inputs, provides complete original-active-profile ports for all19 workloads, and compares native selfhost output with unchanged C bodies on one recorded host.

The compiler now composes an exact closed typed forward-copy loop and its typed writer. Runtime guards validate initial index0, handle, both complete vector ranges and all private fuel before any item mutation. Success copies each source load immediately followed by its destination store, preserving overlapping forward-copy propagation, and publishes through the original leaf return. Failed guards retain the byte-exact original loop, including partial writes and traps. No benchmark-name selection, result cache, new capabilities/budgets or product host fallback is introduced.

Qualified source: `5869e7ee14002a520aa77d5a5cdc41e76e7f03ea`. Fresh rotating previous-product/candidate/C comparisons on zebulun Apple M4 qualify BOTH changed original workloads under unchanged criteria:

| Original workload | Previous product | Candidate | C | Time reduction | Candidate/C |
| --- | ---: | ---: | ---: | ---: | ---: |
| matmult-int | 4.409318 µs | 3.221540 µs | 0.920910 µs | 26.937912% | 3.498214x |
| md5sum | 12.374915 µs | 11.005772 µs | 2.495772 µs | 11.063853% | 4.409767x |

Each has30 accepted triples (30/32 attempts respectively). Every series remains below10% RSD; both speed ratios exceed1.05 and mean gaps exceed summed SD. The other17 guests remain byte-identical. No new full-suite aggregate or multiplication of historical speedups is claimed.

Validation:

- Fresh all19 native SIR/emission census reproduces the preceding qualified product. Actual matmult FN4 and MD5 FN11 retain their original five-word private entry and50-word fallback/return tail; the added31 words implement guard plus scalar loop with the original fuel publication/return.
- Four identical native compiler generations:831000 B, SHA256 `4c36b9893d7efc6f527d262dfd6c9b957988e5d6b4a759eed5d37339b6a96755`.
- Before timing:1532 full supervisor-state comparisons,148 copy/writer field mutations,15 metadata/four-label/open/local refusals,30 actual store-hit/fallback controls, real/test-layout equivalence, observer/quiet19 byte parity and unchanged480 fixtures/11843 native executions.
- Adoption:494 fixtures/14019 native executions. Original480/11843 tables and expectations remain an exact prefix. Independent observable-value oracles cover overlapping/wide/refused copies, invalid probes, partial fuel, zero trips and extreme integers. Normal native unit reproduces the independently executed bytes before the reviewed generated golden update.
- ERR/G1-G5 pass with current-source native generations2/3/4 recorded; seed0 is not bootstrap stage0. Existing refusals and bootstrap inventory remain unchanged. Initial authoring/generator refusals and task-only cache cleanup are retained as evidence.
- Three committed-source integrated generations reproduce all162 objects (117 frontend), containers, native code and commands. Executable:6109176 B, SHA256 `b6fb0799a809b10694c95a3ab119fd397eb5509046ee565089d4527da7dae76c`. Generation3 checks/compiles all19 original sources and emits exactly the measured guests and offsets.
- All391 check/391 compile/891 export classifications match the prior product, along with391 normalized full checker messages and1780 native output/status files. Existing compile/export gaps remain.

Definition identity content addresses normalized typed implementations and dependencies. Native DefCID/artifact/result caching remains unconnected. These native structural proofs freshly execute every body. New algorithms and independent semantic oracles use the documented one-off authoring exception; generated tests use the authoritative fixture generator. Python/C remain bootstrap proof and measurement tools. Rung records, bin/amu selection and wire20 grants remain unchanged.

These are aligned original native body measurements, not official Embench scores. C-or-better across all19 and100% own-source release qualification remain unachieved. This PR remains a draft.

Evidence: `docs/coscientist-copy-forward-20261006.md` and `docs/evidence/coscientist-copy-forward-20261006/` preserve the fresh census, prospective registration, failed authoring attempts, source/generated expectations, native proofs, both raw timing/C receipts, gates, complete hashed input snapshot, three integrated generations, actual per-case results and checksums. Earlier qualified and rejected experiments remain archived with their historical decisions.

Next: refresh all19 current native-versus-C measurements to rank remaining gaps, then test pair-load/pair-store copying only where forward overlap semantics are proved. It is registered, unimplemented and unmeasured.
