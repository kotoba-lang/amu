"""Bootstrap-only read-only candidate census, not a native optimizer or proof."""
from pathlib import Path
from collections import Counter
import json, hashlib

root = Path('/private/tmp/amu-current19-refresh-20261006')
census_root = Path('/private/tmp/amu-copy-forward-20261006/observer/meta-ports')
rows = []
for name in [e['workload'] for e in json.loads((root/'audit.json').read_text())['rankedRows']]:
    base = census_root/name
    c = json.loads((base/'census.json').read_text())
    sir = {}
    for line in (base/'compile.log').read_text().splitlines():
        if line.startswith('SIR '):
            i,op,a,b,z = map(int,line.split()[1:])
            sir[i] = (op,a,b,z)
    identity = set()
    # Exact uncharged one-argument identity; private labels are allowed.
    for fid,fn in c['functions'].items():
        body = [sir[i] for i in range(fn['start']+1,fn['end']) if sir[i][0] != 9]
        if sir[fn['start']][2] == 1 and body == [(4,0,1,0),(19,0,0,0)]:
            identity.add(int(fid))
    candidates=[]
    for event in c['events']:
        if event['op'] != 'OP-CALL': continue
        i=event['sir']; op,callee,temp,n=sir[i]
        # Count actual returning BL sites only; already inlined/tail calls excluded.
        if n > 7 or not any(int(w,16)&0xfc000000 == 0x94000000 for w in event['words']): continue
        fn=c['functions'][str(event['fn'])]
        labels={}
        for k in range(fn['start']+1,fn['end']):
            if sir[k][0] == 9: labels.setdefault(sir[k][1],[]).append(k)
        p=i+1;seen=set();path=[];ok=False
        for _ in range(16):
            if p in seen or not fn['start'] < p < fn['end']: break
            seen.add(p);o,a,b,z=sir[p];path.append(p)
            if o==19:
                ok=(a==temp and b==0 and z==0);break
            if o==9 and b==0 and z==0: p+=1;continue
            if o==10 and b==0 and z==0 and len(labels.get(a,[]))==1:
                p=labels[a][0];continue
            if o==13 and a in identity and b==temp and z==1: p+=1;continue
            break
        if ok and path != [i+1]:
            candidates.append({'fn':event['fn'],'sir':i,'callee':callee,'args':n,'continuation':path,'frameBytes':fn['frameBytes']})
    rows.append({'workload':name,'identityFunctions':sorted(identity),'candidateReturningCalls':len(candidates),'candidateFunctions':len(set(e['fn'] for e in candidates)),'sites':candidates,'censusSha256':hashlib.sha256((base/'census.json').read_bytes()).hexdigest()})
out={'status':'read-only-observed-candidate-census','productChanged':False,'nativeOptimizerImplemented':False,'dynamicProfile':False,'eligibilityNotYetProved':True,'maximumContinuationSteps':16,'rows':rows}
(root/'tail-continuation-census.json').write_text(json.dumps(out,indent=2)+'\n')
print([(e['workload'],e['candidateReturningCalls']) for e in rows])
