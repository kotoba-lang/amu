from pathlib import Path
import json,hashlib,subprocess,os,socket,statistics,math,time,resource,sys,shutil
root=Path('/private/tmp/amu-zebulun-current19-refresh-20261006');p=root/'package';old=Path('/private/tmp/amu-zebulun-paired-20261005');sys.path.insert(0,str(old/'repo/scripts/seed/image'));from darwin_cpu_idle import snapshot,interval,background_activity
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();load=lambda f:json.loads(f.read_text());spec=load(p/'paired-timing-spec.json');matrix=load(p/'comparison-matrix.json');proof=load(p/'native-proof.json');o=load(old/'measurement-2/results.json');runner=old/'environment/runner';assert socket.gethostname().split('.')[0]==spec['host'];assert sha(runner)==o['runnerSha256']==matrix['runnerSha256'];assert sha(p/'comparison-matrix.json')==spec['matrixSpecSha256']==o['matrixSpecSha256'];assert sha(p/'paired-timing-spec.json')==sha(old/'repo/bench/embench/paired-timing-spec.json');assert len(proof['entries'])==len(spec['entries'])==19
out=root/'measurement';assert not out.exists();out.mkdir();report={'format':'amu.current-native19-refresh/v1','status':'running','sourceHypothesis':load(p/'hypothesis.json'),'host':socket.gethostname(),'specSha256':sha(p/'paired-timing-spec.json'),'matrixSpecSha256':sha(p/'comparison-matrix.json'),'runnerSha256':sha(runner),'clang':o['clang'],'environmentReceiptSha256':sha(old/'measurement-2/results.json'),'performanceMeasured':False,'officialEmbenchScore':False,'ownSource100PercentSelfhostQualified':False,'entries':[],'rows':[]}
def save():(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
def loadavg():return float(subprocess.check_output(['sysctl','-n','vm.loadavg'],text=True).split()[1])
def sample(row,arm,calls,warm,cpu=False):
 u=resource.getrusage(resource.RUSAGE_CHILDREN) if cpu else None;start=snapshot() if cpu else None;d=out/row['workload'];q=subprocess.run([str(runner),'raw' if arm=='Kotoba' else 'dylib',str(d/('native.bin' if arm=='Kotoba' else 'c.dylib')),str(row['offset']) if arm=='Kotoba' else row['cSymbol'],'aarch64',str(row['iterationsPerCall']),str(calls),str(warm),str(matrix['maximumFuel'])],capture_output=True,text=True);assert q.returncode==0,(row['workload'],arm,q.stderr);s=json.loads(q.stdout);assert s['result']==1 and s['calls']==calls and s['warmupCalls']==warm
 if arm=='Kotoba':assert s['contextFuelConsumed']==row['expectedNativeFuelPerCall'],(row['workload'],s)
 if cpu:
  activity=interval(start,snapshot());v=resource.getrusage(resource.RUSAGE_CHILDREN);ns=round(((v.ru_utime+v.ru_stime)-(u.ru_utime+u.ru_stime))*1e9);s['cpuActivityEnvelope']=background_activity(activity,ns,os.cpu_count())
 return s
save()
try:
 for entry in spec['entries']:
  name=entry['workload'];e=next(x for x in o['entries'] if x['workload']==name);n=next(x for x in proof['entries'] if x['workload']==name);control=next(x for x in matrix['entries'] if x['workload']==name);assert n['sourceSha256']==control['expectedSourceSha256']==sha(old/'repo'/control['source']);assert sha(p/name/'native.bin')==n['nativeSha256'];assert sha(old/'measurement-2'/name/'c.dylib')==e['cDylibSha256'];assert e['cSymbol']==entry['cSymbol'] and e['iterationsPerCall']==entry['iterationsPerCall'];d=out/name;d.mkdir();shutil.copy2(p/name/'native.bin',d/'native.bin');shutil.copy2(old/'measurement-2'/name/'c.dylib',d/'c.dylib')
  row={k:v for k,v in e.items() if k not in ['timingSummary','calibratedCalls','acceptedPairs','attemptedPairs','checks']};row.update({'offset':n['offset'],'nativeSha256':n['nativeSha256'],'sourceSha256':n['sourceSha256'],'expectedNativeFuelPerCall':next(x['fuelConsumed'] for x in n['runs'] if x['n']==entry['iterationsPerCall']),'checks':[]});report['entries'].append(row);save()
  for arm in ['Kotoba','C']:
   q=sample(row,arm,2,spec['warmupCalls']);row['checks'].append(q)
  counts={}
  for arm in ['Kotoba','C']:
   assert loadavg()<=spec['maximumLoad'],'host busy before calibration';s=sample(row,arm,3,spec['warmupCalls']);assert s['elapsedNanoseconds']>0;counts[arm]=max(1,round(spec['targetIntervalNs']/(s['elapsedNanoseconds']/3)))
  row['calibratedCalls']=counts;accepted=0;print('START',name,flush=True)
  for pair in range(spec['maximumPairAttempts']):
   group=[]
   for arm in (['Kotoba','C'] if pair%2==0 else ['C','Kotoba']):
    before=loadavg();s=sample(row,arm,counts[arm],spec['warmupCalls'],True);after=loadavg();reasons=[]
    if max(before,after)>spec['maximumLoad']:reasons.append('host-load')
    if s['elapsedNanoseconds']<spec['minimumIntervalNs']:reasons.append('short-interval')
    if s['cpuActivityEnvelope']['estimatedBackgroundIdlePercent']<spec['minimumBackgroundIdlePercent']:reasons.append('background-cpu')
    z={**s,'workload':name,'arm':arm,'pair':pair,'iterationsPerCall':row['iterationsPerCall'],'loadBefore':before,'loadAfter':after,'recordedEpoch':time.time(),'accepted':False,'rejectionReasons':reasons};group.append(z);report['rows'].append(z);save()
   ok=all(not x['rejectionReasons'] for x in group)
   for x in group:x['accepted']=ok
   accepted+=int(ok);row['acceptedPairs']=accepted;row['attemptedPairs']=pair+1;save()
   if accepted==spec['samplesPerArm']:break
  assert accepted==spec['samplesPerArm'],'insufficient quiet pairs';summary={}
  for arm in ['Kotoba','C']:
   xs=[z['elapsedNanoseconds']/(z['calls']*z['iterationsPerCall']) for z in report['rows'] if z['workload']==name and z['arm']==arm and z['accepted']];mu=statistics.mean(xs);sd=statistics.stdev(xs);summary[arm]={'meanNsPerBody':mu,'sdNs':sd,'relativeSd':sd/mu,'samples':len(xs)}
  k=summary['Kotoba'];c=summary['C'];stable=max(k['relativeSd'],c['relativeSd'])<=spec['maximumRelativeSd'];summary.update({'KotobaTimeOverC':k['meanNsPerBody']/c['meanNsPerBody'],'stable':stable,'separatedCOrBetter':stable and c['meanNsPerBody']/k['meanNsPerBody']>=spec['minimumSpeedup'] and c['meanNsPerBody']-k['meanNsPerBody']>c['sdNs']+k['sdNs']});row['timingSummary']=summary;save();print('FINISH',name,json.dumps(summary),flush=True)
 report['performanceMeasured']=True;report['status']='complete-provisional-current19-timing';report['geometricMeanKotobaTimeOverC']=math.exp(statistics.mean(math.log(e['timingSummary']['KotobaTimeOverC']) for e in report['entries']));report['allWorkloadsSeparatedCOrBetter']=all(e['timingSummary']['separatedCOrBetter'] for e in report['entries'])
except Exception as e:report['status']='failed';report['failure']={'type':type(e).__name__,'message':str(e)};raise
finally:save()
print('PASS terminal fresh all19 pairs; official and goal qualification remain separate',flush=True)
