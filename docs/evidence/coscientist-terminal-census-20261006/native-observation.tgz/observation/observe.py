from pathlib import Path
import json,os,re,subprocess,hashlib
w=Path('/private/tmp/amu-terminal-census-20261006');b=Path('/private/tmp/amu-small-tail-frame-20261006');e=next(x for x in json.loads((b/'ports-correctness.json').read_text())['entries'] if x['workload']=='statemate');rows=[]
for n in [0,1,2,17,32]:
 for fuel in [1,2,64,805,806,16777216]:
  obs={};counts={}
  for label,p,off,loader in [('baseline',b/'ports-2/statemate/native.bin',e['offset'],w/'diagnostic-loader'),('diagnostic',w/'statemate.bin',int((w/'statemate.offset').read_text()),w/'diagnostic-loader'),('original-supervisor',b/'ports-2/statemate/native.bin',e['offset'],b/'full-state-loader')]:
   env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');env.pop('KEXE_COMMAND',None);q=subprocess.run([str(loader),str(p),str(off),'1','aarch64','-',str(n)],env=env,capture_output=True,text=True);(w/f'run-{n}-{fuel}-{label}.log').write_text(q.stdout+q.stderr);assert ':fuel ' in q.stdout,(n,fuel,label,q.stdout,q.stderr);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)};counts[label]={int(k):int(v) for k,v in re.findall(r'^DIAG_COUNT (\d+) (\d+)$',q.stderr,re.M)}
  assert obs['baseline']==obs['diagnostic']==obs['original-supervisor'],(n,fuel,obs);assert not counts['baseline'];rows.append({'n':n,'fuel':fuel,'observation':obs['baseline'],'counts':counts['diagnostic']});print('PASS exact state and diagnostic counts',n,fuel,flush=True)
(w/'observations.json').write_text(json.dumps({'status':'complete-original-statemate-diagnostic-fullstate-parity','comparisons':len(rows),'rows':rows,'officialEmbenchScore':False,'performanceMeasurement':False},indent=2)+'\n')
