from pathlib import Path
import subprocess,json
w=Path('/private/tmp/amu-terminal-census-20261006');base=(w/'calibration.kotoba').read_text();script=(w/'calibrate.py').read_text();rows=[]
for name,source,eq_reads in [('changed-tail',base.replace('(finish v)))','(finish [42])))'),2),('changed-before-read',base.replace('(do (vector-assoc! v 0 (+ (vector-at v 0) 1)) (finish v)))','(let [v2 [42]] (do (vector-assoc! v2 0 (+ (vector-at v2 0) 1)) (finish v2))))'),1)]:
 p=w/(name+'.kotoba');p.write_text(source);s=script.replace("w/'calibration.kotoba'",'w/'+repr(name+'.kotoba')).replace("arm+'-calibration", "arm+'-"+name).replace("f'calibration-", "f'"+name+'-').replace("w/'calibration-proof.json'",'w/'+repr(name+'-proof.json'))
 if name=='changed-tail':s=s.replace("str(n+1 if n<-1 else n+2)","str(43)").replace('1 if n<-1 else 2','2')
 else:s=s.replace("str(n+1 if n<-1 else n+2)","str(44)").replace('1 if n<-1 else 2','2')
 s=s.replace('3:1,4:2,5:1','3:1,4:'+str(eq_reads)+',5:0');(w/(name+'.py')).write_text(s);q=subprocess.run(['python3',str(w/(name+'.py'))],capture_output=True,text=True);(w/(name+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,q.stdout,q.stderr);rows.append({'control':name,'proof':json.loads((w/(name+'-proof.json')).read_text())});print('PASS false-equality control',name,flush=True)
(w/'false-equality-controls.json').write_text(json.dumps({'status':'complete-independent-different-tail-and-read-handles','cases':10,'rows':rows},indent=2)+'\n')
