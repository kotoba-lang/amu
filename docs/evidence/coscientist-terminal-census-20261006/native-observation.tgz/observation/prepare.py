from pathlib import Path
import json,shutil,hashlib,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-terminal-census-20261006');b=Path('/private/tmp/amu-small-tail-frame-20261006');g=(r/'seed/41-a64gen.kotoba').read_text();assert g==(b/'41-a64gen-prototype.kotoba').read_text();(w/'baseline-41-a64gen.kotoba').write_text(g)
def rep(a,z):
 global g
 assert g.count(a)==1,(a,g.count(a));g=g.replace(a,z,1)
helper=''';; One-off diagnostic context extension at400; never production ABI.
;; Preserve x14..17 and NZCV around counters; x7 is already current here.
(defn- gn-profile-begin [M :vector-i64 rv :i64] :vector-i64
 (let [M0 (-> M (gn-emit (enc-stp-pre 14 15 31 -16))
                   (gn-emit (enc-stp-pre 16 17 31 -16))
                   (gn-emit 0xd53b4210) (gn-emit (enc-stp-pre 16 31 31 -16)))]
  (-> (cond (= rv 16) (gn-emit M0 (enc-ldr 15 31 16))
            (= rv 17) (gn-emit M0 (enc-ldr 15 31 24))
            (= rv 14) (gn-emit M0 (enc-ldr 15 31 32))
            (= rv 15) (gn-emit M0 (enc-ldr 15 31 40))
            :else (gn-mov M0 15 rv))
      (gn-emit (enc-ldr 14 7 400)))))
(defn- gn-profile-inc [M :vector-i64 slot :i64] :vector-i64
 (-> M (gn-emit (enc-ldr 17 14 (* slot 8)))
       (gn-emit (enc-add-i 17 17 1)) (gn-emit (enc-str 17 14 (* slot 8)))))
(defn- gn-profile-end [M :vector-i64] :vector-i64
 (-> M (gn-emit (enc-ldp-post 16 31 31 16)) (gn-emit 0xd51b4210)
       (gn-emit (enc-ldp-post 16 17 31 16)) (gn-emit (enc-ldp-post 14 15 31 16))))
(defn- gn-profile-entry [M :vector-i64 f :i64 np :i64] :vector-i64
 (let [M0 (gn-gs M 14 f) slot (* f 8)
       vec (and (= np 1) (= (gn-fnf M f FF-PT0) TY-VEC))]
  (-> M0 (gn-profile-begin 0) (gn-profile-inc slot)
      (cond-> (not vec) (gn-mov-imm 15 0))
      (gn-emit (enc-str 15 14 (* (+ slot 7) 8))) (gn-profile-end))))
(defn- gn-profile-read [M :vector-i64 rv :i64] :vector-i64
 (let [slot (* (gn-g M 14) 8)]
  (-> M (gn-profile-begin rv) (gn-profile-inc (inc slot))
      (gn-emit (enc-str 15 14 (* (+ slot 6) 8)))
      (gn-emit (enc-ldr 16 14 (* (+ slot 7) 8)))
      (gn-emit (enc-cmp-r 15 16)) (gn-emit (enc-bcond (enc-cond-ne) 4))
      (gn-profile-inc (+ slot 4)) (gn-profile-end))))
(defn- gn-profile-write [M :vector-i64 rv :i64] :vector-i64
 (-> M (gn-profile-begin rv) (gn-profile-inc (+ (* (gn-g M 14) 8) 2)) (gn-profile-end)))
(defn- gn-profile-tail [M :vector-i64 i :i64] :vector-i64
 (let [slot (* (gn-g M 14) 8)]
  (-> M (gn-profile-begin 0) (gn-profile-inc (+ slot 3))
      (gn-emit (enc-ldr 16 14 (* (+ slot 7) 8)))
      (gn-emit (enc-cmp-r 15 16)) (gn-emit (enc-bcond (enc-cond-ne) 4))
      (gn-profile-inc (+ slot 5)) (gn-profile-end))))
'''
rep('(defn- gn-op-fn2 [',helper+'\n(defn- gn-op-fn2 [')
rep('(gn-gs gn-f-h 0) (gn-vclear) (gn-tree-entry f)', '(gn-gs gn-f-h 0) (gn-vclear) (gn-profile-entry f np) (gn-tree-entry f)')
rep('(defn- gn-op-tail-call [M :vector-i64 f :i64 t :i64 n :i64]', '(defn- gn-op-tail-call [M :vector-i64 i :i64 f :i64 t :i64 n :i64]')
rep('(gn-op-tail-call M f t n)', '(gn-op-tail-call M i f t n)')
rep('(gn-args t 0 n) (gn-ctx) (gn-epilogue)', '(gn-args t 0 n) (gn-ctx) (gn-profile-tail i) (gn-epilogue)')
rep('(gn-ldt t 17 0) (gn-vread rv ri d)', '(gn-ldt t 17 0) (gn-profile-read rv) (gn-vread rv ri d)')
rep('(-> M2 (gn-ctx) (gn-hchk rv 312 320)', '(-> M2 (gn-ctx) (gn-profile-write rv) (gn-hchk rv 312 320)')
(w/'41-a64gen-diagnostic.kotoba').write_text(g);parts=[z.strip() for z in (r/'seed/MANIFEST').read_text().splitlines() if z.strip() and not z.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join(g if p=='seed/41-a64gen.kotoba' else (r/p).read_text() for p in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader')]:shutil.copy2(b/src,w/dst)
source=(r/'tools/kexe_loader.c').read_text();a='  uint64_t code_length;\n};';assert source.count(a)==1;source=source.replace(a,'  uint64_t code_length;\n  uint64_t *diagnostic_counters;\n};',1);a='  struct kexe_context_v11 context;';assert source.count(a)==1;source=source.replace(a,a+'\n  uint64_t diagnostic_counters[4096];',1);a='  int structured_report = getenv("KEXE_STRUCTURED_REPORT") != NULL;';source=source.replace(a,'  shared->context.diagnostic_counters = shared->diagnostic_counters;\n'+a,1);a='  if (child_status == 0 && shared->completed == 1) {';assert source.count(a)==1;source=source.replace(a,'  for (unsigned d = 0; d < 4096; ++d) if (shared->diagnostic_counters[d]) fprintf(stderr, "DIAG_COUNT %u %llu\\n", d, (unsigned long long)shared->diagnostic_counters[d]);\n'+a,1)
source += '\n_Static_assert(offsetof(struct kexe_context_v11, diagnostic_counters) == 400, "diagnostic context pointer");\n';(w/'diagnostic-loader.c').write_text(source)
q=subprocess.run(['clang','-O2','-o',str(w/'diagnostic-loader'),str(w/'diagnostic-loader.c')],capture_output=True,text=True);(w/'loader-build.log').write_text(q.stdout+q.stderr);assert q.returncode==0,q.stderr
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();(w/'hypothesis.json').write_text(json.dumps({'status':'registered-before-native-observation','question':'Do dynamically visited terminal-only functions read the same vector as their one-argument entry and pass it unchanged on terminal transitions?','scope':'Original statemate source; qualified product generator plus counter-only diagnostic emissions, separate extended diagnostic loader. No optimizer/new production ABI/no timing claim.','authoringException':'New one-off diagnostic algorithm and observer schema, not a product mechanical refactor; temporary only.','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'baselineGeneratorSha256':sha(w/'baseline-41-a64gen.kotoba'),'diagnosticGeneratorSha256':sha(w/'41-a64gen-diagnostic.kotoba'),'diagnosticLoaderSha256':sha(w/'diagnostic-loader.c'),'countMeanings':{'0':'function-entry','1':'direct-or-expanded-vector-read','2':'direct-or-expanded-vector-write','3':'genuine-terminal-transfer','4':'read-handle-equals-single-vector-entry-arg','5':'terminal-arg0-equals-single-vector-entry-arg','6':'last-read-handle-value-not-count','7':'single-vector-entry-handle-value-not-count'},'productChanged':False,'performanceMeasured':False,'officialEmbenchScore':False},indent=2)+'\n');print('PASS diagnostic prepared; context field400 asserted; product and source untouched')
