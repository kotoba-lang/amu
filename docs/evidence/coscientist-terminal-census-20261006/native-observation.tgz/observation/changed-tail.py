from pathlib import Path
import json,os,re,subprocess
w=Path('/private/tmp/amu-terminal-census-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');images={}
for arm,seed,offset in [('baseline','seed-0.bin','seed-0.offset'),('diagnostic','diagnostic-seed.bin','diagnostic-seed.offset')]:
 for stage,args in [('compile',['compile',str(w/'changed-tail.kotoba'),'--target','aarch64-macos','--output',str(w/(arm+'-changed-tail.kseed'))]),('extract',['extract-native',str(w/(arm+'-changed-tail.kseed')),'--symbol','batch','--output',str(w/(arm+'-changed-tail.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/seed),(w/offset).read_text().strip(),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(arm+'-changed-tail-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(arm,stage,q.stdout[-300:],q.stderr)
  if stage=='extract':off=int(re.search(r':offset (\d+)',q.stdout).group(1));images[arm]=(w/(arm+'-changed-tail.bin'),off)
rows=[]
for n in [-20,-2,-1,0,17]:
 obs={};c={}
 for arm,(path,off) in images.items():
  env=dict(os.environ,KEXE_STRUCTURED_REPORT='1',KEXE_FUEL='100');q=subprocess.run([str(w/'diagnostic-loader'),str(path),str(off),'1','aarch64','-',str(n)],env=env,capture_output=True,text=True);(w/f'changed-tail-{n}-{arm}.log').write_text(q.stdout+q.stderr);assert q.returncode==0,(n,arm,q.stdout,q.stderr);obs[arm]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M)};c[arm]={int(k):int(v) for k,v in re.findall(r'^DIAG_COUNT (\d+) (\d+)$',q.stderr,re.M)}
 assert obs['baseline']==obs['diagnostic'];assert ':result '+str(43)+' ' in obs['diagnostic']['report'];assert not c['baseline'];counts=c['diagnostic'];bykind={k:sum(v for s,v in counts.items() if s<8192 and s%8==k) for k in range(6)}
 assert bykind=={0:3,1:3,2:2,3:1,4:2,5:0},(n,bykind,counts)
 assert sum(v for s,v in counts.items() if s>=8192)==1,(n,counts)
 rows.append({'n':n,'expectedCounts':bykind,'observation':obs['diagnostic'],'counts':counts});print('PASS independently predicted counts',n,bykind,flush=True)
(w/'changed-tail-proof.json').write_text(json.dumps({'status':'complete-independent-control-count-and-fullstate-oracles','cases':len(rows),'rows':rows},indent=2)+'\n')
