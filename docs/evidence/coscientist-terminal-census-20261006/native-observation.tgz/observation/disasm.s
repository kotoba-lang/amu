.text
.globl _diagnostic
_diagnostic:
.incbin "/private/tmp/amu-terminal-census-20261006/diagnostic-calibration.bin"
