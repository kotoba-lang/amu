from pathlib import Path
import subprocess,os,re,json,hashlib
w=Path('/private/tmp/amu-terminal-census-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');images={}
for label,args in [('compile',['compile',str(w/'seed-unity.kotoba'),'--target','aarch64-macos','--output',str(w/'diagnostic-seed.kseed')]),('extract',['extract-native',str(w/'diagnostic-seed.kseed'),'--symbol','main','--output',str(w/'diagnostic-seed.bin')])]:
 q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-0.bin'),(w/'seed-0.offset').read_text().strip(),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/('seed-'+label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout[-300:],q.stderr)
 if label=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1);(w/'diagnostic-seed.offset').write_text(off+'\n')
e=next(x for x in json.loads((r/'bench/embench/comparison-matrix.json').read_text())['entries'] if x['workload']=='statemate');src=r/e['source'];assert hashlib.sha256(src.read_bytes()).hexdigest()==e['expectedSourceSha256']
for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/'statemate.kseed')]),('extract',['extract-native',str(w/'statemate.kseed'),'--symbol',e['symbol'],'--output',str(w/'statemate.bin')])]:
 q=subprocess.run([str(w/'kexe-loader'),str(w/'diagnostic-seed.bin'),off,'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/('guest-'+label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout[-300:],q.stderr)
 if label=='extract':(w/'statemate.offset').write_text(re.search(r':offset (\d+)',q.stdout).group(1)+'\n')
print('PASS native diagnostic compiler emits unchanged-source instrumented statemate',flush=True)
