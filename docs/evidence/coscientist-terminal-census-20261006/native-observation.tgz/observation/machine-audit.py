from pathlib import Path
import subprocess,struct,json
w=Path('/private/tmp/amu-terminal-census-20261006');s='''.text
.globl _save_restore
_save_restore:
stp x14, x15, [sp, #-16]!
stp x16, x17, [sp, #-16]!
mrs x16, nzcv
stp x16, xzr, [sp, #-16]!
ldp x16, xzr, [sp], #16
msr nzcv, x16
ldp x16, x17, [sp], #16
ldp x14, x15, [sp], #16
''';(w/'save-restore.s').write_text(s);q=subprocess.run(['clang','-c','-arch','arm64',str(w/'save-restore.s'),'-o',str(w/'save-restore.o')],capture_output=True,text=True);assert q.returncode==0,q.stderr;p=(w/'save-restore.o').read_bytes();n=struct.unpack_from('<I',p,16)[0];off=32;code=None
for _ in range(n):
 cmd,size=struct.unpack_from('<II',p,off)
 if cmd==25:
  ns=struct.unpack_from('<I',p,off+64)[0]
  for j in range(ns):
   sec=off+72+j*80
   if p[sec:sec+16].rstrip(b'\0')==b'__text':
    length=struct.unpack_from('<Q',p,sec+40)[0];at=struct.unpack_from('<I',p,sec+48)[0];code=p[at:at+length]
 off+=size
assert code is not None and len(code)==32;seq=[v[0] for v in struct.iter_unpack('<I',code)];prefix=seq[:4];suffix=seq[4:];guest=[v[0] for v in struct.iter_unpack('<I',(w/'statemate.bin').read_bytes())];blocks=[];i=0
while i<len(guest):
 if guest[i:i+4]!=prefix:i+=1;continue
 j=i+4
 while j<len(guest) and guest[j:j+4]!=suffix:j+=1
 assert j<len(guest),(i,j)
 for k in range(i+4,j):
  z=guest[k]
  if (z&0xff000010)==0x54000000:
   imm=(z>>5)&0x7ffff;imm=imm-(1<<19) if imm&(1<<18) else imm;assert (z&15)==1 and i+4<=k+imm<=j,(i,j,k,z,imm)
  assert (z&0xfc000000)!=0x94000000 and z!=0xd65f03c0,(i,k,z)
 blocks.append({'firstByte':i*4,'restoreFirstByte':j*4,'afterByte':(j+4)*4});i=j+4
assert len(blocks)>1000;out={'status':'complete-assembler-independent-save-restore-and-instrumentation-branch-audit','blocks':len(blocks),'expectedSaveWords':[hex(z) for z in prefix],'expectedRestoreWords':[hex(z) for z in suffix],'allConditionalInstrumentationBranchesJoinBeforeFlagRegisterRestore':True,'noReturningCallOrReturnInsideInstrumentation':True,'stackDeltaAtExit':0,'registersPreserved':[14,15,16,17],'flagsPreserved':'NZCV','source':'Clang assembler independent expected encodings compared to actual native diagnostic statemate','regions':blocks};(w/'machine-audit.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',len(blocks),'actual balanced native register/NZCV wrappers and conditional joins')
