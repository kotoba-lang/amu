from pathlib import Path
import importlib.util,subprocess,os,re,json,types,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-constant-index-20261005');sp=importlib.util.spec_from_file_location('fx',r/'scripts/seed/a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
# New handwritten SIR probes: immediate admitted boundaries and fallback shapes.
for k in [-1,0,1,31,4095,4096]:
 for t in [0,4,5,7]:
  name='ki_read_'+str(k).replace('-','m')+'_'+str(t)
  m.fx(name,0,1,[('FUEL',),('FUEL',),('CONST',0,4097),('RT','RT-VECTOR-ALLOC',0,1),('LSET',1,0),('LGET',t,1),('CONST',t+1,k),('RT','RT-VECTOR-AT',t,2),('RET',t)])
  m.run(name,[],0 if k>=0 else 'trap',fuel=2);m.run(name,[],'trap',fuel=1)
 for t in [0,4,5]:
  for value in [0,123]:
   name='ki_write_'+str(k).replace('-','m')+'_'+str(t)+'_'+str(value)
   m.fx(name,0,1,[('FUEL',),('FUEL',),('CONST',0,4097),('RT','RT-VECTOR-ALLOC',0,1),('LSET',1,0),('LGET',t,1),('CONST',t+1,k),('CONST',t+2,value),('RT','RT-VECTOR-ASSOC-IN-PLACE',t,3),('CONST',t+1,k),('RT','RT-VECTOR-AT',t,2),('RET',t)])
   m.run(name,[],value if k>=0 else 'trap',fuel=2);m.run(name,[],'trap',fuel=1)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800');loader=str(w/'kexe-loader');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];chunks=[]
for real in [False,True]:
 prefix='fixture-real' if real else 'fixture-test';src=w/(prefix+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real))
 for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(prefix+'.kseed'))]),('extract',['extract-native',str(w/(prefix+'.kseed')),'--symbol','main','--output',str(w/(prefix+'.bin'))])]:
  p=subprocess.run([loader,str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(prefix+'-'+label+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(label,p.stdout,p.stderr)
  if label=='extract':off=re.search(r':offset (\d+)',p.stdout).group(1)
 p=subprocess.run([loader,str(w/(prefix+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(prefix+'.stdout')).write_text(p.stdout);assert p.returncode==0,p.stderr;chunks.append(p.stdout)
assert m.blob_from(chunks[0])[0].rstrip(b'\0')==m.blob_from(chunks[1])[0].rstrip(b'\0') and m.blob_from(chunks[0])[1]==m.blob_from(chunks[1])[1]
d=w/'fixture-run/unit/41-a64gen';d.mkdir(parents=True,exist_ok=True);(d/'stdout').write_text(chunks[1]);os.environ['SEED_BUILD']=str(w/'fixture-run');original=m.subprocess.run

def run(args,**kw):
 if args[:2]==['zsh',m.R+'/scripts/seed/unit.sh']:return types.SimpleNamespace(returncode=0,stdout='native experimental fixture emitter already verified; byte golden untouched',stderr='')
 return original(args,**kw)
m.subprocess.run=run;assert m.runs(False)==0
blob,fns=m.blob_from(chunks[1]);names=[f[0] for f in m.FIX];audit={}
for k in [0,1,31,4095]:
 for t in [0,4,5]:
  name='ki_read_'+str(k)+'_'+str(t);f=names.index(name)+1;end=fns.get(f+1,int(re.search(r'words (\d+)',chunks[1]).group(1))*4);words=struct.unpack('<'+'I'*((end-fns[f])//4),blob[fns[f]:end]);cmp=0xf100021f+(k<<10)
  exact=sum(words[j]==cmp and words[j+1]==0x54000048 for j in range(len(words)-1));assert exact==1,(name,exact)
  audit[name]={'exactUnsignedLengthGtImmediateAndBranch':exact,'bytes':end-fns[f]}
(w/'fixture-proof.json').write_text(json.dumps({'runs':len(m.RUNS),'fixtures':len(m.FIX),'realTestLayoutIdentical':True,'instructionAudit':audit},indent=2)+'\n');print('PASS exact checked-index instruction audits',flush=True)
