from pathlib import Path
import hashlib,json,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-constant-index-20261005');old=(r/'seed/41-a64gen.kotoba').read_text();g=old
anchor=';; (vector-at v i), v = temp t, i = temp t+1 (t <= 5)'
helper=''';; A known index 0..4095 needs no temporary materialization: length > index
;; unsigned is exactly the original index < length check. Bounds trap stays.
(defn- gn-vidx-k [M :vector-i64 index :i64] :vector-i64
  (-> M
      (gn-emit (enc-ldp 17 16 16 0))
      (gn-emit (enc-cmp-i 16 index))
      (gn-emit (enc-bcond 8 2))
      (gn-emit (gn-e-udf))
      (gn-emit (enc-ldr 16 7 328))
      (gn-emit (enc-add-i 17 17 index))))
'''
assert g.count(anchor)==1;g=g.replace(anchor,helper+anchor)
a='''  (let [M1 (gn-pin M (inc t))
        ri (gn-pinned M1 (inc t))'''
b='''  (let [k (gn-dv M (inc t))
        known (and (gn-isk M (inc t) gn-k-const) (>= k 0) (<= k 4095))
        M1 (if known M (gn-pin M (inc t)))
        ri (if known 0 (gn-pinned M1 (inc t)))'''
assert g.count(a)==1;g=g.replace(a,b)
a='(gn-hchk rv 312 320) (gn-vidx ri) (gn-emit (gn-e-ldrr d 16 17 1))'
b='(gn-hchk rv 312 320) (cond-> known (gn-vidx-k k) (not known) (gn-vidx ri)) (gn-emit (gn-e-ldrr d 16 17 1))'
assert g.count(a)==1;g=g.replace(a,b)
a='''  (let [M1 (-> M (gn-pin t) (gn-pin (inc t)))
        M2'''
b='''  (let [k (gn-dv M (inc t))
        known (and (gn-isk M (inc t) gn-k-const) (>= k 0) (<= k 4095))
        M1 (cond-> (gn-pin M t) (not known) (gn-pin (inc t)))
        M2'''
assert g.count(a)==1;g=g.replace(a,b)
a='ri (gn-pinned M2 (inc t))';b='ri (if known 0 (gn-pinned M2 (inc t)))';assert g.count(a)==1;g=g.replace(a,b)
a='(gn-hchk rv 312 320) (gn-vidx ri) (gn-emit (gn-e-strr3 rx 16 17))'
b='(gn-hchk rv 312 320) (cond-> known (gn-vidx-k k) (not known) (gn-vidx ri)) (gn-emit (gn-e-strr3 rx 16 17))'
assert g.count(a)==1;g=g.replace(a,b)
(w/'41-a64gen-prototype.kotoba').write_text(g)
files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')]
u=''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files);(w/'seed-unity.kotoba').write_text(u);(w/'seed-unity.kotoba.sha256').write_text(hashlib.sha256(u.encode()).hexdigest()+'\n')
for ext in ['bin','offset']:shutil.copyfile(Path('/private/tmp/amu-sign-wrapper-20261005')/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile('/private/tmp/amu-sign-wrapper-20261005/kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['check-ports.py','bulk-state.py']:
 s=Path('/private/tmp/amu-sign-wrapper-20261005',name).read_text().replace("w=pathlib.Path('/private/tmp/amu-sign-wrapper-20261005')","w=pathlib.Path('/private/tmp/amu-constant-index-20261005')") if name=='check-ports.py' else Path('/private/tmp/amu-sign-wrapper-20261005',name).read_text().replace("w=Path('/private/tmp/amu-sign-wrapper-20261005');base=Path('/private/tmp/amu-wrapper-prototype-20261005')","w=Path('/private/tmp/amu-constant-index-20261005');base=Path('/private/tmp/amu-sign-wrapper-20261005')")
 if name=='check-ports.py':s=s.replace("baseline=json.loads(pathlib.Path('/private/tmp/amu-wrapper-prototype-20261005/ports-correctness.json')","baseline=json.loads(pathlib.Path('/private/tmp/amu-sign-wrapper-20261005/ports-correctness.json')")
 (w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'hypothesis':'Known i64 vector indices 0..4095 can use unsigned length>immediate checks and immediate offset addition, avoiding index temporary materialization while preserving handle/bounds/fuel/traps.','admission':'Exact constant descriptor only, 0..4095. Other indices retain existing path.','canonicalSourcesChanged':False,'promotion':'Fresh 30 baseline/candidate/C rotating triples, same existing noise policy, speedup >=1.05 and mean gap > summed SD; correctness and selfhost gates required.','sourceHead':'fa391957901cef14b2a6021e3a22104ec08c27ba','exception':'One-off new compiler algorithm prototype; no mechanical source refactor.'},indent=2)+'\n')
print('prototype ready')
