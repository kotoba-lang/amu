from pathlib import Path
import hashlib,json,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-dead-protection-20261005');old=(r/'seed/41-a64gen.kotoba').read_text();g=old
anchor=';; the first reader of temp t from instruction j on in straight-line code'
helper=''';; Before an explicit local update, only preserve aliases that may be read.
;; The existing bounded kill proof refuses branches/unknown paths. A proved
;; dead alias needs no old-value materialization, including at a later flush.
(defn- gn-prot-live [M :vector-i64 lo :i64 hi :i64 x :i64 s :i64 j :i64] :vector-i64
  (cond (>= lo hi) M
        (and (not= lo x) (gn-isk M lo gn-k-local) (= (gn-dv M lo) s))
        (let [next (if (gn-kills M j lo 16) (gn-dset M lo gn-k-reg 0) (gn-mat M lo))]
          (gn-prot-live next (inc lo) hi x s j))
        :else (gn-prot-live M (inc lo) hi x s j)))
''';assert g.count(anchor)==1;g=g.replace(anchor,helper+anchor)
a='''(defn- gn-op-lset [M :vector-i64 s :i64 t :i64] :vector-i64
  (let [M1 (gn-prot M 0 (gn-g M gn-f-h) t s)''';b='''(defn- gn-op-lset [M :vector-i64 i :i64 s :i64 t :i64] :vector-i64
  (let [M1 (gn-prot-live M 0 (gn-g M gn-f-h) t s (inc i))''';assert g.count(a)==1;g=g.replace(a,b)
a='OP-LSET (gn-op-lset M a b)';b='OP-LSET (gn-op-lset M i a b)';assert g.count(a)==1;g=g.replace(a,b)
(w/'41-a64gen-prototype.kotoba').write_text(g);files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];u=''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files);(w/'seed-unity.kotoba').write_text(u);(w/'seed-unity.kotoba.sha256').write_text(hashlib.sha256(u.encode()).hexdigest()+'\n')
for ext in ['bin','offset']:shutil.copyfile(Path('/private/tmp/amu-sign-wrapper-20261005')/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile('/private/tmp/amu-sign-wrapper-20261005/kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['check-ports.py','bulk-state.py','remote.py']:
 s=Path('/private/tmp/amu-vector-descriptor2-20261005',name).read_text().replace('/private/tmp/amu-vector-descriptor2-20261005','/private/tmp/amu-dead-protection-20261005').replace('/private/tmp/amu-zebulun-vector-descriptor2-20261005','/private/tmp/amu-zebulun-dead-protection-20261005');(w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'hypothesis':'Use existing 16-instruction kill proof to avoid materializing dead aliases before explicit local updates, including parallel recurrence argument assignments.','admission':'Only alias descriptors to updated local, excluding update operand; keep original preservation when proof unknown/live; no changes to coalesced writes.','promotion':'Fresh 30 rotating baseline/candidate/C triples; >=1.05 and mean gap>sumSD plus original noise/semantic rules','sourceHead':'ff8c9d19ca781c40e950c8d30bb248695fd8ac05','exception':'One-off new compiler algorithm authoring'},indent=2)+'\n')
