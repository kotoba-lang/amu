from pathlib import Path
import importlib.util,subprocess,os,re,json,types,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-dead-protection-20261005');sp=importlib.util.spec_from_file_location('fx',r/'scripts/seed/a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
# Dead versus live aliases to a replaced local, including branch conservatism.
for name,body in [
 ('dead_alias',[('LGET',0,1),('CONST',1,99),('LSET',1,1),('CONST',0,42),('RET',0)]),
 ('live_alias',[('LGET',0,1),('CONST',1,99),('LSET',1,1),('RET',0)]),
 ('high_dead_alias',[('LGET',8,1),('CONST',9,99),('LSET',1,9),('CONST',8,42),('RET',8)]),
 ('high_live_alias',[('LGET',8,1),('CONST',9,99),('LSET',1,9),('RET',8)]),
 ('branch_live_alias',[('LGET',0,1),('CONST',1,99),('LSET',1,1),('LGET',1,1),('BRZ',1,'alias_branch'),('RET',0),('LABEL','alias_branch'),('RET',0)])]:
 m.fx(name,1,1,[('FUEL',),('FUEL',)]+body)
 for n in [m.MIN,-1,0,1,42,m.MAX]:m.run(name,[n],42 if 'dead' in name else n,fuel=2)
 m.run(name,[42],'trap',fuel=1)
m.fx('alias_swap',3,3,[('LABEL','swap_entry'),('FUEL',),('LGET',0,1),('CONST',1,0),('CMP','CC-EQ',0),('BRNZ',0,'swap_exit'),('LGET',0,1),('CONST',1,1),('BIN','BOP-SUB',0),('LGET',1,3),('LGET',2,2),('LSET',1,0),('LSET',2,1),('LSET',3,2),('BR','swap_entry'),('LABEL','swap_exit'),('LGET',0,2),('CONST',1,10),('BIN','BOP-MUL',0),('LGET',1,3),('BIN','BOP-ADD',0),('RET',0)])
for n in [0,1,2,3,17]:m.run('alias_swap',[n,2,7],27 if n%2==0 else 72,fuel=n+1)
m.run('alias_swap',[3,2,7],'trap',fuel=3)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800');loader=str(w/'kexe-loader');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];chunks=[]
for real in [False,True]:
 prefix='fixture-real' if real else 'fixture-test';src=w/(prefix+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real))
 for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(prefix+'.kseed'))]),('extract',['extract-native',str(w/(prefix+'.kseed')),'--symbol','main','--output',str(w/(prefix+'.bin'))])]:
  p=subprocess.run([loader,str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(prefix+'-'+label+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(label,p.stdout,p.stderr)
  if label=='extract':off=re.search(r':offset (\d+)',p.stdout).group(1)
 p=subprocess.run([loader,str(w/(prefix+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(prefix+'.stdout')).write_text(p.stdout);assert p.returncode==0,p.stderr;chunks.append(p.stdout)
assert m.blob_from(chunks[0])[0].rstrip(b'\0')==m.blob_from(chunks[1])[0].rstrip(b'\0') and m.blob_from(chunks[0])[1]==m.blob_from(chunks[1])[1]
d=w/'fixture-run/unit/41-a64gen';d.mkdir(parents=True,exist_ok=True);(d/'stdout').write_text(chunks[1]);os.environ['SEED_BUILD']=str(w/'fixture-run');original=m.subprocess.run

def run(args,**kw):
 if args[:2]==['zsh',m.R+'/scripts/seed/unit.sh']:return types.SimpleNamespace(returncode=0,stdout='native experimental fixture emitter already verified; byte golden untouched',stderr='')
 return original(args,**kw)
m.subprocess.run=run;assert m.runs(False)==0
blob,fns=m.blob_from(chunks[1]);names=[f[0] for f in m.FIX];audit={}
for name in ['dead_alias','live_alias']:
 f=names.index(name)+1;end=fns.get(f+1,int(re.search(r'words (\d+)',chunks[1]).group(1))*4);words=struct.unpack('<'+'I'*((end-fns[f])//4),blob[fns[f]:end]);preserve=sum(x==0xaa0003e9 for x in words)
 assert preserve==(0 if name=='dead_alias' else 1),(name,preserve)
 audit[name]={'oldLocalToTempMov':preserve,'bytes':end-fns[f]}
(w/'fixture-proof.json').write_text(json.dumps({'runs':len(m.RUNS),'fixtures':len(m.FIX),'realTestLayoutIdentical':True,'instructionAudit':audit},indent=2)+'\n');print('PASS dead-alias instruction audits',flush=True)
