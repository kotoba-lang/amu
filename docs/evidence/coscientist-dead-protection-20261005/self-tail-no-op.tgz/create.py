from pathlib import Path
import hashlib,json,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-self-tail-frame-20261005');old=(r/'seed/41-a64gen.kotoba').read_text();g=old
anchor='(def gn-cap 4096)';assert g.count(anchor)==1;g=g.replace(anchor,'(def gn-f-self 13)    ; current function id\n(def gn-f-body 14)    ; code word after prologue/parameter binding\n'+anchor)
anchor='(defn- gn-op-fn2 [M1 :vector-i64 i :i64 f :i64 np :i64] :vector-i64';helper='''(defn- gn-body-mark [M :vector-i64 f :i64] :vector-i64
  (-> M (gn-gs gn-f-self f) (gn-gs gn-f-body (vector-at M MM-CODE-N))))
''';assert g.count(anchor)==1;g=g.replace(anchor,helper+anchor)
a='''                  (gn-gs gn-f-ctx 1)
                  (gn-gs gn-f-h 0)))))))''';b='''                  (gn-gs gn-f-ctx 1)
                  (gn-gs gn-f-h 0)
                  (gn-body-mark f)))))))''';assert g.count(a)==1;g=g.replace(a,b)
a='''  (let [restored (-> M (gn-args t 0 n) (gn-ctx) (gn-epilogue))
        at (- (vector-at restored MM-CODE-N) 1)]
    (-> restored (gn-put MM-CODE-N at) (gn-fix FX-BL26 f) (gn-emit (enc-b 0)))))'''
b='''  (if (and (= f (gn-g M gn-f-self)) (= (gn-g M gn-f-leaf) 0)
           (= n (gn-fnf M f FF-NPARAMS)) (<= n 7) (> (gn-g M gn-f-body) 0))
      (let [bound (-> M (gn-args t 0 n) (gn-ctx) (gn-params 1 n))
            target (gn-g bound gn-f-body)]
        (-> bound (gn-emit (enc-b (- target (vector-at bound MM-CODE-N))))
            (gn-gs gn-f-dead 1)))
      (let [restored (-> M (gn-args t 0 n) (gn-ctx) (gn-epilogue))
            at (- (vector-at restored MM-CODE-N) 1)]
        (-> restored (gn-put MM-CODE-N at) (gn-fix FX-BL26 f) (gn-emit (enc-b 0))))))''';assert g.count(a)==1;g=g.replace(a,b)
(w/'41-a64gen-prototype.kotoba').write_text(g);files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];u=''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files);(w/'seed-unity.kotoba').write_text(u);(w/'seed-unity.kotoba.sha256').write_text(hashlib.sha256(u.encode()).hexdigest()+'\n')
for ext in ['bin','offset']:shutil.copyfile(Path('/private/tmp/amu-sign-wrapper-20261005')/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile('/private/tmp/amu-sign-wrapper-20261005/kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['check-ports.py','bulk-state.py','remote.py']:
 s=Path('/private/tmp/amu-vector-descriptor2-20261005',name).read_text().replace('/private/tmp/amu-vector-descriptor2-20261005','/private/tmp/amu-self-tail-frame-20261005').replace('/private/tmp/amu-zebulun-vector-descriptor2-20261005','/private/tmp/amu-zebulun-self-tail-frame-20261005');(w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'hypothesis':'Direct scalar self-tail recursion can rebind <=7 register arguments and branch to body using the existing frame, avoiding repeated callee-save/prologue/epilogue work.','admission':'CALL immediately followed by same-temp RET; same current function, exact arity <=7, non-leaf; original body entry FUEL reruns each iteration. Other calls unchanged.','promotion':'Fresh 30 rotating baseline/candidate/C triples; existing noise policy; >=1.05 speedup and gap>sumSD plus native fixed point and correctness','sourceHead':'ff8c9d19ca781c40e950c8d30bb248695fd8ac05','exception':'One-off new compiler algorithm authoring, no mechanical refactor'},indent=2)+'\n')
