import pathlib,json,re,subprocess,hashlib
w=pathlib.Path('/private/tmp/amu-tailleaf-prototype-20261005');loader=pathlib.Path('/private/tmp/amu-tailcall-20261005/kexe-loader');reference=json.loads(pathlib.Path('/private/tmp/amu-tailcall-20261005/statemate-state-parity.json').read_text());offset=lambda sym:int(re.search(r':offset (\d+)',(w/(sym+'.extract.log')).read_text()).group(1))
for c in reference['cells']:
 sym='stage-cell' if c['kind']=='stage' else 'repeat-cell';n=c['test']*4096+c['stage']*169+c['cell'] if c['kind']=='stage' else c['iterations']*169+c['cell']
 p=subprocess.run([str(loader),str(w/(sym+'.bin')),str(offset(sym)),'1','aarch64','35,37,38,39',str(n)],capture_output=True,text=True);assert p.returncode==0 and int(p.stdout.strip().splitlines()[-1])==c['value'],(c,p.returncode,p.stdout,p.stderr)
for g in reference['guards']:
 p=subprocess.run([str(loader),str(w/'bounds-probe.bin'),str(offset('bounds-probe')),'1','aarch64','35,37,38,39',str(g['n'])],capture_output=True,text=True);assert (p.returncode==0 if g['n']==168 else p.returncode!=0 and 'KEXE_TRAP' in p.stderr),(g,p.returncode,p.stderr)
runner='/private/tmp/amu-embench-compare-20261004/runner';off=offset('statemate');entry=next(e for e in json.loads(pathlib.Path('/private/tmp/amu-tailcall-20261005/ports-correctness.json').read_text())['entries'] if e['workload']=='statemate');runs=[]
for x in entry['runs']:
 p=subprocess.run([runner,'raw',str(w/'statemate.bin'),str(off),'aarch64',str(x['n']),'1','0','16777216'],capture_output=True,text=True);assert p.returncode==0,p.stderr;s=json.loads(p.stdout);assert s['result']==x['result'] and s['contextFuelConsumed']==x['fuelConsumed'],(x,s);runs.append(s)
p=subprocess.run([runner,'raw',str(w/'statemate.bin'),str(off),'aarch64','1','1','0','1'],capture_output=True,text=True);assert p.returncode==-5,p.returncode
(w/'correctness.json').write_text(json.dumps({'status':'pass','stateCells':len(reference['cells']),'guards':reference['guards'],'runs':runs,'fuelTrap':p.returncode,'performanceMeasured':False},indent=2)+'\n');print('PASS',len(reference['cells']),'state cells and result/fuel/bounds')
