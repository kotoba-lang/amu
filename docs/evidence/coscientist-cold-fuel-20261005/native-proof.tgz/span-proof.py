from pathlib import Path
import subprocess,os,re,json,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-cold-fuel-20261005');src=w/'span-proof.kotoba'
source='''
(defn- span-print [M :vector-i64 j :i64 end :i64] :i64
 (if (= j end) (io-out "\n")
  (let [o (io-out (string-concat " " (mem-u2dec (vector-at M (+ MM-CODE-BASE j)))))] (span-print M (inc j) end))))
(defn- span-case [M :vector-i64 leaf :i64 ctx :i64 target :i64 start :i64] :vector-i64
 (let [M0 (-> M (gn-gs gn-f-freg leaf) (gn-gs gn-f-leaf leaf) (gn-gs gn-f-ctx ctx) (gn-gs gn-f-fb 16)
               (gn-gs 13 target) (gn-put MM-CODE-N start))
       M1 (gn-op-fuel M0) end (vector-at M1 MM-CODE-N)
       o (io-out (string-concat (string-concat (string-concat (mem-u2dec leaf) " ") (mem-u2dec ctx))
                  (string-concat (string-concat " " (mem-u2dec target)) (string-concat " " (mem-u2dec start)))))
       q (span-print M1 start end)] M1))
(defn- seed-main [] :i64
 (let [M0 (gn-run (-> (vector-alloc MM-WORDS) (gn-put MM-SIR-N 1) (gn-put MM-CODE-N 1) (gn-put MM-FIX-N 1)))
       M1 (span-case M0 1 1 1 262144)
       M2 (span-case M1 1 1 1 262145)
       M3 (span-case M2 0 1 1 262143)
       M4 (span-case M3 0 1 1 262144)
       M5 (span-case M4 0 0 1 262142)
       M6 (span-case M5 0 0 1 262143)
       M7 (span-case M6 1 1 0 10)
       M8 (span-case M7 0 0 0 10)] (vector-at M8 MM-ERR)))
'''.replace('"\n"','"\\n"')
src.write_text('\n'.join((r/p).read_text() for p in ['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'])+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+source)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800');loader=str(w/'kexe-loader');seed=w/'seed-4.bin'
for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/'span-proof.kseed')]),('extract',['extract-native',str(w/'span-proof.kseed'),'--symbol','main','--output',str(w/'span-proof.bin')])]:
 p=subprocess.run([loader,str(seed),seed.with_suffix('.offset').read_text().strip(),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/('span-'+label+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(label,p.stdout,p.stderr)
 if label=='extract':off=re.search(r':offset (\d+)',p.stdout).group(1)
p=subprocess.run([loader,str(w/'span-proof.bin'),off,'0','aarch64','37','--'],env=env,capture_output=True,text=True);(w/'span-proof.stdout').write_text(p.stdout);assert p.returncode==0,(p.returncode,p.stdout,p.stderr);rows=[]
for line in p.stdout.splitlines():
 nums=list(map(int,line.split()));leaf,ctx,target,start=nums[:4];words=nums[4:];j=1 if leaf else 2+(not ctx);branch=start+j;delta=target-branch;admitted=target>0 and -262144<=delta<=262143
 if admitted:
  assert words[j]&0xff00001f==0x54000003;d=(words[j]>>5)&0x7ffff;d-=1<<19 if d&(1<<18) else 0;assert d==delta
  assert len(words)==(2 if leaf else 4+(not ctx))
  if not leaf:assert words[-1]==0xf90004f0
 else:
  assert words[j]&0xff00001f==0x54000002 and 0xd4200000 in words;assert len(words)==(4 if leaf else 5+(not ctx))
 rows.append({'leaf':leaf,'contextAlreadyAvailable':ctx,'target':target,'start':start,'actualDelta':delta,'coldAdmitted':admitted,'words':words})
assert len(rows)==8
(w/'span-proof.json').write_text(json.dumps({'status':'complete-native-exact-span-and-legacy-fallback-proof','cases':rows,'covers':'exact negative19-bit limit, one word beyond, actual context-restore instruction, missing cold target; legacy charges/trap code remain'},indent=2)+'\n');print('PASS actual branch range boundary and original fallback',flush=True)
