from pathlib import Path
import shutil,json
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-cold-fuel-20261005');base=Path('/private/tmp/amu-scalar-tree-20261005');g=(r/'seed/41-a64gen.kotoba').read_text()
helper=''';; Failure blocks precede the callable entry. Direct/indirect/export/tail
;; references still point to FF-CODE after the block; ordinary execution never
;; passes through failure code. Field13 is private and reset for every FN.
(defn- gn-cold-entry [M :vector-i64 f :i64] :vector-i64
  (let [at (vector-at M MM-CODE-N)
        M1 (if (= (gn-g M gn-f-fuel) 1)
             (-> M (cond-> (= (gn-g M gn-f-leaf) 1) (gn-emit (enc-str 31 7 CTX-FUEL)))
                   (gn-emit (enc-brk 0)) (gn-gs 13 at)) M)]
    (gn-put M1 (+ MM-FN-BASE (* f MM-FN-W) FF-CODE) (vector-at M1 MM-CODE-N))))

'''
a='(defn- gn-op-fn2 ';assert g.count(a)==1;g=g.replace(a,helper+a)
a='(gn-put (+ MM-FN-BASE (* f MM-FN-W) FF-CODE) (vector-at M2 MM-CODE-N))';assert g.count(a)==1;g=g.replace(a,'(gn-cold-entry f)')
a=g.index('(defn- gn-op-fuel ');b=g.index(';; one SIR instruction',a);old=g[a:b]
new='''(defn- gn-op-fuel [M :vector-i64] :vector-i64
  (let [target (gn-g M 13) at (+ (vector-at M MM-CODE-N) (if (= (gn-g M gn-f-freg) 1) 1 2))
        ;; gn-ctx can emit one instruction. Evaluate it before proving distance.
        M1 (if (= (gn-g M gn-f-freg) 1) M (gn-ctx M))
        branch (+ (vector-at M1 MM-CODE-N) (if (= (gn-g M1 gn-f-freg) 1) 1 2))
        delta (- target branch)]
    (if (and (> target 0) (>= delta -262144) (<= delta 262143))
      (if (= (gn-g M1 gn-f-freg) 1)
        (-> M1 (gn-emit (enc-subs-i 8 8 1)) (gn-emit (enc-bcond (enc-cond-lo) delta)))
        (-> M1 (gn-emit (enc-ldr 16 7 CTX-FUEL)) (gn-emit (enc-subs-i 16 16 1))
               (gn-emit (enc-bcond (enc-cond-lo) delta)) (gn-emit (enc-str 16 7 CTX-FUEL))))
      OLD)))

'''.replace('OLD',old[old.index('(if '):].rstrip()[:-1].replace('(gn-g M gn-f-freg)','(gn-g M1 gn-f-freg)').replace('(-> M\n','(-> M1\n').replace('(-> M (gn-emit','(-> M1 (gn-emit'))
g=g[:a]+new+g[b:];(w/'41-a64gen-prototype.kotoba').write_text(g);files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
for ext in ['bin','offset']:shutil.copyfile(base/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile(base/'kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['build.py','check-ports.py','bulk-state.py']:
 s=(base/name).read_text().replace('amu-scalar-tree-20261005','amu-cold-fuel-20261005').replace("base=Path('/private/tmp/amu-sign-wrapper-20261005')","base=Path('/private/tmp/amu-scalar-tree-20261005')").replace("pathlib.Path('/private/tmp/amu-sign-wrapper-20261005/ports-correctness.json')","pathlib.Path('/private/tmp/amu-scalar-tree-20261005/ports-correctness.json')")
 if name=='build.py':s=s.replace("str(w/f'seed-{n-1}.bin'),'0','0'","str(w/f'seed-{n-1}.bin'),(w/f'seed-{n-1}.offset').read_text().strip(),'0'")
 else:s=s.replace("str(seed),'0','0'","str(seed),seed.with_suffix('.offset').read_text().strip(),'0'")
 (w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'hypothesis':'Put a shared exact exhaustion block before each fuel-bearing callable entry, setting FF-CODE after it. At each checkpoint prove actual backward signed19 branch span, including any gn-ctx restore. Emit SUBS/B.LO into that block so success falls through. Keep every original decrement/nonleaf store/leaf commit; out-of-range/missing block keeps legacy check. No pending relocations, body duplication or precharge.','promotion':'Native fixedpoint; all19 result/exactfuel/exhaustion, full Pico state, every low budget/trap/partial state, callable entry and native failure target audits. Freshquiet30 for all changed workloads, >=5% and gap>sumSD with no separated regression.','sourceHead':'affc8563aabef45bb29167fd1a73d5d065e70890','exception':'One-off compiler algorithm authoring, not mechanical refactoring'},indent=2)+'\n')
