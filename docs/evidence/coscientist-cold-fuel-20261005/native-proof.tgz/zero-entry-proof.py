from pathlib import Path
import importlib.util,subprocess,os,json,re
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-cold-fuel-20261005');sp=importlib.util.spec_from_file_location('fx',r/'scripts/seed/a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);m.FIX.clear();m.RUNS.clear()
m.fx('zero_leaf',1,1,[('FUEL',),('FUEL',),('FUEL',),('LGET',0,1),('RET',0)])
m.fx('zero_entry',1,1,[('FUEL',),('LGET',0,1),('CALL','zero_leaf',0,1),('RET',0)])
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800');loader=str(w/'kexe-loader');blobs={}
for label,seed,backend in [('baseline',Path('/private/tmp/amu-scalar-tree-20261005/seed-4.bin'),r/'seed/41-a64gen.kotoba'),('candidate',w/'seed-4.bin',w/'41-a64gen-prototype.kotoba')]:
 d=w/('zero-entry-'+label);d.mkdir();src=d/'source.kotoba';parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+backend.read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+m.kotoba(True))
 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(d/'image.kseed')]),('extract',['extract-native',str(d/'image.kseed'),'--symbol','main','--output',str(d/'native.bin')])]:
  p=subprocess.run([loader,str(seed),seed.with_suffix('.offset').read_text().strip(),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(mode+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(label,mode,p.stdout,p.stderr)
  if mode=='extract':off=re.search(r':offset (\d+)',p.stdout).group(1)
 p=subprocess.run([loader,str(d/'native.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(d/'emitter.stdout').write_text(p.stdout);assert p.returncode==0;pblob,fns=m.blob_from(p.stdout);(d/'guest.bin').write_bytes(pblob);blobs[label]=(d/'guest.bin',fns[2])
rows=[]
for budget in range(1,6):
 results=[]
 for label,(code,off) in blobs.items():
  e=dict(os.environ,KEXE_FUEL=str(budget),KEXE_STRUCTURED_REPORT='1',KEXE_CPU_SECONDS='30',KEXE_WALL_SECONDS='30');e.pop('KEXE_COMMAND',None)
  p=subprocess.run([loader,str(code),str(off),'1','aarch64','-','17'],env=e,capture_output=True,text=True,timeout=35);results.append({'exit':p.returncode,'report':p.stdout,'traps':re.findall(r'^KEXE_TRAP.*$',p.stderr,re.M)})
 assert results[0]==results[1],(budget,results)
 assert (results[0]['exit']==120 and ':budget/fuel' in ' '.join(results[0]['traps'])) if budget<4 else results[0]['exit']==0 and ':result 17' in results[0]['report']
 rows.append({'initialFuel':budget,'regionEntryFuel':budget-1,**results[0]})
(w/'zero-entry-proof.json').write_text(json.dumps({'status':'complete-exact-zero-region-entry-and-boundary-parity','zeroInitialFuel':'refused by supervisor; not counted as an executed guest','zeroRegionEntry':'initial budget1 consumed by caller; callee guard sees0 and takes original exhaustion path','comparisons':len(rows),'rows':rows},indent=2)+'\n');print('PASS zero region-entry and every caller/callee budget boundary',flush=True)
