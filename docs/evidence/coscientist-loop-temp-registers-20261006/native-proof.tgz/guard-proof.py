from pathlib import Path
import importlib.util,subprocess,os,json,re,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-loop-temp-registers-20261006');sp=importlib.util.spec_from_file_location('fx',w/'permanent-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
for mode in ['hot','cold','constant','trivial','coalesced']:
 name='guard_'+mode;body=[('CONST',0,1),('LSET',2,0),('LABEL',name+'_loop'),('LGET',7,1),('CONST',8,7 if mode!='trivial' else 1),('BIN','BOP-ADD',7)]
 if mode=='constant':body[3]=('CONST',7,11)
 if mode=='coalesced':body += [('LSET',3,7)]
 body += [('LGET',0,2),('CONST',1,1),('BIN','BOP-SUB',0),('LSET',2,0),('FUEL',)]
 if mode!='cold':body += [('BRNZ',0,name+'_loop')]
 body += [('RET',0 if mode=='coalesced' else 7)];m.fx(name,1,3 if mode=='coalesced' else 2,body)
fns,labels,lits,sir,fnrecs=m.layout_tables();tests=[];defs=[]
for mode in ['hot','cold','constant','trivial','coalesced']:
 name='guard_'+mode;f=fns[name];start=next(i+1 for i,x in enumerate(sir) if x[0]==m.C['OP-FN'] and x[1]==f);end=next(i+1 for i,x in enumerate(sir) if i+1>start and x[0]==m.C['OP-END']);want=1 if mode=='hot' else 0
 defs.append(f'''(defn- check-{mode} [] :i64
 (let [M0 (gn-run (t-load (t-init))) M1 (gn-op-fn M0 {start} {f} 1)
        got (gn-g M1 gn-f-nt) again (gn-hot-temp-range M1 {start})]
  (if (and (= got {want}) (= again {want}) (= (vector-at M1 MM-ERR) 0)) 0 1)))''');tests.append(mode)
 if mode=='hot':
  branch=next(i+1 for i,x in enumerate(sir) if start<i+1<end and x[0]==m.C['OP-BRNZ']);label=labels[name+'_loop'];p=next(i+1 for i,x in enumerate(sir) if start<i+1<end and x[0]==m.C['OP-LABEL'] and x[1]==label);labelNameSlot=m.C['MM-SIR-BASE']+p*m.C['MM-SIR-W']+m.C['IF-A'];coldFn=fns['ht_cold_control'];coldStart=next(i+1 for i,x in enumerate(sir) if x[0]==m.C['OP-FN'] and x[1]==coldFn)
  for variant,expr in [('budget',f'(gn-hot-temp-scan M1 {start+1} 17 0 0)'),('wronglabel',f'(gn-hot-temp-range (t-put M1 {labelNameSlot} {label+1}) {start})'),('foreign',f'(gn-hot-temp-range (gn-gs M1 (+ gn-a-lp {label}) {coldStart}) {start})'),('wrongstart',f'(gn-hot-temp-range M1 {start+1})')]:
   defs.append(f'''(defn- check-{variant} [] :i64
 (let [M0 (gn-run (t-load (t-init))) M1 (gn-op-fn M0 {start} {f} 1)]
  (if (= {expr} 0) 0 1)))''');tests.append(variant)
text=m.kotoba(True);text=text.replace('(defn- seed-main [] :i64','(defn- original-seed-main [] :i64');assert '(defn- seed-main [] :i64' not in text;text+='\n'+'\n'.join(defs)+'\n(defn- seed-main [] :i64 (+ '+' '.join('(check-'+x+')' for x in tests)+'))\n';src=w/'guard-proof.kotoba';src.write_text('\n'.join((r/n).read_text() for n in ['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'])+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+text);env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/'guard-proof.kseed')]),('extract',['extract-native',str(w/'guard-proof.kseed'),'--symbol','main','--output',str(w/'guard-proof.bin')])]:
 q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/('guard-'+label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout,q.stderr)
 if label=='extract':offset=re.search(r':offset (\d+)',q.stdout).group(1)
q=subprocess.run([str(w/'kexe-loader'),str(w/'guard-proof.bin'),offset,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/'guard-native-output.log').write_text(q.stdout+q.stderr);assert q.returncode==0,(q.stdout,q.stderr);assert len(tests)==9 and 0<=q.returncode<=9; (w/'guard-proof.json').write_text(json.dumps({'status':'complete-fresh-native-loop-temp-admission-and-refusal-guard-proof','cases':tests,'nativeResult':0,'commandExit':q.returncode,'failureCountBound':9,'observationContract':'Command main exits with sum of nine nonnegative0-or1 guard failures, not scalar stdout; zeroexit proves zero failures.','sourceSha256':hashlib.sha256(src.read_bytes()).hexdigest()},indent=2)+'\n');print('PASS native guard cases',tests,flush=True)
