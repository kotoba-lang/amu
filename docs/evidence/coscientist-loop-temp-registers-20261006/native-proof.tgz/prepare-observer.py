from pathlib import Path
w=Path('/private/tmp/amu-loop-temp-registers-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');g=(w/'41-a64gen-prototype.kotoba').read_text();needle='                leaf (gn-g M2 gn-f-leaf)]';assert g.count(needle)==1
fields=['f','F','ns','dp','(gn-g M2 gn-f-nsv)','(gn-g M2 gn-f-nt)'];text='"\\n"'
for x in reversed(fields):text=f'(string-concat (string-from-i64 {x}) (string-concat " " {text}))'
g=g.replace(needle,'                leaf (gn-g M2 gn-f-leaf)\n                printed (io-out (string-concat "REG " '+text+'))]')
parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'observer-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in parts))
s=(Path('/private/tmp/amu-loop-high-temp-20261006/hand-proof.py').read_text()).replace('amu-loop-high-temp-20261006','amu-loop-temp-registers-20261006');(w/'hand-proof.py').write_text(s);(w/'hand-build.py').write_text(s[:s.index('rows=[];values=')]+"print('PASS hand real/test layout and candidate fixtures ready',flush=True)\n")
for n in ['import-proof.py','resource-proof.py']:(w/n).write_text((Path('/private/tmp/amu-loop-high-temp-20261006')/n).read_text().replace('amu-loop-high-temp-20261006','amu-loop-temp-registers-20261006'))
import shutil
shutil.copyfile('/private/tmp/amu-loop-high-temp-20261006/baseline-a64gen-fixtures.py',w/'baseline-a64gen-fixtures.py')
