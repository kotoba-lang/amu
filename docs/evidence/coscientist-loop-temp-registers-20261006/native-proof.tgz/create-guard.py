from pathlib import Path
import json
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-loop-temp-registers-20261006');g=(w/'41-a64gen-prototype.kotoba').read_text()
helper=''';; Profitability: a dynamic non-coalesced high result inside an actual loop.
;; Adjacent local/constant producers distinguish deferred constant-only setup.
;; This selects register capacity, not expression semantics or execution results.
(defn- gn-hot-temp-scan [M :vector-i64 j :i64 limit :i64 acc :i64 work :i64] :i64
 (cond (or (<= work 0) (>= j (vector-at M MM-SIR-N))) 0
       (= (gn-op M j) OP-END) acc
       (= (gn-op M j) OP-FN) 0
       :else
       (let [t (gn-sir M j IF-B) bop (gn-sir M j IF-A)
             v (gn-sir M (dec j) IF-B)
             yes (and (= (gn-op M j) OP-BIN) (>= t 7) (< t limit)
                 (or (= bop BOP-ADD) (= bop BOP-MUL))
                 (not= v 0) (not= v 1) (not= v -1)
                 (= (gn-op M (- j 2)) OP-LGET) (= (gn-sir M (- j 2) IF-A) t)
                 (= (gn-op M (dec j)) OP-CONST) (= (gn-sir M (dec j) IF-A) (inc t))
                 (= (gn-co M j t) 0) (gn-high-loop M j))]
        (gn-hot-temp-scan M (inc j) limit (if yes (gn-max acc (- t 6)) acc) (dec work)))))
(defn- gn-hot-temp-range [M :vector-i64 i :i64] :i64
 (if (or (<= i 0) (not= (gn-op M i) OP-FN)) 0
  (gn-hot-temp-scan M (inc i) (+ 7 (- 10 (gn-g M gn-f-nsv))) 0 8192)))
'''
needle='(defn- gn-op-fn2 [';assert g.count(needle)==1;g=g.replace(needle,helper+needle,1);needle='M2 (gn-assign M1)';assert g.count(needle)==1;g=g.replace(needle,'allocated (gn-assign M1)\n                M2 (gn-gs allocated gn-f-nt (gn-hot-temp-range allocated i))',1);(w/'41-a64gen-prototype.kotoba').write_text(g)
parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in parts));h=json.loads((w/'hypothesis.json').read_text());h['hypothesis']='Map spare callee registers only through highest non-coalesced high BIN ADD/MUL result with adjacent LGET and nontrivial CONST inside bounded validated same-function loop; preserve original homes/frame/local allocation and unnamed state14 tree flag.';h['registeredEvidence']=json.loads((r/'docs/evidence/coscientist-temp-materialization-census-20261006/next-hypothesis.json').read_text());h['proofRequirements']='Fresh fixedpoint/all7989/all19state; actual admission/word/save/restore/guard cases, aliases/joins/calls/tail/RET2/import/resources/fuel before timing. No product promotion yet.';(w/'hypothesis.json').write_text(json.dumps(h,indent=2)+'\n');print('PASS registered general loop-produced high-temp guard before native build')
