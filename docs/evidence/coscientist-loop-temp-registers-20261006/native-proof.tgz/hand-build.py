from pathlib import Path
import os,subprocess,re,json,importlib.util,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-loop-temp-registers-20261006');sp=importlib.util.spec_from_file_location('m',w/'baseline-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);cases=[]
m.fx('ht_clobber',7,7,[('FUEL',),('CONST',0,77),('RET',0)])
m.fx('ht_alloc',0,0,[('FUEL',),('CONST',0,1),('RT','RT-VECTOR-ALLOC',0,1),('CONST',0,77),('RET',0)])
for t,mode in [(t,mode) for t in [6,7,10,31] for mode in ['plain','coalesced','beforecall','aftercall','alias','loop','walk','skip']]+[(63,'plain')]:
 name=f'ht_case_{len(cases)}';body=[('FUEL',)]+[('CONST',j,11-3*j) for j in range(8)]+[('VEC',0,8),('CONST',0,99),('VEC',0,1)]
 if mode in ['loop','walk']:body += [('CONST',0,2),('LSET',7,0),('CONST',0,0),('LSET',8,0),('LABEL',name+'_loop'),('LGET',0,7),('BRZ',0,name+'_end')]
 for j in range(t):body += [('LGET',j,3 if j%2==0 else 4),('CONST',j+1,-19+7*j),('BIN','BOP-ADD',j)]
 if mode=='beforecall':body += [('CONST',t+j,v) for j,v in enumerate([1,99,98,1,0,1,66])]+[('CALL','ht_clobber',t,7)]
 if mode=='skip':body += [('LGET',t,2),('CONST',t+1,8),('CMP','CC-GE',t),('BRNZ',t,name+'_skip')]
 body += [('LGET',t,1),('LGET',t+1,2),('RT','RT-VECTOR-AT',t,2)]
 if mode=='coalesced':body += [('LSET',5,t),('LGET',t,5)]
 if mode=='aftercall':body += [('CALL','ht_alloc',t+1,0),('BIN','BOP-ADD',t)]
 if mode=='alias':body += [('LSET',1,t),('LGET',t,1),('CONST',t+1,0),('RT','RT-VECTOR-AT',t,2)]
 if mode=='skip':body += [('BR',name+'_join'),('LABEL',name+'_skip'),('CONST',t,77),('LABEL',name+'_join')]
 body += [('BIN','BOP-ADD',j) for j in range(t-1,-1,-1)]
 if mode in ['loop','walk']:
  body += [('LGET',1,8),('BIN','BOP-ADD',0),('LSET',8,0)]
  if mode=='walk':body += [('LGET',0,2),('CONST',1,1),('BIN','BOP-ADD',0),('LSET',2,0)]
  body += [('LGET',0,7),('CONST',1,1),('BIN','BOP-SUB',0),('LSET',7,0),('FUEL',),('BR',name+'_loop'),('LABEL',name+'_end'),('LGET',0,8)]
 body += [('RET',0)];m.fx(name,4,8,body);cases.append({'name':name,'t':t,'mode':mode})
# Author one-iteration enclosing loop for every hand caller so the new
# profitability guard admits each access, including call/alias/resource paths.
for c in cases:
 k=next(j for j,x in enumerate(m.FIX) if x[0]==c['name']);name,np,ns,dp,body=m.FIX[k];at=body.index(('VEC',0,1))+1;label=name+'_outer'
 assert body[-1]==('RET',0)
 body=body[:at]+[('CONST',0,1),('LSET',6,0),('LABEL',label)]+body[at:-1]+[('LSET',9,0),('LGET',0,6),('CONST',1,1),('BIN','BOP-SUB',0),('LSET',6,0),('FUEL',),('BRNZ',0,label),('LGET',0,9),('RET',0)]
 m.FIX[k]=(name,np,9,dp,body)
ids={x[0]:j+1 for j,x in enumerate(m.FIX)};(w/'hand-cases.json').write_text(json.dumps(cases,indent=2)+'\n');(w/'hand-ids.json').write_text(json.dumps(ids,indent=2)+'\n')
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];images={};chunks={}
for label,gen,real in [('baseline-hand','baseline-41-a64gen.kotoba',True),('candidate-hand','41-a64gen-prototype.kotoba',True),('candidate-hand-test','41-a64gen-prototype.kotoba',False)]:
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/gen).read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real))
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-300:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0;(w/(label+'.stdout')).write_text(q.stdout);blob,fc=m.blob_from(q.stdout);bp=w/(label+'-fixture.bin');bp.write_bytes(blob);images[label]=(bp,fc);chunks[label]=(blob,fc)
a=chunks['candidate-hand-test'];b=chunks['candidate-hand'];assert a[1]==b[1] and a[0][:len(b[0])]==b[0] and not any(a[0][len(b[0]):]) and 0<=len(a[0])-len(b[0])<=7
(w/'hand-layout.json').write_text(json.dumps({'status':'complete-native-high-temp-hand-real-test-layout','fixtures':len(m.FIX),'callers':len(cases),'codeAndLiteralBytesEqual':True,'fnOffsetsEqual':True,'testOnlyPaddingBytes':len(a[0])-len(b[0])},indent=2)+'\n')
print('PASS hand real/test layout and candidate fixtures ready',flush=True)
