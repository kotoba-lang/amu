from pathlib import Path
import importlib.util,json,subprocess,os,re,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-loop-temp-registers-20261006');sp=importlib.util.spec_from_file_location('fx',w/'permanent-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);first=len(m.FIX);cs=[]
m.fx('ct_id',1,1,[('FUEL',),('LGET',0,1),('CONST',1,7),('BIN','BOP-ADD',0),('RET',0)])
m.fx('ct_pair',1,1,[('FUEL',),('LGET',0,1),('LGET',1,1),('CONST',2,9),('BIN','BOP-ADD',1),('RET2',0)])
for depth in [8,10,17,31,63]:
 for mode in ['leaf','call','alloc','join','pair','tail']:
  name=f'ct_{depth}_{mode}';body=[('FUEL',)]
  for j in range(depth):body += [('LGET',j,1),('CONST',j+1,j+1),('BIN','BOP-ADD',j)]
  body += [('LGET',depth,2)]
  if mode in ['call','tail']:body += [('CALL','ct_id',depth,1)]
  if mode=='tail':body += [('RET',depth)]
  elif mode=='alloc':body += [('CONST',depth,1),('RT','RT-VECTOR-ALLOC',depth,1)]
  elif mode=='pair':body += [('CALL','ct_pair',depth,1),('RES2',depth+1),('BIN','BOP-ADD',depth)]
  elif mode=='join':body += [('BRZ',depth,name+'_zero'),('CONST',depth+1,7),('BIN','BOP-ADD',depth),('BR',name+'_end'),('LABEL',name+'_zero'),('CONST',depth,11),('LABEL',name+'_end')]
  if mode!='tail':body += [('BIN','BOP-ADD',j) for j in range(depth-1,-1,-1)]+[('RET',0)]
  label=name+'_loop';back=[('LGET',0,4),('CONST',1,1),('BIN','BOP-SUB',0),('LSET',4,0),('FUEL',),('BRNZ',0,label)]
  if mode=='tail':
   k=next(j for j,x in enumerate(body) if x[0]=='CALL');body=body[:k]+back+body[k:]
  else:
   ret=body[-1];body=body[:-1]+[('LSET',5,ret[1])]+back+[('LGET',0,5),('RET',0)]
  body=body[:1]+[('CONST',0,1),('LSET',4,0),('LABEL',label)]+body[1:]
  m.fx(name,3,5 if mode!='tail' else 4,body)
  outer=name+'_outer';body=[('FUEL',)]
  for k in range(1,11):body += [('LGET',0,1),('CONST',1,k),('BIN','BOP-ADD',0),('LSET',k+3,0)]
  body += [('LGET',0,1),('LGET',1,2),('LGET',2,3),('CALL',name,0,3)]
  for k in range(1,11):body += [('LGET',1,k+3),('BIN','BOP-ADD',0)]
  body += [('RET',0)];m.fx(outer,3,13,body);cs.append({'name':name,'outer':outer,'depth':depth,'mode':mode})
(w/'callee-cases.json').write_text(json.dumps(cs,indent=2)+'\n');ids={x[0]:j+1 for j,x in enumerate(m.FIX)};env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');images={}
for label,gen in [('baseline-callee','baseline-41-a64gen.kotoba'),('candidate-callee','41-a64gen-prototype.kotoba')]:
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in ['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'])+'\n'+(w/gen).read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+m.kotoba(True))
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-300:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0;(w/(label+'.stdout')).write_text(q.stdout);blob,fc=m.blob_from(q.stdout);bp=w/(label+'-fixture.bin');bp.write_bytes(blob);images[label]=(bp,fc)
# Independently audit exact added register saves/restores and unchanged frame.
audit=[]
def words(label,name):
 bp,fc=images[label];blob=bp.read_bytes();k=ids[name];p=blob[fc[k]:fc.get(k+1,len(blob))];return struct.unpack('<'+'I'*(len(p)//4),p)
def frame(ws):
 return sum((x>>10)&4095 for x in ws[:20] if x&0xffc003ff==0xd10003ff)+sum(((x>>10)&4095)<<12 for x in ws[:20] if x&0xffc003ff==0xd14003ff)
for c in cs:
 old=words('baseline-callee',c['name']);new=words('candidate-callee',c['name']);F=frame(old);assert F==frame(new),(c,F,frame(new));ns=4 if c['mode']=='tail' else 5;localnsv=0 if c['mode'] in ['leaf','join'] else 3 if c['mode']=='tail' else 4;nt=min(c['depth']-7,10-localnsv)
 saved=[]
 for j in range(nt):
  reg=19+localnsv+j;offset=F-8*(ns+1+7+j+1);st=0xf9000000+(offset//8<<10)+(31<<5)+reg;ld=0xf9400000+(offset//8<<10)+(31<<5)+reg
  assert new.count(st)==1 and new.count(ld)>=1,(c,j,F,offset,hex(st),new.count(st),new.count(ld));assert offset>=8*localnsv and offset+8<=F,(c,j,F,offset,localnsv)
  saved.append({'register':reg,'originalTemp':7+j,'offset':offset})
 audit.append({'case':c,'frameBytes':F,'unchangedFrame':True,'calleeBackupSlots':saved})
(w/'callee-instruction-audit.json').write_text(json.dumps(audit,indent=2)+'\n');rows=[]
for c in cs:
 for a,b in [(m.MIN,37),(37,m.MAX),(0,0),(-19,-7),(99,1)]:
  for fuel in [1,2,3,4,16777216]:
   mode=c['mode'];charges=4 if mode in ['call','tail','pair'] else 3;valid=fuel>=charges
   term={'leaf':b,'call':m.s64(b+7),'tail':m.s64(b+7),'alloc':1,'join':11 if b==0 else m.s64(b+7),'pair':m.s64(2*b+9)}[mode]
   inner=term if mode=='tail' else m.s64(c['depth']*a+c['depth']*(c['depth']+1)//2+term);expect=m.s64(inner+10*a+55);obs={}
   for label,(bp,fc) in images.items():
    e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'clobber-full-state-loader'),str(bp),str(fc[ids[c['outer']]]),'3','aarch64','-',str(a),str(b),'0'],env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
    assert (q.returncode==0)==valid,(c,a,b,fuel,label,q.stdout,q.stderr)
    if valid:assert re.search(r':result '+str(expect)+r'(?:\s|})',q.stdout),(c,a,b,fuel,label,expect,q.stdout)
    assert f':remaining {max(0,fuel-charges)}' in q.stdout,(c,a,b,fuel,q.stdout)
   assert obs['baseline-callee']==obs['candidate-callee'],(c,a,b,fuel,obs);rows.append({'case':c,'a':a,'b':b,'fuel':fuel,'expectedResult':expect if valid else 'trap',**obs})
 print('PASS extra callee/frame/full-state',c,flush=True)
(w/'callee-proof.json').write_text(json.dumps({'status':'complete-independent-native-callee-frame-call-tail-RET2-join-allocating-fullstate-proof','comparisons':len(rows),'cases':cs,'observations':rows},indent=2)+'\n');print('PASS',len(rows),'extra callee state comparisons',flush=True)
