from pathlib import Path
import shutil,json,hashlib,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-loop-temp-registers-20261006');b=Path('/private/tmp/amu-loop-high-temp-20261006')
g=(r/'seed/41-a64gen.kotoba').read_text();(w/'baseline-41-a64gen.kotoba').write_text(g)
def replace(a,c):
 global g
 assert g.count(a)==1,(a,g.count(a));g=g.replace(a,c,1)
replace('(def gn-cap 4096)', '(def gn-f-nt 13)      ; additional callee registers for temps, after locals\n(def gn-cap 4096)')
replace(';; ---- constants ', ''';; Canonical expression registers: low caller-saved, then unused callee-saved.
;; Locals retain the original allocation. Mapped homes hold caller register
;; backups only, never expression values; original frame size is unchanged.
(defn- gn-treg [M :vector-i64 t :i64] :i64
 (cond (< t 7) (+ 9 t)
       (< t (+ 7 (gn-g M gn-f-nt))) (+ 19 (gn-g M gn-f-nsv) (- t 7))
       :else -1))

;; ---- constants ''')
replace('          (< t 7) (+ 9 t)\n          :else -1)))','          :else (gn-treg M t))))')
replace('          (< t 7) (-> M (gn-into (+ 9 t) t) (gn-dset t gn-k-reg 0))','          (>= (gn-treg M t) 0) (-> M (gn-into (gn-treg M t) t) (gn-dset t gn-k-reg 0))')
replace('(cond (> s 0) (gn-sreg M s) (< t 7) (+ 9 t) :else 16)', '(cond (> s 0) (gn-sreg M s) (>= (gn-treg M t) 0) (gn-treg M t) :else 16)')
replace('        (>= t 7) (-> M (gn-st d (gn-home M t)) (gn-def t gn-k-reg 0))', '        (< (gn-treg M t) 0) (-> M (gn-st d (gn-home M t)) (gn-def t gn-k-reg 0))')
replace('(and (= s 0) (>= t 7))','(and (= s 0) (< (gn-treg M t) 0))')
replace('(gn-gs M2 gn-f-fb (if framed (+ (gn-r16 (* 8 (+ ns dp 2))) (gn-r16 (* 8 nsv)) (gn-g M2 gn-f-out)) 0))', '(-> M2 (gn-gs gn-f-nt (gn-min (gn-max 0 (- dp 7)) (- 10 nsv)))\n        (gn-gs gn-f-fb (if framed (+ (gn-r16 (* 8 (+ ns dp 2))) (gn-r16 (* 8 nsv)) (gn-g M2 gn-f-out)) 0)))')
replace(';; params x0.. -> their slots', ''';; Save/restore added callee registers in their unused original temp homes.
(defn- gn-tsave [M :vector-i64 i :i64 ld :i64] :vector-i64
 (if (>= i (gn-g M gn-f-nt)) M
  (let [t (+ 7 i) reg (gn-treg M t)]
   (gn-tsave (if (= ld 1) (gn-ld M reg (gn-home M t)) (gn-st M reg (gn-home M t))) (inc i) ld))))
;; params x0.. -> their slots''')
replace('(gn-csave 0 (gn-g M2 gn-f-nsv) 0)))','(gn-csave 0 (gn-g M2 gn-f-nsv) 0)\n                                      (gn-tsave 0 0)))')
replace('(-> (gn-csave 0 (gn-g M gn-f-nsv) 1)\n', '(-> (gn-tsave 0 1) (gn-csave 0 (gn-g M gn-f-nsv) 1)\n')
(w/'41-a64gen-prototype.kotoba').write_text(g)
parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')]
(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader'),('clobber-full-state-loader','clobber-full-state-loader')]:shutil.copy2(b/src,w/dst)
for name in ['build.py','check-ports.py','permanent-regression.py','ports-state.py']:
 s=(b/name).read_text().replace('amu-loop-high-temp-20261006','amu-loop-temp-registers-20261006')
 if name=='ports-state.py':s=s.replace("b=Path('/private/tmp/amu-affine-reader-20261005')", "b=Path('/private/tmp/amu-loop-high-temp-20261006')")
 (w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'status':'registered-before-build-and-measurement','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'baselineSeedSha256':hashlib.sha256((w/'seed-0.bin').read_bytes()).hexdigest(),'hypothesis':'Use unused callee registers for high temps without growing original frame; save them in the mapped original homes, preserve local allocation and all execution contracts.','authoringException':'One-off new experimental Kotoba register-allocation algorithm, no mechanical rule covers it. Product sources remain unchanged until native correctness and prospective timing qualify.','timingRule':'Original all19 workload unchanged; fresh30 triples each changed guest; load<=4 idle>=90 RSD<=10 ratio>=1.05 meanGap>sumSD; no officialscoreclaim.','proofRequirements':'Native fixedpoint; all7989 existing result/trap regressions; original19fullstate/fuel; independent additional callee/frame/call/tail/RET2/alias/import/resource proofs before timing.'},indent=2)+'\n')
print('registered experimental allocator, source unchanged')
