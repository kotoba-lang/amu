import json,pathlib,subprocess,re,os,hashlib
r=pathlib.Path('/Users/junkawasaki/github/wt/amu-seed17');w=pathlib.Path('/private/tmp/amu-scalar-tree-20261005');seed=w/'seed-4.bin';loader=w/'kexe-loader';baseline=json.loads(pathlib.Path('/private/tmp/amu-sign-wrapper-20261005/ports-correctness.json').read_text());matrix=json.loads((r/'bench/embench/comparison-matrix.json').read_text());runner='/private/tmp/amu-embench-compare-20261004/runner';report={'status':'running','entries':[]};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save():(w/'ports-correctness.json').write_text(json.dumps(report,indent=2)+'\n')
for e in matrix['entries']:
 name=e['workload'];d=w/'ports-2'/name;d.mkdir(parents=True);s=r/e['source'];assert sha(s)==e['expectedSourceSha256'];env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
 for label,args in [('compile',['compile',str(s),'--target','aarch64-macos','--output',str(d/'image.kseed')]),('extract',['extract-native',str(d/'image.kseed'),'--symbol',e['symbol'],'--output',str(d/'native.bin')])]:
  p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(name,label,p.stdout,p.stderr)
 off=int(re.search(r':offset (\d+)',(d/'extract.log').read_text()).group(1));b=next(x for x in baseline['entries'] if x['workload']==name);runs=[]
 for x in b['runs']:
  p=subprocess.run([runner,'raw',str(d/'native.bin'),str(off),'aarch64',str(x['n']),'1','0','16777216'],capture_output=True,text=True);assert p.returncode==0,(name,p.stderr);v=json.loads(p.stdout);assert v['result']==x['result'] and v['contextFuelConsumed']==x['fuelConsumed'],(name,x,v);runs.append({'n':x['n'],'result':v['result'],'fuelConsumed':v['contextFuelConsumed']})
 p=subprocess.run([runner,'raw',str(d/'native.bin'),str(off),'aarch64','1','1','0','1'],capture_output=True,text=True);assert p.returncode==b['fuelTrapReturncode'],(name,p.returncode)
 report['entries'].append({'workload':name,'sourceSha256':sha(s),'nativeSha256':sha(d/'native.bin'),'offset':off,'runs':runs,'fuelTrapReturncode':p.returncode});save();print('PASS',name,flush=True)
report['status']='complete-result-and-exact-fuel-parity';save()
