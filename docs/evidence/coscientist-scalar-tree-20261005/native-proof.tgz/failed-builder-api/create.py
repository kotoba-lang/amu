from pathlib import Path
import json,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-scalar-tree-20261005');g=(r/'seed/41-a64gen.kotoba').read_text()
proof=''';; A whole pure scalar threshold tree; return the exclusive SIR end or0.
;; Exact operands and actual branch target positions are checked recursively.
(defn- gn-tree-end [M :vector-i64 p :i64 depth :i64] :i64
  (if (or (> depth 7) (>= p (vector-at M MM-SIR-N))) 0
    (if (and (= (gn-op M p) OP-CONST) (= (gn-sir M p IF-A) 0) (= (gn-sir M p IF-C) 0)) (inc p)
      (if (and (= (gn-op M p) OP-LGET) (= (gn-sir M p IF-A) 0) (= (gn-sir M p IF-B) 1) (= (gn-sir M p IF-C) 0)
               (= (gn-op M (+ p 1)) OP-CONST) (= (gn-sir M (+ p 1) IF-A) 1) (= (gn-sir M (+ p 1) IF-C) 0)
               (> (gn-sir M (+ p 1) IF-B) 0) (< (gn-sir M (+ p 1) IF-B) 64)
               (= (gn-op M (+ p 2)) OP-CMP) (= (gn-sir M (+ p 2) IF-A) CC-LT) (= (gn-sir M (+ p 2) IF-B) 0) (= (gn-sir M (+ p 2) IF-C) 0)
               (= (gn-op M (+ p 3)) OP-BRZ) (= (gn-sir M (+ p 3) IF-A) 0) (= (gn-sir M (+ p 3) IF-C) 0))
        (let [a (gn-tree-end M (+ p 4) (inc depth)) le (gn-sir M (+ p 3) IF-B)]
          (if (and (> a 0) (= (gn-op M a) OP-BR) (= (gn-sir M a IF-B) 0) (= (gn-sir M a IF-C) 0)
                   (= (gn-op M (inc a)) OP-LABEL) (= (gn-sir M (inc a) IF-A) le)
                   (= (gn-sir M (inc a) IF-B) 0) (= (gn-sir M (inc a) IF-C) 0) (= (gn-lpos M le) (inc a)))
            (let [b (gn-tree-end M (+ a 2) (inc depth)) lx (gn-sir M a IF-A)]
              (if (and (> b 0) (= (gn-op M b) OP-LABEL) (= (gn-sir M b IF-A) lx)
                       (= (gn-sir M b IF-B) 0) (= (gn-sir M b IF-C) 0) (= (gn-lpos M lx) b)) (inc b) 0)) 0)) 0))))
(defn- gn-tree-value [M :vector-i64 p :i64 x :i64] :i64
  (if (= (gn-op M p) OP-CONST) (gn-sir M p IF-B)
    (gn-tree-value M (if (< x (gn-sir M (inc p) IF-B)) (+ p 4) (inc (gn-lpos M (gn-sir M (+ p 3) IF-B)))) x)))
(defn- gn-tree-data [M :vector-i64 p :i64 x :i64] :vector-i64
  (if (= x 64) M (let [v (gn-tree-value M p x)]
    (gn-tree-data (-> M (gn-emit (bit-and v 0xffffffff)) (gn-emit (bit-and (i64-shift-right v 32) 0xffffffff))) p (inc x)))))
(defn- gn-tree-emit [M :vector-i64 p :i64 charge :i64] :vector-i64
  (let [M0 (cond-> M (= charge 1) (gn-op-fuel))
        M1 (-> M0 (gn-slot 9 1) (gn-emit (enc-cmp-i 9 0))) low (vector-at M1 MM-CODE-N)
        M2 (-> M1 (gn-emit (enc-bcond (enc-cond-lt) 0)) (gn-emit (enc-cmp-i 9 63))) high (vector-at M2 MM-CODE-N)
        M3 (gn-emit M2 (enc-bcond (enc-cond-gt) 0)) adr (vector-at M3 MM-CODE-N)
        M4 (-> M3 (gn-emit (gn-e-adr 10)) (gn-emit (gn-e-ldrr 0 10 9 1)) (gn-epilogue))
        l (vector-at M4 MM-CODE-N) M5 (-> M4 (gn-const 0 (gn-tree-value M p 0)) (gn-epilogue))
        h (vector-at M5 MM-CODE-N) M6 (-> M5 (gn-const 0 (gn-tree-value M p 63)) (gn-epilogue))
        table (vector-at M6 MM-CODE-N) delta (* (- table adr) 4)
        M7 (gn-tree-data M6 p 0)]
    (-> M7 (gn-put (+ MM-CODE-BASE low) (enc-bcond (enc-cond-lt) (- l low)))
           (gn-put (+ MM-CODE-BASE high) (enc-bcond (enc-cond-gt) (- h high)))
           (gn-put (+ MM-CODE-BASE adr) (+ (gn-e-adr 10) (i64-shift-left (bit-and delta 3) 29) (i64-shift-left (i64-shift-right delta 2) 5)))
           (gn-gs 14 1))))
(defn- gn-tree-entry [M :vector-i64 f :i64] :vector-i64
  (let [a (gn-fnf M f FF-SIR) charge (if (= (gn-op M (inc a)) OP-FUEL) 1 0)
        label (+ a 1 charge) p (inc label)]
    (if (and (= (gn-sir M a IF-B) 1) (= (gn-g M gn-f-leaf) 1)
             (= (gn-op M label) OP-LABEL) (= (gn-sir M label IF-B) 0) (= (gn-sir M label IF-C) 0)
             (or (= charge 0) (and (= (gn-sir M (inc a) IF-A) 0) (= (gn-sir M (inc a) IF-B) 0) (= (gn-sir M (inc a) IF-C) 0))))
      (let [end (gn-tree-end M p 0)]
        (if (and (> (- end p) 128) (= (gn-op M end) OP-RET) (= (gn-sir M end IF-A) 0) (= (gn-sir M end IF-B) 0) (= (gn-sir M end IF-C) 0)
                 (= (gn-op M (inc end)) OP-END) (= (gn-sir M (inc end) IF-A) f) (= (gn-sir M (inc end) IF-B) 0) (= (gn-sir M (inc end) IF-C) 0))
          (gn-tree-emit M p charge) M)) M)))
'''
a=';; ---- FLOAT (agent FLOAT';assert g.count(a)==1;g=g.replace(a,proof+'\n'+a)
a='(gn-gs gn-f-h 0)))))))';assert g.count(a)==1;g=g.replace(a,'(gn-gs gn-f-h 0) (gn-tree-entry f)))))))')
a='(if (and (= (gn-g M gn-f-dead) 1) (not (or (= op OP-LABEL) (= op OP-FN) (= op OP-END))))';assert g.count(a)==1;g=g.replace(a,'(if (or (and (= (gn-g M 14) 1) (not (or (= op OP-FN) (= op OP-END))))\n            (and (= (gn-g M gn-f-dead) 1) (not (or (= op OP-LABEL) (= op OP-FN) (= op OP-END)))))')
(w/'41-a64gen-prototype.kotoba').write_text(g);files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
for ext in ['bin','offset']:shutil.copyfile(Path('/private/tmp/amu-sign-wrapper-20261005')/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile('/private/tmp/amu-sign-wrapper-20261005/kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['build.py','check-ports.py','bulk-state.py','remote.py']:(w/name).write_text(Path('/private/tmp/amu-bounded-fill-20261005',name).read_text().replace('amu-bounded-fill-20261005','amu-scalar-tree-20261005').replace('amu-zebulun-bounded-fill-20261005','amu-zebulun-scalar-tree-20261005'))
(w/'hypothesis.json').write_text(json.dumps({'hypothesis':'Prove complete pure one-argument integer threshold tree (thresholds1..63, literal leaves, exact branch targets). Emit native64-entry i64 table with saturated signed full-domain endpoints, preserving optional entry fuel. No function names or memoization. Target repeated coefficient position lookup.','promotion':'Fresh30 quiet rotating triples; >=1.05 speedup and gap>sumSD; fixedpoint, canonical result/exactfuel/trap/state parity.','sourceHead':'c6300527d8b930b06df332e982d9d2def344905d','exception':'One-off compiler algorithm authoring, not mechanical refactoring'},indent=2)+'\n')
