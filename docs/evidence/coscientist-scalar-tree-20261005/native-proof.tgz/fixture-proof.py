from pathlib import Path
import importlib.util,subprocess,os,re,json,types,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-scalar-tree-20261005');sp=importlib.util.spec_from_file_location('fx',r/'scripts/seed/a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)

leaves=[m.MIN,m.MAX,-1,0,1,-4294967297,4294967297,65535]*8
values=[m.MIN,m.MIN+1,-65537,-65,-2,-1,*range(66),127,65535,m.MAX-1,m.MAX]
def rows(name,lo,hi,mode='lt',outer=False):
 if hi-lo==1:return [('LGET',0,1)] if mode=='value' and lo==3 else [('CONST',0,leaves[lo])]
 mid=(lo+hi)//2;threshold=mid if mode not in ['negative','outside'] or not outer else -1 if mode=='negative' else 65
 le=f'{name}_{lo}_{hi}_else';lx=f'{name}_{lo}_{hi}_end';cc='CC-EQ' if mode=='eq' and outer else 'CC-LT'
 return [('LGET',0,1),('CONST',1,threshold),('CMP',cc,0),('BRZ',0,le)]+rows(name,lo,mid,mode)+[('BR',lx),('LABEL',le)]+rows(name,mid,hi,mode)+[('LABEL',lx)]
def expected(x,lo,hi,mode='lt',outer=False):
 if hi-lo==1:return x if mode=='value' and lo==3 else leaves[lo]
 mid=(lo+hi)//2;t=mid if mode not in ['negative','outside'] or not outer else -1 if mode=='negative' else 65;pick=x==t if mode=='eq' and outer else x<t
 return expected(x,lo,mid,mode) if pick else expected(x,mid,hi,mode)
for charge in [0,1]:
 for tag,size,mode in [('lt64',64,'lt'),('lt32',32,'lt'),('lt16',16,'lt'),('negative',64,'negative'),('outside',64,'outside'),('eq',64,'eq'),('value',64,'value')]:
  name=f'tree{charge}_{tag}';body=([('FUEL',)] if charge else [])+[('LABEL',name+'_root')]+rows(name,0,size,mode,True)+[('RET',0)];m.fx(name,1,1,body)
  caller='call_'+name;m.fx(caller,1,1,[('FUEL',),('FUEL',),('LGET',0,1),('CALL',name,0,1),('RET',0)])
  for x in values:m.run(caller,[x],expected(x,0,size,mode,True),fuel=2+charge)
  for fuel in range(1,2+charge):m.run(caller,[m.MIN],'trap',fuel=fuel)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800');loader=str(w/'kexe-loader');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];chunks=[]
for real in [False,True]:
 prefix='fixture-real' if real else 'fixture-test';src=w/(prefix+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real))
 for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(prefix+'.kseed'))]),('extract',['extract-native',str(w/(prefix+'.kseed')),'--symbol','main','--output',str(w/(prefix+'.bin'))])]:
  p=subprocess.run([loader,str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(prefix+'-'+label+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(label,p.stdout,p.stderr)
  if label=='extract':off=re.search(r':offset (\d+)',p.stdout).group(1)
 p=subprocess.run([loader,str(w/(prefix+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(prefix+'.stdout')).write_text(p.stdout);assert p.returncode==0,p.stderr;chunks.append(p.stdout)
assert m.blob_from(chunks[0])[0].rstrip(b'\0')==m.blob_from(chunks[1])[0].rstrip(b'\0') and m.blob_from(chunks[0])[1]==m.blob_from(chunks[1])[1]
d=w/'fixture-run/unit/41-a64gen';d.mkdir(parents=True,exist_ok=True);(d/'stdout').write_text(chunks[1]);os.environ['SEED_BUILD']=str(w/'fixture-run');original=m.subprocess.run

def run(args,**kw):
 if args[:2]==['zsh',m.R+'/scripts/seed/unit.sh']:return types.SimpleNamespace(returncode=0,stdout='native experimental fixture emitter already verified; byte golden untouched',stderr='')
 return original(args,**kw)
m.subprocess.run=run;assert m.runs(False)==0
blob,fns=m.blob_from(chunks[1]);names=[f[0] for f in m.FIX];audit={}
for name in ['tree0_lt64','tree1_lt64','tree0_lt32','tree1_lt32']:
 f=names.index(name)+1;end=fns.get(f+1);code=blob[fns[f]:end];words=struct.unpack('<'+'I'*(len(code)//4),code);adrs=[i for i,x in enumerate(words) if (x&0x9f000000)==0x10000000 and (x&31)==10];assert len(adrs)==1,(name,adrs);j=adrs[0];v=words[j];delta=(((v>>5)&0x7ffff)<<2)|((v>>29)&3);delta=delta-(1<<21) if delta&(1<<20) else delta;table=j*4+delta;data=struct.unpack('<64q',code[table:table+512]);size=64 if name.endswith('64') else 32;assert list(data)==[expected(x,0,size) for x in range(64)],(name,data);prefix=words[:table//4];bl=sum((x&0xfc000000)==0x94000000 for x in prefix);blr=sum((x&0xfffffc1f)==0xd63f0000 for x in prefix);rets=sum(x==0xd65f03c0 for x in prefix);assert bl==blr==0 and rets==3,(name,bl,blr,rets);assert words[j+1]==0xf8697940,(name,hex(words[j+1]));audit[name]={'directBL':bl,'indirectBLR':blr,'returnPaths':rets,'tableEntries':64,'tableValuesIndependentlyChecked':True,'bytes':len(code),'instructionBytesBeforeTable':table}
for name in ['tree0_lt16','tree1_negative','tree1_outside','tree1_eq','tree1_value']:
 f=names.index(name)+1;end=fns.get(f+1);words=struct.unpack('<'+'I'*((end-fns[f])//4),blob[fns[f]:end]);assert not any((x&0x9f000000)==0x10000000 and (x&31)==10 for x in words),name;audit[name]={'tableAdmission':False}
(w/'fixture-proof.json').write_text(json.dumps({'runs':len(m.RUNS),'fixtures':len(m.FIX),'realTestLayoutIdentical':True,'instructionAudit':audit},indent=2)+'\n');print('PASS scalar-tree lookup payload and fallback audits',flush=True)
