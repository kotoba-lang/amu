from pathlib import Path
import subprocess,os,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-scalar-tree-20261005'); base=Path('/private/tmp/amu-sign-wrapper-20261005')
loader=w/'kexe-loader';runner=Path('/private/tmp/amu-embench-compare-20261004/runner');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
report={'hypothesis':'proved threshold tree table','rows':[]};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def compile(seed,src,d,symbols):
 d.mkdir(exist_ok=True,parents=True);out=d/'image.kseed'
 p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--','compile',str(src),'--target','aarch64-macos','--output',str(out)],env=env,capture_output=True,text=True);(d/'compile.log').write_text(p.stdout+p.stderr);assert p.returncode==0,(src,p.stdout,p.stderr)
 offsets={}
 for symbol in symbols:
  p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--','extract-native',str(out),'--symbol',symbol,'--output',str(d/'native.bin')],env=env,capture_output=True,text=True);(d/(symbol+'.extract.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(symbol,p.stderr);offsets[symbol]=int(re.search(r':offset (\d+)',p.stdout).group(1))
 return offsets
def run(d,off,n,fuel=16777216):
 e=dict(env,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
 p=subprocess.run([str(loader),str(d/'native.bin'),str(off),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True)
 if p.returncode==0:
  m=re.search(r':result (-?\d+)',p.stdout);assert m,(n,fuel,p.stdout);value={'result':int(m.group(1))}
 else:
  assert 'KEXE_TRAP' in p.stderr,(n,fuel,p.returncode,p.stdout,p.stderr)
  value=None
 m=re.search(r':fuel \{:initial (\d+) :remaining (\d+)\}',p.stdout);assert m,(n,fuel,p.stdout,p.stderr);consumed=int(m.group(1))-int(m.group(2));return {'exit':p.returncode,'value':value,'fuelConsumed':consumed,'structuredReport':p.stdout.strip(),'traps':re.findall(r'^KEXE_TRAP.*$',p.stderr,re.M)}

MIN=-(1<<63);MAX=(1<<63)-1
leaves=[MIN,MAX,-1,0,1,-4294967297,4294967297,65535]*8

def tree(lo,hi,mode='lt',outer=False):
 if hi-lo==1:return str(leaves[lo]) if mode!='value' or lo!=3 else 'x'
 mid=(lo+hi)//2;threshold=mid if mode not in ['negative','outside'] or not outer else -1 if mode=='negative' else 65
 cc='=' if mode=='eq' and outer else '<'
 return f'(if ({cc} x {threshold}) {tree(lo,mid,mode)} {tree(mid,hi,mode)})'

def expect(x,lo,hi,mode='lt',outer=False):
 if hi-lo==1:return leaves[lo] if mode!='value' or lo!=3 else x
 mid=(lo+hi)//2;t=mid if mode not in ['negative','outside'] or not outer else -1 if mode=='negative' else 65
 pick=x==t if mode=='eq' and outer else x<t
 return expect(x,lo,mid,mode) if pick else expect(x,mid,hi,mode)

forms=[];cases=[]
for mode,size in [('lt',64),('lt32',32),('lt16',16),('negative',64),('outside',64),('eq',64),('value',64)]:
 fn='f-'+mode;actual='lt' if mode.startswith('lt') else mode
 forms.append(f'(defn- {fn} [x :i64] :i64 {tree(0,size,actual,True)})')
 name='call-'+mode;forms.append(f'(defn {name} [x :i64] :i64 ({fn} x))');cases.append((name,size,actual))
forms+=['(defn bad [x :i64] :i64 (let [v (vector-alloc 0)] (vector-at v x)))'];cases.append(('bad',0,'trap'))
symbols=[c[0] for c in cases];src=w/'probe.kotoba';src.write_text('(ns probe (:export ['+' '.join(symbols)+']))\n'+'\n'.join(forms)+'\n')
a=w/'probe-baseline';b=w/'probe-candidate';oa=compile(base/'seed-4.bin',src,a,symbols);ob=compile(w/'seed-4.bin',src,b,symbols)
values=[MIN,MIN+1,-65537,-65,-2,-1,*range(0,66),127,65535,MAX-1,MAX]
for symbol,size,kind in cases:
 for n in values:
  for fuel in [1,2,3,16777216]:
   x=run(a,oa[symbol],n,fuel);y=run(b,ob[symbol],n,fuel);assert x==y,(symbol,n,fuel,x,y)
   if fuel==16777216:
    if kind=='trap':assert x['exit']!=0 and any('SIGILL' in z for z in x['traps'])
    else:assert x['exit']==0 and x['value']['result']==expect(n,0,size,kind,True),(symbol,n,x)
   report['rows'].append({'symbol':symbol,'input':n,'fuel':fuel,**x})
 print('PASS source',symbol,flush=True);(w/'correctness.json').write_text(json.dumps(report,indent=2)+'\n')
report['status']='complete-signed-exact-fuel-trap-resource-parity';report['sourceSha256']=sha(src);(w/'correctness.json').write_text(json.dumps(report,indent=2)+'\n')
