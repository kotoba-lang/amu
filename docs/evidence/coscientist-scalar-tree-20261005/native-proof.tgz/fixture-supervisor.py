from pathlib import Path
import subprocess,os,json,re
w=Path('/private/tmp/amu-scalar-tree-20261005');scope={};s=(w/'fixture-proof.py').read_text();exec(s[:s.index('env=dict(')],scope);m=scope['m'];r=scope['r'];prefix='fixture-baseline-real';src=w/(prefix+'.kotoba');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba','seed/41-a64gen.kotoba','seed/42-layout.kotoba'];src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+m.kotoba(True));loader=str(w/'kexe-loader');seed='/private/tmp/amu-sign-wrapper-20261005/seed-4.bin';env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800')
for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(prefix+'.kseed'))]),('extract',['extract-native',str(w/(prefix+'.kseed')),'--symbol','main','--output',str(w/(prefix+'.bin'))])]:
 p=subprocess.run([loader,seed,'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(prefix+'-'+stage+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(stage,p.stdout,p.stderr)
 if stage=='extract':off=re.search(r':offset (\d+)',p.stdout).group(1)
p=subprocess.run([loader,str(w/(prefix+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(prefix+'.stdout')).write_text(p.stdout);assert p.returncode==0,p.stderr
base,fa=m.blob_from(p.stdout);cand,fb=m.blob_from((w/'fixture-real.stdout').read_text());(w/'fixture-baseline-code.bin').write_bytes(base);(w/'fixture-candidate-code.bin').write_bytes(cand);names=[f[0] for f in m.FIX];rows=[]
def run(path,off,args,budget):
 e=dict(os.environ,KEXE_FUEL=str(budget),KEXE_STRUCTURED_REPORT='1')
 p=subprocess.run([loader,str(path),str(off),str(len(args)),'aarch64','-',*map(str,args)],env=e,capture_output=True,text=True);q=re.search(r':fuel \{:initial (\d+) :remaining (\d+)\}',p.stdout);assert q,(path,args,budget,p.stdout,p.stderr)
 if p.returncode:assert 'KEXE_TRAP' in p.stderr,(path,p.stderr)
 return {'exit':p.returncode,'report':p.stdout.strip(),'fuelConsumed':int(q.group(1))-int(q.group(2)),'traps':re.findall(r'^KEXE_TRAP.*$',p.stderr,re.M)}
for charge in [0,1]:
 for tag in ['lt64','lt32','lt16','negative','outside','eq','value']:
  fn=f'call_tree{charge}_{tag}';f=names.index(fn)+1
  for n in [m.MIN,m.MIN+1,-1,0,1,3,31,32,63,64,m.MAX]:
   for budget in [1,2,3,4,16777216]:
    a=run(w/'fixture-baseline-code.bin',fa[f],[n],budget);b=run(w/'fixture-candidate-code.bin',fb[f],[n],budget);assert a==b,(fn,n,budget,a,b);rows.append({'function':fn,'input':n,'fuel':budget,**a})
  print('PASS exact supervisor',fn,flush=True)
(w/'fixture-supervisor.json').write_text(json.dumps({'status':'complete-handwritten-baseline-candidate-exact-supervisor-report-parity','comparisons':len(rows),'rows':rows},indent=2)+'\n')
