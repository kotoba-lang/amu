from pathlib import Path
w=Path('/private/tmp/amu-scalar-tree-20261005');s=Path('/private/tmp/amu-index-write-20261005/fixture-proof.py').read_text();prefix=s[:s.index('sign=')].replace('amu-index-write-20261005','amu-scalar-tree-20261005');tail=s[s.index('env=dict('):s.index("for name in ['call_iw")]
body='''leaves=[m.MIN,m.MAX,-1,0,1,-4294967297,4294967297,65535]*8
values=[m.MIN,m.MIN+1,-65537,-65,-2,-1,*range(66),127,65535,m.MAX-1,m.MAX]
def rows(name,lo,hi,mode='lt',outer=False):
 if hi-lo==1:return [('LGET',0,1)] if mode=='value' and lo==3 else [('CONST',0,leaves[lo])]
 mid=(lo+hi)//2;threshold=mid if mode not in ['negative','outside'] or not outer else -1 if mode=='negative' else 65
 le=f'{name}_{lo}_{hi}_else';lx=f'{name}_{lo}_{hi}_end';cc='CC-EQ' if mode=='eq' and outer else 'CC-LT'
 return [('LGET',0,1),('CONST',1,threshold),('CMP',cc,0),('BRZ',0,le)]+rows(name,lo,mid,mode)+[('BR',lx),('LABEL',le)]+rows(name,mid,hi,mode)+[('LABEL',lx)]
def expected(x,lo,hi,mode='lt',outer=False):
 if hi-lo==1:return x if mode=='value' and lo==3 else leaves[lo]
 mid=(lo+hi)//2;t=mid if mode not in ['negative','outside'] or not outer else -1 if mode=='negative' else 65;pick=x==t if mode=='eq' and outer else x<t
 return expected(x,lo,mid,mode) if pick else expected(x,mid,hi,mode)
for charge in [0,1]:
 for tag,size,mode in [('lt64',64,'lt'),('lt32',32,'lt'),('lt16',16,'lt'),('negative',64,'negative'),('outside',64,'outside'),('eq',64,'eq'),('value',64,'value')]:
  name=f'tree{charge}_{tag}';body=([('FUEL',)] if charge else [])+[('LABEL',name+'_root')]+rows(name,0,size,mode,True)+[('RET',0)];m.fx(name,1,1,body)
  caller='call_'+name;m.fx(caller,1,1,[('FUEL',),('FUEL',),('LGET',0,1),('CALL',name,0,1),('RET',0)])
  for x in values:m.run(caller,[x],expected(x,0,size,mode,True),fuel=2+charge)
  for fuel in range(1,2+charge):m.run(caller,[m.MIN],'trap',fuel=fuel)
'''
audit='''for name in ['tree0_lt64','tree1_lt64','tree0_lt32','tree1_lt32']:
 f=names.index(name)+1;end=fns.get(f+1);code=blob[fns[f]:end];words=struct.unpack('<'+'I'*(len(code)//4),code);adrs=[i for i,x in enumerate(words) if (x&0x9f000000)==0x10000000 and (x&31)==10];assert len(adrs)==1,(name,adrs);j=adrs[0];v=words[j];delta=(((v>>5)&0x7ffff)<<2)|((v>>29)&3);delta=delta-(1<<21) if delta&(1<<20) else delta;table=j*4+delta;data=struct.unpack('<64q',code[table:table+512]);size=64 if name.endswith('64') else 32;assert list(data)==[expected(x,0,size) for x in range(64)],(name,data);prefix=words[:table//4];bl=sum((x&0xfc000000)==0x94000000 for x in prefix);blr=sum((x&0xfffffc1f)==0xd63f0000 for x in prefix);rets=sum(x==0xd65f03c0 for x in prefix);assert bl==blr==0 and rets==3,(name,bl,blr,rets);assert words[j+1]==0xf8697940,(name,hex(words[j+1]));audit[name]={'directBL':bl,'indirectBLR':blr,'returnPaths':rets,'tableEntries':64,'tableValuesIndependentlyChecked':True,'bytes':len(code),'instructionBytesBeforeTable':table}
for name in ['tree0_lt16','tree1_negative','tree1_outside','tree1_eq','tree1_value']:
 f=names.index(name)+1;end=fns.get(f+1);words=struct.unpack('<'+'I'*((end-fns[f])//4),blob[fns[f]:end]);assert not any((x&0x9f000000)==0x10000000 and (x&31)==10 for x in words),name;audit[name]={'tableAdmission':False}
(w/'fixture-proof.json').write_text(json.dumps({'runs':len(m.RUNS),'fixtures':len(m.FIX),'realTestLayoutIdentical':True,'instructionAudit':audit},indent=2)+'\\n');print('PASS scalar-tree lookup payload and fallback audits',flush=True)
'''
(w/'fixture-proof.py').write_text(prefix+body+tail+audit)
