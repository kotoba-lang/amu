#include "c-bridge.c"
#include <stdio.h>
int main(void){for(int n=1;n<=32;n++){if(oracle_selfcheck(n,0,0,0,0,0,0,0)!=1||bench(n,0,0,0,0,0,0,0)!=1)return 1;for(int f=0;f<4;f++)observe(n*4+f,0,0,0,0,0,0,0);}printf("PASS 32 original bodies/verifiers, 128 initialized observations\n");return 0;}
