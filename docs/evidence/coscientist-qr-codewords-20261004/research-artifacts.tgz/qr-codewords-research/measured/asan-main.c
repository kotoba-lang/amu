/* BOOTSTRAP-TOOL: valid initialized fragment accesses only. */
#include "c-bridge.c"
int main(void){init_heap_beebs(heap,8192);initeccsize(1,22);if(VERSION!=2||WD!=25||WDB!=4||neccblk1!=1||neccblk2!=0||datablkw!=34||eccblkwid!=10)return 2;for(int c=0;c<4;c++){
 if(oracle_selfcheck(c,0,0,0,0,0,0,0)!=1)return 1;
 for(int stage=0;stage<5;stage++)for(int cell=0;cell<1024;cell++)(void)observe(c*8192+stage*1024+cell,0,0,0,0,0,0,0);
}return 0;}
