/* BOOTSTRAP-TOOL: original QR codeword functions with snapshots only.
 * Copyright 2014-2019 Embecosm/Bristol; GPL-3.0-or-later. */
#include <stdint.h>
#include <limits.h>
#include <string.h>
#include "../upstream/src/qrduino/qrencode.c"
#include "../upstream/support/beebsc.h"
static unsigned char heap[8192] __attribute__((aligned));
static int64_t states[5][1024];static unsigned char poly[11];
static const char *payloads[]={"http://www.mageec.com","AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","","0123456789012345678901234567890123456789"};
static void snapshot(int stage){for(int i=0;i<768;i++)states[stage][i]=strinbuf[i];for(int i=0;i<11;i++)states[stage][768+i]=poly[i];for(int i=0;i<44;i++)states[stage][800+i]=qrframe[i];}
static void observed(int c){memset(states,0,sizeof(states));memset(heap,0,sizeof(heap));memset(poly,0,sizeof(poly));init_heap_beebs(heap,8192);initecc(1,2);memcpy(strinbuf,payloads[c],strlen(payloads[c])+1);snapshot(0);

  unsigned i;
  unsigned size, max;
  size = strlen ((char *) strinbuf);

  max = datablkw * (neccblk1 + neccblk2) + neccblk2;
  if (size >= max - 2)
    {
      size = max - 2;
      if (VERSION > 9)
	size--;
    }

  i = size;
  if (VERSION > 9)
    {
      strinbuf[i + 2] = 0;
      while (i--)
	{
	  strinbuf[i + 3] |= strinbuf[i] << 4;
	  strinbuf[i + 2] = strinbuf[i] >> 4;
	}
      strinbuf[2] |= size << 4;
      strinbuf[1] = size >> 4;
      strinbuf[0] = 0x40 | (size >> 12);
    }
  else
    {
      strinbuf[i + 1] = 0;
      while (i--)
	{
	  strinbuf[i + 2] |= strinbuf[i] << 4;
	  strinbuf[i + 1] = strinbuf[i] >> 4;
	}
      strinbuf[1] |= size << 4;
      strinbuf[0] = 0x40 | (size >> 4);
    }
  i = size + 3 - (VERSION < 10);
  while (i < max)
    {
      strinbuf[i++] = 0xec;
      // buffer has room        if (i == max)            break;
      strinbuf[i++] = 0x11;
    }

  snapshot(1);
  // calculate and append ECC
  unsigned char *ecc = &strinbuf[max];
  unsigned char *dat = strinbuf;
  initrspoly (eccblkwid, qrframe);
  memcpy(poly,qrframe,11);snapshot(2);

  for (i = 0; i < neccblk1; i++)
    {
      appendrs (dat, datablkw, ecc, eccblkwid, qrframe);
      dat += datablkw;
      ecc += eccblkwid;
    }
  for (i = 0; i < neccblk2; i++)
    {
      appendrs (dat, datablkw + 1, ecc, eccblkwid, qrframe);
      dat += datablkw + 1;
      ecc += eccblkwid;
    }
  snapshot(3);
  unsigned j;
  dat = qrframe;
  for (i = 0; i < datablkw; i++)
    {
      for (j = 0; j < neccblk1; j++)
	*dat++ = strinbuf[i + j * datablkw];
      for (j = 0; j < neccblk2; j++)
	*dat++ = strinbuf[(neccblk1 * datablkw) + i + (j * (datablkw + 1))];
    }
  for (j = 0; j < neccblk2; j++)
    *dat++ = strinbuf[(neccblk1 * datablkw) + i + (j * (datablkw + 1))];
  for (i = 0; i < eccblkwid; i++)
    for (j = 0; j < neccblk1 + neccblk2; j++)
      *dat++ = strinbuf[max + i + j * eccblkwid];
  memcpy (strinbuf, qrframe, max + eccblkwid * (neccblk1 + neccblk2));


snapshot(4);
}
#define EXTRA int64_t x1,int64_t x2,int64_t x3,int64_t x4,int64_t x5,int64_t x6,int64_t ctx
int64_t observe(int64_t encoded,EXTRA){int c=encoded/8192,code=encoded%8192,stage=code/1024,cell=code%1024;if(encoded<0||c>3||stage>4)return INT64_MIN;observed(c);return states[stage][cell];}
int64_t table_cell(int64_t i,EXTRA){if(i<0||i>=512)return INT64_MIN;return i<256?g0log[i]:g0exp[i-256];}
int64_t oracle_selfcheck(int64_t c,EXTRA){if(c<0||c>3)return 0;observed(c);int64_t saved[1024];memcpy(saved,states[4],sizeof(saved));memset(heap,0,sizeof(heap));init_heap_beebs(heap,8192);initecc(1,2);memcpy(strinbuf,payloads[c],strlen(payloads[c])+1);stringtoqr();for(int i=0;i<768;i++)if(strinbuf[i]!=saved[i])return 0;for(int i=0;i<44;i++)if(qrframe[i]!=saved[800+i])return 0;return check_heap_beebs(heap);}
