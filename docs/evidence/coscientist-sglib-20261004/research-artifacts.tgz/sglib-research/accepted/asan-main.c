/* BOOTSTRAP-TOOL: validate observation accesses, no timed instrumentation. */
#include "c-bridge.c"
int main(void){
 for(unsigned n=1;n<=32;n++)if(oracle_selfcheck(n,0,0,0,0,0,0,0)!=1)return 1;
 for(unsigned stage=0;stage<6;stage++)for(unsigned cell=0;cell<1860;cell++)
  (void)observe_stage(stage*4096+cell,0,0,0,0,0,0,0);
 return 0;
}
