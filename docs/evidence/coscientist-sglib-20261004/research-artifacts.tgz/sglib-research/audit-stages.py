import ctypes,json,pathlib,re,subprocess
p=pathlib.Path('/private/tmp/amu-embench-compare-20261004/coscientist-sglib');c=ctypes.CDLL(str(p/'c.dylib'))
for name in ('observe_stage','oracle_selfcheck'):
 f=getattr(c,name);f.restype=ctypes.c_int64;f.argtypes=[ctypes.c_int64]*8
assert c.oracle_selfcheck(0,0,0,0,0,0,0,0)==1
entry=re.search(r':offset (\d+)',(p/'observe-stage-extract.log').read_text()).group(1)
report={'performanceMeasured':False,'unchangedCSelfcheck':True,'cells':[]}
for stage,cells in json.loads((p/'observed-fields.json').read_text())['stages'].items():
 for cell in cells:
  encoded=int(stage)*4096+cell;r=subprocess.run([str(p.parent/'runner'),'raw',str(p/'observe-stage.bin'),entry,'aarch64',str(encoded),'1','0','16777216'],capture_output=True,text=True);assert r.returncode==0,(stage,cell,r)
  v=json.loads(r.stdout)['result'];w=c.observe_stage(encoded,0,0,0,0,0,0,0);assert v==w,(stage,cell,v,w)
  report['cells'].append({'stage':int(stage),'cell':cell,'Kotoba':v,'C':w})
 (p/'stage-results.json').write_text(json.dumps(report,indent=2)+'\n');print('stage',stage,len(cells),'cells match',flush=True)
print('PASS',len(report['cells']),flush=True)
