from pathlib import Path
import importlib.util,subprocess,os,json,re,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-affine-read-20261006');sp=importlib.util.spec_from_file_location('fx',w/'permanent-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);baseFIX=list(m.FIX);cases=[];values=[11-3*j for j in range(8)]
def author(name,t,factor,prefix,mode,admit):
 out=t-2;label=name+'_loop';body=[('FUEL',)]+[('CONST',j,values[j]) for j in range(8)]+[('VEC',0,8),('CONST',0,1),('LSET',5,0),('LABEL',label)]+[('LGET',j,1) for j in range(out)]+[('LGET',out,3),('CONST',t-1,prefix),('LGET',t,1),('CONST',t+1,factor),('BIN','BOP-MUL',t),('LGET',t+1,2),('BIN','BOP-ADD',t),('BIN','BOP-ADD',t-1),('RT','RT-VECTOR-AT',out,2)]
 if mode=='future-index-ret2':body += [('RET2',out),('FUEL',),('BR',label)]
 else:
  if mode in ['alias','coalesced']:body += [('LSET',1 if mode=='alias' else 6,out),('LGET',out,1 if mode=='alias' else 6)]
  body += [('BIN','BOP-ADD',j) for j in range(out-1,-1,-1)]+[('LSET',6,0),('LGET',0,5),('CONST',1,1),('BIN','BOP-SUB',0),('LSET',5,0),('FUEL',)]
  if mode!='cold':body += [('BRNZ',0,label)]
  body += [('LGET',0,6),('RET',0)]
 m.fx(name,3,6,body);entry=name
 if mode=='future-index-ret2':
  entry=name+'_call';m.fx(entry,3,3,[('FUEL',),('LGET',0,1),('LGET',1,2),('LGET',2,3),('CALL',name,0,3),('RES2',1),('BIN','BOP-ADD',0),('RET',0)])
 cases.append({'name':name,'entry':entry,'t':t,'factor':factor,'prefix':prefix,'mode':mode,'admit':admit})
for t in [7,8,10,17,31,63]:
 for factor in [2,20,-3,m.MIN,m.MAX,65537]:
  for prefix in [-4095,0,4095]:
   for mode in ['plain','coalesced','alias']:author('ar_'+str(len(cases)),t,factor,prefix,mode,True)
for mode in ['future-index-ret2','cold','large-prefix','zero-factor','one-factor','minusone-factor']:
 author('ar_refuse_'+mode,7,0 if mode=='zero-factor' else 1 if mode=='one-factor' else -1 if mode=='minusone-factor' else 20,4096 if mode=='large-prefix' else 800,mode,False)
authored=[f for f in m.FIX if f not in baseFIX];allAudits=[];rows=[];env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800')
for batchN,begin in enumerate(range(0,len(cases),24)):
 batch=cases[begin:begin+24];names={c['name'] for c in batch}|{c['entry'] for c in batch};m.FIX=baseFIX+[f for f in authored if f[0] in names];sentinel=next(f for f in baseFIX if f[0]=='ht_cold_control');m.FIX.append(('ar_fixture_sentinel',*sentinel[1:]));ids={f[0]:j+1 for j,f in enumerate(m.FIX)};droot=w/('read-batch-'+str(batchN));droot.mkdir(exist_ok=True);images={}
 for label,gen in [('baseline-read','baseline-41-a64gen.kotoba'),('candidate-read','41-a64gen-prototype.kotoba')]:
  src=droot/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in ['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'])+'\n'+(w/gen).read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+m.kotoba(True))
  for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(droot/(label+'.kseed'))]),('extract',['extract-native',str(droot/(label+'.kseed')),'--symbol','main','--output',str(droot/(label+'.bin'))])]:
   q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(droot/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-300:],q.stderr)
   if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
  q=subprocess.run([str(w/'kexe-loader'),str(droot/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0,(label,q.stdout[-300:],q.stderr);(droot/(label+'.stdout')).write_text(q.stdout);blob,fc=m.blob_from(q.stdout);bp=droot/(label+'-fixture.bin');bp.write_bytes(blob);images[label]=(bp,fc)
  for c in batch:
   k=ids[c['name']];chunk=blob[fc[k]:fc.get(k+1,len(blob))];ws=struct.unpack('<'+'I'*(len(chunk)//4),chunk);madds=[x for x in ws if (x&0xffe08000)==0x9b000000 and ((x>>10)&31)!=31];want=1 if label=='candidate-read' and c['admit'] else 0;assert len(madds)==want,(label,c,madds,want)
   if want:assert (madds[0]&31)==1 and ((madds[0]>>16)&31)==16 and 19<=((madds[0]>>10)&31)<=28 and 19<=((madds[0]>>5)&31)<=28,(c,hex(madds[0]))
   allAudits.append({'batch':batchN,'compiler':label,'case':c,'maddWords':[hex(x) for x in madds]})
 for c in batch:
  for a,ix in [(m.MIN,0),(m.MAX,7),(-1,8),(0,-1),(123,m.MIN)]:
   b=m.s64(ix-c['prefix']-m.s64(a*c['factor']));assert m.s64(m.s64(a*c['factor'])+b+c['prefix'])==ix
   for fuel in [1,2,16777216]:
    readValid=0<=ix<8;valid=readValid and fuel>=2;answer=m.s64(values[ix]+(ix if c['mode']=='future-index-ret2' else (c['t']-2)*a)) if valid else None;obs={}
    remaining=max(0,fuel-(2 if readValid or c['mode']=='future-index-ret2' else 1))
    for label,(bp,fc) in images.items():
     e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'clobber-full-state-loader'),str(bp),str(fc[ids[c['entry']]]),'3','aarch64','-',str(a),str(b),'1'],env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
     assert (q.returncode==0)==valid,(label,c,a,b,ix,fuel,q.stdout,q.stderr)
     if valid:assert re.search(r':result '+str(answer)+r'(?:\s|})',q.stdout),(label,c,a,b,ix,fuel,answer,q.stdout)
     allocated=(c['mode']!='future-index-ret2' or fuel>=2);wantitems=values if allocated else [];assert obs[label]['items']==['DIAG_VECTOR_ITEMS 8 '+' '.join(map(str,values))] if allocated else obs[label]['items']==['DIAG_VECTOR_ITEMS 0']
     assert f':remaining {remaining}' in q.stdout and re.search(r':vectors \{:capacity \d+ :used '+str(int(allocated))+r'\}',q.stdout),(label,c,a,b,ix,fuel,q.stdout)
    assert obs['baseline-read']==obs['candidate-read'],(c,a,b,ix,fuel,obs);rows.append({'case':c,'a':a,'b':b,'expectedIndex':ix,'fuel':fuel,'expected':answer,**obs})
 print('PASS read batch',batchN,'cases',len(batch),'total states',len(rows),flush=True)
(w/'read-cases.json').write_text(json.dumps(cases,indent=2)+'\n');(w/'read-proof.json').write_text(json.dumps({'status':'complete-independent-native-affine-read-overflow-alias-coalescing-live-index-refusal-fuel-state-proof','comparisons':len(rows),'cases':len(cases),'batches':batchN+1,'instructionAudit':allAudits,'observations':rows},indent=2)+'\n');print('PASS',len(rows),'independent affine-read state comparisons',flush=True)
