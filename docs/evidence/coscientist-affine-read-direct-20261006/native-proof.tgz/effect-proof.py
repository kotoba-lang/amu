from pathlib import Path
import importlib.util,subprocess,os,json,re,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-affine-read-direct-20261006');sp=importlib.util.spec_from_file_location('fx',w/'permanent-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);cases=[]
m.fx('ac_open_stub',0,0,[('FUEL',),('CONST',0,77),('RET',0)]);target=len(m.FIX);m.fx('ac_actual_alloc',0,0,[('FUEL',),('CONST',0,1),('RT','RT-VECTOR-ALLOC',0,1),('RET',0)]);replacement=len(m.FIX)
for t in [7,8,17]:
 for factor in [20,-3]:
  name=f'ac_effect_{t}_{factor}';out=t-1;label=name+'_loop';body=[('FUEL',)]+[('CONST',j,11-3*j) for j in range(8)]+[('VEC',0,8),('LSET',4,0),('CONST',0,1),('LSET',5,0),('LABEL',label)]+[('LGET',j,1) for j in range(t-2)]+[('LGET',t-2,3),('CONST',out,0),('LGET',t,1),('CONST',t+1,factor),('BIN','BOP-MUL',t),('LGET',t+1,2),('BIN','BOP-ADD',t),('BIN','BOP-ADD',out),('RT','RT-VECTOR-AT',t-2,2),('LSET',6,t-2),('CALL','ac_open_stub',t-1,0),('LGET',t-2,6)]+[('BIN','BOP-ADD',j) for j in range(t-3,-1,-1)]+[('LSET',6,0),('LGET',0,5),('CONST',1,1),('BIN','BOP-SUB',0),('LSET',5,0),('FUEL',),('BRNZ',0,label),('LGET',0,6),('RET',0)];m.fx(name,3,6,body);cases.append({'name':name,'t':t,'factor':factor})
sentinel=next(x for x in m.FIX if x[0]=='ht_cold_control');m.FIX.append(('ac_effect_sentinel',*sentinel[1:]));ids={f[0]:j+1 for j,f in enumerate(m.FIX)};text=m.kotoba(True);assert text.count('(gn-run M0)')==1;text=text.replace('(gn-run M0)',f'(gn-run-open M0 {target} 1)');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800');images={};audits=[]
for label,gen in [('baseline-effect','baseline-41-a64gen.kotoba'),('candidate-effect','41-a64gen-prototype.kotoba')]:
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in ['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'])+'\n'+(w/gen).read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+text)
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-300:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'.stdout')).write_text(q.stdout);assert q.returncode==0,(label,q.stdout[-300:],q.stderr);blob,fc=m.blob_from(q.stdout);patched=bytearray(blob);struct.pack_into('<I',patched,fc[target],0x14000000|(((fc[replacement]-fc[target])//4)&0x3ffffff));bp=w/(label+'-linked.bin');bp.write_bytes(patched);images[label]=(bp,fc)
 for c in cases:
  k=ids[c['name']];chunk=blob[fc[k]:fc.get(k+1,len(blob))];words=struct.unpack('<'+'I'*(len(chunk)//4),chunk);count=sum((x&0xffe08000)==0x9b000000 and ((x>>10)&31)!=31 for x in words);assert count==(1 if label=='candidate-effect' else 0),(label,c,count);audits.append({'compiler':label,'case':c,'nonMulMaddInstructions':count})
rows=[];values=[11-3*j for j in range(8)]
for c in cases:
 for a,b in [(m.MIN,m.MAX),(m.MAX,m.MIN),(0,0),(1,1),(0,7),(0,8),(-1,23)]:
  for h in [0,1,2,m.MIN,m.MAX]:
   for fuel in [1,2,3,16777216]:
    ix=m.s64(m.s64(a*c['factor'])+b);readValid=h==1 and 0<=ix<8;allocated=readValid and fuel>=2;valid=readValid and fuel>=3;expected=m.s64((c['t']-2)*a+values[ix]) if valid else None;remaining=max(0,fuel-(3 if readValid else 1));obs={}
    for label,(bp,fc) in images.items():
     e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'clobber-full-state-loader'),str(bp),str(fc[ids[c['name']]]),'3','aarch64','-',str(a),str(b),str(h)],env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
     assert (q.returncode==0)==valid,(c,a,b,h,fuel,label,q.stdout,q.stderr)
     if valid:assert re.search(r':result '+str(expected)+r'(?:\s|})',q.stdout),(c,a,b,h,fuel,label,expected,q.stdout)
     assert f':remaining {remaining}' in q.stdout and re.search(r':vectors \{:capacity \d+ :used '+str(1+int(allocated))+r'\}',q.stdout) and re.search(r':vector-items \{:capacity \d+ :used '+str(8+int(allocated))+r'\}',q.stdout),(c,a,b,h,fuel,label,q.stdout)
     items=values+([0] if allocated else []);assert obs[label]['items']==['DIAG_VECTOR_ITEMS '+str(len(items))+' '+' '.join(map(str,items))]
    assert obs['baseline-effect']==obs['candidate-effect'];rows.append({'case':c,'a':a,'b':b,'handle':h,'fuel':fuel,'expected':expected,**obs})
   for budget,key,val in [('table','KEXE_VECTORS',1),('items','KEXE_VECTOR_ITEMS',8)]:
    fuel=16777216;ix=m.s64(m.s64(a*c['factor'])+b);readValid=h==1 and 0<=ix<8;remaining=fuel-(2 if readValid else 1);items=values+([0] if readValid and budget=='table' else []);obs={}
    for label,(bp,fc) in images.items():
     e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e[key]=str(val);e.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'clobber-full-state-loader'),str(bp),str(fc[ids[c['name']]]),'3','aarch64','-',str(a),str(b),str(h)],env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
     assert q.returncode!=0 and f':remaining {remaining}' in q.stdout and re.search(r':vectors \{:capacity \d+ :used 1\}',q.stdout) and re.search(r':vector-items \{:capacity \d+ :used '+str(len(items))+r'\}',q.stdout),(c,a,b,h,budget,label,q.stdout,q.stderr);assert obs[label]['items']==['DIAG_VECTOR_ITEMS '+str(len(items))+' '+' '.join(map(str,items))]
    assert obs['baseline-effect']==obs['candidate-effect'];rows.append({'case':c,'a':a,'b':b,'handle':h,'budget':budget,'expectedRemaining':remaining,**obs})
 print('PASS chain vector/openimport/resources',c,flush=True)
(w/'effect-proof.json').write_text(json.dumps({'status':'complete-independent-native-affine-vector-invalid-index-open-allocating-import-and-resource-partial-write-proof','comparisons':len(rows),'fuelAndTrapComparisons':840,'resourceComparisons':420,'actualLinkedAllocatingImport':True,'instructionAudit':audits,'observations':rows},indent=2)+'\n');print('PASS',len(rows),'extra vector/effect/resource state comparisons',flush=True)
