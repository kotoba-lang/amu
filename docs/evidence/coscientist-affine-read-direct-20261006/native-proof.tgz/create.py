from pathlib import Path
import json,shutil,subprocess,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-affine-read-direct-20261006');prior=Path('/private/tmp/amu-affine-chain-20261006');base=Path('/private/tmp/amu-loop-high-temp-20261006');g=(r/'seed/41-a64gen.kotoba').read_text();(w/'baseline-41-a64gen.kotoba').write_text(g)
p=(prior/'41-a64gen-prototype.kotoba').read_text();start=p.index('(defn- gn-affine-chain?');end=p.index('(defn- gn-affine-chain [',start);guard=p[start:end].replace('gn-affine-chain?','gn-affine-read?')
guard=guard.replace('(and (>= t 7)', '(and (= (gn-g M gn-f-leaf) 0) (>= t 7)').replace('(< (+ i 5) (vector-at M MM-SIR-N))','(< (+ i 6) (vector-at M MM-SIR-N))')
guard=guard.replace('(gn-high-loop M i)', '''(= (gn-op M (+ i 6)) OP-RT) (= (gn-sir M (+ i 6) IF-A) RT-VECTOR-AT)
       (= (gn-sir M (+ i 6) IF-B) (- t 2)) (= (gn-sir M (+ i 6) IF-C) 2)
       (gn-kills M (+ i 7) (dec t) 16) (gn-high-loop M i)''')
helper=''';; Exact affine index consumed by immediately adjacent checked vector read.
;; Original nonleaf frame reserves x0/x1 scratch; every handle/index check stays.
;; Dead intermediates only; final result uses original alias/coalescing placement.
'''+guard+'''(defn- gn-affine-read [M :vector-i64 i :i64 t :i64] :vector-i64
 (let [out (- t 2) s (gn-co M (+ i 6) out) d (gn-dreg M out s)
       a (gn-sreg M (gn-sir M i IF-B)) b (gn-sreg M (gn-sir M (+ i 3) IF-B))
       factor (gn-sir M (inc i) IF-B) prefix (gn-dv M (dec t))
       M1 (-> M (gn-protect out s) (gn-into 0 out) (gn-mov-imm 16 factor)
              (gn-emit (enc-madd 1 a 16 b)) (gn-bin-imm BOP-ADD 1 1 prefix)
              (gn-ctx) (gn-hchk 0 312 320) (gn-vidx 1)
              (gn-emit (gn-e-ldrr d 16 17 1)) (gn-fin out s d))]
  (gn-gs M1 gn-f-skip (+ 6 (gn-g M1 gn-f-skip)))))
'''
needle=';; one SIR instruction (unreachable ones';assert g.count(needle)==1;g=g.replace(needle,helper+'\n'+needle,1);needle='OP-LGET (gn-def M a gn-k-local b)';assert g.count(needle)==1;g=g.replace(needle,'OP-LGET (if (gn-affine-read? M i a) (gn-affine-read M i a) (gn-def M a gn-k-local b))',1);(w/'41-a64gen-prototype.kotoba').write_text(g)
parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader'),('clobber-full-state-loader','clobber-full-state-loader')]:shutil.copy2(base/src,w/dst)
for n in ['build.py','check-ports.py','permanent-regression.py','ports-state.py','effect-proof.py']:(w/n).write_text((prior/n).read_text().replace('amu-affine-chain-20261006','amu-affine-read-direct-20261006'))
(w/'hypothesis.json').write_text(json.dumps({'status':'registered-before-native-build-and-measurement','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'hypothesis':'Compose exact affine index and immediately consuming checked vector-at in original nonleaf frame; eliminate intermediate materialization while retaining original handle/index checks.','priorRegistration':json.loads((r/'docs/evidence/coscientist-affine-chain-20261006/next-hypothesis.json').read_text()),'authoringException':'One-off new experimental Kotoba algorithm and independent hand fixtures, not a mechanical product rewrite. Qualified source unchanged until complete semantics/performance/gates.','baselineSeedSha256':hashlib.sha256((w/'seed-0.bin').read_bytes()).hexdigest(),'timingRule':'Fresh30triples per changed originalguest; load<=4 idle>=90 RSD<=10 ratio>=1.05 gap>sumSD; no identical-machine retiming.','goal':'C-or-better all19 original aligned workloads, native selfhost; not officialscore.'},indent=2)+'\n');print('PASS new affine-read prototype registered; original qualified product baseline')
