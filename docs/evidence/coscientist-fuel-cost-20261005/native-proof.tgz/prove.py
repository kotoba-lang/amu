from pathlib import Path
import json,subprocess,os,re,hashlib,shutil
w=Path('/private/tmp/amu-fuel-cost-20261005');base=Path('/private/tmp/amu-scalar-tree-20261005');mf=json.loads((w/'diagnostic/manifest.json').read_text());e=next(x for x in json.loads((base/'ports-correctness.json').read_text())['entries'] if x['workload']=='picojpeg')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ,KEXE_FUEL='16777216',KEXE_STRUCTURED_REPORT='1',KEXE_CPU_SECONDS='30',KEXE_WALL_SECONDS='30');env.pop('KEXE_COMMAND',None)
rows=[]
for x in e['runs']:
 row={'n':x['n']};reports=[]
 for label,p,off in [('baseline',base/'ports-2/picojpeg/native.bin',e['offset']),('diagnostic',w/'diagnostic/native.bin',mf['offset'])]:
  q=subprocess.run([str(w/'kexe-loader'),str(p),str(off),'1','aarch64','-',str(x['n'])],env=env,capture_output=True,text=True,timeout=35)
  (w/f'{label}-n{x["n"]}.log').write_text(q.stdout+q.stderr);assert q.returncode==0,(label,x,q.returncode,q.stderr)
  result=int(re.search(r':result (-?\d+)',q.stdout).group(1));initial,remaining=map(int,re.search(r':initial (\d+) :remaining (\d+)',q.stdout).groups());fuel=initial-remaining
  assert result==x['result'];assert fuel==(x['fuelConsumed'] if label=='baseline' else 0)
  row[label+'Result']=result;row[label+'FuelConsumed']=fuel
  reports.append(re.sub(r':fuel \{:initial \d+ :remaining \d+\}',':fuel DIAGNOSTIC-DIFFERENCE',q.stdout))
 assert reports[0]==reports[1],('nonfuel supervisor report differs',x)
 row['nonFuelSupervisorReportExact']=True;rows.append(row)
boundary=[]
for label,p,off in [('baseline',base/'ports-2/picojpeg/native.bin',e['offset']),('diagnostic',w/'diagnostic/native.bin',mf['offset'])]:
 q=subprocess.run([str(w/'kexe-loader'),str(p),str(off),'1','aarch64','-','1'],env=dict(env,KEXE_FUEL='1'),capture_output=True,text=True,timeout=35)
 (w/f'{label}-fuel1.log').write_text(q.stdout+q.stderr)
 assert (q.returncode!=0 and ':budget/fuel' in q.stdout+q.stderr) if label=='baseline' else q.returncode==0 and ':result 1' in q.stdout
 boundary.append({'arm':label,'returncode':q.returncode,'output':q.stdout+q.stderr})
report={'status':'complete-bounded-results-and-state-parity-with-explicit-fuel-difference','baselineNativeSha256':mf['baselineNativeSha256'],'diagnosticNativeSha256':mf['nativeSha256'],'runs':rows,'fuel1Boundary':boundary,'workspace':json.loads((w/'bulk-state.json').read_text()),'promotionEligible':False,'observableFuelSemanticsPreserved':False,'wallSeconds':30,'cpuSeconds':30,'unknownGuestsAdmitted':False}
(w/'diagnostic/bounded-proof.json').write_text(json.dumps(report,indent=2)+'\n');mf.update(boundedVerificationStatus=report['status'],boundedVerificationSha256=sha(w/'diagnostic/bounded-proof.json'))
(w/'diagnostic/manifest.json').write_text(json.dumps(mf,indent=2)+'\n');shutil.copyfile(base/'seed-4.bin',w/'diagnostic/producer-compiler.bin');shutil.copyfile(w/'compiler/native.bin',w/'diagnostic/diagnostic-compiler.bin')
print(json.dumps(report,indent=2),flush=True)
