from pathlib import Path
import subprocess,os,re,json,hashlib,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-fuel-cost-20261005');base=Path('/private/tmp/amu-scalar-tree-20261005')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
g=(r/'seed/41-a64gen.kotoba').read_text();a=g.index('(defn- gn-op-fuel ');b=g.index(';; one SIR instruction',a)
g=g[:a]+'''(defn- gn-op-fuel [M :vector-i64] :vector-i64
  ;; DIAGNOSTIC ONLY: no charge/check; preserve context restoration side effect.
  (if (= (gn-g M gn-f-freg) 1) M (gn-ctx M)))

'''+g[b:]
(w/'41-a64gen-diagnostic.kotoba').write_text(g)
files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')]
(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
shutil.copyfile(base/'kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
producer=base/'seed-4.bin';assert sha(producer)=='98905d4a7c3da0d94465d99f4b32ae195c2e7972d1b995a3744a0d588595635d'
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
def build(seed,src,d,symbol):
 d.mkdir();out=d/'image.kseed'
 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(out)]),('extract',['extract-native',str(out),'--symbol',symbol,'--output',str(d/'native.bin')])]:
  p=subprocess.run([str(w/'kexe-loader'),str(seed),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True,timeout=1900);(d/(mode+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(mode,p.stdout,p.stderr)
  if mode=='extract':off=int(re.search(r':offset (\d+)',p.stdout).group(1));(d/'offset').write_text(str(off)+'\n')
 return off
off=build(producer,w/'seed-unity.kotoba',w/'compiler','main');assert off==0
src=r/'bench/embench/picojpeg-full.kotoba';e=next(x for x in json.loads((base/'ports-correctness.json').read_text())['entries'] if x['workload']=='picojpeg')
assert sha(src)==e['sourceSha256'];off=build(w/'compiler/native.bin',src,w/'diagnostic','bench')
mf={'format':'amu.native-fuel-diagnostic/v1','workload':'picojpeg','diagnostic':True,'promotionEligible':False,'observableFuelSemanticsPreserved':False,'COrBetterEvidence':False,'sourceSha256':sha(src),'baselineSourceSha256':e['sourceSha256'],'nativeSha256':sha(w/'diagnostic/native.bin'),'offset':off,'baselineNativeSha256':e['nativeSha256'],'baselineOffset':e['offset'],'producerCompilerSha256':sha(producer),'diagnosticCompilerSha256':sha(w/'compiler/native.bin'),'diagnosticCompilerSourceSha256':sha(w/'seed-unity.kotoba'),'diagnosticBackendSourceSha256':sha(w/'41-a64gen-diagnostic.kotoba'),'compilerGenerations':1,'fixedPointClaim':False,'retainedFuelSetup':'leaf prologue load and epilogue store retained; nonleaf gn-ctx restoration retained','sourceHead':subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip()}
(w/'diagnostic/manifest.json').write_text(json.dumps(mf,indent=2)+'\n');print(json.dumps(mf,indent=2),flush=True)
