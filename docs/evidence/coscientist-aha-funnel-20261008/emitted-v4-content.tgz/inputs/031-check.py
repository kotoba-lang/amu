"""Offline comparison of actual emitted images/output, never an execution substitute."""
import re,struct
MASK=(1<<64)-1
def need(v,m):
 if not v:raise AssertionError(m)
def signed(x):
 x&=MASK;return x-(1<<64) if x>>63 else x
def pairs():
 for i in range(64):
  for j in range(64):yield signed(1<<i),signed(1<<j)
 e=[0,1,2,1<<62,1<<63,MASK,MASK-1,0xaaaaaaaaaaaaaaaa,0x5555555555555555]
 for x in e:
  for y in e:yield signed(x),signed(y)
def expected(case,x,y):
 right=((y&MASK)>>63) if case!='signed-shift-negative' else y>>63
 result=((x&MASK)<<1)|right
 if case=='live-prefix-negative':result+=7
 return signed(result)
def output(case,raw):
 lines=raw.decode('ascii').splitlines();need(len(lines)==4178 and lines[-1]=='END 4177','exact4177+end')
 values=[]
 for i,((x,y),line) in enumerate(zip(pairs(),lines[:-1])):
  parts=line.split();need(len(parts)==5 and parts[0]=='PAIR' and all(re.fullmatch(r'-?\d+',v) for v in parts[1:]),'exactPAIRschema');j,a,b,r=map(int,parts[1:]);need((j,a,b)==(i,x,y),'exactorderedinputpair');need(r==expected(case,x,y),'actualresult mathematicaloracle');values.append(r)
 need(len(values)==4177,'allpairs');return values
def container(k,n,offset):
 need(k==f'KSEED1 {len(n)} 1\nmain {offset} 0\n\n'.encode()+n,'whole solemain0 payload exact')
def images(case,off,on,koff,kon,oo,no):
 container(koff,off,oo);container(kon,on,no);need(0<len(off)<=4194304 and len(off)==len(on) and 0<=oo<len(off) and oo%4==0 and oo==no,'sameboundedwholeimage/offset')
 if case!='positive':need(off==on and koff==kon,'genuinecheckednegativewholebyteidentity');return {'changes':0}
 changedBytes=[i for i,(a,b) in enumerate(zip(off,on)) if a!=b];changed=sorted(set(i//4 for i in changedBytes))
 need(len(changed)==3 and changed==list(range(changed[0],changed[0]+3)),'exactone threewordsite')
 start=changed[0]*4;need(start+12<=len(off),'complete aligned changedspan')
 need(off[:start]==on[:start] and off[start+12:]==on[start+12:],'all other bytes including literal tail exact')
 aw=list(struct.unpack('<III',off[start:start+12]));bw=list(struct.unpack('<III',on[start:start+12]))
 i=0;w=bw[i];x=(w>>5)&31;y=(w>>16)&31;d=w&31
 need(all(19<=r<=28 for r in [x,y,d]),'residentinput/dest registers')
 need(bw[i:i+3]==[0x93c0fc00+(y<<16)+(x<<5)+d,0xd503201f,0xd503201f],'actualEXTR63 highx/lowy andNOPs')
 need(aw[i:i+3]==[0xd3400000+(63<<16)+(62<<10)+(x<<5)+9,0xd3400000+(63<<16)+(63<<10)+(y<<5)+10,0xaa000000+(10<<16)+(9<<5)+d],'exactoriginal LSL/LSR/ORR operand order')
 prefix=f'KSEED1 {len(off)} 1\nmain {oo} 0\n\n'.encode();need(koff[:len(prefix)]==kon[:len(prefix)],'metadata prefix unchanged')
 return {'changes':3,'byteOffset':start,'originalWords':aw[i:i+3],'newWords':bw[i:i+3],'registers':{'high':x,'low':y,'destination':d},'allOtherNativeAndContainerBytesEqual':True}
