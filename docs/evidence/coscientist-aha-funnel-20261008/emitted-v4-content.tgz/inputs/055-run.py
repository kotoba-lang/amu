"""Root-authorized finite actual emitted execution, never active on import."""
from pathlib import Path
import os,sys,json,re,hashlib,subprocess,signal
from check import images,output
D=Path(__file__).resolve().parent
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(v,m):
 if not v:raise AssertionError(m)
def load(p):return json.loads(Path(p).read_text())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def main():
 need(len(sys.argv)==2,'rootGO path');gp=Path(sys.argv[1]);g=load(gp);gh=H(gp);pr=load(D/'preregistration.json');pins=load(D/'source-pins.json');out=D/'run-outputs';rows=[];success=False;immutable={};results=[]
 need(g['authorizeEmittedSemanticExecution'] is True and type(g['maximumLoaderCalls']) is int and g['maximumLoaderCalls']==18 and g['noRetry'] is True and g['performanceTiming'] is False,'finite diagnostic rootGO')
 need(g['driverSHA256']==H(D/'run.py') and g['sourcePinsSHA256']==H(D/'source-pins.json') and len(g['sourceReviews'])==2,'specific frozen source reviews')
 def guard():
  need(H(gp)==gh,'immutableGO')
  for n,v in pins.items():need(H(D/n)==v['sha256'] and (D/n).stat().st_size==v['bytes'],'frozen source '+n)
  for p,v in pr['inputs'].items():need(H(p)==v['sha256'] and Path(p).stat().st_size==v['bytes'],'input '+p)
  for v in g['sourceReviews']:
   need(H(v['path'])==v['sha256'],'reviewhash');j=load(v['path']);need(j['status'].startswith('PASS') and j['sourcePinsSHA256']==g['sourcePinsSHA256'],'specific parsed currentreview')
  for p,v in immutable.items():need(H(p)==v['sha256'] and Path(p).stat().st_size==v['bytes'],'copy/artifact '+p)
 guard();need(not out.exists(),'freshoutputs/norerun');out.mkdir()
 for case in pr['cases']:
  p=out/(case+'.kotoba');p.write_bytes((D/p.name).read_bytes());p.chmod(0o444);immutable[str(p)]={'sha256':H(p),'bytes':p.stat().st_size}
 W=D.parent;loader=W/'vector-emitter-param-native-build-v1-root/kexe-loader';B=W/'vector-aha-funnel-native-build-plan-v4-root/run-outputs';producers={'off':B/'off-generation1.bin','on':B/'on-generation1.bin'}
 base={k:v for k,v in os.environ.items() if not k.startswith('KEXE_')}
 env={'KEXE_COMMAND':'1','KEXE_STRING_POOL':'67108864','KEXE_VECTORS':'65536','KEXE_PAIRS':'1048576','KEXE_VECTOR_ITEMS':'1048576'}
 def call(label,image,offset,args,build):
  guard();need(len(rows)<18 and label not in [r['label'] for r in rows],'18/noRetry');seconds=1800 if build else 180;caps='35,37,38,39' if build else '37,38,39';e=env|{'KEXE_CPU_SECONDS':str(seconds),'KEXE_WALL_SECONDS':str(seconds)}
  if build:e.update(KEXE_CAP_RESOURCES_35=str(out),KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
  cmd=[str(loader),str(image),str(offset),'0','aarch64',caps,'--']+args;r={'index':len(rows)+1,'label':label,'argv':cmd,'imageSHA256':H(image),'kexeEnvironment':e,'removedInheritedKexeKeys':sorted(k for k in os.environ if k.startswith('KEXE_')),'timeoutSeconds':seconds+10,'state':'started'};rows.append(r);save(out/'attempts.json',rows)
  p=subprocess.Popen(cmd,cwd=out,env=base|e,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);timed=False
  try:o,er=p.communicate(timeout=seconds+10)
  except subprocess.TimeoutExpired:timed=True;os.killpg(p.pid,signal.SIGKILL);o,er=p.communicate()
  (out/(label+'.stdout')).write_bytes(o);(out/(label+'.stderr')).write_bytes(er);r.update(state='terminal',returncode=p.returncode,timeout=timed,stdoutSHA256=hashlib.sha256(o).hexdigest(),stderrSHA256=hashlib.sha256(er).hexdigest());save(out/'attempts.json',rows);guard();need(not timed and p.returncode==0 and er==b'' and (not build or b':ok true' in o),'first failure '+label);return o
 try:
  for case in pr['cases']:
   artifacts={}
   for arm in pr['arms']:
    name=case+'-'+arm;k=out/(name+'.kseed');n=out/(name+'.bin')
    call(name+'-compile',producers[arm],0,['compile',str(out/(case+'.kotoba')),'--target','aarch64-macos','--output',str(k)],True)
    need(0<k.stat().st_size<=4194560,'bounded container beforeextract');immutable[str(k)]={'sha256':H(k),'bytes':k.stat().st_size};save(out/'immutable-artifacts.json',immutable)
    raw=call(name+'-extract',producers[arm],0,['extract-native',str(k),'--symbol','main','--output',str(n)],True);xs=re.findall(rb':offset (\d+)\b',raw);need(len(xs)==1,'sole actualoffset');offset=int(xs[0]);need(0<n.stat().st_size<=4194304 and 0<=offset<n.stat().st_size and offset%4==0,'bounded native actualentry')
    immutable[str(n)]={'sha256':H(n),'bytes':n.stat().st_size};artifacts[arm]={'native':str(n),'kseed':str(k),'offset':offset,'nativeSHA256':H(n),'containerSHA256':H(k)};save(out/'immutable-artifacts.json',immutable)
   a,b=artifacts['off'],artifacts['on'];w=images(case,Path(a['native']).read_bytes(),Path(b['native']).read_bytes(),Path(a['kseed']).read_bytes(),Path(b['kseed']).read_bytes(),a['offset'],b['offset']);save(out/(case+'-structural.json'),w)
   values={}
   for arm in pr['arms']:
    a=artifacts[arm];raw=call(case+'-'+arm+'-guest',Path(a['native']),a['offset'],[],False);values[arm]=output(case,raw);save(out/(case+'-'+arm+'-oracle.json'),{'status':'PASS_EXACT_4177_ACTUAL_NATIVE_OUTPUT_ORACLE','pairs':len(values[arm]),'fuelObservable':False})
   need(values['off']==values['on'],'pairedactualoutputs');results.append({'case':case,'artifacts':artifacts,'structural':w,'pairs':4177,'actualGuestArms':2,'nativeFuelObserved':False,'actualNegativeGuardCauseQualified':False});save(out/'comparisons.json',results)
  guard();need(len(rows)==18,'exact18closedcalls');save(out/'report.json',{'status':'PASS_FINITE_EMITTED_EXTR_4177_PAIRED_EXECUTION_AND_TWO_CHECKED_SOURCE_NEGATIVE_PARITY_ONLY','loaderCalls':18,'actualGuestCalls':6,'positivePairs':4177,'negativePairsPerFixture':4177,'fuelEqualityObserved':False,'negativeGuardCauseQualified':False,'performanceQualified':False,'productAdoption':False});success=True
 except BaseException as e:save(out/'failure.json',{'exception':repr(e),'calls':len(rows),'noRetry':True,'stopFirstFailure':True});raise
 finally:save(out/'terminal.json',{'calls':len(rows),'allCallsClosed':all(r['state']=='terminal' for r in rows),'failure':not success,'noRetry':True})
if __name__=='__main__':main()
