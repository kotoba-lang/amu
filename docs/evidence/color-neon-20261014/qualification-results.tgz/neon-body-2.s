.text
.globl _neon_body_2
_neon_body_2:
	ldr	q0, [x9, #12288]
	ldr	q1, [x9, #12304]
	uzp1.4s	v0, v0, v1
	xtn.4h	v0, v0
	bic.4h	v0, #255, lsl #8
	movi.4h	v1, #103
	mul.4h	v1, v0, v1
	movi.4h	v2, #183
	mul.4h	v2, v0, v2
	ushr.4h	v2, v2, #8
	ldr	q3, [x9, #16384]
	ldr	q4, [x9, #16400]
	uzp1.4s	v3, v3, v4
	xtn.4h	v3, v3
	usra.4h	v0, v1, #8
	mvni.4h	v1, #178
	add.4h	v1, v3, v1
	add.4h	v0, v0, v1
	movi.2d	v1, #0000000000000000
	smax.4h	v0, v0, v1
	movi	d3, #0xff00ff00ff00ff
	smin.4h	v0, v0, v3
	ushll.4s	v0, v0, #0
	ushll.2d	v4, v0, #0
	str	q4, [x9, #16384]
	ushll2.2d	v0, v0, #0
	str	q0, [x9, #16400]
	ldr	q0, [x9, #18432]
	ldr	q4, [x9, #18448]
	uzp1.4s	v0, v0, v4
	xtn.4h	v0, v0
	sub.4h	v0, v0, v2
	movi.4h	v2, #91
	add.4h	v0, v0, v2
	smax.4h	v0, v0, v1
	smin.4h	v0, v0, v3
	ushll.4s	v0, v0, #0
	ushll.2d	v1, v0, #0
	str	q1, [x9, #18432]
	ushll2.2d	v0, v0, #0
	str	q0, [x9, #18448]
ret
