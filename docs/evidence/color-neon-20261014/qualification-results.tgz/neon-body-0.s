.text
.globl _neon_body_0
_neon_body_0:
	ldr	q0, [x9, #12288]
	ldr	q1, [x9, #12304]
	uzp1.4s	v0, v0, v1
	xtn.4h	v0, v0
	bic.4h	v0, #255, lsl #8
	ushll.4s	v0, v0, #0
	ushll.2d	v1, v0, #0
	str	q1, [x9, #16384]
	ushll2.2d	v0, v0, #0
	str	q0, [x9, #16400]
	str	q1, [x9, #18432]
	str	q0, [x9, #18448]
	str	q1, [x9, #20480]
	str	q0, [x9, #20496]
ret
