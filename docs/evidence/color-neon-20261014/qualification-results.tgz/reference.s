	.build_version macos, 26, 0	sdk_version 26, 5
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_color4                         ; -- Begin function color4
	.p2align	2
_color4:                                ; @color4
	.cfi_startproc
; %bb.0:
	add	x9, x0, w2, uxtw #3
	mov	w8, w2
	ldr	q0, [x9, #12288]
	ldr	q1, [x9, #12304]
	uzp1.4s	v0, v0, v1
	xtn.4h	v0, v0
	bic.4h	v0, #255, lsl #8
	cmp	x1, #1
	b.eq	LBB0_3
; %bb.1:
	cbnz	x1, LBB0_4
; %bb.2:
	ushll.4s	v0, v0, #0
	ushll.2d	v1, v0, #0
	add	x8, x0, x8, lsl #3
	str	q1, [x8, #16384]
	ushll2.2d	v0, v0, #0
	str	q0, [x8, #16400]
	str	q1, [x8, #18432]
	str	q0, [x8, #18448]
	str	q1, [x8, #20480]
	str	q0, [x8, #20496]
	ret
LBB0_3:
	movi.4h	v1, #88
	mul.4h	v1, v0, v1
	ushr.4h	v1, v1, #8
	movi.4h	v2, #198
	mul.4h	v2, v0, v2
	add	x8, x0, x8, lsl #3
	ldr	q3, [x8, #18432]
	ldr	q4, [x8, #18448]
	uzp1.4s	v3, v3, v4
	xtn.4h	v3, v3
	sub.4h	v1, v3, v1
	movi.4h	v3, #44
	add.4h	v1, v1, v3
	movi.2d	v3, #0000000000000000
	smax.4h	v1, v1, v3
	movi	d4, #0xff00ff00ff00ff
	smin.4h	v1, v1, v4
	ushll.4s	v1, v1, #0
	ushll.2d	v5, v1, #0
	str	q5, [x8, #18432]
	ushll2.2d	v1, v1, #0
	str	q1, [x8, #18448]
	ldr	q1, [x8, #20480]
	ldr	q5, [x8, #20496]
	uzp1.4s	v1, v1, v5
	xtn.4h	v1, v1
	usra.4h	v0, v2, #8
	mvni.4h	v2, #226
	add.4h	v1, v1, v2
	add.4h	v0, v0, v1
	smax.4h	v0, v0, v3
	smin.4h	v0, v0, v4
	ushll.4s	v0, v0, #0
	ushll.2d	v1, v0, #0
	str	q1, [x8, #20480]
	ushll2.2d	v0, v0, #0
	str	q0, [x8, #20496]
	ret
LBB0_4:
	movi.4h	v1, #103
	mul.4h	v1, v0, v1
	movi.4h	v2, #183
	mul.4h	v2, v0, v2
	ushr.4h	v2, v2, #8
	add	x8, x0, x8, lsl #3
	ldr	q3, [x8, #16384]
	ldr	q4, [x8, #16400]
	uzp1.4s	v3, v3, v4
	xtn.4h	v3, v3
	usra.4h	v0, v1, #8
	mvni.4h	v1, #178
	add.4h	v1, v3, v1
	add.4h	v0, v0, v1
	movi.2d	v1, #0000000000000000
	smax.4h	v0, v0, v1
	movi	d3, #0xff00ff00ff00ff
	smin.4h	v0, v0, v3
	ushll.4s	v0, v0, #0
	ushll.2d	v4, v0, #0
	str	q4, [x8, #16384]
	ushll2.2d	v0, v0, #0
	str	q0, [x8, #16400]
	ldr	q0, [x8, #18432]
	ldr	q4, [x8, #18448]
	uzp1.4s	v0, v0, v4
	xtn.4h	v0, v0
	sub.4h	v0, v0, v2
	movi.4h	v2, #91
	add.4h	v0, v0, v2
	smax.4h	v0, v0, v1
	smin.4h	v0, v0, v3
	ushll.4s	v0, v0, #0
	ushll.2d	v1, v0, #0
	str	q1, [x8, #18432]
	ushll2.2d	v0, v0, #0
	str	q0, [x8, #18448]
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_main                           ; -- Begin function main
	.p2align	2
_main:                                  ; @main
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #448                        ; =0x1c0
	movk	w9, #1, lsl #16
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #16, lsl #12            ; =65536
	sub	sp, sp, #448
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh2:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh3:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh4:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	add	x0, sp, #8, lsl #12             ; =32768
	add	x0, x0, #432
	mov	w1, #32768                      ; =0x8000
	bl	_bzero
	add	x0, sp, #432
	mov	w1, #32768                      ; =0x8000
	bl	_bzero
	mov	x13, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	mov	x10, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x28, #0                         ; =0x0
	mov	w12, #-358                      ; =0xfffffe9a
	mov	w14, #-179                      ; =0xffffff4d
	mov	w15, #-454                      ; =0xfffffe3a
	mov	w16, #-227                      ; =0xffffff1d
	mov	w17, #-356                      ; =0xfffffe9c
	mov	w0, #-178                       ; =0xffffff4e
	mov	w1, #-452                       ; =0xfffffe3c
	mov	w2, #-226                       ; =0xffffff1e
	mov	w3, #-354                       ; =0xfffffe9e
	mov	w4, #-177                       ; =0xffffff4f
	mov	w5, #-450                       ; =0xfffffe3e
	mov	w6, #-225                       ; =0xffffff1f
	mov	w7, #-352                       ; =0xfffffea0
	mov	w19, #-176                      ; =0xffffff50
	mov	w22, #-448                      ; =0xfffffe40
	mov	w25, #-224                      ; =0xffffff20
LBB1_1:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_2 Depth 2
	mov	w23, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
	stp	x8, x10, [sp, #80]              ; 16-byte Folded Spill
	lsr	x8, x8, #8
	lsl	w9, w8, #1
	stp	w14, w12, [sp, #72]             ; 8-byte Folded Spill
	add	w12, w12, w9
	str	w12, [sp, #284]                 ; 4-byte Folded Spill
	add	w12, w14, w8
	str	x12, [sp, #272]                 ; 8-byte Folded Spill
	lsr	x10, x10, #8
	neg	w12, w10
	str	x12, [sp, #264]                 ; 8-byte Folded Spill
	stp	x11, x13, [sp, #96]             ; 16-byte Folded Spill
	lsr	x11, x11, #8
	lsl	w12, w11, #1
	stp	w16, w15, [sp, #64]             ; 8-byte Folded Spill
	add	w14, w15, w12
	str	w14, [sp, #260]                 ; 4-byte Folded Spill
	add	w14, w16, w11
	str	x14, [sp, #248]                 ; 8-byte Folded Spill
	lsr	x13, x13, #8
	neg	w14, w13
	str	x14, [sp, #240]                 ; 8-byte Folded Spill
	stp	w0, w17, [sp, #56]              ; 8-byte Folded Spill
	add	w14, w17, w9
	str	w14, [sp, #236]                 ; 4-byte Folded Spill
	add	w14, w0, w8
	str	x14, [sp, #224]                 ; 8-byte Folded Spill
	stp	w2, w1, [sp, #48]               ; 8-byte Folded Spill
	add	w14, w1, w12
	str	w14, [sp, #220]                 ; 4-byte Folded Spill
	add	w14, w2, w11
	str	x14, [sp, #208]                 ; 8-byte Folded Spill
	stp	w4, w3, [sp, #40]               ; 8-byte Folded Spill
	add	w14, w3, w9
	str	w14, [sp, #204]                 ; 4-byte Folded Spill
	add	w14, w4, w8
	str	x14, [sp, #192]                 ; 8-byte Folded Spill
	stp	w6, w5, [sp, #32]               ; 8-byte Folded Spill
	add	w14, w5, w12
	str	w14, [sp, #188]                 ; 4-byte Folded Spill
	add	w14, w6, w11
	str	x14, [sp, #176]                 ; 8-byte Folded Spill
	stp	w19, w7, [sp, #24]              ; 8-byte Folded Spill
	add	w9, w7, w9
	str	w9, [sp, #172]                  ; 4-byte Folded Spill
	add	w8, w19, w8
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	stp	w25, w22, [sp, #16]             ; 8-byte Folded Spill
	add	w8, w22, w12
	str	w8, [sp, #156]                  ; 4-byte Folded Spill
	add	w8, w25, w11
	str	x8, [sp, #144]                  ; 8-byte Folded Spill
	neg	w9, w10, lsl #1
	neg	w8, w13, lsl #1
	stp	w8, w9, [sp, #136]              ; 8-byte Folded Spill
	str	x28, [sp, #288]                 ; 8-byte Folded Spill
LBB1_2:                                 ;   Parent Loop BB1_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	orr	x9, x20, #0x1
	add	x19, x20, #1
	orr	x8, x20, #0x2
	stp	x8, x9, [sp, #120]              ; 16-byte Folded Spill
	add	x30, x20, #2
	ldr	x8, [sp, #272]                  ; 8-byte Folded Reload
	add	w8, w8, w20
	and	w8, w8, #0xffff
	ldr	w9, [sp, #284]                  ; 4-byte Folded Reload
	add	w9, w9, w23
	and	w9, w9, #0x10000
	sub	w8, w8, w9
	ldr	x9, [sp, #264]                  ; 8-byte Folded Reload
	add	w15, w9, w20
	add	w9, w15, #91
	and	w9, w9, #0xffff
	ldr	w10, [sp, #140]                 ; 4-byte Folded Reload
	add	w16, w10, w23
	add	w10, w16, #182
	and	w10, w10, #0x10000
	sub	w9, w9, w10
	ldr	x10, [sp, #224]                 ; 8-byte Folded Reload
	add	w10, w10, w20
	and	w10, w10, #0xffff
	ldr	w11, [sp, #236]                 ; 4-byte Folded Reload
	add	w11, w11, w23
	and	w11, w11, #0x10000
	sub	w10, w10, w11
	add	w11, w15, #92
	and	w11, w11, #0xffff
	add	w12, w16, #184
	and	w12, w12, #0x10000
	sub	w11, w11, w12
	ldr	x12, [sp, #192]                 ; 8-byte Folded Reload
	add	w12, w12, w20
	and	w12, w12, #0xffff
	ldr	w13, [sp, #204]                 ; 4-byte Folded Reload
	add	w13, w13, w23
	and	w13, w13, #0x10000
	sub	w12, w12, w13
	add	w13, w15, #93
	and	w13, w13, #0xffff
	add	w14, w16, #186
	and	w14, w14, #0x10000
	sub	w13, w13, w14
	ldr	x14, [sp, #160]                 ; 8-byte Folded Reload
	add	w14, w14, w20
	and	w14, w14, #0xffff
	ldr	w17, [sp, #172]                 ; 4-byte Folded Reload
	add	w17, w17, w23
	and	w17, w17, #0x10000
	sub	w14, w14, w17
	add	w15, w15, #94
	and	w15, w15, #0xffff
	add	w16, w16, #188
	and	w16, w16, #0x10000
	sub	w15, w15, w16
	ldr	x16, [sp, #144]                 ; 8-byte Folded Reload
	add	w16, w16, w20
	and	w16, w16, #0xffff
	ldr	w17, [sp, #156]                 ; 4-byte Folded Reload
	add	w17, w17, w23
	and	w17, w17, #0x10000
	sub	w16, w16, w17
	ldr	x17, [sp, #240]                 ; 8-byte Folded Reload
	add	w5, w17, w20
	add	w17, w5, #47
	and	w17, w17, #0xffff
	ldr	w0, [sp, #136]                  ; 4-byte Folded Reload
	add	w6, w0, w23
	add	w0, w6, #94
	and	w0, w0, #0x10000
	sub	w17, w17, w0
	ldr	x0, [sp, #176]                  ; 8-byte Folded Reload
	add	w0, w0, w20
	and	w0, w0, #0xffff
	ldr	w1, [sp, #188]                  ; 4-byte Folded Reload
	add	w1, w1, w23
	and	w1, w1, #0x10000
	sub	w0, w0, w1
	add	w1, w5, #46
	and	w1, w1, #0xffff
	add	w2, w6, #92
	and	w2, w2, #0x10000
	sub	w1, w1, w2
	ldr	x2, [sp, #208]                  ; 8-byte Folded Reload
	add	w2, w2, w20
	and	w2, w2, #0xffff
	ldr	w3, [sp, #220]                  ; 4-byte Folded Reload
	add	w3, w3, w23
	and	w3, w3, #0x10000
	sub	w2, w2, w3
	add	w3, w5, #45
	and	w3, w3, #0xffff
	add	w4, w6, #90
	and	w4, w4, #0x10000
	sub	w3, w3, w4
	ldr	x4, [sp, #248]                  ; 8-byte Folded Reload
	add	w4, w4, w20
	and	w4, w4, #0xffff
	ldr	w7, [sp, #260]                  ; 4-byte Folded Reload
	str	w23, [sp, #300]                 ; 4-byte Folded Spill
	add	w7, w7, w23
	and	w7, w7, #0x10000
	sub	w4, w4, w7
	orr	x7, x20, #0x3
	str	x7, [sp, #112]                  ; 8-byte Folded Spill
	add	w5, w5, #44
	and	w5, w5, #0xffff
	add	w6, w6, #88
	and	w6, w6, #0x10000
	sub	w5, w5, w6
	add	x26, x20, #3
	bic	w8, w8, w8, asr #31
	cmp	w8, #255
	mov	w6, #255                        ; =0xff
	csel	w8, w8, w6, lt
	str	x8, [sp, #312]                  ; 8-byte Folded Spill
	bic	w8, w9, w9, asr #31
	cmp	w8, #255
	csel	w8, w8, w6, lt
	str	x8, [sp, #304]                  ; 8-byte Folded Spill
	bic	w8, w10, w10, asr #31
	cmp	w8, #255
	csel	w8, w8, w6, lt
	str	x8, [sp, #320]                  ; 8-byte Folded Spill
	bic	w8, w11, w11, asr #31
	cmp	w8, #255
	csel	w8, w8, w6, lt
	str	x8, [sp, #344]                  ; 8-byte Folded Spill
	bic	w8, w12, w12, asr #31
	cmp	w8, #255
	csel	w8, w8, w6, lt
	str	x8, [sp, #328]                  ; 8-byte Folded Spill
	bic	w8, w13, w13, asr #31
	cmp	w8, #255
	csel	w8, w8, w6, lt
	str	x8, [sp, #352]                  ; 8-byte Folded Spill
	bic	w8, w14, w14, asr #31
	cmp	w8, #255
	csel	w8, w8, w6, lt
	str	x8, [sp, #336]                  ; 8-byte Folded Spill
	bic	w8, w15, w15, asr #31
	cmp	w8, #255
	csel	w8, w8, w6, lt
	str	x8, [sp, #360]                  ; 8-byte Folded Spill
	bic	w8, w16, w16, asr #31
	add	x10, sp, #8, lsl #12            ; =32768
	add	x10, x10, #432
	str	x28, [x10, #12288]
	str	x20, [x10, #20480]
	cmp	w8, #255
	csel	w8, w8, w6, lt
	str	x8, [sp, #368]                  ; 8-byte Folded Spill
	bic	w8, w17, w17, asr #31
	str	x20, [x10, #18432]
	str	x20, [x10, #16384]
	cmp	w8, #255
	csel	w24, w8, w6, lt
	bic	w8, w0, w0, asr #31
	str	x28, [x10, #12296]
	str	x19, [x10, #20488]
	cmp	w8, #255
	csel	w8, w8, w6, lt
	str	x8, [sp, #376]                  ; 8-byte Folded Spill
	bic	w8, w1, w1, asr #31
	str	x19, [x10, #18440]
	mov	x22, x19
	str	x19, [x10, #16392]
	cmp	w8, #255
	csel	w27, w8, w6, lt
	bic	w8, w2, w2, asr #31
	str	x28, [x10, #12304]
	str	x30, [x10, #20496]
	cmp	w8, #255
	csel	w21, w8, w6, lt
	bic	w8, w3, w3, asr #31
	str	x30, [x10, #18448]
	mov	x23, x30
	str	x30, [x10, #16400]
	cmp	w8, #255
	csel	w19, w8, w6, lt
	bic	w8, w4, w4, asr #31
	str	x28, [x10, #12312]
	str	x26, [x10, #20504]
	cmp	w8, #255
	csel	w25, w8, w6, lt
	bic	w8, w5, w5, asr #31
	str	x26, [x10, #18456]
	str	x26, [x10, #16408]
	cmp	w8, #255
	csel	w28, w8, w6, lt
	add	x0, sp, #8, lsl #12             ; =32768
	add	x0, x0, #432
	mov	w1, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	bl	_color4
	add	x10, sp, #8, lsl #12            ; =32768
	add	x10, x10, #432
	ldr	x8, [x10, #16384]
	mov	x14, x20
	cmp	x20, x8
	b.ne	LBB1_43
; %bb.3:                                ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x10, #18432]
	cmp	x8, x28
	ldr	x15, [sp, #368]                 ; 8-byte Folded Reload
	b.ne	LBB1_42
; %bb.4:                                ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x10, #20480]
	cmp	x8, x25
	ldr	x16, [sp, #376]                 ; 8-byte Folded Reload
	mov	x20, x14
	b.ne	LBB1_39
; %bb.5:                                ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x10, #16392]
	cmp	x22, x8
	b.ne	LBB1_39
; %bb.6:                                ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x10, #18440]
	cmp	x8, x19
	b.ne	LBB1_39
; %bb.7:                                ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x10, #20488]
	cmp	x8, x21
	b.ne	LBB1_39
; %bb.8:                                ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x10, #16400]
	cmp	x23, x8
	b.ne	LBB1_39
; %bb.9:                                ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x10, #18448]
	cmp	x8, x27
	b.ne	LBB1_39
; %bb.10:                               ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x10, #20496]
	cmp	x8, x16
	b.ne	LBB1_39
; %bb.11:                               ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x10, #16408]
	cmp	x26, x8
	b.ne	LBB1_39
; %bb.12:                               ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x10, #18456]
	cmp	x8, x24
	b.ne	LBB1_39
; %bb.13:                               ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x10, #20504]
	cmp	x8, x15
	b.ne	LBB1_39
; %bb.14:                               ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [sp, #288]                  ; 8-byte Folded Reload
	str	x8, [x10, #12288]
	str	x20, [x10, #20480]
	str	x20, [x10, #18432]
	str	x20, [x10, #16384]
	str	x8, [x10, #12296]
	str	x22, [x10, #20488]
	str	x22, [x10, #18440]
	str	x22, [x10, #16392]
	str	x8, [x10, #12304]
	str	x23, [x10, #20496]
	str	x23, [x10, #18448]
	str	x23, [x10, #16400]
	mov	x28, x8
	str	x8, [x10, #12312]
	str	x26, [x10, #20504]
	str	x26, [x10, #18456]
	str	x26, [x10, #16408]
	add	x0, sp, #8, lsl #12             ; =32768
	add	x0, x0, #432
	mov	w1, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	bl	_color4
	add	x15, sp, #8, lsl #12            ; =32768
	add	x15, x15, #432
	ldr	x8, [x15, #16384]
	ldp	x12, x14, [sp, #304]            ; 16-byte Folded Reload
	cmp	x8, x14
	b.ne	LBB1_40
; %bb.15:                               ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x15, #18432]
	cmp	x8, x12
	b.ne	LBB1_40
; %bb.16:                               ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x15, #20480]
	cmp	x20, x8
	ldp	x27, x24, [sp, #352]            ; 16-byte Folded Reload
	ldp	x9, x19, [sp, #336]             ; 16-byte Folded Reload
	ldp	x11, x10, [sp, #320]            ; 16-byte Folded Reload
	b.ne	LBB1_41
; %bb.17:                               ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x15, #16392]
	cmp	x8, x11
	b.ne	LBB1_41
; %bb.18:                               ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x15, #18440]
	cmp	x8, x19
	b.ne	LBB1_41
; %bb.19:                               ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x15, #20488]
	cmp	x22, x8
	b.ne	LBB1_41
; %bb.20:                               ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x15, #16400]
	cmp	x8, x10
	b.ne	LBB1_41
; %bb.21:                               ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x15, #18448]
	cmp	x8, x27
	b.ne	LBB1_41
; %bb.22:                               ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x15, #20496]
	cmp	x23, x8
	b.ne	LBB1_41
; %bb.23:                               ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x15, #16408]
	cmp	x8, x9
	b.ne	LBB1_41
; %bb.24:                               ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x15, #18456]
	cmp	x8, x24
	b.ne	LBB1_41
; %bb.25:                               ;   in Loop: Header=BB1_2 Depth=2
	ldr	x8, [x15, #20504]
	cmp	x26, x8
	b.ne	LBB1_41
; %bb.26:                               ;   in Loop: Header=BB1_2 Depth=2
	str	x28, [sp, #12720]
	str	x12, [sp, #18864]
	str	x14, [sp, #16816]
	str	x28, [sp, #12728]
	str	x22, [sp, #20920]
	str	x11, [sp, #16824]
	str	x28, [sp, #12736]
	str	x23, [sp, #20928]
	str	x10, [sp, #16832]
	str	x28, [sp, #12744]
	str	x26, [sp, #20936]
	ldr	w23, [sp, #300]                 ; 4-byte Folded Reload
	add	w23, w23, #8
	str	x9, [sp, #16840]
	mov	w8, #65531                      ; =0xfffb
	cmp	x20, x8
	str	x20, [sp, #20912]
	add	x20, x20, #4
	b.ls	LBB1_2
; %bb.27:                               ;   in Loop: Header=BB1_1 Depth=1
	add	x28, x28, #1
	ldp	w14, w12, [sp, #72]             ; 8-byte Folded Reload
	add	w12, w12, #2
	str	x19, [sp, #18872]
	ldp	x8, x10, [sp, #80]              ; 16-byte Folded Reload
	add	x8, x8, #103
	add	w14, w14, #1
	str	x27, [sp, #18880]
	add	x10, x10, #183
	ldp	w16, w15, [sp, #64]             ; 8-byte Folded Reload
	add	w15, w15, #2
	str	x24, [sp, #18888]
	ldp	x11, x13, [sp, #96]             ; 16-byte Folded Reload
	add	x11, x11, #198
	add	w16, w16, #1
	add	x13, x13, #88
	ldp	w0, w17, [sp, #56]              ; 8-byte Folded Reload
	add	w17, w17, #2
	add	w0, w0, #1
	ldp	w2, w1, [sp, #48]               ; 8-byte Folded Reload
	add	w1, w1, #2
	add	w2, w2, #1
	ldp	w4, w3, [sp, #40]               ; 8-byte Folded Reload
	add	w3, w3, #2
	add	w4, w4, #1
	ldp	w6, w5, [sp, #32]               ; 8-byte Folded Reload
	add	w5, w5, #2
	add	w6, w6, #1
	ldp	w19, w7, [sp, #24]              ; 8-byte Folded Reload
	add	w7, w7, #2
	add	w19, w19, #1
	ldp	w25, w22, [sp, #16]             ; 8-byte Folded Reload
	add	w22, w22, #2
	add	w25, w25, #1
	cmp	x28, #256
	b.ne	LBB1_1
; %bb.28:
	mov	w21, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
	mov	w9, #2                          ; =0x2
	mov	w10, #7                         ; =0x7
	stp	xzr, x8, [sp, #384]
	mov	x8, #-9223372036854775808       ; =0x8000000000000000
	mov	x11, #9223372036854775807       ; =0x7fffffffffffffff
	mov	x23, #55556                     ; =0xd904
	movk	x23, #50049, lsl #16
	movk	x23, #24327, lsl #32
	movk	x23, #15074, lsl #48
	add	x22, sp, #8, lsl #12            ; =32768
	add	x22, x22, #432
	stp	x9, x10, [sp, #400]
	stp	x8, x11, [sp, #416]
	mov	w24, #88                        ; =0x58
	mov	w25, #198                       ; =0xc6
	mov	w26, #255                       ; =0xff
	mov	w27, #103                       ; =0x67
	mov	w28, #183                       ; =0xb7
LBB1_29:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_30 Depth 2
	mov	x8, #0                          ; =0x0
LBB1_30:                                ;   Parent Loop BB1_29 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	eor	x9, x23, x23, lsl #13
	eor	x9, x9, x9, lsr #7
	eor	x23, x9, x9, lsl #17
	str	x23, [x22, x8]
	add	x8, x8, #8
	cmp	x8, #8, lsl #12                 ; =32768
	b.ne	LBB1_30
; %bb.31:                               ;   in Loop: Header=BB1_29 Depth=1
	add	x0, sp, #432
	add	x1, sp, #8, lsl #12             ; =32768
	add	x1, x1, #432
	mov	w2, #32768                      ; =0x8000
	bl	_memcpy
	eor	x8, x23, x23, lsl #13
	eor	x8, x8, x8, lsr #7
	eor	x23, x8, x8, lsl #17
	mov	x8, #44049                      ; =0xac11
	movk	x8, #52643, lsl #16
	movk	x8, #5371, lsl #32
	movk	x8, #3223, lsl #48
	umulh	x8, x23, x8
	sub	x9, x23, x8
	add	x8, x8, x9, lsr #1
	lsr	x8, x8, #5
	mov	w9, #61                         ; =0x3d
	msub	x20, x8, x9, x23
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #43690, lsl #16
	umull	x8, w21, w8
	lsr	x8, x8, #34
	mov	w9, #6                          ; =0x6
	msub	w8, w8, w9, w21
	add	x9, sp, #384
	ldr	x19, [x9, w8, uxtw #3]
	add	x0, sp, #8, lsl #12             ; =32768
	add	x0, x0, #432
	mov	x1, x19
	mov	x2, x20
	bl	_color4
	add	x8, sp, #432
	add	x8, x8, x20, lsl #3
	mov	w9, #12288                      ; =0x3000
	ldrb	w9, [x8, x9]
	cbz	x19, LBB1_34
; %bb.32:                               ;   in Loop: Header=BB1_29 Depth=1
	cmp	x19, #1
	b.ne	LBB1_36
; %bb.33:                               ;   in Loop: Header=BB1_29 Depth=1
	umull	x10, w9, w24
	lsr	x10, x10, #8
	umull	x11, w9, w25
	lsr	x11, x11, #8
	mov	w12, #20480                     ; =0x5000
	ldr	w12, [x8, x12]
	add	w9, w9, w12
	add	w9, w11, w9
	mov	w11, #18432                     ; =0x4800
	ldr	w11, [x8, x11]
	sub	w10, w11, w10
	add	w10, w10, #44
	and	w11, w10, #0xffff
	lsl	w10, w10, #1
	and	w10, w10, #0x10000
	sub	w10, w11, w10
	bic	w10, w10, w10, asr #31
	cmp	w10, #255
	csel	w10, w10, w26, lt
	str	x10, [x8, #18432]
	sub	w9, w9, #227
	and	w10, w9, #0xffff
	lsl	w9, w9, #1
	and	w9, w9, #0x10000
	sub	w9, w10, w9
	bic	w9, w9, w9, asr #31
	cmp	w9, #255
	csel	w9, w9, w26, lt
	str	x9, [x8, #20480]
	mov	w9, #12296                      ; =0x3008
	ldrb	w9, [x8, x9]
	umull	x10, w9, w24
	lsr	x10, x10, #8
	umull	x11, w9, w25
	lsr	x11, x11, #8
	mov	w12, #20488                     ; =0x5008
	ldr	w12, [x8, x12]
	add	w9, w9, w12
	add	w9, w11, w9
	mov	w11, #18440                     ; =0x4808
	ldr	w11, [x8, x11]
	sub	w10, w11, w10
	add	w10, w10, #44
	and	w11, w10, #0xffff
	lsl	w10, w10, #1
	and	w10, w10, #0x10000
	sub	w10, w11, w10
	bic	w10, w10, w10, asr #31
	cmp	w10, #255
	csel	w10, w10, w26, lt
	str	x10, [x8, #18440]
	sub	w9, w9, #227
	and	w10, w9, #0xffff
	lsl	w9, w9, #1
	and	w9, w9, #0x10000
	sub	w9, w10, w9
	bic	w9, w9, w9, asr #31
	cmp	w9, #255
	csel	w9, w9, w26, lt
	str	x9, [x8, #20488]
	mov	w9, #12304                      ; =0x3010
	ldrb	w9, [x8, x9]
	umull	x10, w9, w24
	lsr	x10, x10, #8
	umull	x11, w9, w25
	lsr	x11, x11, #8
	mov	w12, #20496                     ; =0x5010
	ldr	w12, [x8, x12]
	add	w9, w9, w12
	add	w9, w11, w9
	mov	w11, #18448                     ; =0x4810
	ldr	w11, [x8, x11]
	sub	w10, w11, w10
	add	w10, w10, #44
	and	w11, w10, #0xffff
	lsl	w10, w10, #1
	and	w10, w10, #0x10000
	sub	w10, w11, w10
	bic	w10, w10, w10, asr #31
	cmp	w10, #255
	csel	w10, w10, w26, lt
	str	x10, [x8, #18448]
	sub	w9, w9, #227
	and	w10, w9, #0xffff
	lsl	w9, w9, #1
	and	w9, w9, #0x10000
	sub	w9, w10, w9
	bic	w9, w9, w9, asr #31
	cmp	w9, #255
	csel	w9, w9, w26, lt
	mov	w10, #12312                     ; =0x3018
	ldrb	w10, [x8, x10]
	str	x9, [x8, #20496]
	umull	x9, w10, w24
	lsr	x9, x9, #8
	umull	x11, w10, w25
	mov	w12, #20504                     ; =0x5018
	ldr	w12, [x8, x12]
	lsr	x11, x11, #8
	add	w10, w10, w12
	add	w10, w11, w10
	mov	w11, #18456                     ; =0x4818
	ldr	w11, [x8, x11]
	sub	w9, w11, w9
	add	w9, w9, #44
	and	w11, w9, #0xffff
	lsl	w9, w9, #1
	and	w9, w9, #0x10000
	sub	w9, w11, w9
	bic	w9, w9, w9, asr #31
	cmp	w9, #255
	csel	w9, w9, w26, lt
	str	x9, [x8, #18456]
	sub	w9, w10, #227
	and	w10, w9, #0xffff
	lsl	w9, w9, #1
	and	w9, w9, #0x10000
	sub	w9, w10, w9
	bic	w9, w9, w9, asr #31
	cmp	w9, #255
	csel	w9, w9, w26, lt
	b	LBB1_35
LBB1_34:                                ;   in Loop: Header=BB1_29 Depth=1
	str	x9, [x8, #16384]
	str	x9, [x8, #18432]
	str	x9, [x8, #20480]
	mov	w9, #12296                      ; =0x3008
	ldrb	w9, [x8, x9]
	str	x9, [x8, #16392]
	str	x9, [x8, #18440]
	str	x9, [x8, #20488]
	mov	w9, #12304                      ; =0x3010
	ldrb	w9, [x8, x9]
	str	x9, [x8, #16400]
	str	x9, [x8, #18448]
	str	x9, [x8, #20496]
	mov	w9, #12312                      ; =0x3018
	ldrb	w9, [x8, x9]
	str	x9, [x8, #16408]
	str	x9, [x8, #18456]
LBB1_35:                                ;   in Loop: Header=BB1_29 Depth=1
	str	x9, [x8, #20504]
	add	x0, sp, #8, lsl #12             ; =32768
	add	x0, x0, #432
	add	x1, sp, #432
	mov	w2, #32768                      ; =0x8000
	bl	_memcmp
	cbz	w0, LBB1_37
	b	LBB1_46
LBB1_36:                                ;   in Loop: Header=BB1_29 Depth=1
	umull	x10, w9, w27
	lsr	x10, x10, #8
	mov	w11, #16384                     ; =0x4000
	ldr	w11, [x8, x11]
	add	w11, w9, w11
	add	w10, w10, w11
	umull	x9, w9, w28
	lsr	x9, x9, #8
	sub	w10, w10, #179
	and	w11, w10, #0xffff
	lsl	w10, w10, #1
	and	w10, w10, #0x10000
	sub	w10, w11, w10
	bic	w10, w10, w10, asr #31
	cmp	w10, #255
	csel	w10, w10, w26, lt
	str	x10, [x8, #16384]
	mov	w10, #18432                     ; =0x4800
	ldr	w10, [x8, x10]
	sub	w9, w10, w9
	add	w9, w9, #91
	and	w10, w9, #0xffff
	lsl	w9, w9, #1
	and	w9, w9, #0x10000
	sub	w9, w10, w9
	bic	w9, w9, w9, asr #31
	cmp	w9, #255
	csel	w9, w9, w26, lt
	str	x9, [x8, #18432]
	mov	w9, #12296                      ; =0x3008
	ldrb	w9, [x8, x9]
	umull	x10, w9, w27
	lsr	x10, x10, #8
	mov	w11, #16392                     ; =0x4008
	ldr	w11, [x8, x11]
	add	w11, w9, w11
	add	w10, w10, w11
	umull	x9, w9, w28
	lsr	x9, x9, #8
	sub	w10, w10, #179
	and	w11, w10, #0xffff
	lsl	w10, w10, #1
	and	w10, w10, #0x10000
	sub	w10, w11, w10
	bic	w10, w10, w10, asr #31
	cmp	w10, #255
	csel	w10, w10, w26, lt
	str	x10, [x8, #16392]
	mov	w10, #18440                     ; =0x4808
	ldr	w10, [x8, x10]
	sub	w9, w10, w9
	add	w9, w9, #91
	and	w10, w9, #0xffff
	lsl	w9, w9, #1
	and	w9, w9, #0x10000
	sub	w9, w10, w9
	bic	w9, w9, w9, asr #31
	cmp	w9, #255
	csel	w9, w9, w26, lt
	str	x9, [x8, #18440]
	mov	w9, #12304                      ; =0x3010
	ldrb	w9, [x8, x9]
	umull	x10, w9, w27
	lsr	x10, x10, #8
	mov	w11, #16400                     ; =0x4010
	ldr	w11, [x8, x11]
	add	w11, w9, w11
	add	w10, w10, w11
	umull	x9, w9, w28
	lsr	x9, x9, #8
	sub	w10, w10, #179
	and	w11, w10, #0xffff
	lsl	w10, w10, #1
	and	w10, w10, #0x10000
	sub	w10, w11, w10
	bic	w10, w10, w10, asr #31
	cmp	w10, #255
	csel	w10, w10, w26, lt
	mov	w11, #18448                     ; =0x4810
	ldr	w11, [x8, x11]
	str	x10, [x8, #16400]
	sub	w9, w11, w9
	add	w9, w9, #91
	and	w10, w9, #0xffff
	lsl	w9, w9, #1
	and	w9, w9, #0x10000
	sub	w9, w10, w9
	bic	w9, w9, w9, asr #31
	cmp	w9, #255
	csel	w9, w9, w26, lt
	mov	w10, #12312                     ; =0x3018
	ldrb	w10, [x8, x10]
	str	x9, [x8, #18448]
	umull	x9, w10, w27
	lsr	x9, x9, #8
	mov	w11, #16408                     ; =0x4018
	ldr	w11, [x8, x11]
	add	w11, w10, w11
	add	w9, w9, w11
	umull	x10, w10, w28
	lsr	x10, x10, #8
	sub	w9, w9, #179
	and	w11, w9, #0xffff
	lsl	w9, w9, #1
	and	w9, w9, #0x10000
	sub	w9, w11, w9
	bic	w9, w9, w9, asr #31
	cmp	w9, #255
	csel	w9, w9, w26, lt
	str	x9, [x8, #16408]
	mov	w9, #18456                      ; =0x4818
	ldr	w9, [x8, x9]
	sub	w9, w9, w10
	add	w9, w9, #91
	and	w10, w9, #0xffff
	lsl	w9, w9, #1
	and	w9, w9, #0x10000
	sub	w9, w10, w9
	bic	w9, w9, w9, asr #31
	cmp	w9, #255
	csel	w9, w9, w26, lt
	str	x9, [x8, #18456]
	add	x0, sp, #8, lsl #12             ; =32768
	add	x0, x0, #432
	add	x1, sp, #432
	mov	w2, #32768                      ; =0x8000
	bl	_memcmp
	cbnz	w0, LBB1_46
LBB1_37:                                ;   in Loop: Header=BB1_29 Depth=1
	add	w21, w21, #1
	mov	w8, #10000                      ; =0x2710
	cmp	w21, w8
	b.ne	LBB1_29
; %bb.38:
	mov	w8, #33554432                   ; =0x2000000
	str	x8, [sp]
Lloh5:
	adrp	x0, l_.str@PAGE
Lloh6:
	add	x0, x0, l_.str@PAGEOFF
	bl	_printf
	mov	w0, #0                          ; =0x0
	ldur	x8, [x29, #-96]
Lloh7:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh8:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh9:
	ldr	x9, [x9]
	cmp	x9, x8
	b.eq	LBB1_45
	b	LBB1_47
LBB1_39:
	ldp	x9, x10, [sp, #112]             ; 16-byte Folded Reload
	ldr	x11, [sp, #128]                 ; 8-byte Folded Reload
	mov	x12, x28
	mov	x14, x20
	ldr	x28, [sp, #288]                 ; 8-byte Folded Reload
	b	LBB1_44
LBB1_40:
	add	x21, x20, #1
	add	x16, x20, #2
	add	x15, x20, #3
	mov	x25, x20
	ldp	x27, x24, [sp, #352]            ; 16-byte Folded Reload
	ldp	x9, x19, [sp, #336]             ; 16-byte Folded Reload
	ldp	x11, x10, [sp, #320]            ; 16-byte Folded Reload
	b	LBB1_44
LBB1_41:
	ldp	x15, x16, [sp, #112]            ; 16-byte Folded Reload
	ldr	x21, [sp, #128]                 ; 8-byte Folded Reload
	mov	x25, x20
	b	LBB1_44
LBB1_42:
	ldp	x9, x10, [sp, #112]             ; 16-byte Folded Reload
	ldr	x11, [sp, #128]                 ; 8-byte Folded Reload
	mov	x12, x28
	ldr	x28, [sp, #288]                 ; 8-byte Folded Reload
	ldr	x16, [sp, #376]                 ; 8-byte Folded Reload
	b	LBB1_44
LBB1_43:
	ldp	x9, x10, [sp, #112]             ; 16-byte Folded Reload
	ldr	x11, [sp, #128]                 ; 8-byte Folded Reload
	mov	x12, x28
	ldr	x28, [sp, #288]                 ; 8-byte Folded Reload
	ldp	x15, x16, [sp, #368]            ; 16-byte Folded Reload
LBB1_44:
	str	x19, [sp, #18872]
	str	x27, [sp, #18880]
	str	x24, [sp, #18888]
	str	x28, [sp, #12720]
	str	x25, [sp, #20912]
	str	x12, [sp, #18864]
	str	x14, [sp, #16816]
	str	x28, [sp, #12728]
	str	x21, [sp, #20920]
	str	x11, [sp, #16824]
	str	x28, [sp, #12736]
	str	x16, [sp, #20928]
	str	x10, [sp, #16832]
	str	x28, [sp, #12744]
	str	x15, [sp, #20936]
	mov	w0, #1                          ; =0x1
	str	x9, [sp, #16840]
	ldur	x8, [x29, #-96]
Lloh10:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh11:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh12:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB1_47
LBB1_45:
	add	sp, sp, #16, lsl #12            ; =65536
	add	sp, sp, #448
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB1_46:
	mov	w0, #2                          ; =0x2
	ldur	x8, [x29, #-96]
Lloh13:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh14:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh15:
	ldr	x9, [x9]
	cmp	x9, x8
	b.eq	LBB1_45
LBB1_47:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh2, Lloh3, Lloh4
	.loh AdrpLdrGotLdr	Lloh7, Lloh8, Lloh9
	.loh AdrpAdd	Lloh5, Lloh6
	.loh AdrpLdrGotLdr	Lloh10, Lloh11, Lloh12
	.loh AdrpLdrGotLdr	Lloh13, Lloh14, Lloh15
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"PASS_COLOR4_NEON_EXHAUSTIVE_C256_RGB65536_TWO_VARIANTS_%llu_PIXELS_FULL64_RANDOM10000_ALL4096_WORDS\n"

.subsections_via_symbols
