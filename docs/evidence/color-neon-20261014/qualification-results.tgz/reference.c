#include <arm_neon.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>

static uint16x4_t low16(const uint64_t *p) {
    uint32x4_t x=vcombine_u32(vmovn_u64(vld1q_u64(p)),vmovn_u64(vld1q_u64(p+2)));
    return vmovn_u32(x);
}
static void store64(uint64_t *p,uint16x4_t x) {
    uint32x4_t y=vmovl_u16(x);
    vst1q_u64(p,vmovl_u32(vget_low_u32(y)));
    vst1q_u64(p+2,vmovl_u32(vget_high_u32(y)));
}
static uint16x4_t clamp16(uint16x4_t x) {
    int16x4_t y=vmax_s16(vreinterpret_s16_u16(x),vdup_n_s16(0));
    return vreinterpret_u16_s16(vmin_s16(y,vdup_n_s16(255)));
}
__attribute__((noinline)) void color4(uint64_t *v,int64_t block,unsigned i) {
    uint16x4_t c=vand_u16(low16(v+1536+i),vdup_n_u16(255));
    if(block==0) {
        store64(v+2048+i,c);store64(v+2304+i,c);store64(v+2560+i,c);
    } else if(block==1) {
        uint16x4_t cg=vsub_u16(vshr_n_u16(vmul_u16(c,vdup_n_u16(88)),8),vdup_n_u16(44));
        uint16x4_t cb=vsub_u16(vadd_u16(c,vshr_n_u16(vmul_u16(c,vdup_n_u16(198)),8)),vdup_n_u16(227));
        store64(v+2304+i,clamp16(vsub_u16(low16(v+2304+i),cg)));
        store64(v+2560+i,clamp16(vadd_u16(low16(v+2560+i),cb)));
    } else {
        uint16x4_t cr=vsub_u16(vadd_u16(c,vshr_n_u16(vmul_u16(c,vdup_n_u16(103)),8)),vdup_n_u16(179));
        uint16x4_t cg=vsub_u16(vshr_n_u16(vmul_u16(c,vdup_n_u16(183)),8),vdup_n_u16(91));
        store64(v+2048+i,clamp16(vadd_u16(low16(v+2048+i),cr)));
        store64(v+2304+i,clamp16(vsub_u16(low16(v+2304+i),cg)));
    }
}
static int32_t signed16(uint64_t x) {
    uint32_t y=(uint16_t)x;return (int32_t)y-((y&32768)?65536:0);
}
static uint64_t pixel(uint64_t x) {
    int32_t y=signed16(x);return y<0?0:y>255?255:(uint64_t)y;
}
static void scalar(uint64_t *v,int64_t block,unsigned i) {
    uint64_t c=v[1536+i]&255;
    if(block==0) {v[2048+i]=c;v[2304+i]=c;v[2560+i]=c;}
    else if(block==1) {
        int32_t cg=signed16(c*88/256-44),cb=signed16(c+c*198/256-227);
        v[2304+i]=pixel(v[2304+i]-(uint64_t)(int64_t)cg);
        v[2560+i]=pixel(v[2560+i]+(uint64_t)(int64_t)cb);
    } else {
        int32_t cr=signed16(c+c*103/256-179),cg=signed16(c*183/256-91);
        v[2048+i]=pixel(v[2048+i]+(uint64_t)(int64_t)cr);
        v[2304+i]=pixel(v[2304+i]-(uint64_t)(int64_t)cg);
    }
}
static uint64_t next(uint64_t *s) {
    *s^=*s<<13;*s^=*s>>7;*s^=*s<<17;return *s;
}
int main(void) {
    uint64_t a[4096]={0},b[4096]={0},count=0;
    for(unsigned c=0;c<256;c++)for(unsigned x=0;x<65536;x+=4) {
        for(int block=1;block<=2;block++) {
            for(unsigned j=0;j<4;j++) {
                a[1536+j]=c;a[2048+j]=a[2304+j]=a[2560+j]=x+j;
                b[1536+j]=c;b[2048+j]=b[2304+j]=b[2560+j]=x+j;
            }
            color4(a,block,0);for(unsigned j=0;j<4;j++)scalar(b,block,j);
            for(unsigned j=0;j<4;j++)if(a[2048+j]!=b[2048+j]||a[2304+j]!=b[2304+j]||a[2560+j]!=b[2560+j])return 1;
            count+=4;
        }
    }
    uint64_t rng=UINT64_C(0x3ae25f07c381d904);
    const int64_t selectors[]={0,1,2,7,INT64_MIN,INT64_MAX};
    for(unsigned trial=0;trial<10000;trial++) {
        for(unsigned j=0;j<4096;j++)a[j]=next(&rng);
        memcpy(b,a,sizeof a);
        unsigned i=(unsigned)(next(&rng)%61);int64_t block=selectors[trial%6];
        color4(a,block,i);for(unsigned j=0;j<4;j++)scalar(b,block,i+j);
        if(memcmp(a,b,sizeof a))return 2;
    }
    printf("PASS_COLOR4_NEON_EXHAUSTIVE_C256_RGB65536_TWO_VARIANTS_%llu_PIXELS_FULL64_RANDOM10000_ALL4096_WORDS\n",(unsigned long long)count);
    return 0;
}
