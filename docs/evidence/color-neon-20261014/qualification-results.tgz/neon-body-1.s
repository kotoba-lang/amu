.text
.globl _neon_body_1
_neon_body_1:
	ldr	q0, [x9, #12288]
	ldr	q1, [x9, #12304]
	uzp1.4s	v0, v0, v1
	xtn.4h	v0, v0
	bic.4h	v0, #255, lsl #8
	movi.4h	v1, #88
	mul.4h	v1, v0, v1
	ushr.4h	v1, v1, #8
	movi.4h	v2, #198
	mul.4h	v2, v0, v2
	ldr	q3, [x9, #18432]
	ldr	q4, [x9, #18448]
	uzp1.4s	v3, v3, v4
	xtn.4h	v3, v3
	sub.4h	v1, v3, v1
	movi.4h	v3, #44
	add.4h	v1, v1, v3
	movi.2d	v3, #0000000000000000
	smax.4h	v1, v1, v3
	movi	d4, #0xff00ff00ff00ff
	smin.4h	v1, v1, v4
	ushll.4s	v1, v1, #0
	ushll.2d	v5, v1, #0
	str	q5, [x9, #18432]
	ushll2.2d	v1, v1, #0
	str	q1, [x9, #18448]
	ldr	q1, [x9, #20480]
	ldr	q5, [x9, #20496]
	uzp1.4s	v1, v1, v5
	xtn.4h	v1, v1
	usra.4h	v0, v2, #8
	mvni.4h	v2, #226
	add.4h	v1, v1, v2
	add.4h	v0, v0, v1
	smax.4h	v0, v0, v3
	smin.4h	v0, v0, v4
	ushll.4s	v0, v0, #0
	ushll.2d	v1, v0, #0
	str	q1, [x9, #20480]
	ushll2.2d	v0, v0, #0
	str	q0, [x9, #20496]
ret
