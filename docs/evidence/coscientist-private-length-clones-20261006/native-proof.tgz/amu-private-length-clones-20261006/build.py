from pathlib import Path
import subprocess,os,re,json,hashlib
W=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17')
g=(W/'baseline-41-a64gen.kotoba').read_text();g=g.replace('(defn- gn-loop [M :vector-i64 i :i64]', '(defn- gn-loop [M :vector-i64 i :i64 Safe :vector-i64]');g=g.replace('(gn-ins M i (gn-op M i))','(gn-ins (gn-gs M (+ gn-g-open-n 1) (vector-at Safe i)) i (gn-op M i))');g=g.replace('(gn-loop (gn-gs M1 gn-f-skip 0) (+ i 1 k))','(gn-loop (gn-gs M1 gn-f-skip 0) (+ i 1 k) Safe)')
g=g.replace('  (cond (and (gn-isk M t gn-k-lit) (= slot RT-PAIR-SECOND))','  (cond (and (pc-safe M) (= slot RT-VECTOR-AT) (= n 2)) (pc-at M i t)\n        (and (pc-safe M) (= slot RT-VECTOR-ASSOC-IN-PLACE) (= n 3)) (pc-set M t)\n        (and (gn-isk M t gn-k-lit) (= slot RT-PAIR-SECOND))')
g=g.replace('        M1 (mem-alloc M0 (+ gn-a-lp MM-LABEL-CAP 2))','        MR (pc-restore M0)\n        Safe (vector-alloc MM-SIR-CAP)\n        MP (pc-run MR Safe first count)\n        Origin (vector-at MP MM-R0)\n        M1 (mem-alloc MP (+ gn-a-lp MM-LABEL-CAP 5))').replace('(gn-loop M2 1)','(gn-loop M2 1 Safe)')
g=g.replace('(gn-gs gn-g-open-n count))', '(gn-gs gn-g-open-n count) (gn-gs (+ gn-g-open-n 2) Origin) (gn-gs (+ gn-g-open-n 3) 0x50434c43))')
helpers='\n'.join((W/p).read_text() for p in ['shape-native.kotoba','length-collect.kotoba','clones-native.kotoba']);g=g.replace('(defn- gn-run-open [',helpers+'\n(defn- gn-run-open [');(W/'41-a64gen-prototype.kotoba').write_text(g)
parts=[p.strip() for p in (R/'seed/MANIFEST').read_text().splitlines() if p.strip() and not p.lstrip().startswith('#')];unity='\n'.join(g if p=='seed/41-a64gen.kotoba' else (R/p).read_text() for p in parts);(W/'unity.kotoba').write_text(unity)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for label,args in [('compile',['compile',str(W/'unity.kotoba'),'--target','aarch64-macos','--output',str(W/'seed-1.kseed')]),('extract',['extract-native',str(W/'seed-1.kseed'),'--symbol','main','--output',str(W/'seed-1.bin')])]:
 q=subprocess.run([str(W/'kexe-loader'),str(W/'seed-0.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(W/('seed-1-'+label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout[-1000:],q.stderr)
 if label=='extract':(W/'seed-1.offset').write_text(re.search(r':offset (\d+)',q.stdout).group(1)+'\n')
print('PASS actual new candidate native seed generation1',flush=True)
