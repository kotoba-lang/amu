from pathlib import Path
import subprocess,os,re
W=Path(__file__).resolve().parent;src=(W/'adoption-permanent-test.kotoba').read_text();needle='    (if (and mask_shared (not mask_single) (not mask_limit)\n             (t-ar-guards)';assert needle in src
bindings=[]
for name in ['mask_shared','mask_single','mask_limit','hot_guard','cold_guard','hot_limit','bad_label_guard','foreign_guard']:
 bindings.append('p_'+name+' (t-out (string-concat "GUARD '+name+' " (string-concat (if '+name+' "true" "false") "\\n")))')
for name in ['start_limit','reader_closed','reader_wrong','reader_open','e3','closed','direct','transitive','independent','clamp_closed','clamp_open','sign_open']:
 bindings.append('p_'+name+' (t-out (string-concat "GUARD '+name+' " (string-concat (string-from-i64 '+name+') "\\n")))')
replacement='    (let [ar (t-ar-guards) p_ar (t-out (if ar "GUARD ar true\\n" "GUARD ar false\\n")) '+ ' '.join(bindings)+']\n     (if (and mask_shared (not mask_single) (not mask_limit)\n             ar'
src=src.replace(needle,replacement);src=src.rstrip()+')\n';(W/'guard-probe.kotoba').write_text(src)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');off=(W/'seed-4.offset').read_text().strip()
for label,args in [('compile',['compile',str(W/'guard-probe.kotoba'),'--target','aarch64-macos','--output',str(W/'guard-probe.kseed')]),('extract',['extract-native',str(W/'guard-probe.kseed'),'--symbol','main','--output',str(W/'guard-probe.bin')])]:
 q=subprocess.run([str(W/'kexe-loader'),str(W/'seed-4.bin'),off,'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(W/('guard-'+label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0
 if label=='extract':runoff=re.search(r':offset (\d+)',q.stdout)[1]
q=subprocess.run([str(W/'kexe-loader'),str(W/'guard-probe.bin'),runoff,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(W/'guard.stdout').write_text(q.stdout);(W/'guard.stderr').write_text(q.stderr);print(q.returncode, '\n'.join(line for line in q.stdout.splitlines() if line.startswith('GUARD')),q.stderr)
