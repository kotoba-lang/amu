from pathlib import Path
import subprocess,os,re,json,hashlib
W=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();g=(W/'41-a64gen-prototype.kotoba').read_text()
def out(prefix,fields):
 s='"\\n"'
 for x in reversed(fields):s=f'(string-concat (string-from-i64 {x}) (string-concat " " {s}))'
 return f'(io-out (string-concat "{prefix} " {s}))'
helpers='''
(defn- pc-print-fields [M :vector-i64 f :i64 k :i64] :i64
 (cond (>= f (vector-at M MM-FN-N)) 0
       (= k MM-FN-W) (pc-print-fields M (inc f) 0)
       :else (let [printed '''+out('PCFF',['f','k','(gn-fnf M f k)'])+'''] (pc-print-fields M f (inc k)))))
(defn- pc-print-jobs [J :vector-i64 j :i64] :i64
 (if (> j (vector-at J 0)) 0 (let [printed '''+out('PCJOB',['j',*[f'(vector-at J (+ {k} (* 4 j)))' for k in range(16,20)]])+'''] (pc-print-jobs J (inc j)))))
(defn- pc-print-facts [D :vector-i64 k :i64] :i64
 (if (> k (vector-at D 0)) 0 (let [printed '''+out('PCFACT',['k',*[f'(vector-at D (+ {v} (* 5 k)))' for v in range(16,21)]])+'''] (pc-print-facts D (inc k)))))
(defn- pc-print-safe [Safe :vector-i64 i :i64 end :i64] :i64
 (if (>= i end) 0 (let [printed (if (= (vector-at Safe i) 1) '''+out('PCSAFE',['i'])+''' 0)] (pc-print-safe Safe (inc i) end))))
(defn- pc-audit [M :vector-i64 J :vector-i64 D :vector-i64 Safe :vector-i64 phase :i64] :i64
 (let [header '''+out('PCPHASE',['phase','(vector-at M MM-FN-N)','(vector-at M MM-SIR-N)','(vector-at M MM-LABEL-N)','(vector-at J 4)','(vector-at D 4)'])+'''
       sir (sh-sir M 1) meta (sh-meta M 1) ff (pc-print-fields M 1 0) jobs (if (= phase 0) (pc-print-jobs J 1) 0)
       facts (if (= phase 0) (pc-print-facts D 1) 0) sf (if (= phase 1) (pc-print-safe Safe 1 (vector-at M MM-SIR-N)) 0)] 0))
'''
g=g.replace('j3 (pc-plan M j2 1)', 'j3 (pc-plan M j2 1)\n        audit_before (pc-audit M j3 D Safe 0)')
g=g.replace('(gn-put MM-R0 origin))] m2)', '(gn-put MM-R0 origin))\n          audit_after (pc-audit m2 j4 D Safe 1)] m2)')
assert g.count('audit_before')==1 and g.count('audit_after')==1
g=g.replace('(if (or (not fit) (= (vector-at j3 5) (vector-at M MM-FN-N))) (gn-put M MM-R0 0)', '(if (or (not fit) (= (vector-at j3 5) (vector-at M MM-FN-N))) (let [audit_no_clone (pc-audit M j3 D Safe 1)] (gn-put M MM-R0 0))')
assert g.count('audit_no_clone')==1
g=g.replace('(defn- gn-run-open [',helpers+'\n(defn- gn-run-open [')
parts=[p.strip() for p in (R/'seed/MANIFEST').read_text().splitlines() if p.strip() and not p.lstrip().startswith('#')];o=W/'observer';o.mkdir(exist_ok=True);(o/'41.kotoba').write_text(g);(o/'unity.kotoba').write_text('\n'.join(g if p=='seed/41-a64gen.kotoba' else (R/p).read_text() for p in parts));env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for label,args in [('compile',['compile',str(o/'unity.kotoba'),'--target','aarch64-macos','--output',str(o/'image.kseed')]),('extract',['extract-native',str(o/'image.kseed'),'--symbol','main','--output',str(o/'seed.bin')])]:
 q=subprocess.run([str(W/'kexe-loader'),str(W/'seed-0.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(o/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout[-1000:],q.stderr)
 if label=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
rows=[]
for e in json.loads((R/'bench/embench/comparison-matrix.json').read_text())['entries']:
 d=o/'ports'/e['workload'];d.mkdir(parents=True,exist_ok=True)
 for label,args in [('compile',['compile',str(R/e['source']),'--target','aarch64-macos','--output',str(d/'image.kseed')]),('extract',['extract-native',str(d/'image.kseed'),'--symbol',e['symbol'],'--output',str(d/'native.bin')])]:
  q=subprocess.run([str(W/'kexe-loader'),str(o/'seed.bin'),off,'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(e['workload'],label,q.stdout[-1000:],q.stderr)
  if label=='extract':offset=int(re.search(r':offset (\d+)',q.stdout).group(1))
 old=next(x for x in json.loads((W/'ports-build.json').read_text())['entries'] if x['workload']==e['workload']);assert sha(d/'native.bin')==old['nativeSha256'] and offset==old['offset'];rows.append({'workload':e['workload'],'nativeSha256':sha(d/'native.bin'),'offset':offset});print('PASS actual candidate observer parity',e['workload'],flush=True)
(o/'parity.json').write_text(json.dumps({'status':'PASS read-only pre/post/contexts/facts observer emits exact actual candidate bytes/offsets','entries':rows},indent=2)+'\n')
