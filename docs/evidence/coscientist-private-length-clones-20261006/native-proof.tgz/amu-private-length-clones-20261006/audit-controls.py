from pathlib import Path
import json,importlib.util
W=Path(__file__).resolve().parent;sp=importlib.util.spec_from_file_location('ir_audit',W/'ir-audit.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
p=W/'observer/ports/statemate/compile.log';s=p.read_text();assert v.audit(p)['clones']==532
lines=s.splitlines();phase=-1;indices={};safe=[]
for i,line in enumerate(lines):
 q=line.split()
 if not q:continue
 if q[0]=='PCPHASE':phase=int(q[1])
 if q[0]=='PCJOB' and int(q[3])>=0:indices.setdefault('job',i)
 if q[0]=='PCFACT':indices.setdefault('fact',i)
 if q[0]=='PCSAFE':safe.append(i)
 if phase==1 and q[0]=='PCFF' and int(q[1])==540 and int(q[2])==v.C['FF-EXPORT']:indices['export']=i
 if phase==1 and q[0]=='PCFF' and int(q[1])==540 and int(q[2])==v.C['FF-PT0']:indices['type']=i
 if phase==1 and q[0]=='SIR' and int(q[1])>=9740:
  op=int(q[2])
  if op==v.O('CALL'):indices.setdefault('call',i)
  if op==v.O('LABEL'):indices.setdefault('label',i)
  if op==v.O('BRZ'):indices.setdefault('branch',i)
 if phase==1 and q[0]=='SIR' and int(q[1])<9740 and int(q[2])==v.O('RET'):indices.setdefault('public-instruction',i)
mutants={}
def edit(name,key,col,value):
 x=lines[:];q=x[indices[key]].split();q[col]=str(value);x[indices[key]]=' '.join(q);mutants[name]='\n'.join(x)+'\n'
edit('wrong-private-length','job',3,168);edit('wrong-context-source','job',2,1);edit('private-export-leak','export',3,1);edit('wrong-private-type','type',3,1);edit('wrong-private-call','call',3,1);edit('label-not-remapped','label',3,1);edit('branch-not-remapped','branch',4,1);edit('changed-public-return','public-instruction',3,99)
x=lines[:];q=x[safe[0]].split();q[1]='3';x[safe[0]]=' '.join(q);mutants['public-unproved-access-flag']='\n'.join(x)+'\n'
x=lines[:];del x[safe[0]];mutants['missing-required-guard-flag']='\n'.join(x)+'\n';x=lines[:];del x[indices['fact']];mutants['missing-proof-fact']='\n'.join(x)+'\n'
rows=[];d=W/'audit-controls';d.mkdir(exist_ok=True)
for name,text in mutants.items():
 p=d/(name+'.log');p.write_text(text)
 try:v.audit(p);detected=False
 except (AssertionError,KeyError,ValueError):detected=True
 assert detected,name;rows.append({'name':name,'result':'REFUSED'})
(W/'audit-controls.json').write_text(json.dumps({'status':'PASS11 changed proof packets refused','correctOriginalPacketAccepted':True,'mutations':rows,'actualNativeEmitterMutationTests':False,'performanceClaim':False},indent=2)+'\n');print('PASS11 changed source/context/guard/metadata packets refused')
