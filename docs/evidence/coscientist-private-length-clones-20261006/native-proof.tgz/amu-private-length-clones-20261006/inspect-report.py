from pathlib import Path
import subprocess,os,re,json
W=Path(__file__).resolve().parent
for label in ['adoption-permanent-test','adoption-permanent-real']:
 if not (W/(label+'.bin')).exists():continue
 off=re.search(r':offset (\d+)',(W/(label+'-extract.log')).read_text())[1]
 env=dict(os.environ,KEXE_COMMAND='1',KEXE_STRUCTURED_REPORT='1',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
 q=subprocess.run([str(W/'kexe-loader'),str(W/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(W/(label+'-failed.stdout')).write_text(q.stdout);(W/(label+'-failed.stderr')).write_text(q.stderr);print(label,q.returncode,q.stdout[-1800:],q.stderr[-1500:],flush=True)
