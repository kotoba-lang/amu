from pathlib import Path
import json,hashlib,subprocess,os,re,shutil
W=Path(__file__).resolve().parent;B=Path('/private/tmp/amu-static-vector-chain-20261006');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();runner='/private/tmp/amu-embench-compare-20261004/runner';base=json.loads((B/'ports-correctness.json').read_text());rows=[]
for e in json.loads((W/'ports-build.json').read_text())['entries']:
 old=next(x for x in base['entries'] if x['workload']==e['workload']);runs=[]
 for x in old['runs']:
  q=subprocess.run([runner,'raw',str(W/'ports'/e['workload']/'native.bin'),str(e['offset']),'aarch64',str(x['n']),'1','0','16777216'],capture_output=True,text=True);assert q.returncode==0,(e['workload'],q.stderr);v=json.loads(q.stdout);assert v['result']==x['result'] and v['contextFuelConsumed']==x['fuelConsumed'],(e['workload'],x,v);runs.append({'n':x['n'],'result':v['result'],'fuelConsumed':v['contextFuelConsumed']})
 q=subprocess.run([runner,'raw',str(W/'ports'/e['workload']/'native.bin'),str(e['offset']),'aarch64','1','1','0','1'],capture_output=True,text=True);assert q.returncode==old['fuelTrapReturncode']
 rows.append({**e,'runs':runs,'fuelTrapReturncode':q.returncode});print('PASS actual original result/fuel',e['workload'],flush=True)
(W/'ports-semantic.json').write_text(json.dumps({'status':'PASS original19 results/fuel plus fuel1 traps','entries':rows,'performanceClaim':False},indent=2)+'\n')
shutil.copy2('/private/tmp/amu-closed-chain-fuel-20261006/full-state-loader',W/'full-state-loader');states=[]
for e in rows:
 old=next(x for x in base['entries'] if x['workload']==e['workload']);cases=[(x['n'],16777216) for x in e['runs'] if x['n'] in (0,1,2)]+[(1,f) for f in [1,2,3,4,31,32,33,257]]
 for n,fuel in cases:
  obs={}
  for label,p,offset in [('product',B/'ports-2'/e['workload']/'native.bin',old['offset']),('candidate',W/'ports'/e['workload']/'native.bin',e['offset'])]:
   env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');env.pop('KEXE_COMMAND',None);q=subprocess.run([str(W/'full-state-loader'),str(p),str(offset),'1','aarch64','-',str(n)],env=env,capture_output=True,text=True);assert ':fuel ' in q.stdout
   obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
  assert obs['product']==obs['candidate'],(e['workload'],n,fuel,obs);states.append({'workload':e['workload'],'n':n,'fuel':fuel,**obs})
 print('PASS actual original full supervisor state',e['workload'],flush=True)
(W/'ports-state.json').write_text(json.dumps({'status':'PASS original19 full-state and partial-fuel','groups':len(states),'rows':states},indent=2)+'\n')
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');gens=[]
for g in [2,3,4]:
 previous=W/f'seed-{g-1}.bin';off=(W/f'seed-{g-1}.offset').read_text().strip()
 for label,args in [('compile',['compile',str(W/'unity.kotoba'),'--target','aarch64-macos','--output',str(W/f'seed-{g}.kseed')]),('extract',['extract-native',str(W/f'seed-{g}.kseed'),'--symbol','main','--output',str(W/f'seed-{g}.bin')])]:
  q=subprocess.run([str(W/'kexe-loader'),str(previous),off,'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(W/f'seed-{g}-{label}.log').write_text(q.stdout+q.stderr);assert q.returncode==0,(g,label,q.stdout[-1500:],q.stderr[-1500:])
  if label=='extract':(W/f'seed-{g}.offset').write_text(re.search(r':offset (\d+)',q.stdout).group(1)+'\n')
 gens.append({'generation':g,'sha256':sha(W/f'seed-{g}.bin'),'bytes':(W/f'seed-{g}.bin').stat().st_size});print('PASS actual native generation',g,gens[-1],flush=True)
assert len({x['sha256'] for x in gens})==1,gens
(W/'fixed-point.json').write_text(json.dumps({'status':'PASS actual native generations2/3/4 byte-identical','generations':gens,'performanceClaim':False},indent=2)+'\n')
