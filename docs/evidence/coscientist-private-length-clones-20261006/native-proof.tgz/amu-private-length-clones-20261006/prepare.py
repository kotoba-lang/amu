from pathlib import Path
import json,shutil
W=Path(__file__).resolve().parent;B=Path('/private/tmp/amu-length-context-20261006');R=Path('/Users/junkawasaki/github/wt/amu-seed17')
h=json.loads((R/'docs/evidence/coscientist-length-context-20261006/next-hypothesis.json').read_text());h.update(status='registered-before-native-candidate-build',sourceCommit='fcece8f3679b62f52ca5ac40d6a016b044f24b48',scope='Unity only (no replaceable imports): deterministic private clones, exact nonnegative literal bounds elision; generic context access checks retained.',authoringException='New excluded native optimizer algorithm, not a mechanical product refactor.');(W/'hypothesis.json').write_text(json.dumps(h,indent=2)+'\n')
s=(B/'length-native.kotoba').read_text();s=s[:s.index('(defn- lc-report [')]
s=s.replace('(* 2 j)','(* 4 j)').replace('(* 2 n)','(* 4 n)')
# Carry sparse final facts D; J entries fn,length,status,clone-id.
s=s.replace('Q :vector-i64 J :vector-i64 f :i64','Q :vector-i64 J :vector-i64 D :vector-i64 f :i64')
s=s.replace('Q :vector-i64 L :vector-i64 J :vector-i64 f :i64','Q :vector-i64 L :vector-i64 J :vector-i64 D :vector-i64 f :i64')
s=s.replace('Q :vector-i64 L :vector-i64 J :vector-i64 j :i64','Q :vector-i64 L :vector-i64 J :vector-i64 D :vector-i64 j :i64')
s=s.replace('(lc-facts M F V H Q j0 f len (inc i) end)','(lc-facts M F V H Q j0 D f len (inc i) end)')
s=s.replace('(lc-facts M F V H q3 J f len (inc p) end)','(lc-facts M F V H q3 J D f len (inc p) end)')
s=s.replace('(lc-function M F V H Q L J f len)','(lc-function M F V H Q L (mem-set J 1 j) D f len)')
s=s.replace('(lc-jobs M F V H Q L j0 (inc j))','(lc-jobs M F V H Q L j0 D (inc j))')
s=s.replace('j0 (if (and callee (>= actual 0) (<= actual 4096)) (lc-add J a actual) J)]','j0 (if (and callee (>= actual 0) (<= actual 4096)) (lc-add J a actual) J)\n        d0 (if (and access (>= len 0) (>= idx 0) (< idx alen)) (pc-fact D (vector-at J 1) i 2 alen idx) D)\n        d1 (if (and callee (>= actual 0) (<= actual 4096)) (pc-fact d0 (vector-at J 1) i 1 (lc-find j0 a actual 1) 0) d0)]')
s=s.replace('(let [printed (lc-out "LENGTH-SKIP" f len p ns dp)] J)','(let [printed (lc-out "LENGTH-SKIP" f len p ns dp)] (mem-set J (+ 18 (* 4 (vector-at J 1))) 2))')
s=s.replace('(if good (lc-facts M F V H q3 J D f len (inc p) end) J)','(if good (lc-facts M F V H q3 (mem-set J (+ 18 (* 4 (vector-at J 1))) 1) D f len (inc p) end) (mem-set J (+ 18 (* 4 (vector-at J 1))) 2))')
(W/'length-collect.kotoba').write_text(s);(W/'shape-native.kotoba').write_bytes((B/'shape-native.kotoba').read_bytes())
for p in ['baseline-41-a64gen.kotoba','42-layout.kotoba','ports-correctness.json']:shutil.copy2(B/p,W/p)
for p,dst in [('observer/seed-0.bin','seed-0.bin'),('observer/seed-0.offset','seed-0.offset'),('observer/kexe-loader','kexe-loader')]:shutil.copy2(B/p,W/dst)
