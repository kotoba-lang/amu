from pathlib import Path
import subprocess,os,re,json,hashlib
W=Path(__file__).resolve().parent.parent;T=W/'team-machine';R=Path('/Users/junkawasaki/github/wt/amu-seed17')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [W/'41-a64gen-prototype.kotoba',W/'42-layout-prototype.kotoba',W/'seed-4.bin']}
(T/'input-pins.json').write_text(json.dumps(pins,indent=2))
g=(W/'observer/41.kotoba').read_text()
def out(prefix,fields):
 s='"\\n"'
 for x in reversed(fields):s=f'(string-concat (string-from-i64 {x}) (string-concat " " {s}))'
 return f'(io-out (string-concat "{prefix} " {s}))'
helper='''
(defn- mc-fns [M :vector-i64 f :i64] :i64 (if (>= f (vector-at M MM-FN-N)) 0 (let [a '''+out('MCFN',['f','(gn-fnf M f FF-CODE)'])+'''] (mc-fns M (inc f)))))
(defn- mc-fixes [M :vector-i64 i :i64] :i64 (if (>= i (vector-at M MM-FIX-N)) 0 (let [b (+ MM-FIX-BASE (* i MM-FIX-W)) a '''+out('MCFIX',['i',*[f'(vector-at M (+ b {j}))' for j in range(4)]])+'''] (mc-fixes M (inc i)))))
(defn- mc-report [M :vector-i64] :i64 (let [a '''+out('MCCODE',['(vector-at M MM-CODE-N)'])+''' b (mc-fns M 1) c (mc-fixes M 1)] 0))
'''
g=g.replace('(defn- gn-run-open [',helper+'\n(defn- gn-run-open [')
g=g.replace('(let [M1 (gn-ins (gn-gs M (+ gn-g-open-n 1) (vector-at Safe i)) i (gn-op M i))', '(let [start (vector-at M MM-CODE-N) M1 (gn-ins (gn-gs M (+ gn-g-open-n 1) (vector-at Safe i)) i (gn-op M i))')
g=g.replace('k (gn-g M1 gn-f-skip)]', 'k (gn-g M1 gn-f-skip) event '+out('MCINS',['i','start','(vector-at M1 MM-CODE-N)','(vector-at Safe i)','(gn-g M1 gn-f-vmode)','k'])+']');assert g.count('event (io-out')==1

g=g.replace('n (vector-at M3 MM-CODE-N)]','n (vector-at M3 MM-CODE-N) audit_machine (mc-report M3)]');assert g.count('audit_machine')==1
parts=[p.strip() for p in (R/'seed/MANIFEST').read_text().splitlines() if p.strip() and not p.lstrip().startswith('#')]
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
base=json.loads((W/'ports-build.json').read_text())['entries']
for mode in ['control','optimized']:
 o=T/mode;o.mkdir(exist_ok=True);gs=g
 if mode=='control':
  needle='(defn- pc-safe [M :vector-i64] :bool (= (gn-g M (+ gn-g-open-n 1)) 1))';assert gs.count(needle)==1;gs=gs.replace(needle,'(defn- pc-safe [M :vector-i64] :bool false)')
 (o/'41.kotoba').write_text(gs);(o/'unity.kotoba').write_text('\n'.join(gs if p=='seed/41-a64gen.kotoba' else (R/p).read_text() for p in parts))
 for label,args in [('compile',['compile',str(o/'unity.kotoba'),'--target','aarch64-macos','--output',str(o/'image.kseed')]),('extract',['extract-native',str(o/'image.kseed'),'--symbol','main','--output',str(o/'seed.bin')])]:
  q=subprocess.run([str(W/'kexe-loader'),str(W/'seed-0.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(o/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(mode,label,q.stdout[-1000:],q.stderr)
  if label=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 rows=[]
 for e in json.loads((R/'bench/embench/comparison-matrix.json').read_text())['entries']:
  d=o/'ports'/e['workload'];d.mkdir(parents=True,exist_ok=True)
  for label,args in [('compile',['compile',str(R/e['source']),'--target','aarch64-macos','--output',str(d/'image.kseed')]),('extract',['extract-native',str(d/'image.kseed'),'--symbol',e['symbol'],'--output',str(d/'native.bin')])]:
   q=subprocess.run([str(W/'kexe-loader'),str(o/'seed.bin'),off,'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(mode,e['workload'],label,q.stdout[-1000:],q.stderr)
   if label=='extract':offset=int(re.search(r':offset (\d+)',q.stdout).group(1))
  if mode=='optimized':
   old=next(x for x in base if x['workload']==e['workload']);assert sha(d/'native.bin')==old['nativeSha256'] and offset==old['offset']
  rows.append({'workload':e['workload'],'nativeSha256':sha(d/'native.bin'),'offset':offset,'sourceSha256':sha(R/e['source'])});print('PASS native',mode,e['workload'],flush=True)
 (o/'parity.json').write_text(json.dumps(rows,indent=2))
for p,h in pins.items():assert sha(Path(p))==h
