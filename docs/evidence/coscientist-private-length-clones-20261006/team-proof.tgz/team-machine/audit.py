from pathlib import Path
import re,struct,json,collections,hashlib,copy
T=Path(__file__).resolve().parent;W=T.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def parse(p):
 lines=(p/'compile.log').read_text().splitlines();phase=None;records=[];post=[];fns={};fix=[];n=None;events=[]
 for l in lines:
  v=l.split()
  if not v:continue
  if v[0]=='PCPHASE':phase=int(v[1]);records.append(tuple(map(int,v[1:])))
  if v[0] in ('SIR','META','PCFF','PCJOB','PCFACT','PCSAFE'):post.append((phase,v[0],*map(int,v[1:])))
  if v[0]=='MCINS':events.append(tuple(map(int,v[1:])))
  if v[0]=='MCFN':fns[int(v[1])]=int(v[2])
  if v[0]=='MCFIX':fix.append(tuple(map(int,v[1:])))
  if v[0]=='MCCODE':assert n is None;n=int(v[1])
 assert n and fns and records
 b=(p/'native.bin').read_bytes();words=[v[0] for v in struct.iter_unpack('<I',b[:4*(n-1)])]
 assert len(words)==n-1
 return dict(records=records,post=post,fns=fns,fix=fix,n=n,words=words,raw=b,events=events)
def signed(n,b):return n-(1<<b) if n&(1<<(b-1)) else n
def branch(z):
 if z&0x7c000000==0x14000000:return z&0xfc000000,signed(z&0x3ffffff,26)
 if z&0xff000010==0x54000000:return z&0xff00001f,signed((z>>5)&0x7ffff,19)
 if z&0x7e000000==0x34000000:return z&0xff00001f,signed((z>>5)&0x7ffff,19)
 if z&0x7e000000==0x36000000:return z&0xfff8001f,signed((z>>5)&0x3fff,14)
 if z&0x9f000000==0x10000000:return z&0x9f00001f,signed(((z>>5)&0x7ffff)*4+((z>>29)&3),21)/4
 return None
def triple(w,i):
 if i+2>=len(w):return False
 z=w[i];return z&0xffe0fc1f==0xeb00001f and ((z>>16)&31) in (3,16) and ((z>>5)&31)!=17 and w[i+1]==0x54000043 and w[i+2]==0

def audit(a,b):
 assert a['records']==b['records'];assert a['post']==b['post'];assert a['fns'].keys()==b['fns'].keys()
 assert len(a['fix'])==len(b['fix']);lit={};fixpairs=[]
 for x,y in zip(a['fix'],b['fix']):
  ix,at,k,t,u=x;iy,bt,l,s,v=y;assert (ix,k,t,u)==(iy,l,s,v);fixpairs.append((x,y))
  if k==5:
   for j in [0,1]:lit[(at+j,bt+j)]=j
 aw,bw=a['words'],b['words'];mapping={};pairs=[];deleted=[];total=collections.Counter()
 ids=list(a['fns']);assert ids==sorted(ids)
 for f in ids:
  start=a['fns'][f];bs=b['fns'][f]
  if start==0:assert bs==0;continue
  end=next((a['fns'][g] for g in ids if g>f and a['fns'][g]>0),a['n']);be=next((b['fns'][g] for g in ids if g>f and b['fns'][g]>0),b['n']);i=start;j=bs
  # zero-code records may share start; only positive spans are scanned.
  while i<end:
   assert j<=be,(f,i,j,be)
   z=aw[i-1];v=bw[j-1] if j<be else None;q=branch(z);r=branch(v) if v is not None else None
   equal=z==v or (q is not None and r is not None and q[0]==r[0]) or ((i,j) in lit and z&~0x1fffe0==v&~0x1fffe0)
   if equal:
    mapping[i]=j;pairs.append((i,j));i+=1;j+=1
   else:
    assert triple(aw,i-1),(f,i,j,hex(z),None if v is None else hex(v))
    assert i+3<=end;deleted.append((f,i,(z>>5)&31,(z>>16)&31))
    for k in range(3):mapping[i+k]=j
    i+=3
  assert j==be,(f,'end',i,j,be)
 mapping[a['n']]=b['n'];assert len(mapping)==a['n']
 for f in ids:
  if a['fns'][f]>0:assert mapping[a['fns'][f]]==b['fns'][f],('fn',f)
  else:assert b['fns'][f]==0
 assert len(a['events'])==len(b['events'])
 event_ranges={}
 for x,y in zip(a['events'],b['events']):
  si,st,en,safe,mode,skip=x;sj,bt,be,bsafe,bmode,bskip=y
  assert (si,safe,mode,skip)==(sj,bsafe,bmode,bskip)
  assert mapping[st]==bt and mapping[en]==be,('sir range',x,y)
  for at in range(st,en):event_ranges[at]=x
 sir={x[2]:x[3:] for x in a['post'] if x[:2]==(1,'SIR')}
 for f,at,ri,rm in deleted:
  si,st,en,safe,mode,skip=event_ranges[at]
  assert safe==1 and at+3<=en
  op,slot,temp,n=sir[si]
  if op==13:
   fields={(x[2],x[3]):x[4] for x in a['post'] if x[:2]==(1,'PCFF')};p=fields[slot,12]
   assert sir[p][:3]==(1,slot,n);p+=1
   if sir[p][0]==18:p+=1
   while sir[p][0]==9:p+=1
   for k in range(n):assert sir[p+k][:3]==(4,k,k+1)
   p+=n;op,slot,base,arity=sir[p];assert base==0 and arity==n
   assert sir[p+1][:2]==(19,0) and sir[p+2][0]==2
  assert op==14 and (slot,n) in ((176,2),(208,3)),(f,at,event_ranges[at],sir[si])
  assert rm==(3 if mode==2 else 16) and (slot==208 or mode!=1)
  assert f>=a['records'][0][1],('public deletion',f,a['records'][0])
  total['provedSirDeletedBounds']+=1
 total['emittedSirEvents']=len(a['events'])
 for i,j in pairs:
  z=aw[i-1];v=bw[j-1];q=branch(z);r=branch(v)
  if q is not None:
   assert r is not None and q[0]==r[0];target=i+q[1];bt=j+r[1]
   assert target in mapping and mapping[target]==bt,('branch',i,j,target,bt,mapping.get(target));total['branches']+=1
  elif (i,j) in lit:
   kind=lit[i,j];mask=0xffe00000
   assert z&mask==(0xd2800000 if kind==0 else 0xf2a00000)
   assert z&~0x1fffe0==v&~0x1fffe0;total['literalWords']+=1
  else:assert z==v;total['exactWords']+=1
 for x,y in fixpairs:
  ix,at,k,t,u=x;iy,bt,l,s,v=y;assert mapping[at]==bt
  if k==5:
   assert mapping[at+1]==bt+1
   old=((aw[at-1]>>5)&65535)|(((aw[at]>>5)&65535)<<16);new=((bw[bt-1]>>5)&65535)|(((bw[bt]>>5)&65535)<<16)
   oldpool=((a['n']-1)*4+7)//8*8;newpool=((b['n']-1)*4+7)//8*8
   assert old-oldpool==new-newpool,('literal pool pointer',at,old,new,oldpool,newpool)
  elif k==4:
   assert u in (0,1);q=branch(aw[at-1]);r=branch(bw[bt-1]);assert q and r
   assert at+q[1]==a['fns'][t]+u and bt+r[1]==b['fns'][t]+u
   if u==1:
    assert aw[a['fns'][t]-1]==bw[b['fns'][t]-1]==0xd2800005;total['privateEntries']+=1
 oldpool=((a['n']-1)*4+7)//8*8;newpool=((b['n']-1)*4+7)//8*8
 # layout permits zero alignment padding only; literal payload must be byte-exact.
 assert set(a['raw'][4*(a['n']-1):oldpool])<= {0};assert set(b['raw'][4*(b['n']-1):newpool])<= {0}
 assert a['raw'][oldpool:]==b['raw'][newpool:]
 total['deletedBounds']=len(deleted);total['deletedWords']=len(deleted)*3;total['functions']=len(ids)
 assert a['n']-b['n']==total['deletedWords']
 return dict(counts=dict(total),deleted=deleted,mapping=mapping,pairs=pairs)
rows=[];tot=collections.Counter();details={}
for p in sorted((T/'control/ports').iterdir()):
 a=parse(p);b=parse(T/'optimized/ports'/p.name);out=audit(a,b);tot.update(out['counts']);details[p.name]=out
 rows.append(dict(workload=p.name,controlSha256=sha(p/'native.bin'),optimizedSha256=sha(T/'optimized/ports'/p.name/'native.bin'),controlWords=a['n']-1,optimizedWords=b['n']-1,**out['counts']));print('PASS',p.name,out['counts'])
(T/'mapping.json').write_text(json.dumps(details,separators=(',',':'))+'\n')
controls=[];a=parse(T/'control/ports/statemate');b=parse(T/'optimized/ports/statemate');out=details['statemate']
# Deliberately mutate one remaining ordinary word, one branch target, one retained handle bound, one literal immediate (if present), and metadata aux.
def refused(name,c,d):
 try:audit(c,d)
 except (AssertionError,KeyError,TypeError,IndexError) as e:controls.append({'name':name,'status':'REFUSED','diagnostic':str(e)[:300]});return
 raise AssertionError('mutant accepted '+name)
for kind in ['ordinary','branch','handle']:
 d=copy.deepcopy(b)
 for i,j in out['pairs']:
  z=b['words'][j-1]
  if kind=='ordinary' and branch(z) is None and z!=0 and not triple(b['words'],j-1):d['words'][j-1]^=1;break
  if kind=='branch' and branch(z) is not None:d['words'][j-1]^=(1 if z&0x7c000000==0x14000000 else 32);break
  if kind=='handle' and z&0xffe0fc1f==0xeb00001f and (z>>5)&31==17 and (z>>16)&31==16:d['words'][j-1]^=32;break
 else:raise AssertionError('missing calibration '+kind)
 refused(kind+' opcode/target corrupt',a,d)
d=copy.deepcopy(b)
for idx,x in enumerate(d['fix']):
 if x[4]==1:d['fix'][idx]=(*x[:4],0);break
else:raise AssertionError('missing private calibration')
refused('private aux corruption',a,d)
# Extra permissible-looking removal must fail projected target/code/function accounting.
c=copy.deepcopy(a)
f,i,ri,rm=out['deleted'][0];c['words'][i-1]=(c['words'][i-1]&~0x3e0)|(17<<5)
refused('allow handle check deletion',c,b)
c=parse(T/'control/ports/crc32');d=parse(T/'optimized/ports/crc32');lf=next(x for x in d['fix'] if x[2]==5);d['words'][lf[1]-1]^=32
refused('declared literal immediate corruption',c,d)
d=copy.deepcopy(b);d['fns'][next(f for f in d['fns'] if d['fns'][f]>1)]+=1
refused('function entry corruption',a,d)
c=copy.deepcopy(a);si=next(x[0] for x in c['events'] if x[3]==1 and x[1]<=out['deleted'][0][1]<x[2]);c['events']=[(x[0],x[1],x[2],0,x[4],x[5]) if x[0]==si else x for x in c['events']]
refused('safe evidence corruption',c,b)
(T/'audit.json').write_text(json.dumps({'status':'PASS independent all19 actual machine translation audit','totals':dict(tot),'rows':rows,'controls':controls,'limits':'Typed admitted SIR and supervisor metadata assumed. Only CMP-register/B.LO+2/UDF0 bounds triples with index register other than x17 and length register x3 or x16 may be deleted. Every retained opcode, function entry, branch projected target, fixup kind/target/aux and declared literal pointer/payload checked. All deleted triples tied to Safe=1 private-clone emitted SIR RT or independently reconstructed exact runtime wrapper; mode1 reads excluded. Every emitted SIR range is projected. Native observer optimized bytes/offsets exact immutable candidate. Not general proof or timing.'},indent=2)+'\n');print('PASS totals',dict(tot),'controls',len(controls))
