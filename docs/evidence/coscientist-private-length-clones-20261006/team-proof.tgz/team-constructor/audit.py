from pathlib import Path
import subprocess,os,re,json,hashlib
W=Path('/private/tmp/amu-private-length-clones-20261006');D=W/'team-constructor';D.mkdir(exist_ok=True)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
def compile(src,compiler,out,symbol='run'):
 out.parent.mkdir(exist_ok=True,parents=True)
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(out.with_suffix('.kseed'))]),('extract',['extract-native',str(out.with_suffix('.kseed')),'--symbol',symbol,'--output',str(out)])]:
  q=subprocess.run([str(W/'kexe-loader'),str(compiler),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(out.parent/(out.stem+'-'+stage+'.log')).write_text(q.stdout+q.stderr)
  assert q.returncode==0,(src,stage,q.stdout[-1000:],q.stderr[-1000:])
  if stage=='extract': off=int(re.search(r':offset (\d+)',q.stdout)[1])
 return off
cases={
 'empty-read':('(defn- read0 [v :vector-i64] :i64 (vector-at v 0))','(let [v (vector-alloc 0)] (read0 v))'),
 'len3-read2':('(defn- read2 [v :vector-i64] :i64 (vector-at v 2))','(let [v (vector-assoc! (vector-alloc 3) 2 n)] (read2 v))'),
 'len3-oob3':('(defn- read3 [v :vector-i64] :i64 (vector-at v 3))','(let [v (vector-alloc 3)] (read3 v))'),
 'distinct3-5':('(defn- read3 [v :vector-i64] :i64 (vector-at v 3))','(if (= n 0) (read3 (vector-alloc 3)) (read3 (vector-assoc! (vector-alloc 5) 3 77)))'),
 'equal-join':('(defn- read2 [v :vector-i64] :i64 (vector-at v 2))','(let [v (if (= n 0) (vector-assoc! (vector-alloc 3) 2 44) (vector-assoc! (vector-alloc 3) 2 55))] (read2 v))'),
 'unequal-join':('(defn- read3 [v :vector-i64] :i64 (vector-at v 3))','(let [v (if (= n 0) (vector-alloc 3) (vector-assoc! (vector-alloc 5) 3 66))] (read3 v))'),
 'identity-inplace':('(defn- ident [v :vector-i64] :vector-i64 (vector-assoc! v 2 91))\n(defn- read2 [v :vector-i64] :i64 (vector-at v 2))','(let [v (vector-alloc 3)] (read2 (ident v)))'),
 'loop-read':('(defn- walk [v :vector-i64 n :i64] :i64 (loop [i 0 s 0] (if (= i n) s (recur (+ i 1) (+ s (vector-at v 2))))))','(walk (vector-assoc! (vector-alloc 3) 2 7) n)'),
 'unknown-allocation':('(defn- alloc-other [v :vector-i64 n :i64] :vector-i64 (vector-alloc n))\n(defn- read3 [v :vector-i64] :i64 (vector-at v 3))','(let [v (alloc-other (vector-alloc 5) n)] (read3 v))'),
 'public-entry':('(defn read3 [v :vector-i64] :i64 (vector-at v 3))','(read3 (vector-assoc! (vector-alloc 5) 3 88))'),
}
rows=[]
for name,(defs,body) in cases.items():
 src=D/(name+'.kotoba');src.write_text('(ns constructor.'+name+' (:export [run'+(' read3' if name=='public-entry' else '')+']))\n'+defs+'\n(defn run [n :i64] :i64 '+body+')\n')
 offsets={label:compile(src,c,D/name/(label+'.bin')) for label,c in [('baseline',W/'seed-0.bin'),('candidate',W/'seed-4.bin'),('observer',W/'observer/seed.bin')]}
 assert (D/name/'candidate.bin').read_bytes()==(D/name/'observer.bin').read_bytes()
 log=(D/name/'observer-compile.log').read_text();flags=len(re.findall(r'^PCSAFE ',log,re.M));jobs=[list(map(int,l.split()[1:])) for l in log.splitlines() if l.startswith('PCJOB ')]
 for n in [0,1,2,3,5]:
  for fuel in [1,2,7,31,1048576]:
   obs={}
   for label in ['baseline','candidate']:
    e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
    q=subprocess.run([str(W/'full-state-loader'),str(D/name/(label+'.bin')),str(offsets[label]),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True)
    obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
   assert obs['baseline']==obs['candidate'],(name,n,fuel,obs)
   rows.append({'case':name,'n':n,'fuel':fuel,'safeFlags':flags,'jobs':jobs,**obs})
 print('PASS',name,'flags',flags,flush=True)
(D/'semantic.json').write_text(json.dumps({'status':'PASS','rows':rows},indent=2)+'\n')
