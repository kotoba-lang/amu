exec((__import__('pathlib').Path('/private/tmp/amu-private-length-clones-20261006/team-constructor/audit.py')).read_text().split('rows=[]')[0])
needle='(= (vector-at J (+ 17 (* 4 j))) len)';replacement='(or (= (vector-at J (+ 17 (* 4 j))) len) (and (>= (vector-at J (+ 17 (* 4 j))) 0) (>= len 0)))'
base=(W/'unity.kotoba').read_text();assert base.count(needle)==1
src=D/'merge-length-compiler.kotoba';src.write_text(base.replace(needle,replacement,1));compiler=D/'merge-length-compiler.bin';assert compile(src,W/'seed-0.bin',compiler,'main')==0
case='distinct5-3';target=D/case/'merged.bin';off=compile(D/(case+'.kotoba'),compiler,target);obs={}
for label,p,o in [('baseline',D/case/'baseline.bin',int(re.search(r':offset (\d+)',(D/case/'baseline-extract.log').read_text())[1])),('mutant',target,off)]:
 e=dict(os.environ,KEXE_FUEL='1048576',KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
 q=subprocess.run([str(W/'full-state-loader'),str(p),str(o),'1','aarch64','-','1'],env=e,capture_output=True,text=True)
 obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
assert obs['baseline']!=obs['mutant'],obs
(D/'merge-mutant.json').write_text(json.dumps({'status':'PASS','detected':True,'sourceMutation':'collapse distinct nonnegative exact length contexts',**obs},indent=2)+'\n');print('PASS actual wrong-context merging mutant detected',flush=True)
