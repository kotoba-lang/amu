exec((__import__('pathlib').Path('/private/tmp/amu-private-length-clones-20261006/team-constructor/audit.py')).read_text().split('rows=[]')[0])
extra={
 'distinct5-3':('(defn- read3 [v :vector-i64] :i64 (vector-at v 3))','(if (= n 0) (read3 (vector-assoc! (vector-alloc 5) 3 77)) (read3 (vector-alloc 3)))'),
 'indirect-invalidate':('(defn- select [v :vector-i64] :vector-i64 (vector-alloc 3))\n(defn- invoke [f [:fn [[:vector-i64] :vector-i64]] v :vector-i64] :vector-i64 (f v))\n(defn- read3 [v :vector-i64] :i64 (vector-at v 3))','(read3 (invoke (fn [v] (vector-alloc 3)) (vector-alloc 5)))'),
}
rows=[]
for name,(defs,body) in extra.items():
 src=D/(name+'.kotoba');src.write_text('(ns constructor.'+name+' (:export [run]))\n'+defs+'\n(defn run [n :i64] :i64 '+body+')\n')
 offsets={label:compile(src,c,D/name/(label+'.bin')) for label,c in [('baseline',W/'seed-0.bin'),('candidate',W/'seed-4.bin'),('observer',W/'observer/seed.bin')]}
 assert (D/name/'candidate.bin').read_bytes()==(D/name/'observer.bin').read_bytes()
 flags=len(re.findall(r'^PCSAFE ',(D/name/'observer-compile.log').read_text(),re.M))
 for n in [0,1,2,3,5]:
  for fuel in [1,2,7,31,1048576]:
   obs={}
   for label in ['baseline','candidate']:
    e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
    q=subprocess.run([str(W/'full-state-loader'),str(D/name/(label+'.bin')),str(offsets[label]),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True)
    obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
   assert obs['baseline']==obs['candidate'],(name,n,fuel,obs)
   rows.append({'case':name,'n':n,'fuel':fuel,'safeFlags':flags,**obs})
 print('PASS',name,'flags',flags,flush=True)
(D/'extra-semantic.json').write_text(json.dumps({'status':'PASS','rows':rows},indent=2)+'\n')
