exec((__import__('pathlib').Path('/private/tmp/amu-private-length-clones-20261006/team-constructor/audit.py')).read_text().split('rows=[]')[0])
import hashlib
mutations=[('off-by-one','(< idx alen)','(<= idx alen)','len3-oob3',0),('public-safe','(defn- pc-safe [M :vector-i64] :bool (= (gn-g M (+ gn-g-open-n 1)) 1))','(defn- pc-safe [M :vector-i64] :bool true)','empty-read',0)]
records=[]
for name,needle,replace,case,n in mutations:
 base=(W/'unity.kotoba').read_text();assert base.count(needle)==1
 src=D/(name+'-compiler.kotoba');src.write_text(base.replace(needle,replace,1));compiler=D/(name+'-compiler.bin');coff=compile(src,W/'seed-0.bin',compiler,'main');assert coff==0
 target=D/case/(name+'.bin');off=compile(D/(case+'.kotoba'),compiler,target)
 obs={}
 for label,p,o in [('baseline',D/case/'baseline.bin',int(re.search(r':offset (\d+)',(D/case/'baseline-extract.log').read_text())[1])),('mutant',target,off)]:
  e=dict(os.environ,KEXE_FUEL='1048576',KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
  q=subprocess.run([str(W/'full-state-loader'),str(p),str(o),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True)
  obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
 assert obs['baseline']!=obs['mutant'],(name,obs)
 records.append({'mutant':name,'case':case,'detected':True,'compilerSha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),**obs});print('PASS detected actual source mutant',name,flush=True)
(D/'mutants.json').write_text(json.dumps({'status':'PASS','records':records},indent=2)+'\n')
