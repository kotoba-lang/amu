from pathlib import Path
import shutil
w=Path('/private/tmp/amu-static-arg-20261005');d=w/'initial-evidence';d.mkdir(exist_ok=True)
for n in ['41-a64gen-prototype.kotoba','clone.kotoba','create.py','generations.json','ports-correctness.json','descriptor-admission.json','seed-4.bin','seed-4.offset']:shutil.copyfile(w/n,d/n)
p=w/'clone.kotoba';s=p.read_text();s=''';; 40-a64enc stat word101 is unused; private owner of the extended G block.
;; Never assume a G from another backend owns clone metadata. Disabled state
;; must not read beyond the original G allocation (including heap headroom).
(def gn-sp-owner 101)
(defn- gn-sp-enabled [M :vector-i64] :bool
  (let [p (vector-at M gn-sp-owner)]
    (and (>= p MM-HEAP-BASE) (= p (vector-at M gn-cell))
         (<= (+ p gn-sp-size) (vector-at M MM-HEAP-TOP)) (<= (+ p gn-sp-size) MM-HEAP-END))))
'''+s
s=s.replace('''  (let [k (- f (gn-g M gn-sp-original-fn))]
    (if (and (>= k 0) (< k (gn-g M gn-sp-count))) (gn-g M (+ gn-sp-records (* k 3) 1)) 0)))''','''  (if (gn-sp-enabled M)
    (let [k (- f (gn-g M gn-sp-original-fn))]
      (if (and (>= k 0) (< k (gn-g M gn-sp-count))) (gn-g M (+ gn-sp-records (* k 3) 1)) 0)) 0))''',1)
s+='''
(defn- gn-sp-lget [M :vector-i64 t :i64 s :i64] :vector-i64
  (if (gn-sp-enabled M)
    (let [f (gn-g M gn-sp-current)]
      (if (and (> (gn-sp-slot M f) 0) (= s (gn-sp-slot M f)))
        (gn-def M t gn-k-const (gn-sp-bit M f)) (gn-def M t gn-k-local s)))
    (gn-def M t gn-k-local s)))
;; Regeneration must restore direct references before installing a new import
;; boundary. Existing code/fixups remain for the caller to reset as usual.
(defn- gn-sp-unprepare [M :vector-i64] :vector-i64
  (if (gn-sp-enabled M)
    (let [sir (gn-g M gn-sp-original-sir)]
      (-> M (gn-sp-undo 1 sir) (gn-put MM-SIR-N sir)
          (gn-put MM-FN-N (gn-g M gn-sp-original-fn))
          (gn-put MM-LABEL-N (gn-g M gn-sp-original-label)) (gn-put gn-sp-owner 0))) M))
'''
p.write_text(s)
p=w/'create.py';s=p.read_text();a="g=g.replace('OP-LGET (gn-def M a gn-k-local b)'";start=s.index(a);end=s.index("g=g.replace('(mem-alloc",start)
s=s[:start]+"g=g.replace('OP-LGET (gn-def M a gn-k-local b)','OP-LGET (gn-sp-lget M a b)')\ng=g.replace('OP-FN (gn-op-fn M i a b)','OP-FN (gn-op-fn (if (gn-sp-enabled M) (gn-gs M gn-sp-current a) M) i a b)')\n"+s[end:]
# Replace the complete old generated run-open replacement with a transactional,
# owner-checked variant; original code block matching remains unchanged.
start=s.index("g=g.replace('(mem-alloc");end=s.index("assert g.count(a)==1;g=g.replace(a,b);",start)
s=s[:start]+'''start=g.index('(defn- gn-run-open');end=g.index(';; Unity compilation',start)
b="""(defn- gn-run-open [M :vector-i64 first :i64 count :i64] :vector-i64
  (let [MR (gn-sp-unprepare M) top (vector-at MR MM-HEAP-TOP)
        M0 (if (< top MM-HEAP-BASE) (gn-put MR MM-HEAP-TOP MM-HEAP-BASE) MR)
        room (<= (+ (vector-at M0 MM-HEAP-TOP) gn-sp-size) MM-HEAP-END)
        M1 (mem-alloc M0 (if room gn-sp-size (+ gn-a-lp MM-LABEL-CAP 2)))
        code (vector-at M1 MM-CODE-N) fix (vector-at M1 MM-FIX-N)
        enabled (and room (= (vector-at M1 MM-ERR) 0))
        MB (-> (gn-put M1 gn-cell (vector-at M1 MM-R0))
               (gn-gs gn-g-open first) (gn-gs gn-g-open-n count))
        M2 (if enabled
             (-> MB (gn-put gn-sp-owner (vector-at MB gn-cell))
                    (gn-gs gn-sp-count 0) (gn-gs gn-sp-total 0) (gn-gs gn-sp-current 0)
                    (gn-gs gn-sp-original-fn (vector-at MB MM-FN-N))
                    (gn-gs gn-sp-original-sir (vector-at MB MM-SIR-N))
                    (gn-gs gn-sp-original-label (vector-at MB MM-LABEL-N)))
             (gn-put MB gn-sp-owner 0))
        MP (if enabled (gn-sp-prepare M2 1) M2)
        M3 (if (= (vector-at MP MM-ERR) 0) (gn-loop MP 1) MP)
        overflow (and enabled (> (gn-g M3 gn-sp-count) 0) (or (= (vector-at M3 MM-ERR) E-GEN-FULL) (= (vector-at M3 MM-ERR) E-GEN-FRAME)))
        M4 (if overflow
             (let [sir (gn-g M3 gn-sp-original-sir)
                   MU (-> M3 (gn-sp-undo 1 sir) (gn-put MM-SIR-N sir)
                          (gn-put MM-FN-N (gn-g M3 gn-sp-original-fn))
                          (gn-put MM-LABEL-N (gn-g M3 gn-sp-original-label))
                          (gn-put MM-CODE-N code) (gn-put MM-FIX-N fix)
                          (gn-put MM-ERR 0) (gn-put MM-ERR-POS 0) (gn-put MM-ERR-N 0)
                          (gn-gs gn-sp-count 0) (gn-gs gn-sp-total 0) (gn-gs gn-sp-current 0))]
               (gn-loop MU 1)) M3)
        n (vector-at M4 MM-CODE-N)]
    (gn-put M4 MM-R0 (- n 1))))

"""
g=g[:start]+b+g[end:]
'''+s[end+len('assert g.count(a)==1;g=g.replace(a,b);'):]
p.write_text(s)
print('reentry restoration and no-extra-heap fallback authored; original evidence preserved')
