from pathlib import Path
import shutil,json,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-static-arg-20261005');base=Path('/private/tmp/amu-clamp-call-20261005');g=(r/'seed/41-a64gen.kotoba').read_text();previous=Path('/private/tmp/amu-affine-join-20261005/41-a64gen-prototype.kotoba').read_text();a=previous.index('(defn- gn-const-fn');b=previous.index('(defn- gn-restore-const');proof=previous[a:b];needle=';; every instruction from i';assert g.count(needle)==1;g=g.replace(needle,proof+'\n'+(w/'clone.kotoba').read_text()+'\n'+needle)
g=g.replace('OP-LGET (gn-def M a gn-k-local b)','OP-LGET (if (and (> (gn-sp-slot M (gn-g M gn-sp-current)) 0) (= b (gn-sp-slot M (gn-g M gn-sp-current)))) (gn-def M a gn-k-const (gn-sp-bit M (gn-g M gn-sp-current))) (gn-def M a gn-k-local b))')
g=g.replace('OP-FN (gn-op-fn M i a b)','OP-FN (gn-op-fn (gn-gs M gn-sp-current a) i a b)')
g=g.replace('(mem-alloc M0 (+ gn-a-lp MM-LABEL-CAP 2))','(mem-alloc M0 gn-sp-size)')
a='''        M2 (-> (gn-put M1 gn-cell (vector-at M1 MM-R0))
               (gn-gs gn-g-open first) (gn-gs gn-g-open-n count))
        M3 (if (= (vector-at M2 MM-ERR) 0) (gn-loop M2 1) M2)
        n (vector-at M3 MM-CODE-N)]
    (gn-put M3 MM-R0 (- n 1))))'''
b='''        code (vector-at M1 MM-CODE-N) fix (vector-at M1 MM-FIX-N)
        M2 (-> (gn-put M1 gn-cell (vector-at M1 MM-R0))
               (gn-gs gn-g-open first) (gn-gs gn-g-open-n count)
               (gn-gs gn-sp-count 0) (gn-gs gn-sp-total 0) (gn-gs gn-sp-current 0)
               (gn-gs gn-sp-original-fn (vector-at M1 MM-FN-N))
               (gn-gs gn-sp-original-sir (vector-at M1 MM-SIR-N))
               (gn-gs gn-sp-original-label (vector-at M1 MM-LABEL-N)))
        MP (if (= (vector-at M2 MM-ERR) 0) (gn-sp-prepare M2 1) M2)
        M3 (if (= (vector-at MP MM-ERR) 0) (gn-loop MP 1) MP)
        overflow (and (> (gn-g M3 gn-sp-count) 0) (or (= (vector-at M3 MM-ERR) E-GEN-FULL) (= (vector-at M3 MM-ERR) E-GEN-FRAME)))
        M4 (if overflow
             (let [sir (gn-g M3 gn-sp-original-sir)
                   MU (-> M3 (gn-sp-undo 1 sir) (gn-put MM-SIR-N sir)
                          (gn-put MM-FN-N (gn-g M3 gn-sp-original-fn))
                          (gn-put MM-LABEL-N (gn-g M3 gn-sp-original-label))
                          (gn-put MM-CODE-N code) (gn-put MM-FIX-N fix)
                          (gn-put MM-ERR 0) (gn-put MM-ERR-POS 0) (gn-put MM-ERR-N 0)
                          (gn-gs gn-sp-count 0) (gn-gs gn-sp-total 0) (gn-gs gn-sp-current 0))]
               (gn-loop MU 1)) M3)
        n (vector-at M4 MM-CODE-N)]
    (gn-put M4 MM-R0 (- n 1))))'''
assert g.count(a)==1;g=g.replace(a,b);(w/'41-a64gen-prototype.kotoba').write_text(g);files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
# Native observation logs registrations only. Target instructions are unchanged.
needle='''          (-> M (gn-sp-record-copy f next 0)''';assert g.count(needle)==1;dg=g.replace(needle,'''          (let [observed (io-out (string-concat "STATIC " (string-concat (string-from-i64 f) (string-concat " " (string-concat (string-from-i64 s) (string-concat " " (string-concat (string-from-i64 v) "\\n")))))))]
          (-> M (gn-sp-record-copy f next 0)''');dg=dg.replace('(gn-put MM-R0 next)))))','(gn-put MM-R0 next))))))',1);(w/'observer-backend.kotoba').write_text(dg);(w/'observer-unity.kotoba').write_text(''.join((dg if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
for ext in ['bin','offset']:shutil.copyfile(base/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile(base/'kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
old=Path('/private/tmp/amu-affine-join-20261005')
for name in ['build.py','check-ports.py','bulk-state.py','baseline-a64gen-fixtures.py','baseline-41-a64gen.kotoba']:(w/name).write_text((old/name).read_text().replace('amu-affine-join-20261005','amu-static-arg-20261005'))
(w/'hypothesis.json').write_text(json.dumps({'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'hypothesis':'Closed private internal variants for one actual static bit argument, including exact unchanged loop reassignment proof. Clone source SIR unchanged except identity/label relocation; preserve original prescan/frame inputs and actual arguments/fuel/effects. Emit proven invariant LGET as CONST. Propagate static bits into direct callees via bounded dominance. No function/workload-name selection.','bounds':'16 variants,total4096 copiedSIR,each512instructions,caller-origin256,edges4096,callee slots<=64/temps<=16; exhausted budget keeps original targets. Optional code/frame growth overflow restores original targets/table fills and regenerates natively. Open callee and RET2/RES2 refuse.','proof':'Actual all19 admission and diagnostic/quiet target identity, exact results/fuel/traps/state/partialwrites and low fuel, true/false/changed/reassigned/bypass/backedge controls, import substitution, clone/capacity fallback, native fixedpoint. Fresh30triples everychangedguest same1.05+noise rule then committed-source gates/integrated3gen/corpus before promotion.','exception':'One-off new Kotoba compiler algorithm authoring; isolated, product unchanged'},indent=2)+'\n');print('registered native scalar-argument specialization prototype')
