from pathlib import Path
import importlib.util,subprocess,os,re,json,types,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-static-arg-20261005');spec=importlib.util.spec_from_file_location('base',w/'baseline-a64gen-fixtures.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');
# Stable bit modes and invariant/changed loop assignments; no benchmark names.
m.fx('sa_choose',2,2,[('FUEL',),('LGET',0,2),('BRZ',0,'sa_choose_false'),('LGET',0,1),('CONST',1,1),('BIN','BOP-ADD',0),('BR','sa_choose_done'),('LABEL','sa_choose_false'),('LGET',0,1),('CONST',1,2),('BIN','BOP-ADD',0),('LABEL','sa_choose_done'),('RET',0)])
for bit in [0,1]:
 c=f'sa_call{bit}';m.fx(c,1,1,[('FUEL',),('LGET',0,1),('CONST',1,bit),('CALL','sa_choose',0,2),('RET',0)])
 for x in [m.MIN,-32769,-1,0,1,32768,m.MAX]:m.run(c,[x],m.s64(x+2-bit),fuel=2)
 m.run(c,[0],'trap',fuel=1)
m.fx('sa_dynamic',2,2,[('FUEL',),('LGET',0,1),('LGET',1,2),('CALL','sa_choose',0,2),('RET',0)])
for x in [m.MIN,-1,0,m.MAX]:
 for bit in [0,1,-1,m.MAX]:m.run('sa_dynamic',[x,bit],m.s64(x+(2 if bit==0 else 1)),fuel=2)
for changed in [False,True]:
 f='sa_changed' if changed else 'sa_loop';body=[('FUEL',),('LABEL',f+'_top'),('LGET',0,3),('CONST',1,3),('CMP','CC-GE',0),('BRNZ',0,f+'_end'),('LGET',0,2),('BRZ',0,f+'_false'),('CONST',0,5),('BR',f+'_join'),('LABEL',f+'_false'),('CONST',0,7),('LABEL',f+'_join'),('LGET',0,1),('LGET',1,2),('CALL','sa_choose',0,2),('LSET',1,0)]
 if changed:body += [('CONST',0,1),('LSET',2,0),('LGET',0,3),('CONST',1,1),('BIN','BOP-ADD',0),('LSET',3,0)]
 else:body += [('LGET',0,2),('LGET',1,3),('CONST',2,1),('BIN','BOP-ADD',1),('LSET',2,0),('LSET',3,1)]
 body += [('FUEL',),('BR',f+'_top'),('LABEL',f+'_end'),('LGET',0,1),('RET',0)];m.fx(f,3,3,body)
 for bit in [0,1]:
  c=f'{f}_call{bit}';m.fx(c,2,2,[('FUEL',),('LGET',0,1),('CONST',1,bit),('LGET',2,2),('CALL',f,0,3),('RET',0)])
  for x in [m.MIN,-1,0,m.MAX]:
   for i in [-1,0,1,2,3,4,m.MAX]:
    n=max(0,3-i);delta=(n+(1 if n>0 and bit==0 else 0)) if changed else n*(2-bit);cost=2+2*n;m.run(c,[x,i],m.s64(x+delta),fuel=cost)
    for fuel in range(1,cost):m.run(c,[x,i],'trap',fuel=fuel)
m.fx('sa_bypass',3,3,[('FUEL',),('LGET',0,2),('BRZ',0,'sa_bypass_dummy'),('CONST',0,9),('LABEL','sa_bypass_dummy'),('CONST',0,1),('LGET',1,3),('BRZ',1,'sa_bypass_join'),('LGET',0,2),('LABEL','sa_bypass_join'),('LSET',2,0),('LGET',0,1),('LGET',1,2),('CALL','sa_choose',0,2),('RET',0)])
for bit in [0,1]:
 c=f'sa_bypass_call{bit}';m.fx(c,2,2,[('FUEL',),('LGET',0,1),('CONST',1,bit),('LGET',2,2),('CALL','sa_bypass',0,3),('RET',0)])
 for x in [m.MIN,-1,0,m.MAX]:
  for condition in [0,1]:m.run(c,[x,condition],m.s64(x+(2 if condition!=0 and bit==0 else 1)),fuel=3)
  for fuel in [1,2]:m.run(c,[x,1],'trap',fuel=fuel)
m.fx('sa_replacement',2,2,[('FUEL',),('CONST',0,1),('RT','RT-VECTOR-ALLOC',0,1),('CONST',0,77),('RET',0)])

parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];stdout={}
for label,real in [('expanded-test',False),('expanded-real',True)]:
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real))
 test=src.read_text();dump="""(defn- t-static [M :vector-i64 k :i64] :i64
  (if (>= k (gn-g M gn-sp-count)) 0
    (let [f (+ (gn-g M gn-sp-original-fn) k)
          out (t-out (string-concat "STATICREC " (string-concat (string-from-i64 f)
           (string-concat " " (string-concat (string-from-i64 (gn-sp-original M f))
           (string-concat " " (string-concat (string-from-i64 (gn-sp-slot M f))
           (string-concat " " (string-concat (string-from-i64 (gn-sp-bit M f)) "\\n")))))))))]
      (t-static M (inc k)))))
""";test=test.replace('(defn- seed-main [] :i64',dump+'(defn- seed-main [] :i64',1);test=test.replace('        nw (vector-at M1 MM-R0)','        nw (vector-at M1 MM-R0)\n        static_report (t-static M1 0)',1);src.write_text(test)

 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+mode+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,mode,q.stdout,q.stderr)
  if mode=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'.stdout')).write_text(q.stdout);(w/(label+'.stderr')).write_text(q.stderr);assert q.returncode==0,(label,q.stdout[-400:],q.stderr);stdout[label]=q.stdout
aa=m.blob_from(stdout['expanded-test']);bb=m.blob_from(stdout['expanded-real']);assert aa[1]==bb[1] and aa[0][:len(bb[0])]==bb[0] and not any(aa[0][len(bb[0]):])
assert len(aa[0])-len(bb[0]) in [0,1,2,3,4,5,6,7]
d=w/'expanded-run/unit/41-a64gen';d.mkdir(parents=True,exist_ok=True);(d/'stdout').write_text(stdout['expanded-real']);os.environ['SEED_BUILD']=str(w/'expanded-run');original=m.subprocess.run;m.subprocess.run=lambda args,**kw:types.SimpleNamespace(returncode=0,stdout='compiled and executed natively: real/test identical',stderr='') if args[:2]==['zsh',m.R+'/scripts/seed/unit.sh'] else original(args,**kw)
assert m.runs(False)==0;m.subprocess.run=original
keys={tuple(map(int,x.split()[2:])) for x in stdout['expanded-real'].splitlines() if x.startswith('STATICREC ')}
ids={x[0]:i+1 for i,x in enumerate(m.FIX)}
for bit in [0,1]:assert (ids['sa_choose'],2,bit) in keys and (ids['sa_loop'],2,bit) in keys,keys
assert not any(f in [ids['sa_changed'],ids['sa_bypass']] for f,slot,bit in keys),keys
assert len(keys)<=16
(w/'expanded-variants.json').write_text(json.dumps({'status':'complete-positive-and-refused-static-variant-audit','variants':sorted(keys),'functions':ids},indent=2)+'\n')
(w/'expanded-proof.json').write_text(json.dumps({'status':'complete-native-base-oracles-and-regeneration-open-controls','fixtures':len(m.FIX),'runs':len(m.RUNS),'codeAndLiteralBytesIdentical':True,'testOnlyTrailingZeroPaddingBytes':len(aa[0])-len(bb[0]),'regeneration':'Fixture main runs closed generation, then open regeneration on same M and verifies imported context/clamp guards.','candidateSha256':hashlib.sha256((w/'seed-4.bin').read_bytes()).hexdigest()},indent=2)+'\n');print('PASS base oracles and reentrant open boundary',flush=True)
