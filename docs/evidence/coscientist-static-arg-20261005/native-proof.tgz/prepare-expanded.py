from pathlib import Path
w=Path('/private/tmp/amu-static-arg-20261005');s=(w/'base-proof.py').read_text();needle="parts=['seed/00-ns.kotoba'";pos=s.index(needle)
# Append new hand-derived fixtures before construction/execution of the generator.
insert='''
# Stable bit modes and invariant/changed loop assignments; no benchmark names.
m.fx('sa_choose',2,2,[('FUEL',),('LGET',0,2),('BRZ',0,'sa_choose_false'),('LGET',0,1),('CONST',1,1),('BIN','BOP-ADD',0),('BR','sa_choose_done'),('LABEL','sa_choose_false'),('LGET',0,1),('CONST',1,2),('BIN','BOP-ADD',0),('LABEL','sa_choose_done'),('RET',0)])
for bit in [0,1]:
 c=f'sa_call{bit}';m.fx(c,1,1,[('FUEL',),('LGET',0,1),('CONST',1,bit),('CALL','sa_choose',0,2),('RET',0)])
 for x in [m.MIN,-32769,-1,0,1,32768,m.MAX]:m.run(c,[x],m.s64(x+2-bit),fuel=2)
 m.run(c,[0],'trap',fuel=1)
m.fx('sa_dynamic',2,2,[('FUEL',),('LGET',0,1),('LGET',1,2),('CALL','sa_choose',0,2),('RET',0)])
for x in [m.MIN,-1,0,m.MAX]:
 for bit in [0,1,-1,m.MAX]:m.run('sa_dynamic',[x,bit],m.s64(x+(2 if bit==0 else 1)),fuel=2)
for changed in [False,True]:
 f='sa_changed' if changed else 'sa_loop';body=[('FUEL',),('LABEL',f+'_top'),('LGET',0,3),('CONST',1,3),('CMP','CC-GE',0),('BRNZ',0,f+'_end'),('LGET',0,2),('BRZ',0,f+'_false'),('CONST',0,5),('BR',f+'_join'),('LABEL',f+'_false'),('CONST',0,7),('LABEL',f+'_join'),('LGET',0,1),('LGET',1,2),('CALL','sa_choose',0,2),('LSET',1,0)]
 if changed:body += [('CONST',0,1),('LSET',2,0),('LGET',0,3),('CONST',1,1),('BIN','BOP-ADD',0),('LSET',3,0)]
 else:body += [('LGET',0,2),('LGET',1,3),('CONST',2,1),('BIN','BOP-ADD',1),('LSET',2,0),('LSET',3,1)]
 body += [('FUEL',),('BR',f+'_top'),('LABEL',f+'_end'),('LGET',0,1),('RET',0)];m.fx(f,3,3,body)
 for bit in [0,1]:
  c=f'{f}_call{bit}';m.fx(c,2,2,[('FUEL',),('LGET',0,1),('CONST',1,bit),('LGET',2,2),('CALL',f,0,3),('RET',0)])
  for x in [m.MIN,-1,0,m.MAX]:
   for i in [-1,0,1,2,3,4,m.MAX]:
    n=max(0,3-i);delta=(n+(1 if n>0 and bit==0 else 0)) if changed else n*(2-bit);cost=2+2*n;m.run(c,[x,i],m.s64(x+delta),fuel=cost)
    for fuel in range(1,cost):m.run(c,[x,i],'trap',fuel=fuel)
m.fx('sa_bypass',3,3,[('FUEL',),('LGET',0,2),('BRZ',0,'sa_bypass_dummy'),('CONST',0,9),('LABEL','sa_bypass_dummy'),('CONST',0,1),('LGET',1,3),('BRZ',1,'sa_bypass_join'),('LGET',0,2),('LABEL','sa_bypass_join'),('LSET',2,0),('LGET',0,1),('LGET',1,2),('CALL','sa_choose',0,2),('RET',0)])
for bit in [0,1]:
 c=f'sa_bypass_call{bit}';m.fx(c,2,2,[('FUEL',),('LGET',0,1),('CONST',1,bit),('LGET',2,2),('CALL','sa_bypass',0,3),('RET',0)])
 for x in [m.MIN,-1,0,m.MAX]:
  for condition in [0,1]:m.run(c,[x,condition],m.s64(x+(2 if condition!=0 and bit==0 else 1)),fuel=3)
  for fuel in [1,2]:m.run(c,[x,1],'trap',fuel=fuel)
m.fx('sa_replacement',2,2,[('FUEL',),('CONST',0,1),('RT','RT-VECTOR-ALLOC',0,1),('CONST',0,77),('RET',0)])
'''
s=s[:pos]+insert+'\n'+s[pos:];s=s.replace('base-test','expanded-test').replace('base-real','expanded-real').replace("w/'base-run", "w/'expanded-run").replace("w/'base-proof.json'", "w/'expanded-proof.json'")
# Capture variant identities after generation and before the regeneration inside
# fixture main. This does not alter emitted target bytes.
a='+m.kotoba(real))';assert s.count(a)==1;replacement='''+m.kotoba(real))
 test=src.read_text();dump="""(defn- t-static [M :vector-i64 k :i64] :i64
  (if (>= k (gn-g M gn-sp-count)) 0
    (let [f (+ (gn-g M gn-sp-original-fn) k)
          out (t-out (string-concat "STATICREC " (string-concat (string-from-i64 f)
           (string-concat " " (string-concat (string-from-i64 (gn-sp-original M f))
           (string-concat " " (string-concat (string-from-i64 (gn-sp-slot M f))
           (string-concat " " (string-concat (string-from-i64 (gn-sp-bit M f)) "\\\\n")))))))))]
      (t-static M (inc k)))))
""";test=test.replace('(defn- seed-main [] :i64',dump+'(defn- seed-main [] :i64',1);test=test.replace('        nw (vector-at M1 MM-R0)','        nw (vector-at M1 MM-R0)\\n        static_report (t-static M1 0)',1);src.write_text(test)
''';s=s.replace(a,replacement)
# Explicitly audit proven invariant and refused mutation/bypass roots.
needle="(w/'expanded-proof.json').write_text";assert s.count(needle)==1;s=s.replace(needle,"""keys={tuple(map(int,x.split()[2:])) for x in stdout['expanded-real'].splitlines() if x.startswith('STATICREC ')}
ids={x[0]:i+1 for i,x in enumerate(m.FIX)}
for bit in [0,1]:assert (ids['sa_choose'],2,bit) in keys and (ids['sa_loop'],2,bit) in keys,keys
assert not any(f in [ids['sa_changed'],ids['sa_bypass']] for f,slot,bit in keys),keys
assert len(keys)<=16
(w/'expanded-variants.json').write_text(json.dumps({'status':'complete-positive-and-refused-static-variant-audit','variants':sorted(keys),'functions':ids},indent=2)+'\\n')
"""+needle)
(w/'expanded-proof.py').write_text(s);print('prepared invariant/changed/bypassed modes, loop bounds and fuel hand-oracles')
