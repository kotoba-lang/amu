from pathlib import Path
import subprocess,os,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-static-arg-20261005');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');loader=str(w/'kexe-loader');offset=0
for label,args in [('compile',['compile',str(w/'frame-unity.kotoba'),'--target','aarch64-macos','--output',str(w/'frame-seed.kseed')]),('extract',['extract-native',str(w/'frame-seed.kseed'),'--symbol','main','--output',str(w/'frame-seed.bin')])]:
 q=subprocess.run([loader,str(w/'seed-0.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/('frame-'+label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout,q.stderr)
 if label=='extract':offset=int(re.search(r':offset (\d+)',q.stdout).group(1))
rows=[]
for e in json.loads((r/'bench/embench/comparison-matrix.json').read_text())['entries']:
 src=r/e['source'];assert hashlib.sha256(src.read_bytes()).hexdigest()==e['expectedSourceSha256'];d=w/'frame-ports'/e['workload'];d.mkdir(parents=True,exist_ok=True)
 q=subprocess.run([loader,str(w/'frame-seed.bin'),str(offset),'0','aarch64','35,37,38,39','--','compile',str(src),'--target','aarch64-macos','--output',str(d/'image.kseed')],env=env,capture_output=True,text=True);(d/'compile.log').write_text(q.stdout+q.stderr);assert q.returncode==0,(e['workload'],q.stdout,q.stderr)
 sites=[list(map(int,x.split()[1:])) for x in q.stdout.splitlines() if x.startswith('STATIC ')];rows.append({'workload':e['workload'],'sites':sites,'privateStaticVariants':len(sites)});print(rows[-1],flush=True)
(w/'frame-admission.json').write_text(json.dumps({'status':'complete-native-frame-observation','observerOnly':True,'entries':rows,'privateStaticVariants':sum(x['privateStaticVariants'] for x in rows)},indent=2)+'\n')
