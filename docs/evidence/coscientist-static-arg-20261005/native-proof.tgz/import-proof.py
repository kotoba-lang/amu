from pathlib import Path
import subprocess,os,re,json,struct
w=Path('/private/tmp/amu-static-arg-20261005');scope={};s=(w/'expanded-proof.py').read_text();exec(s[:s.index("parts=['seed/")],scope);m=scope['m'];r=scope['r'];names=[x[0] for x in m.FIX];sid=names.index('sa_choose')+1;replacement=names.index('sa_replacement')+1;env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];images={};states=[]
for label in ['baseline-open','candidate-reopened','candidate-fresh-open']:
 backend=w/('baseline-41-a64gen.kotoba' if label.startswith('baseline') else '41-a64gen-prototype.kotoba');test=m.kotoba(True)
 if label=='candidate-reopened':test=test.replace('        M1 (gn-run M0)',f'        MC0 (gn-run M0)\n        M1 (gn-run-open (t-put (t-put MC0 MM-CODE-N 1) MM-FIX-N 1) {sid} 1)',1)
 else:test=test.replace('(gn-run M0)',f'(gn-run-open M0 {sid} 1)',1)
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/x).read_text() for x in parts)+'\n'+backend.read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+test)
 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+mode+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,mode,q.stdout,q.stderr)
  if mode=='extract':offset=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),offset,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'.stdout')).write_text(q.stdout);assert q.returncode==0,(label,q.stdout[-300:],q.stderr);blob,fc=m.blob_from(q.stdout);patched=bytearray(blob);struct.pack_into('<I',patched,fc[sid],0x14000000|(((fc[replacement]-fc[sid])//4)&0x03ffffff));path=w/(label+'-linked.bin');path.write_bytes(patched);images[label]=(path,fc)
# Reopening must equal fresh-open emission, not merely the same observed result.
a=m.blob_from((w/'candidate-reopened.stdout').read_text());b=m.blob_from((w/'candidate-fresh-open.stdout').read_text());assert a==b
closed=m.blob_from((w/'expanded-real.stdout').read_text());p=w/'candidate-closed-control.bin';p.write_bytes(closed[0]);images['candidate-closed-control']=(p,closed[1])
rows=[]
for caller,nargs,second in [('sa_call0',1,None),('sa_call1',1,None),('sa_dynamic',2,0),('sa_loop_call0',2,0),('sa_loop_call1',2,0)]:
 f=names.index(caller)+1
 for x in [-(1<<63),-1,0,(1<<63)-1]:
  for fuel in [1,2,3,4,5,6,7,8,16777216]:
   pair={}
   for label,(path,fc) in images.items():
    e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1',KEXE_CPU_SECONDS='30',KEXE_WALL_SECONDS='30');e.pop('KEXE_COMMAND',None)
    args=['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(path),str(fc[f]),str(nargs),'aarch64','-',str(x),*([str(second)] if nargs==2 else [])];q=subprocess.run(args,env=e,capture_output=True,text=True,timeout=35);assert ':fuel ' in q.stdout,(label,caller,q.stdout,q.stderr)
    pair[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
   assert pair['baseline-open']==pair['candidate-reopened']==pair['candidate-fresh-open'],(caller,x,fuel,pair)
   if fuel==16777216:assert pair['candidate-reopened']!=pair['candidate-closed-control'],(caller,x,pair)
   rows.append({'caller':caller,'x':x,'fuel':fuel,**pair})
 print('PASS allocating import substitution and closed->open restoration',caller,flush=True)
(w/'import-proof.json').write_text(json.dumps({'status':'complete-native-reopened-allocating-import-substitution','reopenedAndFreshOpenMachineBytesIdentical':True,'signature':'2 i64 parameters, i64 return; actual body charges fuel, allocates and returns77; diagnostic allocator clobbersx7','cases':rows,'comparisons':len(rows),'closedHighFuelControlsDiffer':True},indent=2)+'\n');print('PASS',len(rows),'import/fuel/supervisor comparisons',flush=True)
