from pathlib import Path
import ast, hashlib, json, math, re, statistics, sys

W = Path(sys.argv[1]).resolve()
D = W / 'collected'
source = Path('/Users/junkawasaki/github/workspaces/codex/embench-total-C-round84-20261012/collection-plan/verify.py')
node = next(n for n in ast.parse(source.read_text()).body if isinstance(n, ast.FunctionDef) and n.name == 'cpu')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<independent-raw-cpu>', 'exec'))
report = json.loads((D / 'results/report.json').read_text())
assert report['closure'] == []
expected = {x['workload']: x for x in json.loads((D / 'expected-original-accounting.json').read_text())}
review, values = [], {}
for row in report['rows']:
    p = D / row['raw']
    raw = json.loads(p.read_text())
    assert raw['maxAttempts'] == 3 and raw['selectionPolicy'] == 'FIRST_CPU_QUALIFIED_NOT_FASTEST'
    assert raw['cpuOnlyRetries'] and raw['noPilot'] and raw['noOldElapsedReuse']
    records = []
    accepted = []
    for attempt, s in enumerate(raw['samples']):
        assert s['attempt'] == attempt
        quiet = json.loads((p.parent / (row['workload'] + '-quiet-' + str(attempt) + '.json')).read_text())
        if s.get('executed') is False:
            assert not quiet['ready'] and s['reasons'] == ['quiet-admission-timeout'] and s['retryEligible']
            records.append(dict(attempt=attempt, accepted=False, reasons=s['reasons']))
            continue
        pre = cpu(quiet['probes'][-1]['cpuActivity'])
        assert quiet['ready'] and pre >= 70
        post = cpu(s['cpuActivity'])
        activity = s['cpuActivity']
        bg = min(100, post + 100 * activity['childCpuNs'] / (activity['envelopeNs'] * activity['logicalCpuCount']))
        assert abs(bg - activity['estimatedBackgroundIdlePercent']) < 1e-9
        sample = json.loads(s['stdout'].splitlines()[-1])
        ledger = expected[row['workload']]
        assert s['returncode'] == 0 and sample == s['sample']
        assert {k: v for k, v in sample.items() if k != 'elapsedNs'} == ledger['expectedSample']
        assert s['stderr'] == ledger['expectedStderr']
        assert len(re.findall(r':[a-z-]+ \d+', s['stderr'])) == 17
        fuel = re.search(r':fuel \{:initial (\d+) :remaining (\d+)\}', s['stdout'])
        assert fuel and int(fuel[1]) == 34359738368
        assert int(fuel[1]) - int(fuel[2]) == sample['benchmarkFuel'] + sample['verifyFuel']
        ns = sample['elapsedNs']
        assert ns == s['elapsedNs'] and ns >= 500000000
        reasons = (['raw-post-cpu'] if post < 70 else []) + (['background-cpu'] if bg < 70 else [])
        assert reasons == s['reasons'] and s['accepted'] == (not reasons)
        assert s['retryEligible'] == bool(reasons)
        records.append(dict(attempt=attempt, accepted=s['accepted'], reasons=reasons, elapsedNs=ns,
                            preRaw=pre, postRaw=post, backgroundIdle=bg, originalStateFuelAll17Exact=True))
        if s['accepted']:
            accepted.append((attempt, ns))
    assert len(accepted) <= 1
    chosen = accepted[0][0] if accepted else None
    assert raw['selectedAttempt'] == chosen and raw['complete'] == bool(accepted)
    if accepted:
        assert chosen == len(raw['samples']) - 1
        assert abs(row['elapsedNs'] - accepted[0][1]) < 1
        values.setdefault(row['workload'], {}).setdefault(row['arm'], []).append(accepted[0][1])
    else:
        assert len(raw['samples']) == 3 and row['elapsedNs'] is None
    review.append(dict(workload=row['workload'], slot=row['slot'], arm=row['arm'], records=records))
ratios = {}
for name, arms in values.items():
    if len(arms.get('OFF', [])) == len(arms.get('ON', [])) == 2:
        ratio = statistics.median(arms['ON']) / statistics.median(arms['OFF'])
        assert abs(ratio - report['ratios'][name]['medianONDividedByOFF']) < 1e-12
        ratios[name] = dict(medianONDividedByOFF=ratio, shorterPercent=100 * (1-ratio),
                            individualPairs=[arms['ON'][i]/arms['OFF'][i] for i in range(2)])
complete = report['status'] == 'COMPLETE_EXPLORATORY_ONE_FIXED4'
assert not complete or (len(review) == 4 and len(ratios) == 1)
out = dict(status='PASS_INDEPENDENT_FIXED4_RAW_CPU_ORIGINAL_STATE_FUEL_ALL17',
           campaignStatus=report['status'], complete=complete, ratios=ratios, slots=review,
           performanceGoalClaim=False, statisticalClaim=False, oldElapsedReuse=False)
(W / 'root-independent-review.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(dict(status=out['status'], campaignStatus=report['status'], complete=complete, ratios=ratios)))
