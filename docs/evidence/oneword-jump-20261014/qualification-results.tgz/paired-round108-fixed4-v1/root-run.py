from pathlib import Path
import json, shlex, subprocess

W = Path(__file__).resolve().parent
receipt = json.loads((W / 'root-setup-receipt.json').read_text())
root = receipt['root']
assert receipt['status'] == 'PASS_EXACT_FILES_TWO_BUILDS_GLOBAL_IDLE' and receipt['ownedRows'] == []
assert not (W / 'root-run-started.json').exists()
(W / 'root-run-started.json').write_text(json.dumps(dict(root=root)) + '\n')
ssh = ['-i', '/Users/junkawasaki/.ssh/murakumo', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15']
q = subprocess.run(['ssh', *ssh, 'joseph@100.82.123.35', 'python3 ' + shlex.quote(root + '/pf-fixed4-controller.py')], capture_output=True)
(W / 'root-run.stdout').write_bytes(q.stdout)
(W / 'root-run.stderr').write_bytes(q.stderr)
(W / 'root-run-terminal.json').write_text(json.dumps(dict(exit=q.returncode, stderrBytes=len(q.stderr)), indent=2) + '\n')
assert not q.stderr, q.stderr.decode()
print('Remote command ended; authoritative terminal report still requires collection')
