"""Root-only remote timing after separate reviewed setup/build/custody."""
import json,os,statistics,shutil,importlib.util,hashlib,subprocess,re,shlex
from pathlib import Path
def global_idle(exclude_ancestors=False):
 q=subprocess.run(['/bin/ps','-axo','pid=,ppid=,command='],capture_output=True,text=True,check=True)
 parsed=[]
 for line in q.stdout.splitlines():
  m=re.match(r'\s*(\d+)\s+(\d+)\s+(.*)',line)
  if m:parsed.append(dict(pid=int(m[1]),ppid=int(m[2]),command=m[3]))
 own=os.getpid();ancestors=set();byid={r['pid']:r for r in parsed};p=byid.get(own,{}).get('ppid',0)
 while p in byid and p not in ancestors:
  ancestors.add(p);p=byid[p]['ppid']
 watched=[]
 pattern=re.compile(r'/Users/joseph/github/workspaces/codex/embench-picojpeg-edn-20261009|/Users/joseph/github/workspaces/codex/seed-logical-immediate|/(?:timer(?:s)?(?:\s|/|$)|kexe-loader(?:\s|$)|(?:one-controller|confirm-controller)\.py(?:\s|$)|ablate\.py(?:\s|$)|(?:campaign[^ /]*|run_trigger)\.py(?:\s|$))')
 active=re.compile(r'/(?:OFF|ON)/timer(?:\s|$)|/(?:one-controller|confirm-controller|ablate|(?:campaign[^ /]*|run_trigger))\.py(?:\s|$)')
 for row in parsed:
  if row['pid']==own:continue
  # Exclude only an actual ancestor invoking this exact script with no
  # additional command. macOS login wrappers are explicitly recognized.
  if row['pid'] in ancestors:
   ownscript=str(Path(__file__).resolve())
   try: argv=shlex.split(row['command'])
   except ValueError: argv=[]
   shellnames=['/bin/zsh','/bin/sh','/bin/bash','/bin/dash']
   tail=None
   if len(argv)>=3 and argv[0] in shellnames and argv[1]=='-c': tail=argv[2:]
   elif argv and argv[0]=='/usr/bin/login':
    # Only the login's real shell invocation suffix can qualify.
    positions=[i for i,x in enumerate(argv) if x in shellnames]
    if len(positions)==1:
     i=positions[0]
     if i+2<len(argv) and argv[i+1]=='-c': tail=argv[i+2:]
   if tail is not None:
    if len(tail)==1:
     try: tail=shlex.split(tail[0])
     except ValueError: tail=[]
    if tail==['python3',ownscript]:continue
  if pattern.search(row['command']):watched.append(row)
 return watched
W=Path(__file__).resolve().parent
assert global_idle()==[]
assert (W/'qualification-binding.json').exists()
custody=json.loads((W/'root-setup-receipt.json').read_text());assert custody['status']=='PASS_EXACT_FILES_TWO_BUILDS_GLOBAL_IDLE' and custody['ownedRows']==[] and custody['root']==str(W)
for rel,row in json.loads((W/'packet-manifest.json').read_text()).items():
 p=W/rel;assert p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
O=W/'results';O.mkdir(exist_ok=False);report={'status':'RUNNING','protocol':'FOUR_FIXED_SLOTS_FIRST_CPU_QUALIFIED_MAX3','rows':[],'ratios':{},'noPilot':True,'adaptiveN':False,'oldElapsedReuse':False}
def save(): (O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for spec in json.loads((W/'spec.json').read_text()):
 values={'OFF':[],'ON':[]}
 for slot,arm in enumerate(spec['order']):
  d=O/(spec['workload']+'-slot'+str(slot));p=d/'timers'/spec['workload'];p.mkdir(parents=True);shutil.copy2(W/'timers'/spec['workload']/arm/'timer',p/'timer')
  shutil.copy2(W/'timers'/spec['workload']/arm/'timer-fixed-n',p/'timer-fixed-n')
  assert hashlib.sha256((p/'timer-fixed-n').read_bytes()).hexdigest()==custody['wrapperHashes'][spec['workload']+'/'+arm]
  assert hashlib.sha256((W/'timers'/spec['workload']/arm/'timer').read_bytes()).hexdigest()==custody['timerHashes'][spec['workload']+'/'+arm]
  expectedHash=custody['timerHashes'][spec['workload']+'/'+arm];assert hashlib.sha256((p/'timer').read_bytes()).hexdigest()==expectedHash
  loader=importlib.util.spec_from_file_location('slot_'+str(slot),W/'run_trigger.py');m=importlib.util.module_from_spec(loader);loader.loader.exec_module(m);m._quiet_wait_remaining=180.0
  old=dict(os.environ);os.environ.update(spec['environment'])
  try:ms=m.run_benchmark(spec['workload'],str(p/'timer-fixed-n'),type('Args',(),{'samples':1})())
  except Exception as ex:
   report['status']='FAILED_NON_CPU_NO_RETRY';report['failure']=repr(ex);report['closure']=global_idle();save();raise
  finally:os.environ.clear();os.environ.update(old)
  report['rows'].append({'workload':spec['workload'],'slot':slot,'arm':arm,'elapsedNs':None if ms is None else ms*1000000,'raw':str((d/'raw'/ (spec['workload']+'.json')).relative_to(W))});save()
  if ms is None:report['status']='REFUSED_INCOMPLETE_FIXED4';report['closure']=global_idle();save();raise SystemExit(2)
  values[arm].append(ms)
 report['ratios'][spec['workload']]={'medianONDividedByOFF':statistics.median(values['ON'])/statistics.median(values['OFF']),'individualPairs':[values['ON'][i]/values['OFF'][i]for i in range(2)],'exploratory':True};save()
report['closure']=global_idle();assert report['closure']==[]
report['status']='COMPLETE_EXPLORATORY_ONE_FIXED4';save()
