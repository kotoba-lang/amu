from pathlib import Path
import ast, hashlib, json, subprocess, tarfile

W = Path(__file__).resolve().parent
program = (W / 'remote-collect.py').read_bytes()
ast.parse(program)
assert not (W / 'collected').exists()
ssh = ['-i', '/Users/junkawasaki/.ssh/murakumo', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15']
host = 'joseph@100.82.123.35'
q = subprocess.run(['ssh', *ssh, host, 'python3 -'], input=program, capture_output=True)
(W / 'root-collect.stdout').write_bytes(q.stdout)
(W / 'root-collect.stderr').write_bytes(q.stderr)
assert q.returncode == 0 and not q.stderr and q.stdout, q.stderr.decode()
receipt = json.loads(q.stdout)
archive = W / 'root-collected.tar.gz'
q = subprocess.run(['scp', *ssh, host + ':' + receipt['archive'], str(archive)], capture_output=True)
assert q.returncode == 0
b = archive.read_bytes()
assert len(b) == receipt['bytes'] and hashlib.sha256(b).hexdigest() == receipt['sha256']
with tarfile.open(archive) as t:
    members = t.getmembers()
    assert len(members) == receipt['members']
    assert all(m.isfile() and not m.issym() and not m.islnk() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
    custody = json.load(t.extractfile('collection-custody.json'))
    assert custody['root'] == receipt['root'] and custody['ownedRows'] == []
    for row in custody['files']:
        data = t.extractfile(row['path']).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    (W / 'collected').mkdir()
    t.extractall(W / 'collected', filter='data')
(W / 'root-collection-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS exact collection archive and every result/source/timer hash')
