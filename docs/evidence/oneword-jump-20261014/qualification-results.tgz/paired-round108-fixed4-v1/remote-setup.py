from pathlib import Path
import ast, hashlib, json, os, re, shlex, subprocess, sys, tarfile

root, archive = Path(sys.argv[1]), Path(sys.argv[2])
sha = sys.argv[3]
assert hashlib.sha256(archive.read_bytes()).hexdigest() == sha
assert not root.exists(), 'Fresh namespace only; no overwrite'
with tarfile.open(archive) as t:
    members=t.getmembers()
    assert members and all(m.isfile() and not m.issym() and not m.islnk() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
    root.mkdir()
    t.extractall(root,filter='data')
manifest = json.loads((root / 'packet-manifest.json').read_text())
for rel, row in manifest.items():
    p = root / rel
    b = p.read_bytes()
    assert not p.is_symlink() and len(b) == row['bytes'] and hashlib.sha256(b).hexdigest() == row['sha256']
controller = root / 'pf-fixed4-controller.py'
node = next(n for n in ast.parse(controller.read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'global_idle')
__file__ = str(controller)
exec(compile(ast.Module(body=[node], type_ignores=[]), '<qualified-global-idle>', 'exec'))
def setup_idle():
    watched = global_idle()
    text = subprocess.check_output(['/bin/ps', '-axo', 'pid=,ppid=,command='], text=True)
    by = {}
    for line in text.splitlines():
        match = re.match(r'\s*(\d+)\s+(\d+)\s+(.*)', line)
        if match:
            by[int(match[1])] = (int(match[2]), match[3])
    parents = set()
    pid = by.get(os.getpid(), (0, ''))[0]
    while pid in by and pid not in parents:
        parents.add(pid)
        pid = by[pid][0]
    expected = ['python3', '-', str(root), str(archive), sha]
    remaining = []
    for row in watched:
        argv = shlex.split(row['command'])
        shell = ['/bin/zsh', '/bin/sh', '/bin/bash', '/bin/dash']
        positions = [i for i, word in enumerate(argv) if word in shell]
        tail = None
        if row['pid'] in parents and len(positions) == 1:
            i = positions[0]
            if i + 2 < len(argv) and argv[i+1] == '-c':
                tail = argv[i+2:]
                if len(tail) == 1:
                    tail = shlex.split(tail[0])
        if tail != expected:
            remaining.append(row)
    return remaining

assert setup_idle() == []
builds = []
for i, argv in enumerate(json.loads((root / 'build-plan.json').read_text())):
    assert len(argv) == 6 and argv[:3] == ['/usr/bin/clang', '-std=c11', '-O2'] and argv[4] == '-o'
    z = subprocess.run(argv, cwd=root, capture_output=True)
    (root / f'build-{i}.stdout').write_bytes(z.stdout)
    (root / f'build-{i}.stderr').write_bytes(z.stderr)
    builds.append(dict(argv=argv, exit=z.returncode, stdout=z.stdout.decode(), stderr=z.stderr.decode()))
    assert z.returncode == 0 and not z.stderr, (i, z.stderr)
assert len(builds) == 2
timers, wrappers = {}, {}
for s in json.loads((root / 'spec.json').read_text()):
    for arm in ['OFF', 'ON']:
        key = s['workload'] + '/' + arm
        d = root / 'timers' / s['workload'] / arm
        timer, wrapper = d / 'timer', d / 'timer-fixed-n'
        assert shlex.split(wrapper.read_text().splitlines()[1]) == ['exec', str(timer), str(s['n'])]
        assert os.access(wrapper, os.X_OK)
        timers[key] = hashlib.sha256(timer.read_bytes()).hexdigest()
        wrappers[key] = hashlib.sha256(wrapper.read_bytes()).hexdigest()
assert setup_idle() == []
receipt = dict(status='PASS_EXACT_FILES_TWO_BUILDS_GLOBAL_IDLE', root=str(root), archiveSHA256=sha,
               ownedRows=[], timerHashes=timers, wrapperHashes=wrappers, builds=builds, files=len(manifest)+1)
(root / 'root-setup-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
