from pathlib import Path
import json,hashlib,subprocess,os,sys,time
W=Path(__file__).parent;P=json.loads((W/'PLAN.json').read_text())
assert sys.argv[1:]==['--parent-approved-generation-only']
def pin(p):
 p=Path(p);z=p.read_bytes();return dict(path=str(p),bytes=len(z),sha256=hashlib.sha256(z).hexdigest())
def verify(r):assert pin(r['path'])==r,r['path']
for r in P['inputs']:verify(r)
for r in json.loads((W/'controller-pins.json').read_text())['files']:verify(r)
assert P['executionReady'] is True and P['maxNewCompilerCalls']==78
assert not (W/'started.json').exists(),'No generation restart'
(W/'started.json').write_text(json.dumps(dict(ownerPID=os.getpid(),time=time.time()))+'\n')
(W/'raw').mkdir();R=dict(status='LIVE_GENERATION_ONLY',calls=[],guestCalls=0)
E={k:v for k,v in os.environ.items() if not k.startswith('KEXE_')};E.update(P['environment'])
def save(name,z):(W/name).write_text(json.dumps(z,indent=2)+'\n')
def call(tag,args):
 protected=Path(P['stableProducer']['path']);before=protected.read_bytes();loaderBefore=Path(P['loader']['path']).read_bytes();sourcesBefore={e['source']['path']:Path(e['source']['path']).read_bytes()for e in P['entries']}
 z=subprocess.Popen(args,cwd=W,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 R.update(activeCall=tag,ownedChildPID=z.pid);save('progress.json',R)
 while True:
  try:o,e=z.communicate(timeout=60);break
  except subprocess.TimeoutExpired:R['observationTimeoutSameChildPreserved']=True;save('progress.json',R)
 (W/'raw'/(tag+'.stdout')).write_bytes(o);(W/'raw'/(tag+'.stderr')).write_bytes(e)
 assert protected.read_bytes()==before and Path(P['loader']['path']).read_bytes()==loaderBefore and all(Path(k).read_bytes()==v for k,v in sourcesBefore.items()),'Protected producer/source mutation'
 R['calls'].append(dict(tag=tag,argv=args,exit=z.returncode,stdoutSHA256=hashlib.sha256(o).hexdigest(),stderrSHA256=hashlib.sha256(e).hexdigest()))
 save('calls.json',R['calls']);assert z.returncode==0,(tag,z.returncode)
 print(tag,'TERMINAL',z.returncode,flush=True)
def payload(native,container):
 h,b=Path(container).read_bytes().split(b'\n\n',1);ls=h.decode().splitlines();m,n,c=ls[0].split()
 assert m=='KSEED1' and int(n)==len(b) and int(c)==len(ls)-1 and b==Path(native).read_bytes()
 ex={}
 for row in ls[1:]:
  name,p,a=row.split();assert name not in ex;ex[name]=[int(p),int(a)]
  assert 0<=int(p)<len(b) and int(p)%4==0 and 0<=int(a)<=16
 return ex
rows=[]
try:
 assert payload(P['stableProducer']['path'],P['stableProducerContainer']['path'])=={'main':[0,0]}
 assert len(P['entries'])==39
 for entry in P['entries']:
  source=entry['source'];verify(source)
  assert Path(source['path']).read_bytes()==Path(entry['baseline']['source']['path']).read_bytes()
  if entry['reused']:
   arm=P['reusedOfficialEDN'];assert entry['kind']=='official' and entry['workload']=='edn'
   for k in('native','container','source'):verify(arm[k])
   assert Path(arm['source']['path']).read_bytes()==Path(source['path']).read_bytes()
   assert payload(arm['native']['path'],arm['container']['path'])==arm['exports']
  else:
   tag=entry['tag'];k=W/(tag+'.kseed');b=W/(tag+'.bin')
   base=[P['loader']['path'],P['stableProducer']['path'],'0','0','aarch64','35,37,38,39','--']
   call(tag+'-compile',base+['compile',source['path'],'--target','aarch64-macos','--output',str(k)])
   call(tag+'-extract',base+['extract-native',str(k),'--symbol',entry['symbol'],'--output',str(b)])
   ex=payload(b,k);assert entry['symbol'] in ex
   arm=dict(native=pin(b),container=pin(k),source=source,exports=ex,offset=ex[entry['symbol']][0],arity=ex[entry['symbol']][1])
  rows.append(dict(**entry,arm=arm));save('generated-artifacts.json',dict(status='GENERATING_NOT_NATIVE_AUDIT_OR_GUEST',images=rows,newCompilerCalls=len(R['calls']),reusedCompilerCalls=0,guestCalls=0))
 assert len(R['calls'])==78 and len(rows)==39 and R['guestCalls']==0
 save('generated-artifacts.json',dict(status='PASS_ALL39_PAYLOAD_HEADER_EXPORT_SOURCE_CUSTODY_NOT_SEMANTIC_GATE',images=rows,newCompilerCalls=78,reusedCompilerCalls=0,totalDownstreamCompilerScope=78,guestCalls=0))
 R.update(status='TERMINAL0_ALL78_COMPILER_TOOLS_ALL39_CUSTODY_ONLY',all39NativeGatesPending=True,all483OriginalObservationsPending=True)
except BaseException as e:
 R.update(status='FIRST_FAILURE_PRESERVED',error=repr(e));save('first-failure.json',R);save('progress.json',R);raise
save('progress.json',R);save('terminal-receipt.json',R);print(R["status"],flush=True)
