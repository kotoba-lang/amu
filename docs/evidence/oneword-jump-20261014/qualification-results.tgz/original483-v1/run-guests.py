from pathlib import Path
import subprocess,json,hashlib,os,sys,time,importlib.util
W=Path(__file__).parent;P=json.loads((W/'PLAN.json').read_text())
assert sys.argv[1:]==['--parent-approved-483-guests-only']
def pin(p):
 p=Path(p);z=p.read_bytes();return dict(path=str(p),bytes=len(z),sha256=hashlib.sha256(z).hexdigest())
def verify(r):assert pin(r['path'])==r,r['path']
for r in P['inputs']:verify(r)
for r in json.loads((W/'controller-pins.json').read_text())['files']:verify(r)
assert P['executionReady'] is True and P['compilerCalls']==0 and P['guestCalls']==483
assert not (W/'started.json').exists(),'No observation restart'
(W/'started.json').write_text(json.dumps(dict(ownerPID=os.getpid(),time=time.time()))+'\n');(W/'raw').mkdir();(W/'native-audits').mkdir()
R=dict(status='LIVE_PRE_GUEST_GATES',compilerCalls=0,guests=[])
def save(name,z):(W/name).write_text(json.dumps(z,indent=2)+'\n')
try:
 spec=importlib.util.spec_from_file_location('spr_root_snapshot',P['nativeGate']['path']);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 assert len(P['all39Images'])==39
 gatePaths=set();gates=[]
 for z in P['all39Images']:
  out=mod.audit(z['baseline'],z['arm']);assert isinstance(out['changed'],bool)
  save('native-audits/'+z['tag']+'.json',out);gatePaths.add(z['arm']['native']['path']);gates.append(dict(tag=z['tag'],changed=out['changed']))
 assert len(gates)==39 and not R['guests'];save('all39-gates.json',dict(status='PASS_ALL39_BEFORE_ANY_GUEST',rows=gates))
 for z in P['observations']:
  arm=z['arm'];assert arm['native']['path'] in gatePaths and arm['arity']==1
  for k in('native','container','source'):verify(arm[k])
  E={k:v for k,v in os.environ.items() if not k.startswith('KEXE_')};E.update(P['environment']);E['KEXE_FUEL']=str(z['fuel'])
  argv=[P['loader']['path'],arm['native']['path'],str(arm['offset']),'1','aarch64','37',str(z['iterations'])]
  child=subprocess.Popen(argv,cwd=W,env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  R.update(status='LIVE_GUEST',activeTag=z['tag'],ownedChildPID=child.pid);save('progress.json',R)
  while True:
   try:o,e=child.communicate(timeout=60);break
   except subprocess.TimeoutExpired:R['observationTimeoutSameChildPreserved']=True;save('progress.json',R)
  (W/'raw'/(z['tag']+'.stdout')).write_bytes(o);(W/'raw'/(z['tag']+'.stderr')).write_bytes(e)
  actual=dict(exit=child.returncode,stdout=o.decode(),stderr=e.decode(),iterations=z['iterations'],fuel=z['fuel'])
  row=dict(tag=z['tag'],kind=z['kind'],actual=actual,expected=z['expected'],stdoutSHA256=hashlib.sha256(o).hexdigest(),stderrSHA256=hashlib.sha256(e).hexdigest(),argv=argv)
  R['guests'].append(row);save('observations.json',R['guests'])
  assert (actual['exit'],actual['stdout'],actual['stderr'])==(z['expected']['exit'],z['expected']['stdout'],z['expected']['stderr']),(z['tag'],'EXACT_ORIGINAL_RAW_PARITY_FAILURE')
 assert len(R['guests'])==483 and sum(z['kind']=='profile' for z in R['guests'])==95 and sum(z['kind']=='lowFuel' for z in R['guests'])==76 and sum(z['kind']=='interaction' for z in R['guests'])==312
 R.update(status='PASS_ORIGINAL19_95_76_312_ALL483_EXACT_RAW_ZERO_COMPILER',guestCalls=483,all39GatesPassed=True)
except BaseException as e:
 R.update(status='FIRST_FAILURE_PRESERVED',error=repr(e),guestCalls=len(R['guests']));save('first-failure.json',R);save('progress.json',R);raise
save('progress.json',R);save('terminal-receipt.json',R);print(json.dumps(dict(status=R['status'],guestCalls=483,compilerCalls=0,all39GatesPassed=True),indent=2),flush=True)
