from pathlib import Path
import json,subprocess,re,os
w=Path('/private/tmp/amu-local-vector-charged-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');ns={};exec((w/'fixture-proof.py').read_text().split('env=dict(')[0],ns);m=ns['m'];fns=ns['fns'];sir=ns['sir'];typeform=ns['typeform'];f=fns['lv_charged_writer'];owner=fns['lv_charged'];start=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==f);opstart=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==owner);call=next(i for i,x in enumerate(sir,1) if i>opstart and x[0]==m.C['OP-CALL']);sb=m.C['MM-SIR-BASE'];sw=m.C['MM-SIR-W'];fb=m.C['MM-FN-BASE']+f*m.C['MM-FN-W'];cases=[]
for j in range(9):
 for field in range(4):
  if j==2 and field==1:continue
  cases.append((sb+(start+j)*sw+field,sir[start+j-1][field]+1))
for field,value in [('FF-SIR',0),('FF-SIR',start+1),('FF-SIR',len(sir)-3),('FF-NPARAMS',2),('FF-NSLOTS',4),('FF-DEPTH',4),('FF-RTYPE',m.C['TY-I64']),('FF-PT0',m.C['TY-I64'])]:cases.append((fb+m.C[field],value))
for j in [1,2]:cases.append((fb+m.C['FF-PT0']+j,m.C['TY-F64']))
cases.append((sb+(call+1)*sw,m.C['OP-RES2']))
label=sir[start+1][1];foreign=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==fns['lv_sink'])+1
probe=f'''(defn- t-lv-check [M :vector-i64] :bool (gn-local-writer M {call} {f}))
(defn- t-lv-mut [M :vector-i64 at :i64 value :i64] :bool
 (let [old (vector-at M at) set (t-put M at value) got (t-lv-check set) restore (t-put set at old)] (not got)))
(defn- t-lv-open [M :vector-i64] :bool
 (let [old (gn-g M gn-g-open) old_n (gn-g M gn-g-open-n)
       set (-> M (gn-gs gn-g-open {f}) (gn-gs gn-g-open-n 1)) got (t-lv-check set)
       restore (-> set (gn-gs gn-g-open old) (gn-gs gn-g-open-n old_n))] (not got)))
(defn- t-lv-duplicate [M :vector-i64] :bool
 (let [at (+ MM-SIR-BASE (* {foreign} MM-SIR-W)) old_op (vector-at M at) old_a (vector-at M (+ at 1))
       set (-> M (t-put at OP-LABEL) (t-put (+ at 1) {label})) got (t-lv-check set)
       restore (-> set (t-put at old_op) (t-put (+ at 1) old_a))] (not got)))
(defn- t-lv-mode [M :vector-i64] :vector-i64
 (-> M (gn-gs gn-f-leaf 2) (gn-gs gn-f-ns 3) (gn-gs gn-f-dp 3) (gn-gs gn-f-out 0) (gn-gs gn-f-nsv 0) (gn-gs gn-f-fb 0)))
(defn- t-lv-mode-mut [M :vector-i64 field :i64 value :i64] :bool (not (gn-local-vmode (gn-gs (t-lv-mode M) field value))))
(defn- t-lv-guards [M :vector-i64] :bool
 (and (t-lv-check M)
 {' '.join(f'(t-lv-mut M {at} {v})' for at,v in cases)}
 (t-lv-open M) (t-lv-duplicate M)
 (not (gn-local-writer M {call} 0))
 (not (gn-local-writer M {call} (vector-at M MM-FN-N)))
 (gn-local-writer M {call} {fns['lv_writer']})
 (gn-local-vmode (t-lv-mode M))
 (t-lv-mode-mut M gn-f-leaf 0) (t-lv-mode-mut M gn-f-leaf 1)
 (t-lv-mode-mut M gn-f-ns 4) (t-lv-mode-mut M gn-f-dp 4)
 (t-lv-mode-mut M gn-f-out 8) (t-lv-mode-mut M gn-f-nsv 1) (t-lv-mode-mut M gn-f-fb 16)))
'''
text=m.kotoba(True).replace('(defn- seed-main [] :i64',typeform+probe+'(defn- seed-main [] :i64').replace('        M1 (gn-run (t-small-types M0))','        M1 (gn-run (t-lv-types (t-small-types M0)))').replace('(if (and mask_shared','(if (and (t-lv-guards M1) mask_shared')
parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];src=w/'mutation-probe.kotoba';src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+text);env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/'mutation-probe.kseed')]),('extract',['extract-native',str(w/'mutation-probe.kseed'),'--symbol','main','--output',str(w/'mutation-probe.bin')])]:
 q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/('mutation-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(stage,q.stdout[-300:],q.stderr)
 if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
q=subprocess.run([str(w/'kexe-loader'),str(w/'mutation-probe.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/'mutation-probe.stdout').write_text(q.stdout+q.stderr);assert q.returncode==0,(q.stdout[-300:],q.stderr);(w/'mutation-proof.json').write_text(json.dumps({'status':'complete-native-exact-writer-and-local-mode-mutation-refusals','instructionFieldMutations':35,'metadataAndCallMutations':len(cases)-35,'positiveControls':3,'openRefusals':1,'duplicateLabelRefusal':True,'modeRefusals':7,'invalidCalleeControls':2,'mutations':cases},indent=2)+'\n');print('PASS all',len(cases),'native writer shape refusals plus 7 mode guards')
