from pathlib import Path
import json,struct
w=Path('/private/tmp/amu-local-vector-charged-20261006');b=Path('/private/tmp/amu-small-tail-frame-20261006');load=lambda p:json.loads(p.read_text());rows=[];changes=[]
for e in load(w/'ports-correctness.json')['entries']:
 name=e['workload'];a=load(w/'observer/meta-ports'/name/'census.json');old=load(b/'observer/meta-ports'/name/'census.json');raw=lambda root:[z for z in (root/'observer/meta-ports'/name/'compile.log').read_text().splitlines() if z.startswith('SIR ')];assert raw(w)==raw(b);assert a['allEmissionRangesPartitioned'] and old['allEmissionRangesPartitioned'];assert a['functions'].keys()==old['functions'].keys()
 for f,v in a['functions'].items():
  for k in ['start','end','frameBytes','locals','depth','localCalleeRegisters','leaf']:assert v[k]==old['functions'][f][k],(name,f,k)
  assert [[z[k] for k in ['start','backedge','label']] for z in v['loops']]==[[z[k] for k in ['start','backedge','label']] for z in old['functions'][f]['loops']]
 oa={v['sir']:v for v in old['events']};words=lambda v:[int(z,16) for z in v['words']]
 caches={int(z.split()[1]):list(map(int,z.split()[2:])) for z in (w/'observer/meta-ports'/name/'compile.log').read_text().splitlines() if z.startswith('CACHE ')}
 for v in a['events']:
  p=oa[v['sir']]
  if v['op']=='OP-FUEL':assert v['words']==p['words'],(name,v,p)
  if len(v['words'])<len(p['words']):
   assert name=='statemate' and v['op'] in ['OP-CALL','OP-RT'] and len(p['words'])-len(v['words'])==11,(name,v,p)
   f=a['functions'][str(v['fn'])];assert f['leaf']==2 and f['locals']<=3 and f['depth']<=3 and f['frameBytes']==0
   assert caches[v['sir']][0]==2 and caches[v['sir']][1]>0 and caches[v['sir']][2:]==caches[v['sir']][:2],(v,caches[v['sir']])
   assert any(((z&0xffe00c00)==0xf8200800) and ((z>>5)&31)==4 for z in words(v)),(name,v)
   assert words(v)[:5]==words(p)[:5]==[0xf94004f0,0xf1000610,0x54000042,0xd4200000,0xf90004f0],(v,p)
   changes.append({'workload':name,'sir':v['sir'],'function':v['fn'],'cache':caches[v['sir']],'baselineWords':p['words'],'candidateWords':v['words']})
 rows.append({'workload':name,'originalSirExact':True,'frameLocalDepthLeafMetadataExact':True,'fuelEventWordsExact':True,'oldCodeWords':old['codeWords'],'newCodeWords':a['codeWords'],'nativeByteExact':e['nativeSha256']==next(z['nativeSha256'] for z in load(b/'ports-correctness.json')['entries'] if z['workload']==name)})
assert len(changes)>0 and sum(z['nativeByteExact'] for z in rows)==18
assert sum(z['oldCodeWords']-z['newCodeWords'] for z in rows)==11*len(changes)
fx=load(w/'fixture-proof.json');assert fx['comparisons']==6300
for z in fx['regions']:
 delta=z['baselineWords']-z['candidateWords'];assert delta==({'twice':22}.get(z['variant'],11 if z['variant'] in ['normal','zero','direct','charged','quot0','quotneg','quot3'] else 0)),z
same=(w/'permanent-regression-fixture.bin').read_bytes()==(b/'permanent-regression-fixture.bin').read_bytes()
(w/'instruction-audit.json').write_text(json.dumps({'status':'complete-all19-local-witness-charged-store-and-frame-fuel-audit','staticCountsNotTimeShares':True,'original508FixtureBlobByteExact':same,'originalUnitGoldenByteExact':same,'storeSites':changes,'fixtureRegions':fx['regions'],'rows':rows},indent=2)+'\n');print('PASS',len(changes),'same-local stores; all19 original frames/SIR/fuel; other18 guest bytes exact; old fixture exact',same)
