from pathlib import Path
import json,re,struct,hashlib,subprocess,collections
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-local-vector-write-20261006/observer');C={}
for n in ['seed/SIR','seed/HEADS','seed/MEMORY-MAP']:
 for m in re.finditer(r'\[:c (\S+) (-?\d+)',(r/n).read_text()):C[m[1]]=int(m[2])
ops={v:k for k,v in C.items() if k.startswith('OP-')};audit=json.loads((w/'observer-byte-audit.json').read_text());assert len(audit['entries'])==19;rows=[]
for e in audit['entries']:
 name=e['workload'];d=w/'meta-ports'/name;blob=(d/'native.bin').read_bytes();sir={};fns={};emits=[]
 for line in (d/'compile.log').read_text().splitlines():
  if line.startswith('SIR '):
   i,*a=map(int,line.split()[1:]);assert i not in sir or sir[i]==a;sir[i]=a
  elif line.startswith('FN '):
   f,*a=map(int,line.split()[1:]);assert f not in fns;fns[f]=dict(zip(['start','frameBytes','locals','depth','localCalleeRegisters','leaf','codeWordStart'],a))
  elif line.startswith('EMIT '):emits.append(list(map(int,line.split()[1:])))
 assert sorted(sir)==list(range(1,max(sir)+1));labels={v[1]:i for i,v in sir.items() if v[0]==C['OP-LABEL']};owner={}
 for f,info in fns.items():
  start=info['start'];assert sir[start][0]==C['OP-FN'] and sir[start][1]==f;j=start+1
  while sir[j][0]!=C['OP-END']:j+=1
  info['end']=j;info['loops']=[]
  for i in range(start,j+1):owner[i]=f
  for i in range(start+1,j):
   op,a,b,c=sir[i];label=a if op==C['OP-BR'] else b if op in [C['OP-BRZ'],C['OP-BRNZ']] else 0;p=labels.get(label,0)
   if start<p<i:info['loops'].append({'start':p,'backedge':i,'label':label})
 expected=1;pos=1;events=[]
 for i,skip,start,end in emits:
  assert i==expected and start==pos and start<=end and (end-1)*4<=len(blob),(name,i,expected,start,pos,end)
  assert all(owner[z]==owner[i] for z in range(i,i+skip+1));events.append({'sir':i,'consumedThrough':i+skip,'op':ops[sir[i][0]],'fn':owner[i],'firstWord':start,'afterWord':end,'wordCount':end-start,'words':[hex(x[0]) for x in struct.iter_unpack('<I',blob[(start-1)*4:(end-1)*4])]});expected=i+skip+1;pos=end
 assert expected==max(sir)+1
 for f,info in fns.items():
  fe=[x for x in events if x['fn']==f];info['emittedWords']=sum(x['wordCount'] for x in fe)
  for loop in info['loops']:
   le=[x for x in fe if loop['start']<=x['sir']<=loop['backedge']];assert all(x['consumedThrough']<=loop['backedge'] for x in le)
   loop['emittedWords']=sum(x['wordCount'] for x in le);loop['operations']={};loop['events']=le
   for x in le:loop['operations'][x['op']]=loop['operations'].get(x['op'],0)+x['wordCount']
 row={'workload':name,'nativeSha256':hashlib.sha256(blob).hexdigest(),'nativeOffset':e['offset'],'sirCount':len(sir),'codeWords':pos-1,'allEmissionRangesPartitioned':True,'functions':fns,'events':events}
 (d/'census.json').write_text(json.dumps(row,indent=2)+'\n');rows.append({k:v for k,v in row.items() if k!='events'})
 if name=='matmult-int':
  print('MATMULT fn5',json.dumps(fns[5],indent=2),flush=True)
  (w/'native-words.s').write_text('.text\n.globl _native_words\n_native_words:\n'+''.join(f'.long 0x{x[0]:08x}\n' for x in struct.iter_unpack('<I',blob)))
  for cmd,out in [(['xcrun','clang','-target','arm64-apple-macos11','-c',str(w/'native-words.s'),'-o',str(w/'native-words.o')],None),(['xcrun','llvm-objdump','--disassemble',str(w/'native-words.o')],w/'native-disassembly.txt')]:
   q=subprocess.run(cmd,capture_output=True,text=True);assert q.returncode==0,q.stderr
   if out:out.write_text(q.stdout)
(w/'census.json').write_text(json.dumps({'status':'complete-native-all19-read-only-SIR-and-emission-census','notRuntimeTimeShares':True,'notPerformanceMeasurement':True,'productChanged':False,'all19DiagnosticQuietBytesAndOffsetsEqual':True,'entries':rows},indent=2)+'\n')
print('PASS all19 complete SIR coverage and exact contiguous emission partitions',flush=True)
