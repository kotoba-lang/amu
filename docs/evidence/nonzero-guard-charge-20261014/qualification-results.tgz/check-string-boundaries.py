from pathlib import Path
import json,hashlib,os,subprocess,importlib.util,re
W=Path(__file__).resolve().parent;D=W/'string-boundaries-v1';D.mkdir(exist_ok=False);A=D/'artifacts';A.mkdir();raw=D/'raw';raw.mkdir()
S=A/'controls.kotoba';S.write_text('''(ns guarded-charge-controls (:export [run char-at]))
(defn char-at [s :string i :i64] :i64 (if (= i (string-length s)) 0 (string-code-point-at s i)))
(defn run [kind :i64 i :i64] :i64
 (let [s (case kind 0 "abc" 1 "éa" 2 (string-concat "ab" "c") 3 "" 4 "😀" "abc")]
  (char-at s i)))
''')
L=W.parent/'embench-pf-twoarg-20261013/protected-host/kexe-loader'
P={'OFF':W.parent/'seed-prepaid-fuel-register-reuse-20261014/selfbuild-v1/host/G4.bin','ON':W/'compiler-only-v1/artifacts/candidate.bin'}
def pin(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
assert pin(P['OFF'])['sha256']=='611ac7a79532c345bc36c03280962d3b847e1ad622e3f39a0a2588ad794dd008'
assert pin(P['ON'])['sha256']==json.loads((W/'compiler-only-v1/report.json').read_text())['nativeSHA256']
pins={p:pin(p)for p in [L,S,*P.values()]};calls=[]
env={k:v for k,v in os.environ.items()if not k.startswith('KEXE_')};env.update(KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(A),KEXE_FUEL='off',KEXE_VECTORS='4194304',KEXE_VECTOR_ITEMS='134217728',KEXE_STRING_POOL='268435456',KEXE_PAIRS='16777216',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',TMPDIR=str(A))
def call(tag,args,e):
 z=subprocess.run(list(map(str,args)),cwd=D,env=e,capture_output=True,timeout=1800);(raw/(tag+'.stdout')).write_bytes(z.stdout);(raw/(tag+'.stderr')).write_bytes(z.stderr);calls.append(dict(tag=tag,exit=z.returncode));(D/'calls.json').write_text(json.dumps(calls,indent=2)+'\n');assert all(pin(p)==v for p,v in pins.items());return z.returncode,z.stdout,z.stderr
arms={}
for tag,p in P.items():
 k=A/(tag+'.kseed');b=A/(tag+'.bin');base=[L,p,'0','0','aarch64','35,37,38,39','--']
 for name,args in [('compile',['compile',S,'--target','aarch64-macos','--output',k]),('extract',['extract-native',k,'--symbol','run','--output',b])]:
  code,_,err=call(tag+'-'+name,base+args,env);assert code==0 and not err
 h,payload=k.read_bytes().split(b'\n\n',1);assert payload==b.read_bytes();ex={n:[int(o),int(a)]for n,o,a in map(str.split,h.decode().splitlines()[1:])};assert ex['run'][1]==ex['char-at'][1]==2;arms[tag]=dict(native=pin(b),container=pin(k),source=pin(S),exports=ex)
spec=importlib.util.spec_from_file_location('string_physical',W/'native-gate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);proof=m.audit(arms['OFF'],arms['ON']);assert proof['changed'] and len(proof['sites'])==1;(D/'physical-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
def oracle(kind,i):
 b=['abc','éa','abc','','😀'][kind].encode()
 if i==len(b):return 0
 if i<0 or i>=len(b):return None
 try:return ord(b[i:].decode()[0])
 except UnicodeError:return None
indices=[-(1<<63),-1,0,1,2,3,4,5,127,(1<<63)-1]
cases=[dict(symbol='run',kind=k,i=i,fuel=100000,result=oracle(k,i))for k in range(5)for i in indices]
cases += [dict(symbol='run',kind=k,i=i,fuel=f,result=oracle(k,i))for k,i in [(0,0),(0,3),(1,0),(2,1)]for f in range(1,129)]
fuels=[1,2,100000,(1<<63),(1<<64)-1]
cases += [dict(symbol='char-at',kind=h,i=i,fuel=f,result=None)for h in [0,-1,1,(1<<63)-1]for i in [0,-1]for f in fuels]
cases += [dict(symbol='run',kind=0,i=0,fuel=f,result=97)for f in fuels[-2:]]
(D/'cases.json').write_text(json.dumps(dict(cases=cases),indent=2)+'\n')
guest={k:v for k,v in env.items()if not k.startswith('KEXE_')};guest.update(KEXE_ARENA_USE='1',KEXE_STRUCTURED_REPORT='1',KEXE_CPU_SECONDS='60',KEXE_WALL_SECONDS='60');rows=[]
for i,c in enumerate(cases):
 pair=[];guest['KEXE_FUEL']=str(c['fuel'])
 for tag,a in arms.items():
  off,arity=a['exports'][c['symbol']];code,o,e=call(f'{i}-{tag}',[L,a['native']['path'],off,arity,'aarch64','37',c['kind'],c['i']],guest)
  if b':status :ok'in o:
   v=re.search(rb':result (-?\d+)',o);assert code==0 and c['result'] is not None and v and int(v[1])==c['result']
  else:
   assert code==120 and b':status :trap :exit 120'in o
   if b':SIGTRAP'in e:assert c['fuel']<=128 and b'budget/fuel'in e and re.search(rb':remaining 0\}',o)
   else:assert b':SIGILL'in e and c['result'] is None
  f=re.search(rb':fuel \{:initial (\d+) :remaining (\d+)\}',o);assert f and int(f[1])==c['fuel'] and 0<=int(f[2])<=c['fuel'] and len(re.findall(rb':[a-z-]+ \d+',e))==17;pair.append((code,o,e))
 assert pair[0]==pair[1],('STRING_BOUNDARY_RAW_PARITY',c);rows.append(dict(**c,exit=pair[0][0]))
r=dict(status='PASS_STRING_ASCII_UNICODE_POOL_ENDPOINT_INVALID_HANDLE_INDEX_FUEL1_128_UINT64_EXACT_RAW_ALL17',pairs=len(rows),guestCalls=2*len(rows),compilerCalls=4,actualUnreachableEdgeElisions=1,rows=rows,performanceMeasured=False);(D/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(r['status'],r['pairs'])
