from pathlib import Path
import ast, hashlib, json, shlex, subprocess

W = Path(__file__).resolve().parent
program = (W / 'remote-setup.py').read_bytes()
ast.parse(program)
remote = json.loads((W / 'PLAN.json').read_text())['remoteRoot']
assert remote == '/Users/joseph/github/workspaces/codex/embench-picojpeg-edn-20261009/Nonzero-guard-charge-round101-fixed4-20261014-v1'
archive = W / 'root-public-packet.tar.gz'
sha = hashlib.sha256(archive.read_bytes()).hexdigest()
ssh = ['-i', '/Users/junkawasaki/.ssh/murakumo', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15']
command = 'python3 - ' + ' '.join(map(shlex.quote, [remote, remote + '-packet.tar.gz', sha]))
q = subprocess.run(['ssh', *ssh, 'joseph@100.82.123.35', command], input=program, capture_output=True)
(W / 'root-setup.stdout').write_bytes(q.stdout)
(W / 'root-setup.stderr').write_bytes(q.stderr)
assert q.returncode == 0 and not q.stderr and q.stdout, (q.returncode, q.stderr.decode())
receipt = json.loads(q.stdout)
assert receipt['status'] == 'PASS_EXACT_FILES_TWO_BUILDS_GLOBAL_IDLE' and receipt['ownedRows'] == []
assert receipt['root'] == remote and receipt['archiveSHA256'] == sha
(W / 'root-setup-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS exact archive, two host timer builds, two fixed-N wrappers and closure')
