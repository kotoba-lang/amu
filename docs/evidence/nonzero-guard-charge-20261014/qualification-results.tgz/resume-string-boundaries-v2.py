from pathlib import Path
import json,hashlib,os,subprocess,importlib.util,re
W=Path(__file__).resolve().parent;B=W/'string-boundaries-v1';D=W/'string-boundaries-v2';D.mkdir(exist_ok=False);raw=D/'raw';raw.mkdir();L=W.parent/'embench-pf-twoarg-20261013/protected-host/kexe-loader'
def pin(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
arms={};S=B/'artifacts/controls.kotoba'
for tag in ['OFF','ON']:
 b=B/'artifacts'/(tag+'.bin');k=b.with_suffix('.kseed');h,payload=k.read_bytes().split(b'\n\n',1);assert payload==b.read_bytes();ex={n:[int(o),int(a)]for n,o,a in map(str.split,h.decode().splitlines()[1:])};arms[tag]=dict(native=pin(b),container=pin(k),source=pin(S),exports=ex)
spec=importlib.util.spec_from_file_location('resume_physical',W/'native-gate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);proof=m.audit(arms['OFF'],arms['ON']);assert proof['changed'] and len(proof['sites'])==1
cases=json.loads((B/'cases.json').read_text())['cases'];assert len(cases)==604
limit=(1<<53)-1
cases += [dict(symbol='char-at',kind=h,i=i,fuel=limit,result=None)for h in [0,-1,1,(1<<63)-1]for i in [0,-1]]
cases += [dict(symbol='run',kind=0,i=i,fuel=limit,result=97 if i==0 else 0)for i in [0,3]]
(D/'cases.json').write_text(json.dumps(dict(cases=cases),indent=2)+'\n')
pins=[pin(L),pin(S),pin(B/'cases.json'),pin(B/'calls.json'),pin(B/'physical-proof.json')]+[a[k]for a in arms.values()for k in ['native','container']]+[pin(p)for p in sorted((B/'raw').glob('*'))]
(D/'protected-inputs.json').write_text(json.dumps(dict(files=pins),indent=2)+'\n')
def verify():
 for r in pins:assert pin(Path(r['path']))==r
verify();E={k:v for k,v in os.environ.items()if not k.startswith('KEXE_')};E.update(KEXE_ARENA_USE='1',KEXE_STRUCTURED_REPORT='1',KEXE_CPU_SECONDS='60',KEXE_WALL_SECONDS='60');calls=[];rows=[];reused=actual=config=0
for i,c in enumerate(cases):
 pair=[];E['KEXE_FUEL']=str(c['fuel'])
 for tag,a in arms.items():
  key=f'{i}-{tag}';oPath=B/'raw'/(key+'.stdout');ePath=B/'raw'/(key+'.stderr')
  if oPath.exists():
   assert ePath.exists();o=oPath.read_bytes();e=ePath.read_bytes();old=next(r for r in json.loads((B/'calls.json').read_text())if r['tag']==key);code=old['exit'];reused+=1
  else:
   off,arity=a['exports'][c['symbol']];z=subprocess.run(list(map(str,[L,a['native']['path'],off,arity,'aarch64','37',c['kind'],c['i']])),cwd=D,env=E,capture_output=True,timeout=60);code,o,e=z.returncode,z.stdout,z.stderr;(raw/(key+'.stdout')).write_bytes(o);(raw/(key+'.stderr')).write_bytes(e);calls.append(dict(tag=key,exit=code));(D/'new-calls.json').write_text(json.dumps(calls,indent=2)+'\n')
  if c['fuel']>limit:
   assert code==2 and not o and e==b'kexe-loader: KEXE_FUEL exceeds the maximum budget 9007199254740991 (2^53-1)\n';config+=1
  else:
   actual+=1
   if b':status :ok'in o:
    v=re.search(rb':result (-?\d+)',o);assert code==0 and c['result'] is not None and v and int(v[1])==c['result']
   else:
    assert code==120 and b':status :trap :exit 120'in o
    if b':SIGTRAP'in e:assert c['fuel']<=128 and b'budget/fuel'in e and re.search(rb':remaining 0\}',o)
    else:assert b':SIGILL'in e and c['result'] is None
   f=re.search(rb':fuel \{:initial (\d+) :remaining (\d+)\}',o);assert f and int(f[1])==c['fuel'] and 0<=int(f[2])<=c['fuel'] and len(re.findall(rb':[a-z-]+ \d+',e))==17
  pair.append((code,o,e))
 assert pair[0]==pair[1],('STRING_BOUNDARY_RAW_PARITY',c);rows.append(dict(**c,exit=pair[0][0]))
verify();assert len(rows)==614 and actual==1192 and config==36 and reused==1131
r=dict(status='PASS_STRING614_ASCII_UNICODE_POOL_ENDPOINT_INVALID_HANDLE_INDEX_FUEL1_128_PUBLIC_MAX_CONFIGURATION_REFUSALS_EXACT_RAW_ALL17',pairs=614,actualGuestCalls=actual,configurationRefusals=config,compilerCalls=0,newLoaderInvocations=len(calls),reusedAlreadyObservedInvocations=reused,originalCompilerCalls=4,actualUnreachableEdgeElisions=1,firstFailurePreserved='v1 expected guest for excessive fuel; loader refused configuration before any guest',noRepeatedObservedGuests=True,rows=rows,performanceMeasured=False);(D/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(r['status'],r['newLoaderInvocations'])
