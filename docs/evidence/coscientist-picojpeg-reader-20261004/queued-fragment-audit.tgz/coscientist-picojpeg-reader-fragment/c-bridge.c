/* BOOTSTRAP-TOOL: unchanged original reader primitives on original fixture. */
#define GLOBAL_SCALE_FACTOR 1
#include <stdint.h>
#include <limits.h>
#include "../upstream/src/picojpeg/libpicojpeg.c"
#include "../upstream/src/picojpeg/picojpeg_test.c"
static int last;
static void reset(int mode){memset(gInBuf,0,sizeof(gInBuf));jpeg_off=0;g_pNeedBytesCallback=pjpeg_need_bytes_callback;g_pCallback_data=0;gCallbackStatus=0;gInBufOfs=gInBufLeft=gTemFlag=gBitBuf=0;gBitsLeft=8;last=0;if(mode)init();}
#define EXTRA int64_t x1,int64_t x2,int64_t x3,int64_t x4,int64_t x5,int64_t x6,int64_t ctx
int64_t observe(int64_t encoded,EXTRA){int mode=encoded/1048576,code=encoded%1048576,limit=code/512,cell=code%512;if(encoded<0||mode>3)return INT64_MIN;reset(mode);
 for(int i=0;i<limit;i++){int n=1+i%16,op=i%5;if(mode==0)last=getChar();else if(mode==1)last=getBits1(n);else if(mode==2)last=getBits2(n);else if(op==0)last=getBits(n,i%2);else if(op==1)last=getBit();else if(op==2)last=getChar();else if(op==3)last=getOctet(1);else{fixInBuffer();last=-1;}}
 if(cell<256)return gInBuf[cell];switch(cell){case 256:return gInBufOfs;case 257:return gInBufLeft;case 258:return gTemFlag;case 259:return gBitBuf;case 260:return gBitsLeft;case 261:return jpeg_off;case 262:return gCallbackStatus;case 263:return last;default:return INT64_MIN;}}
int64_t decoder_selfcheck(int64_t n,EXTRA){benchmark_body(1,n);return verify_benchmark(0);}
