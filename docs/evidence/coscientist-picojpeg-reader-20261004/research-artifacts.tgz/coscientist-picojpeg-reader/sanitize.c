#include "c-bridge.c"
#include <stdio.h>
int main(void){int reads=0;for(int n=1;n<=32;n++)if(decoder_selfcheck(n,0,0,0,0,0,0,0)!=1)return 1;
 int common[]={0,1,2,7,16,252,253,1024};for(int mode=0;mode<4;mode++)for(int j=0;j<8;j++)for(int cell=0;cell<264;cell++){if(observe(mode*1048576+common[j]*512+cell,0,0,0,0,0,0,0)==INT64_MIN)return 2;reads++;}
 int tail[]={569,570,571,574};for(int j=0;j<4;j++)for(int cell=0;cell<264;cell++){if(observe(tail[j]*512+cell,0,0,0,0,0,0,0)==INT64_MIN)return 3;reads++;}
 printf("PASS 32 unchanged C decoder/verifier selfchecks, %d initialized reader state accesses\n",reads);return 0;}
