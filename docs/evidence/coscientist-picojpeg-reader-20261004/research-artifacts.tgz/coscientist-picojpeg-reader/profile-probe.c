#include "c-bridge.c"
#include <stdio.h>
int main(void){jpeg_off=0;unsigned s=pjpeg_decode_init(&pInfo,pjpeg_need_bytes_callback,0,0);printf("init=%u width=%u height=%u components=%u scan=%u blocks=%u MCU=%ux%u total=%u\n",s,gImageXSize,gImageYSize,gCompsInFrame,gScanType,gMaxBlocksPerMCU,gMaxMCUXSize,gMaxMCUYSize,gNumMCUSRemaining);int mcus=0;while((s=pjpeg_decode_mcu())==0)mcus++;printf("decodedMCUs=%d terminal=%u bytes=%u verifier=%d\n",mcus,s,jpeg_off,verify_benchmark(0));return verify_benchmark(0)?0:1;}
