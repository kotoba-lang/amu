from pathlib import Path
import json,hashlib
D=Path(__file__).parent
W=D.parent; B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation'); I=W/'implementation-v4'
c=json.loads((D/'call-comparison.json').read_text());f=json.loads((D/'frame-comparison.json').read_text());p=json.loads((D/'footprint.json').read_text())
def pin(path):return dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
inputs=[B/'seed-4.bin',I/'seed-4.bin',B/'observer/ports/statemate/compile.log',B/'observer/ports/statemate/native.bin',I/'observer/ports/statemate/compile.log',I/'observer/ports/statemate/native.bin',I/'41-a64gen-prototype.kotoba',I/'clones-native.kotoba',W/'team-independent-v4/report.json']
r=dict(status='PASS_STATIC_NEGATIVE_CAUSE_CHECK',candidateAdopted=False,cause='Undetermined; actual sampled-PC or controlled successor evidence is needed for causality.',baselineSeed=pin(B/'seed-4.bin'),candidateSeed=pin(I/'seed-4.bin'),callSpans={k:v for k,v in c.items() if k not in ('callsDetail','status')},frames={k:v for k,v in f.items() if k!='frames'},footprint=p,findings=['All 1,474 cloned CALL records are bound by PCMAP to original CALL SIR. Actual native CALL emission has 216 BL instructions in both variants; zero no-BL to BL changes and zero lost tail-B sites.', 'All 532 cloned functions retain original frame size, callee-save count and leaf class; 390 shared-fuel leaf2 functions remain leaf2.', '416 cloned CALL spans change instruction length; their aggregate difference is minus 2,730 words. Static helper-fusion loss and frame inflation are not supported by these comparisons.', 'Full image grows from 87,716 to 152,292 bytes because original bodies are preserved plus 532 private clones; original539 becomes1071functions. Direct-branch distance aggregate rises from1,484,952 to1,553,152 bytes over611 static CALL spans. Neither count is dynamically weighted or a proven slowdown cause.'],limitations=['Static counts do not establish executed hotness, cache-miss rates or causality.', 'EMIT spans account for skip/coalescing as emitted; zero-BL spans alone do not distinguish every fusion family. Preserved skip and branch classifications support the narrow negative check.', 'Reader-cache modes are not printed by this observer; do not claim independently sampled runtime cache-mode frequencies.', 'Independent V4 whole-machine proof separately binds cloned SIR, fix targets, aux1 entries and permitted guard deletions. This diagnosis does not rerun native proof, timing or profiling.'],inputPins=[pin(x) for x in inputs])
# carry skip changes explicitly
r['callSpans']['skipTransitions']={}
for x in c['callsDetail']:
 if x['baseline'] and x['candidate']:
  k=f"{x['baseline']['skip']}->{x['candidate']['skip']}";r['callSpans']['skipTransitions'][k]=r['callSpans']['skipTransitions'].get(k,0)+1
(D/'report.json').write_text(json.dumps(r,indent=2)+'\n')
(D/'artifact-pins.json').write_text(json.dumps([pin(x) for x in sorted(D.iterdir()) if x.is_file() and x.name!='artifact-pins.json'],indent=2)+'\n')
print(pin(D/'report.json'));print(r['callSpans']['skipTransitions'])
