from pathlib import Path
import json,struct,collections,hashlib
W=Path('/private/tmp/amu-vector-shape-specialize-20261006')
B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation')
I=W/'implementation-v4'
D=W/'team-regression-diagnosis-v4'
def load(p):
 rows=collections.defaultdict(list)
 for l in (p/'compile.log').read_text().splitlines():
  s=l.split()
  if s and s[0] in ('FN','SIR','EMIT','PCMAP','PCJOB','FIX'):
   rows[s[0]].append(list(map(int,s[1:])))
 rows['sir']={x[0]:x[1:] for x in rows['SIR']}
 rows['emit']={x[0]:x[1:] for x in rows['EMIT']}
 raw=(p/'native.bin').read_bytes();rows['words']=struct.unpack('<'+'I'*(len(raw)//4),raw[:len(raw)//4*4])
 return rows
def span(r,s):
 e=r['emit'].get(s)
 if e is None:return None
 skip,a,z=e[:3];words=r['words'][a-1:z-1]
 return dict(skip=skip,start=a,end=z,words=z-a,BL=sum((w&0xfc000000)==0x94000000 for w in words),B=sum((w&0xfc000000)==0x14000000 for w in words),hex=[f'{w:08x}' for w in words])
b=load(B/'observer/ports/statemate');c=load(I/'observer/ports/statemate')
calls=[]
for m in c['PCMAP']:
 ctx,f,orig,new,op,a,t,n,flags=m
 if op!=13:continue
 old=b['sir'][orig]; assert old[0]==13
 x,y=span(b,orig),span(c,new)
 calls.append(dict(ctx=ctx,clone=f,originalSir=orig,clonedSir=new,originalTarget=old[1],cloneTarget=a,args=n,baseline=x,candidate=y))
changes=[x for x in calls if x['baseline'] and x['candidate'] and (x['baseline']['BL'],x['baseline']['words'])!=(x['candidate']['BL'],x['candidate']['words'])]
res=dict(status='STATIC_DIAGNOSIS',calls=len(calls),changedSpans=len(changes),lostNoBL=sum(x['baseline']['BL']==0 and x['candidate']['BL']>0 for x in changes),gainedNoBL=sum(x['baseline']['BL']>0 and x['candidate']['BL']==0 for x in changes),baselineBL=sum(x['baseline']['BL'] for x in calls if x['baseline']),candidateBL=sum(x['candidate']['BL'] for x in calls if x['candidate']),wordDifference=sum(x['candidate']['words']-x['baseline']['words'] for x in calls if x['baseline'] and x['candidate']),callsDetail=calls)
(D/'call-comparison.json').write_text(json.dumps(res,indent=2)+'\n')
print({k:v for k,v in res.items() if k!='callsDetail'})
for x in changes[:15]:print({k:v for k,v in x.items() if k not in ('baseline','candidate')}, {k:x['baseline'][k] for k in ('skip','words','BL')},{k:x['candidate'][k] for k in ('skip','words','BL')})
fnB={x[0]:x for x in b['FN']};fnC={x[0]:x for x in c['FN']}
job={x[4]:x[1] for x in c['PCJOB'] if x[4]>0}
frames=[]
for clone,orig in job.items():
 if clone not in fnC:continue
 u,v=fnB[orig],fnC[clone]
 frames.append(dict(original=orig,clone=clone,baselineFrame=u[2],candidateFrame=v[2],baselineNSV=u[5],candidateNSV=v[5],baselineLeaf=u[6],candidateLeaf=v[6],baselineStart=u[7],candidateStart=v[7]))
def counter(field):return dict(collections.Counter(f'{x["baseline"+field]}->{x["candidate"+field]}' for x in frames))
more=dict(cloneCount=len(frames),frameTransitions=counter('Frame'),leafTransitions=counter('Leaf'),nsvTransitions=counter('NSV'),lostTailB=sum(x['baseline']['B']>0 and x['candidate']['B']==0 for x in calls if x['baseline'] and x['candidate']),gainedTailB=sum(x['baseline']['B']==0 and x['candidate']['B']>0 for x in calls if x['baseline'] and x['candidate']),frames=frames)
(D/'frame-comparison.json').write_text(json.dumps(more,indent=2)+'\n')
print({k:v for k,v in more.items() if k!='frames'})
def addr(r,f,s):
 e=r['emit'][s];a,z=e[1:3]
 out=[]
 for at in range(a,z):
  w=r['words'][at-1]
  if (w&0x7c000000)==0x14000000:
   delta=w&0x3ffffff
   if delta&(1<<25):delta-=1<<26
   out.append(dict(at=at,target=at+delta,distanceBytes=abs(delta*4),link=bool(w&(1<<31))))
 return out
edges=[]
for x in calls:
 if not x['baseline'] or not x['candidate']:continue
 old=addr(b,0,x['originalSir']);new=addr(c,0,x['clonedSir'])
 if old or new:edges.append(dict(originalSir=x['originalSir'],cloneSir=x['clonedSir'],baseline=old,candidate=new))
(D/'direct-branch-comparison.json').write_text(json.dumps(edges,indent=2)+'\n')
res2=dict(baselineBytes=(B/'observer/ports/statemate/native.bin').stat().st_size,candidateBytes=(I/'observer/ports/statemate/native.bin').stat().st_size,baselineFunctions=len(b['FN']),candidateFunctions=len(c['FN']),branchSites=len(edges),baselineDistanceSum=sum(z['distanceBytes'] for x in edges for z in x['baseline']),candidateDistanceSum=sum(z['distanceBytes'] for x in edges for z in x['candidate']),scope='Static cloned CALL spans only; distances unweighted by execution frequency. No causal performance claim.')
(D/'footprint.json').write_text(json.dumps(res2,indent=2)+'\n');print(res2)
