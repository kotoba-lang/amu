
from pathlib import Path
import json,subprocess,hashlib,os,datetime,time
r=Path('/private/tmp/amu-zebulun-vector-shape-pc-v4-20261006');pr=json.loads((r/'preregistration.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for local,h in pr['inputPins'].items():
 p=r/Path(local).name
 if p.exists():assert sha(p)==h
old=Path('/private/tmp/amu-zebulun-paired-20261005/environment/runner')
assert sha(old)=='a1b8778cf9af255f66bba3e3cad20e3baadd9653e18defe429bfa179840665ac'
assert (r/'trusted-o2-text.txt').read_text().splitlines()[2:]==(r/'prior-text.txt').read_text().splitlines()[2:]
def env():
 return {'timeUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'load':subprocess.check_output(['sysctl','-n','vm.loadavg'],text=True),'uname':subprocess.check_output(['uname','-a'],text=True),'cpu':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True)}
(r/'environment-before.json').write_text(json.dumps(env(),indent=2)+'\n')
# Exact same expected summary across historic driver, rebuilt original and sampler.
cal=[]
for arm in ['baseline','candidate']:
 for exe in [str(old),str(r/'trusted-runner-o2'),str(r/'profile-runner-o2')]:
  q=subprocess.run([exe,'raw',str(r/(arm+'.bin')),'85576','aarch64','32','1','1','16777216'],text=True,capture_output=True,timeout=45)
  name=arm+'-'+Path(exe).name
  (r/('calibration-'+name+'.stdout')).write_text(q.stdout);(r/('calibration-'+name+'.stderr')).write_text(q.stderr)
  row=json.loads(next(x for x in q.stdout.splitlines() if x.startswith('{')))
  assert q.returncode==0 and row['result']==1 and row['contextFuelConsumed']==23715
  cal.append({'arm':arm,'exe':exe,'exit':q.returncode,'result':row['result'],'fuelConsumed':row['contextFuelConsumed']})
(r/'calibration.json').write_text(json.dumps(cal,indent=2)+'\n')
rows=[];start=time.monotonic()
for ix,z in enumerate(pr['profiles']):
 assert time.monotonic()-start<420
 assert float(env()['load'].split()[1])<3
 environ=os.environ.copy();environ['PC_INTERVAL_US']=str(z['intervalUs'])
 q=subprocess.run([str(r/'profile-runner-o2'),'raw',str(r/(z['arm']+'.bin')),'85576','aarch64','32','200000','1','16777216'],text=True,capture_output=True,timeout=45,env=environ)
 name=f"profile-{ix}-{z['arm']}"
 (r/(name+'.stdout')).write_text(q.stdout);(r/(name+'.stderr')).write_text(q.stderr)
 row=json.loads(next(x for x in q.stdout.splitlines() if x.startswith('{')))
 assert q.returncode==0 and row['result']==1 and row['contextFuelConsumed']==23715
 header=next(x for x in q.stdout.splitlines() if x.startswith('PC_HEADER')).split()
 assert int(header[1])>100 and int(header[2])==0
 rows.append({'index':ix,**z,'exit':q.returncode,'captured':int(header[1]),'dropped':int(header[2]),'summary':row,'environmentAfter':env(),'stdoutSha256':sha(r/(name+'.stdout'))})
 (r/'profiles.json').write_text(json.dumps(rows,indent=2)+'\n');print('PROFILE',ix,z['arm'],header[1],flush=True)
(r/'environment-after.json').write_text(json.dumps(env(),indent=2)+'\n')
(r/'terminal.json').write_text(json.dumps({'status':'PASS_DIAGNOSTIC_CAPTURE','profiles':len(rows),'timeUTC':env()['timeUTC'],'diagnosticOnly':True,'performanceMeasured':False},indent=2)+'\n')
