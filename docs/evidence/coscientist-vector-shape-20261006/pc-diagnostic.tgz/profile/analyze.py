from pathlib import Path
import json,collections,struct,bisect,re,hashlib
D=Path(__file__).parent;W=D.parent;E=D/'remote-evidence';B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation');I=W/'implementation-v4'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ops={int(n):name for name,n in re.findall(r'\(def (OP-[A-Z0-9-]+) (\d+)\)',(I/'unity.kotoba').read_text())}
def model(arm):
 p=(B if arm=='baseline' else I)/'observer/ports/statemate';rows=collections.defaultdict(list)
 for l in (p/'compile.log').read_text().splitlines():
  s=l.split()
  if s and s[0] in ['FN','SIR','EMIT','PCMAP','PCJOB']:rows[s[0]].append(list(map(int,s[1:])))
 sir={r[0]:r[1:] for r in rows['SIR']};em=sorted((r[2],r[3],r[0],r[1]) for r in rows['EMIT'] if r[3]>r[2]);starts=[r[0] for r in em]
 fn=sorted((r[7],r[0],r[2],r[5],r[6]) for r in rows['FN']);fs=[r[0] for r in fn]
 pm={r[3]:r[2] for r in rows['PCMAP']};jobs={r[4]:r[1] for r in rows['PCJOB'] if r[4]>0}
 raw=(p/'native.bin').read_bytes();words=struct.unpack('<'+'I'*(len(raw)//4),raw[:len(raw)//4*4]);assert sha(p/'native.bin')==sha(D/(arm+'.bin'))
 def classify(pc):
  if pc<0:return {'region':'outsideGuest'}
  word=pc//4+1;k=bisect.bisect_right(starts,word)-1;j=bisect.bisect_right(fs,word)-1
  if k<0 or not(em[k][0]<=word<em[k][1]):return {'region':'unmappedGuest','relativePC':pc}
  a,z,s,skip=em[k];fstart,f,frame,nsv,leaf=fn[j];inst=words[word-1];op,*args=sir[s]
  fuel=inst in [0xf1000508,0xf1000610,0xf94004f0,0xf90004f0,0xf90004ff] or op==18
  # Broad ISA classification, not cycle cost; conditional branches include guard/fuel/control.
  cls='other'
  if inst&0x7c000000==0x14000000:cls='BL' if inst&0x80000000 else 'B'
  elif inst&0xff000010==0x54000000:cls='conditionalBranch'
  elif inst&0x7e000000==0x34000000:cls='compareBranch'
  elif inst&0x3a000000==0x28000000:cls='loadStorePair'
  elif inst&0x3b000000 in [0x39000000,0x38000000]:cls='loadStore'
  return {'region':'fuelInstruction' if fuel else ops[op], 'sir':s,'originalSir':pm.get(s,s),'function':f,'originalFunction':jobs.get(f,f),'frame':frame,'nsv':nsv,'leaf':leaf,'relativePC':pc,'instruction':f'{inst:08x}','machineClass':cls,'sirArgs':args,'spanStart':a,'spanEnd':z,'skip':skip}
 return classify
models={a:model(a) for a in ['baseline','candidate']};summary=[];allrows=[]
profiles=json.loads((E/'profiles.json').read_text());assert len(profiles)==8
for p in profiles:
 name=f"profile-{p['index']}-{p['arm']}";src=E/(name+'.stdout');assert sha(src)==p['stdoutSha256']
 lines=src.read_text().splitlines();h=next(x for x in lines if x.startswith('PC_HEADER')).split();samples=[l.split() for l in lines if l.startswith('PC ')]
 assert len(samples)==int(h[1])==p['captured'] and p['dropped']==0
 assert p['summary']['result']==1 and p['summary']['contextFuelConsumed']==23715
 mapped=[{'index':int(x[1]),'absolutePC':x[3],**models[p['arm']](int(x[2]))} for x in samples]
 (D/(name+'.mapped.json')).write_text(json.dumps(mapped,indent=2)+'\n')
 counts=collections.Counter(x['region'] for x in mapped);pc=collections.Counter((x.get('relativePC'),x.get('originalSir'),x.get('instruction'),x.get('region')) for x in mapped if x['region']!='outsideGuest')
 summary.append({'index':p['index'],'arm':p['arm'],'intervalUs':p['intervalUs'],'captured':len(mapped),'regions':dict(counts),'proportions':{k:v/len(mapped) for k,v in counts.items()},'topPCs':[dict(relativePC=k[0],originalSir=k[1],instruction=k[2],region=k[3],count=v) for k,v in pc.most_common(20)]})
 allrows.extend({'arm':p['arm'],**x} for x in mapped)
aggregate={}
for arm in ['baseline','candidate']:
 rows=[x for x in allrows if x['arm']==arm];counts=collections.Counter(x['region'] for x in rows);n=len(rows)
 functions=collections.Counter(x.get('originalFunction') for x in rows if x['region']!='outsideGuest');machine=collections.Counter(x.get('machineClass') for x in rows)
 aggregate[arm]={'captured':n,'regions':dict(counts),'proportions':{k:v/n for k,v in counts.items()},'topOriginalFunctions':functions.most_common(20),'machineClasses':dict(machine),'unmapped':counts['unmappedGuest']}
report={'status':'PASS_DIAGNOSTIC_CAPTURE_AND_PC_BINDING','diagnosticOnly':True,'performanceMeasured':False,'profiles':summary,'aggregate':aggregate,'trust':'Exact raw native hash -> frozen observer EMIT+FN+PCMAP -> sampledPC mapping. POSIX SIGPROF gives interrupted PC, not retired-instruction count/cycles or cache miss counter. No timing estimate derived.'}
(D/'profile-analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(aggregate,indent=2))
