from pathlib import Path
import json,hashlib,shutil
D=Path(__file__).parent;W=D.parent;T=W/'team-timing-v4/timing-package/statemate';src=Path('/private/tmp/amu-embench-compare-20261004/runner.c')
shutil.copy2(src,D/'trusted-runner.c')
for x,y in [('baseline-native.bin','baseline.bin'),('candidate/native.bin','candidate.bin')]:shutil.copy2(T/x,D/y)
s=src.read_text();pos=s.index('int main(int argc')
extra=r'''
#include <sys/time.h>
#include <sys/ucontext.h>
#define PC_CAP 65536
static uintptr_t sampled_pc[PC_CAP];
static volatile sig_atomic_t pc_n,pc_dropped;
static struct sigaction pc_old_action;
static struct itimerval pc_old_timer;
static void pc_capture(int signal_number, siginfo_t *info, void *uc_void) {
  (void)signal_number;(void)info;
  ucontext_t *uc=(ucontext_t*)uc_void;
  uintptr_t pc=(uintptr_t)uc->uc_mcontext->__ss.__pc;
  sig_atomic_t n=pc_n;
  if(n<PC_CAP){sampled_pc[n]=pc;pc_n=n+1;}else pc_dropped++;
}
static void pc_begin(void) {
  const char *text=getenv("PC_INTERVAL_US");
  int interval=text?atoi(text):997;
  if(interval<500 || interval>2000)exit(2);
  struct sigaction action;memset(&action,0,sizeof action);
  action.sa_sigaction=pc_capture;action.sa_flags=SA_SIGINFO;
  sigemptyset(&action.sa_mask);
  if(getitimer(ITIMER_PROF,&pc_old_timer)!=0)fail("getitimer");
  if(pc_old_timer.it_value.tv_sec || pc_old_timer.it_value.tv_usec || pc_old_timer.it_interval.tv_sec || pc_old_timer.it_interval.tv_usec){fprintf(stderr,"preexisting profiler timer rejected\n");exit(2);}
  if(sigaction(SIGPROF,NULL,&pc_old_action)!=0)fail("sigaction read");
  if(pc_old_action.sa_handler!=SIG_DFL && pc_old_action.sa_handler!=SIG_IGN){fprintf(stderr,"preexisting profiler handler rejected\n");exit(2);}
  if(sigaction(SIGPROF,&action,NULL)!=0)fail("sigaction install");
  struct itimerval timer;memset(&timer,0,sizeof timer);timer.it_interval.tv_usec=interval;timer.it_value.tv_usec=interval;
  if(setitimer(ITIMER_PROF,&timer,NULL)!=0)fail("setitimer");
}
static void pc_end(void *memory,size_t artifact_bytes) {
  sigset_t set,old;sigemptyset(&set);sigaddset(&set,SIGPROF);
  if(sigprocmask(SIG_BLOCK,&set,&old)!=0)fail("sigprocmask");
  struct itimerval zero;memset(&zero,0,sizeof zero);
  if(setitimer(ITIMER_PROF,&zero,NULL)!=0)fail("disable profiler");
  /* SIGPROF is only used here; drain a pending final tick before restoring. */
  sigset_t pending;sigpending(&pending);
  if(sigismember(&pending,SIGPROF)){int signum;sigwait(&set,&signum);}
  if(sigaction(SIGPROF,&pc_old_action,NULL)!=0)fail("restore sigaction");
  if(setitimer(ITIMER_PROF,&pc_old_timer,NULL)!=0)fail("restore timer");
  if(sigprocmask(SIG_SETMASK,&old,NULL)!=0)fail("restore signalmask");
  uintptr_t base=(uintptr_t)memory;
  printf("PC_HEADER %d %d %zu\n",(int)pc_n,(int)pc_dropped,artifact_bytes);
  for(sig_atomic_t i=0;i<pc_n;i++){
    uintptr_t pc=sampled_pc[i];
    printf("PC %d %lld %llx\n",(int)i,(long long)(pc>=base && pc<base+artifact_bytes?pc-base:-1LL),(unsigned long long)pc);
  }
}
'''
s=s[:pos]+extra+s[pos:]
s=s.replace('  started = nanoseconds();','  pc_begin();\n  started = nanoseconds();')
s=s.replace('  uint64_t context_fuel_after = context->fuel;','  pc_end(memory,artifact_bytes);\n  uint64_t context_fuel_after = context->fuel;')
(D/'profile-runner.c').write_text(s)
m=json.loads((T/'candidate/manifest.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(D/'baseline.bin')==m['baselineNativeSha256'] and sha(D/'candidate.bin')==m['nativeSha256']
pr=dict(status='PREREGISTERED_BEFORE_BUILD_OR_PROFILE',purpose='diagnostic sampled-PC only; no performance score/statistical pooling',baselineSeed='761856bb455de5d36021e177be8f3a0bbf65772dd66cbdf29c8e114f8cbe3d93',candidateSeed='924b03c26998aed4d2a6b15a720cea14866fa3c70d803f56e52de6efdd0a35eb',host='zebulun@100.66.28.79',remoteRoot='/private/tmp/amu-zebulun-vector-shape-pc-v4-20261006',n=32,calls=200000,warmup=1,fuel=16777216,offset=85576,expectedResult=1,expectedFuelConsumed=23715,profiles=[dict(arm=a,intervalUs=i) for i in [997,1009] for a in ['baseline','candidate','candidate','baseline']],limits=dict(samplesPerProcess=65536,profileProcesses=8,perProcessSeconds=45,wholeJobSeconds=420),rawFormat='PC_HEADER captured dropped artifactBytes; PC index relativeByteOffset(-1 outside) absolutePC; unchanged runner summary JSON',trust='Same trusted runner C context/reset/ABI retained, signal sampling added only around call loop. SIGPROF old handler/timer saved, existing nondefault rejected, restored and pending tick drained. No loader trap handlers altered.',inputPins={str(p):sha(p) for p in [D/'trusted-runner.c',D/'profile-runner.c',D/'baseline.bin',D/'candidate.bin',T/'candidate/manifest.json']},calibration='unsampled single-call runner exact result/fuel plus sample driver single-call (possibly zero PCs); tiny existing native identity negative PC sanity; no workload changes',analysis='Map guest relative PCs to exact frozen FN, EMIT/SIR, classify FUEL/RT200/reads/writes/CALL/machine branches/ALU. Preserve outside guest PCs separately. Proportions across schedules; no hotness inferred from static totals.')
(D/'preregistration.json').write_text(json.dumps(pr,indent=2)+'\n')
print('PREREG',sha(D/'preregistration.json'),sha(src))
