from pathlib import Path
import json,subprocess,hashlib
D=Path(__file__).parent;remote='/private/tmp/amu-zebulun-vector-placement-v4-20261006';host='zebulun@100.66.28.79';key='/Users/junkawasaki/.ssh/murakumo';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
go=json.loads((D/'root-GO.json').read_text());assert go['status'].startswith('GO ') and go['preflightSha256']==sha(D/'preflight.json') and go['preregistrationSha256']==sha(D/'preregistration.json') and go['expectedProcesses']==28
pr=json.loads((D/'preregistration.json').read_text());assert len(pr['schedule'])==28
for p,h in json.loads((D/'preflight-pins.json').read_text()).items():assert sha(D/p)==h
code=r'''
from pathlib import Path
import json,subprocess,hashlib,time,resource,os,datetime
from darwin_cpu_idle import snapshot,interval,background_activity
r=Path(REMOTE);pr=json.loads((r/'preregistration.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in pr['pins'].items():assert sha(r/Path(p).name)==h
assert not (r/'diagnostic-results.json').exists(),'no campaign overwrite/rerun'
assert sha(r/'darwin_cpu_idle.py')=='1060a6cf91e3ded30bde9bd8e861d1d59b79c5a679956c4dc9066f5f2955a7d3'
assert json.loads((r/'calibration-terminal.json').read_text())['comparisons']==14
report={'status':'running-controlled-placement-diagnostic','rootGO':__ROOT_GO__,'rows':[],'performanceQualification':False,'officialEmbenchScore':False,'candidateAdopted':False}
def save():(r/'diagnostic-results.json').write_text(json.dumps(report,indent=2)+'\n')
def load():return subprocess.check_output(['sysctl','-n','vm.loadavg'],text=True)
save();start=time.monotonic()
for ix,z in enumerate(pr['schedule']):
 assert time.monotonic()-start<1260
 beforeLoad=load();usage=resource.getrusage(resource.RUSAGE_CHILDREN);before=snapshot()
 env=dict(os.environ,CODE_BASE_SHIFT=str(z['shift']))
 q=subprocess.run([str(r/'placement-runner'),'raw',str(r/(z['arm']+'.bin')),'85576','aarch64','32','200000','1','16777216'],text=True,capture_output=True,timeout=45,env=env)
 after=snapshot();used=resource.getrusage(resource.RUSAGE_CHILDREN);ns=round(((used.ru_utime+used.ru_stime)-(usage.ru_utime+usage.ru_stime))*1e9);afterLoad=load()
 name=f"diagnostic-{ix}-{z['arm']}-{z['shift']}";(r/(name+'.stdout')).write_text(q.stdout);(r/(name+'.stderr')).write_text(q.stderr)
 row={'index':ix,**z,'exit':q.returncode,'loadBefore':beforeLoad,'loadAfter':afterLoad,'cpuActivityEnvelope':background_activity(interval(before,after),ns,os.cpu_count()),'stdoutSHA256':sha(r/(name+'.stdout'))}
 if q.returncode==0:
  v=json.loads(next(x for x in q.stdout.splitlines() if x.startswith('{')));p=list(map(int,next(x for x in q.stdout.splitlines() if x.startswith('PLACEMENT')).split()[1:]));row.update(summary=v,placement=p)
  assert v['calls']==200000 and v['result']==1 and v['contextFuelConsumed']==23715
  assert p[0]==z['shift'] and p[1]%16384==z['shift'] and p[2]+z['shift']<=p[3]
 row['lowIdleFlag']=row['cpuActivityEnvelope']['estimatedBackgroundIdlePercent']<95
 row['highLoadFlag']=float(beforeLoad.split()[1])>=3 or float(afterLoad.split()[1])>=3
 report['rows'].append(row);save();print('DIAGNOSTIC',ix,z['arm'],z['shift'],'exit',q.returncode,'flags',row['lowIdleFlag'],row['highLoadFlag'],flush=True)
 if q.returncode!=0:raise RuntimeError('native diagnostic error retained; no retry')
report['status']='terminal-controlled-placement-diagnostic-all28';report['endedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
'''.replace('REMOTE',repr(remote)).replace('__ROOT_GO__',repr(go))
(D/'remote-diagnostic.py').write_text(code)
q=subprocess.run(['ssh','-i',key,'-o','BatchMode=yes',host,'cd '+remote+' && python3 -'],input=code,text=True);(D/'diagnostic-exit.json').write_text(json.dumps({'exit':q.returncode})+'\n');raise SystemExit(q.returncode)
