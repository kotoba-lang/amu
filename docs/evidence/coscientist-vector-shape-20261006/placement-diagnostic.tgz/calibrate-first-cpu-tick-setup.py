from pathlib import Path
import subprocess,json
D=Path(__file__).parent;remote='/private/tmp/amu-zebulun-vector-placement-v4-20261006';host='zebulun@100.66.28.79';key='/Users/junkawasaki/.ssh/murakumo'
code=r'''
from pathlib import Path
import subprocess,json,os,hashlib,resource
r=Path(REMOTE);pr=json.loads((r/'preregistration.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in pr['pins'].items():assert sha(r/Path(p).name)==h
assert sha(r/'darwin_cpu_idle.py')=='1060a6cf91e3ded30bde9bd8e861d1d59b79c5a679956c4dc9066f5f2955a7d3'
for name in ['trusted','placement']:
 q=subprocess.run(['clang','-O2','-std=c11',str(r/(name+'-runner.c')),'-o',str(r/(name+'-runner')),'-ldl'],text=True,capture_output=True)
 (r/(name+'-build.stdout')).write_text(q.stdout);(r/(name+'-build.stderr')).write_text(q.stderr);(r/(name+'-build.exit')).write_text(str(q.returncode)+'\n');assert q.returncode==0
old=Path('/private/tmp/amu-zebulun-paired-20261005/environment/runner');a=subprocess.check_output(['otool','-t',str(r/'trusted-runner')],text=True);b=subprocess.check_output(['otool','-t',str(old)],text=True)
(r/'trusted-text.txt').write_text(a);(r/'prior-text.txt').write_text(b);assert a.splitlines()[2:]==b.splitlines()[2:]
from darwin_cpu_idle import snapshot,interval,background_activity
rows=[]
for shift in pr['shiftsBytes']:
 for arm in pr['arms']:
  env=dict(os.environ,CODE_BASE_SHIFT=str(shift));usage=resource.getrusage(resource.RUSAGE_CHILDREN);before=snapshot()
  q=subprocess.run([str(r/'placement-runner'),'raw',str(r/(arm+'.bin')),'85576','aarch64','32','1','1','16777216'],text=True,capture_output=True,timeout=45,env=env)
  after=snapshot();used=resource.getrusage(resource.RUSAGE_CHILDREN);ns=round(((used.ru_utime+used.ru_stime)-(usage.ru_utime+usage.ru_stime))*1e9)
  name=f'calibration-{shift}-{arm}';(r/(name+'.stdout')).write_text(q.stdout);(r/(name+'.stderr')).write_text(q.stderr)
  row=json.loads(next(x for x in q.stdout.splitlines() if x.startswith('{')));place=next(x for x in q.stdout.splitlines() if x.startswith('PLACEMENT')).split()
  assert q.returncode==0 and row['result']==1 and row['contextFuelConsumed']==23715
  assert int(place[1])==shift and int(place[2])%os.sysconf('SC_PAGESIZE')==shift and int(place[3])+shift<=int(place[4])
  rows.append({'arm':arm,'shift':shift,'exit':q.returncode,'result':row['result'],'fuelConsumed':row['contextFuelConsumed'],'placement':list(map(int,place[1:])),'cpuActivityEnvelope':background_activity(interval(before,after),ns,os.cpu_count()),'stdoutSHA256':sha(r/(name+'.stdout'))})
  (r/'calibration.json').write_text(json.dumps(rows,indent=2)+'\n')
(r/'calibration-terminal.json').write_text(json.dumps({'status':'PASS_CALIBRATION_ONLY_AWAIT_ROOT_GO','comparisons':len(rows),'elapsedDiagnosticStarted':False,'trustedRunnerTextExact':True},indent=2)+'\n')
print('CALIBRATION PASS',len(rows),'no elapsed diagnostic started')
'''.replace('REMOTE',repr(remote))
(D/'remote-calibrate.py').write_text(code);q=subprocess.run(['ssh','-i',key,'-o','BatchMode=yes',host,'cd '+remote+' && python3 -'],input=code,text=True);(D/'calibration-exit.json').write_text(json.dumps({'exit':q.returncode})+'\n');raise SystemExit(q.returncode)
