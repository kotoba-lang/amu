from pathlib import Path
import json,hashlib
D=Path(__file__).parent;E=D/'remote-evidence';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pr=json.loads((D/'preregistration.json').read_text())
for p,h in pr['pins'].items():assert sha(Path(p))==h and sha(E/Path(p).name)==h
rows=json.loads((E/'calibration.json').read_text());assert len(rows)==14 and len({(x['arm'],x['shift']) for x in rows})==14
for x in rows:
 assert x['exit']==0 and x['result']==1 and x['fuelConsumed']==23715
 p=E/f"calibration-{x['shift']}-{x['arm']}.stdout";assert sha(p)==x['stdoutSHA256'];raw=p.read_text();z=json.loads(next(l for l in raw.splitlines() if l.startswith('{')));assert z['calls']==1 and z['warmupCalls']==1 and z['result']==1 and z['contextFuelConsumed']==23715
 shift,base,bytes,mapped=x['placement'];assert shift==x['shift'] and base%16384==shift and bytes+shift<=mapped
assert (E/'trusted-text.txt').read_text().splitlines()[2:]==(E/'prior-text.txt').read_text().splitlines()[2:]
assert sha(D/'darwin_cpu_idle.py')==sha(E/'darwin_cpu_idle.py')=='1060a6cf91e3ded30bde9bd8e861d1d59b79c5a679956c4dc9066f5f2955a7d3'
plan={'status':'BEFORE_ELAPSED_DIAGNOSTIC_ANALYSIS_PLAN','classification':'Only placement sensitivity frontier; no official score or adoption','effectRule':'Report each arm/base-shift elapsed per fixed-call invocation by forward/reverse order. A >=10% effect in the same direction relative to shift0 in both orders with both compared idle>=95% supports placement sensitivity; otherwise uncertainty. This is a diagnostic criterion, not statistical qualification.','allRows':'Keep all28registered attempts, low-idle/load flags and any failure. No replacement or acceptance seeking rerun; no old timing statistics pooled.','bounds':'Each call charge/result unchanged, native byte hashes/length unchanged. ASLR highaddress/pagebits are not pinned; actual reported codebase address and shift within alignment recorded. Any sensitivity may include ASLR/page-placement confounding; not proof of a particular cache/predictor mechanism.'}
(D/'analysis-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
files=[p for p in sorted(D.rglob('*')) if p.is_file() and p.name not in ['preflight.json','preflight-pins.json']]
pins={str(p.relative_to(D)):sha(p) for p in files};(D/'preflight-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
r={'status':'PASS_STATIC_AND14_CALIBRATION_AWAIT_ROOT_GO','elapsedDiagnosticStarted':False,'registeredDiagnosticProcesses':28,'calibrationPairs':14,'nativeActualCalls':14,'firstCalibrationGuestReusedWithoutRerun':True,'resultEach':1,'fuelConsumedEach':23715,'RXBoundsEach':True,'nativeSHA256':{a:sha(D/(a+'.bin')) for a in pr['arms']},'preregistrationSHA256':sha(D/'preregistration.json'),'baseContractSHA256':sha(D/'base-contract.json'),'analysisPlanSHA256':sha(D/'analysis-plan.json'),'preflightPinsSHA256':sha(D/'preflight-pins.json'),'preflightPinCount':len(pins),'cpuHelperSHA256':sha(D/'darwin_cpu_idle.py'),'trustedRunnerTextExact':True,'calibrationCPUInterval':'unavailable for one-call short intervals; first ValueError preserved, no native failure/no guest rerun. Long diagnostics retain proper CPUtick+rusage envelope.','productAdoption':False,'officialEmbenchScore':False}
(D/'preflight.json').write_text(json.dumps(r,indent=2)+'\n');print('PREFLIGHT',sha(D/'preflight.json'),len(pins))
