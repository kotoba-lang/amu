from pathlib import Path
import json,hashlib
D=Path(__file__).parent;E=D/'diagnostic-evidence';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((E/'diagnostic-results.json').read_text());pr=json.loads((D/'preregistration.json').read_text());assert r['status']=='terminal-controlled-placement-diagnostic-all28' and len(r['rows'])==28
rows=r['rows'];index={}
for ix,(x,z) in enumerate(zip(rows,pr['schedule'])):
 assert x['index']==ix and all(x[k]==z[k] for k in z)
 assert x['exit']==0 and x['summary']['result']==1 and x['summary']['contextFuelConsumed']==23715 and x['summary']['calls']==200000
 p=E/f"diagnostic-{ix}-{x['arm']}-{x['shift']}.stdout";assert sha(p)==x['stdoutSHA256'];v=json.loads(next(y for y in p.read_text().splitlines() if y.startswith('{')));assert v==x['summary']
 assert x['placement'][0]==x['shift'] and x['placement'][1]%16384==x['shift'] and x['placement'][2]+x['shift']<=x['placement'][3]
 index[x['arm'],x['order'],x['shift']]=x
summary=[]
for arm in pr['arms']:
 for s in pr['shiftsBytes']:
  item={'arm':arm,'shift':s,'orders':{}}
  for order in ['forward','reverse']:
   x=index[arm,order,s];zero=index[arm,order,0];ratio=x['summary']['elapsedNanoseconds']/zero['summary']['elapsedNanoseconds']
   item['orders'][order]={'elapsedNanoseconds':x['summary']['elapsedNanoseconds'],'relativeToSameOrderShift0':ratio,'actualCodeBase':x['placement'][1],'idlePercent':x['cpuActivityEnvelope']['estimatedBackgroundIdlePercent'],'lowIdleFlag':x['lowIdleFlag'],'highLoadFlag':x['highLoadFlag'],'zeroComparisonLowIdleFlag':zero['lowIdleFlag']}
  z=list(item['orders'].values());item['supportedPlacementSensitivity']=s!=0 and all(not(x['lowIdleFlag'] or x['highLoadFlag'] or x['zeroComparisonLowIdleFlag']) for x in z) and (all(x['relativeToSameOrderShift0']>=1.10 for x in z) or all(x['relativeToSameOrderShift0']<=1/1.10 for x in z))
  summary.append(item)
report={'status':'PASS_DIAGNOSTIC_RAW_VALIDATION','diagnosticOnly':True,'officialEmbenchScore':False,'performanceQualification':False,'candidateReadoption':False,'rows':len(rows),'lowIdleFlagRows':[x['index'] for x in rows if x['lowIdleFlag']],'highLoadFlagRows':[x['index'] for x in rows if x['highLoadFlag']],'supportedSensitivity':[{'arm':x['arm'],'shift':x['shift']} for x in summary if x['supportedPlacementSensitivity']],'comparisonTable':summary,'limitations':['Two fixed order observations per arm/offset are a diagnostic frontier, not stable repeated benchmark qualification.', 'All28raw attempts kept and no low-idle rows discarded/replaced. Predeclared criterion requires bothshift0andcomparisonrows idle>=95% and matching>=10%effect direction across bothorders.', 'Actual ASLR highaddress/pagebits differ betweenprocesses; shifts control low14bitswithinmapping, not sharedvirtualpage. Any sensitivity does not identify a cache/predictor cause.', 'V4 remains rejected by previous independently qualified full19campaign. This diagnostic cannot authorize adoption or a new source candidate.'], 'rawResultsSHA256':sha(E/'diagnostic-results.json'),'preregistrationSHA256':sha(D/'preregistration.json'),'analysisPlanSHA256':sha(D/'analysis-plan.json')}
(D/'diagnostic-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print('REPORT',report['supportedSensitivity'],'flags',report['lowIdleFlagRows'])
for x in summary:print(x['arm'],x['shift'],[round(y['relativeToSameOrderShift0'],4) for y in x['orders'].values()])
