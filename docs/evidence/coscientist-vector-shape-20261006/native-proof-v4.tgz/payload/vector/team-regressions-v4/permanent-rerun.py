from pathlib import Path
import subprocess,json
D=Path(__file__).resolve().parent;p=subprocess.run(['python3',str(D/'permanent.py')],capture_output=True,text=True);(D/'permanent-rerun.stdout').write_text(p.stdout);(D/'permanent-rerun.stderr').write_text(p.stderr);(D/'permanent-rerun.status.json').write_text(json.dumps({'exit':p.returncode,'setupFailurePreserved':'setup-first-missing-vector-helper','oracleChanged':False}));print(p.stdout[-1000:],p.stderr[-1000:]);assert p.returncode==0
