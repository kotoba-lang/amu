from pathlib import Path
import subprocess,json
D=Path(__file__).resolve().parent;W=D.parent;I=W/'implementation-v4';S=W/'team-adoption-gates-v4/source'
rows=[]
for label,argv in [('readonly',['python3',str(S/'scripts/seed/a64gen_stable_vector_fixtures.py'),'--seed',str(I/'seed-4.bin'),'--loader',str(I/'kexe-loader'),'--out',str(D/'readonly')]),('scalar',['python3',str(S/'scripts/seed/a64gen_scalar_dag_fixtures.py'),'--seed',str(I/'seed-4.bin'),'--loader',str(I/'kexe-loader'),'--out',str(D/'scalar')]),('permanent',['python3',str(D/'permanent.py')])]:
 p=subprocess.run(argv,capture_output=True,text=True);(D/(label+'.stdout')).write_text(p.stdout);(D/(label+'.stderr')).write_text(p.stderr);r={'label':label,'status':p.returncode,'argv':argv};rows.append(r);(D/'execution-status.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,p.returncode,p.stdout[-1000:],p.stderr[-1000:],flush=True);assert p.returncode==0
