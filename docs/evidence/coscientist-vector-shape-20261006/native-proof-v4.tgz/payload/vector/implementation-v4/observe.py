from pathlib import Path
import subprocess,os,re,json,hashlib
W=Path(__file__).resolve().parent;O=W/'observer';O.mkdir(exist_ok=True);R=Path('/Users/junkawasaki/github/wt/amu-seed17');I=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def out(label,fields):
 s='"\\n"'
 for f in reversed(fields):s=f'(string-concat (string-from-i64 {f}) (string-concat " " {s}))'
 return f'(io-out (string-concat "{label} " {s}))'
def census(prefix):
 return f'''(defn- ob-{prefix.lower()} [M :vector-i64 i :i64] :i64
 (if (>= i (vector-at M MM-SIR-N)) 0 (let [printed {out(prefix,['i','(gn-op M i)','(gn-sir M i IF-A)','(gn-sir M i IF-B)','(gn-sir M i IF-C)'])}] (ob-{prefix.lower()} M (inc i)))))
'''
helpers=census('ORIGINALSIR')+census('SIR')+'''(defn- ob-meta-fields [M :vector-i64 f :i64 k :i64] :i64
 (if (= k MM-FN-W) 0 (let [printed '''+out('META',['f','k','(gn-fnf M f k)'])+'''] (ob-meta-fields M f (inc k)))))
(defn- ob-meta [M :vector-i64 f :i64] :i64
 (if (>= f (vector-at M MM-FN-N)) 0 (let [printed (ob-meta-fields M f 0)] (ob-meta M (inc f)))))
(defn- ob-jobs [J :vector-i64 j :i64] :i64
 (if (> j (vector-at J 0)) 0 (let [printed '''+out('PCJOB',['j','(vector-at J (+ 16 (* 4 j)))','(vector-at J (+ 17 (* 4 j)))','(vector-at J (+ 18 (* 4 j)))','(vector-at J (+ 19 (* 4 j)))'])+'''] (ob-jobs J (inc j)))))
(defn- ob-facts [D :vector-i64 j :i64] :i64
 (if (> j (vector-at D 0)) 0 (let [printed '''+out('PCFACT',['(vector-at D (+ 16 (* 5 j)))','(vector-at D (+ 17 (* 5 j)))','(vector-at D (+ 18 (* 5 j)))','(vector-at D (+ 19 (* 5 j)))','(vector-at D (+ 20 (* 5 j)))'])+'''] (ob-facts D (inc j)))))
'''
helpers+='(defn- ob-fix [M :vector-i64 j :i64] :i64\n (if (>= j (vector-at M MM-FIX-N)) 0 (let [b (+ MM-FIX-BASE (* j MM-FIX-W)) printed '+out('FIX',['j','(vector-at M (+ b XF-AT))','(vector-at M (+ b XF-KIND))','(vector-at M (+ b XF-TARGET))','(vector-at M (+ b XF-AUX))'])+'] (ob-fix M (inc j)))))\n'
g=(W/'41-a64gen-prototype.kotoba').read_text();g=g.replace('(defn- gn-run-plan [',helpers+'\n(defn- gn-run-plan [')
g=g.replace('MR (pc-restore M0) Safe','MR (pc-restore M0) beforeSir (ob-originalsir MR 1) beforeMeta (ob-meta MR 1) Safe')
g=g.replace('Origin (vector-at MP MM-R0)','Origin (vector-at MP MM-R0) afterSir (ob-sir MP 1) afterMeta (ob-meta MP 1)')
g=g.replace('(< (vector-at j3 7) MM-LABEL-CAP))]','(< (vector-at j3 7) MM-LABEL-CAP))\n        planPrinted '+out('PCPLAN',['(if fit 1 0)','(vector-at M MM-FN-N)','(vector-at M MM-SIR-N)','(vector-at M MM-LABEL-N)','(vector-at j3 5)','(vector-at j3 6)','(vector-at j3 7)','(vector-at D 0)','(vector-at j3 4)','(vector-at D 4)'])+' jobsPrinted (ob-jobs j3 1) factsPrinted (ob-facts D 1)]')
g=g.replace('sf (mem-set Safe pos flags)]','sf (mem-set Safe pos flags) mapped '+out('PCMAP',['ctx','clone','i','pos','op','aa','bb','c','flags'])+']')
# Log physical layout metadata at the existing final ordinary-FN allocation point.
needle='(gn-put (+ MM-FN-BASE (* f MM-FN-W) FF-CODE) (vector-at M2 MM-CODE-N))'
assert g.count(needle)==1
# Safe binding around gn-op-fn2 entire function rather than altering M mutation.
start=g.index('(defn- gn-op-fn2 [');end=g.index('(defn- gn-op-ret [',start) if '(defn- gn-op-ret [' in g[start:] else -1
# FN was printed in earlier observer at exact M2/F/ns/dp/leaf let point; add after M2 binding chain end.
needle='leaf (gn-g M2 gn-f-leaf)]'
assert g.count(needle)==1
g=g.replace(needle,'leaf (gn-g M2 gn-f-leaf) printed '+out('FN',['f','i','F','ns','dp','(gn-g M2 gn-f-nsv)','leaf','(vector-at M2 MM-CODE-N)'])+']')
# Emit spans each original/cloned SIR event, including annotation flags and consumed instructions.
needle='M1 (gn-ins (gn-gs mb pc-flag (vector-at Safe i)) i (gn-op M i))\n          k (gn-g M1 gn-f-skip)]'
assert g.count(needle)==1
g=g.replace(needle,'start (vector-at mb MM-CODE-N) M1 (gn-ins (gn-gs mb pc-flag (vector-at Safe i)) i (gn-op M i))\n          k (gn-g M1 gn-f-skip) printed '+out('EMIT',['i','k','start','(vector-at M1 MM-CODE-N)','(vector-at Safe i)'])+']')
g=g.replace('hit (= (gn-g M3 pc-budget-hit) 1)', 'fixPrinted (ob-fix M3 0) hit (= (gn-g M3 pc-budget-hit) 1)')
# Exact HCHK event fields plus start/end emitted word coordinates.
a=g.index('(defn- gn-hchk [');b=g.index(';; after gn-hchk',a);old=g[a:b];sig=old[:old.index('\n')];body=old[old.index('\n')+1:].rstrip();assert body.endswith(')');body=body[:-1]
g=g[:a]+sig+'\n (let [start (vector-at M MM-CODE-N) result '+body+' printed '+out('HCHK',['rv','used','base','(gn-g M pc-flag)','start','(vector-at result MM-CODE-N)'])+'] result))\n'+g[b:]
layout=(W/'42-layout.kotoba').read_text()
lhelpers='(defn- ob-literals [M :vector-i64 j :i64] :i64\n (if (>= j (vector-at M MM-LIT-N)) 0 (let [b (+ MM-LIT-BASE (* j MM-LIT-W)) printed '+out('LIT',['j','(vector-at M (+ b LF-B))','(vector-at M (+ b LF-LEN))','(vector-at M (+ b LF-POOL))','(vector-at M (+ b LF-TOK))'])+'] (ob-literals M (inc j)))))\n'
lhelpers+='(defn- ob-litbytes [M :vector-i64 j :i64] :i64\n (if (>= j (vector-at M MM-LITB-N)) 0 (let [printed '+out('LITB',['j','(vector-at M (+ MM-LITB-BASE j))'])+'] (ob-litbytes M (inc j)))))\n'
a=layout.index('(defn- ly-run [');layout=layout[:a]+lhelpers+layout[a:]
old='(let [M1 (ly-pool M)]\n    (if (= (ly-failed M1) 0) (ly-run2 M1) M1)))'
new='(let [M1 (ly-pool M) result (if (= (ly-failed M1) 0) (ly-run2 M1) M1)\n        envPrinted '+out('LITENV',['(vector-at result MM-POOL-OFF)','(vector-at result MM-CODE-BYTES)','(vector-at result MM-CODE-N)','(vector-at result MM-LIT-N)','(vector-at result MM-LITB-N)'])+' literalsPrinted (ob-literals result 1) bytesPrinted (ob-litbytes result 0)] result))'
assert layout.count(old)==1;layout=layout.replace(old,new);(O/'42.kotoba').write_text(layout)
(O/'41.kotoba').write_text(g)
parts=[x.strip()for x in (I/'source-snapshot/seed/MANIFEST').read_text().splitlines()if x.strip()and not x.lstrip().startswith('#')]
(O/'unity.kotoba').write_text('\n'.join(g if p=='seed/41-a64gen.kotoba'else layout if p=='seed/42-layout.kotoba'else (I/'source-snapshot'/p).read_text()for p in parts))
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for label,args in [('compile',['compile',str(O/'unity.kotoba'),'--target','aarch64-macos','--output',str(O/'image.kseed')]),('extract',['extract-native',str(O/'image.kseed'),'--symbol','main','--output',str(O/'seed.bin')])]:
 q=subprocess.run([str(W/'kexe-loader'),str(W/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(O/(label+'.stdout')).write_text(q.stdout);(O/(label+'.stderr')).write_text(q.stderr);(O/(label+'.status.json')).write_text(json.dumps({'exit':q.returncode}));assert q.returncode==0,(label,q.stdout[-1000:],q.stderr[-1000:])
 if label=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1]);(O/'seed.offset').write_text(str(off)+'\n')
rows=[];base=json.loads((W/'ports-build.json').read_text())['entries'];matrix=json.loads((R/'bench/embench/comparison-matrix.json').read_text())
for e in matrix['entries']:
 d=O/'ports'/e['workload'];d.mkdir(parents=True,exist_ok=True)
 for label,args in [('compile',['compile',str(R/e['source']),'--target','aarch64-macos','--output',str(d/'image.kseed')]),('extract',['extract-native',str(d/'image.kseed'),'--symbol',e['symbol'],'--output',str(d/'native.bin')])]:
  q=subprocess.run([str(W/'kexe-loader'),str(O/'seed.bin'),str(off),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'.log')).write_text(q.stdout+q.stderr);(d/(label+'.status.json')).write_text(json.dumps({'exit':q.returncode}));assert q.returncode==0,(e['workload'],label,q.stdout[-1000:],q.stderr[-1000:])
  if label=='extract':offset=int(re.search(r':offset (\d+)',q.stdout)[1])
 old=next(x for x in base if x['workload']==e['workload']);assert sha(d/'native.bin')==old['nativeSha256'] and offset==old['offset'],(e['workload'],'observer changed output')
 rows.append({'workload':e['workload'],'sha256':sha(d/'native.bin'),'offset':offset});print('PASS exact observer',e['workload'],flush=True)
(O/'report.json').write_text(json.dumps({'status':'PASS byte+offset exact primary all19 observer','entries':rows,'sourceSha256':sha(O/'41.kotoba'),'unitySha256':sha(O/'unity.kotoba'),'observerNativeSha256':sha(O/'seed.bin'),'schemas':{'ORIGINALSIR':'site op a b c before clones','SIR':'site op a b c after clones','META':'fn field value; original and after metadata sequential groups','FN':'fn sir frame ns dp nsv leaf codeWordStart','PCJOB':'context originalFn length status cloneFn','PCFACT':'context originalSir kind target index;kind1 targetContext,kind2 exactsafeIndex length/index,kind3 validVector length/zero','PCMAP':'ctx clone originalSir clonedSir op a b c flags','HCHK':'rv used base flags firstWord afterWord','EMIT':'sir skip firstWord afterWord flags','LIT':'index byteStart length poolOffset token','LITB':'byteIndex value','LITENV':'poolOffset codeBytes codeN literalN literalByteN','FIX':'index at kind target aux','PCPLAN':'fit oldFn oldSir oldLabels nextFn nextSir nextLabels factCount jobFailure factFailure'}},indent=2)+'\n')
