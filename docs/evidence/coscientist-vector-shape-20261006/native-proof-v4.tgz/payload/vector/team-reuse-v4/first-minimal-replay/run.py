from pathlib import Path
import subprocess,json
D=Path(__file__).resolve().parent;p=subprocess.run(['python3',str(D/'audit.py')],capture_output=True,text=True);(D/'stdout').write_text(p.stdout);(D/'stderr').write_text(p.stderr);(D/'status.json').write_text(json.dumps({'exit':p.returncode}));print(p.stdout[-2000:],p.stderr[-1000:]);assert p.returncode==0
