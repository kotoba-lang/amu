from pathlib import Path
import json,subprocess,os,hashlib,re
W=Path(__file__).resolve().parent;L=Path('/private/tmp/amu-private-length-clones-20261006/full-state-loader');r=json.loads((W/'report.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cases=[-9223372036854775808,-1,0,1,2,4,4096,9223372036854775807];p={'status':'PREREGISTERED generic original exported unknown-vector index controls before execution','fixtures':['exported-unknown','unknown-only'],'vectorArg':'vi:11,13','indices':cases,'oracle':{'0':11,'1':13,'others':'must trap'},'types':'vector-i64,i64','loaderSha256':sha(L),'candidateSeedSha256':r['candidateSeedSha256']};(W/'export-index-preregistration.json').write_text(json.dumps(p,indent=2)+'\n');rows=[]
for name in p['fixtures']:
 entry=next(x for x in r['rows'] if x['fixture']==name);assert not entry['nativeChanged'] and not entry['actualAdmitted']
 for k in cases:
  out={}
  for label in ['baseline','candidate']:
   env=dict(os.environ,KEXE_FUEL='1024',KEXE_STRUCTURED_REPORT='1',KEXE_ARG_TYPES='vector-i64,i64');env.pop('KEXE_COMMAND',None);q=subprocess.run([str(L),str(W/name/(label+'-read.bin')),str(entry['offsets'][label+':read']),'2','aarch64','-','vi:11,13',str(k)],env=env,capture_output=True,text=True);(W/name/f'original-vector-index{k}-{label}.stdout').write_text(q.stdout);(W/name/f'original-vector-index{k}-{label}.stderr').write_text(q.stderr);out[label]={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
  assert out['baseline']==out['candidate'],(name,k,out)
  if k in [0,1]:assert out['baseline']['exit']==0 and int(re.search(r':result (-?\d+)',out['baseline']['stdout'])[1])==[11,13][k]
  else:assert out['baseline']['exit']!=0
  rows.append({'fixture':name,'index':k,'equal':True,**out})
(W/'export-index-report.json').write_text(json.dumps({'status':'PASS exact generic original-export valid-vector/invalid-index guards fullstate','pairs':len(rows),'rows':rows,'candidateVersion':'v4','sourceChanges':0,'timingRuns':0},indent=2)+'\n');print('PASS16 generic original exported vector/index pairs')
