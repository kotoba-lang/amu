from pathlib import Path
import json,os,subprocess,hashlib
W=Path(__file__).resolve().parent;I=W.parent.parent/'implementation-v3';B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation');D=W/'baseline-stage';D.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();p=json.loads((W/'source-preregistration.json').read_text());rows=[]
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for name,m in p['fixtures'].items():
 src=W/(name+'.kotoba');assert sha(src)==m['sourceSha256'];q=subprocess.run([str(I/'kexe-loader'),str(B/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--','compile',str(src),'--target','aarch64-macos','--output',str(D/(name+'.kseed'))],env=env,capture_output=True,text=True);(D/(name+'.stdout')).write_text(q.stdout);(D/(name+'.stderr')).write_text(q.stderr);rows.append({'fixture':name,'exit':q.returncode,'sourceSha256':sha(src),'stdout':q.stdout,'stderr':q.stderr});print(name,q.returncode,q.stdout[-450:],q.stderr[-450:],flush=True)
(D/'report.json').write_text(json.dumps({'status':'BASELINE actual compile setup only','rows':rows,'candidateExecutions':0,'guestExecutions':0,'timingRuns':0},indent=2)+'\n')
