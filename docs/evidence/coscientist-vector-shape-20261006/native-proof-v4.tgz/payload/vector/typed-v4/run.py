from pathlib import Path
import os,re,json,hashlib,subprocess,shutil
W=Path(__file__).resolve().parent;I=W.parent.parent/'implementation-v4';B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation');L=Path('/private/tmp/amu-private-length-clones-20261006/full-state-loader');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());p=load(W/'preregistration.json')
for n,h in load(W/'input-pins.json').items():assert sha(Path(n))==h
for n,h in load(W/'source-pins.json').items():assert sha(W/n)==h
compilerEnv=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[];failures=[];setup=[];allpairs=[]
def invoke(cmd,env,dst):
 q=subprocess.run(cmd,env=env,capture_output=True,text=True);dst.with_suffix('.stdout').write_text(q.stdout);dst.with_suffix('.stderr').write_text(q.stderr);return q

def execute(d,label,symbol,off,args,fuel,cap,tag):
 env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');env.pop('KEXE_COMMAND',None)
 if cap:env[cap[0]]=str(cap[1])
 q=invoke([str(L),str(d/(label+'-'+symbol+'.bin')),str(off),str(len(args)),'aarch64','-',*map(str,args)],env,d/(tag+'-'+label));return {'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
for name,meta in p['fixtures'].items():
 d=W/name;d.mkdir();offsets={};logs={};valid=True;symbols=['read'] if name=='unknown-only' else (['run','read'] if name=='exported-unknown' else ['run'])
 for label,seed in [('baseline',B/'seed-4.bin'),('candidate',I/'seed-4.bin'),('observer',I/'observer/seed.bin')]:
  if label=='baseline':
   bas=load(W/'baseline-stage/native-pins.json')[name];assert bas['sourceSha256']==meta['sourceSha256'] and bas['compilerSha256']==p['baselineSeedSha256'];logs[label]=''
   for symbol in symbols:
    src=W/'baseline-stage'/(name+'-'+symbol+'.bin');assert sha(src)==bas['native'][symbol]['sha256'];shutil.copy2(src,d/(label+'-'+symbol+'.bin'));offsets[label,symbol]=bas['native'][symbol]['offset']
   continue

  q=invoke([str(I/'kexe-loader'),str(seed),'0','0','aarch64','35,37,38,39','--','compile',str(W/(name+'.kotoba')),'--target','aarch64-macos','--output',str(d/(label+'.kseed'))],compilerEnv,d/(label+'-compile'));logs[label]=q.stdout
  if q.returncode:setup.append({'fixture':name,'label':label,'stage':'compile','exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr});valid=False;continue
  for symbol in symbols:
   q=invoke([str(I/'kexe-loader'),str(seed),'0','0','aarch64','35,37,38,39','--','extract-native',str(d/(label+'.kseed')),'--symbol',symbol,'--output',str(d/(label+'-'+symbol+'.bin'))],compilerEnv,d/(label+'-'+symbol+'-extract'))
   if q.returncode:setup.append({'fixture':name,'label':label,'stage':'extract '+symbol,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr});valid=False;continue
   offsets[label,symbol]=int(re.search(r':offset (\d+)',q.stdout)[1])
 if not valid:print('SETUP FAILURE retained',name,flush=True);continue
 for symbol in symbols:assert sha(d/('candidate-'+symbol+'.bin'))==sha(d/('observer-'+symbol+'.bin')) and offsets['candidate',symbol]==offsets['observer',symbol]
 jobs=[list(map(int,z.split()[1:])) for z in logs['observer'].splitlines() if z.startswith('PCJOB ')];maps=[list(map(int,z.split()[1:])) for z in logs['observer'].splitlines() if z.startswith('PCMAP ')];facts=[list(map(int,z.split()[1:])) for z in logs['observer'].splitlines() if z.startswith('PCFACT ')];plans=[list(map(int,z.split()[1:])) for z in logs['observer'].splitlines() if z.startswith('PCPLAN ')];changed=any(sha(d/('candidate-'+s+'.bin'))!=sha(d/('baseline-'+s+'.bin')) for s in symbols);admitted=bool(maps and any(j[-1]>0 for j in jobs))
 if meta['expectedAdmission']=='positive' and not(changed and admitted):failures.append({'fixture':name,'requirement':'positive actual specialization + changed code','changed':changed,'jobs':jobs,'maps':len(maps)})
 if meta['expectedAdmission']=='refusal' and (admitted or changed):failures.append({'fixture':name,'requirement':'refusal generic identical','changed':changed,'jobs':jobs,'maps':len(maps)})
 pairs=[]
 if 'run' in symbols:
  cases=[(n,f,None) for n in p['normalInputs'] for f in p['fuelPrefixes']]+[(1,1024,c) for c in p['resourceCases']]
  for k,(n,f,cap) in enumerate(cases):
   out={label:execute(d,label,'run',offsets[label,'run'],[n],f,cap,'case'+str(k)) for label in ['baseline','candidate']};equal=out['baseline']==out['candidate'];row={'fixture':name,'symbol':'run','n':n,'fuel':f,'cap':cap,'equal':equal,**out};pairs.append(row);allpairs.append(row)
   if not equal:failures.append({'fixture':name,'requirement':'full-state parity','case':k,'n':n,'fuel':f,'cap':cap})
   if out['baseline']['exit']==0 and f==1024 and cap is None:
    want=meta['normalOracle'][str(n)];got=int(re.search(r':result (-?\d+)',out['baseline']['stdout'])[1]);assert got==want,(name,n,got,want)
 if 'read' in symbols:
  for k,args in enumerate(p['invalidExportArgs']):
   out={label:execute(d,label,'read',offsets[label,'read'],args,1024,None,'export'+str(k)) for label in ['baseline','candidate']};equal=out['baseline']==out['candidate'];row={'fixture':name,'symbol':'read','args':args,'fuel':1024,'cap':None,'equal':equal,**out};pairs.append(row);allpairs.append(row)
   if not equal or out['baseline']['exit']==0:failures.append({'fixture':name,'requirement':'original exported unknown/invalid guard retained','args':args})
 rows.append({'fixture':name,'expectedAdmission':meta['expectedAdmission'],'nativeChanged':changed,'actualAdmitted':admitted,'jobs':jobs,'mapCount':len(maps),'facts':facts,'plans':plans,'offsets':{label+':'+symbol:off for (label,symbol),off in offsets.items()},'sourceSha256':sha(W/(name+'.kotoba')),'nativePins':{label+':'+symbol:sha(d/(label+'-'+symbol+'.bin')) for label in ['baseline','candidate','observer'] for symbol in symbols},'pairs':len(pairs)});print('TERMINAL typed',name,'changed',changed,'admitted',admitted,'pairs',len(pairs),'failures',len(failures),flush=True)
(W/'raw-paired-states.json').write_text(json.dumps(allpairs,indent=2)+'\n');(W/'report.json').write_text(json.dumps({'status':'PASS' if not failures and not setup else 'FAIL required typed qualification','candidateSeedSha256':p['candidateSeedSha256'],'candidateVersion':'v4','baselineNormalOracleBeforeCandidate':True,'rows':rows,'setupFailures':setup,'failures':failures,'fullStatePairs':len(allpairs),'trappedPairs':sum(r['baseline']['exit']!=0 for r in allpairs),'rawPairedStatesSha256':sha(W/'raw-paired-states.json'),'newTimingRuns':0,'goldenChanges':0,'sourceOraclesCandidateIndependent':True,'limitations':['Finite actual source/native/full-state controls; not universal soundness proof.','Preregistered positive admission failures are reported and not relabeled.']},indent=2)+'\n')
pins={str(f.relative_to(W)):sha(f) for f in W.rglob('*') if f.is_file() and f.name!='artifact-pins.json' and '__pycache__' not in f.parts};(W/'artifact-pins.json').write_text(json.dumps(pins,indent=2)+'\n');print('FINAL',len(allpairs),'pairs',len(setup),'setup failures',len(failures),'qualification failures',flush=True)
