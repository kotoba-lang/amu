from pathlib import Path
import json,os,subprocess,hashlib,re
W=Path(__file__).resolve().parent;I=W.parent.parent/'implementation-v3';B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation');L=Path('/private/tmp/amu-private-length-clones-20261006/full-state-loader');D=W/'baseline-stage';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();p=json.loads((W/'source-preregistration.json').read_text());records={};env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for name,m in p['fixtures'].items():
 symbols=['read'] if name=='unknown-only' else (['run','read'] if name=='exported-unknown' else ['run']);offsets={};norm=[]
 for symbol in symbols:
  native=D/(name+'-'+symbol+'.bin');q=subprocess.run([str(I/'kexe-loader'),str(B/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--','extract-native',str(D/(name+'.kseed')),'--symbol',symbol,'--output',str(native)],env=env,capture_output=True,text=True);(D/(name+'-'+symbol+'-extract.stdout')).write_text(q.stdout);(D/(name+'-'+symbol+'-extract.stderr')).write_text(q.stderr);assert q.returncode==0;off=int(re.search(r':offset (\d+)',q.stdout)[1]);offsets[symbol]=off
  if symbol=='run':
   for n in p['normalInputs']:
    e=dict(os.environ,KEXE_FUEL='1024',KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);v=subprocess.run([str(L),str(native),str(off),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True);(D/f'{name}-oracle-n{n}.stdout').write_text(v.stdout);(D/f'{name}-oracle-n{n}.stderr').write_text(v.stderr);assert v.returncode==0 and int(re.search(r':result (-?\d+)',v.stdout)[1])==m['normalOracle'][str(n)],(name,n,v.stdout,v.stderr);norm.append({'n':n,'expected':m['normalOracle'][str(n)],'exit':v.returncode,'stdout':v.stdout,'stderr':v.stderr})
 records[name]={'sourceSha256':m['sourceSha256'],'compilerSha256':sha(B/'seed-4.bin'),'imageSha256':sha(D/(name+'.kseed')),'native':{s:{'sha256':sha(D/(name+'-'+s+'.bin')),'offset':offsets[s]} for s in symbols},'baselineNormalOracle':norm};print('BASELINE independent oracle PASS',name,len(norm),flush=True)
(D/'native-pins.json').write_text(json.dumps(records,indent=2)+'\n')
