from pathlib import Path
import subprocess,json
w=Path(__file__).resolve().parent
for n in ['ordinary','fuel','resource']:
 q=subprocess.run(['python3',str(w/(n+'.py'))],capture_output=True,text=True);(w/(n+'.stdout')).write_text(q.stdout);(w/(n+'.stderr')).write_text(q.stderr);(w/(n+'.status.json')).write_text(json.dumps({'exit':q.returncode}));print(n,q.returncode,q.stdout[-600:],q.stderr[-1000:],flush=True);assert q.returncode==0
