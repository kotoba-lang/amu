from pathlib import Path
import json,struct,collections,copy,hashlib
D=Path(__file__).parent;I=D.parent/'implementation-v4'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def signed(n,b):return n-(1<<b) if n&(1<<(b-1)) else n
def branch(z):
 if z&0x7c000000==0x14000000:return z&0xfc000000,signed(z&0x3ffffff,26)
 if z&0xff000010==0x54000000:return z&0xff00001f,signed((z>>5)&0x7ffff,19)
 if z&0x7e000000==0x34000000:return z&0xff00001f,signed((z>>5)&0x7ffff,19)
 if z&0x7e000000==0x36000000:return z&0xfff8001f,signed((z>>5)&0x3fff,14)
 if z&0x9f000000==0x10000000:return z&0x9f00001f,signed(((z>>5)&0x7ffff)*4+((z>>29)&3),21)/4
 return None
def parse(p):
 d={'meta':[],'fns':{},'fix':[],'events':[],'hchk':[],'struct':[]};raw=(p/'native.bin').read_bytes()
 for l in (p/'compile.log').read_text().splitlines():
  q=l.split()
  if not q or q[0] not in ['FN','FIX','EMIT','HCHK','PCMAP','PCJOB','PCFACT','PCPLAN','SIR','ORIGINALSIR','META']:continue
  v=tuple(map(int,q[1:]));tag=q[0]
  if tag=='FN':d['fns'][v[0]]=v[-1]
  elif tag=='FIX':d['fix'].append(v)
  elif tag=='EMIT':d['events'].append(v)
  elif tag=='HCHK':d['hchk'].append(v)
  else:d['struct'].append((tag,*v))
 n=max(v[3] for v in d['events']);d.update(n=n,raw=raw,words=list(struct.unpack('<'+'I'*(n-1),raw[:4*(n-1)])))
 return d
def audit(a,b):
 assert a['struct']==b['struct'];assert a['fns'].keys()==b['fns'].keys();assert len(a['fix'])==len(b['fix'])
 lit={};fixpairs=[]
 for x,y in zip(a['fix'],b['fix']):
  ix,at,k,t,u=x;iy,bt,l,s,v=y;assert(ix,k,t,u)==(iy,l,s,v);fixpairs.append((x,y))
  if k==5:
   for j in [0,1]:lit[at+j,bt+j]=j
 assert len(a['hchk'])==len(b['hchk']);deleted=set();hguards=0
 for x,y in zip(a['hchk'],b['hchk']):
  rv,used,base,flags,st,en=x;rr,uu,bb,ff,bs,be=y;assert(rv,used,base,flags)==(rr,uu,bb,ff)
  if en-st==be-bs:continue
  assert (used,base)==(312,320) and flags&2 and en-st==8 and be-bs==3
  w=a['words'];assert w[st-1]==0xf9409cf0 and w[st]==0xf9400210 and w[st+1]==0xd1000411|(rv<<5)
  assert w[st+2]==0xeb10023f and w[st+3]==0x54000043 and w[st+4]==0
  assert w[st+5]==0xf940a0f0 and w[st+6]==0x8b111210
  deleted.update([st,st+1,st+3,st+4,st+5]);hguards+=1
 aw,bw=a['words'],b['words'];mapping={};pairs=[];bounds=[];i=j=1
 while i<a['n']:
  if i in deleted:mapping[i]=j;i+=1;continue
  z=aw[i-1];v=bw[j-1] if j<b['n'] else None;q=branch(z);r=branch(v) if v is not None else None
  equal=z==v or(q and r and q[0]==r[0])or((i,j)in lit and z&~0x1fffe0==v&~0x1fffe0)
  if equal:mapping[i]=j;pairs.append((i,j));i+=1;j+=1;continue
  assert i+2<a['n'] and z&0xffe0fc1f==0xeb00001f and((z>>16)&31)in(3,16)and((z>>5)&31)!=17 and aw[i]==0x54000043 and aw[i+1]==0,('unexpected deletion',i,j,hex(z),None if v is None else hex(v))
  ev=next(e for e in a['events'] if e[2]<=i and i+3<=e[3]);assert ev[-1]&1,('unproved bounds',i,ev)
  bounds.append((i,ev[0]));
  for k in range(3):mapping[i+k]=j
  i+=3
 assert j==b['n'];mapping[a['n']]=b['n'];counts=collections.Counter()
 for i,j in pairs:
  z=aw[i-1];v=bw[j-1];q=branch(z);r=branch(v)
  if q:
   assert r and q[0]==r[0];target=i+q[1];bt=j+r[1];assert mapping.get(target)==bt,('edge',i,j,target,bt,mapping.get(target));counts['edges']+=1
  elif(i,j)in lit:
   kind=lit[i,j];assert z&0xffe00000==(0xd2800000 if kind==0 else 0xf2a00000);assert z&~0x1fffe0==v&~0x1fffe0;counts['literalWords']+=1
  else:assert z==v;counts['exactWords']+=1
 for f,at in a['fns'].items():assert mapping[at]==b['fns'][f]
 for x,y in zip(a['events'],b['events']):
  si,sk,st,en,flag=x;sj,kk,bs,be,ff=y;assert(si,sk,flag)==(sj,kk,ff);assert mapping[st]==bs and mapping[en]==be,('event',x,y)
 for x,y in fixpairs:
  ix,at,k,t,u=x;iy,bt,l,s,v=y
  if at==0:assert x==y and k==t==u==0;continue
  assert mapping[at]==bt
  if k==5:
   assert mapping[at+1]==bt+1
   old=((aw[at-1]>>5)&65535)|(((aw[at]>>5)&65535)<<16);new=((bw[bt-1]>>5)&65535)|(((bw[bt]>>5)&65535)<<16)
   oldpool=((a['n']-1)*4+7)//8*8;newpool=((b['n']-1)*4+7)//8*8;assert old-oldpool==new-newpool
  elif k==4:
   q=branch(aw[at-1]);r=branch(bw[bt-1]);assert q and r and u in(0,1);assert at+q[1]==a['fns'][t]+u and bt+r[1]==b['fns'][t]+u
   if u==1:assert aw[a['fns'][t]-1]==bw[b['fns'][t]-1]==0xd2800005;counts['privateAux1']+=1
 ap=((a['n']-1)*4+7)//8*8;bp=((b['n']-1)*4+7)//8*8
 assert set(a['raw'][4*(a['n']-1):ap])<={0};assert set(b['raw'][4*(b['n']-1):bp])<={0};assert a['raw'][ap:]==b['raw'][bp:]
 assert a['n']-b['n']==5*hguards+3*len(bounds)
 counts.update(handleChecksDeleted=hguards,boundsDeleted=len(bounds),functions=len(a['fns']),events=len(a['events']),fixes=len(a['fix']))
 return dict(counts=counts,pairs=pairs)
rows=[];tot=collections.Counter()
for p in sorted((I/'observer/ports').iterdir()):
 a=parse(D/'control/observer/ports'/p.name);b=parse(p);r=audit(a,b);tot.update(r['counts']);rows.append({'workload':p.name,'controlSha256':sha(D/'control/observer/ports'/p.name/'native.bin'),'candidateSha256':sha(p/'native.bin'),**r['counts']});print('PASS',p.name,dict(r['counts']),flush=True)
(D/'machine-report.json').write_text(json.dumps({'status':'PASS full emitted machine projection between same-cloned-SIR original-guard control and v2','totals':dict(tot),'rows':rows},indent=2)+'\n')
