import machine,json
from pathlib import Path
D=Path(__file__).parent;I=D.parent/'implementation-v4';B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation/observer/ports');rows=[]
for p in sorted((I/'observer/ports').iterdir()):
 a=machine.parse(B/p.name);b=machine.parse(p);n=a['n'];oldmax=max(a['fns']);end=b['fns'].get(oldmax+1,b['n']);assert end==n,(p.name,'generic span changed',end,n)
 # Same original metadata/code entry indices proved separately by IR plus exact layout.
 assert all(b['fns'][f]==v for f,v in a['fns'].items())
 fixes={v[1]:v for v in b['fix'] if v[1]<n};oldfix={v[1]:v for v in a['fix']};edges=0;redirects=0
 facts={}
 jobs={}
 for tag,*v in b['struct']:
  if tag=='PCJOB':jobs[v[0]]=v[1:]
  elif tag=='PCFACT' and v[2]==1:facts[v[1]]=v[3]
 for j in range(1,n):
  x=a['words'][j-1];y=b['words'][j-1]
  if x==y:continue
  q=machine.branch(x);r=machine.branch(y)
  if q and r and q[0]==r[0]:
   at=oldfix.get(j);bt=fixes.get(j);assert at and bt and at[2]==bt[2]==4 and at[4]==bt[4]
   assert bt[3]>oldmax;assert any(v[0]==at[3] and v[3]==bt[3] for v in jobs.values());assert j+q[1]==a['fns'][at[3]]+at[4] and j+r[1]==b['fns'][bt[3]]+bt[4];redirects+=1;continue
  at=oldfix.get(j) or oldfix.get(j-1);bt=fixes.get(j) or fixes.get(j-1)
  assert at and bt and at[2]==bt[2]==5 and at[3:]==bt[3:] and x&~0x1fffe0==y&~0x1fffe0,(p.name,j,hex(x),hex(y))
  # literal relocation already full control-to-candidate pool verified; baseline pool payload equality below.
 ap=((n-1)*4+7)//8*8;bp=((b['n']-1)*4+7)//8*8;assert a['raw'][ap:]==b['raw'][bp:]
 rows.append({'workload':p.name,'genericWordSpan':n-1,'redirectedBL':redirects})
(D/'generic-report.json').write_text(json.dumps({'status':'PASS original generic full native span/entry preservation; only declared BL redirect and literal pool relocation','rows':rows},indent=2)+'\n')
