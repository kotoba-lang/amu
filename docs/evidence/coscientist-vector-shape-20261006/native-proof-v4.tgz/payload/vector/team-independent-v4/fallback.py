from pathlib import Path
import json,hashlib
D=Path(__file__).parent;I=D.parent/'implementation-v4';T=D.parent/'team-controls-v4';B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation/ports');rows=[];budgets={}
for p in sorted((I/'observer/ports').iterdir()):
 fn={};plan=None;n=0
 for l in(p/'compile.log').read_text().splitlines():
  q=l.split()
  if not q:continue
  if q[0]=='PCPLAN':plan=list(map(int,q[1:]))
  elif q[0]=='FN':fn[int(q[1])]=int(q[-1])
  elif q[0]=='LITENV':n=int(q[3])
 old=plan[1]if plan else max(fn)+1;start=fn.get(old,n);budgets[p.name]=n-start
for c in sorted(T.iterdir()):
 if not c.is_dir():continue
 cap=0 if c.name=='disabled'else int(c.name.removeprefix('clone-word-cap'))
 for w,budget in budgets.items():
  p=c/w/'native.bin';assert p.exists();target=I/'ports'/w/'native.bin'if cap>=budget and cap>0 else B/w/'native.bin'
  assert p.read_bytes()==target.read_bytes(),(c.name,w,budget)
  rows.append({'control':c.name,'workload':w,'actualCloneWords':budget,'expected':'candidate'if target.parts[-4]=='implementation-v4'else 'baseline','sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(D/'fallback-report.json').write_text(json.dumps({'status':'PASS independently recomputed actual cloneword threshold and all152 raw byte fallback controls','budgets':budgets,'rows':rows},indent=2)+'\n')
