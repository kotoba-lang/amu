from pathlib import Path
import json,struct
D=Path(__file__).parent;I=D.parent/'implementation-v4';rows=[]
for p in sorted((I/'observer/ports').iterdir()):
 lit=[];lb={};env=None
 for l in (p/'compile.log').read_text().splitlines():
  q=l.split()
  if not q or q[0]not in['LIT','LITB','LITENV']:continue
  v=list(map(int,q[1:]))
  if q[0]=='LIT':lit.append(v)
  elif q[0]=='LITB':assert v[0]not in lb;lb[v[0]]=v[1]
  else:assert env is None;env=v
 pool,codebytes,n,ln,bn=env;raw=(p/'native.bin').read_bytes();assert codebytes==len(raw) and pool==((n-1)*4+7)//8*8
 assert len(lit)==ln-1 and set(lb)==set(range(bn))
 for i,st,length,off,tok in lit:
  assert off>=pool and off+length<=len(raw);assert raw[off:off+length]==bytes(lb[j]for j in range(st,st+length))
 assert set(raw[(n-1)*4:pool])<={0};rows.append({'workload':p.name,'literalRecords':ln-1,'literalBytes':bn-1,'poolOffset':pool,'codeBytes':codebytes})
(D/'literal-report.json').write_text(json.dumps({'status':'PASS independently bind LIT/LITB metadata to all19 actual final pool bytes','rows':rows},indent=2)+'\n')
