from pathlib import Path
import subprocess,os,re,json,hashlib
D=Path(__file__).parent;I=D.parent/'implementation-v4';E=D/'exhaustion';E.mkdir(exist_ok=True)
s=(I/'unity.kotoba').read_text();s=s.replace('(defn main [] :i64 (seed-main))','')
s+="""
(defn- ex-init [m :vector-i64 err :i64] :vector-i64
 (-> m (mem-set 256 77) (mem-set 500000 81) (mem-set gn-cell 0) (mem-set MM-ERR err) (mem-set MM-FN-N 1) (mem-set MM-SIR-N 1) (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1) (mem-set MM-HEAP-TOP (- MM-HEAP-END 1))))
(defn- ex-compare [a :vector-i64 b :vector-i64 i :i64 diffs :i64] :i64
 (if (= i MM-WORDS) diffs (ex-compare a b (inc i) (+ diffs (if (= (vector-at a i) (vector-at b i)) 0 1)))))
(defn main [] :i64
 (let [a0 (ex-init (mem-new) 0) b0 (ex-init (mem-new) 0)
       a1 (gn-run-plan a0 0 0 false) b1 (mem-alloc b0 (+ gn-a-lp MM-LABEL-CAP 88))
       x (ex-compare a1 b1 0 0)
       c0 (ex-init (mem-new) 777) d0 (ex-init (mem-new) 777)
       c1 (gn-run-plan c0 0 0 false) d1 (mem-alloc d0 (+ gn-a-lp MM-LABEL-CAP 88))
       y (ex-compare c1 d1 0 0)]
  (+ (* 1000 x) y)))
"""
(E/'source.kotoba').write_text(s)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for label,args in [('compile',['compile',str(E/'source.kotoba'),'--target','aarch64-macos','--output',str(E/'image.kseed')]),('extract',['extract-native',str(E/'image.kseed'),'--symbol','main','--output',str(E/'native.bin')])]:
 q=subprocess.run([str(I/'kexe-loader'),str(I/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(E/(label+'.stdout')).write_text(q.stdout);(E/(label+'.stderr')).write_text(q.stderr);(E/(label+'.status.json')).write_text(json.dumps({'exit':q.returncode}));assert q.returncode==0,(label,q.stdout[-800:],q.stderr[-800:])
 if label=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1])
env.pop('KEXE_COMMAND');q=subprocess.run([str(I/'kexe-loader'),str(E/'native.bin'),str(off),'0','aarch64','-'],env=env,capture_output=True,text=True);(E/'run.stdout').write_text(q.stdout);(E/'run.stderr').write_text(q.stderr);(E/'run.status.json').write_text(json.dumps({'exit':q.returncode}));print(q.returncode,q.stdout,q.stderr)
