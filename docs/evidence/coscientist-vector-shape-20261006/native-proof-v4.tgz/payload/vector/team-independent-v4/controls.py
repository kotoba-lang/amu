import machine,copy,json
from pathlib import Path
D=Path(__file__).parent;I=D.parent/'implementation-v4';rows=[]
def refuse(name,a,b):
 try:machine.audit(a,b)
 except (AssertionError,KeyError,IndexError,TypeError) as e:rows.append({'name':name,'status':'DETECTED','diagnostic':str(e)[:200]});return
 raise AssertionError('accepted '+name)
a=machine.parse(D/'control/observer/ports/statemate');b=machine.parse(I/'observer/ports/statemate');r=machine.audit(a,b)
for kind in ['ordinary','branch','privateaux','boundsflag','validflag','entry','pool']:
 x=copy.deepcopy(a);y=copy.deepcopy(b)
 if kind in ['ordinary','branch']:
  j=next(j for i,j in r['pairs'] if (machine.branch(b['words'][j-1])is not None)==(kind=='branch') and b['words'][j-1]!=0);y['words'][j-1]^=32 if kind=='branch' else 1
 elif kind=='privateaux':
  k=next(k for k,v in enumerate(y['fix'])if v[2]==4 and v[4]==1);v=y['fix'][k];y['fix'][k]=(*v[:4],0)
 elif kind=='boundsflag':
  x['events']=[(*v[:4],v[4]&~1)for v in x['events']]
 elif kind=='validflag':
  x['hchk']=[(*v[:3],v[3]&~2,*v[4:])for v in x['hchk']];y['hchk']=[(*v[:3],v[3]&~2,*v[4:])for v in y['hchk']]
 elif kind=='entry':y['fns'][next(f for f in y['fns'] if y['fns'][f]>1)]+=1
 else:y['raw']=y['raw']+b'\x01'
 refuse(kind,x,y)
a=machine.parse(D/'control/observer/ports/crc32');b=machine.parse(I/'observer/ports/crc32');v=next(v for v in b['fix']if v[2]==5);b['words'][v[1]-1]^=32;refuse('declaredliteral',a,b)
(D/'machine-controls.json').write_text(json.dumps({'status':'PASS eight actual opcode/edge/metadata/flag/pool mutation calibrations','controls':rows},indent=2)+'\n')
