from pathlib import Path
import json,hashlib,copy
I=Path('/private/tmp/amu-vector-shape-specialize-20261006/implementation-v4');D=Path(__file__).resolve().parent;O=I/'observer';B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation/observer/ports');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def parse(p):
 d={'old':{},'sir':{},'jobs':{},'facts':[],'maps':{},'meta':{},'plan':None}
 for l in (p/'compile.log').read_text().splitlines():
  q=l.split()
  if not q or q[0] not in ['ORIGINALSIR','SIR','PCJOB','PCFACT','PCMAP','META','PCPLAN']:continue
  v=list(map(int,q[1:]));tag=q[0]
  if tag=='ORIGINALSIR':d['old'][v[0]]=tuple(v[1:])
  elif tag=='SIR':d['sir'][v[0]]=tuple(v[1:])
  elif tag=='PCJOB':d['jobs'][v[0]]=tuple(v[1:])
  elif tag=='PCFACT':d['facts'].append(tuple(v))
  elif tag=='PCMAP':d['maps'][v[3]]=tuple(v)
  elif tag=='META':d['meta'].setdefault((v[0],v[1]),[]).append(v[2])
  elif tag=='PCPLAN':assert d['plan'] is None;d['plan']=tuple(v)
 return d

def audit(d,baseline):
 assert d['old']==baseline
 oldFn=(d['plan'][1] if d['plan'] else max(f for f,k in d['meta'])+1)
 oldSir=(d['plan'][2] if d['plan'] else max(d['old'])+1)
 assert set(d['old'])==set(range(1,oldSir))
 for (f,k),values in d['meta'].items():
  if f<oldFn:assert len(values)==2 and values[0]==values[1],('original FN metadata',f,k,values)
  else:assert len(values)==1
 facts={(ctx,i,kind):(target,index) for ctx,i,kind,target,index in d['facts']}
 cloneJobs={clone:(ctx,f,length,status) for ctx,(f,length,status,clone) in d['jobs'].items() if clone>0}
 addressed={v[2] for v in d['old'].values() if v[0]==22}
 redirects={}
 for (ctx,i,kind),(target,index) in facts.items():
  if kind!=1:continue
  cf,length,status,clone=d['jobs'][target]
  assert d['old'][i][0]==13 and d['old'][i][1]==cf
  if d['jobs'][ctx][1]==-1 and clone>0:redirects[i]=clone
 for i,old in d['old'].items():
  new=d['sir'][i]
  assert new==((old[0],redirects[i],old[2],old[3]) if i in redirects else old),('generic source/body preservation',i)
 labelMaps={};byclone={}
 for site,m in d['maps'].items():
  ctx,clone,originalSir,newSir,op,a,b,c,flags=m
  assert site==newSir and clone in cloneJobs and cloneJobs[clone][0]==ctx
  assert d['sir'][site]==(op,a,b,c)
  byclone.setdefault(clone,[]).append(m)
  if op==9:labelMaps[(clone,d['old'][originalSir][1])]=a
 for clone,(ctx,f,length,status) in cloneJobs.items():
  assert length>=0 and status==1 and f not in addressed and d['meta'][(f,11)][0]==0
  for k in range(16):
   v=d['meta'][(clone,k)][0];old=d['meta'][(f,k)][0]
   if k in [0,1,11,13]:assert v==0
   elif k==2:assert v==2
   elif k==12:assert d['sir'][v]==(1,clone,d['old'][old][2],d['old'][old][3])
   else:assert v==old,('clone ABI/type/fuel/depth',clone,k)
  ms=sorted(byclone[clone],key=lambda x:x[3]);assert [m[3] for m in ms]==list(range(ms[0][3],ms[-1][3]+1))
  assert [m[2] for m in ms]==list(range(ms[0][2],ms[-1][2]+1))
  assert d['old'][ms[0][2]][:2]==(1,f) and d['old'][ms[-1][2]]==(2,f,0,0)
  for m in ms:
   ctx,clone,orig,site,op,a,b,c,flag=m;z=d['old'][orig];exp=list(z)
   if op in [1,2]:exp[1]=clone
   elif op in [9,10]:exp[1]=labelMaps[(clone,z[1])]
   elif op in [11,12]:exp[2]=labelMaps[(clone,z[2])]
   elif op==13:
    r=facts.get((ctx,orig,1));job=d['jobs'][r[0]] if r else None
    if job and job[3]>0:exp[1]=job[3]
   assert tuple(exp)==(op,a,b,c),('exact clone remap',clone,orig)
   expectedFlag=(1 if (ctx,orig,2) in facts else 0)+(2 if (ctx,orig,3) in facts else 0)
   assert flag==expectedFlag
 assert set(d['sir'])-set(d['old'])==set(d['maps']),('exact clone SIR coverage')
 return {'originalFns':oldFn-1,'originalSir':oldSir-1,'clones':len(cloneJobs),'cloneSir':len(d['maps']),'genericRedirects':len(redirects),'boundsCertificates':sum(k[2]==2 for k in facts),'validityCertificates':sum(k[2]==3 for k in facts)}
rows=[];data={}
for p in sorted((O/'ports').iterdir()):
 base={}
 for l in (B/p.name/'compile.log').read_text().splitlines():
  q=l.split()
  if q and q[0]=='SIR':base[int(q[1])]=tuple(map(int,q[2:]))
 d=parse(p);r=audit(d,base);data[p.name]=(d,base);rows.append({'workload':p.name,**r});print('PASS readonly IR retention/clone/flags',p.name,flush=True)
d,base=data['statemate'];controls=[]
mutations=[]
i=next(i for i,z in d['old'].items() if z[0]!=13);x=copy.deepcopy(d);z=list(x['sir'][i]);z[1]^=1;x['sir'][i]=tuple(z);mutations.append(('generic non-call opcode operand',x))
site=next(iter(d['maps']));x=copy.deepcopy(d);z=list(x['maps'][site]);z[-1]^=2;x['maps'][site]=tuple(z);mutations.append(('unjustified valid flag',x))
clone=next(v[3] for v in d['jobs'].values() if v[3]>0);x=copy.deepcopy(d);x['meta'][(clone,14)][0]^=1;mutations.append(('clone fuel ABI field',x))
for name,x in mutations:
 try:audit(x,base)
 except (AssertionError,KeyError) as e:controls.append({'name':name,'status':'DETECTED','diagnostic':str(e)[:300]})
 else:raise AssertionError('fault accepted '+name)
(D/'ir-binding-report.json').write_text(json.dumps({'status':'PASS separate original generic SIR/FN and exact clone structural/flag binding; machine projection audited separately','rows':rows,'controls':controls,'meaningBoundary':'This independently verifies record/source preservation, not all-predecessor semantic certificates, native instructions or current e317 correctness. Constructor oracle is separate; whole native CFG cannot PASS current cached-branch failure.'},indent=2)+'\n')
