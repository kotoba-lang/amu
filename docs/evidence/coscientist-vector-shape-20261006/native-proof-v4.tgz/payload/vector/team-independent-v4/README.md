V4 independent terminal audit PASS within recorded scope

All19 actualmachineprojection,originalgenericentry/body/pool,FIX/privateaux,IR/clonemapping andliteralmetadata pass. Disabled+seven clonebudget controls152 rawnative/exporttables match independentlyderived baseline/candidate expectation. Actual native allocator-error fixture checks every8,388,608 compiler memorywords for fresh/preexistingerror:zero differences. Removingguard source mutation yields4 differences percase. Eightmachine+threeIRfaults detected.

Candidate924b03/sourceimmutable. Earlier e317/V2/V3 negativeevidence retained. No timing or adoptionclaim; independent wholeCFG mechanizedproof not claimed and fullordinarysemantic suites belong otherowners. See report.json and external-proof-input-pins.json for trustboundaries.
