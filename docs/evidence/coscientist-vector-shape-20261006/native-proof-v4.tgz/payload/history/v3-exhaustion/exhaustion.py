from pathlib import Path
import subprocess,os,re,json,hashlib
D=Path(__file__).parent;I=D.parent/'implementation-v3';E=D/'exhaustion';E.mkdir(exist_ok=True)
s=(I/'unity.kotoba').read_text();s=s.replace('(defn main [] :i64 (seed-main))','''(defn main [] :i64
 (let [m0 (mem-new) m1 (-> m0 (mem-set 256 77) (mem-set MM-FN-N 1) (mem-set MM-SIR-N 1) (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1) (mem-set MM-HEAP-TOP (- MM-HEAP-END 1)))
       m2 (gn-run-plan m1 0 0 false)]
  (+ (* (vector-at m2 MM-ERR) 1000) (vector-at m2 256))))''')
(E/'source.kotoba').write_text(s)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for label,args in [('compile',['compile',str(E/'source.kotoba'),'--target','aarch64-macos','--output',str(E/'image.kseed')]),('extract',['extract-native',str(E/'image.kseed'),'--symbol','main','--output',str(E/'native.bin')])]:
 q=subprocess.run([str(I/'kexe-loader'),str(I/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(E/(label+'.stdout')).write_text(q.stdout);(E/(label+'.stderr')).write_text(q.stderr);(E/(label+'.status.json')).write_text(json.dumps({'exit':q.returncode}));assert q.returncode==0,(label,q.stdout[-800:],q.stderr[-800:])
 if label=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1])
env.pop('KEXE_COMMAND');q=subprocess.run([str(I/'kexe-loader'),str(E/'native.bin'),str(off),'0','aarch64','-'],env=env,capture_output=True,text=True);(E/'run.stdout').write_text(q.stdout);(E/'run.stderr').write_text(q.stderr);(E/'run.status.json').write_text(json.dumps({'exit':q.returncode}));print(q.returncode,q.stdout,q.stderr)
