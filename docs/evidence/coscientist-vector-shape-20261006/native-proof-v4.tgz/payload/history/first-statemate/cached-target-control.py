from pathlib import Path
import json,struct,subprocess,os,hashlib
W=Path('/private/tmp/amu-vector-shape-specialize-20261006');I=W/'implementation';D=W/'team-resource';O=I/'observer/ports/statemate';raw=bytearray((O/'native.bin').read_bytes());words=list(struct.unpack('<'+str(len(raw)//4)+'I',raw));events=[]
for l in (O/'compile.log').read_text().splitlines():
 if not l.startswith('HCHK '):continue
 rv,used,base,flags,start,end=map(int,l.split()[1:])
 if not(flags&2 and used==312 and base==320):continue
 assert end-start==3
 # Cached branch immediately before MOV key,HCHK, or immediately before HCHK for saved-bank reader.
 for at in [start-2,start-1]:
  z=words[at-1];cond=(z&0xff000010==0x54000000 and z&15==0);cb=(z&0x7e000000==0x34000000 and z&(1<<24)!=0)
  if not(cond or cb):continue
  delta=(z>>5)&0x7ffff;delta=delta-(1<<19)if delta&(1<<18)else delta
  if delta!=13:continue
  # Exact actual miss tail LDP from descriptor16, LDR items328, ADD offset17 shifted3.
  a,b,c=words[end-1:end+2]
  assert (a&0xffc003e0)==0xa9400200,(at,'LDP',hex(a))
  assert (b&0xffffffe0)==0xf940a4e0,(at,'items',hex(b))
  assert (c&0xffe0fc00)==0x8b000c00,(at,'ADD',hex(c))
  target=end+3
  if at==start-1:target+=1
  assert at+delta==target+5,(at,delta,target)
  new=(z&~0xffffe0)|(((target-at)&0x7ffff)<<5);struct.pack_into('<I',raw,(at-1)*4,new)
  events.append({'branchWord':at,'oldTarget':at+delta,'actualMissEnd':target,'hchkStart':start,'hchkEnd':end,'flags':flags,'oldWord':hex(z),'newWord':hex(new)});break
path=D/'statemate-cached-target-repaired.bin';path.write_bytes(raw)
assert events
base=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation');br=json.loads((base/'ports-build.json').read_text());cr=json.loads((I/'ports-build.json').read_text());obs={};env=dict(os.environ,KEXE_FUEL='16777216',KEXE_STRUCTURED_REPORT='1');env.pop('KEXE_COMMAND',None)
for label,p,r in [('baseline',base/'ports/statemate/native.bin',br),('firstcandidate',I/'ports/statemate/native.bin',cr),('ownedTargetRepaired',path,cr)]:
 off=next(x['offset']for x in r['entries']if x['workload']=='statemate');q=subprocess.run(['/private/tmp/amu-private-length-clones-20261006/full-state-loader',str(p),str(off),'1','aarch64','-','4'],env=env,capture_output=True,text=True);obs[label]={'exit':q.returncode,'stdout':q.stdout.strip(),'stderr':q.stderr.strip()}
assert obs['baseline']!=obs['firstcandidate'];assert obs['baseline']==obs['ownedTargetRepaired'],obs
(D/'cached-target-control.json').write_text(json.dumps({'status':'PASS actual failing native candidate repaired solely at precisely bound cached-hit targets','events':events,'observations':obs,'mutantPath':str(path),'mutantSha256':hashlib.sha256(raw).hexdigest(),'primaryUnchanged':True,'notPromotion':True},indent=2)+'\n');print('PASS corrected branch targets',len(events),'original failure and complete fullstate equality confirmed')
