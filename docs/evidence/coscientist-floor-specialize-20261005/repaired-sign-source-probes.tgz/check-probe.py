from pathlib import Path
import subprocess,os,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-sign-signed-audit-20261005'); base=Path('/private/tmp/amu-wrapper-prototype-20261005')
loader=w/'kexe-loader';runner=Path('/private/tmp/amu-embench-compare-20261004/runner');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
report={'hypothesis':'scalar sign-extension wrapper inlining','rows':[]};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def compile(seed,src,d,symbols):
 d.mkdir(exist_ok=True,parents=True);out=d/'image.kseed'
 p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--','compile',str(src),'--target','aarch64-macos','--output',str(out)],env=env,capture_output=True,text=True);(d/'compile.log').write_text(p.stdout+p.stderr);assert p.returncode==0,(src,p.stdout,p.stderr)
 offsets={}
 for symbol in symbols:
  p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--','extract-native',str(out),'--symbol',symbol,'--output',str(d/'native.bin')],env=env,capture_output=True,text=True);(d/(symbol+'.extract.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(symbol,p.stderr);offsets[symbol]=int(re.search(r':offset (\d+)',p.stdout).group(1))
 return offsets
def run(d,off,n,fuel=16777216):
 e=dict(env,KEXE_FUEL=str(fuel));e.pop('KEXE_COMMAND',None)
 p=subprocess.run([str(loader),str(d/'native.bin'),str(off),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True)
 if p.returncode==0:
  value={'result':int(p.stdout.splitlines()[-1]),'contextFuelConsumed':None}
 else:
  assert 'KEXE_TRAP' in p.stderr,(n,fuel,p.returncode,p.stdout,p.stderr)
  value=None
 return {'exit':p.returncode,'value':value}
def wrap(x):
 x&=(1<<64)-1
 return x-(1<<64) if x>>63 else x
def sx(x,width):
 v=x&((1<<width)-1)
 return v-(1<<width) if v>=(1<<(width-1)) else v
for name,src,symbols,inputs in [('probe',w/'probe.kotoba',['sign1', 'sign2', 'sign8', 'sign16', 'sign24', 'sign31', 'sign32', 'high', 'constant', 'unsupported', 'tail', 'alias'],[-9223372036854775808, -4294967296, -2147483649, -2147483648, -65536, -32769, -32768, -129, -128, -1, 0, 1, 2, 127, 128, 255, 256, 32767, 32768, 65535, 65536, 2147483647, 2147483648, 4294967295, 4294967296, 9223372036854775807])]:
 a=w/(name+'-baseline');b=w/(name+'-candidate');oa=compile(base/'seed-4.bin',src,a,symbols);ob=compile(w/'seed-4.bin',src,b,symbols)
 cases=[(s,n) for s in symbols for n in inputs] if name=='probe' else [('bench',n) for n in inputs]+[('repeated-state',4096*n+i) for n in [1,2] for i in range(4096)]+[('bounds-probe',i) for i in [-1,0,4095,4096]]
 for s,n in cases:
  for fuel in [16777216,1,2,3,4,5]:
   x=run(a,oa[s],n,fuel);y=run(b,ob[s],n,fuel)
   assert x['exit']==y['exit'],(s,n,fuel,x,y)
   if x['value'] is not None:
    assert x['value']['result']==y['value']['result'] and x['value']['contextFuelConsumed']==y['value']['contextFuelConsumed'],(s,n,fuel,x,y)
   if fuel==16777216:
    expected=sx(n,int(s[4:])) if s.startswith('sign') else sx(n,16)+36 if s=='high' else wrap(n-2) if s=='constant' else ((n&65535)-65535 if (n&65535)>=32768 else n&65535) if s=='unsupported' else sx(n,32) if s=='tail' else wrap(n+sx(n,8)+sx(n,16))
    assert x['exit']==0 and x['value']['result']==expected,(s,n,x,expected)
   report['rows'].append({'source':name,'symbol':s,'input':n,'fuel':fuel,'exit':x['exit'],'result':None if x['value'] is None else x['value']['result'],'consumed':None if x['value'] is None else x['value']['contextFuelConsumed']})
 report[name]={'baselineBytes':(a/'native.bin').stat().st_size,'candidateBytes':(b/'native.bin').stat().st_size,'candidateSha256':sha(b/'native.bin'),'offsets':ob,'sourceSha256':sha(src)}
 print('PASS',name,report[name],flush=True)
 report['status']='in-progress';(w/'correctness.json').write_text(json.dumps(report,indent=2)+'\n')
report['executionAdapter']='signed-i64 native loader; exact count unavailable, positive fuel boundary differential only';report['status']='complete-signed-result-and-positive-fuel-boundary-parity';report['compilerGenerations']={str(n):sha(w/f'seed-{n}.bin') for n in [2,3,4]};assert len(set(report['compilerGenerations'].values()))==1
(w/'correctness.json').write_text(json.dumps(report,indent=2)+'\n')
