from pathlib import Path
import importlib.util,subprocess,os,re,json,types,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-floor-specialize-20261005');sp=importlib.util.spec_from_file_location('fx',r/'scripts/seed/a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
# Exact hand-written helper, with optional entry fuel and full wrapped i64 oracle.
body=[('LGET',0,1),('CONST',1,0),('CMP','CC-LT',0),('BRZ',0,'fq_else'),('CONST',0,0),('CONST',1,0),('LGET',2,1),('BIN','BOP-SUB',1),('LGET',2,2),('CONST',3,1),('BIN','BOP-SUB',2),('BIN','BOP-ADD',1),('LGET',2,2),('BIN','BOP-QUOT',1),('BIN','BOP-SUB',0),('BR','fq_exit'),('LABEL','fq_else'),('LGET',0,1),('LGET',1,2),('BIN','BOP-QUOT',0),('LABEL','fq_exit'),('RET',0)]
values=[m.MIN,m.MIN+1,m.MIN+127,m.MIN+255,m.MIN+4095,-65537,-32769,-257,-256,-255,-129,-128,-127,-2,-1,0,1,2,127,128,255,256,257,32768,m.MAX]
def expected(x,d):
 a=m.s64(m.s64(-x)+d-1) if x<0 else x
 q=abs(a)//d;q=-q if a<0 else q
 return m.s64(-q) if x<0 else q
for charged in [False,True]:
 name='fq_charged' if charged else 'fq_plain';b=[('FUEL',)] if charged else []
 b += [tuple(name+'_'+x if isinstance(x,str) and x.startswith('fq_') else x for x in row) for row in body]
 m.fx(name,2,2,b)
 for d in [2,4,128,256,4096]:
  caller='call_'+name+'_'+str(d);m.fx(caller,1,1,[('FUEL',),('FUEL',),('LGET',0,1),('CONST',1,d),('CALL',name,0,2),('RET',0)])
  for x in values:m.run(caller,[x],expected(x,d),fuel=3 if charged else 2)
  m.run(caller,[1],'trap',fuel=2 if charged else 1)
 m.fx('high_'+name,1,1,[('FUEL',),('FUEL',),('LGET',8,1),('CONST',9,256),('CALL',name,8,2),('RET',8)])
 for x in values:m.run('high_'+name,[x],expected(x,256),fuel=3 if charged else 2)
 m.fx('const_'+name,0,0,[('FUEL',),('FUEL',),('CONST',0,m.MIN),('CONST',1,256),('CALL',name,0,2),('RET',0)]);m.run('const_'+name,[],expected(m.MIN,256),fuel=3 if charged else 2)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800');loader=str(w/'kexe-loader');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];chunks=[]
for real in [False,True]:
 prefix='fixture-real' if real else 'fixture-test';src=w/(prefix+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real))
 for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(prefix+'.kseed'))]),('extract',['extract-native',str(w/(prefix+'.kseed')),'--symbol','main','--output',str(w/(prefix+'.bin'))])]:
  p=subprocess.run([loader,str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(prefix+'-'+label+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(label,p.stdout,p.stderr)
  if label=='extract':off=re.search(r':offset (\d+)',p.stdout).group(1)
 p=subprocess.run([loader,str(w/(prefix+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(prefix+'.stdout')).write_text(p.stdout);assert p.returncode==0,p.stderr;chunks.append(p.stdout)
assert m.blob_from(chunks[0])[0].rstrip(b'\0')==m.blob_from(chunks[1])[0].rstrip(b'\0') and m.blob_from(chunks[0])[1]==m.blob_from(chunks[1])[1]
d=w/'fixture-run/unit/41-a64gen';d.mkdir(parents=True,exist_ok=True);(d/'stdout').write_text(chunks[1]);os.environ['SEED_BUILD']=str(w/'fixture-run');original=m.subprocess.run

def run(args,**kw):
 if args[:2]==['zsh',m.R+'/scripts/seed/unit.sh']:return types.SimpleNamespace(returncode=0,stdout='native experimental fixture emitter already verified; byte golden untouched',stderr='')
 return original(args,**kw)
m.subprocess.run=run;assert m.runs(False)==0
blob,fns=m.blob_from(chunks[1]);names=[f[0] for f in m.FIX];audit={}
for name in ['call_fq_plain_2','call_fq_plain_256','call_fq_charged_4096','high_fq_plain']:
 f=names.index(name)+1;end=fns.get(f+1,int(re.search(r'words (\d+)',chunks[1]).group(1))*4);words=struct.unpack('<'+'I'*((end-fns[f])//4),blob[fns[f]:end]);bl=sum((x&0xfc000000)==0x94000000 for x in words);sdiv=sum((x&0xffe0fc00)==0x9ac00c00 for x in words);assert bl==sdiv==0,(name,bl,sdiv)
 audit[name]={'directBL':bl,'SDIV':sdiv,'bytes':end-fns[f]}
(w/'fixture-proof.json').write_text(json.dumps({'runs':len(m.RUNS),'fixtures':len(m.FIX),'realTestLayoutIdentical':True,'instructionAudit':audit},indent=2)+'\n');print('PASS exact floor-helper instruction audits',flush=True)
