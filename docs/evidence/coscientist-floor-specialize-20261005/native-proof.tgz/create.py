from pathlib import Path
import hashlib,json,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-floor-specialize-20261005');old=(r/'seed/41-a64gen.kotoba').read_text();g=old
shape=[('OP-LGET',0,1),('OP-CONST',1,0),('OP-CMP','CC-LT',0),('OP-BRZ',0,'le'),('OP-CONST',0,0),('OP-CONST',1,0),('OP-LGET',2,1),('OP-BIN','BOP-SUB',1),('OP-LGET',2,2),('OP-CONST',3,1),('OP-BIN','BOP-SUB',2),('OP-BIN','BOP-ADD',1),('OP-LGET',2,2),('OP-BIN','BOP-QUOT',1),('OP-BIN','BOP-SUB',0),('OP-BR','lx',0),('OP-LABEL','le',0),('OP-LGET',0,1),('OP-LGET',1,2),('OP-BIN','BOP-QUOT',0),('OP-LABEL','lx',0),('OP-RET',0,0),('OP-END','f',0)]
checks=[]
for j,(op,a,b) in enumerate(shape):
 checks.append(f'(and (= (gn-op M (+ q {j})) {op}) (= (gn-sir M (+ q {j}) IF-A) {a}) (= (gn-sir M (+ q {j}) IF-B) {b}) (= (gn-sir M (+ q {j}) IF-C) 0))')
helper=''';; Exact wrapped negative-quotient diamond; caller's divisor is an adjacent
;; constant 2^shift, shift 1..12. Token 2048+shift, optional fuel bit 512.
(defn- gn-floor-wrapper [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :i64
  (let [p (gn-fnf M f FF-SIR) k (gn-sir M (dec i) IF-B)]
    (if (or (< p 1) (not= n 2) (not= (gn-op M p) OP-FN)
            (not= (gn-sir M p IF-A) f) (not= (gn-sir M p IF-B) 2)
            (not= (gn-op M (dec i)) OP-CONST) (not= (gn-sir M (dec i) IF-A) (inc t))
            (< k 2) (> k 4096) (not= (bit-and k (dec k)) 0)) 0
      (let [fuel (if (= (gn-op M (inc p)) OP-FUEL) 1 0)
            q (gn-skiplab M (+ p 1 fuel)) le (gn-sir M (+ q 3) IF-B) lx (gn-sir M (+ q 15) IF-A)]
        (if (and (> le 0) (> lx 0) (not= le lx)
                 CHECKS)
            (+ 2048 (gn-tz k 0) (* fuel 512)) 0)))))
'''.replace('CHECKS','\n                 '.join(checks))
a='(defn- gn-call-wrapper [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :i64\n  (if (= (gn-op M (inc i)) OP-RES2) 0\n      (let [w (gn-wrapper M f t n)] (if (> w 0) w (gn-sign-wrapper M f n)))))'
b=helper+'''(defn- gn-call-wrapper [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :i64
  (if (= (gn-op M (inc i)) OP-RES2) 0
      (let [w (gn-wrapper M f t n) s (if (> w 0) w (gn-sign-wrapper M f n))]
        (if (> s 0) s (gn-floor-wrapper M i f t n)))))''';assert g.count(a)==1;g=g.replace(a,b)
a='(if (>= w 1024) (>= w 1536) (>= w 256))';b='(if (>= w 2048) (>= w 2560) (if (>= w 1024) (>= w 1536) (>= w 256)))';assert g.count(a)==1;g=g.replace(a,b)
a='(defn- gn-op-call [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :vector-i64'
helper='''(defn- gn-call-floor [M :vector-i64 i :i64 t :i64 w :i64] :vector-i64
  (let [shift (bit-and w 511) divisor (i64-shift-left 1 shift) mask (dec divisor)
        M1 (if (>= w 2560) (gn-op-fuel M) M)]
    (if (gn-isk M1 t gn-k-const)
      (let [v (gn-dv M1 t) z (+ (- 0 v) mask)]
        (gn-def M1 t gn-k-const (if (< v 0) (- 0 (quot z divisor)) (quot v divisor))))
      (let [s (gn-co M1 i t) d (gn-dreg M1 t s) x (gn-src M1 t 16 0)]
        (-> M1 (gn-protect t s) (gn-ldt t 16 0)
            (gn-emit (enc-cmp-i x 0)) (gn-emit (enc-bcond (enc-cond-ge) 9))
            (gn-emit (enc-sub-r 16 31 x)) (gn-emit (enc-add-i 16 16 mask))
            (gn-emit (gn-e-bf 0x93400000 17 16 63 63))
            (gn-emit (gn-e-bf 0x92400000 17 17 0 (dec shift)))
            (gn-emit (enc-add-r 16 16 17))
            (gn-emit (gn-e-bf 0x93400000 16 16 shift 63))
            (gn-emit (enc-sub-r d 31 16)) (gn-emit (enc-b 2))
            (gn-emit (gn-e-bf 0x93400000 d x shift 63)) (gn-fin t s d))))))
''';assert g.count(a)==1;g=g.replace(a,helper+a)
a='(cond (>= w 1024) (gn-call-sign M i t w)';b='(cond (>= w 2048) (gn-call-floor M i t w)\n         (>= w 1024) (gn-call-sign M i t w)';assert g.count(a)==1;g=g.replace(a,b)
(w/'41-a64gen-prototype.kotoba').write_text(g);files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];u=''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files);(w/'seed-unity.kotoba').write_text(u);(w/'seed-unity.kotoba.sha256').write_text(hashlib.sha256(u.encode()).hexdigest()+'\n')
for ext in ['bin','offset']:shutil.copyfile(Path('/private/tmp/amu-sign-wrapper-20261005')/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile('/private/tmp/amu-sign-wrapper-20261005/kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['check-ports.py','bulk-state.py','remote.py']:
 s=Path('/private/tmp/amu-vector-descriptor2-20261005',name).read_text().replace('/private/tmp/amu-vector-descriptor2-20261005','/private/tmp/amu-floor-specialize-20261005').replace('/private/tmp/amu-zebulun-vector-descriptor2-20261005','/private/tmp/amu-zebulun-floor-specialize-20261005');(w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'hypothesis':'Exact SIR wrapped-negative-quotient diamond with adjacent known divisor 2^k, k1..12, permits inlining and removal of dynamic division while retaining wrapped MIN/near-MIN source behavior.','promotion':'Fresh 30 rotating baseline/candidate/C triples; >=1.05 speedup and gap>sumSD, unchanged policy and native correctness gates.','sourceHead':'2c05aa000aee64853fd991135d3da14e4ab11413','exception':'One-off compiler algorithm authoring, no mechanical refactor'},indent=2)+'\n')
