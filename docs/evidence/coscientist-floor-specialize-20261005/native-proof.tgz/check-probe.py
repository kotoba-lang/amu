from pathlib import Path
import subprocess,os,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-floor-specialize-20261005'); base=Path('/private/tmp/amu-sign-wrapper-20261005')
loader=w/'kexe-loader';runner=Path('/private/tmp/amu-embench-compare-20261004/runner');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
report={'hypothesis':'wrapped quotient helper specialization','rows':[]};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def compile(seed,src,d,symbols):
 d.mkdir(exist_ok=True,parents=True);out=d/'image.kseed'
 p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--','compile',str(src),'--target','aarch64-macos','--output',str(out)],env=env,capture_output=True,text=True);(d/'compile.log').write_text(p.stdout+p.stderr);assert p.returncode==0,(src,p.stdout,p.stderr)
 offsets={}
 for symbol in symbols:
  p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--','extract-native',str(out),'--symbol',symbol,'--output',str(d/'native.bin')],env=env,capture_output=True,text=True);(d/(symbol+'.extract.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(symbol,p.stderr);offsets[symbol]=int(re.search(r':offset (\d+)',p.stdout).group(1))
 return offsets
def run(d,off,n,fuel=16777216):
 e=dict(env,KEXE_FUEL=str(fuel));e.pop('KEXE_COMMAND',None)
 p=subprocess.run([str(loader),str(d/'native.bin'),str(off),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True)
 if p.returncode==0:
  value={'result':int(p.stdout.splitlines()[-1]),'contextFuelConsumed':None}
 else:
  assert 'KEXE_TRAP' in p.stderr,(n,fuel,p.returncode,p.stdout,p.stderr)
  value=None
 return {'exit':p.returncode,'value':value}
values=[-9223372036854775808,-9223372036854775807,-9223372036854775681,-9223372036854775553,-9223372036854771713,-65537,-32769,-257,-256,-255,-129,-128,-127,-2,-1,0,1,2,127,128,255,256,257,32768,9223372036854775807]
symbols=['fq'+str(d) for d in [1,2,4,128,256,4096,8192,3]]+['constant','high','alias','dynamic','nonmatch']
forms=['(defn- floor-quot [x :i64 divisor :i64] :i64 (if (< x 0) (- 0 (quot (+ (- 0 x) (- divisor 1)) divisor)) (quot x divisor)))','(defn- almost [x :i64 divisor :i64] :i64 (if (< x 0) (- 0 (quot (+ (- 0 x) (- divisor 2)) divisor)) (quot x divisor)))']
for d in [1,2,4,128,256,4096,8192,3]:forms.append(f'(defn fq{d} [x :i64] :i64 (floor-quot x {d}))')
forms+=['(defn constant [x :i64] :i64 (floor-quot -9223372036854775808 256))','(defn high [x :i64] :i64 '+ '(+ x '*9+'(floor-quot x 256)'+')'*9+')','(defn alias [x :i64] :i64 (let [a x b (floor-quot x 256)] (+ a b)))','(defn dynamic [x :i64] :i64 (floor-quot x (+ (bit-and x 7) 1)))','(defn nonmatch [x :i64] :i64 (almost x 256))']
src=w/'probe.kotoba';src.write_text('(ns probe (:export ['+' '.join(symbols)+']))\n'+'\n'.join(forms)+'\n')
def signed(x):
 x&=(1<<64)-1
 return x-(1<<64) if x>>63 else x
def hand(x,d,delta=1):
 a=signed(signed(-x)+d-delta) if x<0 else x;q=abs(a)//d;q=-q if a<0 else q
 return signed(-q) if x<0 else q
for name,src,symbols,inputs in [('probe',src,symbols,values)]:
 a=w/(name+'-baseline');b=w/(name+'-candidate');oa=compile(base/'seed-4.bin',src,a,symbols);ob=compile(w/'seed-4.bin',src,b,symbols)
 cases=[(s,n) for s in symbols for n in inputs] if name=='probe' else [('bench',n) for n in inputs]+[('repeated-state',4096*n+i) for n in [1,2] for i in range(4096)]+[('bounds-probe',i) for i in [-1,0,4095,4096]]
 for s,n in cases:
  for fuel in [16777216,1,2,3,4,5]:
   x=run(a,oa[s],n,fuel);y=run(b,ob[s],n,fuel)
   assert x['exit']==y['exit'],(s,n,fuel,x,y)
   if x['value'] is not None:
    assert x['value']['result']==y['value']['result'] and x['value']['contextFuelConsumed']==y['value']['contextFuelConsumed'],(s,n,fuel,x,y)
   if fuel==16777216:
    assert x['exit']==0,(s,n,x)
    expected=hand(n,int(s[2:])) if s.startswith('fq') else hand(-(1<<63),256) if s=='constant' else signed(9*n+hand(n,256)) if s=='high' else signed(n+hand(n,256)) if s=='alias' else hand(n,(n&7)+1) if s=='dynamic' else hand(n,256,2)
    assert x['value']['result']==expected,(s,n,x,expected)
   report['rows'].append({'source':name,'symbol':s,'input':n,'fuel':fuel,'exit':x['exit'],'result':None if x['value'] is None else x['value']['result'],'consumed':None if x['value'] is None else x['value']['contextFuelConsumed']})
 report[name]={'baselineBytes':(a/'native.bin').stat().st_size,'candidateBytes':(b/'native.bin').stat().st_size,'candidateSha256':sha(b/'native.bin'),'offsets':ob,'sourceSha256':sha(src)}
 print('PASS',name,report[name],flush=True)
 report['executionAdapter']='native signed-i64 loader; context fuel count unavailable; exact counts separately measured for canonical workloads';report['status']='in-progress';(w/'correctness.json').write_text(json.dumps(report,indent=2)+'\n')
report['status']='complete-signed-result-and-positive-fuel-boundary-parity';report['compilerGenerations']={str(n):sha(w/f'seed-{n}.bin') for n in [2,3,4]};assert len(set(report['compilerGenerations'].values()))==1
(w/'correctness.json').write_text(json.dumps(report,indent=2)+'\n')
