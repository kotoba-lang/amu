import pathlib,json,hashlib,shutil,subprocess,os,tarfile
old=pathlib.Path('/private/tmp/amu-zebulun-paired-20261005');prior=pathlib.Path('/private/tmp/amu-zebulun-wrapper-suite-20261005');root=pathlib.Path('/private/tmp/amu-zebulun-sign-changed-20261005');root.mkdir()
with tarfile.open('/private/tmp/amu-sign-changed-payload-20261005.tgz') as t:t.extractall(root/'candidate')
o=json.loads((old/'measurement-2/results.json').read_text());b=root/'baseline';b.mkdir();entries=[];sources={}
for name in ['statemate','wikisort']:
 d=b/name;d.mkdir();p=prior/'timing'/name/'results.json';r=json.loads(p.read_text());assert r['status']=='complete-provisional-candidate-timing' and r['summary']['stable'];e=next(x for x in o['entries'] if x['workload']==name);shutil.copyfile(prior/'candidate-ports'/name/'native.bin',d/'native.bin');shutil.copyfile(old/'measurement-2'/name/'c.dylib',d/'c.dylib');entries.append({**e,'offset':r['manifest']['offset'],'nativeSha256':r['manifest']['nativeSha256']});sources[name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'report':r}
(b/'results.json').write_text(json.dumps({'status':'complete-provisional-timing','runnerSha256':o['runnerSha256'],'matrixSpecSha256':o['matrixSpecSha256'],'entries':entries,'sourceReports':sources,'derivation':'wrapper code baseline; all three arms measured anew','officialEmbenchScore':False},indent=2)+'\n')
(root/'timing').mkdir();env=dict(os.environ,PYTHONPATH=str(old/'repo/scripts/seed/image'))
for name in ['statemate','wikisort']:
 print('START',name,flush=True);subprocess.run(['python3','/private/tmp/amu-zebulun-integrated-20261005/measure-native-candidate-v2.py',str(b),str(root/'candidate'/name),str(old/'environment/runner'),str(old/'repo/bench/embench/paired-timing-spec.json'),str(root/'timing'/name)],env=env,check=True)
