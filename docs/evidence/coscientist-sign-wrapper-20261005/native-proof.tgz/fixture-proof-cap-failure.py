from pathlib import Path
import importlib.util,subprocess,os,re,json,types,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-sign-wrapper-20261005');sp=importlib.util.spec_from_file_location('fx',r/'scripts/seed/a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
for width,charged in [(1,False),(8,False),(16,False),(32,False),(8,True)]:
 name=f'sx{width}'+('_fuel' if charged else '')
 mask=(1<<width)-1;half=1<<(width-1);mod=1<<width
 body=[('FUEL',)] if charged else []
 body += [('LGET',0,1),('CONST',1,mask),('BIN','BOP-AND',0),('LSET',2,0),('LGET',0,2),('CONST',1,half),('CMP','CC-GE',0),('BRZ',0,name+'_else'),('LGET',0,2),('CONST',1,mod),('BIN','BOP-SUB',0),('BR',name+'_exit'),('LABEL',name+'_else'),('LGET',0,2),('LABEL',name+'_exit'),('RET',0)]
 m.fx(name,1,2,body)
 caller='caller_'+name;m.fx(caller,1,1,[('FUEL',),('LGET',0,1),('CALL',name,0,1),('RET',0)])
 for n in [m.MIN,-(1<<32),-65536,-32769,-129,-128,-1,0,1,127,128,255,32768,65535,2147483648,m.MAX]:
  v=n&mask;expect=v-mod if v>=half else v;m.run(caller,[n],expect,fuel=2 if charged else 1)
 m.run(caller,[1],'trap',fuel=1 if charged else 0)
m.fx('caller_sx_high',1,1,[('FUEL',),('LGET',8,1),('CALL','sx16',8,1),('RET',8)])
for n in [-32769,-32768,-1,0,32767,32768,m.MAX]:
 v=n&65535;m.run('caller_sx_high',[n],v-65536 if v>=32768 else v,fuel=1)
m.fx('caller_sx_const',0,0,[('FUEL',),('CONST',0,65535),('CALL','sx16',0,1),('RET',0)]);m.run('caller_sx_const',[],-1,fuel=1)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800');loader=str(w/'kexe-loader');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];chunks=[]
for real in [False,True]:
 prefix='fixture-real' if real else 'fixture-test';src=w/(prefix+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real))
 for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(prefix+'.kseed'))]),('extract',['extract-native',str(w/(prefix+'.kseed')),'--symbol','main','--output',str(w/(prefix+'.bin'))])]:
  p=subprocess.run([loader,str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(prefix+'-'+label+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(label,p.stdout,p.stderr)
  if label=='extract':off=re.search(r':offset (\d+)',p.stdout).group(1)
 p=subprocess.run([loader,str(w/(prefix+'.bin')),off,'0','aarch64','37','--'],env=env,capture_output=True,text=True);(w/(prefix+'.stdout')).write_text(p.stdout);assert p.returncode==0,p.stderr;chunks.append(p.stdout)
assert m.blob_from(chunks[0])[0].rstrip(b'\0')==m.blob_from(chunks[1])[0].rstrip(b'\0') and m.blob_from(chunks[0])[1]==m.blob_from(chunks[1])[1]
d=w/'fixture-run/unit/41-a64gen';d.mkdir(parents=True,exist_ok=True);(d/'stdout').write_text(chunks[1]);os.environ['SEED_BUILD']=str(w/'fixture-run');original=m.subprocess.run

def run(args,**kw):
 if args[:2]==['zsh',m.R+'/scripts/seed/unit.sh']:return types.SimpleNamespace(returncode=0,stdout='native experimental fixture emitter already verified; byte golden untouched',stderr='')
 return original(args,**kw)
m.subprocess.run=run;assert m.runs(False)==0
blob,fns=m.blob_from(chunks[1]);names=[f[0] for f in m.FIX];audit={}
for name in ['caller_sx1','caller_sx8','caller_sx16','caller_sx32','caller_sx8_fuel','caller_sx_high']:
 f=names.index(name)+1;end=fns.get(f+1,int(re.search(r'words (\d+)',chunks[1]).group(1))*4);words=struct.unpack('<'+'I'*((end-fns[f])//4),blob[fns[f]:end]);bl=sum((x&0xfc000000)==0x94000000 for x in words);sbfm=sum((x&0xffc00000)==0x93400000 for x in words);assert bl==0 and sbfm==1,(name,bl,sbfm);audit[name]={'directBL':bl,'SBFM':sbfm,'bytes':end-fns[f]}
(w/'fixture-proof.json').write_text(json.dumps({'runs':len(m.RUNS),'fixtures':len(m.FIX),'realTestLayoutIdentical':True,'instructionAudit':audit},indent=2)+'\n');print('PASS exact sign-extension instruction audits',flush=True)
