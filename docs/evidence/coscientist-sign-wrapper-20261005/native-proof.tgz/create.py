from pathlib import Path
import hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-sign-wrapper-20261005');old=(r/'seed/41-a64gen.kotoba').read_text();g=old
anchor='(defn- gn-call-wrapper [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :i64\n  (if (= (gn-op M (inc i)) OP-RES2) 0 (gn-wrapper M f t n)))'
new=''';; Exact scalar sign-extension decision tree: mask, local, signed >= half,
;; subtract modulus on the high half, join and return. Width 1..32 only.
;; Token 1024 + width; bit 9 records the original optional entry fuel.
(defn- gn-sign-wrapper [M :vector-i64 f :i64 n :i64] :i64
  (let [p (gn-fnf M f FF-SIR)]
    (if (or (< p 1) (not= n 1) (not= (gn-op M p) OP-FN)
            (not= (gn-sir M p IF-A) f) (not= (gn-sir M p IF-B) 1)) 0
      (let [fuel (if (= (gn-op M (inc p)) OP-FUEL) 1 0)
            q (gn-skiplab M (+ p 1 fuel)) mask (gn-sir M (inc q) IF-B)
            half (quot (inc mask) 2) slot (gn-sir M (+ q 3) IF-A)
            le (gn-sir M (+ q 7) IF-B) lx (gn-sir M (+ q 11) IF-A)]
        (if (and (> mask 0) (<= mask 4294967295) (= (bit-and mask (inc mask)) 0)
                 (= (gn-op M q) OP-LGET) (= (gn-sir M q IF-A) 0) (= (gn-sir M q IF-B) 1)
                 (= (gn-op M (inc q)) OP-CONST) (= (gn-sir M (inc q) IF-A) 1)
                 (= (gn-op M (+ q 2)) OP-BIN) (= (gn-sir M (+ q 2) IF-A) BOP-AND) (= (gn-sir M (+ q 2) IF-B) 0)
                 (= (gn-op M (+ q 3)) OP-LSET) (> slot 1) (= (gn-sir M (+ q 3) IF-B) 0)
                 (= (gn-op M (+ q 4)) OP-LGET) (= (gn-sir M (+ q 4) IF-A) 0) (= (gn-sir M (+ q 4) IF-B) slot)
                 (= (gn-op M (+ q 5)) OP-CONST) (= (gn-sir M (+ q 5) IF-A) 1) (= (gn-sir M (+ q 5) IF-B) half)
                 (= (gn-op M (+ q 6)) OP-CMP) (= (gn-sir M (+ q 6) IF-A) CC-GE) (= (gn-sir M (+ q 6) IF-B) 0)
                 (= (gn-op M (+ q 7)) OP-BRZ) (= (gn-sir M (+ q 7) IF-A) 0) (> le 0)
                 (= (gn-op M (+ q 8)) OP-LGET) (= (gn-sir M (+ q 8) IF-A) 0) (= (gn-sir M (+ q 8) IF-B) slot)
                 (= (gn-op M (+ q 9)) OP-CONST) (= (gn-sir M (+ q 9) IF-A) 1) (= (gn-sir M (+ q 9) IF-B) (inc mask))
                 (= (gn-op M (+ q 10)) OP-BIN) (= (gn-sir M (+ q 10) IF-A) BOP-SUB) (= (gn-sir M (+ q 10) IF-B) 0)
                 (= (gn-op M (+ q 11)) OP-BR) (> lx 0) (not= le lx)
                 (= (gn-op M (+ q 12)) OP-LABEL) (= (gn-sir M (+ q 12) IF-A) le)
                 (= (gn-op M (+ q 13)) OP-LGET) (= (gn-sir M (+ q 13) IF-A) 0) (= (gn-sir M (+ q 13) IF-B) slot)
                 (= (gn-op M (+ q 14)) OP-LABEL) (= (gn-sir M (+ q 14) IF-A) lx)
                 (= (gn-op M (+ q 15)) OP-RET) (= (gn-sir M (+ q 15) IF-A) 0)
                 (= (gn-op M (+ q 16)) OP-END))
          (+ 1024 (gn-tz (inc mask) 0) (* fuel 512)) 0)))))
(defn- gn-call-wrapper [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :i64
  (if (= (gn-op M (inc i)) OP-RES2) 0
      (let [w (gn-wrapper M f t n)] (if (> w 0) w (gn-sign-wrapper M f n)))))
''';assert g.count(anchor)==1;g=g.replace(anchor,new)
a='(if (> w 0) (if (>= w 256) (gn-gs M gn-f-fuel 1) M)';b='(if (> w 0) (if (if (>= w 1024) (>= w 1536) (>= w 256)) (gn-gs M gn-f-fuel 1) M)';assert g.count(a)==1;g=g.replace(a,b)
a='(defn- gn-op-call [M :vector-i64 i :i64 f :i64 t :i64 n :i64] :vector-i64';helpers='''(defn- gn-call-sign [M :vector-i64 i :i64 t :i64 w :i64] :vector-i64
  (let [width (bit-and w 511) modulus (i64-shift-left 1 width)
        M1 (if (>= w 1536) (gn-op-fuel M) M)]
    (if (gn-isk M1 t gn-k-const)
      (let [v (bit-and (gn-dv M1 t) (dec modulus))]
        (gn-def M1 t gn-k-const (if (>= v (quot modulus 2)) (- v modulus) v)))
      (let [s (gn-co M1 i t) d (gn-dreg M1 t s) x (gn-src M1 t 16 1)]
        (-> M1 (gn-protect t s) (gn-ldt t 16 1)
            (gn-emit (gn-e-bf 0x93400000 d x 0 (dec width))) (gn-fin t s d))))))
''';assert g.count(a)==1;g=g.replace(a,helpers+a)
a='(cond (> w 0) (let [M1';b='(cond (>= w 1024) (gn-call-sign M i t w)\n         (> w 0) (let [M1';assert g.count(a)==1;g=g.replace(a,b)
(w/'41-a64gen-prototype.kotoba').write_text(g)
u=Path('/private/tmp/amu-wrapper-prototype-20261005/seed-unity.kotoba').read_text();assert u.count(old)==1;u=u.replace(old,g);(w/'seed-unity.kotoba').write_text(u);(w/'seed-unity.kotoba.sha256').write_text(hashlib.sha256(u.encode()).hexdigest()+'\n')
for ext in ['bin','offset']:(w/f'seed-0.{ext}').write_bytes(Path(f'/private/tmp/amu-wrapper-prototype-20261005/seed-4.{ext}').read_bytes())
for name in ['check-ports.py','bulk-state.py']:
 s=Path('/private/tmp/amu-masked-wrapper-20261005',name).read_text().replace('/private/tmp/amu-masked-wrapper-20261005','/private/tmp/amu-sign-wrapper-20261005');(w/name).write_text(s)
print('sign-extension prototype ready')
