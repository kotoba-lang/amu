import pathlib,json,subprocess,hashlib
r=pathlib.Path('/Users/junkawasaki/github/wt/amu-seed17');w=pathlib.Path('/private/tmp/amu-sign-wrapper-integrated-20261005');matrix=json.loads((r/'bench/embench/comparison-matrix.json').read_text());proof=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for e in matrix['entries']:
 d=w/'ports'/e['workload'];d.mkdir(parents=True);source=r/e['source'];assert sha(source)==e['expectedSourceSha256']
 for label,args in [('check',['check',str(source)]),('compile',['compile',str(source),'--target','aarch64-macos','--output',str(d/'image.kexe')]),('extract',['extract-native',str(d/'image.kexe'),'--symbol',e['symbol'],'--output',str(d/'native.bin')])]:
  p=subprocess.run([str(w/'g3/amu'),*args],capture_output=True,text=True);(d/(label+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(e['workload'],label,p.stdout,p.stderr)
 assert sha(d/'native.bin')==sha(pathlib.Path('/private/tmp/amu-sign-wrapper-20261005/ports-2')/e['workload']/'native.bin'),e['workload'];proof.append({'workload':e['workload'],'sourceSha256':sha(source),'nativeSha256':sha(d/'native.bin')});print('PASS',e['workload'],flush=True)
(w/'ports.json').write_text(json.dumps({'status':'complete-19-integrated-native-machine-parity','entries':proof},indent=2)+'\n')
