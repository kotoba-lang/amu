from pathlib import Path
import subprocess
s=Path('build/coscientist-aes/nettle-aes.kotoba').read_text()
for name,old,new in [('no-rounds','(blocks (rounds next mode 1 w0 w1 w2 w3) mode test (+ block 1))','(blocks next mode test (+ block 1))'),('one-block','(blocks (rounds next mode 1 w0 w1 w2 w3) mode test (+ block 1))','(rounds next mode 1 w0 w1 w2 w3)'),('no-scratch','next (vector-assoc! s 634 input)','next s')]:
 assert s.count(old)==1;p=Path('build/coscientist-aes/diagnostic-'+name+'.kotoba');p.write_text(s.replace(old,new));r=subprocess.run(['build/seed17/g3/amu','check',str(p)],capture_output=True,text=True);print(name,r.stdout,r.stderr)
