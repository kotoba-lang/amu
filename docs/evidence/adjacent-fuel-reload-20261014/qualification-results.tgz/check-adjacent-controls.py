from pathlib import Path
import json,hashlib,subprocess,os,importlib.util,re
W=Path(__file__).parent;D=W/'adjacent-controls-v3';D.mkdir(exist_ok=False);A=D/'artifacts';A.mkdir();raw=D/'raw';raw.mkdir()
S=A/'controls.kotoba';S.write_text("""(ns adjacent-charge-controls (:export [run lower branch]))
(defn lower [c :i64] :i64 (if (and (>= c 65) (<= c 90)) (+ c 32) c))
(defn- pattern [a :i64 b :i64 flags :i64] :i64
 (if (= a 124) -4 (if (= a 36) -1 (if (= a 46) 1
  (if (= (bit-and flags 1) 1) (if (= (lower a) (lower b)) 1 -1) (if (= a b) 1 -1))))))
(defn run [x :i64] :i64 (pattern (bit-and x 255) (bit-and (i64-shift-right x 8) 255) (bit-and (i64-shift-right x 16) 1)))
(defn branch [x :i64] :i64
 (if (= x 0) 11 (if (= x 1) 12 (if (= x 2) 13 (if (= x 3) 14 (if (= x 4) 15 -7))))))
""")
L=W.parent/'embench-pf-twoarg-20261013/protected-host/kexe-loader';P={'OFF':W.parent/'seed-nonzero-guard-charge-20261014/selfbuild-v1/host/G4.bin','ON':W/'compiler-only-v3/artifacts/candidate.bin'}
def pin(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
assert pin(P['OFF'])['sha256']=='87d29d354142b3391abd475211ddd6a677c4e1f18ea0c74c72ffa450cf16eb56';assert pin(P['ON'])['sha256']==json.loads((W/'selfhost-qualified-v3.json').read_text())['nativeSHA256']
pins={p:pin(p)for p in [L,S,*P.values()]};calls=[]
env={k:v for k,v in os.environ.items()if not k.startswith('KEXE_')};env.update(KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(A),KEXE_FUEL='off',KEXE_VECTORS='4194304',KEXE_VECTOR_ITEMS='134217728',KEXE_STRING_POOL='268435456',KEXE_PAIRS='16777216',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',TMPDIR=str(A))
def call(tag,args,e):
 z=subprocess.run(list(map(str,args)),cwd=D,env=e,capture_output=True,timeout=1800);(raw/(tag+'.stdout')).write_bytes(z.stdout);(raw/(tag+'.stderr')).write_bytes(z.stderr);calls.append(dict(tag=tag,exit=z.returncode));(D/'calls.json').write_text(json.dumps(calls,indent=2)+'\n');assert all(pin(p)==v for p,v in pins.items());return z.returncode,z.stdout,z.stderr
arms={}
for tag,p in P.items():
 k=A/(tag+'.kseed');b=A/(tag+'.bin');base=[L,p,'0','0','aarch64','35,37,38,39','--']
 for name,args in [('compile',['compile',S,'--target','aarch64-macos','--output',k]),('extract',['extract-native',k,'--symbol','run','--output',b])]:
  code,_,err=call(tag+'-'+name,base+args,env);assert code==0 and not err
 h,payload=k.read_bytes().split(b'\n\n',1);assert payload==b.read_bytes();ex={n:[int(o),int(a)]for n,o,a in map(str.split,h.decode().splitlines()[1:])};assert all(a==1 for _,a in ex.values());arms[tag]=dict(native=pin(b),container=pin(k),source=pin(S),exports=ex)
spec=importlib.util.spec_from_file_location('fuel_physical',W/'native-gate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);proof=m.audit(arms['OFF'],arms['ON']);(D/'physical-proof.json').write_text(json.dumps(proof,indent=2)+'\n');assert proof['changed'] and len(proof['sites'])>=1,'No generic changed site: save before guests'
def lower(x):return x+32 if 65<=x<=90 else x
def oracle(symbol,x):
 if symbol=='lower':return lower(x)
 if symbol=='branch':return 11+x if 0<=x<=4 else -7
 a=x&255;b=(x>>8)&255;f=(x>>16)&1
 return -4 if a==124 else -1 if a==36 else 1 if a==46 else 1 if (lower(a)==lower(b)if f else a==b)else -1
cases=[]
xs=[-(1<<63),-1,0,1,2,3,4,5,64,65,90,91,(1<<63)-1]
for symbol in ['lower','branch']:
 for x in xs:cases.append(dict(symbol=symbol,x=x,fuel=100000,result=oracle(symbol,x)))
for a,b,f in [(124,0,0),(36,36,0),(46,0,1),(65,97,1),(65,97,0),(97,65,1),(0,0,0),(255,255,0),(255,0,1),(90,122,1),(91,123,1)]:
 x=a+(b<<8)+(f<<16);cases.append(dict(symbol='run',x=x,fuel=100000,result=oracle('run',x)))
for symbol,x in [('lower',65),('branch',4),('branch',5),('run',65+(97<<8)+(1<<16))]:
 for fuel in range(1,65):cases.append(dict(symbol=symbol,x=x,fuel=fuel,result=oracle(symbol,x)))
for symbol in ['lower','branch','run']:cases.append(dict(symbol=symbol,x=0,fuel=(1<<53)-1,result=oracle(symbol,0)))
(D/'cases.json').write_text(json.dumps(dict(cases=cases),indent=2)+'\n');guest={k:v for k,v in env.items()if not k.startswith('KEXE_')};guest.update(KEXE_ARENA_USE='1',KEXE_STRUCTURED_REPORT='1',KEXE_CPU_SECONDS='60',KEXE_WALL_SECONDS='60',TMPDIR=str(A));rows=[]
for i,c in enumerate(cases):
 pair=[];guest['KEXE_FUEL']=str(c['fuel'])
 for tag,a in arms.items():
  off,arity=a['exports'][c['symbol']];code,o,e=call(f'{i}-{tag}',[L,a['native']['path'],off,arity,'aarch64','37',c['x']],guest)
  if b':status :ok'in o:
   value=re.search(rb':result (-?\d+)',o);assert code==0 and value and int(value[1])==c['result']
  else:assert code==120 and b':status :trap :exit 120'in o and b':SIGTRAP'in e and b'budget/fuel'in e and c['fuel']<=64 and re.search(rb':remaining 0\}',o)
  fuel=re.search(rb':fuel \{:initial (\d+) :remaining (\d+)\}',o);assert fuel and int(fuel[1])==c['fuel']and 0<=int(fuel[2])<=c['fuel']and len(re.findall(rb':[a-z-]+ \d+',e))==17
  pair.append((code,o,e))
 assert pair[0]==pair[1],('ADJACENT_CHARGE_RAW_PARITY',c);rows.append(dict(**c,exit=pair[0][0]))
(D/'report.json').write_text(json.dumps(dict(status='PASS_ADJACENT_CONTROLS_RAW_FUEL1_64_MAX53_ALL17',pairs=len(rows),guestCalls=len(rows)*2,compilerCalls=4,changedSites=len(proof['sites']),rows=rows,adopted=False,performanceMeasured=False),indent=2)+'\n');print('PASS_ADJACENT_CONTROLS',len(rows),'pairs',len(proof['sites']),'sites')
