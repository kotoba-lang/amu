from pathlib import Path
import struct,json,hashlib,importlib.util
s=importlib.util.spec_from_file_location('utils',Path(__file__).with_name('native-utils.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def audit(old,new):
 A,ae=m.payload(old);B,be=m.payload(new);assert ae==be and len(A)==len(B)
 assert Path(old['source']['path']).read_bytes()==Path(new['source']['path']).read_bytes()
 if A==B:return dict(status='WHOLE_IDENTITY',changed=False)
 pool,entries=m.source_pool(Path(new['source']['path']).read_bytes());end=len(A)-len(pool);assert end%4==0
 if pool:assert A[end:]==B[end:]==pool
 a=struct.unpack('<'+'I'*(end//4),A[:end]);b=struct.unpack('<'+'I'*(end//4),B[:end]);roots={x[0]for x in ae.values()};refs=[]
 for i,z in enumerate(a):
  r=m.ref(z,i*4)
  if r:roots.add(r[1]);refs.append(dict(pc=i*4,kind=r[0],target=r[1]));assert m.ref(b[i],i*4)==r
  assert z&0xfffffc1f not in [0xd61f0000,0xd63f0000],('INDIRECT_CONTROL_WITHOUT_OWNERSHIP',i*4)
 sites=[]
 for i,(z,v)in enumerate(zip(a,b)):
  if z==v:continue
  p=i*4;assert z==0xf94004f0 and v==0xd503201f and i>0 and i+3<len(a)
  assert a[i-1]==b[i-1]==0xf90004f0 and a[i+1]==b[i+1]==0xf1000610
  assert p not in roots,('DIRECT_OR_ADDRESS_ENTRY_AT_REMOVED_LOAD',p)
  assert (a[i+2]==0x54000042 and a[i+3]==0xd4200000)or a[i+2]&0xff00001f==0x54000003
  assert a[i+2:i+4]==b[i+2:i+4]
  sites.append(dict(pc=p,priorStorePC=p-4,storedLoadedRegister=16,contextRegister=7,contextByteOffset=8,originalSubtractionPC=p+4,flagsUnchanged=True,allPublicationAndTrapWordsUnchanged=True,noInterveningInstruction=True,loadNotAnyDirectOrAddressRoot=True))
 assert sites
 return dict(status='PASS_ALL_WORDS_SAME_LAYOUT_ADJACENT_STR16_LDR16_NOP_FULL_ROOTS',changed=True,sites=sites,refs=refs,sourcePoolBytes=len(pool),exports=ae,completeOtherBytesIdentity=True,proof='Adjacent STR guarantees x16 equals CTXfuel. No alternate reachable entry into NOP. Register/flags/memory and every original successful publication/exhaustion path unchanged. Existing compiler closed source rejects FADDR/CALLI/CAP. No indirect emitted control accepted.',adopted=False,performanceMeasured=False)
