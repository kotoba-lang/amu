import pathlib,json,hashlib,tarfile,shutil,subprocess,os
old=pathlib.Path('/private/tmp/amu-zebulun-paired-20261005');first=pathlib.Path('/private/tmp/amu-zebulun-integrated-20261005');root=pathlib.Path('/private/tmp/amu-zebulun-wrapper-20261005');root.mkdir()
with tarfile.open('/private/tmp/amu-wrapper-candidate-20261005.tgz') as t:t.extractall(root)
r=json.loads((first/'timing/statemate/results.json').read_text());assert r['status']=='complete-provisional-candidate-timing' and r['summary']['stable'];original=json.loads((old/'measurement-2/results.json').read_text());e=next(x for x in original['entries'] if x['workload']=='statemate');e={**e,'offset':r['manifest']['offset'],'nativeSha256':r['manifest']['nativeSha256']}
b=root/'derived-measured-baseline';d=b/'statemate';d.mkdir(parents=True);shutil.copyfile(first/'candidate-ports/statemate/native.bin',d/'native.bin');shutil.copyfile(old/'measurement-2/statemate/c.dylib',d/'c.dylib')
# This is a measured-arm projection, preserving source report and all triples.
# New experiment resamples all three arms; no previous timing samples are reused.
derived={'format':'amu.measured-candidate-arm-projection/v1','status':'complete-provisional-timing','runnerSha256':original['runnerSha256'],'matrixSpecSha256':original['matrixSpecSha256'],'entries':[e],'sourceReportSha256':hashlib.sha256((first/'timing/statemate/results.json').read_bytes()).hexdigest(),'sourceReport':r,'derivation':'candidate arm of completed integrated experiment is now the baseline machine code; C unchanged','officialEmbenchScore':False}
(b/'results.json').write_text(json.dumps(derived,indent=2)+'\n')
env=dict(os.environ,PYTHONPATH=str(old/'repo/scripts/seed/image'))
subprocess.run(['python3',str(first/'measure-native-candidate-v2.py'),str(b),str(root/'candidate'),str(old/'environment/runner'),str(old/'repo/bench/embench/paired-timing-spec.json'),str(root/'timing')],env=env,check=True)
