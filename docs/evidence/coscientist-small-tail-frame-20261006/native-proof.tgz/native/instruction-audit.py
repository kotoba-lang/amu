from pathlib import Path
import json
w=Path('/private/tmp/amu-small-tail-frame-20261006');old=Path('/private/tmp/amu-copy-forward-20261006/observer/meta-ports');new=w/'observer/meta-ports';rows=[]
for entry in json.loads((w/'ports-correctness.json').read_text())['entries']:
 name=entry['workload'];a=json.loads((old/name/'census.json').read_text());b=json.loads((new/name/'census.json').read_text());assert b['nativeSha256']==entry['nativeSha256'];assert a['sirCount']==b['sirCount'];assert a['functions'].keys()==b['functions'].keys();assert [s for s in (old/name/'compile.log').read_text().splitlines() if s.startswith('SIR ')]==[s for s in (new/name/'compile.log').read_text().splitlines() if s.startswith('SIR ')];mode=[];charges=0
 for f,fn in b['functions'].items():
  before=a['functions'][f]
  for key in ['start','end','locals','depth']:assert before[key]==fn[key]
  if fn['leaf']==2:
   assert before['leaf']==0 and before['frameBytes']>0;assert fn['frameBytes']==fn['localCalleeRegisters']==0;assert fn['locals']<=7 and fn['depth']<=7;mode.append(int(f))
   for ev in [v for v in b['events'] if v['fn']==int(f)]:
    if ev['op']=='OP-FN':assert ev['wordCount']==0,(name,f,ev)
    if ev['op']=='OP-FUEL':assert [int(s,16) for s in ev['words']]==[0xf94004f0,0xf1000610,0x54000042,0xd4200000,0xf90004f0],(name,f,ev);charges+=1
    assert not any((int(s,16)&0xfc000000)==0x94000000 or (int(s,16)&0xfffffc1f)==0xd63f0000 for s in ev['words']),(name,f,ev)
  else:
   for key in ['leaf','frameBytes','localCalleeRegisters']:assert before[key]==fn[key],(name,f,key)
 rows.append({'workload':name,'mode2Functions':len(mode),'functionIds':mode,'originalPublishedFuelEvents':charges,'oldCodeWords':a['codeWords'],'newCodeWords':b['codeWords'],'nativeSha256':entry['nativeSha256'],'unchangedSIR':True})
assert next(x for x in rows if x['workload']=='statemate')['mode2Functions']==391
(w/'instruction-audit.json').write_text(json.dumps({'status':'complete-actual-all19-frameless-terminal-register-and-published-fuel-instruction-audit','staticCountsNotTimeShares':True,'rows':rows},indent=2)+'\n');print([(x['workload'],x['mode2Functions'],x['oldCodeWords'],x['newCodeWords']) for x in rows])
