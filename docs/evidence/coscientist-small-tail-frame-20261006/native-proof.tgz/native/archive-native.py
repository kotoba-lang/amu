from pathlib import Path
import json,hashlib,tarfile,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-small-tail-frame-20261006');e=r/'docs/evidence/coscientist-small-tail-frame-20261006';e.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=w/'replay-timing-audit.py';p.write_text((w/'timing-audit.py').read_text().replace("w=Path('/private/tmp/amu-small-tail-frame-20261006');","w=Path(__file__).resolve().parent;"))
for name,roots in [('native-proof.tgz',[(w,'native')]),('timing-proof.tgz',[(w/'remote-evidence','remote-evidence'),(p,'replay-timing-audit.py')])]:
 with tarfile.open(e/name,'w:gz') as t:
  for root,label in roots:
   if root.is_file():t.add(root,arcname=label);continue
   for f in sorted(root.rglob('*')):
    if not f.is_file() or '__pycache__' in f.parts:continue
    rel=f.relative_to(root)
    if root==w and rel.parts[0] in ['remote-evidence','timing-package']:continue
    t.add(f,arcname=label+'/'+str(rel),recursive=False)
 assert (e/name).stat().st_size<100000000;print('ARCHIVE',name,(e/name).stat().st_size,flush=True)
with tarfile.open(e/'native-proof.tgz') as t:
 assert t.extractfile('native/41-a64gen-prototype.kotoba').read()==t.extractfile('native/committed-source/seed/41-a64gen.kotoba').read()==(r/'seed/41-a64gen.kotoba').read_bytes()
with tarfile.open(e/'timing-proof.tgz') as t:
 for name in json.loads((w/'preflight.json').read_text())['changedGuests']:
  assert 'remote-evidence/timing-package/'+name+'/timing/results.json' in t.getnames()
for name in ['hypothesis.json','generations.json','preflight.json','fixture-proof.json','invalid-handle-proof.json','mutation-proof.json','instruction-audit.json','timing-audit.json','permanent-prefix-audit.json','normal-unit-independent-audit.json','gate-summary.json','committed-unity-proof.json','committed-source-manifest.json','next-hypothesis.json','next-census.json','returning-call-census.json']:
 shutil.copy2(w/name,e/name)
print('PASS native measured-source linkage and all9 timing archives')
