from pathlib import Path
import json,importlib.util
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-small-tail-frame-20261006')
a=json.loads((w/'timing-audit.json').read_text());assert a['performanceAllowsFurtherAdoptionGates']
p=r/'scripts/seed/a64gen-fixtures.py';s=p.read_text();(w/'before-permanent-generator.py').write_text(s)
sp=importlib.util.spec_from_file_location('before',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);before=(m.FIX.copy(),m.RUNS.copy())
assert (r/'seed/41-a64gen.kotoba').read_bytes()==(w/'baseline-41-a64gen.kotoba').read_bytes()
(r/'seed/41-a64gen.kotoba').write_bytes((w/'41-a64gen-prototype.kotoba').read_bytes())
probe=(w/'fixture-proof.py').read_text();defs=probe[probe.index("m.fx('st_id'"):probe.index('fns,labels,lits,sir,frec=')].replace('m.fx(', 'fx(')
block='# Small terminal-only frames: independent scalar, branch, fuel and vector oracles.\nSMALL_TAIL_START=len(FIX)\n'+defs+'''
for name in ['st_scalar','st_wrap','st_branch','st_driver','st_ref_np2','st_ref_d8','st_ref_return','st_ref_driver']:
 for x in [0,1,-1,3,-7,17,MIN,MAX,65536]:
  value=s64(2*s64((x+7)*(x-5))+3) if name in ['st_scalar','st_wrap'] else 41 if name=='st_branch' and x==0 else s64(x+7) if name=='st_driver' else s64(3*x+3) if name=='st_ref_return' else 1 if name=='st_ref_driver' else s64(2*x+3)
  charges=3 if name in ['st_driver','st_ref_driver'] else 2
  for fuel in [1,2,3,4,5,16777216,(1<<53)-1]:
   run(name,[99,x] if name=='st_ref_np2' else [x],value if fuel>=charges else 'trap',fuel=fuel)

'''
s=s.replace('def kotoba(real_layout=False):',block+'def kotoba(real_layout=False):',1)
needle="    du_ids=[fns[c['name']] for c in DOT_UNROLL_CASES]"
helper='''    small_types={x[0]:('TY-VEC' if x[0] in ['st_vtarget','st_vec','st_alloc','st_ref_vec'] else 'TY-I64','TY-VEC' if x[0]=='st_alloc' else 'TY-I64') for x in FIX[SMALL_TAIL_START:]}
    o += ['(defn- t-small-types [M :vector-i64] :vector-i64',
          ' (-> M '+' '.join('(t-put '+str(C['MM-FN-BASE']+fns[name]*C['MM-FN-W']+fld)+' '+ty+')' for name,(pt,rt) in small_types.items() for fld,ty in [(C['FF-RTYPE'],rt)]+[(C['FF-PT0']+j,pt) for j in range(next(x[1] for x in FIX if x[0]==name))])+'))']
'''
assert s.count(needle)==1;s=s.replace(needle,helper+needle,1);assert s.count('        M1 (gn-run M0)')==1;s=s.replace('        M1 (gn-run M0)','        M1 (gn-run (t-small-types M0))',1);p.write_text(s)
sp=importlib.util.spec_from_file_location('after',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);assert m.FIX[:len(before[0])]==before[0] and m.RUNS[:len(before[1])]==before[1];m.gen()
(w/'permanent-prefix-audit.json').write_text(json.dumps({'originalFixtures':len(before[0]),'originalRuns':len(before[1]),'prefixExact':True,'fixtures':len(m.FIX),'runs':len(m.RUNS)},indent=2)+'\n');print('PASS durable fixture generator and exact original prefix',len(m.FIX),len(m.RUNS))
