from pathlib import Path
w=Path('/private/tmp/amu-small-tail-frame-20261006')
s=Path('/private/tmp/amu-tail-continuation-20261006/check-ports.py').read_text().replace('amu-tail-continuation-20261006','amu-small-tail-frame-20261006');(w/'check-ports.py').write_text(s)
for name in ['ports-state.py','resource-proof.py','permanent-regression.py']:
 s=Path('/private/tmp/amu-tail-continuation-20261006',name).read_text().replace('amu-tail-continuation-20261006','amu-small-tail-frame-20261006').replace("w/'clobber-full-state-loader'","w/'full-state-loader'");(w/name).write_text(s)
