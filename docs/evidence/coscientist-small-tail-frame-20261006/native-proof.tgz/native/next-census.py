from pathlib import Path
import json,re
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-small-tail-frame-20261006');C={}
for name in ['seed/SIR','seed/HEADS','seed/MEMORY-MAP']:
 for m in re.finditer(r'\[:c (\S+) (-?\d+)',(r/name).read_text()):C[m[1]]=int(m[2])
x=json.loads((w/'observer/meta-ports/statemate/census.json').read_text());sir={}
for line in (w/'observer/meta-ports/statemate/compile.log').read_text().splitlines():
 if line.startswith('SIR '):i,*a=map(int,line.split()[1:]);sir[i]=a
rows=[]
for f,v in x['functions'].items():
 fn=int(f);np=sir[v['start']][2]
 if v['leaf']!=0 or v['frameBytes']<=0 or v['locals']>7 or v['depth']>7 or np>2:continue
 events=[z for z in x['events'] if z['fn']==fn];words=[int(word,16) if isinstance(word,str) else word for z in events for word in z['words']]
 if any(word&0xfc000000==0x94000000 or word&0xfffffc1f==0xd63f0000 for word in words):continue
 calls=[{'sir':i,'callee':sir[i][1],'temp':sir[i][2],'arguments':sir[i][3],'immediateScalarReturn':sir[i+1][0]==C['OP-RET'] and sir[i+1][1]==sir[i][2]} for i in range(v['start']+1,v['end']) if sir[i][0]==C['OP-CALL']]
 rows.append({'function':fn,'incomingArguments':np,'locals':v['locals'],'depth':v['depth'],'frameBytes':v['frameBytes'],'calls':calls})
(w/'next-census.json').write_text(json.dumps({'status':'read-only-current-mode0-small-framed-no-observed-returning-call-census','candidateFunctions':len(rows),'staticCountsNotTimeSharesOrAdmissionProof':True,'rows':rows},indent=2)+'\n')
h={'status':'registered-before-implementation-and-timing','experiment':'simultaneous-two-argument-terminal-transfer','basis':f'{len(rows)} current statemate small framed functions have no observed returning BL/BLR with at most two incoming arguments; this is a static filter, not eligibility or dynamic evidence.','question':'Can safe simultaneous two-argument transfer extend terminal-only mode and reduce the remaining original statemate gap beyond variation?','implemented':False,'measured':False,'requirements':['Start from this qualified product after integration, preserve original19 source/fuel/resource scope','Use a proved parallel argument move: capture both sources before either destination clobber; preserve x7, x30 and all applicable ABI invariants','Prove scalar/vec/type/closed metadata, original published fuel, branch ownership and no live value after transfer; retain current refusal frames for unknown shapes','Independent permutation/alias/constant/context/partial-fuel/resource/trap oracles and mutation controls, full original permanent expectations and native fixed point','Fresh one-campaign rotating product/candidate/C for every changed original guest; unchanged thresholds, no identical retiming','Product gates and committed-source three-generation integration before adoption'],'resultMemoization':False,'nativeDefCIDBridgeConnected':False,'all19GoalAchieved':False,'officialEmbenchScore':False}
(w/'next-hypothesis.json').write_text(json.dumps(h,indent=2)+'\n');print('PASS next registered static candidates',len(rows))
# The zero result rejects extending argument admission alone as this next target.
counts={}
for e in x['events']:
 if e['op']=='OP-CALL' and any((int(z,16)&0xfc000000)==0x94000000 for z in e['words']):
  callee=sir[e['sir']][1];counts[callee]=counts.get(callee,0)+1
control={'status':'read-only-current-returning-call-targets','twoArgumentSmallFrameFilterCandidates':len(rows),'staticCountsNotTimeShares':True,'callees':[{'function':f,'returningCallSites':n,**x['functions'][str(f)]} for f,n in sorted(counts.items(),key=lambda z:(-z[1],z[0]))]}
(w/'returning-call-census.json').write_text(json.dumps(control,indent=2)+'\n')
h={'status':'registered-before-implementation-and-timing','experiment':'exact-uncharged-unsigned-less-wrapper','basis':'Current original statemate uless helper is function5:18 emitted words, zero FUEL in its exact signed-branch SIR, 5 actual returning BL sites. Extending two-argument frame admission alone found zero remaining small framed no-BL candidates. Static counts do not establish time shares.','question':'Can exact closed typed signed-branch unsigned-less semantics lower to AArch64 unsigned compare at callers and remove returning-call overhead beyond variation?','implemented':False,'measured':False,'requirements':['Recognize exact uncharged helper control/data flow and closed i64/i64->bool metadata; open/import/changed shape uses original calls','Prove mathematical equivalence for all signed bit patterns, including same-sign and opposite-sign inputs; no result memoization','Preserve simultaneous argument values and live caller state, x7/context, original fuel/trap/resource behavior and exact boolean representation','Independent signed extrema, permutation, live locals, branches, mutated instruction/type/effect/open controls and actual emitted-code audits','Original19 source, all508/14523 permanent expectations, native fixed point, all changed bodies one fresh rotating product/candidate/C campaign with unchanged thresholds','Product gates and committed-source integration before adoption'],'nativeDefCIDBridgeConnected':False,'all19GoalAchieved':False,'officialEmbenchScore':False}
(w/'next-hypothesis.json').write_text(json.dumps(h,indent=2)+'\n');print('PASS registered unsigned-less structural hypothesis; 5 static sites, no timing claim')
