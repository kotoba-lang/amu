from pathlib import Path
import subprocess,os,re,json
w=Path('/private/tmp/amu-small-tail-frame-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');ns={};exec((w/'fixture-proof.py').read_text().split('env=dict(')[0],ns);m=ns['m'];fns=ns['fns'];sir=ns['sir'];typeform=ns['typeform'];base=m.C['MM-FN-BASE'];fw=m.C['MM-FN-W'];sb=m.C['MM-SIR-BASE'];sw=m.C['MM-SIR-W'];owner=fns['st_scalar'];target=fns['st_target'];start=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==owner);end=next(i for i,x in enumerate(sir,1) if i>start and x[0]==m.C['OP-END']);call=next(i for i,x in enumerate(sir,1) if start<i<end and x[0]==m.C['OP-CALL']);tp=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==target);cases=[]
def meta(f,field,value):cases.append((base+f*fw+m.C[field],value))
for field,value in [('FF-SIR',start+1),('FF-NPARAMS',2),('FF-RTYPE',m.C['TY-F64']),('FF-NSLOTS',8),('FF-DEPTH',8),('FF-PT0',m.C['TY-F64'])]:meta(owner,field,value)
for field,value in [('FF-SIR',tp+1),('FF-NPARAMS',2),('FF-RTYPE',m.C['TY-BOOL']),('FF-PT0',m.C['TY-F64'])]:meta(target,field,value)
firstconst=next(i for i,x in enumerate(sir,1) if start<i<end and x[0]==m.C['OP-CONST']);firstlocal=next(i for i,x in enumerate(sir,1) if start<i<end and x[0]==m.C['OP-LGET'])
for pos,field,value in [(call,2,1),(call,3,2),(call+1,0,m.C['OP-RET2']),(call+1,1,1),(call+1,2,1),(call,1,0),(firstconst,0,m.C['OP-CAP']),(firstconst,0,m.C['OP-STR']),(firstconst,1,7),(firstlocal,2,8),(end,1,owner+1)]:cases.append((sb+pos*sw+field,value))
branch=fns['st_branch'];bp=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==branch);bi=next(i for i,x in enumerate(sir,1) if i>bp and x[0]==m.C['OP-BRZ']);label=ns['labels']['st_else'];idp=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==fns['st_id']);vec=fns['st_vec'];vp=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==vec);ri=next(i for i,x in enumerate(sir,1) if i>vp and x[0]==m.C['OP-RT']);extra=[(sb+bi*sw+2,ns['labels']['sum_h'],branch,bp),(sb+ri*sw+1,m.C['RT-VECTOR-AT']+8,vec,vp)]
probe=f'''(defn- t-small-test [M :vector-i64 p :i64 f :i64] :bool
 (let [np (gn-sir M p IF-B) ns (gn-max (gn-max (gn-sir M p IF-C) (gn-fnf M f FF-NSLOTS)) (gn-max np (gn-scan M (inc p) 2 0)))
       dp (gn-max (gn-fnf M f FF-DEPTH) (gn-scan M (inc p) 1 0))
       MP (-> M (gn-gs gn-f-leaf 1) (gn-gs gn-f-ns ns) (gn-gs gn-f-dp dp) (gn-gs gn-f-out 0) (gn-pre (inc p)))]
  (gn-small-tail MP p f np)))
(defn- t-small-mut [M :vector-i64 at :i64 value :i64 p :i64 f :i64] :bool
 (let [old (vector-at M at) set (t-put M at value) got (t-small-test set p f) restore (t-put set at old)] (not got)))
(defn- t-small-open [M :vector-i64 f :i64] :bool
 (let [old (gn-g M gn-g-open) old_n (gn-g M gn-g-open-n)
       set (-> M (gn-gs gn-g-open f) (gn-gs gn-g-open-n 1)) got (t-small-test set {start} {owner})
       restore (-> set (gn-gs gn-g-open old) (gn-gs gn-g-open-n old_n))] (not got)))
(defn- t-small-duplicate [M :vector-i64] :bool
 (let [at (+ MM-SIR-BASE (* {idp+1} MM-SIR-W)) old_op (vector-at M at) old_a (vector-at M (+ at 1))
       set (-> M (t-put at OP-LABEL) (t-put (+ at 1) {label})) got (t-small-test set {bp} {branch})
       restore (-> set (t-put at old_op) (t-put (+ at 1) old_a))] (not got)))
(defn- t-small-guards [M :vector-i64] :bool
 (and (t-small-test M {start} {owner}) (t-small-test M {bp} {branch}) (t-small-test M {vp} {vec})
      {' '.join(f'(t-small-mut M {at} {value} {start} {owner})' for at,value in cases)}
      {' '.join(f'(t-small-mut M {at} {value} {p} {f})' for at,value,f,p in extra)}
      (t-small-open M {owner}) (t-small-open M {target}) (t-small-duplicate M)))
'''
text=m.kotoba(True).replace('(defn- seed-main [] :i64',typeform+probe+'(defn- seed-main [] :i64').replace('        M1 (gn-run M0)','        M1 (gn-run (t-small-types M0))').replace('(if (and mask_shared','(if (and (t-small-guards M1) mask_shared')
parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];src=w/'mutation-probe.kotoba';src.write_text('\n'.join((r/x).read_text() for x in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+text);env=dict(os.environ,KEXE_COMMAND='1',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/'mutation-probe.kseed')]),('extract',['extract-native',str(w/'mutation-probe.kseed'),'--symbol','main','--output',str(w/'mutation-probe.bin')])]:
 q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/('mutation-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(stage,q.stdout[-300:],q.stderr)
 if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
q=subprocess.run([str(w/'kexe-loader'),str(w/'mutation-probe.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/'mutation-probe.stdout').write_text(q.stdout+q.stderr);assert q.returncode==0,(q.stdout[-300:],q.stderr);(w/'mutation-proof.json').write_text(json.dumps({'status':'complete-native-small-tail-positive-and-bound-abi-type-effect-open-label-refusals','positiveControls':3,'instructionAndMetadataMutations':len(cases)+len(extra),'openRefusals':2,'duplicateLabelRefusal':True,'mutations':cases+extra},indent=2)+'\n');print('PASS native small-tail guards',len(cases)+len(extra),flush=True)
