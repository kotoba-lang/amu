from pathlib import Path
import subprocess,os,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-small-tail-frame-integrated-20261006');p=Path('/private/tmp/amu-small-tail-frame-20261006');A=w/'g3/amu';matrix=json.loads((r/'bench/embench/comparison-matrix.json').read_text());expected=json.loads((Path('/private/tmp/amu-small-tail-frame-20261006')/'ports-correctness.json').read_text());report={'status':'running','entries':[]};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();env=dict(os.environ,KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800')
for e in matrix['entries']:
 name=e['workload'];d=w/'ports'/name;d.mkdir(parents=True,exist_ok=True);src=r/e['source'];assert sha(src)==e['expectedSourceSha256'];b=next(x for x in expected['entries'] if x['workload']==name)
 for label,args in [('check',['check',str(src)]),('compile',['compile',str(src),'--target','aarch64-macos','--output',str(d/'image.kexe')]),('extract',['extract-native',str(d/'image.kexe'),'--symbol',e['symbol'],'--output',str(d/'native.bin')])]:
  q=subprocess.run([str(A),*args],env=env,capture_output=True,text=True);(d/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,label,q.stdout,q.stderr)
  if label=='extract':off=int(re.search(r':offset (\d+)',q.stdout).group(1))
 assert sha(d/'native.bin')==b['nativeSha256'] and off==b['offset'],(name,sha(d/'native.bin'),b)
 report['entries'].append({'workload':name,'sourceSha256':sha(src),'nativeSha256':sha(d/'native.bin'),'offset':off});(w/'ports.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS integrated source check/compile and measured code',name,flush=True)
report['status']='complete-19-integrated-native-machine-parity';(w/'ports.json').write_text(json.dumps(report,indent=2)+'\n')
