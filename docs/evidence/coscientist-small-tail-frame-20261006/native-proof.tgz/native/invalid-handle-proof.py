from pathlib import Path
import os,json,subprocess,re,importlib.util
w=Path('/private/tmp/amu-small-tail-frame-20261006');ns={};exec((w/'fixture-proof.py').read_text().split('env=dict(')[0],ns);m=ns['m'];f=ns['fns']['st_vec'];images={label:m.blob_from((w/(label+'-fixture.stdout')).read_text())[1][f] for label in ['baseline','candidate']};rows=[]
for value in [0,1,4,-1,9999,-(1<<63),(1<<63)-1]:
 for fuel in [1,2,3,17,16777216,(1<<53)-1]:
  obs={}
  for label,offset in images.items():
   env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');env.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'full-state-loader'),str(w/(label+'-fixture.bin')),str(offset),'1','aarch64','-',str(value)],env=env,capture_output=True,text=True);assert q.returncode!=0,(label,value,fuel,q.stdout);assert ':remaining '+str(fuel-1)+'}' in q.stdout,(label,value,fuel,q.stdout);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
  assert obs['baseline']==obs['candidate'],(value,fuel,obs);rows.append({'input':value,'fuel':fuel,'expectedRemaining':fuel-1,**obs})
(w/'invalid-handle-proof.json').write_text(json.dumps({'status':'complete-independent-invalid-vector-and-published-fuel-fullstate','comparisons':len(rows),'rows':rows},indent=2)+'\n');print('PASS',len(rows),'invalid-handle fullstate oracles')
