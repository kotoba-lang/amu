from pathlib import Path
import shutil,hashlib,json
w=Path('/private/tmp/amu-small-tail-frame-20261006');b=w/'gate-build';old=Path('/private/tmp/amu-copy-forward-product-20261006/gate-build');b.mkdir(exist_ok=True)
for name in ['seed-package.info','seed-0.info','seed-1.info','seed-2.info','kexe-loader','kexe-benchmark']:
 shutil.copy2(old/name,b/name)
for k,g in enumerate([2,3,4]):
 for ext in ['bin','offset']:shutil.copy2(w/f'seed-{g}.{ext}',b/f'seed-{k}.{ext}')
shutil.copy2(w/'seed-unity.kotoba',b/'seed-unity.kotoba');h=hashlib.sha256((b/'seed-unity.kotoba').read_bytes()).hexdigest();(b/'seed-unity.kotoba.sha256').write_text(h+'\n')
(w/'gate-build-lineage.json').write_text(json.dumps({'unitySha256':h,'seed0IsBootstrapStage0':False,'generations':[{'gateCompiler':k,'actualNativeGeneration':g,'sha256':hashlib.sha256((w/f'seed-{g}.bin').read_bytes()).hexdigest()} for k,g in enumerate([2,3,4])]},indent=2)+'\n')
