from pathlib import Path
import json,re
w=Path('/private/tmp/amu-small-tail-frame-20261006');s=(w/'gates.log').read_text();g={}
for k in ['ERR','G1','G2','G3','G4','G5']:
 line=next(x for x in s.splitlines() if x.startswith(k+' '));assert 'PASS' in line;g[k]=line
s=(w/'gates-build-qualified.log').read_text();line=next(x for x in s.splitlines() if x.startswith('BUILD '));assert 'PASS' in line;g['BUILD']=line
(w/'gate-summary.json').write_text(json.dumps({'status':'all-requested-gates-pass','rows':g,'initialFailures':'Copied stale metadata corrected; exact manifest unity independently rebuilds same native bytes. Original logs retained.','officialEmbenchScore':False},indent=2)+'\n');print('PASS current source BUILD plus ERR/G1-G5')
