from pathlib import Path
import json,importlib.util,subprocess,os,re,hashlib,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-small-tail-frame-20261006');raw=(r/'scripts/seed/a64gen-fixtures.py').read_text().replace("R = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))", "R = '/Users/junkawasaki/github/wt/amu-seed17'",1);(w/'frozen-fixtures.py').write_text(raw);sp=importlib.util.spec_from_file_location('fx',w/'frozen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);oldcount=len(m.FIX)
m.fx('st_id',1,1,[('LGET',0,1),('RET',0)])
m.fx('st_target',1,1,[('FUEL',),('LGET',0,1),('CONST',1,2),('BIN','BOP-MUL',0),('CONST',1,3),('BIN','BOP-ADD',0),('RET',0)])
locals=[('LGET',0,1),('CONST',1,7),('BIN','BOP-ADD',0),('LSET',2,0),('LGET',0,1),('CONST',1,5),('BIN','BOP-SUB',0),('LSET',3,0),('LGET',0,2),('LGET',1,3),('BIN','BOP-MUL',0),('LSET',4,0),('LGET',0,4)]
m.fx('st_scalar',1,4,[('FUEL',)]+locals+[('CALL','st_target',0,1),('RET',0)])
m.fx('st_wrap',1,4,[('FUEL',)]+locals+[('CALL','st_id',0,1),('CALL','st_target',0,1),('RET',0)])
m.fx('st_branch',1,1,[('FUEL',),('LGET',0,1),('BRZ',0,'st_else'),('LGET',0,1),('CALL','st_target',0,1),('RET',0),('LABEL','st_else'),('CONST',0,19),('CALL','st_target',0,1),('RET',0)])
m.fx('st_vtarget',1,1,[('FUEL',),('LGET',0,1),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('LGET',1,1),('CONST',2,1),('RT','RT-VECTOR-AT',1,2),('BIN','BOP-ADD',0),('RET',0)])
m.fx('st_vec',1,1,[('FUEL',),('LGET',0,1),('CONST',1,0),('CONST',2,7),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('LGET',0,1),('CALL','st_vtarget',0,1),('RET',0)])
m.fx('st_driver',1,1,[('FUEL',),('CONST',0,0),('LGET',1,1),('CONST',2,-3),('VEC',0,3),('CALL','st_vec',0,1),('RET',0)])
m.fx('st_ref_np2',2,2,[('FUEL',),('LGET',0,2),('CALL','st_target',0,1),('RET',0)])
m.fx('st_ref_d8',1,1,[('FUEL',),('CONST',7,17),('LGET',0,1),('CALL','st_target',0,1),('RET',0)])
m.fx('st_ref_return',1,1,[('FUEL',),('LGET',0,1),('CALL','st_target',0,1),('LGET',1,1),('BIN','BOP-ADD',0),('RET',0)])
m.fx('st_alloc',1,1,[('FUEL',),('LGET',0,1),('VEC',0,1),('RET',0)])
m.fx('st_ref_vec',1,1,[('FUEL',),('LGET',0,1),('CALL','st_alloc',0,1),('RT','RT-VECTOR-COUNT',0,1),('RET',0)])
m.fx('st_ref_driver',1,1,[('FUEL',),('LGET',0,1),('VEC',0,1),('CALL','st_ref_vec',0,1),('RET',0)])
fns,labels,lits,sir,frec=m.layout_tables();types={x[0]:('TY-VEC' if x[0] in ['st_vtarget','st_vec','st_alloc','st_ref_vec'] else 'TY-I64','TY-VEC' if x[0]=='st_alloc' else 'TY-I64') for x in m.FIX[oldcount:]};typeform='(defn- t-small-types [M :vector-i64] :vector-i64\n (-> M '+' '.join('(t-put '+str(m.C['MM-FN-BASE']+fns[name]*m.C['MM-FN-W']+fld)+' '+ty+')' for name,(pt,rt) in types.items() for fld,ty in [(m.C['FF-RTYPE'],rt)]+[(m.C['FF-PT0']+j,pt) for j in range(next(x[1] for x in m.FIX if x[0]==name))])+'))\n'
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');images={};parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba']
for label,gen in [('baseline','baseline-41-a64gen.kotoba'),('candidate','41-a64gen-prototype.kotoba')]:
 text=m.kotoba(True).replace('(defn- seed-main [] :i64',typeform+'(defn- seed-main [] :i64').replace('        M1 (gn-run M0)','        M1 (gn-run (t-small-types M0))')
 src=w/(label+'-fixture.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/gen).read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+text)
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'-fixture.kseed'))]),('extract',['extract-native',str(w/(label+'-fixture.kseed')),'--symbol','main','--output',str(w/(label+'-fixture-generator.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-fixture-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-200:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'-fixture-generator.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'-fixture.stdout')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout[-300:],q.stderr);blob,offsets=m.blob_from(q.stdout);p=w/(label+'-fixture.bin');p.write_bytes(blob);images[label]=(p,offsets);print('PASS native fixture generator',label,len(blob),flush=True)
wrap=lambda x:((x+(1<<63))%(1<<64))-(1<<63);rows=[]
for name in ['st_scalar','st_wrap','st_branch','st_driver','st_ref_np2','st_ref_d8','st_ref_return','st_ref_driver']:
 for x in [0,1,-1,3,-7,17,-(1<<63),(1<<63)-1,65536]:
  want=wrap(2*wrap((x+7)*(x-5))+3) if name in ['st_scalar','st_wrap'] else 41 if name=='st_branch' and x==0 else wrap(x+7) if name=='st_driver' else wrap(3*x+3) if name=='st_ref_return' else 1 if name=='st_ref_driver' else wrap(2*x+3)
  charges=3 if name in ['st_driver','st_ref_driver'] else 2
  for fuel in [1,2,3,4,5,16777216,(1<<53)-1]:
   obs={};args=[99,x] if name=='st_ref_np2' else [x]
   for label,(p,offsets) in images.items():
    e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'full-state-loader'),str(p),str(offsets[fns[name]]),str(len(args)),'aarch64','-']+list(map(str,args)),env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)};assert (q.returncode==0)==(fuel>=charges),(name,x,fuel,charges,label,q.stdout,q.stderr)
    if fuel>=charges:assert ':result '+str(want)+' ' in q.stdout and ':remaining '+str(fuel-charges)+'}' in q.stdout,(name,x,fuel,want,label,q.stdout)
   assert obs['baseline']==obs['candidate'],(name,x,fuel,obs);rows.append({'fixture':name,'x':x,'fuel':fuel,'expected':want,'charges':charges,**obs})
 print('PASS independent locals/branches/vector/context/refusal fullstate',name,flush=True)
regions=[]
for name in ['st_scalar','st_wrap','st_branch','st_vec','st_ref_np2','st_ref_d8','st_ref_return','st_ref_vec']:
 words={label:[v[0] for v in struct.iter_unpack('<I',p.read_bytes()[offsets[fns[name]]:offsets[fns[name]+1]])] for label,(p,offsets) in images.items()};assert words['baseline'][0]==0xa9bf7bfd,(name,words)
 admitted=name in ['st_scalar','st_wrap','st_branch','st_vec'];assert (words['candidate'][0]!=0xa9bf7bfd)==admitted,(name,words);assert words['candidate'][0]==(0xf94004f0 if admitted else 0xa9bf7bfd),(name,words['candidate'][:8]);regions.append({'fixture':name,'framelessPublishedFuel':admitted,'baselineWords':len(words['baseline']),'candidateWords':len(words['candidate'])})
(w/'fixture-proof.json').write_text(json.dumps({'status':'complete-native-independent-small-tail-local-context-published-fuel-fullstate','comparisons':len(rows),'regions':regions,'originalFixturesRetained':oldcount,'totalFixtures':len(m.FIX),'images':{k:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,(p,_) in images.items()},'observations':rows},indent=2)+'\n');print('PASS',len(rows),'fullstate comparisons',flush=True)
