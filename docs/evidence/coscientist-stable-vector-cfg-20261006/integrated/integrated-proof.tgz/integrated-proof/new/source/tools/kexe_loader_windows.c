#define WIN32_LEAN_AND_MEAN
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0A00
#endif
#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <rpc.h>
#include <fwpmu.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <sddl.h>
#include <userenv.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <limits.h>

/* MinGW's user-mode WFP declarations lag the Windows SDK: the API structs and
 * functions are present, but these SDK-owned GUID values and two public flag
 * constants are absent.  Keep the compatibility names private so a MinGW
 * release which later adds the SDK declarations cannot collide with them.
 * Values are the Microsoft win32metadata projection of fwpmu.h/fwpmtypes.h. */
#if defined(__MINGW32__)
static const GUID KEXE_LAYER_ALE_AUTH_CONNECT_V4 =
  {0xc38d57d1, 0x05a7, 0x4c33, {0x90, 0x4f, 0x7f, 0xbc, 0xee, 0xe6, 0x0e, 0x82}};
static const GUID KEXE_LAYER_ALE_AUTH_CONNECT_V6 =
  {0x4a72393b, 0x319f, 0x44bc, {0x84, 0xc3, 0xba, 0x54, 0xdc, 0xb3, 0xb6, 0xb4}};
static const GUID KEXE_LAYER_ALE_AUTH_RECV_ACCEPT_V4 =
  {0xe1cd9fe7, 0xf4b5, 0x4273, {0x96, 0xc0, 0x59, 0x2e, 0x48, 0x7b, 0x86, 0x50}};
static const GUID KEXE_LAYER_ALE_AUTH_RECV_ACCEPT_V6 =
  {0xa3b42c97, 0x9f04, 0x4672, {0xb8, 0x7e, 0xce, 0xe9, 0xc4, 0x83, 0x25, 0x7f}};
static const GUID KEXE_CONDITION_ALE_APP_ID =
  {0xd78e1e87, 0x8644, 0x4ea5, {0x94, 0x37, 0xd8, 0x09, 0xec, 0xef, 0xc9, 0x71}};
static const GUID KEXE_CONDITION_FLAGS =
  {0x632ce23b, 0x5167, 0x435c, {0x86, 0xd7, 0xe9, 0x03, 0x68, 0x4a, 0xa8, 0x0c}};
#ifndef FWPM_SESSION_FLAG_DYNAMIC
#define FWPM_SESSION_FLAG_DYNAMIC 0x00000001u
#endif
#ifndef FWPM_FILTER_FLAG_CLEAR_ACTION_RIGHT
#define FWPM_FILTER_FLAG_CLEAR_ACTION_RIGHT 0x00000008u
#endif
#else
#define KEXE_LAYER_ALE_AUTH_CONNECT_V4 FWPM_LAYER_ALE_AUTH_CONNECT_V4
#define KEXE_LAYER_ALE_AUTH_CONNECT_V6 FWPM_LAYER_ALE_AUTH_CONNECT_V6
#define KEXE_LAYER_ALE_AUTH_RECV_ACCEPT_V4 FWPM_LAYER_ALE_AUTH_RECV_ACCEPT_V4
#define KEXE_LAYER_ALE_AUTH_RECV_ACCEPT_V6 FWPM_LAYER_ALE_AUTH_RECV_ACCEPT_V6
#define KEXE_CONDITION_ALE_APP_ID FWPM_CONDITION_ALE_APP_ID
#define KEXE_CONDITION_FLAGS FWPM_CONDITION_FLAGS
#endif

#if !defined(__clang__)
#error "Kotoba Windows loader requires Clang"
#endif

#if defined(_M_X64)
#define SYSV __attribute__((sysv_abi))
#define KEXE_ISA "x86_64"
#elif defined(_M_ARM64)
#define SYSV
#define KEXE_ISA "aarch64"
#else
#error "Kotoba Windows loader requires x86-64 or Arm64"
#endif
#define KEXE_MAX_CODE (1024u * 1024u)
#define KEXE_PAIR_CAPACITY 4096u
#define KEXE_STRING_POOL_BYTES 65536u
#define KEXE_RECORD_FIELD_LIMIT 32u /* lang/limits.edn :language/static :record-fields (128 until 2026-09-24, adr-2609242100 P1) */
#define KEXE_VECTOR_CAPACITY 4096u
#define KEXE_VECTOR_ITEM_CAPACITY 65536u
/* One vector's length bound, re-derived from kotoba.kir.value/vector-item-limit
 * (2^24 since 2026-09-16, osaho #93). This loader's item arena is still the
 * fixed 65536 words above, so the arena bounds a vector first here; the
 * constant matches KIR so a length KIR admits is refused for the arena's
 * reason, not a stale one. */
#define KEXE_VECTOR_LENGTH_LIMIT 16777216u

struct pair_cell { int64_t first; int64_t second; };
struct vector_cell { uint64_t offset; uint64_t length; };
struct kexe_context {
  uint64_t version;
  uint64_t fuel;
  uint8_t allow[32];
  void *cap_call;
  void *pair_new;
  void *pair_first;
  void *pair_second;
  void *kgraph_assert;
  void *kgraph_get;
  void *kgraph_count;
  void *kgraph_entity_at;
  void *string_equal;
  void *string_concat;
  void *typed_cap_call;
  void *string_substring;
  void *string_code_point_at;
  /* vector-i64 / vector-f64 (ADR-2608030300). Same six slots, same meaning
   * and same offsets as the POSIX loader's kexe_context_v8 -- the ABI is the
   * contract, not either host. See that file for why a vector value is a
   * one-word handle and why conj can append in place. */
  void *vector_new_empty;
  void *vector_conj;
  void *vector_count;
  void *vector_at;
  void *vector_assoc;
  void *vector_drop;
  /* ABI v4 (superproject ADR-2609010200). Same two slots, same meaning and
   * same offsets as the POSIX loader's kexe_context_v8. `vector_alloc` is n
   * zeros in one call, because `vector-new` is variadic and a million-slot
   * allocation cannot be a literal. `vector_assoc_in_place` is the same
   * update lowered to a STORE, returning the SAME handle: legal exactly when
   * no other live handle spans the word, which the compiler proves
   * (`kotoba.compiler.affine` behind `check-affine-writes!`) and this host
   * does not repeat. Memory safety is still checked here, unconditionally. */
  void *vector_alloc;
  void *vector_assoc_in_place;
  /* ABI v5 (2026-09-15). Same slot, same meaning and same offset as the
   * POSIX loader's kexe_context_v5: the byte search as one host call, an
   * empty needle refused, -1 when absent. See that file for the
   * measurement that moved it out of the guest. */
  void *string_index_of;
  /* ABI v6 (2026-09-16). Same two slots, same meaning and same offsets as
   * the POSIX loader's kexe_context_v8: the region reset behind
   * `arena-scope`. See that file for the safety argument. */
  void *arena_enter;
  void *arena_leave;
  /* ABI v7 (2026-09-16). Same four slots as the POSIX loader's
   * kexe_context_v8; see that file for the contracts. */
  void *string_compare;
  void *string_fold_ascii;
  void *string_find_blank;
  void *string_skip_blank;
  /* ABI v8 (2026-09-16): the two line slots; see kexe_loader.c. */
  void *string_index_of_from;
  void *string_compare_lines;
  /* ABI v9 (2026-09-16): the six pointers the inline handle operations
   * read; see kexe_loader.c. Set once at start. */
  uint64_t *pair_used_pointer;
  struct pair_cell *pairs_base;
  uint8_t *pair_validated_base;
  uint64_t *vector_used_pointer;
  struct vector_cell *vectors_base;
  int64_t *vector_items_base;
  /* ABI v10 (2026-09-16): the two range slots; see kexe_loader.c. */
  void *string_find_byte;
  void *string_append_range;
  /* ABI v11 (2026-09-25): the string constructor and three bytes slots; see
   * kexe_loader.c. A refusal here is an unnamed trap -- this host has no
   * supervisor report to name it in. */
  void *string_from_utf8;
  void *bytes_from_vector;
  void *bytes_slice;
  void *bytes_concat;
  uint64_t pair_used;
  struct pair_cell pairs[KEXE_PAIR_CAPACITY];
  /* One flag per pair handle: the bytes this handle addresses are
   * known-valid canonical UTF-8. Sound for the same reason as in
   * kexe_loader.c: a handle's bytes never change after it is minted. */
  uint8_t pair_validated[KEXE_PAIR_CAPACITY];
  uint64_t string_pool_used;
  uint8_t string_pool[KEXE_STRING_POOL_BYTES];
  uint64_t vector_used;
  struct vector_cell vectors[KEXE_VECTOR_CAPACITY];
  uint64_t vector_item_used;
  int64_t vector_items[KEXE_VECTOR_ITEM_CAPACITY];
  /* The arena-scope mark stack (ABI v6), as in kexe_loader.c. */
  uint64_t arena_scope_depth;
  uint64_t arena_scope_marks[256][4];
  const uint8_t *code_base;
  uint64_t code_length;
};

_Static_assert(offsetof(struct kexe_context, fuel) == 8, "fuel ABI");
_Static_assert(offsetof(struct kexe_context, allow) == 16, "allow ABI");
_Static_assert(offsetof(struct kexe_context, cap_call) == 48, "cap ABI");
_Static_assert(offsetof(struct kexe_context, pair_new) == 56, "pair ABI");
_Static_assert(offsetof(struct kexe_context, pair_first) == 64, "first ABI");
_Static_assert(offsetof(struct kexe_context, pair_second) == 72, "second ABI");
_Static_assert(offsetof(struct kexe_context, string_equal) == 112, "string ABI");
_Static_assert(offsetof(struct kexe_context, string_concat) == 120, "string ABI");
_Static_assert(offsetof(struct kexe_context, typed_cap_call) == 128, "typed cap ABI");
_Static_assert(offsetof(struct kexe_context, string_substring) == 136, "string ABI");
_Static_assert(offsetof(struct kexe_context, string_code_point_at) == 144, "string ABI");
_Static_assert(offsetof(struct kexe_context, vector_new_empty) == 152, "vector ABI");
_Static_assert(offsetof(struct kexe_context, vector_conj) == 160, "vector ABI");
_Static_assert(offsetof(struct kexe_context, vector_count) == 168, "vector ABI");
_Static_assert(offsetof(struct kexe_context, vector_at) == 176, "vector ABI");
_Static_assert(offsetof(struct kexe_context, vector_assoc) == 184, "vector ABI");
_Static_assert(offsetof(struct kexe_context, vector_drop) == 192, "vector ABI");
_Static_assert(offsetof(struct kexe_context, vector_alloc) == 200, "vector ABI");
_Static_assert(offsetof(struct kexe_context, vector_assoc_in_place) == 208, "vector ABI");
_Static_assert(offsetof(struct kexe_context, string_index_of) == 216, "string ABI");
_Static_assert(offsetof(struct kexe_context, arena_enter) == 224, "region ABI");
_Static_assert(offsetof(struct kexe_context, arena_leave) == 232, "region ABI");
_Static_assert(offsetof(struct kexe_context, string_compare) == 240, "text ABI");
_Static_assert(offsetof(struct kexe_context, string_skip_blank) == 264, "text ABI");
_Static_assert(offsetof(struct kexe_context, string_index_of_from) == 272, "line ABI");
_Static_assert(offsetof(struct kexe_context, string_compare_lines) == 280, "line ABI");
_Static_assert(offsetof(struct kexe_context, vector_items_base) == 328, "inline ABI");
_Static_assert(offsetof(struct kexe_context, string_find_byte) == 336, "range ABI");
_Static_assert(offsetof(struct kexe_context, string_append_range) == 344, "range ABI");
_Static_assert(offsetof(struct kexe_context, string_from_utf8) == 352, "bytes ABI");
_Static_assert(offsetof(struct kexe_context, bytes_from_vector) == 360, "bytes ABI");
_Static_assert(offsetof(struct kexe_context, bytes_slice) == 368, "bytes ABI");
_Static_assert(offsetof(struct kexe_context, bytes_concat) == 376, "bytes ABI");

static void fail_win(const char *message) {
  fprintf(stderr, "kexe-loader-windows: %s: win32=%lu\n", message, (unsigned long)GetLastError());
  ExitProcess(70);
}

static void fail_input(const char *message) {
  fprintf(stderr, "kexe-loader-windows: %s\n", message);
  ExitProcess(65);
}

static HANDLE create_guest_job(void) {
  HANDLE job = CreateJobObjectW(NULL, NULL);
  JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits;
  if (job == NULL) fail_win("CreateJobObjectW");
  ZeroMemory(&limits, sizeof(limits));
  limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE |
      JOB_OBJECT_LIMIT_ACTIVE_PROCESS;
  limits.BasicLimitInformation.ActiveProcessLimit = 1;
  if (!SetInformationJobObject(job, JobObjectExtendedLimitInformation, &limits, sizeof(limits)))
    fail_win("SetInformationJobObject");
  return job;
}

static int64_t SYSV cap_call(struct kexe_context *ctx, uint32_t id, int64_t value) {
  if (ctx == NULL || ctx->version != 11 || id > 255 || !(ctx->allow[id / 8] & (1u << (id % 8))))
    __builtin_trap();
  return value + 1;
}

static struct pair_cell *checked_pair(struct kexe_context *ctx, int64_t handle) {
  if (ctx == NULL || handle <= 0 || (uint64_t)handle > ctx->pair_used) __builtin_trap();
  return &ctx->pairs[(uint64_t)handle - 1];
}

static int64_t SYSV pair_new(struct kexe_context *ctx, int64_t first, int64_t second) {
  uint64_t index;
  if (ctx == NULL || ctx->pair_used >= KEXE_PAIR_CAPACITY) __builtin_trap();
  index = ctx->pair_used++;
  ctx->pairs[index].first = first;
  ctx->pairs[index].second = second;
  ctx->pair_validated[index] = 0;
  return (int64_t)(index + 1);
}

static int64_t SYSV pair_first(struct kexe_context *ctx, int64_t handle) {
  return checked_pair(ctx, handle)->first;
}

static int64_t SYSV pair_second(struct kexe_context *ctx, int64_t handle) {
  return checked_pair(ctx, handle)->second;
}

static const uint8_t *resolve_string_bytes(struct kexe_context *ctx,
                                           int64_t offset, int64_t length) {
  uint64_t pool_offset;
  if (ctx == NULL || ctx->version != 11 || length < 0) __builtin_trap();
  if (offset >= 0) {
    if ((uint64_t)offset + (uint64_t)length > ctx->code_length ||
        (uint64_t)offset + (uint64_t)length < (uint64_t)offset)
      __builtin_trap();
    return ctx->code_base + offset;
  }
  /* Defined for INT64_MIN, unlike `-offset - 1`. */
  pool_offset = (uint64_t)(-(offset + 1));
  /* Bounded by the bytes that EXIST, as kexe_loader.c's is since 2026-09-16
   * (a hand-built pair past the used bytes resolved; sanitized fuzz). */
  if (pool_offset + (uint64_t)length > ctx->string_pool_used ||
      pool_offset + (uint64_t)length < pool_offset)
    __builtin_trap();
  return ctx->string_pool + pool_offset;
}

static int valid_utf8(const uint8_t *bytes, uint64_t length) {
  uint64_t i = 0;
  while (i < length) {
    uint8_t a = bytes[i++];
    if (a <= 0x7f) continue;
    if (a >= 0xc2 && a <= 0xdf) {
      if (i >= length || (bytes[i++] & 0xc0) != 0x80) return 0;
      continue;
    }
    if (a >= 0xe0 && a <= 0xef) {
      uint8_t b, c;
      if (i + 1 >= length) return 0;
      b = bytes[i++]; c = bytes[i++];
      if ((b & 0xc0) != 0x80 || (c & 0xc0) != 0x80 ||
          (a == 0xe0 && b < 0xa0) || (a == 0xed && b >= 0xa0)) return 0;
      continue;
    }
    if (a >= 0xf0 && a <= 0xf4) {
      uint8_t b, c, d;
      if (i + 2 >= length) return 0;
      b = bytes[i++]; c = bytes[i++]; d = bytes[i++];
      if ((b & 0xc0) != 0x80 || (c & 0xc0) != 0x80 ||
          (d & 0xc0) != 0x80 || (a == 0xf0 && b < 0x90) ||
          (a == 0xf4 && b >= 0x90)) return 0;
      continue;
    }
    return 0;
  }
  return 1;
}

static int hex_nibble(char value) {
  if (value >= '0' && value <= '9') return value - '0';
  if (value >= 'a' && value <= 'f') return value - 'a' + 10;
  return -1;
}

static int64_t parse_i64(const char *text);

static int64_t allocate_host_pair(struct kexe_context *ctx,
                                  int64_t first, int64_t second) {
  uint64_t index;
  if (ctx->pair_used >= KEXE_PAIR_CAPACITY)
    fail_input("tagged argument exceeds pair arena");
  index = ctx->pair_used++;
  ctx->pairs[index].first = first;
  ctx->pairs[index].second = second;
  ctx->pair_validated[index] = 0;
  return (int64_t)(index + 1u);
}

static int parse_variant_profile(const char *text, uint64_t *case_count,
                                 uint64_t *bool_mask) {
  unsigned long long cases, mask;
  int consumed = 0;
  if (sscanf(text, "variant:%llu:%llu%n", &cases, &mask, &consumed) != 2 ||
      text[consumed] != '\0' || cases == 0 || cases > 32 ||
      (mask >> cases) != 0) return 0;
  *case_count = (uint64_t)cases;
  *bool_mask = (uint64_t)mask;
  return 1;
}

static int64_t parse_guest_arg(struct kexe_context *ctx, const char *text) {
  uint64_t start, index, length;
  size_t digits;
  const char *hex;
  if (strncmp(text, "v:", 2) == 0) {
    unsigned long long cases, ordinal;
    long long payload;
    char kind;
    int consumed = 0;
    if (sscanf(text, "v:%llu:%llu:%c:%lld%n", &cases, &ordinal, &kind,
               &payload, &consumed) != 4 || text[consumed] != '\0' ||
        cases == 0 || cases > 32 || ordinal >= cases ||
        (kind != 'i' && kind != 'b') ||
        (kind == 'b' && payload != 0 && payload != 1))
      fail_input("invalid scalar variant argument");
    return allocate_host_pair(ctx, (int64_t)ordinal, (int64_t)payload);
  }
  if (strcmp(text, "o:none") == 0)
    return allocate_host_pair(ctx, 0, 0);
  if (strncmp(text, "o:some:", 7) == 0)
    return allocate_host_pair(ctx, 1, parse_i64(text + 7));
  if (strncmp(text, "e:ok:", 5) == 0)
    return allocate_host_pair(ctx, 1, parse_i64(text + 5));
  if (strncmp(text, "e:err:", 6) == 0)
    return allocate_host_pair(ctx, 0, parse_i64(text + 6));
  if (strncmp(text, "r:", 2) == 0) {
    int64_t fields[KEXE_RECORD_FIELD_LIMIT];
    uint64_t count = 0;
    const char *cursor = text + 2;
    int64_t handle = 0;
    if (*cursor == '\0') fail_input("empty record argument");
    while (*cursor != '\0') {
      char *end = NULL;
      long long field;
      if (count >= KEXE_RECORD_FIELD_LIMIT)
        fail_input("record argument exceeds field limit");
      if ((*cursor != '-' && (*cursor < '0' || *cursor > '9')) ||
          (*cursor == '-' && (cursor[1] < '0' || cursor[1] > '9')))
        fail_input("invalid record argument");
      errno = 0;
      field = strtoll(cursor, &end, 10);
      if (errno == ERANGE || end == cursor || (*end != ',' && *end != '\0'))
        fail_input("invalid record argument");
      fields[count++] = (int64_t)field;
      if (*end == '\0') break;
      cursor = end + 1;
      if (*cursor == '\0') fail_input("invalid record argument");
    }
    if (count > KEXE_PAIR_CAPACITY - ctx->pair_used)
      fail_input("record argument exceeds pair arena");
    for (uint64_t i = count; i > 0; i--) {
      index = ctx->pair_used++;
      ctx->pairs[index].first = fields[i - 1u];
      ctx->pairs[index].second = handle;
      ctx->pair_validated[index] = 0;
      handle = (int64_t)(index + 1u);
    }
    return handle;
  }
  if (strncmp(text, "s:", 2) != 0) return parse_i64(text);
  hex = text + 2;
  digits = strlen(hex);
  if ((digits & 1u) != 0) fail_input("invalid string argument hex");
  length = (uint64_t)(digits / 2u);
  if (length > KEXE_STRING_POOL_BYTES - ctx->string_pool_used ||
      ctx->pair_used >= KEXE_PAIR_CAPACITY)
    fail_input("string argument exceeds host arena");
  for (size_t i = 0; i < digits; i++)
    if (hex_nibble(hex[i]) < 0) fail_input("invalid string argument hex");
  start = ctx->string_pool_used;
  for (uint64_t i = 0; i < length; i++)
    ctx->string_pool[start + i] =
        (uint8_t)((hex_nibble(hex[2u * i]) << 4) |
                  hex_nibble(hex[2u * i + 1u]));
  if (!valid_utf8(ctx->string_pool + start, length))
    fail_input("string argument is not canonical UTF-8");
  index = ctx->pair_used++;
  ctx->pairs[index].first = -((int64_t)start) - 1;
  ctx->pairs[index].second = (int64_t)length;
  ctx->pair_validated[index] = 1;
  ctx->string_pool_used += length;
  return (int64_t)(index + 1u);
}

static const uint8_t *inspect_string_result(const struct kexe_context *ctx,
                                            int64_t handle,
                                            uint64_t *length_out) {
  const struct pair_cell *pair;
  const uint8_t *bytes;
  uint64_t offset, length;
  if (handle <= 0 || (uint64_t)handle > ctx->pair_used) return NULL;
  pair = &ctx->pairs[(uint64_t)handle - 1u];
  if (pair->second < 0) return NULL;
  length = (uint64_t)pair->second;
  if (pair->first >= 0) {
    offset = (uint64_t)pair->first;
    if (length > ctx->code_length || offset > ctx->code_length - length)
      return NULL;
    bytes = ctx->code_base + offset;
  } else {
    offset = (uint64_t)(-(pair->first + 1));
    if (length > ctx->string_pool_used ||
        offset > ctx->string_pool_used - length) return NULL;
    bytes = ctx->string_pool + offset;
  }
  if (!valid_utf8(bytes, length)) return NULL;
  *length_out = length;
  return bytes;
}

static int inspect_record_result(const struct kexe_context *ctx,
                                 int64_t handle, uint64_t field_count,
                                 int64_t fields[KEXE_RECORD_FIELD_LIMIT]) {
  const struct pair_cell *pair;
  if (field_count == 0 || field_count > KEXE_RECORD_FIELD_LIMIT) return 0;
  for (uint64_t i = 0; i < field_count; i++) {
    if (handle <= 0 || (uint64_t)handle > ctx->pair_used) return 0;
    pair = &ctx->pairs[(uint64_t)handle - 1u];
    fields[i] = pair->first;
    handle = pair->second;
  }
  return handle == 0;
}

static int inspect_tagged_i64_result(const struct kexe_context *ctx,
                                     int64_t handle, int option,
                                     int64_t *tag, int64_t *payload) {
  const struct pair_cell *pair;
  if (handle <= 0 || (uint64_t)handle > ctx->pair_used) return 0;
  pair = &ctx->pairs[(uint64_t)handle - 1u];
  if (pair->first != 0 && pair->first != 1) return 0;
  if (option && pair->first == 0 && pair->second != 0) return 0;
  *tag = pair->first;
  *payload = pair->second;
  return 1;
}

static int inspect_variant_result(const struct kexe_context *ctx,
                                  int64_t handle, uint64_t case_count,
                                  uint64_t bool_mask, int64_t *ordinal,
                                  int64_t *payload) {
  const struct pair_cell *pair;
  if (handle <= 0 || (uint64_t)handle > ctx->pair_used) return 0;
  pair = &ctx->pairs[(uint64_t)handle - 1u];
  if (pair->first < 0 || (uint64_t)pair->first >= case_count) return 0;
  if (((bool_mask >> (uint64_t)pair->first) & 1u) != 0 &&
      pair->second != 0 && pair->second != 1) return 0;
  *ordinal = pair->first;
  *payload = pair->second;
  return 1;
}

/* vector-i64 / vector-f64 host table. Mirrors the POSIX loader's
 * checked_vector_* exactly, including the one non-obvious property: conj
 * appends in place when the source slice ends at the arena top, which is safe
 * because every handle carries its own length, so a word past a slice belongs
 * to no handle. Read tools/kexe_loader.c for the full argument -- the two
 * hosts implement one ABI and must not drift. */

static struct vector_cell *checked_vector(struct kexe_context *ctx, int64_t handle) {
  if (ctx == NULL || ctx->version != 11 || handle <= 0 ||
      (uint64_t)handle > ctx->vector_used) __builtin_trap();
  return &ctx->vectors[(uint64_t)handle - 1];
}

static int64_t intern_vector(struct kexe_context *ctx, uint64_t offset, uint64_t length) {
  uint64_t index;
  if (ctx->vector_used >= KEXE_VECTOR_CAPACITY) __builtin_trap();
  index = ctx->vector_used++;
  ctx->vectors[index].offset = offset;
  ctx->vectors[index].length = length;
  return (int64_t)(index + 1);
}

static int64_t SYSV vector_new_empty(struct kexe_context *ctx) {
  if (ctx == NULL || ctx->version != 11) __builtin_trap();
  return intern_vector(ctx, ctx->vector_item_used, 0);
}

static int64_t SYSV vector_count(struct kexe_context *ctx, int64_t handle) {
  return (int64_t)checked_vector(ctx, handle)->length;
}

static int64_t SYSV vector_at(struct kexe_context *ctx, int64_t handle, int64_t index) {
  struct vector_cell *vector = checked_vector(ctx, handle);
  if (index < 0 || (uint64_t)index >= vector->length) __builtin_trap();
  return ctx->vector_items[vector->offset + (uint64_t)index];
}

static int64_t SYSV vector_conj(struct kexe_context *ctx, int64_t handle, int64_t item) {
  struct vector_cell *vector = checked_vector(ctx, handle);
  uint64_t offset = vector->offset;
  uint64_t length = vector->length;
  if (length >= KEXE_VECTOR_LENGTH_LIMIT) __builtin_trap();
  if (offset + length != ctx->vector_item_used) {
    uint64_t destination;
    if (ctx->vector_item_used + length + 1u > KEXE_VECTOR_ITEM_CAPACITY) __builtin_trap();
    destination = ctx->vector_item_used;
    memmove(&ctx->vector_items[destination], &ctx->vector_items[offset],
            (size_t)length * sizeof(int64_t));
    ctx->vector_item_used += length;
    offset = destination;
  }
  if (ctx->vector_item_used >= KEXE_VECTOR_ITEM_CAPACITY) __builtin_trap();
  ctx->vector_items[ctx->vector_item_used++] = item;
  return intern_vector(ctx, offset, length + 1u);
}

static int64_t SYSV vector_assoc(struct kexe_context *ctx, int64_t handle,
                                 int64_t index, int64_t item) {
  struct vector_cell *vector = checked_vector(ctx, handle);
  uint64_t offset = vector->offset;
  uint64_t length = vector->length;
  uint64_t destination;
  if (index < 0 || (uint64_t)index >= length) __builtin_trap();
  if (ctx->vector_item_used + length > KEXE_VECTOR_ITEM_CAPACITY) __builtin_trap();
  destination = ctx->vector_item_used;
  memmove(&ctx->vector_items[destination], &ctx->vector_items[offset],
          (size_t)length * sizeof(int64_t));
  ctx->vector_items[destination + (uint64_t)index] = item;
  ctx->vector_item_used += length;
  return intern_vector(ctx, destination, length);
}

static int64_t SYSV vector_alloc(struct kexe_context *ctx, int64_t count) {
  uint64_t offset;
  uint64_t i;
  if (ctx == NULL || ctx->version != 11) __builtin_trap();
  if (count < 0 || (uint64_t)count > KEXE_VECTOR_LENGTH_LIMIT) __builtin_trap();
  if (ctx->vector_item_used + (uint64_t)count > KEXE_VECTOR_ITEM_CAPACITY) __builtin_trap();
  offset = ctx->vector_item_used;
  for (i = 0; i < (uint64_t)count; i++) ctx->vector_items[offset + i] = 0;
  ctx->vector_item_used += (uint64_t)count;
  return intern_vector(ctx, offset, (uint64_t)count);
}

static int64_t SYSV vector_assoc_in_place(struct kexe_context *ctx, int64_t handle,
                                          int64_t index, int64_t item) {
  struct vector_cell *vector = checked_vector(ctx, handle);
  if (index < 0 || (uint64_t)index >= vector->length) __builtin_trap();
  ctx->vector_items[vector->offset + (uint64_t)index] = item;
  return handle;
}

static int64_t SYSV vector_drop(struct kexe_context *ctx, int64_t handle, int64_t count) {
  struct vector_cell *vector = checked_vector(ctx, handle);
  if (count < 0 || (uint64_t)count > vector->length) __builtin_trap();
  return intern_vector(ctx, vector->offset + (uint64_t)count,
                       vector->length - (uint64_t)count);
}

static int64_t SYSV string_equal(struct kexe_context *ctx,
                                 int64_t left, int64_t right) {
  struct pair_cell *a = checked_pair(ctx, left);
  struct pair_cell *b = checked_pair(ctx, right);
  const uint8_t *a_bytes, *b_bytes;
  if (a->second != b->second) return 0;
  a_bytes = resolve_string_bytes(ctx, a->first, a->second);
  b_bytes = resolve_string_bytes(ctx, b->first, b->second);
  return memcmp(a_bytes, b_bytes, (size_t)a->second) == 0 ? 1 : 0;
}

/* Validate the string behind HANDLE once and remember it on the handle;
 * see pair_validated's comment for the soundness argument. */
static int ensure_valid_string(struct kexe_context *ctx, int64_t handle,
                               const uint8_t *bytes, int64_t length) {
  uint64_t index = (uint64_t)handle - 1;
  if (ctx->pair_validated[index]) return 1;
  if (!valid_utf8(bytes, (uint64_t)length)) return 0;
  ctx->pair_validated[index] = 1;
  return 1;
}

static int64_t mark_validated(struct kexe_context *ctx, int64_t handle) {
  if (handle > 0) ctx->pair_validated[(uint64_t)handle - 1] = 1;
  return handle;
}

static int64_t SYSV string_concat(struct kexe_context *ctx,
                                  int64_t left, int64_t right) {
  struct pair_cell *a = checked_pair(ctx, left);
  struct pair_cell *b = checked_pair(ctx, right);
  int64_t total;
  uint64_t start;
  const uint8_t *a_bytes, *b_bytes;
  if (a->second < 0 || b->second < 0 || a->second > INT64_MAX - b->second)
    __builtin_trap();
  total = a->second + b->second;
  a_bytes = resolve_string_bytes(ctx, a->first, a->second);
  b_bytes = resolve_string_bytes(ctx, b->first, b->second);
  /* TAIL APPEND, as in kexe_loader.c's checked_string_concat (2026-09-15):
   * when LEFT is the pool's last allocation, only RIGHT is copied and
   * charged, and the result is a longer view of the same bytes. */
  if (a->first < 0 &&
      (uint64_t)(-(a->first + 1)) + (uint64_t)a->second == ctx->string_pool_used) {
    if (ctx->string_pool_used + (uint64_t)b->second > KEXE_STRING_POOL_BYTES ||
        ctx->string_pool_used + (uint64_t)b->second < ctx->string_pool_used)
      __builtin_trap();
    start = (uint64_t)(-(a->first + 1));
    memmove(ctx->string_pool + ctx->string_pool_used, b_bytes, (size_t)b->second);
    ctx->string_pool_used += (uint64_t)b->second;
  } else {
    if (ctx->string_pool_used + (uint64_t)total > KEXE_STRING_POOL_BYTES ||
        ctx->string_pool_used + (uint64_t)total < ctx->string_pool_used)
      __builtin_trap();
    start = ctx->string_pool_used;
    memcpy(ctx->string_pool + start, a_bytes, (size_t)a->second);
    memcpy(ctx->string_pool + start + (uint64_t)a->second,
           b_bytes, (size_t)b->second);
    ctx->string_pool_used += (uint64_t)total;
  }
  {
    /* Concatenation of two valid UTF-8 strings is valid UTF-8. */
    int inputs_validated = ctx->pair_validated[(uint64_t)left - 1] &&
                           ctx->pair_validated[(uint64_t)right - 1];
    int64_t result = pair_new(ctx, -((int64_t)start) - 1, total);
    if (inputs_validated) mark_validated(ctx, result);
    return result;
  }
}

/* See kexe_loader.c's checked_string_substring for why the two failures and
 * the UTF-8 validation are exactly these, and why the result is a view that
 * subtracts `start` for pool-backed (negative) offsets. */
static int64_t SYSV string_substring(struct kexe_context *ctx, int64_t handle,
                                     int64_t start, int64_t end) {
  struct pair_cell *source = checked_pair(ctx, handle);
  int64_t offset = source->first;
  int64_t length = source->second;
  const uint8_t *bytes;
  if (length < 0 || start < 0 || end < start || end > length)
    __builtin_trap();
  bytes = resolve_string_bytes(ctx, offset, length);
  if (!ensure_valid_string(ctx, handle, bytes, length)) __builtin_trap();
  if (start < length && (bytes[start] & 0xc0) == 0x80) __builtin_trap();
  if (end < length && (bytes[end] & 0xc0) == 0x80) __builtin_trap();
  /* A code-point-bounded view of a valid string is itself valid. */
  return mark_validated(ctx,
                        pair_new(ctx, offset >= 0 ? offset + start : offset - start,
                                 end - start));
}

/* See kexe_loader.c's checked_arena_enter / checked_arena_leave (ABI v6). */
static int64_t SYSV arena_enter(struct kexe_context *ctx) {
  uint64_t *mark;
  if (ctx->arena_scope_depth >= 256u) __builtin_trap();
  mark = ctx->arena_scope_marks[ctx->arena_scope_depth];
  mark[0] = ctx->pair_used;
  mark[1] = ctx->string_pool_used;
  mark[2] = ctx->vector_used;
  mark[3] = ctx->vector_item_used;
  ctx->arena_scope_depth++;
  return 0;
}

static int64_t SYSV arena_leave(struct kexe_context *ctx) {
  const uint64_t *mark;
  if (ctx->arena_scope_depth == 0) __builtin_trap();
  ctx->arena_scope_depth--;
  mark = ctx->arena_scope_marks[ctx->arena_scope_depth];
  if (mark[0] > ctx->pair_used || mark[1] > ctx->string_pool_used ||
      mark[2] > ctx->vector_used || mark[3] > ctx->vector_item_used)
    __builtin_trap();
  ctx->pair_used = mark[0];
  ctx->string_pool_used = mark[1];
  ctx->vector_used = mark[2];
  ctx->vector_item_used = mark[3];
  return 0;
}

/* See kexe_loader.c's checked_string_compare / _fold_ascii / _scan_blank
 * (ABI v7), mirrored line for line. */
static int64_t SYSV string_compare(struct kexe_context *ctx, int64_t left, int64_t right) {
  struct pair_cell *a = checked_pair(ctx, left);
  struct pair_cell *b = checked_pair(ctx, right);
  const uint8_t *ab, *bb;
  size_t common;
  int c;
  if (a->second < 0 || b->second < 0) __builtin_trap();
  ab = resolve_string_bytes(ctx, a->first, a->second);
  bb = resolve_string_bytes(ctx, b->first, b->second);
  if (!ensure_valid_string(ctx, left, ab, a->second) ||
      !ensure_valid_string(ctx, right, bb, b->second)) __builtin_trap();
  common = (size_t)(a->second < b->second ? a->second : b->second);
  c = memcmp(ab, bb, common);
  if (c < 0) return -1;
  if (c > 0) return 1;
  if (a->second < b->second) return -1;
  if (a->second > b->second) return 1;
  return 0;
}

static int64_t SYSV string_fold_ascii(struct kexe_context *ctx, int64_t handle) {
  struct pair_cell *p = checked_pair(ctx, handle);
  const uint8_t *bytes;
  uint8_t *out;
  uint64_t start;
  int64_t i;
  if (p->second < 0) __builtin_trap();
  bytes = resolve_string_bytes(ctx, p->first, p->second);
  if (!ensure_valid_string(ctx, handle, bytes, p->second)) __builtin_trap();
  if (ctx->string_pool_used + (uint64_t)p->second > KEXE_STRING_POOL_BYTES ||
      ctx->string_pool_used + (uint64_t)p->second < ctx->string_pool_used)
    __builtin_trap();
  start = ctx->string_pool_used;
  out = ctx->string_pool + start;
  for (i = 0; i < p->second; i++) {
    uint8_t c = bytes[i];
    out[i] = (c >= 'A' && c <= 'Z') ? (uint8_t)(c + 32) : c;
  }
  ctx->string_pool_used += (uint64_t)p->second;
  return mark_validated(ctx, pair_new(ctx, -((int64_t)start) - 1, p->second));
}

static int win_blank_byte(uint8_t c) {
  return c == ' ' || c == '\t' || c == '\n' || c == '\v' || c == '\f' || c == '\r';
}

static int64_t string_scan_blank(struct kexe_context *ctx, int64_t handle, int64_t from,
                                 int wanted, int missing_is_length) {
  struct pair_cell *p = checked_pair(ctx, handle);
  const uint8_t *bytes;
  int64_t i;
  if (p->second < 0 || from < 0 || from > p->second) __builtin_trap();
  bytes = resolve_string_bytes(ctx, p->first, p->second);
  if (!ensure_valid_string(ctx, handle, bytes, p->second)) __builtin_trap();
  if (from < p->second && (bytes[from] & 0xc0) == 0x80) __builtin_trap();
  for (i = from; i < p->second; i++) {
    if (win_blank_byte(bytes[i]) == wanted) return i;
  }
  return missing_is_length ? p->second : -1;
}

static int64_t SYSV string_find_blank(struct kexe_context *ctx, int64_t handle, int64_t from) {
  return string_scan_blank(ctx, handle, from, 1, 0);
}

static int64_t SYSV string_skip_blank(struct kexe_context *ctx, int64_t handle, int64_t from) {
  return string_scan_blank(ctx, handle, from, 0, 1);
}

/* See kexe_loader.c's checked_string_index_of. Windows has no memmem; a
 * first-byte scan with memchr and a memcmp on each candidate is the same
 * answer, and both operands are validated once per handle, so a byte match
 * is a code-point-boundary match. */
static int64_t SYSV string_index_of(struct kexe_context *ctx, int64_t haystack,
                                    int64_t needle) {
  struct pair_cell *h = checked_pair(ctx, haystack);
  struct pair_cell *n = checked_pair(ctx, needle);
  int64_t length_h = h->second, length_n = n->second;
  const uint8_t *hb, *nb, *cursor, *end;
  if (length_h < 0 || length_n <= 0) __builtin_trap();
  hb = resolve_string_bytes(ctx, h->first, length_h);
  nb = resolve_string_bytes(ctx, n->first, length_n);
  if (!ensure_valid_string(ctx, haystack, hb, length_h) ||
      !ensure_valid_string(ctx, needle, nb, length_n)) __builtin_trap();
  if (length_n > length_h) return -1;
  cursor = hb;
  end = hb + (length_h - length_n) + 1;
  while (cursor < end) {
    const uint8_t *hit = (const uint8_t *)memchr(cursor, nb[0], (size_t)(end - cursor));
    if (hit == NULL) return -1;
    if (memcmp(hit, nb, (size_t)length_n) == 0) return (int64_t)(hit - hb);
    cursor = hit + 1;
  }
  return -1;
}

/* ABI v8: see kexe_loader.c's checked_string_index_of_from -- the same
 * memchr-first search from a boundary FROM, answering an ABSOLUTE offset. */
static int64_t SYSV string_index_of_from(struct kexe_context *ctx, int64_t haystack,
                                         int64_t needle, int64_t from) {
  struct pair_cell *h = checked_pair(ctx, haystack);
  struct pair_cell *n = checked_pair(ctx, needle);
  int64_t length_h = h->second, length_n = n->second;
  const uint8_t *hb, *nb, *cursor, *end;
  if (length_h < 0 || length_n <= 0 || from < 0 || from > length_h) __builtin_trap();
  hb = resolve_string_bytes(ctx, h->first, length_h);
  nb = resolve_string_bytes(ctx, n->first, length_n);
  if (!ensure_valid_string(ctx, haystack, hb, length_h) ||
      !ensure_valid_string(ctx, needle, nb, length_n)) __builtin_trap();
  if (from < length_h && (hb[from] & 0xc0) == 0x80) __builtin_trap();
  if (length_n > length_h - from) return -1;
  cursor = hb + from;
  end = hb + (length_h - length_n) + 1;
  while (cursor < end) {
    const uint8_t *hit = (const uint8_t *)memchr(cursor, nb[0], (size_t)(end - cursor));
    if (hit == NULL) return -1;
    if (memcmp(hit, nb, (size_t)length_n) == 0) return (int64_t)(hit - hb);
    cursor = hit + 1;
  }
  return -1;
}

static int64_t win_line_length(const uint8_t *bytes, int64_t length, int64_t start) {
  const uint8_t *nl = (const uint8_t *)memchr(bytes + start, '\n', (size_t)(length - start));
  return nl == NULL ? length - start : (int64_t)(nl - (bytes + start));
}

/* ABI v8: see kexe_loader.c's checked_string_compare_lines. The fourth
 * argument is the fifth SysV parameter (r8). */
static int64_t SYSV string_compare_lines(struct kexe_context *ctx, int64_t handle_a,
                                         int64_t i, int64_t handle_b, int64_t j) {
  struct pair_cell *pa = checked_pair(ctx, handle_a);
  struct pair_cell *pb = checked_pair(ctx, handle_b);
  int64_t length_a = pa->second, length_b = pb->second, la, lb;
  const uint8_t *a, *b;
  size_t common;
  int c;
  if (length_a < 0 || length_b < 0 || i < 0 || i > length_a || j < 0 || j > length_b)
    __builtin_trap();
  a = resolve_string_bytes(ctx, pa->first, length_a);
  b = resolve_string_bytes(ctx, pb->first, length_b);
  if (!ensure_valid_string(ctx, handle_a, a, length_a) ||
      !ensure_valid_string(ctx, handle_b, b, length_b)) __builtin_trap();
  if (i < length_a && (a[i] & 0xc0) == 0x80) __builtin_trap();
  if (j < length_b && (b[j] & 0xc0) == 0x80) __builtin_trap();
  la = win_line_length(a, length_a, i);
  lb = win_line_length(b, length_b, j);
  common = (size_t)(la < lb ? la : lb);
  c = memcmp(a + i, b + j, common);
  if (c < 0) return -1;
  if (c > 0) return 1;
  if (la < lb) return -1;
  if (la > lb) return 1;
  return 0;
}

/* ABI v10: see kexe_loader.c's checked_string_find_byte. */
static int64_t SYSV string_find_byte(struct kexe_context *ctx, int64_t handle,
                                     int64_t byte, int64_t from) {
  struct pair_cell *p = checked_pair(ctx, handle);
  const uint8_t *bytes, *hit;
  if (p->second < 0 || byte < 0 || byte > 127 || from < 0 || from > p->second) __builtin_trap();
  bytes = resolve_string_bytes(ctx, p->first, p->second);
  if (!ensure_valid_string(ctx, handle, bytes, p->second)) __builtin_trap();
  if (from < p->second && (bytes[from] & 0xc0) == 0x80) __builtin_trap();
  if (from == p->second) return -1;
  hit = (const uint8_t *)memchr(bytes + from, (int)byte, (size_t)(p->second - from));
  return hit == NULL ? -1 : (int64_t)(hit - bytes);
}

/* ABI v10: see kexe_loader.c's checked_string_append_range -- the same tail
 * append string_concat has here. The fourth argument is the fifth SysV
 * parameter (r8). */
static int64_t SYSV string_append_range(struct kexe_context *ctx, int64_t acc,
                                        int64_t handle, int64_t start, int64_t end) {
  struct pair_cell *pa = checked_pair(ctx, acc);
  struct pair_cell *ps = checked_pair(ctx, handle);
  const uint8_t *a, *b;
  int64_t length_a = pa->second, length_s = ps->second, length_b, total;
  uint64_t pool_offset;
  int a_is_tail;
  if (length_a < 0 || length_s < 0 || start < 0 || end < start || end > length_s ||
      length_a > INT64_MAX - (end - start)) __builtin_trap();
  a = resolve_string_bytes(ctx, pa->first, length_a);
  b = resolve_string_bytes(ctx, ps->first, length_s);
  if (!ensure_valid_string(ctx, acc, a, length_a) ||
      !ensure_valid_string(ctx, handle, b, length_s)) __builtin_trap();
  if (start < length_s && (b[start] & 0xc0) == 0x80) __builtin_trap();
  if (end < length_s && (b[end] & 0xc0) == 0x80) __builtin_trap();
  length_b = end - start;
  total = length_a + length_b;
  pool_offset = ctx->string_pool_used;
  a_is_tail = pa->first < 0 &&
              (uint64_t)(-(pa->first + 1)) + (uint64_t)length_a == ctx->string_pool_used;
  if (a_is_tail) {
    if (ctx->string_pool_used + (uint64_t)length_b > KEXE_STRING_POOL_BYTES ||
        ctx->string_pool_used + (uint64_t)length_b < ctx->string_pool_used) __builtin_trap();
    pool_offset = (uint64_t)(-(pa->first + 1));
    memmove(ctx->string_pool + ctx->string_pool_used, b + start, (size_t)length_b);
    ctx->string_pool_used += (uint64_t)length_b;
  } else {
    if (ctx->string_pool_used + (uint64_t)total > KEXE_STRING_POOL_BYTES ||
        ctx->string_pool_used + (uint64_t)total < ctx->string_pool_used) __builtin_trap();
    memmove(ctx->string_pool + pool_offset, a, (size_t)length_a);
    memmove(ctx->string_pool + pool_offset + (uint64_t)length_a, b + start, (size_t)length_b);
    ctx->string_pool_used += (uint64_t)total;
  }
  return mark_validated(ctx, pair_new(ctx, -((int64_t)pool_offset) - 1, total));
}

/* ABI v11: see kexe_loader.c's checked_string_from_utf8 -- canonical UTF-8
 * only, the same walk; a refusal traps. */
static int canonical_utf8_items(const int64_t *items, uint64_t n) {
  uint64_t i = 0, j, k;
  int64_t b0, b1;
  while (i < n) {
    b0 = items[i];
    if (b0 < 0 || b0 > 255) return 0;
    if (b0 < 0x80) { i++; continue; }
    if (b0 < 0xc2 || b0 > 0xf4 || i + 1 >= n) return 0;
    b1 = items[i + 1];
    k = b0 < 0xe0 ? 1 : b0 < 0xf0 ? 2 : 3;
    if ((b1 & 0xc0) != 0x80 || b1 > 255 ||
        (b0 == 0xe0 && b1 < 0xa0) || (b0 == 0xf0 && b1 < 0x90) ||
        (b0 == 0xed && b1 >= 0xa0) || (b0 == 0xf4 && b1 >= 0x90)) return 0;
    for (j = 2; j <= k; j++)
      if (i + j >= n || (items[i + j] & 0xc0) != 0x80 || items[i + j] > 255) return 0;
    i += k + 1;
  }
  return 1;
}

static int64_t SYSV string_from_utf8(struct kexe_context *ctx, int64_t handle) {
  struct vector_cell *vector = checked_vector(ctx, handle);
  uint64_t n = vector->length, i, pool_offset;
  const int64_t *items = &ctx->vector_items[vector->offset];
  if (n > 65536u || !canonical_utf8_items(items, n)) __builtin_trap();
  if (ctx->string_pool_used + n > KEXE_STRING_POOL_BYTES) __builtin_trap();
  pool_offset = ctx->string_pool_used;
  for (i = 0; i < n; i++) ctx->string_pool[pool_offset + i] = (uint8_t)items[i];
  ctx->string_pool_used += n;
  return mark_validated(ctx, pair_new(ctx, -((int64_t)pool_offset) - 1, (int64_t)n));
}

static int64_t SYSV bytes_from_vector(struct kexe_context *ctx, int64_t handle) {
  struct vector_cell *vector = checked_vector(ctx, handle);
  uint64_t offset = vector->offset, n = vector->length, i, destination;
  if (n > 65536u) __builtin_trap();
  for (i = 0; i < n; i++)
    if (ctx->vector_items[offset + i] < 0 || ctx->vector_items[offset + i] > 255) __builtin_trap();
  if (ctx->vector_item_used + n > KEXE_VECTOR_ITEM_CAPACITY) __builtin_trap();
  destination = ctx->vector_item_used;
  memmove(&ctx->vector_items[destination], &ctx->vector_items[offset], (size_t)n * sizeof(int64_t));
  ctx->vector_item_used += n;
  return intern_vector(ctx, destination, n);
}

static int64_t SYSV bytes_slice(struct kexe_context *ctx, int64_t handle,
                                int64_t start, int64_t end) {
  struct vector_cell *vector = checked_vector(ctx, handle);
  if (start < 0 || end < start || (uint64_t)end > vector->length) __builtin_trap();
  return intern_vector(ctx, vector->offset + (uint64_t)start, (uint64_t)(end - start));
}

static int64_t SYSV bytes_concat(struct kexe_context *ctx, int64_t left, int64_t right) {
  struct vector_cell *a = checked_vector(ctx, left);
  struct vector_cell *b = checked_vector(ctx, right);
  uint64_t a_offset = a->offset, a_length = a->length;
  uint64_t b_offset = b->offset, b_length = b->length, destination;
  if (a_length + b_length > 65536u) __builtin_trap();
  if (ctx->vector_item_used + a_length + b_length > KEXE_VECTOR_ITEM_CAPACITY) __builtin_trap();
  destination = ctx->vector_item_used;
  memmove(&ctx->vector_items[destination], &ctx->vector_items[a_offset], (size_t)a_length * sizeof(int64_t));
  memmove(&ctx->vector_items[destination + a_length], &ctx->vector_items[b_offset], (size_t)b_length * sizeof(int64_t));
  ctx->vector_item_used += a_length + b_length;
  return intern_vector(ctx, destination, a_length + b_length);
}

/* See kexe_loader.c's checked_string_code_point_at: offset must be a
 * code-point boundary in [0, byte-length), exclusive upper bound. */
static int64_t SYSV string_code_point_at(struct kexe_context *ctx, int64_t handle,
                                         int64_t byte_offset) {
  struct pair_cell *source = checked_pair(ctx, handle);
  int64_t offset = source->first;
  int64_t length = source->second;
  const uint8_t *bytes;
  const uint8_t *p;
  uint8_t a;
  if (length < 0 || byte_offset < 0 || byte_offset >= length) __builtin_trap();
  bytes = resolve_string_bytes(ctx, offset, length);
  if (!ensure_valid_string(ctx, handle, bytes, length)) __builtin_trap();
  p = bytes + byte_offset;
  a = p[0];
  if ((a & 0xc0) == 0x80) __builtin_trap();
  if (a <= 0x7f) return a;
  if (a >= 0xc2 && a <= 0xdf) return ((int64_t)(a & 0x1f) << 6) | (p[1] & 0x3f);
  if (a >= 0xe0 && a <= 0xef)
    return ((int64_t)(a & 0x0f) << 12) | ((int64_t)(p[1] & 0x3f) << 6) | (p[2] & 0x3f);
  if (a >= 0xf0 && a <= 0xf4)
    return ((int64_t)(a & 0x07) << 18) | ((int64_t)(p[1] & 0x3f) << 12) |
           ((int64_t)(p[2] & 0x3f) << 6) | (p[3] & 0x3f);
  __builtin_trap();
  return 0;
}

static int valid_typed_value(struct kexe_context *ctx,
                             uint64_t kind, int64_t value) {
  struct pair_cell *pair = checked_pair(ctx, value);
  if (kind == 1) {
    const uint8_t *bytes = resolve_string_bytes(ctx, pair->first, pair->second);
    return ensure_valid_string(ctx, value, bytes, pair->second);
  }
  if (kind == 2 || kind == 3) {
    if (pair->first != 0 && pair->first != 1) return 0;
    return kind != 2 || pair->first != 0 || pair->second == 0;
  }
  if (kind == 4) {
    int64_t ordinal = 0, payload = 0, fields[KEXE_RECORD_FIELD_LIMIT];
    if (inspect_variant_result(ctx, value, 2, 3u, &ordinal, &payload)) return 1;
    if (!inspect_variant_result(ctx, value, 3, 0, &ordinal, &payload)) return 0;
    if (ordinal == 0 || ordinal == 1) {
      if (!inspect_record_result(ctx, payload, 2, fields)) return 0;
      return fields[0] >= 0 && fields[1] > 0;
    }
    if (ordinal == 2) return inspect_record_result(ctx, payload, 2, fields);
    return 0;
  }
  return 0;
}

static int64_t intern_pool_string(struct kexe_context *ctx, const char *text) {
  size_t n;
  uint64_t off;
  if (ctx == NULL || text == NULL) __builtin_trap();
  n = strlen(text);
  if (n > KEXE_STRING_POOL_BYTES ||
      ctx->string_pool_used + n > KEXE_STRING_POOL_BYTES) __builtin_trap();
  off = ctx->string_pool_used;
  memcpy(ctx->string_pool + off, text, n);
  ctx->string_pool_used += n;
  return pair_new(ctx, -((int64_t)off) - 1, (int64_t)n);
}

static int read_wall_millis(int64_t *out) {
  FILETIME ft;
  ULARGE_INTEGER t;
  GetSystemTimeAsFileTime(&ft);
  t.LowPart = ft.dwLowDateTime;
  t.HighPart = ft.dwHighDateTime;
  if (t.QuadPart < 116444736000000000ULL) return -1;
  *out = (int64_t)((t.QuadPart - 116444736000000000ULL) / 10000ULL);
  return 0;
}

static int read_monotonic_nanos(int64_t *out) {
  LARGE_INTEGER freq, now;
  int64_t sec, rem;
  if (!QueryPerformanceFrequency(&freq) || !QueryPerformanceCounter(&now) ||
      freq.QuadPart <= 0) return -1;
  sec = now.QuadPart / freq.QuadPart;
  rem = now.QuadPart % freq.QuadPart;
  if (sec > (INT64_MAX - (rem * 1000000000LL / freq.QuadPart)) / 1000000000LL)
    return -1;
  *out = sec * 1000000000LL + rem * 1000000000LL / freq.QuadPart;
  return 0;
}

static int64_t clock_error_result(struct kexe_context *ctx,
                                  const char *code, const char *message) {
  int64_t code_handle = intern_pool_string(ctx, code);
  int64_t message_handle = intern_pool_string(ctx, message);
  int64_t record = pair_new(ctx, message_handle, 0);
  record = pair_new(ctx, code_handle, record);
  return pair_new(ctx, 2, record);
}

static int64_t hosted_clock_v1(struct kexe_context *ctx, int64_t request) {
  static int64_t observation_sequence = 0;
  static int64_t last_monotonic = -1;
  int64_t ordinal = 0, payload = 0, tick = 0, record;
  if (!inspect_variant_result(ctx, request, 2, 3u, &ordinal, &payload))
    __builtin_trap();
  if (observation_sequence == INT64_MAX) __builtin_trap();
  if (ordinal == 0) {
    if (read_wall_millis(&tick) != 0 || tick < 0)
      return clock_error_result(ctx, ":clock/source", "clock source failed");
    record = pair_new(ctx, ++observation_sequence, 0);
    record = pair_new(ctx, tick, record);
    return pair_new(ctx, 0, record);
  }
  if (ordinal == 1) {
    if (read_monotonic_nanos(&tick) != 0 || tick < 0)
      return clock_error_result(ctx, ":clock/source", "clock source failed");
    if (last_monotonic >= 0 && tick < last_monotonic)
      return clock_error_result(ctx, ":clock/regressed",
                                "monotonic clock regressed");
    last_monotonic = tick;
    record = pair_new(ctx, ++observation_sequence, 0);
    record = pair_new(ctx, tick, record);
    return pair_new(ctx, 1, record);
  }
  __builtin_trap();
  return 0;
}

static int64_t SYSV typed_cap_call(struct kexe_context *ctx, uint64_t id,
                                   uint64_t request_kind, uint64_t result_kind,
                                   int64_t request) {
  int64_t result;
  if (ctx == NULL || ctx->version != 11 || id > 255 ||
      !(ctx->allow[id / 8] & (1u << (id % 8))) ||
      request_kind != result_kind ||
      !valid_typed_value(ctx, request_kind, request))
    __builtin_trap();
  if (request_kind == 4) {
    if (id != 7) __builtin_trap();
    result = hosted_clock_v1(ctx, request);
  } else {
    result = request;
  }
  if (!valid_typed_value(ctx, result_kind, result)) __builtin_trap();
  return result;
}

static uint64_t parse_u64(const char *text, const char *name) {
  char *end = NULL;
  unsigned long long value;
  if (text == NULL || *text == '\0' || *text == '-') fail_input(name);
  errno = 0;
  value = strtoull(text, &end, 10);
  if (errno != 0 || end == text || *end != '\0') fail_input(name);
  return (uint64_t)value;
}

static int64_t parse_i64(const char *text) {
  char *end = NULL;
  long long value;
  if (text == NULL || *text == '\0') fail_input("invalid i64 argument");
  errno = 0;
  value = strtoll(text, &end, 10);
  if (errno != 0 || end == text || *end != '\0') fail_input("invalid i64 argument");
  return (int64_t)value;
}

static void parse_allow(struct kexe_context *ctx, const char *text) {
  const char *cursor = text;
  if (strcmp(text, "-") == 0) return;
  while (*cursor) {
    char *end = NULL;
    unsigned long id;
    errno = 0;
    id = strtoul(cursor, &end, 10);
    if (errno != 0 || end == cursor || id > 255 || (*end != ',' && *end != '\0'))
      fail_input("invalid capability allowlist");
    ctx->allow[id / 8] |= (uint8_t)(1u << (id % 8));
    cursor = *end == ',' ? end + 1 : end;
    if (*end == ',' && *cursor == '\0') fail_input("invalid capability allowlist");
  }
}

static HANDLE restricted_token(void) {
  HANDLE process_token = NULL, token = NULL, impersonation = NULL;
  PSID low_sid = NULL;
  TOKEN_MANDATORY_LABEL label;
  if (!OpenProcessToken(GetCurrentProcess(), TOKEN_DUPLICATE | TOKEN_QUERY | TOKEN_IMPERSONATE |
                        TOKEN_ADJUST_DEFAULT | TOKEN_ASSIGN_PRIMARY,
                        &process_token)) fail_win("OpenProcessToken");
  if (!CreateRestrictedToken(process_token, DISABLE_MAX_PRIVILEGE | LUA_TOKEN,
                             0, NULL, 0, NULL, 0, NULL, &token))
    fail_win("CreateRestrictedToken");
  CloseHandle(process_token);
  if (!ConvertStringSidToSidW(L"S-1-16-4096", &low_sid)) fail_win("ConvertStringSidToSidW");
  label.Label.Attributes = SE_GROUP_INTEGRITY;
  label.Label.Sid = low_sid;
  if (!SetTokenInformation(token, TokenIntegrityLevel, &label,
                           (DWORD)(sizeof(label) + GetLengthSid(low_sid))))
    fail_win("SetTokenInformation low integrity");
  LocalFree(low_sid);
  if (!DuplicateTokenEx(token, TOKEN_QUERY | TOKEN_IMPERSONATE, NULL,
                        SecurityImpersonation, TokenImpersonation, &impersonation))
    fail_win("DuplicateTokenEx impersonation");
  CloseHandle(token);
  return impersonation;
}

static void require_appcontainer_token(void) {
  HANDLE token = NULL;
  DWORD is_appcontainer = 0, returned = 0;
  TOKEN_GROUPS *capability_groups = NULL;
  if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token))
    fail_win("OpenProcessToken AppContainer verification");
  if (!GetTokenInformation(token, TokenIsAppContainer, &is_appcontainer,
                           sizeof(is_appcontainer), &returned))
    fail_win("GetTokenInformation TokenIsAppContainer");
  GetTokenInformation(token, TokenCapabilities, NULL, 0, &returned);
  if (GetLastError() != ERROR_INSUFFICIENT_BUFFER) fail_win("TokenCapabilities size");
  capability_groups = (TOKEN_GROUPS *)malloc(returned);
  if (capability_groups == NULL ||
      !GetTokenInformation(token, TokenCapabilities, capability_groups,
                           returned, &returned))
    fail_win("GetTokenInformation TokenCapabilities");
  CloseHandle(token);
  if (!is_appcontainer)
    fail_input("child contract requires an AppContainer process token");
  if (capability_groups->GroupCount != 0)
    fail_input("AppContainer child unexpectedly has capability SIDs");
  free(capability_groups);
}

static void prohibit_dynamic_code(void) {
  PROCESS_MITIGATION_DYNAMIC_CODE_POLICY policy;
  ZeroMemory(&policy, sizeof(policy));
  policy.ProhibitDynamicCode = 1;
  if (!SetProcessMitigationPolicy(ProcessDynamicCodePolicy, &policy, sizeof(policy))) {
    ZeroMemory(&policy, sizeof(policy));
    if (!GetProcessMitigationPolicy(GetCurrentProcess(), ProcessDynamicCodePolicy,
                                    &policy, sizeof(policy)) || !policy.ProhibitDynamicCode)
      fail_win("SetProcessMitigationPolicy dynamic code");
  }
}

/*
 * Windows Filtering Platform (WFP) per-process network denial.
 *
 * The restricted/low-integrity token applied by restricted_token() does not
 * reliably block Winsock: MIC is a write-up denial mechanism for securable
 * objects and \Device\Afd is not integrity-labeled by default, so a Low-IL
 * token alone does not stop socket()/connect(). This installs an explicit
 * block filter, keyed to this executable's own ALE application id, at the
 * ALE_AUTH_CONNECT layers (outbound) and the ALE_AUTH_RECV_ACCEPT layers
 * (inbound), so both directions are denied regardless of token integrity.
 *
 * This must run while the process still holds its original (non-restricted)
 * privileges -- i.e. before restricted_token()/SetThreadToken -- mirroring
 * the "privileged setup, then restrict" ordering already used for the Job
 * object in create_guest_job(). Every WFP call is fail-closed: any
 * failure here aborts the loader via fail_win() before guest entry, rather
 * than silently proceeding without network denial.
 *
 * The engine session is opened with FWPM_SESSION_FLAG_DYNAMIC, so the BFE
 * (Base Filtering Engine) automatically tears down these filters when the
 * engine handle closes or this process exits/crashes; the handle is
 * intentionally retained (never closed) until process exit, the same
 * pattern run_appcontainer_parent() uses for its Job handle.
 *
 * Hosted x86_64 and Arm64 Windows CI exercises these BFE calls. They remain
 * fail-closed defense in depth; the zero-capability AppContainer token is the
 * primary network boundary.
 *
 * UPDATE (first real CI run, PR #67): FwpmEngineOpen0/FwpmFilterAdd0 did NOT
 * fail (the admin-privilege risk above did not materialize -- every
 * loader invocation in that run, including the plain non-probe ones, got
 * this far without fail_win() firing). The failure was downstream, at the
 * KEXE_NETWORK_PROBE assertion in scripts/windows-profile-conformance.cljk:
 * the probe process exited with a code other than 77, meaning the loopback
 * connect() in connect_and_require_denial() did not resolve to WSAEACCES as
 * expected. Root cause is not confirmed. The filter as originally written
 * requested FWP_EMPTY (auto-assigned) weight, which only ranks this filter
 * among other auto-weighted filters in FWPM_SUBLAYER_UNIVERSAL -- it does
 * not guarantee precedence over higher-weighted filters that may already
 * exist there (from other software, or an OS-default permissive rule for
 * loopback/local traffic). This revision requests maximum explicit weight
 * instead, as a defensive hardening; whether that was in fact the cause was
 * unverified at that stage.
 * connect_and_require_denial() below was also expanded, at the same time,
 * to print an unambiguous diagnostic line on every resolution path (which
 * WSA error, synchronous vs. post-select, or a timeout), so a repeat
 * failure will show the actual cause in the CI log instead of a bare
 * "exit mismatch".
 *
 * UPDATE (second real CI run, PR #67, confirmed root cause): the maximum-
 * weight hardening above did not change the outcome -- the probe's loopback
 * connect() still timed out waiting for a policy decision (see the expanded
 * diagnostics added above; the exact line was "network probe timed out
 * after 2s ... most likely means the WFP block filter is not being
 * evaluated/applied for this connection at all"). This is a documented WFP
 * behavior, not a weight/ordering problem: per Microsoft's Filtering
 * condition flags reference (FWP_CONDITION_FLAG_IS_LOOPBACK, Fwptypes.h),
 * loopback traffic is a distinct classification at the ALE_AUTH_CONNECT and
 * ALE_AUTH_RECV_ACCEPT layers, and a filter that does not explicitly test
 * for it is not guaranteed to be evaluated against loopback connections at
 * all -- it is scoped to "real" (non-loopback) traffic by default. That
 * matches the observed symptom exactly: an unfiltered loopback connect() to
 * a closed port normally gets a fast, synchronous WSAECONNREFUSED (see the
 * comment in connect_and_require_denial()), but this probe instead hung
 * until the bounded `select()` timeout, i.e. it fell through to some
 * un-denied path rather than either succeeding or hitting this filter's
 * BLOCK action.
 *
 * The fix: install a SECOND, dedicated filter per layer that ANDs the same
 * ALE_APP_ID condition with an additional FWPM_CONDITION_FLAGS condition
 * (FWP_MATCH_FLAGS_ALL_SET, value FWP_CONDITION_FLAG_IS_LOOPBACK), so WFP
 * actually classifies and evaluates this app's loopback connections/accepts
 * against a BLOCK filter. The original app-id-only filter is kept unchanged
 * alongside it (not merged into one filter) precisely because a single
 * filter's conditions are AND-combined: adding an IS_LOOPBACK condition to
 * the *existing* filter would narrow it to loopback-only and stop it from
 * matching genuine (non-loopback) outbound/inbound traffic, which is the
 * actual guest-network-egress threat this boundary exists for. Two filters
 * per layer -- one general, one loopback-inclusive -- are required to deny
 * both without narrowing either. The authoritative AppContainer outbound
 * probe below exercises a non-loopback TEST-NET-1 target and requires
 * WSAEACCES.
 */
static void install_network_denial(void) {
  HANDLE engine = NULL;
  FWPM_SESSION0 session;
  FWPM_SUBLAYER0 sublayer;
  wchar_t module_path[MAX_PATH];
  FWP_BYTE_BLOB *app_id = NULL;
  FWPM_FILTER_CONDITION0 app_id_condition;
  FWPM_FILTER_CONDITION0 loopback_conditions[2];
  FWPM_FILTER0 filter;
  static const GUID *layers[] = {
    &KEXE_LAYER_ALE_AUTH_CONNECT_V4,
    &KEXE_LAYER_ALE_AUTH_CONNECT_V6,
    &KEXE_LAYER_ALE_AUTH_RECV_ACCEPT_V4,
    &KEXE_LAYER_ALE_AUTH_RECV_ACCEPT_V6,
  };
  DWORD status;
  size_t i;
  static const GUID denial_sublayer_key =
    {0x7a3b6d13, 0x0d5f, 0x4e87, {0x9e, 0x31, 0x42, 0x7c, 0x65, 0x1a, 0xb8, 0x04}};

  if (GetModuleFileNameW(NULL, module_path, MAX_PATH) == 0) fail_win("GetModuleFileNameW");

  ZeroMemory(&session, sizeof(session));
  session.flags = FWPM_SESSION_FLAG_DYNAMIC;
  status = FwpmEngineOpen0(NULL, RPC_C_AUTHN_WINNT, NULL, &session, &engine);
  if (status != ERROR_SUCCESS) { SetLastError(status); fail_win("FwpmEngineOpen0"); }

  /* Filter weight is compared only inside one sublayer. The universal
     sublayer can lose arbitration to a terminating permit in a higher-weight
     sublayer, which hosted Windows runners demonstrated. Own a maximum-weight
     dynamic sublayer and make each block terminating. */
  ZeroMemory(&sublayer, sizeof(sublayer));
  sublayer.subLayerKey = denial_sublayer_key;
  sublayer.displayData.name = L"kotoba-kexe-network-denial";
  sublayer.displayData.description = L"Fail-closed per-process KEXE network boundary";
  sublayer.weight = 0xffff;
  status = FwpmSubLayerAdd0(engine, &sublayer, NULL);
  if (status != ERROR_SUCCESS && status != (DWORD)FWP_E_ALREADY_EXISTS) {
    SetLastError(status);
    fail_win("FwpmSubLayerAdd0 denial");
  }

  status = FwpmGetAppIdFromFileName0(module_path, &app_id);
  if (status != ERROR_SUCCESS) { SetLastError(status); fail_win("FwpmGetAppIdFromFileName0"); }

  ZeroMemory(&app_id_condition, sizeof(app_id_condition));
  app_id_condition.fieldKey = KEXE_CONDITION_ALE_APP_ID;
  app_id_condition.matchType = FWP_MATCH_EQUAL;
  app_id_condition.conditionValue.type = FWP_BYTE_BLOB_TYPE;
  app_id_condition.conditionValue.byteBlob = app_id;

  ZeroMemory(&loopback_conditions, sizeof(loopback_conditions));
  loopback_conditions[0] = app_id_condition;
  loopback_conditions[1].fieldKey = KEXE_CONDITION_FLAGS;
  loopback_conditions[1].matchType = FWP_MATCH_FLAGS_ALL_SET;
  loopback_conditions[1].conditionValue.type = FWP_UINT32;
  loopback_conditions[1].conditionValue.uint32 =
    FWP_CONDITION_FLAG_IS_NON_APPCONTAINER_LOOPBACK;

  for (i = 0; i < sizeof(layers) / sizeof(layers[0]); i++) {
    UINT64 filter_id = 0;

    /* Filter A: general block, app id only. Per the function-comment
       update above, this is not proven (and, per the documented WFP
       loopback classification, should not be assumed) to cover loopback
       connections -- treat it as covering non-loopback traffic. */
    ZeroMemory(&filter, sizeof(filter));
    filter.layerKey = *layers[i];
    filter.subLayerKey = denial_sublayer_key;
    filter.displayData.name = L"kotoba-kexe-network-denial";
    filter.action.type = FWP_ACTION_BLOCK;
    filter.flags = FWPM_FILTER_FLAG_CLEAR_ACTION_RIGHT;
    filter.weight.type = FWP_UINT8;
    filter.weight.uint8 = 15;
    filter.numFilterConditions = 1;
    filter.filterCondition = &app_id_condition;
    status = FwpmFilterAdd0(engine, &filter, NULL, &filter_id);
    if (status != ERROR_SUCCESS) {
      FwpmFreeMemory0((void **)&app_id);
      SetLastError(status);
      fail_win("FwpmFilterAdd0 general");
    }
    fprintf(stderr, "kexe-loader-windows: network denial filter installed: layer=%zu filter_id=%llu "
                    "kind=general\n", i, (unsigned long long)filter_id);

    /* Filter B: standard-process loopback block, app id AND
       FWP_CONDITION_FLAG_IS_NON_APPCONTAINER_LOOPBACK. The generic loopback
       bit did not match this non-AppContainer process on hosted Windows. */
    filter_id = 0;
    ZeroMemory(&filter, sizeof(filter));
    filter.layerKey = *layers[i];
    filter.subLayerKey = denial_sublayer_key;
    filter.displayData.name = L"kotoba-kexe-network-denial-loopback";
    filter.action.type = FWP_ACTION_BLOCK;
    filter.flags = FWPM_FILTER_FLAG_CLEAR_ACTION_RIGHT;
    filter.weight.type = FWP_UINT8;
    filter.weight.uint8 = 15;
    filter.numFilterConditions = 2;
    filter.filterCondition = loopback_conditions;
    status = FwpmFilterAdd0(engine, &filter, NULL, &filter_id);
    if (status != ERROR_SUCCESS) {
      FwpmFreeMemory0((void **)&app_id);
      SetLastError(status);
      fail_win("FwpmFilterAdd0 loopback");
    }
    fprintf(stderr, "kexe-loader-windows: network denial filter installed: layer=%zu filter_id=%llu "
                    "kind=loopback\n", i, (unsigned long long)filter_id);
  }

  FwpmFreeMemory0((void **)&app_id);
  /* Intentionally retain the engine handle (and its dynamic session's
     filters) until process exit; see the function comment above. */
}

#if defined(_M_X64)
typedef int64_t (SYSV *guest_fn)(int64_t, int64_t, int64_t, int64_t, int64_t,
                                 struct kexe_context *);
#else
typedef int64_t (*guest_fn)(int64_t, int64_t, int64_t, int64_t,
                            int64_t, int64_t, int64_t, struct kexe_context *);
#endif

/*
 * Performs a non-blocking connect() to a caller-created live loopback
 * listener. The same path is proved reachable immediately before the WFP
 * filters are installed. After installation, either WSAEACCES or bounded
 * non-completion is a denial; a completed connection is a failure.
 */
static int connect_and_require_denial(SOCKET sock, const struct sockaddr_in *address) {
  u_long non_blocking = 1;
  fd_set write_set, except_set;
  struct timeval timeout;
  int error_value = 0;
  int error_length = sizeof(error_value);
  int select_result;

  if (ioctlsocket(sock, FIONBIO, &non_blocking) != 0) {
    fprintf(stderr, "kexe-loader-windows: network probe ioctlsocket failed: wsa=%d\n",
            WSAGetLastError());
    return 70;
  }
  if (connect(sock, (const struct sockaddr *)address, sizeof(*address)) == 0) {
    fprintf(stderr, "kexe-loader-windows: network probe connect() unexpectedly succeeded "
                    "synchronously (before any wait) -- the block filter did not deny it\n");
    return 70;
  }
  error_value = WSAGetLastError();
  if (error_value == WSAEACCES) {
    fprintf(stderr, "kexe-loader-windows: network probe denied synchronously by connect(): "
                    "wsa=WSAEACCES(%d)\n", error_value);
    return 0;
  }
  if (error_value != WSAEWOULDBLOCK) {
    /* Diagnostic note: on an un-filtered loopback connect to a closed port
       (nothing listening), Windows normally returns WSAECONNREFUSED here,
       fast and synchronously -- that is the expected symptom if the WFP
       block filter is not actually being applied to this connection. */
    fprintf(stderr, "kexe-loader-windows: network probe connect() failed synchronously with "
                    "unexpected code (expected WSAEACCES): wsa=%d\n", error_value);
    return 70;
  }
  fprintf(stderr, "kexe-loader-windows: network probe connect() returned WSAEWOULDBLOCK, "
                  "waiting up to 2s for async completion\n");
  FD_ZERO(&write_set);
  FD_ZERO(&except_set);
  FD_SET(sock, &write_set);
  FD_SET(sock, &except_set);
  timeout.tv_sec = 2;
  timeout.tv_usec = 0;
  select_result = select(0, NULL, &write_set, &except_set, &timeout);
  if (select_result == SOCKET_ERROR) {
    fprintf(stderr, "kexe-loader-windows: network probe select() itself failed: wsa=%d\n",
            WSAGetLastError());
    return 70;
  }
  if (select_result == 0) {
    fprintf(stderr, "kexe-loader-windows: network probe timed out; timeout is not proof of "
                    "AppContainer policy denial\n");
    return 70;
  }
  if (getsockopt(sock, SOL_SOCKET, SO_ERROR, (char *)&error_value, &error_length) != 0) {
    fprintf(stderr, "kexe-loader-windows: network probe getsockopt(SO_ERROR) failed: wsa=%d\n",
            WSAGetLastError());
    return 70;
  }
  if (error_value == WSAEACCES) {
    fprintf(stderr, "kexe-loader-windows: network probe denied asynchronously after select(): "
                    "wsa=WSAEACCES(%d)\n", error_value);
    return 0;
  }
  if (error_value == 0) {
    fprintf(stderr, "kexe-loader-windows: network probe connect() unexpectedly succeeded "
                    "asynchronously (SO_ERROR=0 after select) -- the block filter did not deny it\n");
    return 70;
  }
  fprintf(stderr, "kexe-loader-windows: network probe resolved asynchronously with unexpected "
                  "code (expected WSAEACCES): wsa=%d\n", error_value);
  return 70;
}

/* Outbound direction: AppContainer without internetClient must reject a
   non-loopback connect with WSAEACCES.  TEST-NET-1 is non-routable, so no
   external service is contacted; timeout/refusal is not accepted as proof. */
static int network_outbound_probe_denied(void) {
  WSADATA wsa_data;
  SOCKET sock = INVALID_SOCKET;
  struct sockaddr_in address;
  int denial;

  if (WSAStartup(MAKEWORD(2, 2), &wsa_data) != 0) {
    fprintf(stderr, "kexe-loader-windows: WSAStartup failed\n");
    return 70;
  }
  sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if (sock == INVALID_SOCKET) {
    fprintf(stderr, "kexe-loader-windows: network probe socket setup failed: wsa=%d\n",
            WSAGetLastError());
    if (sock != INVALID_SOCKET) closesocket(sock);
    WSACleanup();
    return 70;
  }
  ZeroMemory(&address, sizeof(address));
  address.sin_family = AF_INET;
  address.sin_port = htons(9);
  address.sin_addr.s_addr = htonl(0xc0000201); /* 192.0.2.1 */
  denial = connect_and_require_denial(sock, &address);
  closesocket(sock);
  WSACleanup();
  return denial;
}

/* Inbound direction: AppContainer without privateNetworkClientServer must
   reject binding/listening on all interfaces with WSAEACCES. */
static int network_listen_probe_denied(void) {
  WSADATA wsa_data;
  SOCKET listener;
  struct sockaddr_in address;

  if (WSAStartup(MAKEWORD(2, 2), &wsa_data) != 0) {
    fprintf(stderr, "kexe-loader-windows: WSAStartup failed (listen probe)\n");
    return 70;
  }
  listener = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if (listener == INVALID_SOCKET) {
    fprintf(stderr, "kexe-loader-windows: network listen probe socket() failed: wsa=%d\n",
            WSAGetLastError());
    WSACleanup();
    return 70;
  }
  ZeroMemory(&address, sizeof(address));
  address.sin_family = AF_INET;
  address.sin_port = htons(0);
  address.sin_addr.s_addr = htonl(INADDR_ANY);
  if (bind(listener, (struct sockaddr *)&address, sizeof(address)) != 0) {
    int error_value = WSAGetLastError();
    closesocket(listener);
    WSACleanup();
    if (error_value == WSAEACCES) return 0;
    fprintf(stderr, "kexe-loader-windows: network listen bind failed with unexpected wsa=%d\n",
            error_value);
    return 70;
  }
  if (listen(listener, 1) != 0) {
    int error_value = WSAGetLastError();
    closesocket(listener);
    WSACleanup();
    if (error_value == WSAEACCES) return 0;
    fprintf(stderr, "kexe-loader-windows: network listen failed with unexpected wsa=%d\n",
            error_value);
    return 70;
  }
  /* Windows authorizes inbound traffic at accept/classification time, not at
     bind/listen.  The zero TokenCapabilities assertion above is the
     fail-closed proof that privateNetworkClientServer was not granted. */
  fprintf(stderr, "kexe-loader-windows: bind/listen created; zero-capability AppContainer "
                  "prevents external accept authorization\n");
  closesocket(listener);
  WSACleanup();
  return 0;
}

/* Broker the actual guest execution into an AppContainer with no capability
   SIDs. The raw code crosses the boundary only through an inherited anonymous
   mapping, so the child never needs ambient access to the source path. */
static int run_appcontainer_parent(int argc, char **argv) {
  FILE *file;
  long length = 0;
  HANDLE mapping = NULL, job = NULL;
  void *view = NULL;
  SECURITY_ATTRIBUTES inherit;
  wchar_t profile_name[96], executable[MAX_PATH];
  PSID appcontainer_sid = NULL;
  HRESULT hr;
  SECURITY_CAPABILITIES capabilities;
  STARTUPINFOEXW startup;
  PROCESS_INFORMATION process;
  SIZE_T attribute_size = 0;
  wchar_t *command = NULL;
  wchar_t mapping_text[32], length_text[32];
  DWORD exit_code = 70;
  int profile_created = 0;

  if (argc < 6) return 2;
  file = fopen(argv[1], "rb");
  if (file == NULL) fail_input("unable to open code file");
  if (fseek(file, 0, SEEK_END) != 0 || (length = ftell(file)) <= 0 ||
      (unsigned long)length > KEXE_MAX_CODE) {
    fclose(file);
    fail_input("invalid code length");
  }
  rewind(file);

  ZeroMemory(&inherit, sizeof(inherit));
  inherit.nLength = sizeof(inherit);
  inherit.bInheritHandle = TRUE;
  mapping = CreateFileMappingW(INVALID_HANDLE_VALUE, &inherit, PAGE_READWRITE,
                               0, (DWORD)length, NULL);
  if (mapping == NULL) fail_win("CreateFileMappingW code");
  view = MapViewOfFile(mapping, FILE_MAP_WRITE, 0, 0, (SIZE_T)length);
  if (view == NULL) fail_win("MapViewOfFile parent code");
  if (fread(view, 1, (size_t)length, file) != (size_t)length) {
    fclose(file);
    fail_input("short code read");
  }
  fclose(file);
  FlushViewOfFile(view, (SIZE_T)length);
  UnmapViewOfFile(view);
  view = NULL;

  /* WFP remains defense in depth for the broker.  Do not use a broker-local
     loopback connection as the security oracle: Windows permits that flow on
     the tested ALE layers even after these filters are installed.  The child
     probe below runs inside the capability-free AppContainer and is the
     authoritative denial check. */
  install_network_denial();

  _snwprintf(profile_name, 96, L"Kotoba.Kexe.%lu", (unsigned long)GetCurrentProcessId());
  hr = CreateAppContainerProfile(profile_name, profile_name,
                                 L"Ephemeral Kotoba KEXE sandbox", NULL, 0,
                                 &appcontainer_sid);
  if (SUCCEEDED(hr)) {
    profile_created = 1;
  } else if (hr == HRESULT_FROM_WIN32(ERROR_ALREADY_EXISTS)) {
    hr = DeriveAppContainerSidFromAppContainerName(profile_name, &appcontainer_sid);
  }
  if (FAILED(hr) || appcontainer_sid == NULL) {
    SetLastError((DWORD)hr);
    fail_win("CreateAppContainerProfile");
  }

  ZeroMemory(&capabilities, sizeof(capabilities));
  capabilities.AppContainerSid = appcontainer_sid;
  ZeroMemory(&startup, sizeof(startup));
  startup.StartupInfo.cb = sizeof(startup);
  startup.StartupInfo.dwFlags = STARTF_USESTDHANDLES;
  startup.StartupInfo.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
  startup.StartupInfo.hStdOutput = GetStdHandle(STD_OUTPUT_HANDLE);
  startup.StartupInfo.hStdError = GetStdHandle(STD_ERROR_HANDLE);
  InitializeProcThreadAttributeList(NULL, 1, 0, &attribute_size);
  startup.lpAttributeList = (LPPROC_THREAD_ATTRIBUTE_LIST)
      HeapAlloc(GetProcessHeap(), 0, attribute_size);
  if (startup.lpAttributeList == NULL ||
      !InitializeProcThreadAttributeList(startup.lpAttributeList, 1, 0, &attribute_size) ||
      !UpdateProcThreadAttribute(startup.lpAttributeList, 0,
                                 PROC_THREAD_ATTRIBUTE_SECURITY_CAPABILITIES,
                                 &capabilities, sizeof(capabilities), NULL, NULL))
    fail_win("AppContainer process attributes");

  if (GetModuleFileNameW(NULL, executable, MAX_PATH) == 0)
    fail_win("GetModuleFileNameW parent");
  command = _wcsdup(GetCommandLineW());
  if (command == NULL) fail_win("duplicate command line");
  _snwprintf(mapping_text, 32, L"%llu", (unsigned long long)(uintptr_t)mapping);
  _snwprintf(length_text, 32, L"%lu", (unsigned long)length);
  if (!SetEnvironmentVariableW(L"KEXE_APPCONTAINER_CHILD", L"1") ||
      !SetEnvironmentVariableW(L"KEXE_CODE_MAPPING", mapping_text) ||
      !SetEnvironmentVariableW(L"KEXE_CODE_LENGTH", length_text))
    fail_win("SetEnvironmentVariableW child contract");

  ZeroMemory(&process, sizeof(process));
  if (!CreateProcessW(executable, command, NULL, NULL, TRUE,
                      EXTENDED_STARTUPINFO_PRESENT | CREATE_SUSPENDED | CREATE_NO_WINDOW,
                      NULL, NULL, &startup.StartupInfo, &process))
    fail_win("CreateProcessW AppContainer child");
  SetEnvironmentVariableW(L"KEXE_APPCONTAINER_CHILD", NULL);
  SetEnvironmentVariableW(L"KEXE_CODE_MAPPING", NULL);
  SetEnvironmentVariableW(L"KEXE_CODE_LENGTH", NULL);

  job = create_guest_job();
  if (!AssignProcessToJobObject(job, process.hProcess))
    fail_win("AssignProcessToJobObject AppContainer child");
  if (ResumeThread(process.hThread) == (DWORD)-1)
    fail_win("ResumeThread AppContainer child");
  WaitForSingleObject(process.hProcess, INFINITE);
  if (!GetExitCodeProcess(process.hProcess, &exit_code))
    fail_win("GetExitCodeProcess AppContainer child");

  CloseHandle(process.hThread);
  CloseHandle(process.hProcess);
  CloseHandle(job);
  DeleteProcThreadAttributeList(startup.lpAttributeList);
  HeapFree(GetProcessHeap(), 0, startup.lpAttributeList);
  free(command);
  FreeSid(appcontainer_sid);
  CloseHandle(mapping);
  if (profile_created) DeleteAppContainerProfile(profile_name);
  return (int)exit_code;
}

/* granted regions / arena parity: the tail every report ends with, defined
 * ONCE because there are nine of them. `kototama.native.executor`'s
 * `valid-supervisor-report?` has expected `:vectors` and `:vector-items` in
 * every `:ok` and `:trap` report since 2026-09-08 -- the two vector arenas are
 * separately exhaustible and were the only bounded resource a run could hit
 * without the report mentioning it.
 *
 * This repository's deps.edn held the artifact windows identity back for
 * exactly this: an arena windows loader "cannot pair with a posix loader that
 * does not under any single executor". The posix loader gained the arenas in
 * this branch, so the pairing is resolved in the other direction -- both
 * report them, and the hold is over.
 *
 * `:string-pool` joins on 2026-09-10 for the same reason and by the same
 * route: the posix loader added it (its arenas became per-run budgets, and
 * the string arena had no line at all, so a guest that exhausted it had
 * nothing to read), kototama-native's `valid-supervisor-report?` compares
 * the key set for EXACT equality, and a loader that omits the key is
 * therefore rejected as malformed evidence. That is precisely how this was
 * found: with the posix side landed, every job went green except the two
 * windows ones, which failed with "malformed native supervisor evidence".
 *
 * The capacity here is the compile-time KEXE_STRING_POOL_BYTES rather than a
 * budget, because this loader has no KEXE_STRING_POOL override. The
 * validator pins the key's structure and bounds rather than its constant, so
 * the two loaders may disagree on the number and still pair. */
#define KEXE_REPORT_TAIL_FMT                                                   \
  ":heap {:capacity 4096 :used %llu} "                                         \
  ":string-pool {:capacity %u :used %llu} "                                    \
  ":vectors {:capacity %u :used %llu} "                                        \
  ":vector-items {:capacity %u :used %llu}}\n"
#define KEXE_REPORT_TAIL_ARGS(c)                                               \
  (unsigned long long)(c)->pair_used,                                          \
      (unsigned)KEXE_STRING_POOL_BYTES,                                        \
      (unsigned long long)(c)->string_pool_used,                               \
      (unsigned)KEXE_VECTOR_CAPACITY,                                          \
      (unsigned long long)(c)->vector_used,                                    \
      (unsigned)KEXE_VECTOR_ITEM_CAPACITY,                                     \
      (unsigned long long)(c)->vector_item_used

static int sandbox_probe(void) {
  if (getenv("KEXE_FILESYSTEM_PROBE") != NULL) {
    HANDLE file = CreateFileW(L"kotoba-denial-probe.tmp", GENERIC_WRITE, 0, NULL,
                              CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
    if (file != INVALID_HANDLE_VALUE) {
      CloseHandle(file);
      DeleteFileW(L"kotoba-denial-probe.tmp");
      fprintf(stderr, "kexe-loader-windows: filesystem probe unexpectedly succeeded\n");
      return 70;
    }
    fprintf(stderr, "KEXE_TRAP {:kind :sandbox :reason :filesystem-denied}\n");
    return 77;
  }
  if (getenv("KEXE_PROCESS_PROBE") != NULL) {
    STARTUPINFOW startup;
    PROCESS_INFORMATION process;
    wchar_t command[] = L"C:\\Windows\\System32\\cmd.exe /c exit 0";
    ZeroMemory(&startup, sizeof(startup));
    ZeroMemory(&process, sizeof(process));
    startup.cb = sizeof(startup);
    if (CreateProcessW(NULL, command, NULL, NULL, FALSE, CREATE_NO_WINDOW,
                       NULL, NULL, &startup, &process)) {
      TerminateProcess(process.hProcess, 70);
      CloseHandle(process.hThread);
      CloseHandle(process.hProcess);
      fprintf(stderr, "kexe-loader-windows: process probe unexpectedly succeeded\n");
      return 70;
    }
    fprintf(stderr, "KEXE_TRAP {:kind :sandbox :reason :process-denied}\n");
    return 77;
  }
  if (getenv("KEXE_NETWORK_PROBE") != NULL) {
    int denial = network_outbound_probe_denied();
    if (denial != 0) return denial;
    fprintf(stderr, "KEXE_TRAP {:kind :sandbox :reason :network-denied}\n");
    return 77;
  }
  if (getenv("KEXE_NETWORK_LISTEN_PROBE") != NULL) {
    int denial = network_listen_probe_denied();
    if (denial != 0) return denial;
    fprintf(stderr, "KEXE_TRAP {:kind :sandbox :reason :network-listen-denied}\n");
    return 77;
  }
  return 0;
}

int main(int argc, char **argv) {
  long length = 0;
  uint64_t offset, arity;
  uint8_t *source = NULL, *code = NULL;
  DWORD old_protect = 0;
  struct kexe_context *ctx;
  HANDLE token;
  int64_t args[5] = {0, 0, 0, 0, 0}, result;
  const char *child_contract = getenv("KEXE_APPCONTAINER_CHILD");
  const char *result_type = getenv("KEXE_RESULT_TYPE");
  uint64_t record_field_count = 0;
  uint64_t variant_case_count = 0, variant_bool_mask = 0;

  if (child_contract == NULL) return run_appcontainer_parent(argc, argv);
  require_appcontainer_token();

  if (argc < 6) {
    fprintf(stderr, "usage: kexe-loader-windows <raw-code> <offset> <arity> %s <allow-csv|-> [i64 ...]\n",
            KEXE_ISA);
    return 2;
  }
  if (strcmp(argv[4], KEXE_ISA) != 0) fail_input("unsupported ISA");
  offset = parse_u64(argv[2], "invalid offset");
  arity = parse_u64(argv[3], "invalid arity");
  if (arity > 5 || argc != (int)(6 + arity)) fail_input("arity mismatch");
  if (result_type == NULL) result_type = "i64";
  if (strncmp(result_type, "record:", 7) == 0) {
    record_field_count = parse_u64(result_type + 7, "invalid record result type");
    if (record_field_count == 0 || record_field_count > KEXE_RECORD_FIELD_LIMIT)
      fail_input("invalid record result field count");
  } else if (strncmp(result_type, "variant:", 8) == 0) {
    if (!parse_variant_profile(result_type, &variant_case_count,
                               &variant_bool_mask))
      fail_input("invalid variant result type");
  } else if (strcmp(result_type, "i64") != 0 &&
             strcmp(result_type, "string") != 0 &&
             strcmp(result_type, "option-i64") != 0 &&
             strcmp(result_type, "result-i64") != 0)
    fail_input("invalid result type");

  {
    const char *mapping_text = getenv("KEXE_CODE_MAPPING");
    const char *length_text = getenv("KEXE_CODE_LENGTH");
    HANDLE mapping;
    const void *mapped;
    if (mapping_text == NULL || length_text == NULL)
      fail_input("missing AppContainer code mapping contract");
    length = (long)parse_u64(length_text, "invalid mapped code length");
    mapping = (HANDLE)(uintptr_t)parse_u64(mapping_text, "invalid code mapping handle");
    if (length <= 0 || (unsigned long)length > KEXE_MAX_CODE || offset >= (uint64_t)length)
      fail_input("invalid code length or offset");
    mapped = MapViewOfFile(mapping, FILE_MAP_READ, 0, 0, (SIZE_T)length);
    if (mapped == NULL) fail_win("MapViewOfFile child code");
    source = (uint8_t *)malloc((size_t)length);
    if (source == NULL) fail_input("source allocation failed");
    memcpy(source, mapped, (size_t)length);
    UnmapViewOfFile(mapped);
    CloseHandle(mapping);
  }

  SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX | SEM_NOOPENFILEERRORBOX);
  if (!SetDefaultDllDirectories(LOAD_LIBRARY_SEARCH_SYSTEM32)) fail_win("SetDefaultDllDirectories");
  code = (uint8_t *)VirtualAlloc(NULL, (size_t)length, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
  if (code == NULL) fail_win("VirtualAlloc RW");
  memcpy(code, source, (size_t)length);
  SecureZeroMemory(source, (size_t)length);
  free(source);
  if (!VirtualProtect(code, (size_t)length, PAGE_EXECUTE_READ, &old_protect))
    fail_win("VirtualProtect RX");
  if (!FlushInstructionCache(GetCurrentProcess(), code, (size_t)length))
    fail_win("FlushInstructionCache");
  prohibit_dynamic_code();
  ctx = (struct kexe_context *)VirtualAlloc(NULL, sizeof(*ctx), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
  if (ctx == NULL) fail_win("VirtualAlloc context");
  ZeroMemory(ctx, sizeof(*ctx));
  ctx->version = 11;
  ctx->fuel = 512;
  ctx->cap_call = (void *)&cap_call;
  ctx->pair_new = (void *)&pair_new;
  ctx->pair_first = (void *)&pair_first;
  ctx->pair_second = (void *)&pair_second;
  ctx->string_equal = (void *)&string_equal;
  ctx->string_concat = (void *)&string_concat;
  ctx->typed_cap_call = (void *)&typed_cap_call;
  ctx->string_substring = (void *)&string_substring;
  ctx->string_code_point_at = (void *)&string_code_point_at;
  ctx->vector_new_empty = (void *)&vector_new_empty;
  ctx->vector_conj = (void *)&vector_conj;
  ctx->vector_count = (void *)&vector_count;
  ctx->vector_at = (void *)&vector_at;
  ctx->vector_assoc = (void *)&vector_assoc;
  ctx->vector_drop = (void *)&vector_drop;
  ctx->vector_alloc = (void *)&vector_alloc;
  ctx->vector_assoc_in_place = (void *)&vector_assoc_in_place;
  ctx->string_index_of = (void *)&string_index_of;
  ctx->arena_enter = (void *)&arena_enter;
  ctx->arena_leave = (void *)&arena_leave;
  ctx->string_compare = (void *)&string_compare;
  ctx->string_fold_ascii = (void *)&string_fold_ascii;
  ctx->string_find_blank = (void *)&string_find_blank;
  ctx->string_skip_blank = (void *)&string_skip_blank;
  ctx->string_index_of_from = (void *)&string_index_of_from;
  ctx->string_compare_lines = (void *)&string_compare_lines;
  ctx->pair_used_pointer = &ctx->pair_used;
  ctx->pairs_base = ctx->pairs;
  ctx->pair_validated_base = ctx->pair_validated;
  ctx->vector_used_pointer = &ctx->vector_used;
  ctx->vectors_base = ctx->vectors;
  ctx->vector_items_base = ctx->vector_items;
  ctx->string_find_byte = (void *)&string_find_byte;
  ctx->string_append_range = (void *)&string_append_range;
  ctx->string_from_utf8 = (void *)&string_from_utf8;
  ctx->bytes_from_vector = (void *)&bytes_from_vector;
  ctx->bytes_slice = (void *)&bytes_slice;
  ctx->bytes_concat = (void *)&bytes_concat;
  ctx->code_base = code;
  ctx->code_length = (uint64_t)length;
  parse_allow(ctx, argv[5]);
  for (uint64_t i = 0; i < arity; i++)
    args[i] = parse_guest_arg(ctx, argv[6 + i]);

  token = restricted_token();
  if (!SetThreadToken(NULL, token)) fail_win("SetThreadToken restricted");
  {
    int probe = sandbox_probe();
    if (probe != 0) return probe;
  }
#if defined(_M_X64)
  result = ((guest_fn)(code + offset))(args[0], args[1], args[2], args[3], args[4], ctx);
#else
  result = ((guest_fn)(code + offset))(args[0], args[1], args[2], args[3], args[4], 0, 0, ctx);
#endif
  if (!SetThreadToken(NULL, NULL)) fail_win("clear thread token");
  CloseHandle(token);

  if (getenv("KEXE_STRUCTURED_REPORT") != NULL) {
    if (strcmp(result_type, "string") == 0) {
      uint64_t result_length = 0;
      const uint8_t *result_bytes = inspect_string_result(ctx, result, &result_length);
      if (result_bytes == NULL) {
        fprintf(stderr, "KEXE_TRAP {:kind :result :reason :invalid-string-handle}\n");
        printf("{:status :trap :exit 66 :fuel {:initial 512 :remaining %llu} "
               KEXE_REPORT_TAIL_FMT,
               (unsigned long long)ctx->fuel, KEXE_REPORT_TAIL_ARGS(ctx));
        SecureZeroMemory(ctx, sizeof(*ctx));
        VirtualFree(ctx, 0, MEM_RELEASE);
        VirtualFree(code, 0, MEM_RELEASE);
        return 66;
      }
      printf("{:status :ok :result %lld :result-type :string :result-utf8-hex \"",
             (long long)result);
      for (uint64_t i = 0; i < result_length; i++) printf("%02x", result_bytes[i]);
      printf("\" :fuel {:initial 512 :remaining %llu} "
             KEXE_REPORT_TAIL_FMT,
             (unsigned long long)ctx->fuel, KEXE_REPORT_TAIL_ARGS(ctx));
    } else if (record_field_count > 0) {
      int64_t fields[KEXE_RECORD_FIELD_LIMIT];
      if (!inspect_record_result(ctx, result, record_field_count, fields)) {
        fprintf(stderr, "KEXE_TRAP {:kind :result :reason :invalid-record-chain}\n");
        printf("{:status :trap :exit 127 :fuel {:initial 512 :remaining %llu} "
               KEXE_REPORT_TAIL_FMT,
               (unsigned long long)ctx->fuel, KEXE_REPORT_TAIL_ARGS(ctx));
        SecureZeroMemory(ctx, sizeof(*ctx));
        VirtualFree(ctx, 0, MEM_RELEASE);
        VirtualFree(code, 0, MEM_RELEASE);
        return 127;
      }
      printf("{:status :ok :result %lld :result-type :record :result-words [",
             (long long)result);
      for (uint64_t i = 0; i < record_field_count; i++)
        printf(i == 0 ? "%lld" : " %lld", (long long)fields[i]);
      printf("] :fuel {:initial 512 :remaining %llu} "
             KEXE_REPORT_TAIL_FMT,
             (unsigned long long)ctx->fuel, KEXE_REPORT_TAIL_ARGS(ctx));
    } else if (strcmp(result_type, "option-i64") == 0 ||
               strcmp(result_type, "result-i64") == 0) {
      int option = strcmp(result_type, "option-i64") == 0;
      int64_t tag, payload;
      if (!inspect_tagged_i64_result(ctx, result, option, &tag, &payload)) {
        int trap_exit = option ? 128 : 129;
        const char *reason = option ? "invalid-option-i64" : "invalid-result-i64";
        fprintf(stderr, "KEXE_TRAP {:kind :result :reason :%s}\n", reason);
        printf("{:status :trap :exit %d :fuel {:initial 512 :remaining %llu} "
               KEXE_REPORT_TAIL_FMT, trap_exit,
               (unsigned long long)ctx->fuel, KEXE_REPORT_TAIL_ARGS(ctx));
        SecureZeroMemory(ctx, sizeof(*ctx));
        VirtualFree(ctx, 0, MEM_RELEASE);
        VirtualFree(code, 0, MEM_RELEASE);
        return trap_exit;
      }
      printf("{:status :ok :result %lld :result-type :%s "
             ":result-tag %s :result-word %lld "
             ":fuel {:initial 512 :remaining %llu} "
             KEXE_REPORT_TAIL_FMT,
             (long long)result, result_type, tag == 1 ? "true" : "false",
             (long long)payload, (unsigned long long)ctx->fuel,
             KEXE_REPORT_TAIL_ARGS(ctx));
    } else if (variant_case_count > 0) {
      int64_t ordinal, payload;
      if (!inspect_variant_result(ctx, result, variant_case_count,
                                  variant_bool_mask, &ordinal, &payload)) {
        fprintf(stderr, "KEXE_TRAP {:kind :result :reason :invalid-variant}\n");
        printf("{:status :trap :exit 130 :fuel {:initial 512 :remaining %llu} "
               KEXE_REPORT_TAIL_FMT,
               (unsigned long long)ctx->fuel, KEXE_REPORT_TAIL_ARGS(ctx));
        SecureZeroMemory(ctx, sizeof(*ctx));
        VirtualFree(ctx, 0, MEM_RELEASE);
        VirtualFree(code, 0, MEM_RELEASE);
        return 130;
      }
      printf("{:status :ok :result %lld :result-type :variant "
             ":result-ordinal %lld :result-word %lld "
             ":fuel {:initial 512 :remaining %llu} "
             KEXE_REPORT_TAIL_FMT,
             (long long)result, (long long)ordinal, (long long)payload,
             (unsigned long long)ctx->fuel,
             KEXE_REPORT_TAIL_ARGS(ctx));
    } else {
      printf("{:status :ok :result %lld :fuel {:initial 512 :remaining %llu} "
             KEXE_REPORT_TAIL_FMT,
             (long long)result, (unsigned long long)ctx->fuel,
             KEXE_REPORT_TAIL_ARGS(ctx));
    }
  } else printf("%lld\n", (long long)result);

  SecureZeroMemory(ctx, sizeof(*ctx));
  VirtualFree(ctx, 0, MEM_RELEASE);
  VirtualFree(code, 0, MEM_RELEASE);
  return 0;
}
