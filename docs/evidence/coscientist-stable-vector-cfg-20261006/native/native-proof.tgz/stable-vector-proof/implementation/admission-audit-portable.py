from pathlib import Path
import json,hashlib
W=Path(__file__).resolve().parent;P=W.parent/'cfg-model';model=json.loads((P/'analysis.json').read_text());expected={(r['workload'],r['fn']):r for r in model['examinedEligible'] if r['oldFrame']>0};seen={};rows=[]
for p in sorted((W/'observer/ports').iterdir()):
 result={};query={};admit=[]
 for line in (p/'compile.log').read_text().splitlines():
  x=line.split()
  if not x:continue
  if x[0]=='SCRESULT':f,start,yes,left,epoch,edges=map(int,x[1:]);assert f not in result;result[f]=(start,yes,left,epoch,edges)
  elif x[0]=='SCQUERY':start,site,temp,yes,left,epoch=map(int,x[1:]);query.setdefault(start,[]).append((site,temp,yes,left,epoch))
  elif x[0]=='SLADMIT':admit.append(list(map(int,x[1:])))
 for f,native in result.items():
  key=(p.name,f);assert key in expected,('unexpectednativeproof',key);m=expected[key];seen[key]=native;start,yes,left,epoch,edges=native;assert start==m['start'] and bool(yes)==m.get('admit',False)
  if yes:
   actual=query[start];assert len(actual)==len(m['queries'])==epoch
   remaining=131072
   for a,b in zip(actual,m['queries']):
    remaining-=b['visits'];assert a==(b['sir'],b['temp'],1,remaining,actual.index(a)+1),('query mismatch',key,a,b)
   assert left==remaining and 131072-left==m['visits']
   replay=json.loads((P/'replay-inputs.json').read_text());case=next(c for c in replay['cases'] if c['workload']==p.name);sir={int(k):v for k,v in case['sir'].items()};op={k:v for k,v in replay['constants'].items() if k.startswith('OP-')};edgecount=sum(0 if sir[i][0]==op['OP-RET'] else 2 if sir[i][0] in [op['OP-BRZ'],op['OP-BRNZ']] else int(i+1<m['end']) if sir[i][0]!=op['OP-BR'] else 1 for i in range(start+1,m['end']));assert edges==edgecount
   assert next(r for r in admit if r[0]==f)[1:]==[start,1,case['fn'][str(f)][4],case['fn'][str(f)][4]+3,m['newFrameEstimate'],m['end']]
  else:assert not any(r[0]==f for r in admit)
  rows.append({'workload':p.name,'fn':f,'nativeAccepted':bool(yes),'originVisits':131072-left,'epoch':epoch,'edges':edges,'matchesReadOnlyAllPredecessorModel':True})
assert set(seen)==set(expected),(set(expected)-set(seen),set(seen)-set(expected))
(W/'admission-audit.json').write_text(json.dumps({'status':'PASS native candidate proof decisions equal independently frozen read-only original19 all-predecessor model','nativeProofFunctions':len(rows),'nativeAdmittedFunctions':sum(r['nativeAccepted'] for r in rows),'rows':rows,'modelSha256':hashlib.sha256((P/'analysis.json').read_bytes()).hexdigest(),'modelPath':str(P/'analysis.json'),'limits':'Independent siblings verify typed fixtures/semantics. Exact native visit and edge counts compared only for admitted original2; no performance claim.'},indent=2)+'\n');print('PASS actualnative decisions',len(rows),'functions +twoallquery budgets/edges')
