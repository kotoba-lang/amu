from pathlib import Path
import subprocess,os,re,json,hashlib
W=Path(__file__).resolve().parent;D=W/'proof-controls';D.mkdir(exist_ok=True)
base=(W/'unity.kotoba').read_text().replace('(ns seed (:export [main]))','(ns seed (:export [main probe]))',1)
probe='''
(defn- cp-put [M :vector-i64 i :i64 op :i64 a :i64 b :i64] :vector-i64
 (let [x (+ MM-SIR-BASE (* i MM-SIR-W))]
  (-> M (vector-assoc! x op) (vector-assoc! (+ x 1) a) (vector-assoc! (+ x 2) b) (vector-assoc! (+ x 3) 0))))
(defn probe [case :i64] :i64
 (let [M (-> (vector-alloc (+ MM-SIR-BASE (* 10 MM-SIR-W)))
        (cp-put 1 OP-LGET 0 1) (cp-put 2 OP-BRZ 1 1)
        (cp-put 3 (if (= case 2) OP-CONST (if (= case 4) OP-LGET OP-CONST)) (if (or (= case 2) (= case 4)) 0 1) 1)
        (cp-put 4 OP-BR 2 0)
        (cp-put 5 (if (or (= case 1) (= case 4)) OP-LGET OP-CONST) (if (or (= case 1) (= case 4)) 0 1) (if (= case 1) 2 1))
        (cp-put 6 OP-LABEL 2 0) (cp-put 7 OP-RT RT-VECTOR-AT 0))
       S (-> (vector-alloc 72) (vector-assoc! 0 (if (= case 5) 2 131072))
             (vector-assoc! 1 1) (vector-assoc! 2 7) (vector-assoc! 3 0)
             (vector-assoc! 4 8) (vector-assoc! 5 1)
             (sc-edge 1 2) (sc-edge 2 3) (sc-edge 3 4) (sc-edge 4 6) (sc-edge 5 6) (sc-edge 6 7))
       S1 (if (= case 3) S (sc-edge S 2 5))
       S2 (if (= case 6) (sc-edge S1 5 2) S1)
       result (sc-query M S2 7 0)]
  (if (= case 7)
   (let [M1 (cp-put M 3 OP-CONST 0 1) second (sc-query M1 result 7 0)] (vector-at second 1))
   (vector-at result 1))))
'''
variants=[('pristine',None,None,[1,0,0,0,1,0,0,0]),('accept-other-local','(= (gn-sir M j IF-B) (vector-at S2 5))','true',None),('ignore-undefined','(= (sc-head S2 child) 0) (sc-fail S2)','(= (sc-head S2 child) 0) (let [S3 (vector-assoc! S2 (sc-mark-at S2 child) black)] (recur depth))',None),('ignore-cycle','(= mark gray) (sc-fail S1)','(= mark gray) (recur depth)',None),('ignore-budget','(<= (vector-at S1 0) 0) (sc-fail S1)','(<= (vector-at S1 0) 0) (recur depth)',None),('omit-predecessor','(vector-at S (sc-next-at S cursor))','0',None),('reuse-query-epoch','epoch (inc (vector-at S 7))','epoch 1',None)]
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/private/tmp:/Users/junkawasaki/github/wt/amu-seed17',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[]
for name,needle,replacement,expected in variants:
 d=D/name;d.mkdir(exist_ok=True);source=base
 if needle is not None:assert source.count(needle)==1,(name,source.count(needle));source=source.replace(needle,replacement)
 (d/'source.kotoba').write_text(source+probe)
 for step,args in [('compile',['compile',str(d/'source.kotoba'),'--target','aarch64-macos','--output',str(d/'image.kseed')]),('extract',['extract-native',str(d/'image.kseed'),'--symbol','probe','--output',str(d/'native.bin')])]:
  q=subprocess.run([str(W/'kexe-loader'),str(W/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(step+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,step,q.stdout[-2000:],q.stderr[-2000:])
  if step=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1]);(d/'native.offset').write_text(str(off)+'\n')
 outcomes=[]
 for case in range(8):
  e=dict(os.environ,KEXE_STRUCTURED_REPORT='1',KEXE_FUEL='100000000',KEXE_VECTOR_ITEMS='134217728');e.pop('KEXE_COMMAND',None)
  q=subprocess.run([str(W/'kexe-loader'),str(d/'native.bin'),str(off),'1','aarch64','-',str(case)],env=e,capture_output=True,text=True);(d/f'case-{case}.stdout').write_text(q.stdout);(d/f'case-{case}.stderr').write_text(q.stderr);assert q.returncode==0,(name,case,q.stdout,q.stderr)
  result=int(re.search(r':result (-?\d+)',q.stdout)[1]);outcomes.append(result)
 if name=='pristine':assert outcomes==expected;(D/'pristine-outcomes.json').write_text(json.dumps(outcomes)+'\n')
 else:assert outcomes!=json.loads((D/'pristine-outcomes.json').read_text()),(name,'mutant undetected')
 rows.append({'variant':name,'outcomes':outcomes,'status':'PASS pristine' if name=='pristine' else 'MUTATION DETECTED','nativeSha256':hashlib.sha256((d/'native.bin').read_bytes()).hexdigest()});print(name,outcomes,flush=True)
(D/'report.json').write_text(json.dumps({'status':'PASS actual native iterative CFG proof pristine8cases +6 source mutation calibrations','rows':rows,'limits':'Diagnostic syntheticSIR, not typed program acceptance or whole compiler soundness. No primary source changes.'},indent=2)+'\n')
