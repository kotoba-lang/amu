from pathlib import Path
import json,struct,copy,collections,hashlib
W=Path(__file__).resolve().parent
exec(Path('/private/tmp/amu-native-hotpath-20261006/implementation/machine-audit.py').read_text().split('rows=[];tot=')[0])
W=Path(__file__).resolve().parent
B=Path('/private/tmp/amu-static-vector-chain-20261006/observer/meta-ports')
admissions={r['workload']:r['admissions'] for r in json.loads((W/'observer/admission.json').read_text())['entries']}
def cmp(ri,rn):return 0xeb00001f|(rn<<16)|(ri<<5)
def readold(rv,ri,d):
 return [0xf9409cf0,0xf9400210,0xd1000411|(rv<<5),cmp(17,16),0x54000043,0,0xf940a0f0,0x8b111210,0xa9404211,cmp(ri,16),0x54000043,0,0xf940a4f0,0x8b000231|(ri<<16),0xf8607800|(17<<16)|(16<<5)|d]
def readnew(rv,ri,d,nsv):
 length=16+nsv;base=17+nsv;flag=18+nsv
 return [0xb50001a0|flag,*readold(rv,ri,d)[:8],0xa9400000|(length<<10)|(16<<5)|17,0xf940a4e0|base,0x8b110c00|(base<<5)|base,0xd2800020|flag,cmp(ri,length),0x54000043,0,0xf8607800|(ri<<16)|(base<<5)|d]
def saves(nsv,load=False):
 out=[]
 for i in range(0,nsv,2):
  r=19+i;offset=8*i
  if i+1<nsv:out.append((0xa9400000 if load else 0xa9000000)|((offset//8)<<15)|((r+1)<<10)|(31<<5)|r)
  else:out.append((0xf9400000 if load else 0xf9000000)|((offset//8)<<10)|(31<<5)|r)
 return out
def normalize(d,ads,candidate):
 stream=[];pos={};edges=[];internal=set();discarded=set();reads=[];changes=[];words=d['words'];lit={};owner=None
 for ix,at,k,t,aux in d['fix']:
  if k==5:lit[at]=(t,0);lit[at+1]=(t,1)
 ad={r[0]:r for r in ads}
 for event in d['events']:
  sir,skip,start,end=event;op,a,b,c=d['sir'][sir];seg=words[start-1:end-1];consumed=0
  if op==1:owner=a
  pieces=[]
  if owner in ad and op==1:
   f,si,slot,old,new,frame,last=ad[owner]
   assert si==sir and new==old+3
   meta=d['fn'][owner];actualNsv=new if candidate else old
   assert meta[1]>0 and meta[5]==1 and meta[2]==7+old and meta[3]<=7
   expect=[0xa9bf7bfd,0x910003fd,0xd10003ff|(meta[1]<<10),*saves(actualNsv)]
   assert seg[:len(expect)]==expect,('entry',owner,seg,expect)
   pieces=[('entry',0,len(expect)),('word',len(expect),len(seg)-int(candidate))]
   if candidate:
    assert seg[-1]==0xd2800000|(18+new)
    pieces.append(('drop',len(seg)-1,len(seg)))
  elif owner in ad and op==19:
   actualNsv=ad[owner][4] if candidate else ad[owner][3]
   restore=saves(actualNsv,True);tail=[*restore,0x910003bf,0xa8c17bfd,0xd65f03c0]
   assert seg[-len(tail):]==tail,('return',owner,seg,tail)
   begin=len(seg)-len(tail)
   pieces=[('word',0,begin),('restore',begin,begin+len(restore)),('word',begin+len(restore),len(seg))]
  elif owner in ad and op==14:
   assert a==176 and c==2
   n=17 if candidate else 15;assert len(seg)>=n
   tail=seg[-n:]
   if candidate:
    rv=(tail[3]>>5)&31;ri=(tail[13]>>5)&31;dest=tail[-1]&31
    assert tail==readnew(rv,ri,dest,ad[owner][4]),('newread',sir,tail,readnew(rv,ri,dest,ad[owner][4]))
   else:
    rv=(tail[2]>>5)&31;ri=(tail[9]>>5)&31;dest=tail[-1]&31
    assert tail==readold(rv,ri,dest),('oldread',sir,tail,readold(rv,ri,dest))
   assert {rv,ri,dest}.isdisjoint({16+ad[owner][4],17+ad[owner][4],18+ad[owner][4]})
   pieces=[('word',0,len(seg)-n),('read',len(seg)-n,len(seg))]
   reads.append({'fn':owner,'sir':sir,'rv':rv,'ri':ri,'destination':dest,'first':start+len(seg)-n,'end':end})
  else:pieces=[('word',0,len(seg))]
  for kind,lo,hi in pieces:
   if kind=='drop':
    for j in range(lo,hi):pos[start+j]=len(stream)
    changes.append((owner,sir,start+lo,start+hi));discarded.update(range(start+lo,start+hi));
    if op==1 and lo==0:discarded.discard(start)
    continue
   if kind in ['entry','restore']:
    for j in range(lo,hi):pos[start+j]=len(stream)
    stream.append((kind,owner));internal.update(range(start+lo+int(kind=='entry'),start+hi));continue
   if kind=='read':
    token=('READ',owner,sir,rv,ri,dest)
    for j in range(lo,hi):pos[start+j]=len(stream)
    stream.append(token)
    internal.update(range(start+lo+1,start+hi));continue
   for j in range(lo,hi):
    i=start+j;pos[i]=len(stream);z=words[i-1];q=branch(z)
    if q:stream.append(('BR',q[0]));edges.append((len(stream)-1,i+q[1]))
    elif i in lit:stream.append(('LIT',lit[i],z&~0x1fffe0))
    else:stream.append(('WORD',z))
  pos[end]=len(stream)
 assert set(pos)==set(range(1,d['n']+1)),('word coverage',len(pos),d['n'])
 for ix,target in edges:assert target not in internal and target not in discarded,('external branch enters replacement interior',ix,target)
 return stream,pos,edges,reads,changes

def audit(a,b,ads):
 assert a['sir']==b['sir'];assert a['fn'].keys()==b['fn'].keys()
 ad={r[0]:r for r in ads}
 for f,v in a['fn'].items():
  w=b['fn'][f]
  if f in ad:
   assert v[1]>0 and v[4]==ad[f][3] and v[5]==1
   assert (w[0],w[2],w[3],w[5])==(v[0],v[2],v[3],v[5])
   assert (w[1],w[4])==(ad[f][5],ad[f][4])
  else:assert v[:-1]==w[:-1],('metadata',f,v,w)
 assert [(x[0],x[1]) for x in a['events']]==[(x[0],x[1]) for x in b['events']]
 aa,pa,ea,ra,da=normalize(a,ads,False);bb,pb,eb,rb,db=normalize(b,ads,True)
 assert aa==bb,next(((i,x,y) for i,(x,y) in enumerate(zip(aa,bb)) if x!=y),(len(aa),len(bb)))
 assert [(r['fn'],r['sir'],r['rv'],r['ri'],r['destination']) for r in ra]==[(r['fn'],r['sir'],r['rv'],r['ri'],r['destination']) for r in rb]
 for f,v in a['fn'].items():assert pa[v[-1]]==pb[b['fn'][f][-1]]
 assert len(ea)==len(eb)
 for x,y in zip(ea,eb):assert x[0]==y[0] and pa[x[1]]==pb[y[1]],('edge',x,y)
 for x,y in zip(a['events'],b['events']):assert pa[x[2]]==pb[y[2]] and pa[x[3]]==pb[y[3]],('event',x,y)
 assert len(a['fix'])==len(b['fix']);private=0;literal=0
 ap=((a['n']-1)*4+7)//8*8;bp=((b['n']-1)*4+7)//8*8
 for x,y in zip(a['fix'],b['fix']):
  ix,at,k,t,u=x;iy,bt,l,s,v=y;assert (ix,k,t,u)==(iy,l,s,v) and pa[at]==pb[bt]
  if k==5:
   assert pa[at+1]==pb[bt+1]
   old=((a['words'][at-1]>>5)&65535)|(((a['words'][at]>>5)&65535)<<16);new=((b['words'][bt-1]>>5)&65535)|(((b['words'][bt]>>5)&65535)<<16);assert old-ap==new-bp;literal+=2
  if u:
   assert k==4 and u==1 and t not in ad
   oe=a['fn'][t][-1];ne=b['fn'][t][-1];assert a['words'][oe-1]==b['words'][ne-1]==0xd2800005
   assert at+branch(a['words'][at-1])[1]==oe+1 and bt+branch(b['words'][bt-1])[1]==ne+1;private+=1
 assert a['raw'][ap:]==b['raw'][bp:];assert set(a['raw'][(a['n']-1)*4:ap])<={0};assert set(b['raw'][(b['n']-1)*4:bp])<={0}
 assert b['n']-a['n']==sum(2*(len(saves(r[4]))-len(saves(r[3])))+1 for r in ads)+2*len(ra)
 return {'admittedFunctions':len(ads),'stableReadSites':len(ra),'retainedTokens':len(aa),'retainedBranches':len(ea),'literalWords':literal,'privateAux1':private,'addedWords':b['n']-a['n'],'frames':[{'fn':r[0],'oldFrame':a['fn'][r[0]][1],'newFrame':r[5]} for r in ads],'reads':rb}
if __name__=='__main__':
 rows=[];details={};tot=collections.Counter()
 for name,ads in admissions.items():
  a=parse(B/name);b=parse(W/'observer/ports'/name);r=audit(a,b,ads);details[name]=r;rows.append({'workload':name,**r});tot.update({k:v for k,v in r.items() if isinstance(v,int)});print('PASS',name,flush=True)
 controls=[];name='xgboost';a=parse(B/name);b=parse(W/'observer/ports'/name);r=details[name];start=r['reads'][0]['first'];entry=b['fn'][15][-1]
 for title,word,mask in [('handle check',start+1,1),('runtime flag branch',start,32),('captured length',start+9,1<<10),('bound comparison',start+13,1<<16),('fresh load',start+16,1<<16),('bound trap',start+15,1),('flag initializer',entry+7,32),('callee save',entry+3,1<<10),('ordinary branch',next(i for i,z in enumerate(b['words'],1) if branch(z) and i<entry),32)]:
  d=copy.deepcopy(b);d['words'][word-1]^=mask
  try:audit(a,d,admissions[name])
  except (AssertionError,KeyError,IndexError) as e:controls.append({'mutation':title,'word':word,'status':'DETECTED','diagnostic':str(e)[:300]})
  else:raise AssertionError('accepted mutant '+title)
 edge=next(i for i,z in enumerate(b['words'],1) if branch(z) and z&0x7c000000==0x14000000 and i<entry)
 for title in ['external edge into read interior']:
  d=copy.deepcopy(b)
  if title=='external edge into read interior':d['words'][edge-1]=0x14000000|((start+1-edge)&0x3ffffff)
  try:audit(a,d,admissions[name])
  except (AssertionError,KeyError,IndexError) as e:controls.append({'mutation':title,'status':'DETECTED','diagnostic':str(e)[:300]})
  else:raise AssertionError('accepted mutant '+title)
 for name in admissions:
  a=parse(B/name);b=parse(W/'observer/ports'/name)
  lits=[at for ix,at,k,t,u in b['fix'] if k==5]
  if not lits:continue
  d=copy.deepcopy(b);d['words'][lits[0]-1]^=32
  try:audit(a,d,admissions[name])
  except (AssertionError,KeyError,IndexError) as e:controls.append({'mutation':'literal pointer','workload':name,'status':'DETECTED','diagnostic':str(e)[:300]})
  else:raise AssertionError('accepted literal mutant')
  break
 else:raise AssertionError('no literal calibration fixture')
 for name in admissions:
  a=parse(B/name);b=parse(W/'observer/ports'/name)
  private=[j for j,x in enumerate(b['fix']) if x[4]]
  if not private:continue
  d=copy.deepcopy(b);j=private[0];d['fix'][j]=tuple(list(d['fix'][j])[:4]+[0])
  try:audit(a,d,admissions[name])
  except (AssertionError,KeyError,IndexError) as e:controls.append({'mutation':'private aux1 fixup','workload':name,'status':'DETECTED','diagnostic':str(e)[:300]})
  else:raise AssertionError('accepted private mutant')
  break
 else:raise AssertionError('no private calibration fixture')
 report={'status':'PASS original19 full actual native normalized instruction/edge/fixup/literal/entry audit','totals':dict(tot),'rows':rows,'controls':controls,'limits':'Only two observed already-framed leaf functions with all original locals in registers qualify this audit. Exact 17-word guarded metadata read replacements validated independently; all 14 sites retain runtime flag guards (no straight-line guard elision observed). Typed SIR/runtime validity and closed stable local contract independently audited elsewhere. New frames 160/176 bytes can alter OS stack exhaustion boundaries; not proved equal. No timing claim. ports-correctness.json is COPIED BASELINE ORACLE ONLY; ports-build.json and observer/admission.json name actual candidate artifacts.'}
 (W/'machine-audit.json').write_text(json.dumps(report,indent=2)+'\n')
 print('PASS TOTALS',dict(tot),flush=True)
