exec((__import__('pathlib').Path('/private/tmp/amu-stable-vector-cfg-20261006/team-constructor/baseline.py')).read_text().split('rows=[]')[0])
B=Path('/private/tmp/amu-static-vector-chain-20261006/observer');rows=[]
for name in json.loads((D/'cases.json').read_text()):
 d=D/name;q=subprocess.run([str(O/'kexe-loader'),str(B/'meta-seed.bin'),'0','0','aarch64','35,37,38,39','--','compile',str(D/(name+'.kotoba')),'--target','aarch64-macos','--output',str(d/'physical-baseline.kseed')],env=env,capture_output=True,text=True);assert q.returncode==0;(d/'physical-baseline.log').write_text(q.stdout+q.stderr)
 fn=[list(map(int,l.split()[1:])) for l in q.stdout.splitlines() if l.startswith('FN ')];cache=[list(map(int,l.split()[1:])) for l in q.stdout.splitlines() if l.startswith('CACHE ')];rows.append({'case':name,'fn':fn,'cache':cache})
 print(name,[(r[0],r[2],r[5],r[6]) for r in fn],flush=True)
(D/'physical.json').write_text(json.dumps({'status':'PASS retained actual qualified product physical function metadata','rows':rows},indent=2)+'\n')
