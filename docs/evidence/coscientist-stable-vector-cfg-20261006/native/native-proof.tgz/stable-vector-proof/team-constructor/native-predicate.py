from pathlib import Path
import subprocess,os,re,json,hashlib
D=Path(__file__).resolve().parent;I=D.parent/'implementation';O=Path('/private/tmp/amu-private-length-clones-20261006');P=D/'predicate';P.mkdir(exist_ok=True)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/private/tmp:/Users/junkawasaki/github/wt/amu-seed17',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTOR_ITEMS='134217728',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216')
base=(I/'unity.kotoba').read_text();base=base.replace('(ns seed (:export [main]))','(ns seed (:export [main run]))')
body=[(1,0,0,0),(18,0,0,0),(9,1,0,0),(4,0,1,0),(3,1,0,0),(11,1,2,0),(3,1,1,0),(10,3,0,0),(9,2,0,0),(3,1,2,0),(9,3,0,0),(14,176,0,2),(4,0,1,0),(3,1,0,0),(14,176,0,2),(10,1,0,0),(2,0,0,0)]
init='\n'.join(f'(vector-assoc! M (+ MM-SIR-BASE {4*(i+1)+j}) {v})' for i,t in enumerate(body) for j,v in enumerate(t))
# Every fixture starts with an actual legal scalar diamond and local backedge.
driver='''
(defn run [kind :i64] :i64
 (let [M (vector-alloc MM-WORDS)]
 INIT
 (vector-assoc! M gn-cell 1000)
 (vector-assoc! M (+ 1000 gn-a-lp 1) 3)
 (vector-assoc! M (+ 1000 gn-a-lp 2) 9)
 (vector-assoc! M (+ 1000 gn-a-lp 3) 11)
 ;; alternate root on the first diamond arm; good arm is traversed first.
 (if (= kind 1) (do (vector-assoc! M (+ MM-SIR-BASE 28) OP-LGET) (vector-assoc! M (+ MM-SIR-BASE 29) 0) (vector-assoc! M (+ MM-SIR-BASE 30) 2)) M)
 ;; undefined / uncut dependency cycle across backedge.
 (if (= kind 2) (do (vector-assoc! M (+ MM-SIR-BASE 16) OP-CONST) (vector-assoc! M (+ MM-SIR-BASE 17) 2) (vector-assoc! M (+ MM-SIR-BASE 52) OP-CONST) (vector-assoc! M (+ MM-SIR-BASE 53) 2)) M)
 ;; chosen local overwritten by first read's scalar result.
 (if (= kind 3) (do (vector-assoc! M (+ MM-SIR-BASE 52) OP-LSET) (vector-assoc! M (+ MM-SIR-BASE 53) 1) (vector-assoc! M (+ MM-SIR-BASE 54) 0) (vector-assoc! M (+ MM-SIR-BASE 56) OP-LGET) (vector-assoc! M (+ MM-SIR-BASE 57) 0) (vector-assoc! M (+ MM-SIR-BASE 58) 1)) M)
 (if (= kind 5) (vector-assoc! M (+ MM-SIR-BASE 28) OP-CALL) M)
 (if (= kind 6) (vector-assoc! M (+ MM-SIR-BASE 28) OP-CAP) M)
 ;; different-local copy is not the selected-local root.
 (if (= kind 7) (vector-assoc! M (+ MM-SIR-BASE 18) 2) M)
 (let [S (sc-build M 1 17 1)]
  (if (= kind 4) (vector-assoc! S 0 2) M)
  (if (= kind 8) (vector-assoc! S 7 8192) M)
  (if (= kind 9) (do (vector-assoc! S (+ 8 1) 0) (vector-assoc! M (+ MM-SIR-BASE 16) OP-CONST) (vector-assoc! M (+ MM-SIR-BASE 17) 2)) M)
  (if (= (vector-at S 1) 1) (sc-queries M S) S)
  (vector-at S 1))))
'''.replace('INIT',init)
base=base.replace('(defn- seed-main [] :i64 (drv-main))',driver+'\n(defn- seed-main [] :i64 (run 0))')
def build(name,source):
 src=P/(name+'.kotoba');src.write_text(source);out=P/(name+'.bin')
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(P/(name+'.kseed'))]),('extract',['extract-native',str(P/(name+'.kseed')),'--symbol','run','--output',str(out)])]:
  q=subprocess.run([str(O/'kexe-loader'),str(O/'seed-0.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(P/(name+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,stage,q.stdout[-500:],q.stderr[-500:])
  if stage=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1])
 return out,off
def execute(out,off,k):
 e=dict(os.environ,KEXE_FUEL='1048576',KEXE_STRUCTURED_REPORT='1',KEXE_VECTOR_ITEMS='134217728');e.pop('KEXE_COMMAND',None)
 q=subprocess.run([str(O/'kexe-loader'),str(out),str(off),'1','aarch64','-',str(k)],env=e,capture_output=True,text=True);assert q.returncode==0,(k,q.stdout,q.stderr)
 (P/(out.stem+'-kind'+str(k)+'.stderr')).write_text(q.stderr)
 return {'exit':q.returncode,'stdout':q.stdout,'stderrSha256':hashlib.sha256(q.stderr.encode()).hexdigest(),'stderrBytes':len(q.stderr)}
records=[];out,off=build('safe',base)
for k in range(10):
 obs=execute(out,off,k);expected=int(k==0);assert (':result '+str(expected)+' ') in obs['stdout'],(k,obs);records.append({'kind':k,'expected':expected,'actual':obs});print('PASS native predicate',k,flush=True)
mutants=[]
for name,old,new,k in [('ignore-other-predecessors','(vector-at S (sc-next-at S cursor))','0',1),('ignore-chosen-local-write','(or (= op OP-RT) chosen-write)','(= op OP-RT)',3)]:
 assert base.count(old)==1;mo,moff=build(name,base.replace(old,new));obs=execute(mo,moff,k);assert ':result 1 ' in obs['stdout'],(name,obs);mutants.append({'name':name,'kind':k,'detected':True,'baseline':records[k]['actual'],'mutant':obs,'nativeSha256':hashlib.sha256(mo.read_bytes()).hexdigest()});print('PASS native predicate source fault',name,flush=True)
(D/'native-predicate.json').write_text(json.dumps({'status':'PASS','scope':'Welltyped native diagnostic driver over synthetic raw SIR; not checked guest program admission','controls':records,'mutants':mutants},indent=2)+'\n')
