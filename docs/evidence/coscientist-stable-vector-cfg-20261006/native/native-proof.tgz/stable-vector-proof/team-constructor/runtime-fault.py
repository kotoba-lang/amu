from pathlib import Path
import struct,json,os,subprocess,hashlib
D=Path(__file__).resolve().parent;O=Path('/private/tmp/amu-private-length-clones-20261006');p=D/'framed-diamond/candidate.bin';raw=bytearray(p.read_bytes());w=list(struct.unpack('<'+'I'*(len(raw)//4),raw));flag=22;needle=0xd2800000|flag;sites=[i for i,x in enumerate(w) if x==needle];assert len(sites)==1,sites
struct.pack_into('<I',raw,sites[0]*4,needle|(1<<5));out=D/'flag-init-valid.bin';out.write_bytes(raw)
e=dict(os.environ,KEXE_FUEL='1048576',KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run([str(O/'full-state-loader'),str(out),(D/'framed-diamond/candidate.offset').read_text().strip(),'1','aarch64','-','1'],env=e,capture_output=True,text=True)
ref=next(r for r in json.loads((D/'baseline.json').read_text())['rows'] if r['case']=='framed-diamond' and r['n']==1 and r['fuel']==1048576);actual={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};assert actual!={k:ref[k] for k in actual}
(D/'runtime-fault.json').write_text(json.dumps({'status':'PASS actual native flag-initialized-valid fault detected','wordSite':sites[0],'before':needle,'after':needle|32,'baseline':ref,'mutant':actual,'nativeSha256':hashlib.sha256(raw).hexdigest()},indent=2)+'\n');print('PASS runtime validation fault')
