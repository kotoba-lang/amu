exec((__import__('pathlib').Path('/private/tmp/amu-stable-vector-cfg-20261006/team-constructor/verify.py')).read_text().split('I=D.parent')[0])
import struct
I=D.parent/'implementation';oracle=json.loads((D/'allpred.json').read_text())['rows'];rows=[]
for name in json.loads((D/'cases.json').read_text()):
 d=D/name
 for stage,args in [('compile',['compile',str(D/(name+'.kotoba')),'--target','aarch64-macos','--output',str(d/'candidate-observer.kseed')]),('extract',['extract-native',str(d/'candidate-observer.kseed'),'--symbol','run','--output',str(d/'candidate-observer.bin')])]:
  q=subprocess.run([str(O/'kexe-loader'),str(I/'observer/seed.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/('candidate-observer-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,stage,q.stderr)
  if stage=='extract':off=int(re.search(r':offset (\d+)',q.stdout)[1])
 assert (d/'candidate-observer.bin').read_bytes()==(d/'candidate.bin').read_bytes() and off==int((d/'candidate.offset').read_text())
 log=(d/'candidate-observer-compile.log').read_text();events=[list(map(int,l.split()[1:])) for l in log.splitlines() if l.startswith('SLADMIT ')];queries=[list(map(int,l.split()[1:])) for l in log.splitlines() if l.startswith('SCQUERY ')];results=[list(map(int,l.split()[1:])) for l in log.splitlines() if l.startswith('SCRESULT ')]
 expected=[r['function'] for r in oracle if r['case']==name and r['prospectiveAdmitted']];assert [e[0] for e in events]==expected,(name,expected,events)
 raw=(d/'candidate.bin').read_bytes();words=struct.unpack('<'+'I'*(len(raw)//4),raw[:len(raw)//4*4]);checks=[]
 for e in events:
  f,site,slot,old,new,frame,end=e;r=next(r for r in oracle if r['case']==name and r['function']==f);assert frame==r['newFrameProspective'] and old==r['oldNsv']
  actual=[q for q in queries if q[0]==site];assert [(q[1],q[2],q[3]) for q in actual]==[(x['site'],x['temp'],int(x['accepted'])) for x in r['queries']],(name,r['queries'],actual)
  assert actual[-1][4]==131072-r['sharedVisitBudgetUsed'],(name,actual[-1],r['sharedVisitBudgetUsed'])
  flag=18+new;length=16+new;base=17+new;refs=[i for i,w in enumerate(words) if w==0xb5000000|(13<<5)|flag]
  for i in refs:assert words[i+12]==0xd2800000|(1<<5)|flag and words[i+13]&0xff20001f==0xeb00001f and (words[i+13]>>16)&31==length and words[i+14]==0x54000043 and words[i+15]==0
  assert len(refs)==r['readCount'],(name,refs,r['readCount']);checks.append({'function':f,'sharedVisits':r['sharedVisitBudgetUsed'],'chosenLocalWritesChecked':sum(x['kind']=='selected-local-write' for x in r['queries']),'cacheRegs':[length,base,flag],'actualGuardSitesWords':refs,'allReadsRetainRuntimeFlagBoundsTrapAndFreshLoad':True})
 rows.append({'case':name,'observerBytesAndOffsetEqual':True,'actualAdmit':events,'actualQueries':queries,'actualResults':results,'machineChecks':checks});print('PASS ALLpred actualevents/guards',name,len(events),flush=True)
(D/'emit-check.json').write_text(json.dumps({'status':'PASS independent ALL-pred/local-write/shared-budget oracle vs actual native admission and mandatory read guards','rows':rows},indent=2)+'\n')
