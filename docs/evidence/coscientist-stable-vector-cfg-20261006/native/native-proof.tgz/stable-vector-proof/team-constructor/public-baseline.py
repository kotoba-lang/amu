exec((__import__('pathlib').Path('/private/tmp/amu-stable-vector-loop-20261006/team-constructor/baseline.py')).read_text().split('rows=[]')[0])
rows=[]
for name in json.loads((D/'cases.json').read_text()):
 d=D/name;q=subprocess.run([str(O/'kexe-loader'),str(O/'seed-0.bin'),'0','0','aarch64','35,37,38,39','--','extract-native',str(d/'baseline.kseed'),'--symbol','walk','--output',str(d/'baseline-walk.bin')],env=env,capture_output=True,text=True);assert q.returncode==0;(d/'baseline-walk-extract.log').write_text(q.stdout+q.stderr);off=int(re.search(r':offset (\d+)',q.stdout)[1]);(d/'baseline-walk.offset').write_text(str(off)+'\n')
 for handle in [0,1,-1,9223372036854775807]:
  for n in [0,1]:
   e=dict(os.environ,KEXE_FUEL='1048576',KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
   q=subprocess.run([str(O/'full-state-loader'),str(d/'baseline-walk.bin'),str(off),('5' if name.startswith('framed-') else '2'),'aarch64','-',str(handle),str(n),*(['1','2','0'] if name.startswith('framed-') else [])],env=e,capture_output=True,text=True)
   want=0 if n==0 and name in ['loop-first-read','conditional-first','vector-local-change','independent-condition'] else 'trap'
   if want=='trap':assert q.returncode!=0 and 'KEXE_TRAP' in q.stderr,(name,handle,n,q.stdout,q.stderr)
   else:assert q.returncode==0 and ':result 0 ' in q.stdout,(name,handle,n,q.stdout,q.stderr)
   rows.append({'case':name,'handle':handle,'n':n,'fuel':1048576,'independentExpected':want,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
(D/'public-baseline.json').write_text(json.dumps({'status':'PASS original first-read placement observable semantic oracle','rows':rows},indent=2)+'\n');print('PASS invalid-public-handle first-read order',len(rows))
