# Independent bounded dependency-closure + Kahn DAG oracle; no recursive DFS or native stack emulation.
exec((__import__('pathlib').Path('/private/tmp/amu-stable-vector-cfg-20261006/team-constructor/oracle.py')).read_text().split('for name in json.loads')[0])
from collections import deque
LIMIT=131072

def define(q):
 o,a,b,c=q
 if o in [OP(x) for x in ['CONST','LGET','STR','TAB','VEC','FADDR','VECP','RES2']]:return a
 if o in [OP(x) for x in ['BIN','CMP','UN','CALL','RT','CALLI']]:return b
 if o==OP('CAP'):return c
 return -1

def query(s,pred,site,temp,slot,cap):
 # Root is use-before-definition; original last definitions are proof leaves.
 nodes={site};todo=deque([site]);edges={};leaves={};reason=None
 while todo:
  node=todo.popleft()
  if len(nodes)-1>cap:return False,len(nodes)-1,'visit-cap',None
  ps=pred[node]
  if node!=site and define(s[node])==temp:
   leaves[node]=s[node][0]==OP('LGET') and s[node][2]==slot;edges[node]=[]
   if not leaves[node]:reason='alternative-definition'
   continue
  edges[node]=ps
  if not ps:reason=reason or 'entry-undefined'
  for p in ps:
   if p not in nodes:nodes.add(p);todo.append(p)
 indegree={n:0 for n in nodes};forward={n:[] for n in nodes}
 for n,ps in edges.items():
  for p in ps:indegree[n]+=1;forward[p].append(n)
 queue=deque(n for n in nodes if indegree[n]==0);ordered=[]
 while queue:
  n=queue.popleft();ordered.append(n)
  for nxt in forward[n]:
   indegree[nxt]-=1
   if indegree[nxt]==0:queue.append(nxt)
 if len(ordered)!=len(nodes):reason=reason or 'dependency-cycle'
 return reason is None,len(nodes)-1,reason,{'root':[site,temp,slot],'nodes':sorted(nodes),'predecessors':{str(n):edges[n] for n in sorted(nodes)},'acceptedDefinitions':sorted(n for n,v in leaves.items() if v)}

def graph(s,start,end):
 labs={};pred={i:[] for i in range(start+1,end)}
 for i in pred:
  o,a,b,c=s[i]
  if o==OP('LABEL'):
   assert a not in labs and 0<a<C['MM-LABEL-CAP'];labs[a]=i
 for i in pred:
  o,a,b,c=s[i];targets=[] if o==OP('RET') else [labs[a]] if o==OP('BR') else [labs[b],i+1] if o in [OP('BRZ'),OP('BRNZ')] else [i+1]
  for n in targets:
   if n==end:continue
   assert n in pred;pred[n].append(i)
 return pred,labs

rows=[];physical={x['case']:x for x in json.loads((D/'physical.json').read_text())['rows']}
for name in json.loads((D/'cases.json').read_text()):
 sec=(D/name/'observer-compile.log').read_text().split('PCPHASE ')[1];s={};ff={}
 for line in sec.splitlines():
  t=line.split()
  if t and t[0]=='SIR':s[int(t[1])]=tuple(map(int,t[2:]))
  if t and t[0]=='PCFF':f,k,v=map(int,t[1:]);ff.setdefault(f,{})[k]=v
 for f,m in ff.items():
  np=m[C['FF-NPARAMS']];vectors=[k+1 for k in range(np) if m.get(C['FF-PT0']+k)==C['TY-VEC']]
  if not vectors:continue
  chosen=vectors[0];start=m[C['FF-SIR']];end=next(i for i in range(start+1,max(s)+1) if s[i][0]==OP('END'));pred,labs=graph(s,start,end);queries=[];used=0;reasons=[];reads=0;backs=0
  for i in range(start+1,end):
   o,a,b,c=s[i]
   if o in [OP('BR'),OP('BRZ'),OP('BRNZ')]:backs+=int(labs[a if o==OP('BR') else b]<i)
   allowed=o in [OP(x) for x in ['CONST','LGET','LSET','RET','FUEL','LABEL','BR','BRZ','BRNZ']]
   if o in [OP('BIN'),OP('CMP'),OP('UN')]:allowed=a<C[{OP('BIN'):'BOP-F64-ADD',OP('CMP'):'CC-F64-EQ',OP('UN'):'UOP-F64-NEG'}[o]]
   if o==OP('RT'):reads+=1;allowed=a==C['RT-VECTOR-AT'] and c==2 and 0<=b<=5
   if not allowed:reasons.append(['whole-body-op',i,o])
   if (o==OP('RT') and allowed) or (o==OP('LSET') and a==chosen):
    ok,n,why,cert=query(s,pred,i,b,chosen,max(0,LIMIT-used));used+=n;queries.append({'site':i,'temp':b,'kind':'read' if o==OP('RT') else 'selected-local-write','accepted':ok,'visits':n,'refusal':why,'certificate':cert})
    if not ok:reasons.append(['origin',i,why])
  old=next(q for q in physical[name]['fn'] if q[0]==f);cache=next(q for q in physical[name]['cache'] if q[0]==f)
  shape=1<=np<=5 and len(vectors)==1 and all(m.get(C['FF-PT0']+k) in [C['TY-VEC'],C['TY-I64'],C['TY-BOOL']] for k in range(np)) and reads>=2 and backs>0 and end-start<=8192
  # Old physical frame/leaf/cache/nsv conditions; actual expanded frame upper bound from declared ns/dp.
  newnsv=old[5]+3;r16=lambda x:(x+15)//16*16;newframe=r16(8*(old[3]+old[4]+2))+r16(8*newnsv)
  physicalGuard=old[2]>0 and old[6]==1 and cache[1]==0 and old[5]<=7 and newframe<=32768
  rows.append({'case':name,'function':f,'selectedVectorParameter':chosen,'sourceRange':[start,end],'readCount':reads,'backedges':backs,'sharedVisitBudgetUsed':used,'structuralShape':shape,'oldPhysicalGuard':physicalGuard,'oldFrame':old[2],'oldNsv':old[5],'newFrameProspective':newframe,'prospectiveAdmitted':shape and physicalGuard and not reasons,'reasons':reasons,'queries':queries})
(D/'allpred.json').write_text(json.dumps({'status':'PASS independent finite all-predecessor dependency-DAG/local-induction oracle','sharedVisitCap':LIMIT,'rows':rows,'doesNotGrantValidationWitness':True},indent=2)+'\n');print([(r['case'],r['prospectiveAdmitted'],r['sharedVisitBudgetUsed']) for r in rows])
