from pathlib import Path
import json,runpy,re,hashlib,struct,collections
D=Path(__file__).resolve().parent;A=runpy.run_path(str(D/'analyze.py'));B=A['B'];I=A['I'];C=A['C'];cfg=A['cfg'];query=A['query_before'];parse=A['parse'];op=A['op'];data=json.loads((D/'analysis.json').read_text());rows=[]
for r in data['newBeyondFrozenV1']:
 p=B/r['workload'];s,_,fn,cache=parse(p/'compile.log');f=r['fn'];m=fn[f];pred,l=cfg(s,r['start'],r['end']);events={};words=list(struct.unpack('<'+'I'*((p/'native.bin').stat().st_size//4),(p/'native.bin').read_bytes()));bounds=[]
 for line in (p/'compile.log').read_text().splitlines():
  x=line.split()
  if x and x[0]=='EMIT':events[int(x[1])]=tuple(map(int,x[2:]))
 cacheRegs=list(range(19+m[4],22+m[4]));reads=0
 for q in r['queries']:
  if s[q['sir']][0]!=op('RT'):continue
  skip,start,end=events[q['sir']];tail=words[end-16:end-1];assert len(tail)==15
  rv=(tail[2]>>5)&31;ri=(tail[9]>>5)&31;dest=tail[-1]&31;assert set([rv,ri,dest]).isdisjoint(cacheRegs)
  assert tail[0:2]==[0xf9409cf0,0xf9400210] and tail[4:6]==[0x54000043,0] and tail[10:12]==[0x54000043,0]
  bounds.append({'sir':q['sir'],'rv':rv,'index':ri,'destination':dest,'reservedCacheRegisters':cacheRegs,'registerDisjoint':True});reads+=1
 oldSaveWords=(m[4]+1)//2;newSaveWords=(m[4]+3+1)//2;extraEntryReturnWords=2*(newSaveWords-oldSaveWords)+1;extraReadWords=2*reads
 bodyWords=sum(end-start for skip,start,end in events.values() if r['start']<=next((i for i,v in events.items() if v==(skip,start,end)),0)<r['end']) if False else sum(v[2]-v[1] for i,v in events.items() if r['start']<=i<=r['end'])
 joins=[]
 for q in r['queries']:
  for node in q['proofNodes']:
   if len(pred[node])>1:joins.append({'query':q['sir'],'join':node,'predecessors':pred[node],'temp':q['temp'],'allPredecessorOrigin':q['origin']})
 rows.append({'workload':r['workload'],'fn':f,'oldFrame':m[1],'proposedFrame':r['newFrameEstimate'],'oldNsv':m[4],'newNsv':m[4]+3,'cacheRegisters':cacheRegs,'reads':bounds,'joinCertificates':joins,'actualBaselineFunctionWords':bodyWords,'estimatedAddedCodeWords':extraEntryReturnWords+extraReadWords,'estimateAssumptions':'Same exact existing mode3 17-word guarded read, no compile guard elision; save/restore pair grouping as gn-csave. Frame adjustment changes existing immediates; no new homes/source transforms. Pool alignment may add4bytes. Not a compiled candidate or native register proof.'})
# Independent forward must-CFG oracle references; minimal local-only query may
# conservatively reject aliases accepted by the richer local propagation oracle.
T=D.parent/'team-constructor';oracle=json.loads((T/'oracle.json').read_text());comparison=[]
for row in oracle['rows']:
 p=T/row['case']/'observer-compile.log'
 if not p.exists():continue
 s,ff,_,_=parse(p,True);start,end=row['sourceRange'];pred,l=cfg(s,start,end);qq=[]
 for a in row['accesses']:
  site=a['site'];yes,n,why,nodes=query(s,pred,site,s[site][2],1,131072)
  qq.append({'sir':site,'rootedSameLocalOrigin':yes,'independentForwardRootOrigin':a['rootVectorInput'],'refusalReason':why})
 comparison.append({'case':row['case'],'originComparison':qq,'structuralEffectsAdmissionStillSeparate':True})
(D/'design-receipt.json').write_text(json.dumps({'status':'READ-ONLY seven potential admissions across six workloads; two new workloads vs frozen v1','newFunctions':rows,'independentOracleComparison':comparison,'complexity':'CFG O(N+E), E<=2N. Each fixed-temp rooted must query O(N+E) time and O(N) state; Q<=N, worstO(N^2), global131072visited-node cap refuses unknown. N<=8192. No recursive unbounded search. Remaining current scan/label validation cost unchanged.','runtimeValidation':'Flag remains runtime-guarded across joins/backedges; no firstread motion, bounds/fuel/trap/load removal or result cache. No compile witness strengthening proposed.','proofRequirements':['typed original SIR and exact local CFG/fallthrough/RET definitions','every root local write exact all-predecessor same-local origin; induction from original typed parameter','budget/cycle/undefined/alternative origin failures restore original compiler behavior','allocate/save/restore new callee registers including shifted homes/frame/fuel/trap/private target controls','repeat full native word/edge/literal/fixup audit and generations2/3/4 plus original19 native semantic gates before timing'],'notImplemented':True,'notTimed':True,'notSpeedupClaim':True},indent=2)+'\n')
print([(r['workload'],r['estimatedAddedCodeWords'],r['cacheRegisters']) for r in rows])
