from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent;W=D.parent;I=W/'implementation';C=W/'team-constructor';OLD=Path('/private/tmp/amu-private-length-clones-20261006');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(I/'seed-4.bin')=='eab3a7c26eac2fdf32a3d4736fd8dd1c159b811a6dc6b5ef0f69c1d44b798406'
for p,h in json.loads((I/'source-pins.json').read_text()).items():assert sha(I/p)==h
resources=json.loads((D/'resource-states.json').read_text());fuel=json.loads((D/'fuel-states.json').read_text());callee=json.loads((D/'callee-proof.json').read_text());regen=json.loads((D/'regeneration-proof.json').read_text());frame=json.loads((D/'frame-native-proof.json').read_text())
assert resources['fullStatePairs']==161 and resources['trappedPairs']==46
assert fuel['pairs']==209 and fuel['trappedPairs']==151
assert callee['pairs']==8 and callee['actualMachineMutantsDetected']==4
assert len(regen['rows'])==4
# Independently enumerate the admitted frame layout arithmetic, separate from native execution.
rows=[]
for old in range(8):
 for homes in range(4097):
  nnew=old+3;f=((8*(homes+2)+15)//16)*16+((8*nnew+15)//16)*16
  if f<=32768:
   savedEnd=8*nnew;lowest=f-8*(homes+2)
   assert lowest>=savedEnd and f%16==0 and 19+old<=21+old<=28
   rows.append((old,homes,f,lowest,savedEnd))
(D/'frame-arithmetic.json').write_text(json.dumps({'status':'PASS independent bounded arithmetic enumeration; not execution or OS stack proof','combinations':len(rows),'homeLowestFormula':'F-8*(NS+DP+2); all actual home indices <= NS+DP+1','savedArea':'[0,8*(oldNSV+3)); OUT0','registers':'LEN19+oldNSV,BASE20+oldNSV,FLAG21+oldNSV; oldNSV0..7','minHomeSaveGap':min(r[3]-r[4] for r in rows)},indent=2)+'\n')
(D/'frame-nondetection.json').write_text(json.dumps({'status':'CALIBRATION limitation retained','source':'frame-native/compiler.kotoba','mutation':'remove expanded-frame update while retaining three new saved registers','actualExecutedTypedRunPairs':8,'actualExecutedCallerSentinelCases':2,'typedResultMismatches':0,'sentinelMismatches':0,'physicalInvariantDetection':'regeneration no-expanded-frame native probe: closed frame128 expected160, NSV5','separateUnsafeOverlapFault':'frame-native-overlap/compiler.kotoba forces frame16 and yields8/8 guest mismatches plus2/2 sentinel traps'},indent=2)+'\n')
inputs=[I/'seed-4.bin',I/'kexe-loader',I/'source-pins.json',I/'41-a64gen-prototype.kotoba',I/'stable-native.kotoba',I/'cfg-native.kotoba',I/'unity.kotoba',I/'ports-build.json',I/'observer/admission.json',OLD/'full-state-loader',OLD/'ports-state.json',OLD/'ports-correctness.json']
for r in json.loads((I/'ports-build.json').read_text())['entries']:
 inputs.extend([I/'ports'/r['workload']/'native.bin',OLD/'baseline-native'/(r['workload']+'.bin')])
for name in ['framed-diamond','framed-loop-diamond']:
 inputs.extend([C/(name+'.kotoba'),C/name/'candidate-walk.bin',C/name/'candidate-walk.offset',C/name/'candidate.bin',C/name/'candidate.offset'])
pins={str(p):sha(p) for p in inputs}
evidence={str(p.relative_to(D)):sha(p) for p in D.rglob('*') if p.is_file() and p.name!='report.json'}
report={'status':'PASS terminal independent CFG resource/fuel/framed ABI and fault-calibration audit','candidate':{'path':str(I/'seed-4.bin'),'sha256':sha(I/'seed-4.bin'),'bytes':(I/'seed-4.bin').stat().st_size,'offset':0},'nativeResults':{'original19ResourcePairs':161,'resourceTraps':46,'original19FuelPairs':209,'fuelTraps':151,'allExactFullState':True,'publicCalleeSentinelPairs':8,'calleeRegisters':'x19..x28','machineFaultsDetected':4,'frame16SourceCompilerFaultDetected':True,'frame16GuestMismatches':8,'frame16CallerTraps':2,'sameMClosedOpenClosedSourceAndCodeRestoration':True,'originalNSV2FrameGrowth':'128 ->160','acceptedOriginalFrameCeilingFallback':'32768,mode0,error0','unsafeFrameCeilingSourceFault':'32800,mode3,error4103','zeroQueryBudgetSourceControl':'safe mode0 fallback,originalNSV2/frame128/code preserved'},'contracts':{'scratchAllocationWords':'8+8*(bodyN+1); bodyN<=8192','maxPredecessorEdges':'2*bodyN','walkStack':'bodyN','sharedOriginVisitBudget':131072,'unknownOrBudgetExhausted':'generic original path','newSaveRegs':['qrduino oldNSV1 x20..22,NSV4/frame160','xgboost oldNSV2 x21..23,NSV5/frame176'],'frameArithmeticCombinations':len(rows)},'limitations':['Guest heap/string/vector/vector-items and fuel parity tested at these original19 boundaries; compiler scratch allocation/host process resource use is separate.','OS stack ceiling boundary parity across all possible nesting/frame extremes is not proved.','Public success returns preserve callee registers; terminal traps need not return to a caller.','Omitting frame growth was detected by actual native physical metadata invariant, but these two typed guests and sentinel returns did not expose it; explicitly retained non-detection.','No performance measurement, product promotion, whole-program equivalence or C-or-better completion claim.'],'inputPins':pins,'evidencePins':evidence,'writesComplete':True}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
for p,h in pins.items():assert sha(Path(p))==h
for p,h in evidence.items():assert sha(D/p)==h
print('PASS terminal all pins',len(pins),len(evidence),'framecombinations',len(rows))
