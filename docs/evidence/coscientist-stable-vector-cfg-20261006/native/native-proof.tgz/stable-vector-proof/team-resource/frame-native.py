from pathlib import Path
import json,os,re,subprocess,struct
D=Path(__file__).resolve().parent;I=D.parent/'implementation';C=D.parent/'team-constructor';OLD=Path('/private/tmp/amu-private-length-clones-20261006')
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
s=(I/'unity.kotoba').read_text();needle='(gn-gs gn-f-fb frame) (gn-gs gn-f-vmode 3)';assert s.count(needle)==1
P=D/'frame-native-overlap';P.mkdir(exist_ok=True);src=P/'compiler.kotoba';src.write_text(s.replace(needle,'(gn-gs gn-f-fb 16) (gn-gs gn-f-vmode 3)'))
def invoke(bin,off,args,label):
 q=subprocess.run([str(I/'kexe-loader'),str(bin),str(off),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(P/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout[-300:],q.stderr);return q.stdout
invoke(I/'seed-4.bin',0,['compile',str(src),'--target','aarch64-macos','--output',str(P/'compiler.kseed')],'compiler-compile')
o=invoke(I/'seed-4.bin',0,['extract-native',str(P/'compiler.kseed'),'--symbol','main','--output',str(P/'compiler.bin')],'compiler-extract');off=int(re.search(r':offset (\d+)',o)[1]);rows=[]
for case in ['framed-diamond','framed-loop-diamond']:
 invoke(P/'compiler.bin',off,['compile',str(C/(case+'.kotoba')),'--target','aarch64-macos','--output',str(P/(case+'.kseed'))],case+'-compile')
 o=invoke(P/'compiler.bin',off,['extract-native',str(P/(case+'.kseed')),'--symbol','run','--output',str(P/(case+'.bin'))],case+'-extract');at=int(re.search(r':offset (\d+)',o)[1])
 for n in [0,1,2,4]:
  e=dict(os.environ,KEXE_FUEL='1048576',KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);obs={}
  for lab,p,ofs in [('candidate',C/case/'candidate.bin',int((C/case/'candidate.offset').read_text())),('frame-mutant',P/(case+'.bin'),at)]:
   q=subprocess.run([str(OLD/'full-state-loader'),str(p),str(ofs),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True);obs[lab]={'exit':q.returncode,'stdout':q.stdout.strip(),'stderr':q.stderr.strip()}
  rows.append({'case':case,'n':n,**obs,'detected':obs['candidate']!=obs['frame-mutant']})
# The result-only source mutants remain semantically equal here; calibrate caller ABI.
namespace={'struct':struct};wrapcode=(D/'callee.py').read_text().split('def wrap(raw,off):',1)[1].split('rows=[]',1)[0];exec('def wrap(raw,off):'+wrapcode,namespace);wrap=namespace['wrap'];sentinels=[]
for case in ['framed-diamond','framed-loop-diamond']:
 o=invoke(P/'compiler.bin',off,['extract-native',str(P/(case+'.kseed')),'--symbol','walk','--output',str(P/(case+'-walk.bin'))],case+'-walk-extract');at=int(re.search(r':offset (\d+)',o)[1]);blob,at=wrap((P/(case+'-walk.bin')).read_bytes(),at);f=P/(case+'-sentinel.bin');f.write_bytes(blob)
 e=dict(os.environ,KEXE_FUEL='1048576',KEXE_STRUCTURED_REPORT='1',KEXE_ARG_TYPES='vector-i64,i64,i64,i64,i64');e.pop('KEXE_COMMAND',None)
 q=subprocess.run([str(OLD/'full-state-loader'),str(f),str(at),'5','aarch64','-','vi:11,13,17','1','1','2','0'],env=e,capture_output=True,text=True)
 detected=q.returncode!=0 or ':result 999 ' in q.stdout;sentinels.append({'case':case,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr,'detected':detected})
assert any(r['detected'] for r in rows) and all(r['detected'] for r in sentinels),(rows,sentinels)
(D/'frame-native-proof.json').write_text(json.dumps({'status':'PASS actual frame16 overlap source mutant compiled as compiler then typed guest result controls detect corrupted homes','rows':rows,'callerSentinels':sentinels,'resultOnlyDetected':sum(r['detected'] for r in rows)},indent=2)+'\n')
print('PASS frame source mutant actual guest mismatches',sum(r['detected'] for r in sentinels),'of',len(sentinels))
