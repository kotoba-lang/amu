from pathlib import Path
import json,os,re,subprocess,hashlib
W=Path('/private/tmp/amu-stable-vector-cfg-20261006/implementation');D=W.parent/'team-resource';C={n:int(v) for n,v in re.findall(r'\(def ([A-Z][A-Z0-9-]*) (-?\d+)\)',(W/'unity.kotoba').read_text())}
body=[('FN',1,1,9),('LGET',0,1),('CONST',1,0),('RT',176,0,2),('LSET',9,0),('CONST',0,2),('LSET',8,0),('LABEL',1),('LGET',0,1),('CONST',1,1),('RT',176,0,2),('LSET',9,0),('LGET',0,1),('CONST',1,2),('RT',176,0,2),('LSET',9,0),('LGET',0,8),('CONST',1,1),('BIN',C['BOP-SUB'],0),('LSET',8,0),('LGET',0,8),('BRNZ',0,1),('LGET',0,9),('RET',0),('END',1)]
writes=[(C['MM-SIR-N'],len(body)+1),(C['MM-FN-N'],2),(C['MM-LABEL-N'],3),(C['MM-CODE-N'],1),(C['MM-FIX-N'],1)]
for field,v in [('FF-SIR',1),('FF-NPARAMS',1),('FF-NSLOTS',9),('FF-DEPTH',2),('FF-RTYPE',C['TY-I64']),('FF-PT0',C['TY-VEC']),('FF-KIND',C['FK-PRIV'])]:writes.append((C['MM-FN-BASE']+C['MM-FN-W']+C[field],v))
for p,row in enumerate(body,1):
 vals=[C['OP-'+row[0]],*row[1:]]+[0]*(4-len(row))
 for k,v in enumerate(vals):writes.append((C['MM-SIR-BASE']+p*4+k,v))
integrity=[]
originals=[(a,v) for a,v in writes if a not in [C['MM-CODE-N'],C['MM-FIX-N']]]
for g in range(0,len(originals),20):
 ch=originals[g:g+20];integrity.append('(defn- r-int%d [M :vector-i64] :bool (and %s))'%(g//20,' '.join('(= (vector-at M %d) %d)'%(a,v) for a,v in ch)))
checks='(and '+' '.join('(r-int%d M)'%i for i in range(len(integrity)))+')'
integrity.append('(defn- r-integrity [M :vector-i64] :bool '+checks+')')
loads=[]
for g in range(0,len(writes),20):
 ch=writes[g:g+20];loads.append('(defn- r-load%d [M0 :vector-i64] :vector-i64 (let [%s] M%d))'%(g//20,' '.join('M%d (mem-set M%d %d %d)'%(i+1,i,a,v) for i,(a,v) in enumerate(ch)),len(ch)))
expr='(vector-alloc MM-WORDS)'
for n in range(len(loads)):expr='(r-load%d %s)'%(n,expr)
entry='''
(defn- r-out [label :string n :i64] :i64 (io-out (string-concat label (string-concat " " (string-concat (string-from-i64 n) "\\n")))))
(defn- r-copy [M :vector-i64 V :vector-i64 i :i64 n :i64] :vector-i64 (if (= i n) V (r-copy M (mem-set V i (vector-at M (+ MM-CODE-BASE i))) (inc i) n)))
(defn- r-equal [M :vector-i64 V :vector-i64 i :i64 n :i64] :bool (if (= i n) true (and (= (vector-at V i) (vector-at M (+ MM-CODE-BASE i))) (r-equal M V (inc i) n))))
(defn- seed-main [] :i64
 (let [M INIT a (gn-run M) n (vector-at a MM-CODE-N) V (r-copy a (vector-alloc n) 0 n)
       o0 (r-out "CLOSED-MODE" (gn-g a gn-f-vmode)) o1 (r-out "CLOSED-FRAME" (gn-g a gn-f-fb))
       os0 (r-out "CLOSED-SOURCE-EQUAL" (if (r-integrity a) 1 0)) o2 (r-out "CLOSED-NSV" (gn-g a gn-f-nsv)) o3 (r-out "CLOSED-ERR" (vector-at a MM-ERR))
       open (gn-run-open (-> a (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1)) 1 1)
       os1 (r-out "OPEN-SOURCE-EQUAL" (if (r-integrity open) 1 0)) o4 (r-out "OPEN-MODE" (gn-g open gn-f-vmode))
       o5 (r-out "OPEN-CODE-EQUAL" (if (and (= n (vector-at open MM-CODE-N)) (r-equal open V 0 n)) 1 0))
       again (gn-run (-> open (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1)))
       os2 (r-out "AGAIN-SOURCE-EQUAL" (if (r-integrity again) 1 0)) o6 (r-out "AGAIN-CODE-EQUAL" (if (and (= n (vector-at again MM-CODE-N)) (r-equal again V 0 n)) 1 0))
       huge (gn-run (-> again (mem-set MM-CODE-N 1) (mem-set MM-FIX-N 1) (mem-set (+ MM-FN-BASE MM-FN-W FF-DEPTH) 4082)))
       o7 (r-out "HUGE-MODE" (gn-g huge gn-f-vmode)) o8 (r-out "HUGE-FRAME" (gn-g huge gn-f-fb))
       o9 (r-out "HUGE-ERR" (vector-at huge MM-ERR))] 0))
'''.replace('INIT',expr)
R=W/'source-snapshot';base='\n'.join((R/p).read_text() for p in ['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba']);code=(W/'41-a64gen-prototype.kotoba').read_text()
variants={'correct':code,'no-expanded-frame':code.replace('(gn-gs gn-f-fb frame) (gn-gs gn-f-vmode 3)','(gn-gs gn-f-vmode 3)'),'bypass-frame-ceiling':code.replace('(<= nsv 7) (<= frame 32768)','(<= nsv 7) true'),'zero-origin-budget':code.replace('(vector-assoc! 0 131072)','(vector-assoc! 0 0)')}
assert len(set(variants.values()))==4
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[]
for name,version in variants.items():
 d=D/name;d.mkdir(exist_ok=True);src=d/'probe.kotoba';src.write_text(base+'\n'+version+'\n'+'\n'.join(integrity+loads)+entry)
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(d/'probe.kseed')]),('extract',['extract-native',str(d/'probe.kseed'),'--symbol','main','--output',str(d/'probe.bin')])]:
  q=subprocess.run([str(W/'kexe-loader'),str(W/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,stage,q.stdout[-500:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout)[1]
 q=subprocess.run([str(W/'kexe-loader'),str(d/'probe.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(d/'stdout').write_text(q.stdout);(d/'stderr').write_text(q.stderr)
 obs={line.split()[0]:int(line.split()[1]) for line in q.stdout.splitlines() if len(line.split())==2};good=q.returncode==0 and obs.get('CLOSED-MODE')==3 and obs.get('CLOSED-NSV')==5 and obs.get('CLOSED-FRAME')==160 and obs.get('CLOSED-ERR')==0 and obs.get('OPEN-CODE-EQUAL')==1 and obs.get('AGAIN-CODE-EQUAL')==1 and obs.get('HUGE-MODE')==0 and obs.get('HUGE-FRAME')==32768 and obs.get('HUGE-ERR')==0
 assert all(obs.get(k)==1 for k in ['CLOSED-SOURCE-EQUAL','OPEN-SOURCE-EQUAL','AGAIN-SOURCE-EQUAL']), (name,obs)
 assert good==(name=='correct') if name!='zero-origin-budget' else obs.get('CLOSED-MODE')==0 and obs.get('CLOSED-ERR')==0 and obs.get('OPEN-CODE-EQUAL')==1 and obs.get('AGAIN-CODE-EQUAL')==1,(name,obs,q.returncode,q.stderr);rows.append({'variant':name,'exit':q.returncode,'observations':obs,'accepted':good,'detected':not good,'sha256':hashlib.sha256((d/'probe.bin').read_bytes()).hexdigest()});print(name,obs,flush=True)
(D/'regeneration-proof.json').write_text(json.dumps({'status':'PASS pristine same-M closed/open/closed and product-accepted frame ceiling fallback plus two actual source mutants','rows':rows},indent=2)+'\n')
