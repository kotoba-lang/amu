import pathlib,struct,json,subprocess,statistics
p=pathlib.Path(__file__).resolve().parent.parent
r=p/'results/r6m/matmult-int';data=bytearray((r/'matmult-int.bin').read_bytes()); changes=[]
for off in range(0,len(data)-8,4):
 m,a=struct.unpack_from('<II',data,off)
 if m&0xffe0fc00!=0x9b007c00 or a&0xffe0fc00!=0x8b000000:continue
 md=m&31;ad=a&31;an=(a>>5)&31;am=(a>>16)&31
 if md not in (an,am) or an==am or not 9<=md<=15:continue
 acc=am if an==md else an
 fused=0x9b000000|(m&0x1f0000)|(acc<<10)|(m&0x3e0)|ad
 struct.pack_into('<II',data,off,0xd503201f,fused);changes.append([off,m,a,fused])
out=p/'div-prototype/matmult-madd.bin';out.write_bytes(data)
print('patched',len(changes),flush=True)
q=json.loads((p/'results/r6m/qualification.json').read_text());w=next(w for w in q['workloads'] if w['workload']=='matmult-int');rows=[]
for i in range(30):
 for name,f in ([('old',r/'matmult-int.bin'),('madd',out)] if i%2==0 else [('madd',out),('old',r/'matmult-int.bin')]):
  load=float(subprocess.check_output(['sysctl','-n','vm.loadavg'],text=True).split()[1]);assert load<=4,load
  s=json.loads(subprocess.check_output([str(p/'runner'),'raw',str(f),str(w['offset']),'aarch64','0','10000','1','16777216'],text=True));assert s['result']==1
  s.update(arm=name,pair=i,load=load);rows.append(s)
 (p/'div-prototype/madd-results.json').write_text(json.dumps(dict(changes=changes,rows=rows),indent=2)+'\n')
a=[s['elapsedNanoseconds'] for s in rows if s['arm']=='old'];b=[s['elapsedNanoseconds'] for s in rows if s['arm']=='madd'];print('speedup',statistics.mean(a)/statistics.mean(b),'old',statistics.mean(a),'new',statistics.mean(b),'spread',max(b)/min(a),flush=True)
