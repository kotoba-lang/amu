import pathlib,subprocess,json,statistics
p=pathlib.Path(__file__).resolve().parent
asm=['.text']
for arm in ('old','fused'):
 name='madd_'+arm
 asm+=['.p2align 2',f'.globl _{name}',f'_{name}:','mov x1,#10000','mov x2,#17','mov x3,#31']+[f'mov x{k},#{k}' for k in range(4,12)]+[f'L{name}:']
 for k in range(4,12):
  asm+=['mul x17,x2,x3',f'add x{k},x{k},x17'] if arm=='old' else [f'madd x{k},x2,x3,x{k}']
 asm+=['add x2,x2,#1','subs x1,x1,#1',f'b.ne L{name}']+[f'eor x4,x4,x{k}' for k in range(5,12)]+['mov x0,x4','ret']
(p/'madd-inline.s').write_text('\n'.join(asm)+'\n');subprocess.run(['clang','-dynamiclib',str(p/'madd-inline.s'),'-o',str(p/'madd-inline.dylib')],check=True)
rows=[]
for i in range(30):
 for arm in (('old','fused') if i%2==0 else ('fused','old')):
  load=float(subprocess.check_output(['sysctl','-n','vm.loadavg'],text=True).split()[1]);assert load<=4,load
  s=json.loads(subprocess.check_output([str(p.parent/'runner'),'dylib',str(p/'madd-inline.dylib'),'madd_'+arm,'aarch64','0','500','1','16777216'],text=True));s.update(arm=arm,pair=i,load=load);rows.append(s)
 (p/'madd-inline-results.json').write_text(json.dumps(rows,indent=2)+'\n')
assert len({r['result'] for r in rows})==1
for arm in ('old','fused'):
 a=[r['elapsedNanoseconds'] for r in rows if r['arm']==arm];print(arm,statistics.mean(a),min(a),max(a),flush=True)
