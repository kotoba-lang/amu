import pathlib,subprocess,json,statistics,random,ctypes,sys
p=pathlib.Path(__file__).resolve().parent
asm=['.text','.p2align 2']
for k in (2,3,32):
 for arm in ('sdiv','shift'):
  if k==3 and arm=='shift':
   code=['mov x17, #0x5556','movk x17, #0x5555, lsl #16','movk x17, #0x5555, lsl #32','movk x17, #0x5555, lsl #48','smulh x3, x1, x17','add x3, x3, x1, lsr #63']
  elif arm=='sdiv':code=[f'mov x17, #{k}','sdiv x3, x1, x17']
  else:
   sh=k.bit_length()-1
   code=['asr x17, x1, #63',f'lsr x17, x17, #{64-sh}','add x17, x1, x17',f'asr x3, x17, #{sh}']
  name=f'{arm}{k}'
  asm+=['.p2align 2',f'.globl _{name}',f'_{name}:','mov x1,x0','mov x2,#10000','mov x4,#0','mov x5,#0x7f2d','movk x5,#0x4c95,lsl #16','movk x5,#0xf42d,lsl #32','movk x5,#0x5851,lsl #48',f'L{name}:','mul x1,x1,x5','add x1,x1,#1',*code,'eor x4,x4,x3','subs x2,x2,#1',f'b.ne L{name}','mov x0,x4','ret']
  asm+=['.p2align 2',f'.globl _edge_{name}',f'_edge_{name}:','mov x1,x0',*code,'mov x0,x3','ret']
(p/'prototype.s').write_text('\n'.join(asm)+'\n')
subprocess.run(['clang','-dynamiclib',str(p/'prototype.s'),'-o',str(p/'prototype.dylib')],check=True)
lib=ctypes.CDLL(str(p/'prototype.dylib'));rng=random.Random(17)
values=[-(1<<63),(1<<63)-1,-33,-32,-31,-3,-2,-1,0,1,2,3,31,32,33]+[rng.randrange(-(1<<63),1<<63) for _ in range(10000)]
for k in (2,3,32):
 for arm in ('sdiv','shift'):
  f=getattr(lib,f'edge_{arm}{k}');f.argtypes=[ctypes.c_int64];f.restype=ctypes.c_int64
  for x in values:assert f(x)==(abs(x)//k)*(-1 if x<0 else 1),(arm,k,x,f(x))
rows=[];runner=p.parent/'runner'
for i in range(30):
 for k in (2,3,32):
  arms=['sdiv','shift'] if i%2==0 else ['shift','sdiv']
  for arm in arms:
   load=float(subprocess.check_output(['sysctl','-n','vm.loadavg'],text=True).split()[1]);assert load<=4,load
   sample=json.loads(subprocess.check_output([str(runner),'dylib',str(p/'prototype.dylib'),f'{arm}{k}','aarch64','17','50','1','16777216'],text=True))
   sample.update(arm=arm,divisor=k,pair=i,load=load);rows.append(sample)
 (p/'prototype-results.json').write_text(json.dumps(rows,indent=2)+'\n')
for k in (2,3,32):
 a=[r['elapsedNanoseconds'] for r in rows if r['divisor']==k and r['arm']=='sdiv'];b=[r['elapsedNanoseconds'] for r in rows if r['divisor']==k and r['arm']=='shift']
 assert len({r['result'] for r in rows if r['divisor']==k})==1
 print(k,'speedup',statistics.mean(a)/statistics.mean(b),'old',statistics.mean(a),'new',statistics.mean(b),'spread',max(b)/min(a),flush=True)
