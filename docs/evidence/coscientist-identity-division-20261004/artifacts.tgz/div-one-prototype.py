import pathlib,struct,json,subprocess,statistics
p=pathlib.Path(__file__).resolve().parent;data=bytearray((p/'div-one.bin').read_bytes());changes=[]
for off in range(0,len(data)-8,4):
 m,d=struct.unpack_from('<II',data,off)
 if m!=0xd2800031 or d&0xffe0fc00!=0x9ac00c00 or (d>>16)&31!=17:continue
 move=0xaa0003e0|(((d>>5)&31)<<16)|(d&31)
 struct.pack_into('<II',data,off,0xd503201f,move);changes.append([off,m,d,move])
assert len(changes)==1,changes
(p/'div-one-patch.bin').write_bytes(data);rows=[]
value=17
for _ in range(10000):value=(value*6364136223846793005+1)&((1<<64)-1)
if value>>63:value-=1<<64
for i in range(30):
 for arm in (('old','patch') if i%2==0 else ('patch','old')):
  load=float(subprocess.check_output(['sysctl','-n','vm.loadavg'],text=True).split()[1]);assert load<=4,load
  f=p/('div-one.bin' if arm=='old' else 'div-one-patch.bin')
  s=json.loads(subprocess.check_output([str(p.parent/'runner'),'raw',str(f),'0','aarch64','0','10000','1','16777216'],text=True));assert s['result']==value,s
  s.update(arm=arm,pair=i,load=load);rows.append(s)
 (p/'div-one-prototype-results.json').write_text(json.dumps(dict(changes=changes,rows=rows),indent=2)+'\n')
for arm in ('old','patch'):
 a=[s['elapsedNanoseconds'] for s in rows if s['arm']==arm];print(arm,statistics.mean(a),statistics.stdev(a),statistics.median(a),min(a),max(a),flush=True)
