import pathlib,struct,json,subprocess,statistics
p=pathlib.Path(__file__).resolve().parent;data=bytearray((p/'cpa.bin').read_bytes());changes=[]
# sum-string occupies [0,268); its caller supplies x7 and its ASCII
# path never calls C. Preserve caller context reloads outside this function.
for j in range(0,268,4):
 if struct.unpack_from('<I',data,j)[0]==0xf9403fe7:
  struct.pack_into('<I',data,j,0xd503201f);changes.append(j)
assert changes, 'no context reload found'
(p/'cpa-patch.bin').write_bytes(data);print('changes',changes,flush=True);rows=[]
for i in range(30):
 for arm in (('old','patch') if i%2==0 else ('patch','old')):
  load=float(subprocess.check_output(['sysctl','-n','vm.loadavg'],text=True).split()[1]);assert load<=4,load
  f=p/('cpa.bin' if arm=='old' else 'cpa-patch.bin')
  s=json.loads(subprocess.check_output([str(p.parent/'runner'),'raw',str(f),'268','aarch64','0','500','1','16777216'],text=True));assert s['result']==1045000,s
  s.update(arm=arm,pair=i,load=load);rows.append(s)
 (p/'cpa-prototype-results.json').write_text(json.dumps(dict(changes=changes,rows=rows),indent=2)+'\n')
for arm in ('old','patch'):
 a=[s['elapsedNanoseconds'] for s in rows if s['arm']==arm];print(arm,statistics.mean(a),statistics.median(a),min(a),max(a),flush=True)
