.text
.p2align 2
.p2align 2
.globl _sdiv2
_sdiv2:
mov x1,x0
mov x2,#10000
mov x4,#0
mov x5,#0x7f2d
movk x5,#0x4c95,lsl #16
movk x5,#0xf42d,lsl #32
movk x5,#0x5851,lsl #48
Lsdiv2:
mul x1,x1,x5
add x1,x1,#1
mov x17, #2
sdiv x3, x1, x17
eor x4,x4,x3
subs x2,x2,#1
b.ne Lsdiv2
mov x0,x4
ret
.p2align 2
.globl _edge_sdiv2
_edge_sdiv2:
mov x1,x0
mov x17, #2
sdiv x3, x1, x17
mov x0,x3
ret
.p2align 2
.globl _shift2
_shift2:
mov x1,x0
mov x2,#10000
mov x4,#0
mov x5,#0x7f2d
movk x5,#0x4c95,lsl #16
movk x5,#0xf42d,lsl #32
movk x5,#0x5851,lsl #48
Lshift2:
mul x1,x1,x5
add x1,x1,#1
asr x17, x1, #63
lsr x17, x17, #63
add x17, x1, x17
asr x3, x17, #1
eor x4,x4,x3
subs x2,x2,#1
b.ne Lshift2
mov x0,x4
ret
.p2align 2
.globl _edge_shift2
_edge_shift2:
mov x1,x0
asr x17, x1, #63
lsr x17, x17, #63
add x17, x1, x17
asr x3, x17, #1
mov x0,x3
ret
.p2align 2
.globl _sdiv3
_sdiv3:
mov x1,x0
mov x2,#10000
mov x4,#0
mov x5,#0x7f2d
movk x5,#0x4c95,lsl #16
movk x5,#0xf42d,lsl #32
movk x5,#0x5851,lsl #48
Lsdiv3:
mul x1,x1,x5
add x1,x1,#1
mov x17, #3
sdiv x3, x1, x17
eor x4,x4,x3
subs x2,x2,#1
b.ne Lsdiv3
mov x0,x4
ret
.p2align 2
.globl _edge_sdiv3
_edge_sdiv3:
mov x1,x0
mov x17, #3
sdiv x3, x1, x17
mov x0,x3
ret
.p2align 2
.globl _shift3
_shift3:
mov x1,x0
mov x2,#10000
mov x4,#0
mov x5,#0x7f2d
movk x5,#0x4c95,lsl #16
movk x5,#0xf42d,lsl #32
movk x5,#0x5851,lsl #48
Lshift3:
mul x1,x1,x5
add x1,x1,#1
mov x17, #0x5556
movk x17, #0x5555, lsl #16
movk x17, #0x5555, lsl #32
movk x17, #0x5555, lsl #48
smulh x3, x1, x17
add x3, x3, x1, lsr #63
eor x4,x4,x3
subs x2,x2,#1
b.ne Lshift3
mov x0,x4
ret
.p2align 2
.globl _edge_shift3
_edge_shift3:
mov x1,x0
mov x17, #0x5556
movk x17, #0x5555, lsl #16
movk x17, #0x5555, lsl #32
movk x17, #0x5555, lsl #48
smulh x3, x1, x17
add x3, x3, x1, lsr #63
mov x0,x3
ret
.p2align 2
.globl _sdiv32
_sdiv32:
mov x1,x0
mov x2,#10000
mov x4,#0
mov x5,#0x7f2d
movk x5,#0x4c95,lsl #16
movk x5,#0xf42d,lsl #32
movk x5,#0x5851,lsl #48
Lsdiv32:
mul x1,x1,x5
add x1,x1,#1
mov x17, #32
sdiv x3, x1, x17
eor x4,x4,x3
subs x2,x2,#1
b.ne Lsdiv32
mov x0,x4
ret
.p2align 2
.globl _edge_sdiv32
_edge_sdiv32:
mov x1,x0
mov x17, #32
sdiv x3, x1, x17
mov x0,x3
ret
.p2align 2
.globl _shift32
_shift32:
mov x1,x0
mov x2,#10000
mov x4,#0
mov x5,#0x7f2d
movk x5,#0x4c95,lsl #16
movk x5,#0xf42d,lsl #32
movk x5,#0x5851,lsl #48
Lshift32:
mul x1,x1,x5
add x1,x1,#1
asr x17, x1, #63
lsr x17, x17, #59
add x17, x1, x17
asr x3, x17, #5
eor x4,x4,x3
subs x2,x2,#1
b.ne Lshift32
mov x0,x4
ret
.p2align 2
.globl _edge_shift32
_edge_shift32:
mov x1,x0
asr x17, x1, #63
lsr x17, x17, #59
add x17, x1, x17
asr x3, x17, #5
mov x0,x3
ret
