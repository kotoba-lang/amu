from pathlib import Path
import json,hashlib,tarfile,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-same-local-read-20261006');p=Path('/private/tmp/amu-same-local-read-permanent-20261006');u=Path('/private/tmp/amu-same-local-read-unit-20261006');i=Path('/private/tmp/amu-same-local-read-integrated-20261006');a=Path('/private/tmp/amu-same-local-read-integrated-20261006-parity');out=r/'docs/evidence/coscientist-same-local-read-20261006';out.mkdir(parents=True)
for name in ['summary.json','next-hypothesis.json','timing-artifact-audit.json','permanent-summary.json','gate-summary.json','integrated-summary.json','per-case-output-audit.json','pair-instruction-audit.json','permanent-prefix-audit.json']:shutil.copyfile(w/name,out/name)
# Copy authoritative permanent source/generated expectations for replay; all
# original expected cases have already been compared before changing the golden.
snapshot=w/'committed-source';snapshot.mkdir()
for name in ['seed/41-a64gen.kotoba','scripts/seed/a64gen-fixtures.py','seed/tests/unit/41-a64gen_t.kotoba','seed/tests/unit/41-a64gen.expected','seed/tests/unit/41-a64gen.fixtures.json']:
 dst=snapshot/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/name,dst)
assert (r/'seed/41-a64gen.kotoba').read_bytes()==(w/'41-a64gen-prototype.kotoba').read_bytes()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def archive(name,roots,exclude):
 target=out/name
 with tarfile.open(target,'w:gz') as tar:
  for root,label in roots:
   for f in sorted(root.rglob('*')):
    if not f.is_file() or '__pycache__' in f.parts or exclude(root,f):continue
    tar.add(f,arcname=label+'/'+str(f.relative_to(root)),recursive=False)
 print('ARCHIVE',name,target.stat().st_size,sha(target),flush=True)
archive('native-proof.tgz',[(w,'same-local-read'),(p,'permanent'),(u,'normal-unit')],lambda root,f:root==w and ('remote-evidence' in f.relative_to(root).parts or 'timing-package' in f.relative_to(root).parts))
archive('timing.tgz',[(w/'remote-evidence','remote-timing')],lambda root,f:False)
archive('integrated-proof.tgz',[(i,'integrated'),(a,'parity')],lambda root,f:False)
for name,required in [('native-proof.tgz',['same-local-read/41-a64gen-prototype.kotoba','same-local-read/pair-proof.json','permanent/permanent-regression-proof.json','same-local-read/gate-summary.json','same-local-read/committed-source/seed/41-a64gen.kotoba']),('timing.tgz',['remote-timing/timing-package/matmult-int/timing/results.json','remote-timing/timing-package/matmult-int/baseline/matmult-int/c.dylib']),('integrated-proof.tgz',['integrated/g3/amu','integrated/inputs.sha256','integrated/objects3.sha','parity/check.tsv','parity/compile.tsv','parity/exports.tsv'])]:
 with tarfile.open(out/name,'r:gz') as tar:
  names=set(tar.getnames())
  for item in required:assert item in names,(name,item)
  if name=='integrated-proof.tgz':
   images=[tar.extractfile('integrated/g'+str(g)+'/amu').read() for g in [1,2,3]];assert images[0]==images[1]==images[2]
checks=[sha(f)+'  '+f.name for f in sorted(out.iterdir()) if f.name!='checksums.sha256'];(out/'checksums.sha256').write_text('\n'.join(checks)+'\n');print('PASS all full archives and critical lineage/receipt members verified',flush=True)
