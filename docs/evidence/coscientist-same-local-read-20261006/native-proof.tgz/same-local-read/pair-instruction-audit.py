from pathlib import Path
import struct,json,hashlib
w=Path('/private/tmp/amu-same-local-read-20261006');b=Path('/private/tmp/amu-affine-read-direct-20261006');p=Path('/private/tmp/amu-high-loop-cache-20261006');rows=[]
for e in json.loads((w/'ports-correctness.json').read_text())['entries']:
 name=e['workload'];old=b/'ports-2'/name/'native.bin';new=w/'ports-2'/name/'native.bin';prev=p/'ports-2'/name/'native.bin';data=new.read_bytes();changed=data!=old.read_bytes();assert changed==(name=='matmult-int');rows.append({'workload':name,'changed':changed,'baselineSha256':hashlib.sha256(old.read_bytes()).hexdigest(),'candidateSha256':hashlib.sha256(data).hexdigest(),'baselineBytes':old.stat().st_size,'candidateBytes':len(data)})
 if changed:
  assert data!=prev.read_bytes();words=struct.unpack('<'+'I'*(len(data)//4),data);ob=json.loads((b/'instruction-audit.json').read_text())['unchangedOriginalFn5Prologue'];off=ob['offset']//4;orig=tuple(int(v,16) for v in ob['words']);assert words[off:off+12]==orig[:12] and words[off+12]==0xd2800005 and words[off+13:off+16]==orig[12:15]
  sites=[]
  for j in json.loads((b/'instruction-audit.json').read_text())['sites']:
   patt=tuple(int(v,16) for v in j['words']);matches=[i for i in range(len(words)-len(patt)) if words[i:i+len(patt)]==patt];assert len(matches)==1
   i=matches[0]+3;d=j['destinationRegister'];ctx=False
   if d==14:
    assert words[i]==0xf9405fe7;ctx=True;i+=1
    assert words[i]==0xb4000065 and words[i+2]==0x540001a0 and words[i+18]==0xf8617880+d;kind='first-read-original-dynamic-key-check'
   else:
    assert words[i:i+4]==(0xeb03003f,0x54000043,0,0xf8617880+d);kind='dominated-same-local-index-check-and-fresh-load-only'
   sites.append({'nativeByteOffset':i*4,'kind':kind,'originalSite':j['site'],'retainedOriginalContextLoadBeforeCheck':ctx,'words':[hex(v) for v in words[i:i+(19 if d==14 else 4)]]})
  (w/'pair-instruction-audit.json').write_text(json.dumps({'status':'complete-native-original-frame-and-dominated-pair-template-proof','sourceFrameBytes':192,'sourceAllocatedLocals':5,'originalFirst12FrameAndParamWordsEqual':True,'dynamicKeyInitializationOnlyPrologueAddition':True,'originalFuelWordsEqualAfterInsertion':True,'distinctFromProductAndRejectedMachine':True,'sites':sites},indent=2)+'\n')
(w/'code-change.json').write_text(json.dumps(rows,indent=2)+'\n');print('PASS original19 only matmult changed; original frame/params/fuel, first19word guard and second4word checked fresh-read')
