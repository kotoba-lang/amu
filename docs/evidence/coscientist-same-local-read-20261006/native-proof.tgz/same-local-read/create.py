from pathlib import Path
import json,hashlib,shutil,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-same-local-read-20261006');b=Path('/private/tmp/amu-affine-read-direct-20261006');p=Path('/private/tmp/amu-high-loop-cache-20261006');g=(p/'41-a64gen-prototype.kotoba').read_text();(w/'baseline-41-a64gen.kotoba').write_text((r/'seed/41-a64gen.kotoba').read_text())
(w/'hypothesis.json').write_text(json.dumps({'status':'registered-before-native-build-and-timing','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'baselineSeedSha256':hashlib.sha256((b/'seed-4.bin').read_bytes()).hexdigest(),'hypothesis':'Retain the bounded original-nonleaf dynamic descriptor guard on the first read, then prove a later affine read has the same stable source-local on the same straight-line path and reuse descriptor without key comparison.','priorRegistration':json.loads((r/'docs/evidence/coscientist-identity-and-reuse-20261006/next-hypothesis.json').read_text()),'differenceFromRejected':'Only later proven same-local read omits dynamic-key comparison. First read still uses dynamic positive/equal-handle guard; labels/calls/unknown ops reset compile-time witness. Runtime clears and nonleaf high-loop admission retained. Same scalar arithmetic cannot clobber x3/x4.','authoringException':'One-off new experimental Kotoba algorithm and independent hand fixtures, no mechanical product rewrite. Product source unchanged pending semantics/performance/gates.','timingRule':'One prospective fresh30triple batch per changed originalguest; load<=4 idle>=90 RSD<=10 ratio>=1.05 gap>sumSD. No identical-machine retiming.','goal':'C-or-better all19 unchanged original aligned workloads, native selfhost; not officialscore.'},indent=2)+'\n')
needle='(def gn-f-vmode 8)';pos=g.index('\n',g.index(needle));g=g[:pos+1]+'(def gn-f-vslot 13) ; compile-time dominated stable-local descriptor witness\n'+g[pos+1:]
helpers=''';; Compile-time witness only. No added runtime state/branch. First read keeps
;; the dynamic validated-key path; later same-local straight-line read omits it.
;; Labels/branches/calls/unknown effects reset; coalesced local writes reset too.
(defn- gn-vdrop [M :vector-i64 s :i64] :vector-i64
 (if (and (> s 0) (= s (gn-g M gn-f-vslot))) (gn-gs M gn-f-vslot 0) M))
(defn- gn-vstep [M :vector-i64 op :i64 a :i64] :vector-i64
 (cond (or (= op OP-CONST) (= op OP-LGET)) M
       (and (= op OP-BIN) (< a BOP-F64-ADD)) M
       (= op OP-LSET) (gn-vdrop M a)
       :else (gn-gs M gn-f-vslot 0)))
(defn- gn-vpair [M :vector-i64 slot :i64 d :i64] :vector-i64
 (let [active (= (gn-g M gn-f-vmode) 1)
       hit (and active (> slot 0) (= slot (gn-g M gn-f-vslot)))
       M1 (if hit
             (-> M (gn-emit (enc-cmp-r 1 3))
                   (gn-emit (enc-bcond (enc-cond-lo) 2)) (gn-emit (gn-e-udf))
                   (gn-emit (gn-e-ldrr d 4 1 1)))
             (gn-vread M 0 1 d))]
  (gn-gs M1 gn-f-vslot (if active slot 0))))

'''
pos=g.index(';; ---- register assignment');g=g[:pos]+helpers+g[pos:]
needle='(defn- gn-fin [M :vector-i64 t :i64 s :i64 d :i64] :vector-i64\n';assert g.count(needle)==1;g=g.replace(needle,needle+' (gn-fin-quiet (gn-vdrop M s) t s d))\n(defn- gn-fin-quiet [M :vector-i64 t :i64 s :i64 d :i64] :vector-i64\n',1)
needle='(defn- gn-ins [M :vector-i64 i :i64 op :i64] :vector-i64\n';assert g.count(needle)==1;g=g.replace(needle,needle+' (gn-ins-quiet (gn-vstep M op (gn-sir M i IF-A)) i op))\n(defn- gn-ins-quiet [M :vector-i64 i :i64 op :i64] :vector-i64\n',1)
needle='(let [out (- t 2) s (gn-co M (+ i 6) out) d (gn-dreg M out s)';assert g.count(needle)==1;g=g.replace(needle,needle+'\n       slot (if (gn-isk M out gn-k-local) (gn-dv M out) 0)',1)
needle='(gn-ctx) (gn-vread 0 1 d) (gn-fin out s d)';assert g.count(needle)==1;g=g.replace(needle,'(gn-ctx) (gn-vpair slot d) (gn-fin out s d)',1)
(w/'41-a64gen-prototype.kotoba').write_text(g)
parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader'),('clobber-full-state-loader','clobber-full-state-loader')]:shutil.copy2(b/src,w/dst)
for n in ['build.py','check-ports.py','permanent-regression.py','ports-state.py','loop-proof.py','effect-proof.py','import-proof.py','resource-proof.py']:(w/n).write_text((p/n).read_text().replace('amu-high-loop-cache-20261006','amu-same-local-read-20261006'))
print('PASS same-local dominated read registered; original product baseline, state13 named; state14 unchanged')
