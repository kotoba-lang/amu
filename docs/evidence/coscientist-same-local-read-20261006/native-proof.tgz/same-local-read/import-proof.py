from pathlib import Path
import subprocess,re,os,json,struct
w=Path('/private/tmp/amu-same-local-read-20261006');scope={};s=(w/'loop-proof.py').read_text();exec(s[:s.index('env=dict(')],scope);m=scope['m'];r=scope['r'];target=scope['ids']['lc_leaf_2_1'];cs=[]
for t in [0,7]:
 name=f'lc_import_caller_{t}';body=[('FUEL',)]+[('CONST',j,11-3*j) for j in range(8)]+[('VEC',0,8),('LSET',4,0),('CONST',0,2),('LSET',7,0),('CONST',0,0),('LSET',8,0),('LABEL',name+'_loop'),('LGET',0,7),('BRZ',0,name+'_end'),('CONST',0,0),('CONST',1,0),('CONST',2,0),('CONST',3,0),('CONST',4,0),('CONST',5,0),('CONST',6,0),('LGET',7,4),('CONST',8,0),('RT','RT-VECTOR-AT',7,2),('LSET',9,7)]+[('CONST',j,100+j) for j in range(t)]+[('LGET',t,4),('LGET',t+1,2),('CALL','lc_leaf_2_1',t,2)]+[('BIN','BOP-ADD',j) for j in range(t-1,-1,-1)]+[('LSET',6,0),('LGET',0,4),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('LGET',1,9),('BIN','BOP-ADD',0),('LGET',1,6),('BIN','BOP-ADD',0),('LGET',1,8),('BIN','BOP-ADD',0),('LSET',8,0),('LGET',0,7),('CONST',1,1),('BIN','BOP-SUB',0),('LSET',7,0),('FUEL',),('BR',name+'_loop'),('LABEL',name+'_end'),('LGET',0,8),('LGET',1,3),('BIN','BOP-ADD',0),('RET',0)]
 m.fx(name,3,9,body);cs.append({'name':name,'t':t})
m.fx('lc_replacement',2,2,[('FUEL',),('CONST',0,1),('RT','RT-VECTOR-ALLOC',0,1),('CONST',0,77),('RET',0)]);replacement=len(m.FIX);ids={x[0]:j+1 for j,x in enumerate(m.FIX)};fresh=scope['text'](True);needle='(gn-run M0)';assert fresh.count(needle)==1
# Seal actual replacement signature too, independently of unused arguments.
fresh=fresh.replace(needle,f'(gn-run (t-put M0 (+ MM-FN-BASE (* {replacement} MM-FN-W) FF-PT0) TY-VEC))')
closedneedle=f'(gn-run (t-put M0 (+ MM-FN-BASE (* {replacement} MM-FN-W) FF-PT0) TY-VEC))';openreplacement=f'(gn-run-open (t-put M0 (+ MM-FN-BASE (* {replacement} MM-FN-W) FF-PT0) TY-VEC) {target} 1)'
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];images={};audits=[]
for label in ['baseline-open','candidate-open','candidate-closed']:
 test=fresh if label.endswith('closed') else fresh.replace(closedneedle,openreplacement);backend=(w/('baseline-41-a64gen.kotoba' if label.startswith('baseline') else '41-a64gen-prototype.kotoba')).read_text();src=w/(label+'-imports.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+backend+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+test)
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'-imports.kseed'))]),('extract',['extract-native',str(w/(label+'-imports.kseed')),'--symbol','main','--output',str(w/(label+'-imports.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-imports-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-400:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'-imports.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0;(w/(label+'-imports.stdout')).write_text(q.stdout);blob,fc=m.blob_from(q.stdout)
 if label=='candidate-open':
  for c in cs:
   f=ids[c['name']];end=fc[f+1];words=struct.unpack('<'+'I'*((end-fc[f])//4),blob[fc[f]:end]);assert words.count(0xb4000065)==2;assert words.count(0xd2800005)>=2;audits.append({**c,'cacheReadSites':2,'cacheClearInstructions':words.count(0xd2800005)})
 patched=bytearray(blob);struct.pack_into('<I',patched,fc[target],0x14000000|(((fc[replacement]-fc[target])//4)&0x3ffffff));bp=w/(label+'-linked.bin');bp.write_bytes(patched);images[label]=(bp,fc)
rows=[]
for c in cs:
 for index in [0,1,-1,8,m.MIN,m.MAX]:
  for fuel in [1,2,3,4,5,16777216]:
   obs={};allocated=min(2,fuel//2);items=[11-3*j for j in range(8)]+[0]*allocated;remaining=max(0,fuel-5);answer=235+2*sum(100+j for j in range(c['t']))
   for label,(bp,fc) in images.items():
    e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(bp),str(fc[ids[c['name']]]),'3','aarch64','-','0',str(index),'37'],env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
    if label.endswith('open'):
     assert (q.returncode==0)==(fuel>=5),(c,index,fuel,q.stdout)
     if fuel>=5:assert re.search(r':result '+str(answer)+r'(?:\s|})',q.stdout),(c,index,fuel,answer,q.stdout)
     assert f':remaining {remaining}' in q.stdout and f':vectors {{:capacity 4096 :used {1+allocated}}}' in q.stdout and f':vector-items {{:capacity 65536 :used {len(items)}}}' in q.stdout,(label,c,index,fuel,q.stdout)
     assert obs[label]['items']==['DIAG_VECTOR_ITEMS '+str(len(items))+' '+' '.join(map(str,items))]
   assert obs['baseline-open']==obs['candidate-open'];
   if fuel>=5:assert obs['candidate-open']!=obs['candidate-closed']
   rows.append({'caller':c['name'],'index':index,'fuel':fuel,'expectOpenResult':answer if fuel>=5 else None,'expectRemaining':remaining,'expectItems':items,**obs})
(w/'import-proof.json').write_text(json.dumps({'status':'complete-native-live-loop-cache-open-import-hand-state-parity','comparisons':len(rows),'instructionAudit':audits,'actualReplacement':'vector-i64/i64->i64; chargesfuel, allocates1, returns77; diagnosticallocatorclobbersx7','closedControlsDiffer':True,'runs':rows},indent=2)+'\n');print('PASS',len(rows),'live cache/open import comparisons')
