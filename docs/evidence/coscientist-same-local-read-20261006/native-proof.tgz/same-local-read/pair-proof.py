from pathlib import Path
import importlib.util,subprocess,os,re,json,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-same-local-read-20261006');sp=importlib.util.spec_from_file_location('fx',w/'permanent-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
base=list(m.FIX);m.fx('pair_clobber',7,7,[('FUEL',),('CONST',0,77),('RET',0)]);m.fx('pair_alloc',0,0,[('FUEL',),('CONST',0,1),('RT','RT-VECTOR-ALLOC',0,1),('CONST',0,77),('RET',0)])
values=[11-3*j for j in range(8)]+[99-3*j for j in range(8)];cases=[]
def read(t,slot,ixlocal):
 out=t-2
 return [('CONST',j,0) for j in range(out)]+[('LGET',out,slot),('CONST',t-1,0),('LGET',t,1),('CONST',t+1,20),('BIN','BOP-MUL',t),('LGET',t+1,ixlocal),('BIN','BOP-ADD',t),('BIN','BOP-ADD',t-1),('RT','RT-VECTOR-AT',out,2)]
for t in [7,8,17]:
 for mode in ['same','different','alias-source','write','reassign','co-result','co-bin','call','alloc','fuel','join']:
  name='pair_'+str(len(cases));loop=name+'_loop';body=[('FUEL',)]+[('CONST',j,values[j]) for j in range(8)]+[('VEC',0,8),('LSET',4,0)]+[('CONST',j,values[j+8]) for j in range(8)]+[('VEC',0,8),('LSET',5,0)]
  if mode=='alias-source':body += [('LGET',0,4),('LSET',5,0)]
  body += [('CONST',0,2),('LSET',9,0),('CONST',0,0),('LSET',10,0),('LABEL',loop)]
  if mode=='join':body += [('LGET',0,2),('BRZ',0,name+'_skip')]
  body += read(t,4,2)+[('LSET',4 if mode=='co-result' else 7,t-2)]
  if mode=='co-result':body += [('LGET',0,4),('LSET',7,0)]
  if mode=='join':body += [('BR',name+'_join'),('LABEL',name+'_skip'),('CONST',0,17),('LSET',7,0),('LABEL',name+'_join')]
  if mode=='write':body += [('LGET',0,4),('CONST',1,0),('CONST',2,77),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3)]
  if mode=='reassign':body += [('LGET',0,5),('LSET',4,0)]
  if mode=='co-bin':body += [('LGET',0,4),('CONST',1,1),('BIN','BOP-ADD',0),('LSET',4,0)]
  if mode=='call':body += [('LGET',0,4)]+[('CONST',j,v) for j,v in enumerate([99,98,1,0,1,66],1)]+[('CALL','pair_clobber',0,7)]
  if mode=='alloc':body += [('CALL','pair_alloc',0,0)]
  if mode=='fuel':body += [('FUEL',)]
  body += read(t+1,5 if mode in ['different','alias-source'] else 4,3)+[('LSET',8,t-1),('LGET',0,7),('LGET',1,8),('BIN','BOP-ADD',0),('LGET',1,10),('BIN','BOP-ADD',0),('LSET',10,0),('LGET',0,9),('CONST',1,1),('BIN','BOP-SUB',0),('LSET',9,0),('FUEL',),('BRNZ',0,loop),('LGET',0,10),('CONST',1,37),('BIN','BOP-ADD',0),('RET',0)]
  m.fx(name,3,10,body);cases.append({'name':name,'t':t,'mode':mode,'staticHitExpected':mode=='same'})
sentinel=next(f for f in base if f[0]=='ht_cold_control');m.FIX.append(('pair_sentinel',*sentinel[1:]));ids={x[0]:j+1 for j,x in enumerate(m.FIX)}
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];images={};chunks={};audit=[]
for label,gen,real in [('baseline-pair','baseline-41-a64gen.kotoba',True),('candidate-pair','41-a64gen-prototype.kotoba',True),('candidate-pair-test','41-a64gen-prototype.kotoba',False)]:
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/gen).read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real))
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-300:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0;(w/(label+'.stdout')).write_text(q.stdout);blob,fc=m.blob_from(q.stdout);bp=w/(label+'-fixture.bin');bp.write_bytes(blob);images[label]=(bp,fc);chunks[label]=(blob,fc)
 if label=='candidate-pair':
  for c in cases:
   f=ids[c['name']];ws=struct.unpack('<'+'I'*((fc[f+1]-fc[f])//4),blob[fc[f]:fc[f+1]]);guards=ws.count(0xb4000065);assert guards==(1 if c['staticHitExpected'] else 2),(c,guards)
   madds=[v for v in ws if (v&0xffe08000)==0x9b000000 and ((v>>10)&31)!=31];assert len(madds)==2,(c,madds)
   audit.append({**c,'dynamicGuardSites':guards,'affineReads':len(madds)})
a=chunks['candidate-pair-test'];b=chunks['candidate-pair'];assert a[1]==b[1] and a[0][:len(b[0])]==b[0] and not any(a[0][len(b[0]):]) and 0<=len(a[0])-len(b[0])<=7
(w/'pair-cases.json').write_text(json.dumps(cases,indent=2)+'\n');(w/'pair-ids.json').write_text(json.dumps(ids,indent=2)+'\n');rows=[]
for c in cases:
 for av,ix1,ix2 in [(0,0,7),(m.MIN,7,0),(m.MAX,0,0),(-1,8,0),(0,0,8),(123,-1,0),(m.MIN,0,-1),(m.MAX,7,7)]:
  b1=m.s64(ix1-m.s64(av*20));b2=m.s64(ix2-m.s64(av*20))
  for fuel in [1,2,3,4,5,6,16777216]:
   remaining=fuel;items=list(values);descs=[(0,8),(8,8)];h=1;other=1 if c['mode']=='alias-source' else 2;total=0;failed=False;answer=None
   def charge():
    global remaining,failed
    if remaining<1:remaining=0;failed=True;return False
    remaining-=1;return True
   def at(handle,ix):
    global failed
    if not 1<=handle<=len(descs):failed=True;return None
    off,n=descs[handle-1]
    if not 0<=ix<n:failed=True;return None
    return items[off+ix]
   if charge():
    for iteration in range(2):
     first=17 if c['mode']=='join' and b1==0 else at(h,ix1)
     if failed:break
     mode=c['mode']
     if mode=='co-result':h=first
     if mode=='write':items[descs[h-1][0]]=77
     if mode=='reassign':h=other
     if mode=='co-bin':h=m.s64(h+1)
     if mode in ['call','alloc','fuel']:
      if not charge():break
      if mode=='alloc':descs.append((len(items),1));items.append(0)
     second=at(other if mode in ['different','alias-source'] else h,ix2)
     if failed:break
     total=m.s64(total+first+second)
     if not charge():break
    if not failed:answer=m.s64(total+37)
   obs={}
   for label in ['baseline-pair','candidate-pair']:
    path,fc=images[label];e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
    q=subprocess.run([str(w/'clobber-full-state-loader'),str(path),str(fc[ids[c['name']]]),'3','aarch64','-',str(av),str(b1),str(b2)],env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
    assert (q.returncode==0)==(answer is not None),(label,c,av,b1,b2,fuel,answer,q.stdout,q.stderr[-150:])
    if answer is not None:assert re.search(r':result '+str(answer)+r'(?:\s|})',q.stdout),(label,c,fuel,answer,q.stdout)
    assert f':remaining {remaining}' in q.stdout and f':vectors {{:capacity 4096 :used {len(descs)}}}' in q.stdout and f':vector-items {{:capacity 65536 :used {len(items)}}}' in q.stdout,(label,c,fuel,q.stdout,remaining,descs,items)
    assert obs[label]['items']==['DIAG_VECTOR_ITEMS '+str(len(items))+' '+' '.join(map(str,items))],(label,c,fuel,items,q.stderr[-150:])
   assert obs['baseline-pair']==obs['candidate-pair'],(c,av,b1,b2,fuel,obs);rows.append({'case':c,'a':av,'firstIndex':ix1,'secondIndex':ix2,'fuel':fuel,'expected':answer,'expectedRemaining':remaining,'expectedItems':items,**obs})
 print('PASS native same-local pair hand-state',c['name'],c['mode'],flush=True)
(w/'pair-proof.json').write_text(json.dumps({'status':'complete-native-dominated-same-local-read-hand-oracle-real-test-layout-and-barrier-refusals','comparisons':len(rows),'cases':len(cases),'realTestCodeAndLiteralBytesEqual':True,'realTestFnOffsetsEqual':True,'testOnlyPaddingBytes':len(a[0])-len(b[0]),'instructionAudit':audit,'runs':rows},indent=2)+'\n');print('PASS',len(rows),'same-local pair full-state comparisons',flush=True)
