from pathlib import Path
import json,os,re,subprocess,importlib.util
w=Path('/private/tmp/amu-same-local-read-20261006');sp=importlib.util.spec_from_file_location('m',w/'permanent-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);ids=json.loads((w/'loop-ids.json').read_text());cases=json.loads((w/'loop-cases.json').read_text());images={label:(w/(label+'-fixture.bin'),m.blob_from((w/(label+'.stdout')).read_text())[1]) for label in ['baseline-loop','candidate-loop']};rows=[]
for c in cases:
 if c['mode'] not in ['alloc','conj-old','conj-new']:continue
 for budget,key,val in [('table','KEXE_VECTORS',2),('items','KEXE_VECTOR_ITEMS',9)]:
  fuel=16777216;remaining=fuel-(2 if c['mode']=='alloc' else 1);items=[11-3*j for j in range(8)]+[99]
  if budget=='table':items += [0] if c['mode']=='alloc' else [11-3*j for j in range(8)]+[99]+[0]*9
  obs={}
  for label,(path,fc) in images.items():
   env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');env[key]=str(val);env.pop('KEXE_COMMAND',None)
   q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(path),str(fc[ids[c['name']]]),'3','aarch64','-','0','0','37'],env=env,capture_output=True,text=True);assert q.returncode!=0 and f':remaining {remaining}' in q.stdout,(c,budget,q.stdout,q.stderr)
   assert re.search(r':vectors \{:capacity \d+ :used 2\}',q.stdout) and re.search(r':vector-items \{:capacity \d+ :used '+str(len(items))+r'\}',q.stdout),(c,budget,q.stdout)
   obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
   assert obs[label]['items']==['DIAG_VECTOR_ITEMS '+str(len(items))+' '+' '.join(map(str,items))],(c,budget,q.stderr)
  assert obs['baseline-loop']==obs['candidate-loop'];rows.append({'caller':c['name'],'mode':c['mode'],'budget':budget,'expectRemainingFuel':remaining,'expectItems':items,**obs})
(w/'resource-proof.json').write_text(json.dumps({'status':'complete-native-live-loop-cache-resource-exhaustion-partial-write-hand-oracle','comparisons':len(rows),'runs':rows},indent=2)+'\n');print('PASS',len(rows),'resource exhaustion/partial writes')
