#include "c-bridge.c"
#include <stdio.h>
int main(void){for(int n=1;n<=32;n++)if(!oracle_selfcheck(n,0,0,0,0,0,0,0)||bench(n,0,0,0,0,0,0,0)!=1)return 1;int count=0;for(int n=0;n<=32;n++){for(int f=0;f<446;f++){if(observe(n*1024+f,0,0,0,0,0,0,0)==INT64_MIN)return 2;count++;}if(observe(n*1024+540,0,0,0,0,0,0,0)==INT64_MIN)return 3;count++;}printf("PASS 32 original UD bodies/verifiers; %d initialized observations\n",count);return 0;}
