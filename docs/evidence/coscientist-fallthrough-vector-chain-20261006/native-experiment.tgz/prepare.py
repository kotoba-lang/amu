from pathlib import Path
import hashlib,json,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');b=Path('/private/tmp/amu-static-vector-chain-20261006');w=Path('/private/tmp/amu-fallthrough-vector-chain-20261006')
h=json.loads((b/'next-hypothesis.json').read_text());h.update(registration='before implementation/build/timing; baseline source 5114721849fbe4dc7d4775f54a00f9a65519b698',authoringException='One-off new control-flow proof algorithm; prototype only, no mechanical product refactor.');(w/'hypothesis.json').write_text(json.dumps(h,indent=2)+'\n')
g=(r/'seed/41-a64gen.kotoba').read_text();l=(r/'seed/42-layout.kotoba').read_text()
helper=''';; A unique owned label can retain a descriptor only on live fallthrough.
;; Scan the entire closed SIR, including other functions and backward edges.
;; Small-mode admission already excludes indirect/unknown control transfers.
(defn- gn-chain-no-incoming [M :vector-i64 j :i64 l :i64] :bool
 (if (>= j (vector-at M MM-SIR-N)) true
  (let [op (gn-op M j)]
   (if (or (and (= op OP-BR) (= (gn-sir M j IF-A) l))
           (and (or (= op OP-BRZ) (= op OP-BRNZ)) (= (gn-sir M j IF-B) l))) false
    (gn-chain-no-incoming M (inc j) l)))))
'''
a='(defn- gn-chain-step [M :vector-i64 i :i64 op :i64 a :i64]';assert g.count(a)==1;g=g.replace(a,helper+a)
a='  (cond (or (= op OP-CONST) (= op OP-LGET) (= op OP-FUEL)) M\n        (and (= op OP-BIN)';assert g.count(a)==1;g=g.replace(a,'''  (cond (or (= op OP-CONST) (= op OP-LGET) (= op OP-FUEL)) M
        (= op OP-LABEL) (if (and (= (gn-g M gn-f-dead) 0)
                                (= (gn-small-label M 1 a 0) i)
                                (gn-chain-no-incoming M 1 a)) M (gn-gs M gn-f-vslot 0))
        (and (= op OP-BIN)''')
(w/'41-a64gen-prototype.kotoba').write_text(g);(w/'42-layout-prototype.kotoba').write_text(l)
for n in ['41-a64gen','42-layout']:shutil.copy2(r/('seed/'+n+'.kotoba'),w/('baseline-'+n+'.kotoba'))
parts=[s.strip() for s in (r/'seed/MANIFEST').read_text().splitlines() if s.strip() and not s.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join(g if s=='seed/41-a64gen.kotoba' else l if s=='seed/42-layout.kotoba' else (r/s).read_text() for s in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader'),('full-state-loader','full-state-loader')]:shutil.copy2(b/src,w/dst)
for n in ['build.py','check-ports.py','ports-state.py','fixture-proof.py','scratch-proof.py','branch-proof.py','new-resource-proof.py','resource-proof.py']:
 s=(b/n).read_text().replace(str(b),str(w));
 if n=='check-ports.py':s=s.replace('/private/tmp/amu-small-tail-frame-20261006/ports-correctness.json',str(b/'ports-correctness.json'))
 (w/n).write_text(s)
(w/'source-pins.json').write_text(json.dumps({n:hashlib.sha256((w/n).read_bytes()).hexdigest() for n in ['41-a64gen-prototype.kotoba','42-layout-prototype.kotoba','baseline-41-a64gen.kotoba','baseline-42-layout.kotoba','seed-unity.kotoba']},indent=2)+'\n')
print('PASS registered new fallthrough-only prototype; product sources unchanged')
