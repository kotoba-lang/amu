from pathlib import Path
import json
w=Path('/private/tmp/amu-fallthrough-vector-chain-20261006');s=(w/'mutation-proof.py').read_text();at=s.index('text=m.kotoba(True)')
insert='''entryi=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-LABEL'] and x[1]==m.layout_tables()[1]['lv_w_entry']);entrylabel=sir[entryi-1][1]
foreign=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==fns['lv_sink'])+1
probe += f"""(defn- t-ft-state [M :vector-i64 dead :i64 witness :i64] :vector-i64
 (-> M (gn-gs gn-f-vmode 2) (gn-gs gn-f-dead dead) (gn-gs gn-f-vslot witness)))
(defn- t-ft-step [M :vector-i64 dead :i64 witness :i64 expected :i64] :bool
 (= (gn-g (gn-chain-step (t-ft-state M dead witness) {entryi} OP-LABEL {entrylabel}) gn-f-vslot) expected))
(defn- t-ft-incoming [M :vector-i64 op :i64] :bool
 (let [at (+ MM-SIR-BASE (* {foreign} MM-SIR-W))
       o (vector-at M at) a (vector-at M (+ at 1)) b (vector-at M (+ at 2))
       set (-> M (t-put at op) (t-put (+ at 1) {entrylabel}) (t-put (+ at 2) {entrylabel}))
       got (and (not (gn-chain-no-incoming set 1 {entrylabel})) (t-ft-step set 0 -1 0) (t-ft-step set 0 1 0))
       restore (-> set (t-put at o) (t-put (+ at 1) a) (t-put (+ at 2) b))] got))
(defn- t-ft-duplicate [M :vector-i64] :bool
 (let [at (+ MM-SIR-BASE (* {foreign} MM-SIR-W)) o (vector-at M at) a (vector-at M (+ at 1))
       set (-> M (t-put at OP-LABEL) (t-put (+ at 1) {entrylabel})) got (t-ft-step set 0 -1 0)
       restore (-> set (t-put at o) (t-put (+ at 1) a))] got))
(defn- t-ft-guards [M :vector-i64] :bool
 (and (gn-chain-no-incoming M 1 {entrylabel}) (t-ft-step M 0 -1 -1) (t-ft-step M 0 1 1)
      (t-ft-step M 1 -1 0) (t-ft-step M 1 1 0) (t-ft-step M 0 0 0)
      (t-ft-incoming M OP-BR) (t-ft-incoming M OP-BRZ) (t-ft-incoming M OP-BRNZ)
      (t-ft-duplicate M)
      (= (gn-g (gn-vdrop (t-ft-state M 0 -1) 1) gn-f-vslot) 0)
      (= (gn-g (gn-vdrop (t-ft-state M 0 1) 1) gn-f-vslot) 0)))
"""
'''
s=s[:at]+insert+s[at:];s=s.replace('(t-chain-guards M1) mask_shared','(t-chain-guards M1) (t-ft-guards M1) mask_shared');s=s.replace('mutation-probe','incoming-probe').replace('mutation-proof.json','incoming-proof.json').replace("w/('mutation-'+stage+'.log')", "w/('incoming-'+stage+'.log')");s=s.replace("'sourceFieldMutations':len(cases)","'newIncomingDeadDuplicateRootWitnessControls':12,'sourceFieldMutations':len(cases)")
exec(compile(s,str(w/'incoming-proof.py'),'exec'))
