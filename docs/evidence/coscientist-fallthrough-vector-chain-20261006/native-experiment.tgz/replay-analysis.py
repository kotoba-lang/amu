from pathlib import Path
import json,re,hashlib,runpy
w=Path(__file__).resolve().parent;load=lambda n:json.loads((w/n).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();count=0
for name,key,n in [('branch-proof.json','observations',240),('fallthrough-proof.json','observations',96),('ports-state.json','runs',209),('resource-proof.json','runs',38)]:
 x=load(name);assert x['comparisons']==n and len(x[key])==n
 for row in x[key]:
  assert row['baseline']==row['candidate']
  if name in ['branch-proof.json','fallthrough-proof.json']:
   a=row['candidate'];assert int(re.search(r':remaining (-?\d+)',a['report'])[1])==row['expectedRemaining'];assert list(map(int,a['items'][0].split()[2:]))==row['expectedItems'];want=row['expectedResult']
   assert a['exit']==(120 if want is None else 0)
   if want is not None:assert int(re.search(r':result (-?\d+)',a['report'])[1])==want
  if name=='fallthrough-proof.json':
   flag=row['flag'];fuel=row['fuel'];kind=row['variant'];charge=4+max(0,flag) if kind.startswith('loop') else 3;assert row['expectedRemaining']==max(0,fuel-charge);inp=[flag,0,-(1<<63),(1<<63)-1,-1,42,1];result=None
   if fuel>=charge:inp[0]+=1;result=inp[0]
   assert row['expectedResult']==result and row['expectedItems']==[13,17,19,23]+inp
 count+=n
assert count==583
x=load('adoption-permanent-proof.json');assert x['fixtures']==593 and x['runs']==25658 and len(x['observations'])==25658 and x['realTestCodeAndLiteralBytesEqual'] and x['realTestFnOffsetsEqual']
for n,h in load('source-pins.json').items():assert sha(w/n)==h
g=load('generations.json');assert len({x['sha256'] for x in g[1:]})==1
for x in g:assert sha(w/('seed-'+str(x['generation'])+'.bin'))==x['sha256']
assert sha(w/'measurement-runner')=='a1b8778cf9af255f66bba3e3cad20e3baadd9653e18defe429bfa179840665ac'
runpy.run_path(str(w/'replay-timing.py'));assert not load('timing-audit.json')['performanceAllowsFurtherAdoptionGates'];print('PASS extracted583 stored complete states, independent loop oracle,25658 native receipts, source/generation/runner pins and raw timing. Offline replay does not execute native code.')
