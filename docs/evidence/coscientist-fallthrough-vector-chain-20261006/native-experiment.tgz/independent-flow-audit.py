from pathlib import Path
import json,re,collections
w=Path('/private/tmp/amu-fallthrough-vector-chain-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');C={}
for n in ['seed/SIR','seed/HEADS','seed/MEMORY-MAP']:
 for m in re.finditer(r'\[:c (\S+) (-?\d+)',(r/n).read_text()):C[m[1]]=int(m[2])
rows=[];kept=[];killed=[]
for e in json.loads((w/'ports-correctness.json').read_text())['entries']:
 name=e['workload'];d=w/'observer/meta-ports'/name;lines=(d/'compile.log').read_text().splitlines();sir=[list(map(int,z.split()[1:])) for z in lines if z.startswith('SIR ')];cache={int(z.split()[1]):list(map(int,z.split()[2:])) for z in lines if z.startswith('CACHE ')};labels=collections.Counter(x[2] for x in sir if x[1]==C['OP-LABEL']);incoming=collections.defaultdict(list)
 for i,op,a,b,c in sir:
  if op==C['OP-BR']:incoming[a].append(i)
  if op in [C['OP-BRZ'],C['OP-BRNZ']]:incoming[b].append(i)
 count=0
 for i,op,a,b,c in sir:
  if op!=C['OP-LABEL'] or i not in cache:continue
  before_mode,before,after_mode,after=cache[i]
  if before_mode!=2:continue
  count+=1
  if incoming[a] or labels[a]!=1:assert after==0,(name,i,a,cache[i],incoming[a],labels[a]);killed.append({'workload':name,'sir':i,'label':a,'incoming':incoming[a]})
  elif after!=0:
   assert before==after and before!=0;(kept.append({'workload':name,'sir':i,'label':a,'beforeWitness':before,'afterWitness':after,'incoming':[]}))
 rows.append({'workload':name,'completeOriginalSirRecomputed':True,'closedMode2Labels':count})
assert kept # Original closed-mode2 functions may contain only entry labels; loop controls live in independent fixtures.
(w/'independent-flow-audit.json').write_text(json.dumps({'status':'complete-independent-entire-module-SIR-incoming-target-uniqueness-audit','retainedWitnessLabels':len(kept),'killedIncomingOrDuplicateLabels':len(killed),'retained':kept,'killed':killed,'rows':rows,'supplementaryAfterTimingPreflightSealed':True,'nativeCandidateUnchanged':True},indent=2)+'\n');print('PASS independent module-wide incoming/unique proof',len(kept),'retained labels;',len(killed),'incoming/duplicate labels kill witnesses')
