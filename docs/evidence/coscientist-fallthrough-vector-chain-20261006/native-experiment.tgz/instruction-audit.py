from pathlib import Path
import json,struct,collections
w=Path('/private/tmp/amu-fallthrough-vector-chain-20261006');b=Path('/private/tmp/amu-static-vector-chain-20261006');load=lambda p:json.loads(p.read_text());rows=[];private=[];public=[];mode2=[];witnesses=[];accesses=[];fuel=[0xf94004f0,0xf1000610,0x54000042,0xd4200000,0xf90004f0];charges=0
for e in load(w/'ports-correctness.json')['entries']:
 n=e['workload'];d=w/'observer/meta-ports'/n;a=load(d/'census.json');old=load(b/'observer/meta-ports'/n/'census.json');lines=(d/'compile.log').read_text().splitlines();raw=lambda root:[z for z in (root/'observer/meta-ports'/n/'compile.log').read_text().splitlines() if z.startswith('SIR ')];assert raw(w)==raw(b)
 for f,v in a['functions'].items():
  for k in ['start','end','frameBytes','locals','depth','localCalleeRegisters','leaf']:assert v[k]==old['functions'][f][k],(n,f,k)
 oa={v['sir']:v for v in old['events']};ints=lambda v:[int(z,16) for z in v['words']];word=list(struct.unpack('<'+'I'*((d/'native.bin').stat().st_size//4),(d/'native.bin').read_bytes()[:((d/'native.bin').stat().st_size//4)*4]))
 caches={int(z.split()[1]):list(map(int,z.split()[2:])) for z in lines if z.startswith('CACHE ')}
 for v in a['events']:
  p=oa[v['sir']]
  if v['op']=='OP-FUEL':assert v['words']==p['words']
  if ints(p)[:5]==fuel:assert ints(v)[:5]==fuel;(charges:=charges+1)
  if v['op']=='OP-FN' and caches[v['sir']][2]==2:
   f=a['functions'][str(v['fn'])];assert f['leaf']==2 and f['frameBytes']==0 and 1<=f['locals']<=3 and 1<=f['depth']<=3;assert word[f['codeWordStart']-1]==0xd2800005;mode2.append({'workload':n,'fn':v['fn'],'publicWord':f['codeWordStart']})
 tw={int(z.split()[1]):list(map(int,z.split()[2:])) for z in lines if z.startswith('TAILWIT ')}
 for z in lines:
  if not z.startswith('BASE '):continue
  at,slot,known,hit,conditional,rv=map(int,z.split()[1:]);assert hit==int(slot>0 and slot==known) and conditional==int(known==-1 and slot==1);off=0 if hit else 13 if conditional else 15
  if conditional:assert word[at-1]==0xb50001a5
  if not hit and not conditional:assert word[at-1]==0xb4000065 and word[at+1]&0xff00001f==0x54000000
  assert word[at+off-1]&0xffe0fc1f==0xeb00001f and (word[at+off-1]>>16)&31==3
  assert word[at+off]==0x54000043 and word[at+off+1]==0
  mem=word[at+off+2];assert ((mem>>5)&31)==4 and mem&0xffe00c00 in [0xf8600800,0xf8200800]
  accesses.append({'workload':n,'at':at,'slot':slot,'known':known,'hit':bool(hit),'conditional':bool(conditional),'boundsRemain':True})
 for line in lines:
  if not line.startswith('FIX '):continue
  k,at,kind,target,aux=map(int,line.split()[1:]);assert aux in [0,1]
  if kind!=4:assert aux==0;continue
  t=a['functions'][str(target)]['codeWordStart'];x=word[at-1];assert x&0x7c000000==0x14000000;imm=x&0x3ffffff;imm=imm-(1<<26) if imm&(1<<25) else imm;assert at+imm==t+aux,(n,k,at,target,aux,t,at+imm)
  if aux:
   wit=tw[k];assert wit[0]==target and wit[2]==1 and wit[3]>0 and wit[4]==3 and wit[5]==wit[3] and wit[6]==1,(n,k,wit);witnesses.append({'workload':n,'fix':k,'witness':wit})
   assert x&0xfc000000==0x14000000 and word[t-1]==0xd2800005;targetfn=a['functions'][str(target)];assert targetfn['leaf']==2 and targetfn['locals']<=3 and targetfn['depth']<=3;owner=next(z for z in a['events'] if z['firstWord']<=at<z['afterWord']);assert caches[owner['sir']][0]==2 and owner['op']=='OP-CALL';private.append({'workload':n,'fix':k,'at':at,'caller':owner['fn'],'target':target,'publicWord':t,'privateWord':t+1})
  else:public.append({'workload':n,'fix':k})
 rows.append({'workload':n,'originalSirExact':True,'originalFrameLocalDepthLeafExact':True,'fuelExact':True,'baselineWords':old['codeWords'],'candidateWords':a['codeWords'],'nativeByteExact':e['nativeSha256']==next(z['nativeSha256'] for z in load(b/'ports-correctness.json')['entries'] if z['workload']==n)})
assert private and mode2 and sum(z['nativeByteExact'] for z in rows)==18
same=False # Current593 fixture expectation parity checked separately; no old blob identity claim.
out={'status':'complete-native-all19-private-B-public-cold-marker-original-SIR-frame-fuel-audit','current593FixtureExpectationsVerifiedSeparately':True,'tailWitnesses':witnesses,'accessWitnesses':accesses,'staticUncheckedAccesses':sum(z['hit'] for z in accesses),'conditionalRootAccesses':sum(z['conditional'] for z in accesses),'privateTransfers':private,'publicCallTransfers':len(public),'mode2Functions':mode2,'originalFiveWordFuelPrefixesChecked':charges,'rows':rows,'staticCountsNotTimeShares':True}
(w/'instruction-audit.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',len(private),'private B transfers',len(mode2),'cold-entry functions',charges,'fuel prefixes; current593 expectations verified separately')
