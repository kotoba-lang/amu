from pathlib import Path
w=Path('/private/tmp/amu-fallthrough-vector-chain-20261006');o=w/'observer';p=o/'observer-41-a64gen.kotoba';g=p.read_text()
def out(prefix,fields):
 s='"\\n"'
 for x in reversed(fields):s=f'(string-concat (string-from-i64 {x}) (string-concat " " {s}))'
 return f'(io-out (string-concat "{prefix} " {s}))'
a='       conditional (and (= known -1) (= slot 1))';assert g.count(a)==1;g=g.replace(a,a+'\n       printed_base '+out('BASE',['(vector-at M MM-CODE-N)','slot','known','(if hit 1 0)','(if conditional 1 0)','rv']))
a='       M1 (gn-fix M FX-BL26 f) at';assert g.count(a)==1;g=g.replace(a,'       printed_tail '+out('TAILWIT',['(vector-at M MM-FIX-N)','f','t','n','(gn-g M gn-f-vslot)','(gn-dk M t)','(gn-dv M t)','(if private 1 0)'])+'\n'+a)
p.write_text(g);r=Path('/Users/junkawasaki/github/wt/amu-seed17');parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(o/'observer-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (w/'42-layout-prototype.kotoba').read_text() if x=='seed/42-layout.kotoba' else (r/x).read_text())+'\n' for x in parts));print('PASS read-only exact BASE/TAILWIT observations')
