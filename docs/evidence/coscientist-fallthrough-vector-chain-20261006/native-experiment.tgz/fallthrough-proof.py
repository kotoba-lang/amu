from pathlib import Path
import json,os,subprocess,re,hashlib
w=Path('/private/tmp/amu-fallthrough-vector-chain-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');ns={};exec((w/'fixture-proof.py').read_text().split('env=dict(')[0],ns);m=ns['m'];base_types=ns['typeform'];old=len(m.FIX)
read=[('LGET',0,1),('CONST',1,0),('RT','RT-VECTOR-AT',0,2)]
other=[('LGET',0,1),('CONST',1,6),('RT','RT-VECTOR-AT',0,2),('LSET',2,0)]
m.fx('sv_cold',1,2,[('FUEL',),('LGET',0,1),('CALL','lv_finish',0,1),('RET',0)])
variants=['loop_backedge','loop_dead','fallthrough_alias','fallthrough_other']
for kind in variants:
 body=[('FUEL',)]+read
 if kind.startswith('loop'):
  body += [('LSET',2,0),('LABEL','ft_'+kind+'_head'),('FUEL',)]+read+[('LGET',0,2),('CONST',1,0),('CMP','CC-GT',0),('BRZ',0,'ft_'+kind+'_exit')]
  body += [('LGET',0,1),('CONST',1,6),('RT','RT-VECTOR-AT',0,2),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('LGET',0,2),('CONST',1,1),('BIN','BOP-SUB',0),('LSET',2,0),('BR','ft_'+kind+'_head')]
  if kind=='loop_dead':body += [('LABEL','ft_dead_island'),('CONST',0,-1),('LSET',1,0),('TRAP',7)]
  body += [('LABEL','ft_'+kind+'_exit')]
 elif kind=='fallthrough_alias':body += [('LABEL','ft_alias_a'),('LGET',0,1),('LSET',1,0),('LABEL','ft_alias_b')]+read
 else:body += [('LGET',0,1),('CONST',1,6),('RT','RT-VECTOR-AT',0,2),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('LABEL','ft_other_a')]+read
 body += [('LGET',0,1),('CALL','lv_finish',0,1),('RET',0)];m.fx('sv_'+kind,1,2,body)
 driver=[('FUEL',),('CONST',0,13),('CONST',1,17),('CONST',2,19),('CONST',3,23),('VEC',0,4),('LSET',2,0),('LGET',0,1),('CONST',1,0),('CONST',2,m.MIN),('CONST',3,m.MAX),('CONST',4,-1),('CONST',5,42),('LGET',6,2),('VEC',0,7),('CALL','sv_'+kind,0,1),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('RET',0)];m.fx('sv_'+kind+'_driver',1,2,driver)
fns,labels,lits,sir,frec=m.layout_tables();types='(defn- t-sv-types [M :vector-i64] :vector-i64 (-> M '+' '.join('(t-put '+str(m.C['MM-FN-BASE']+fns[name]*m.C['MM-FN-W']+field)+' '+ty+')' for name,np,sl,dp,b in m.FIX[old:] for field,ty in [(m.C['FF-RTYPE'],'TY-I64' if name.endswith('_driver') else 'TY-VEC'),(m.C['FF-PT0'],'TY-I64' if name.endswith('_driver') else 'TY-VEC')])+'))\n'
parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');images={}
for arm in ['baseline','candidate']:
 g='baseline-41-a64gen.kotoba' if arm=='baseline' else '41-a64gen-prototype.kotoba';l='baseline-42-layout.kotoba' if arm=='baseline' else '42-layout-prototype.kotoba';src=w/(arm+'-branch.kotoba');text=m.kotoba(True).replace('(defn- seed-main [] :i64',base_types+types+'(defn- seed-main [] :i64').replace('        M1 (gn-run (t-small-types M0))','        M1 (gn-run (t-sv-types (t-lv-types (t-small-types M0))))');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/g).read_text()+'\n'+(w/l).read_text()+'\n'+text);ks=src.with_suffix('.kseed');exe=w/(arm+'-branch-generator.bin')
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(ks)]),('extract',['extract-native',str(ks),'--symbol','main','--output',str(exe)])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),(w/'seed-4.offset').read_text().strip(),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(arm+'-branch-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(stage,q.stdout,q.stderr)
 off=re.search(r':offset (\d+)',q.stdout)[1];q=subprocess.run([str(w/'kexe-loader'),str(exe),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0,q.stderr;(w/(arm+'-branch.stdout')).write_text(q.stdout);blob,offs=m.blob_from(q.stdout);p=w/(arm+'-branch.bin');p.write_bytes(blob);images[arm]=(p,offs)
rows=[]
for kind in variants:
 for flag in [-1,0,1,3]:
  for fuel in [1,2,3,4,5,2**53-1]:
   otheritems=[13,17,19,23];inp=[flag,0,m.MIN,m.MAX,-1,42,1];charge=4+max(0,flag) if kind.startswith('loop') else 3;remaining=max(0,fuel-charge);result=None
   if fuel>=charge and kind!='invalid_root':
    target=inp;target[0]=((target[0]+1+(1<<63))%(1<<64))-(1<<63);result=target[0]
   expected=otheritems+inp;obs={}
   for arm,(image,offs) in images.items():
    ev=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');ev.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'full-state-loader'),str(image),str(offs[fns['sv_'+kind+'_driver']]),'1','aarch64','-',str(flag)],env=ev,capture_output=True,text=True);a={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)};assert int(re.search(r':remaining (-?\d+)',a['report'])[1])==remaining,(kind,flag,fuel,a,remaining);assert list(map(int,a['items'][0].split()[2:]))==expected,(kind,flag,fuel,a,expected)
    if result is None:assert a['exit']==120,(kind,flag,fuel,a)
    else:assert a['exit']==0 and int(re.search(r':result (-?\d+)',a['report'])[1])==result,(kind,flag,fuel,a,result)
    obs[arm]=a
   assert obs['baseline']==obs['candidate'];rows.append({'variant':kind,'flag':flag,'fuel':fuel,'expectedResult':result,'expectedRemaining':remaining,'expectedItems':expected,**obs})
 print('PASS branch/root/cold witness independent model',kind,flush=True)
(w/'fallthrough-proof.json').write_text(json.dumps({'status':'complete-native-diamond-alias-root-invalid-cold-chain-full-state-oracles','comparisons':len(rows),'newFixtures':len(m.FIX)-old,'observations':rows},indent=2)+'\n');print('PASS',len(rows),'independent branch/cold/root comparisons',flush=True)
