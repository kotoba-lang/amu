"""Abstract contracts only; not a compiler correctness proof."""
from pathlib import Path
import json,itertools
import z3 as z
W=Path(__file__).resolve().parent
r,x,y=z.BitVecs('root x y',64);p,q=z.Bools('left_fact right_fact');choose=z.Bool('choose');length=z.Function('length',z.BitVecSort(64),z.IntSort());mem=z.Array('memory',z.IntSort(),z.IntSort());i,value=z.Ints('index value');L=z.Select(mem,0)
laws=[
 ('meet-retains-only-common-identity',z.And(z.Implies(p,x==r),z.Implies(q,y==r),p,q),z.If(choose,x,y)==r),
 ('identity-preserves-length',x==r,length(x)==length(r)),
 ('admitted-element-store-preserves-header',z.And(i>=0,i<L,L>=0,L<=2**60),z.Select(z.Store(mem,i+1,value),0)==L),
 ('root-passed-to-normal-identity-callee',z.And(x==r,y==x),y==r),
 ('descending-summary-cannot-resurrect',z.BoolVal(True),z.Implies(z.And(p,q),p))]
unsafe=[
 ('union-at-diamond-is-unsound',z.And(p,z.Not(q),x==r,y!=r,z.Not(choose)),z.If(choose,x,y)==r),
 ('returning-other-alias-is-unsound',z.And(x!=r,length(x)==length(r)),x==r),
 ('unbounded-negative-index-can-hit-header',z.And(i==-1,value!=L),z.Select(z.Store(mem,i+1,value),0)==L)]
rows=[]
for kind,items,expected in [('law',laws,'unsat'),('negative-control',unsafe,'sat')]:
 for name,pre,claim in items:
  s=z.Solver();s.add(pre,z.Not(claim));got=str(s.check());assert got==expected,(name,got)
  rows.append({'name':name,'kind':kind,'result':got,'counterexample':str(s.model()) if got=='sat' else None})
# Enumerate all three-function directed call graphs, seeds, and initial schedules.
# A false local summary propagates through all callers; compare global-set closure.
passed=bad=0
for bits in range(512):
 edges={(a,b) for a in range(3) for b in range(3) if bits&(1<<(3*a+b))}
 for invalid in range(8):
  local=[not (invalid&(1<<a)) for a in range(3)];want=local[:]
  while True:
   new=[want[a] and all(want[b] for aa,b in edges if aa==a) for a in range(3)]
   if new==want:break
   want=new
  for order in itertools.permutations(range(3)):
   for requeue in [True,False]:
    state=local[:];queue=list(order);pops=0
    while queue:
     a=queue.pop(0);pops+=1;new=state[a] and all(state[b] for aa,b in edges if aa==a)
     if new!=state[a]:
      state[a]=new
      if requeue:
       for aa,b in sorted(edges):
        if b==a and aa not in queue:queue.append(aa)
    if requeue:assert state==want and pops<=3+len(edges);passed+=1
    elif state!=want:bad+=1
assert bad>0
out={'status':'PASS abstract laws and exhaustive dependency schedule model','solverVersion':z.get_version_string(),'checks':rows,'correctSchedules':passed,'noRequeueCounterexamples':bad,'nodes':3,'graphs':512,'generalCompilerOrTerminationProof':False,'TLCOrTLAPSRun':False}
(W/'laws-proof.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
