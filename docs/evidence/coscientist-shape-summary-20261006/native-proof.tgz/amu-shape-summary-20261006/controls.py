from pathlib import Path
import json,os,re,subprocess
from verify import C,O,parse,infer
W=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17');functions=[]
def fn(name,np,body,want): functions.append((name,np,body,want))
# Independent expected facts are hand-authored before native execution.
fn('caller-before-bad-callee',2,[('LGET',0,1),('LGET',1,2),('CALL',2,0,2),('RET',0)],(1,0))
fn('returns-second-parameter',2,[('LGET',0,2),('RET',0)],(1,0))
fn('identity',1,[('LGET',0,1),('RET',0)],(1,1))
fn('copy-local',1,[('LGET',0,1),('LSET',2,0),('LGET',0,2),('RET',0)],(1,1))
fn('diamond-other-parameter',2,[('LGET',0,1),('CONST',1,0),('BRZ',1,1),('LGET',0,2),('BR',2),('LABEL',1),('LABEL',2),('RET',0)],(1,0))
fn('diamond-both-root',1,[('LGET',0,1),('CONST',1,0),('BRZ',1,3),('LGET',0,1),('BR',4),('LABEL',3),('LABEL',4),('RET',0)],(1,1))
fn('self-recursive-base',1,[('LGET',0,1),('CONST',1,0),('BRZ',1,5),('CALL',7,0,1),('LABEL',5),('RET',0)],(1,1))
fn('mutual-left',1,[('LGET',0,1),('CONST',1,0),('BRZ',1,6),('CALL',9,0,1),('LABEL',6),('RET',0)],(1,1))
fn('mutual-right',1,[('LGET',0,1),('CALL',8,0,1),('RET',0)],(1,1))
fn('bad-SCC-left',2,[('LGET',0,1),('LGET',1,2),('CALL',11,0,2),('RET',0)],(1,0))
fn('bad-SCC-right',2,[('LGET',0,1),('LGET',1,2),('CONST',2,0),('BRZ',2,7),('CALL',10,0,2),('RET',0),('LABEL',7),('LGET',0,2),('RET',0)],(1,0))
fn('read-is-scalar',1,[('LGET',0,1),('CONST',1,0),('RT',176,0,2),('RET',0)],(1,0))
fn('in-place-return-root',1,[('LGET',0,1),('CONST',1,0),('CONST',2,3),('RT',208,0,3),('RET',0)],(1,1))
fn('in-place-return-other',2,[('LGET',0,2),('CONST',1,0),('CONST',2,3),('RT',208,0,3),('RET',0)],(1,0))
fn('allocation-refusal',1,[('LGET',0,1),('RT',200,0,1),('RET',0)],(0,0))
fn('capability-refusal',1,[('LGET',0,1),('CAP',1,0,0),('RET',0)],(0,0))
fn('indirect-refusal',1,[('LGET',0,1),('CALLI',0,0,0),('RET',0)],(0,0))
fn('unknown-refusal',1,[('LGET',0,1),(999,0,0,0),('RET',0)],(0,0))
fn('foreign-label-refusal',1,[('LGET',0,1),('BR',3),('RET',0)],(1,0))
fn('duplicate-label-refusal',1,[('LGET',0,1),('BR',8),('LABEL',8),('LABEL',8),('RET',0)],(1,0))
fn('closed-caller-capability-refusal',1,[('LGET',0,1),('CALL',16,0,1),('RET',0)],(0,0))
fn('closed-SCC-left',1,[('LGET',0,1),('CALL',23,0,1),('RET',0)],(0,0))
fn('closed-SCC-right-cap',1,[('LGET',0,1),('CALL',22,0,1),('CAP',1,0,0),('RET',0)],(0,0))
fn('call-identity-root',1,[('LGET',0,1),('CALL',3,0,1),('RET',0)],(1,1))
fn('call-identity-other',2,[('LGET',0,2),('CALL',3,0,1),('RET',0)],(1,0))
fn('zero-parameter',0,[('CONST',0,4),('RET',0)],(1,0))
fn('wrong-call-arity',1,[('LGET',0,1),('CALL',3,0,0),('RET',0)],(0,0))
fn('reachable-end',1,[('LGET',0,1)],(1,0))
fn('unreachable-alloc-conservative',1,[('LGET',0,1),('RET',0),('RT',200,0,1)],(0,0))
fn('backedge-root',1,[('LGET',0,1),('LABEL',9),('CONST',1,0),('BRNZ',1,9),('RET',0)],(1,1))
fn('backedge-overwrites-root',2,[('LGET',0,1),('LABEL',10),('CONST',1,0),('BRZ',1,11),('LGET',0,2),('BR',10),('LABEL',11),('RET',0)],(1,0))
words=[];writes=[(C['MM-SIR-N'],1),(C['MM-FN-N'],len(functions)+1)];pos=1
for f,(name,np,body,want) in enumerate(functions,1):
 b=C['MM-FN-BASE']+f*C['MM-FN-W']
 for field,val in [('FF-SIR',pos),('FF-NPARAMS',np),('FF-NSLOTS',max(np,2)),('FF-DEPTH',3),('FF-RTYPE',4),('FF-PT0',4)]:writes.append((b+C[field],val))
 ins=[(O('FN'),f,np,max(np,2))]+[(O(x[0]) if isinstance(x[0],str) else x[0],*(tuple(x[1:])+(0,)*(4-len(x)))) for x in body]+[(O('END'),f,0,0)]
 for row in ins:
  for k,v in enumerate(row):writes.append((C['MM-SIR-BASE']+pos*C['MM-SIR-W']+k,v))
  pos+=1
writes.append((C['MM-SIR-N'],pos))
load=[]
for group in range(0,len(writes),20):
 chunk=writes[group:group+20];n=group//20;load.append('(defn- t-sh-load%d [M0 :vector-i64] :vector-i64 (let [%s] M%d))'%(n,' '.join('M%d (mem-set M%d %d %d)'%(i+1,i,a,v) for i,(a,v) in enumerate(chunk)),len(chunk)))
expr='(vector-alloc MM-WORDS)'
for n in range((len(writes)+19)//20):expr='(t-sh-load%d %s)'%(n,expr)
entry='\n'.join(load)+'\n(defn- seed-main [] :i64 (let [M '+expr+' sir (sh-sir M 1) meta (sh-meta M 1) report (sh-report M)] 0))\n'
base='\n'.join((R/p).read_text() for p in ['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'])+'\n'+(W/'baseline-41-a64gen.kotoba').read_text()+'\n'
shape=(W/'shape-native.kotoba').read_text();mutants={
 'correct':shape,
 'no-dependent-requeue':shape.replace('(sh-callers M f1 E (vector-at E (+ 16 f)) (vector-at M MM-SIR-N))','f1'),
 'unsafe-join-union':shape.replace('(bit-and old_l locals)','(bit-or old_l locals)').replace('(bit-and old_t temps)','(bit-or old_t temps)'),
 'wrong-in-place-root':shape.replace('(if (= a RT-VECTOR-ASSOC-IN-PLACE) (sh-bit temps b) 0)','(if (= a RT-VECTOR-ASSOC-IN-PLACE) 1 0)'),
 'zero-budget':shape.replace('(* 128 (- end p))','0')}
(W/'control-expectations.json').write_text(json.dumps([{'f':f,'name':name,'expected':want} for f,(name,np,body,want) in enumerate(functions,1)],indent=2)+'\n')
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[]
for name,code in mutants.items():
 d=W/'controls'/name;d.mkdir(parents=True,exist_ok=True);src=d/'probe.kotoba';src.write_text(base+code+'\n'+entry)
 for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(d/'probe.kseed')]),('extract',['extract-native',str(d/'probe.kseed'),'--symbol','main','--output',str(d/'probe.bin')])]:
  q=subprocess.run([str(W/'observer/kexe-loader'),str(W/'observer/seed-0.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,label,q.stdout[-500:],q.stderr)
  if label=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(W/'observer/kexe-loader'),str(d/'probe.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(d/'stdout').write_text(q.stdout+q.stderr);assert q.returncode==0,(name,q.stderr)
 s,m,got,end=parse(d/'stdout');want,counts=infer(s,m);expected={f:tuple(x[3]) for f,x in enumerate(functions,1)};assert want==expected,(name,[(f,want[f],expected[f]) for f in want if want[f]!=expected[f]])
 mismatches=[{'f':f,'name':functions[f-1][0],'native':got[f],'expected':want[f]} for f in got if got[f]!=want[f]]
 if name=='correct':assert not mismatches
 else:assert mismatches,(name,'mutation not detected')
 if name=='zero-budget':assert all(not id for cl,id in got.values())
 rows.append({'variant':name,'nativeRunExit':q.returncode,'groups':len(got),'mismatches':mismatches,'expectedOutcome':'PASS' if name=='correct' else 'DETECTED'});print(name,len(mismatches),'differences',flush=True)
(W/'controls-proof.json').write_text(json.dumps({'status':'PASS correct native summaries and four actual native source mutants detected','rows':rows},indent=2)+'\n')
