from pathlib import Path
import json,hashlib,shutil,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path(__file__).resolve().parent;b=Path('/private/tmp/amu-static-vector-chain-20261006');o=w/'observer';o.mkdir(exist_ok=True);s=(w/'shape-native.kotoba').read_text();s=s.replace(' (> np 0) (<= np 5) (> ns 0)', ' (>= np 0) (<= np 5) (>= ns 0)');s=s.replace('id (and valid (<= ns 16)', 'id (and valid (> np 0) (<= ns 16)');s=s.replace('(>= b 0) (> c 0) (<= (+ b c) dp) (= c (gn-fnf M a FF-NPARAMS))','(>= b 0) (>= c 0) (<= (+ b (gn-max c 1)) dp) (= c (gn-fnf M a FF-NPARAMS))');(w/'shape-native.kotoba').write_text(s)
g=(r/'seed/41-a64gen.kotoba').read_text();assert g==(b/'41-a64gen-prototype.kotoba').read_text()
def out(prefix,fields):
 text='"\\n"'
 for x in reversed(fields):text=f'(string-concat (string-from-i64 {x}) (string-concat " " {text}))'
 return f'(io-out (string-concat "{prefix} " {text}))'
# Print original source IR and type records, while keeping M/G untouched.
s+='''\n(defn- sh-meta [M :vector-i64 f :i64] :i64
 (if (>= f (vector-at M MM-FN-N)) 0
  (let [printed '''+out('META',['f','(gn-fnf M f FF-SIR)','(gn-fnf M f FF-NPARAMS)','(gn-fnf M f FF-NSLOTS)','(gn-fnf M f FF-DEPTH)','(gn-fnf M f FF-RTYPE)','(gn-fnf M f FF-PT0)'])+'''] (sh-meta M (inc f)))))
(defn- sh-sir [M :vector-i64 i :i64] :i64
 (if (>= i (vector-at M MM-SIR-N)) 0
  (let [printed '''+out('SIR',['i','(gn-op M i)','(gn-sir M i IF-A)','(gn-sir M i IF-B)','(gn-sir M i IF-C)'])+'''] (sh-sir M (inc i)))))
''';s=s.replace(';; Diagnostic only.',';; Diagnostic only.',1);(w/'shape-native.kotoba').write_text(s)
anchor='(defn- gn-run-open [';assert g.count(anchor)==1;g=g.replace(anchor,s+'\n'+anchor)
a='        M1 (mem-alloc M0 (+ gn-a-lp MM-LABEL-CAP 2))';assert g.count(a)==1;g=g.replace(a,'        print_sir (sh-sir M0 1)\n        print_meta (sh-meta M0 1)\n        print_shape (sh-report M0)\n'+a)
(o/'observer-41-a64gen.kotoba').write_text(g);parts=[p.strip() for p in (r/'seed/MANIFEST').read_text().splitlines() if p.strip() and not p.lstrip().startswith('#')];(o/'observer-unity.kotoba').write_text('\n'.join(g if p=='seed/41-a64gen.kotoba' else (r/p).read_text() for p in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader')]:shutil.copy2(b/src,o/dst)
(o/'observe.py').write_text((b/'observer/observe.py').read_text().replace(str(b),str(w)))
# Product comparison is independently preserved, not an assumed receipt.
shutil.copy2(b/'ports-correctness.json',w/'ports-correctness.json');shutil.copy2(b/'41-a64gen-prototype.kotoba',w/'baseline-41-a64gen.kotoba');shutil.copy2(b/'42-layout-prototype.kotoba',w/'42-layout.kotoba')
h=json.loads((r/'docs/evidence/coscientist-closed-chain-fuel-20261006/next-hypothesis.json').read_text());h.update(status='registered-before-native-analysis',sourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),scope='Native diagnostic closed-operation and normal-return-parameter0 identity summaries. Fixed length specialization not implemented.',authoringException='One-off new diagnostic algorithm and independent test schemas; excluded from product, not mechanical product refactor.',sourcePins={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [w/'shape-native.kotoba',o/'observer-41-a64gen.kotoba',o/'observer-unity.kotoba',w/'baseline-41-a64gen.kotoba']});(w/'hypothesis.json').write_text(json.dumps(h,indent=2)+'\n');print('PASS new native bounded CFG and reverse-call-worklist summary prepared')
