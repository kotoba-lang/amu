from pathlib import Path
import json,hashlib,subprocess,re,sys,struct
P=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,h in load(P/'selected-payload-pins.json').items():assert sha(P/name)==h,name
I=P/'implementation';before=load(I/'machine-audit.json');q=subprocess.run([sys.executable,str(I/'machine-audit.py')],capture_output=True,text=True);assert q.returncode==0,q.stderr;assert load(I/'machine-audit.json')==before
fixed=load(I/'fixed-point.json');assert len(fixed['generations'])==4
for g in fixed['generations'][1:]:assert sha(I/f"seed-{g['generation']}.bin")==g['sha256']=='ed0d49bb05c65c56cc28c263f5c66d75ccb330f1e52235e3ff127ddaefc8b2be'
for name,h in load(I/'source-pins.json').items():assert sha(I/name)==h
pc=load(P/'root-proof/ports-semantic.json');assert len(pc['entries'])==19 and pc['matrixExecutions']==95
ordinary=0
for e in pc['entries']:
 d=I/'ports'/e['workload'];assert sha(d/'native.bin')==e['nativeSha256'];assert sha(P/'original19-source'/(e['workload']+'.kotoba'))==e['sourceSha256']
 assert len(e['runs'])==5 and e['fuelTrapReturncode']!=0
 for obs in e['runs']:
  raw=load(P/'root-proof/ports-semantic-raw'/e['workload']/f"n-{obs['n']}.stdout");assert raw['result']==obs['result'] and raw['contextFuelConsumed']==obs['fuelConsumed'] and obs['exit']==0
  assert not (P/'root-proof/ports-semantic-raw'/e['workload']/f"n-{obs['n']}.stderr").read_text()
 ordinary+=len(e['runs'])
source=P/'original19-source/crc32.kotoba';line=next(x for x in source.read_text().splitlines() if x.startswith('(defn- table-at'));table=sum((list(map(int,x.split())) for x in re.findall(r'\[([\d\s]+)\]',line)),[]);assert len(table)==256

def ieee(c,b):
 v=(c^(b&255))&0xffffffff
 for _ in range(8):v=(v>>1)^(0xedb88320 if v&1 else 0)
 return v
assert all(v==ieee(0,i) for i,v in enumerate(table))
native=load(I/'native-controls/report.json');assert len(native['instructionValues'])==native['instructionBasisCases']==45
assert (I/'native-controls/instruction.bin').read_bytes()==struct.pack('<II',0x1ac14000,0xd65f03c0)
for r in native['instructionValues']:
 assert r['result']==ieee(r['crc'],r['byte']) and r['receipt']['exit']==0
 assert int(re.search(r':result (-?\d+)',r['receipt']['stdout'])[1])==r['result']
assert native['originalProductPairs']==len(native['originalPairs'])==220
for r in native['originalPairs']:
 z=r['outcome'];assert set(z)=={'exit','stdout','stderr'}
 if z['exit']==0:assert ':status :ok' in z['stdout']
assert len(native['sourceMutants'])==4
for r in native['sourceMutants']:
 d=I/'native-controls'/r['mutant'];assert sha(d/'unity.kotoba')==r['sourceSha256'] and sha(d/'compiler.bin')==r['compilerSha256'] and sha(d/'guest.bin')==r['guestSha256'];assert r['baseline']!=r['mutantOutcome'] and r['status'].startswith('DETECTED')
core=load(I/'typed-controls/core-report.json');cap=load(I/'typed-controls/flow-cap-report.json');prep=load(I/'typed-controls/preparation.json');typed=0
for r in core['entries']+[cap['receipt']]:
 case=r['case'];d=I/'typed-controls'/case;assert sha(I/'typed-controls'/(case+'.kotoba'))==r['sourceSha256'];assert sha(d/'baseline.bin')==r['baselineSha256'] and sha(d/'candidate.bin')==r['candidateSha256'];assert (d/'candidate.bin').read_bytes()==(d/'observer.bin').read_bytes();assert r['offsets']['candidate']==r['offsets']['observer']
 admits=[list(map(int,z.split()[1:])) for z in (d/'observer-compile.log').read_text().splitlines() if z.startswith('CRPRE ')];assert admits==r['admissions']
 if case in prep['expectedAdmissions']:assert len(admits)==prep['expectedAdmissions'][case]
 if not admits:assert r['baselineSha256']==r['candidateSha256'] and r['offsets']['baseline']==r['offsets']['candidate']
 for pair in r['pairs']:
  for ext in ['stdout','stderr']:
   assert (d/f"baseline-n{pair['n']}-f{pair['fuel']}.{ext}").read_bytes()==(d/f"candidate-n{pair['n']}-f{pair['fuel']}.{ext}").read_bytes()
  typed+=1
assert core['pairs']==288 and typed==336
fallback=load(I/'disabled/parity.json');assert len(fallback['entries'])==19
laws=load(P/'root-laws/report.json');assert sha(source)==laws['sourceSha256'];assert len(laws['queries'])==5 and all(r['actual']==r['expected'] for r in laws['queries'])
for r in laws['queries']:assert (P/'root-laws'/(r['query']+'.smt2')).is_file()
g=load(P/'team-adoption-gates/report.json');assert g['status'].startswith('PASS') and g['goldenChanges']==0
actual=P/'team-adoption-gates/unit-actual/stdout';assert sha(actual)==g['formalUnit']['stdoutSha256']==g['formalUnit']['trackedGoldenSha256'];assert actual.read_bytes()==(P/'team-adoption-gates/41-a64gen.expected').read_bytes();assert len(actual.read_text().splitlines())==5227;assert sha(P/'team-adoption-gates/unit-actual/unit.bin')==g['formalUnit']['unitProgramSha256'];assert sha(P/'team-adoption-gates/unit-generated-blob.bin')==g['formalUnit']['generatedCodeBlobSha256']
assert len(g['requiredGates'])==7
for n in ['measured-host-feature-receipt.json','launch-feature-receipt.json']:
 receipt=load(P/'admission'/n);assert all(z['exit']==0 and z['stdout'].strip().split()[-1]=='1' for z in receipt['features'])
out={'status':'PASS fresh isolated retained-evidence offline replay','machineWorkloads':len(before['rows']),'machineFaultsDetected':len(before['controls']),'ordinaryNativeObservationsRetained':ordinary,'fuelTrapsRetained':19,'typedPairedRawStatesRecompared':typed,'actualInstructionValuesRecomputed':45,'originalExportOutcomeReceiptsRetained':220,'sourceMutantMismatchControlsVerified':4,'tableValuesRecomputed':256,'solverQueriesRetainedNotRerun':5,'formalUnitPassLines':5227,'requiredGatesRetained':7,'nativeExecutions':0,'timingRuns':0,'solverRuns':0,'automaticFeatureAdmission':False,'productAdopted':False,'universalCompilerProof':False,'boundary':'Retained proof receipts, full machine projection + raw machine corrupt controls, typed output pair comparison and finite source/math recomputation; not fresh native execution or fresh SMT solving.'}
print(json.dumps(out,indent=2))
