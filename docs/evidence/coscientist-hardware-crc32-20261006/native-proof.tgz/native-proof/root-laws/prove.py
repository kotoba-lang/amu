from pathlib import Path
import re,json,hashlib
import z3
D=Path(__file__).resolve().parent
src=Path('/Users/junkawasaki/github/wt/amu-seed17/bench/embench/batch-ports/crc32.kotoba')
line=next(x for x in src.read_text().splitlines() if x.startswith('(defn- table-at'))
values=sum((list(map(int,x.split())) for x in re.findall(r'\[([\d\s]+)\]',line)),[])
assert len(values)==256
c=z3.BitVec('accumulator',64); b=z3.BitVec('octet_input',64)
t=z3.K(z3.BitVecSort(8),z3.BitVecVal(0,64))
for i,v in enumerate(values):t=z3.Store(t,z3.BitVecVal(i,8),z3.BitVecVal(v,64))
idx=z3.Extract(7,0,c^b)
old=z3.LShR(c,8)^z3.Select(t,idx)
u32=z3.ULT(c,z3.BitVecVal(1<<32,64))
def recurrence(poly):
 x=z3.Extract(31,0,c)^z3.ZeroExt(24,z3.Extract(7,0,b))
 for _ in range(8):x=z3.LShR(x,1)^z3.If(z3.Extract(0,0,x)==1,z3.BitVecVal(poly,32),z3.BitVecVal(0,32))
 return z3.ZeroExt(32,x)
hw=recurrence(0xedb88320)
queries=[('u32-ieee-table-equivalence', [u32,old!=hw],'unsat'),('upper-i64-required-control',[z3.Not(u32),old!=hw],'sat'),('castagnoli-wrong-polynomial-control',[u32,old!=recurrence(0x82f63b78)],'sat'),('table-mutation-control',[u32,c==0,b==0,(old^z3.BitVecVal(1,64))!=hw],'sat'),('u32-result-closure',[u32,z3.Not(z3.ULT(hw,z3.BitVecVal(1<<32,64)))],'unsat')]
rows=[]
for name,assertions,want in queries:
 s=z3.Solver();s.set(timeout=30000);s.add(*assertions);(D/(name+'.smt2')).write_text(s.to_smt2())
 got=str(s.check());row={'query':name,'expected':want,'actual':got}
 if got=='sat':row['counterexample']={'accumulator':s.model().eval(c,model_completion=True).as_long(),'octet_input':s.model().eval(b,model_completion=True).as_long()}
 assert got==want,row
 rows.append(row)
report={'status':'PASS stated-assumption full bitvector CRC value laws','source':str(src),'sourceSha256':hashlib.sha256(src.read_bytes()).hexdigest(),'tableEntries':256,'solver':z3.get_version_string(),'queries':rows,'instructionEncodingVerified':False,'nativeExecutions':0,'timings':0,'limits':'CRC32B modeled by eight reflected IEEE polynomial steps; official ISA/pseudocode binding, native encoding, fuel/trap/ABI, rewrite u32 certificates and target guards remain separate obligations. No universal optimizer proof.'}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(D.iterdir()) if p.is_file()};pins[str(src)]=report['sourceSha256'];(D/'artifact-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
