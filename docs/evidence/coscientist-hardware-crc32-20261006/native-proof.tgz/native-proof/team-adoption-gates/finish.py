from pathlib import Path
import json,hashlib,tarfile
D=Path(__file__).resolve().parent;I=D.parent/'implementation';S=D/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());U=D/'unit-build/unit/41-a64gen';old=Path('/private/tmp/amu-scalar-dag-inline-20261006/root-proof/unit-build/unit/41-a64gen/stdout');expected=S/'seed/tests/unit/41-a64gen.expected';actual=U/'stdout'
def blob_from(stdout):
 words=[];lits=[];fns={};end=None
 for line in stdout.splitlines():
  p=line.split()
  if not p:continue
  if p[0]=='w':words += [int(x,16) for x in p[1:]]
  elif p[0]=='lit':lits.append((int(p[1]),bytes.fromhex(p[2]) if len(p)>2 else b''))
  elif p[0]=='fn':fns[int(p[1])]=int(p[2])
  elif p[0]=='end':end=int(p[1])
 assert end is not None
 blob=bytearray(b''.join(w.to_bytes(4,'little') for w in words));assert end>=len(blob);blob+=b'\0'*(end-len(blob))
 for off,bs in lits:blob[off:off+len(bs)]=bs
 return bytes(blob),fns
ex=load(D/'execution-status.json');summary=load(D/'initial-summary.json');a=actual.read_bytes();e=expected.read_bytes();o=old.read_bytes();unitEqual=a==e==o;lines=len(a.decode().splitlines());b,f=blob_from(a.decode());ob,of=blob_from(o.decode());eb,ef=blob_from(e.decode());blobEqual=b==ob==eb and f==of==ef
(D/'unit-generated-blob.bin').write_bytes(b);(D/'unit-generated-offsets.json').write_text(json.dumps(f,indent=2)+'\n')
rows=[l.split('\t') for l in (D/'gate-build/gates/r6m/summary.tsv').read_text().splitlines()];gatesEqual=set(r[0] for r in rows)=={'BUILD','ERR','G1','G2','G3','G4','G5'} and all(r[1]=='PASS' for r in rows)
# Every tracked source archive file is preserved except the candidate source41.
archive=[]
with tarfile.open(D/'source-44bf.tar') as t:
 for m in t.getmembers():
  if not m.isfile():continue
  original=t.extractfile(m).read();p=S/m.name
  baseline=hashlib.sha256(original).hexdigest();after=sha(p)
  if m.name=='seed/41-a64gen.kotoba':assert after==sha(I/'41-a64gen-prototype.kotoba')
  else:assert after==baseline,('unexpected tracked source mutation',m.name)
  archive.append({'path':m.name,'originalSha256':baseline,'currentSha256':after,'overlay':m.name=='seed/41-a64gen.kotoba'})
(D/'archive-source-bindings.json').write_text(json.dumps(archive,indent=2)+'\n')
# Inspect exact compiler normalized source and native lineage; no stage0 substitution.
parts=[x.strip() for x in (S/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];formal=''.join((S/p).read_text()+'\n' for p in parts);joined='\n'.join((S/p).read_text() for p in parts)
assert (D/'gate-build/seed-unity.kotoba').read_text()==formal and (I/'unity.kotoba').read_text()==joined
assert (D/'gate-build/verified-unity.bin').read_bytes()==(I/'seed-4.bin').read_bytes()
for rel,h in load(I/'source-pins.json').items():assert sha(I/rel)==h
for rel,h in load(I/'artifact-pins.json')['pins'].items():assert sha(I/rel)==h
passAll=unitEqual and lines==5227 and blobEqual and gatesEqual and len(ex)==4 and all(r['status']==0 for r in ex)
report={'status':('PASS' if passAll else 'FAIL')+' terminal first-run CRC formal5227 and all7 BUILD ERR G1-G5 gates','writesComplete':True,'candidateSeedSha256':sha(I/'seed-4.bin'),'candidateBytes':(I/'seed-4.bin').stat().st_size,'sourceLineage':load(D/'source-lineage.json'),'fullArchiveTrackedSourceFiles':len(archive),'onlyTrackedOverlay':'seed/41-a64gen.kotoba','sourceUnityNormalization':'Same exact per-module bytes/order; formal concatenation adds one LF after each module; own candidate joins modules with LF. Independent formal unity emits identical native ed0 compiler.','formalUnit':{'module':'41-a64gen','status':summary['unitStatus'],'lines':lines,'stdoutBytes':len(a),'stdoutSha256':sha(actual),'trackedGoldenSha256':sha(expected),'previousAdoptedActualSha256':sha(old),'fullRawGoldenAndPreviousByteIdentical':unitEqual,'unitProgramSha256':sha(U/'unit.bin'),'unitProgramOffset':int((U/'unit.offset').read_text()),'generatedCodeBlobSha256':sha(D/'unit-generated-blob.bin'),'generatedCodeBytes':len(b),'generatedFunctions':len(f),'allGeneratedCodePoolAndOffsetsExactPrevious':blobEqual},'requiredGates':rows,'firstRunRawReceipts':ex,'setupFailures':0,'realOracleFailures':0 if passAll else 1,'reruns':0,'goldenChanges':0,'original19MatrixOwner':'root; no duplicate95 execution','fuelBoundary':'Product completed return with remaining0 is success. Formal/current loader is used; earlier diagnostic remaining0-as-trap receipts are not substituted.','limits':['Native generations2/3/4 map to formal gatecompiler0/1/2; gatecompiler0 is not stage0.','G2 result65/66 and1pre-existing front-end refusal is not universal acceptance parity.','Formal G1 uses single-iteration ports, separate from measured batch19 provenance.','Gate durations/kexe-benchmark numbers are validation diagnostics, not fresh performance evidence.','No SSH/M4 execution, timing campaign, expected/source/product updates, adoption or C-or-better claim.']}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
pins={str(p.relative_to(D)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(D.rglob('*')) if p.is_file() and p.name!='artifact-pins.json' and '__pycache__' not in p.parts};(D/'artifact-pins.json').write_text(json.dumps(pins,indent=2)+'\n');print(json.dumps({'status':report['status'],'reportSha256':sha(D/'report.json'),'artifactPinsSha256':sha(D/'artifact-pins.json'),'pinCount':len(pins),'unitBlobBytes':len(b),'unitFunctionCount':len(f)},indent=2));assert passAll,'Initial oracle mismatch retained; no golden changes.'
