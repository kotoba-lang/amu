from pathlib import Path
import subprocess,json,os,re,hashlib,tarfile,shutil
D=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17');I=D.parent/'implementation';S=D/'source';S.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
q=subprocess.run(['git','-C',str(R),'archive','44bfaa28ccb70252bf763e20de5321ced848f0e4','seed','scripts/seed','tools/kexe_loader.c','bench/runtime-comparison/kexe-benchmark.c','bench/embench/ports'],capture_output=True);assert q.returncode==0,q.stderr;(D/'source-44bf.tar').write_bytes(q.stdout)
with tarfile.open(D/'source-44bf.tar') as t:t.extractall(S,filter='data')
assert (S/'seed/41-a64gen.kotoba').read_bytes()==(I/'source-snapshot/seed/41-a64gen.kotoba').read_bytes();(S/'seed/41-a64gen.kotoba').write_bytes((I/'41-a64gen-prototype.kotoba').read_bytes())
parts=[x.strip() for x in (S/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];GB=D/'gate-build';UB=D/'unit-build';GB.mkdir(exist_ok=True);UB.mkdir(exist_ok=True);unity=GB/'seed-unity.kotoba';unity.write_text(''.join((S/p).read_text()+'\n' for p in parts));h=sha(unity)
common=dict(os.environ,SEED_REPO=str(S),SEED_RESOURCES_35=str(S)+':/private/tmp',SEED_PORTS=str(S/'bench/embench/ports'),SEED_PAIRS='16777216',SEED_VECTORS='65536',SEED_VECTOR_ITEMS='134217728',SEED_SECONDS='1800')
# Native compiler lineage independently checked against the exact snapshot.
env=dict(common,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(S)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
receipts=[]
def execute(label,args,env):
 p=subprocess.run(args,env=env,capture_output=True,text=True);(D/(label+'.stdout')).write_text(p.stdout);(D/(label+'.stderr')).write_text(p.stderr);r={'label':label,'argv':args,'status':p.returncode,'stdout':str(D/(label+'.stdout')),'stderr':str(D/(label+'.stderr'))};receipts.append(r);(D/'execution-status.json').write_text(json.dumps(receipts,indent=2)+'\n');return p
for stage,args in [('unity-compile',['compile',str(unity),'--target','aarch64-macos','--output',str(GB/'verified-unity.kseed')]),('unity-extract',['extract-native',str(GB/'verified-unity.kseed'),'--symbol','main','--output',str(GB/'verified-unity.bin')])]:
 p=execute(stage,[str(I/'kexe-loader'),str(I/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env);assert p.returncode==0,(stage,p.stdout,p.stderr)
assert (GB/'verified-unity.bin').read_bytes()==(I/'seed-4.bin').read_bytes()
for B in [GB,UB]:shutil.copy2(I/'kexe-loader',B/'kexe-loader')
for k,g in enumerate([2,3,4]):
 for ext in ['bin','offset']:shutil.copy2(I/f'seed-{g}.{ext}',GB/f'seed-{k}.{ext}')
 (GB/f'seed-{k}.info').write_text(f'label LINEAGE native-generation-{g}; isolated candidate snapshot unity reproduced exactly; no stage0\nunity-sha256 {h}\nseed-sha256 {sha(I/f"seed-{g}.bin")}\n')
(GB/'seed-unity.kotoba.sha256').write_text(h+'\n')
(D/'source-lineage.json').write_text(json.dumps({'sourceCommit':'44bfaa28ccb70252bf763e20de5321ced848f0e4','sourceArchiveSha256':sha(D/'source-44bf.tar'),'soleCandidateOverlay':'seed/41-a64gen.kotoba','source41Sha256':sha(S/'seed/41-a64gen.kotoba'),'candidateSourcePins':json.loads((I/'source-pins.json').read_text()),'unitySha256':h,'independentUnityEmitsExactSeed':sha(GB/'verified-unity.bin'),'correctSingleIterationG1Ports':str(S/'bench/embench/ports'),'notMeasuredBatchPorts':True,'goldenUnchanged':True},indent=2)+'\n')
u=execute('unit-first',['zsh',str(S/'scripts/seed/unit.sh'),'41-a64gen'],dict(common,SEED_BUILD=str(UB),SEED_UNIT_SEED=str(I/'seed-4.bin')));print('unit-first status',u.returncode,flush=True)
g=execute('gates-first',['zsh',str(S/'scripts/seed/gates.sh'),'--rung','r6m','--no-build','--only','BUILD,ERR,G1,G2,G3,G4,G5'],dict(common,SEED_BUILD=str(GB)));print('gates-first status',g.returncode,flush=True)
(D/'initial-summary.json').write_text(json.dumps({'unitStatus':u.returncode,'gatesStatus':g.returncode,'unitStdout':u.stdout,'gatesStdout':g.stdout,'noExpectedChanges':True},indent=2)+'\n')
