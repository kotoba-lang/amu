from pathlib import Path
import subprocess,os,re,json,hashlib,struct
I=Path(__file__).resolve().parent;D=I/'native-controls';D.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();loader=I/'kexe-loader';env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35='/Users/junkawasaki/github/wt/amu-seed17:/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
def command(seed,args,path):
 q=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);path.write_text(q.stdout+q.stderr);assert q.returncode==0,(args,q.stdout[-1000:],q.stderr[-700:]);return q.stdout

def execute(binary,off,args,fuel=1048576):
 e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
 q=subprocess.run([str(loader),str(binary),str(off),str(len(args)),'aarch64','-',*map(str,args)],env=e,capture_output=True,text=True)
 return {'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}

def ieee(c,b):
 v=(c^(b&255))&0xffffffff
 for k in range(8):v=(v>>1)^(0xedb88320 if v&1 else 0)
 return v
# Actual officially-bound CRC instruction, no timing harness.
(D/'instruction.bin').write_bytes(struct.pack('<II',0x1ac14000,0xd65f03c0));basis=[(0,0)]+[(1<<k,0) for k in range(32)]+[(0,1<<k) for k in range(8)];extra=[(0xffffffff,-1),(0x12345678,-4294967301),(0,9223372036854775807),(0xffffffff,-9223372036854775808)];actual=[]
for c,b in basis+extra:
 v=execute(D/'instruction.bin',0,[c,b]);assert v['exit']==0;result=int(re.search(r':result (-?\d+)',v['stdout'])[1]);assert result==ieee(c,b),(c,b,result);actual.append({'crc':c,'byte':b,'result':result,'receipt':v})
(D/'castagnoli.bin').write_bytes(struct.pack('<II',0x1ac15000,0xd65f03c0));wrong=execute(D/'castagnoli.bin',0,[0,1]);assert int(re.search(r':result (-?\d+)',wrong['stdout'])[1])!=ieee(0,1)
# Product-loader original exports: return with remaining0 is successful.
B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation');exports={};pairs=[]
for symbol,values in [('bench',[0,1,2]),('prefix-crc',[0,1,2,3,17,255,1024]),('prefix-seed',[0,1,17,1024]),('table-entry',[-1,0,1,255,256,1099511627776])]:
 offsets={}
 for label,seed,image in [('baseline',I/'seed-0.bin',B/'ports/crc32/image.kseed'),('candidate',I/'seed-4.bin',I/'ports/crc32/image.kseed')]:
  out=command(seed,['extract-native',str(image),'--symbol',symbol,'--output',str(D/(label+'-'+symbol+'.bin'))],D/(label+'-'+symbol+'-extract.log'));offsets[label]=int(re.search(r':offset (\d+)',out)[1])
 for n in values:
  for fuel in [1,2,3,4,7,16,513,2050,2051,2052,1048576]:
   old=execute(D/('baseline-'+symbol+'.bin'),offsets['baseline'],[n],fuel);new=execute(D/('candidate-'+symbol+'.bin'),offsets['candidate'],[n],fuel)
   assert old==new,(symbol,n,fuel,old,new);pairs.append({'symbol':symbol,'n':n,'fuel':fuel,'outcome':new})
 exports[symbol]=offsets
# Actual compiler-source controls, each preserved in its own immutable directory.
mutants=[('unsafe-u32','(cr-u32-at M i acc)','true','wide-phi',1),('unsafe-table','(cr-lit-ok M (gn-sir M (+ j 3) IF-B) lo hi)','true','wrong-table',440),('omitted-charge','(gn-mask-charge (gn-emit m1 (enc-ldr 8 7 CTX-FUEL)))','(gn-emit m1 (enc-ldr 8 7 CTX-FUEL))','positive',1),('wrong-poly','(gn-emit 0x1ac14000)','(gn-emit 0x1ac15000)','positive',1)]
mutation_results=[]
for name,before,after,case,n in mutants:
 d=D/name;d.mkdir(exist_ok=True);unity=(I/'unity.kotoba').read_text();assert unity.count(before)==1;unity=unity.replace(before,after);(d/'unity.kotoba').write_text(unity)
 command(I/'seed-0.bin',['compile',str(d/'unity.kotoba'),'--target','aarch64-macos','--output',str(d/'compiler.kseed')],d/'compiler-compile.log')
 out=command(I/'seed-0.bin',['extract-native',str(d/'compiler.kseed'),'--symbol','main','--output',str(d/'compiler.bin')],d/'compiler-extract.log');assert int(re.search(r':offset (\d+)',out)[1])==0
 source=I/'typed-controls'/(case+'.kotoba');command(d/'compiler.bin',['compile',str(source),'--target','aarch64-macos','--output',str(d/'guest.kseed')],d/'guest-compile.log')
 out=command(d/'compiler.bin',['extract-native',str(d/'guest.kseed'),'--symbol','run','--output',str(d/'guest.bin')],d/'guest-extract.log');off=int(re.search(r':offset (\d+)',out)[1]);base=json.loads((I/'typed-controls/report.json').read_text());rec=next(x for x in base['entries'] if x['case']==case)
 old=execute(I/'typed-controls'/case/'baseline.bin',rec['offsets']['baseline'],[n]);new=execute(d/'guest.bin',off,[n]);assert old!=new,(name,'mutant undetected',old,new)
 mutation_results.append({'mutant':name,'sourceSha256':sha(d/'unity.kotoba'),'compilerSha256':sha(d/'compiler.bin'),'guestSha256':sha(d/'guest.bin'),'case':case,'input':n,'baseline':old,'mutantOutcome':new,'status':'DETECTED actual native mismatch'});print('PASS actual source mutant detected',name,flush=True)
(D/'report.json').write_text(json.dumps({'status':'PASS actual hardware instruction values, original CRC product fuel/trap/resource parity, four source mutant controls','instructionBasisCases':len(actual),'instructionValues':actual,'wrongPolynomialControl':wrong,'originalExportOffsets':exports,'originalProductPairs':len(pairs),'originalPairs':pairs,'sourceMutants':mutation_results,'fuelBoundary':'Product remaining0 after completed return is success; earlier diagnostic remaining0-as-trap runner not used. Actual prefix exhaustion and invalid table entries compared separately.','timingRuns':0},indent=2)+'\n')
