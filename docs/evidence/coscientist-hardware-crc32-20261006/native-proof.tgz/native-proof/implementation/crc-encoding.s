.text
.globl _crc_instruction_reference
_crc_instruction_reference:
 crc32b w0, w0, w1
 crc32b w3, wzr, w2
 ret
