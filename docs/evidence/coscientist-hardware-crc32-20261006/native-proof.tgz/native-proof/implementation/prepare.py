from pathlib import Path
import subprocess,hashlib,json,shutil
I=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17');B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
commit='44bfaa28ccb70252bf763e20de5321ced848f0e4'
def original(rel):return subprocess.check_output(['git','show',commit+':'+rel],cwd=R).decode()
helper=(I/'crc-native.kotoba').read_text();g=original('seed/41-a64gen.kotoba');assert hashlib.sha256(g.encode()).hexdigest()=='4ed9b5600505c33013c966d266a977a3d4ccd56ad3cdc425b1805acf390b95f3'
needle='(defn- gn-op-call [';assert g.count(needle)==1;g=g.replace(needle,helper+'\n'+needle)
needle='dag (di-admit M i f t n)]';assert g.count(needle)==1;g=g.replace(needle,'dag (di-admit M i f t n) crc (cr-root M i f t n)]')
needle='   (cond (> reader 0)';assert g.count(needle)==1;g=g.replace(needle,'   (cond (> crc 0) (cr-call M i crc) (> reader 0)')
(I/'41-a64gen-prototype.kotoba').write_text(g);manifest=original('seed/MANIFEST');parts=[p.strip() for p in manifest.splitlines() if p.strip() and not p.lstrip().startswith('#')]
(I/'unity.kotoba').write_text('\n'.join(g if p=='seed/41-a64gen.kotoba' else original(p) for p in parts))
for rel in parts+['seed/MANIFEST','seed/SIR','seed/HEADS','seed/MEMORY-MAP','bench/embench/comparison-matrix.json']:
 p=I/'source-snapshot'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(original(rel))
(I/'42-layout-prototype.kotoba').write_text(original('seed/42-layout.kotoba'))
for dest,src in [('seed-0.bin','seed-4.bin'),('seed-0.offset','seed-4.offset'),('kexe-loader','kexe-loader')]:
 if not (I/dest).exists():shutil.copy2(B/src,I/dest)
assert sha(I/'seed-0.bin')=='761856bb455de5d36021e177be8f3a0bbf65772dd66cbdf29c8e114f8cbe3d93'
(I/'input-pins.json').write_text(json.dumps({str(p):sha(p) for p in [I/'seed-0.bin',I/'kexe-loader',I.parent/'hypothesis.json']},indent=2)+'\n')
(I/'source-pins.json').write_text(json.dumps({p.name:sha(p) for p in [I/'crc-native.kotoba',I/'41-a64gen-prototype.kotoba',I/'unity.kotoba',I/'42-layout-prototype.kotoba']},indent=2)+'\n')
print('CRC source prepared',sha(I/'41-a64gen-prototype.kotoba'))
