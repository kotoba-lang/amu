from pathlib import Path
import json,re,struct,collections,copy,hashlib
I=Path(__file__).resolve().parent;B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation/observer/ports')
# Read-only copied baseline observer and pinned portable decoder.
exec((I/'machine-decoder.py').read_text())
B=I/'qualified-baseline-observer'

def crload(p):
 d=parse(p);d['pre']=[];d['post']=[];d['flow']=[]
 for l in (p/'compile.log').read_text().splitlines():
  q=l.split()
  if q and q[0] in ['CRPRE','CRPOST','CRFLOW']:d[{'CRPRE':'pre','CRPOST':'post','CRFLOW':'flow'}[q[0]]].append(tuple(map(int,q[1:])))
 return d

def verify_sites(a,b):
 assert a['sir']==b['sir'] and a['fn'].keys()==b['fn'].keys()
 for f,v in a['fn'].items():assert v[:-1]==b['fn'][f][:-1],('frame/register/callee',f)
 assert len(b['pre'])==len(b['post'])==len(b['flow'])
 ea={v[0]:v for v in a['events']};eb={v[0]:v for v in b['events']};sites=[]
 for pre,post,flow in zip(b['pre'],b['post'],b['flow']):
  i,token,acc,octet,ra,ro,ha,ho,frame,height,ctx,bs,fix=pre;ii,be,fixafter,skip=post;p,end,ns,dp,query,slot,yes,mask=flow
  assert i==ii==query and acc==slot and yes==1 and mask&(1<<(acc-1)) and token==2
  assert frame>0 and height==1 and 19<=ra<=28 and 19<=ro<=28 and ha==frame-8*(acc+1) and ho==frame-8*(octet+1)
  assert fix==fixafter and skip==5 and be-bs==10 and eb[i]==(i,5,bs,be)
  assert a['sir'][i][0]==13 and a['sir'][i][2:]==(0,1);f=a['sir'][i][1]
  assert a['sir'][i+1]==(4,1,acc,0) and a['sir'][i+2]==(3,2,8,0) and a['sir'][i+3]==(6,9,1,0) and a['sir'][i+4]==(6,7,0,0)
  expected=[0xaa0003e0|(ra<<16),0xaa0003e1|(ro<<16),0xf94004e8,0xf1000508,0x54000062,0xf90004ff,0xd4200000,0x1ac14000,0xf90004e8]
  destination=a['words'][ea[i+4][3]-2]&31
  expected.append(0xaa0003e0|destination)
  assert b['words'][bs-1:be-1]==expected,('exact capture/charge/crc/store/take block',i)
  oldlo=ea[i][2];oldhi=ea[i+4][3];oldfix=[x for x in a['fix'] if oldlo<=x[1]<oldhi]
  assert len(oldfix)==1 and oldfix[0][2:]==(4,f,0)
  at=oldfix[0][1];assert at+branch(a['words'][at-1])[1]==a['fn'][f][-1]
  fn=a['fn'][f];assert fn[1]==0 and fn[2:6]==(1,2,0,1)
  entry=fn[-1];assert a['words'][entry-1:entry+4]==expected[2:7],('original callee exact charge',f)
  rets=[e for e in a['events'] if fn[0]<e[0]<end and a['sir'][e[0]][0]==19]
  # Filter to callee END, independent of caller's END.
  callee_end=next(j for j,v in a['sir'].items() if j>fn[0] and v==(2,f,0,0))
  rets=[e for e in a['events'] if fn[0]<e[0]<callee_end and a['sir'][e[0]][0]==19];assert len(rets)==1
  assert a['words'][rets[0][3]-3:rets[0][3]-1]==[0xf90004e8,0xd65f03c0]
  assert not any(bs<=x[1]<be for x in b['fix'])
  sites.append({'sir':i,'callee':f,'oldLo':oldlo,'oldHi':oldhi,'newLo':bs,'newHi':be,'oldFix':at,'charged':1,'accReg':ra,'byteReg':ro,'destinationReg':destination,'callerFrame':frame})
 return sites

def normalized(d,sites,new):
 stream=[];pos={};edges=[];internal=set();lit={};regions={(s['newLo'] if new else s['oldLo']):(s['newHi'] if new else s['oldHi'],s) for s in sites}
 for ix,at,k,t,u in d['fix']:
  if k==5:lit[at]=(t,0);lit[at+1]=(t,1)
 i=1
 while i<d['n']:
  if i in regions:
   end,s=regions[i]
   for k in range(i,end):pos[k]=len(stream)
   internal.update(range(i+1,end));stream.append(('CERTIFIED-CRC',s['sir'],s['callee']));i=end;continue
  pos[i]=len(stream);z=d['words'][i-1];q=branch(z)
  if q:stream.append(('BR',q[0]));edges.append((len(stream)-1,i+q[1]))
  elif i in lit:stream.append(('LIT',lit[i],z&~0x1fffe0))
  else:stream.append(('WORD',z))
  i+=1
 pos[d['n']]=len(stream)
 assert set(pos)==set(range(1,d['n']+1))
 for x,target in edges:assert target not in internal,('external incoming into replacement',target)
 return stream,pos,edges

def audit(a,b):
 sites=verify_sites(a,b);aa,pa,ea=normalized(a,sites,False);bb,pb,eb=normalized(b,sites,True)
 assert aa==bb,next(((i,x,y) for i,(x,y) in enumerate(zip(aa,bb)) if x!=y),(len(aa),len(bb)))
 assert len(ea)==len(eb)
 for x,y in zip(ea,eb):assert x[0]==y[0] and pa[x[1]]==pb[y[1]],('all projected branches/calls/ADR',x,y)
 for f,v in a['fn'].items():assert pa[v[-1]]==pb[b['fn'][f][-1]]
 oldevents={e[0]:e for e in a['events']};newevents={e[0]:e for e in b['events']};deleted={s['sir']+k for s in sites for k in range(1,5)}
 assert set(oldevents)-set(newevents)<=deleted and set(newevents)<=set(oldevents)
 for i,x in newevents.items():
  y=oldevents[i];site=next((s for s in sites if s['sir']==i),None)
  assert pa[y[2]]==pb[x[2]]
  assert (pa[site['oldHi']] if site else pa[y[3]])==pb[x[3]]
  if not site:assert x[1]==y[1]
 removed={s['oldFix'] for s in sites};af=[x for x in a['fix'] if x[1] not in removed];assert len(af)==len(b['fix']);literal=private=0
 ap=((a['n']-1)*4+7)//8*8;bp=((b['n']-1)*4+7)//8*8
 for (ix,at,k,t,u),(iy,bt,l,s,v) in zip(af,b['fix']):
  assert (k,t,u)==(l,s,v) and pa[at]==pb[bt]
  if k==5:
   old=((a['words'][at-1]>>5)&65535)|(((a['words'][at]>>5)&65535)<<16);new=((b['words'][bt-1]>>5)&65535)|(((b['words'][bt]>>5)&65535)<<16);assert old-ap==new-bp and pa[at+1]==pb[bt+1];literal+=2
  if u:
   assert k==4 and u==1;oe=a['fn'][t][-1];ne=b['fn'][t][-1];assert a['words'][oe-1]==b['words'][ne-1]==0xd2800005
   assert at+branch(a['words'][at-1])[1]==oe+1 and bt+branch(b['words'][bt-1])[1]==ne+1;private+=1
 assert a['raw'][ap:]==b['raw'][bp:] and set(a['raw'][(a['n']-1)*4:ap])<={0} and set(b['raw'][(b['n']-1)*4:bp])<={0}
 assert b['n']-a['n']==sum(s['newHi']-s['newLo']-(s['oldHi']-s['oldLo']) for s in sites)
 return {'sites':sites,'remainingWords':len(aa),'remainingEdges':len(ea),'literalWords':literal,'privateAux1':private,'addedWords':b['n']-a['n']}
rows=[];data={}
for p in sorted((I/'observer/ports').iterdir()):
 a=crload(B/p.name);b=crload(p);r=audit(a,b);data[p.name]=(a,b);rows.append({'workload':p.name,**r});print('PASS CRC full machine projection',p.name,flush=True)
a,b=data['crc32'];site=rows[[r['workload'] for r in rows].index('crc32')]['sites'][0];controls=[]
for name,word,mask in [('wrong polynomial',site['newLo']+7,0x1000),('wrong accumulator source',site['newLo'],0x10000),('wrong byte source',site['newLo']+1,0x10000),('fuel charge absent',site['newLo']+3,1),('fuel publication omitted',site['newLo']+8,1),('return destination',site['newHi']-1,1),('retained generic callee',a['fn'][1][-1],1),('retained ordinary opcode',site['newHi']+3,1)]:
 d=copy.deepcopy(b);d['words'][word-1]^=mask
 try:audit(a,d)
 except (AssertionError,KeyError,IndexError) as e:controls.append({'name':name,'status':'DETECTED','diagnostic':str(e)[:300]})
 else:raise AssertionError('fault accepted '+name)
(I/'machine-audit.json').write_text(json.dumps({'status':'PASS original19 full emitted-machine/frame/FN/branch/fixup/literal/private projection except exact certified CRC spans','rows':rows,'controls':controls,'trustBoundary':'Typed checked SIR and literal metadata; compiler admission certificate semantic closure supplemented by root SMT/typed controls. Exact hardware block fixed word sequence, software callee retained. Hardware support requires explicit verified feature recipe. No arbitrary opcode/immediate masks.'},indent=2)+'\n')
