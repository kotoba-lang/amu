from pathlib import Path
import subprocess,os,re,json,hashlib
I=Path(__file__).resolve().parent;D=I/'typed-controls';B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation');R=Path('/Users/junkawasaki/github/wt/amu-seed17');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');prep=json.loads((D/'preparation.json').read_text());rows=[]
for name in prep['names']:
 d=D/name;d.mkdir(exist_ok=True);offsets={}
 for label,seed in [('baseline',I/'seed-0.bin'),('candidate',I/'seed-4.bin'),('observer',I/'observer/seed.bin')]:
  for action,args in [('compile',['compile',str(D/(name+'.kotoba')),'--target','aarch64-macos','--output',str(d/(label+'.kseed'))]),('extract',['extract-native',str(d/(label+'.kseed')),'--symbol','run','--output',str(d/(label+'.bin'))])]:
   q=subprocess.run([str(I/'kexe-loader'),str(seed),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'-'+action+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,label,action,q.stdout[-1000:],q.stderr[-1000:])
   if action=='extract':offsets[label]=int(re.search(r':offset (\d+)',q.stdout)[1])
 assert sha(d/'candidate.bin')==sha(d/'observer.bin') and offsets['candidate']==offsets['observer']
 admissions=[list(map(int,l.split()[1:])) for l in (d/'observer-compile.log').read_text().splitlines() if l.startswith('CRPRE ')]
 expected=prep['expectedAdmissions'][name];assert len(admissions)==expected,(name,len(admissions),expected)
 if not expected:assert sha(d/'baseline.bin')==sha(d/'candidate.bin') and offsets['baseline']==offsets['candidate']
 pairs=[]
 for n in prep['inputStops']:
  for fuel in prep['fuelPrefixes']:
   outcomes=[]
   for label in ['baseline','candidate']:
    e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
    q=subprocess.run([str(I/'kexe-loader'),str(d/(label+'.bin')),str(offsets[label]),'1','aarch64','-',str(n)],env=e,capture_output=True,text=True)
    (d/f'{label}-n{n}-f{fuel}.stdout').write_text(q.stdout);(d/f'{label}-n{n}-f{fuel}.stderr').write_text(q.stderr)
    outcomes.append({'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
   assert outcomes[0]==outcomes[1],(name,n,fuel,outcomes)
   pairs.append({'n':n,'fuel':fuel,'status':outcomes[1]['exit']})
 rows.append({'case':name,'sourceSha256':sha(D/(name+'.kotoba')),'baselineSha256':sha(d/'baseline.bin'),'candidateSha256':sha(d/'candidate.bin'),'offsets':offsets,'admissions':admissions,'pairs':pairs});print('PASS typed CRC',name,len(admissions),len(pairs),flush=True)
(D/'report.json').write_text(json.dumps({'status':'PASS native typed admission/refusal and exact product-loader result/resource/fuel/status pairs','pairs':sum(len(r['pairs']) for r in rows),'feature':1,'diagnosticRemainingZeroTrapNotUsed':True,'entries':rows},indent=2)+'\n')
