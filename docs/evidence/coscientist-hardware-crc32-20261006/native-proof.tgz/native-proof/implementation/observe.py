from pathlib import Path
import subprocess,os,re,json,hashlib
I=Path(__file__).resolve().parent;R=Path('/Users/junkawasaki/github/wt/amu-seed17');B=Path('/private/tmp/amu-scalar-dag-inline-20261006/implementation');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def out(prefix,fields):
 s='"\\n"'
 for x in reversed(fields):s=f'(string-concat (string-from-i64 {x}) (string-concat " " {s}))'
 return f'(io-out (string-concat "{prefix} " {s}))'
helper=(I/'crc-native.kotoba').read_text();needle='       result (cr-flow m3 base p end ns dp i slot)';assert helper.count(needle)==1
helper=helper.replace(needle,needle+'\n           flowReceipt '+out('CRFLOW',['p','end','ns','dp','i','slot','(if result 1 0)','(vector-at m3 (+ base (- i p)))']))
needle=' (let [acc (gn-sir M (- i 7) IF-B) octet (gn-sir M (- i 6) IF-B)\n       m1';assert helper.count(needle)==1
helper=helper.replace(needle,' (let [acc (gn-sir M (- i 7) IF-B) octet (gn-sir M (- i 6) IF-B)\n       before '+out('CRPRE',['i','token','acc','octet','(gn-sreg M acc)','(gn-sreg M octet)','(gn-soff M acc)','(gn-soff M octet)','(gn-g M gn-f-fb)','(gn-g M gn-f-h)','(gn-g M gn-f-ctx)','(vector-at M MM-CODE-N)','(vector-at M MM-FIX-N)'])+'\n       m1')
needle='  (gn-gs m3 gn-f-skip (+ 4 (gn-g m3 gn-f-skip)))))';assert helper.count(needle)==1
helper=helper.replace(needle,'  (let [printed '+out('CRPOST',['i','(vector-at m3 MM-CODE-N)','(vector-at m3 MM-FIX-N)','(+ 4 (gn-g m3 gn-f-skip))'])+']\n   (gn-gs m3 gn-f-skip (+ 4 (gn-g m3 gn-f-skip))))))')
g=(B/'observer/41.kotoba').read_text();needle='(defn- gn-op-call [';assert g.count(needle)==1;g=g.replace(needle,helper+'\n'+needle)
needle='dag (di-admit M i f t n)]';assert g.count(needle)==1;g=g.replace(needle,'dag (di-admit M i f t n) crc (cr-root M i f t n)]');needle='   (cond (> reader 0)';assert g.count(needle)==1;g=g.replace(needle,'   (cond (> crc 0) (cr-call M i crc) (> reader 0)')
o=I/'observer';o.mkdir(exist_ok=True);(o/'41.kotoba').write_text(g)
parts=[p.strip() for p in (I/'source-snapshot/seed/MANIFEST').read_text().splitlines() if p.strip() and not p.lstrip().startswith('#')]
(o/'unity.kotoba').write_text('\n'.join(g if p=='seed/41-a64gen.kotoba' else (I/'source-snapshot'/p).read_text() for p in parts))
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(R)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for label,args in [('compile',['compile',str(o/'unity.kotoba'),'--target','aarch64-macos','--output',str(o/'image.kseed')]),('extract',['extract-native',str(o/'image.kseed'),'--symbol','main','--output',str(o/'seed.bin')])]:
 q=subprocess.run([str(I/'kexe-loader'),str(I/'seed-0.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(o/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout[-1500:],q.stderr[-1000:])
 if label=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1);(o/'seed.offset').write_text(off+'\n')
rows=[];base=json.loads((I/'ports-build.json').read_text())['entries']
for e in json.loads((I/'source-snapshot/bench/embench/comparison-matrix.json').read_text())['entries']:
 d=o/'ports'/e['workload'];d.mkdir(parents=True,exist_ok=True)
 for label,args in [('compile',['compile',str(R/e['source']),'--target','aarch64-macos','--output',str(d/'image.kseed')]),('extract',['extract-native',str(d/'image.kseed'),'--symbol',e['symbol'],'--output',str(d/'native.bin')])]:
  q=subprocess.run([str(I/'kexe-loader'),str(o/'seed.bin'),off,'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(e['workload'],label,q.stdout[-1000:],q.stderr[-1000:])
  if label=='extract':offset=int(re.search(r':offset (\d+)',q.stdout).group(1))
 old=next(x for x in base if x['workload']==e['workload']);assert sha(d/'native.bin')==old['nativeSha256'] and offset==old['offset']
 records={tag:[list(map(int,l.split()[1:])) for l in (d/'compile.log').read_text().splitlines() if l.startswith(tag+' ')] for tag in ['CRPRE','CRPOST','CRFLOW']}
 rows.append({'workload':e['workload'],'nativeSha256':sha(d/'native.bin'),'offset':offset,**records});print('PASS CRC observer',e['workload'],len(records['CRPRE']),flush=True)
(o/'admission.json').write_text(json.dumps({'status':'PASS read-only observer byte+offset exact all19','schema':{'CRFLOW':'callerStart end ns dp query local u32Proved entryMask','CRPRE':'sir token accLocal byteLocal accReg byteReg accHome byteHome frame height ctx firstWord fixCount','CRPOST':'sir afterWord fixCount skip'},'entries':rows},indent=2)+'\n')
