# Bootstrap-only: one fixed original19 prospective campaign, no retry-overwrite.
from pathlib import Path
import json,hashlib,shutil,os,subprocess
root=Path('/private/tmp/amu-zebulun-hardware-crc32-20261006');p=root/'timing-package';old=Path('/private/tmp/amu-zebulun-paired-20261005')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();load=lambda f:json.loads(f.read_text())
o=load(old/'measurement-2/results.json');pb=load(p/'product-proof.json');pc=load(p/'candidate-proof.json');pre=load(p/'preflight.json')
assert pre['status']=='setup-complete-awaiting-root-independent-PASS-and-new-root-GO' and len(pre['timedGuests'])==19
go=load(root/'root-GO.json');resource=load(root/'root-final-proof.json')
assert go['rootGO'] is True and go['candidateSeedSha256']==pre['nativeSeedSha256'] and go['preflightSha256']==sha(p/'preflight.json')
assert resource['status'].startswith('PASS') and go['rootFinalProofSha256']==sha(root/'root-final-proof.json')
for name,h in pre['proofPins'].items():assert sha(p/name)==h
assert go['featureReceiptSha256']==pre['featureReceiptSha256'] and go['featureRecipeSha256']==pre['featureRecipeSha256']
assert pre['changedGuests']==['crc32'] and len(pre['timedGuests'])==19
feature=[]
for key in ['hw.optional.arm.FEAT_CRC32','hw.optional.armv8_crc32']:
 q=subprocess.run(['sysctl','-n',key],capture_output=True,text=True)
 feature.append({'key':key,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
 assert q.returncode==0 and q.stdout.strip()=='1','CRC feature absent: no execution permitted'
assert 'Apple M4' in subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True)
assert not (root/'launch-feature-receipt.json').exists(),'single prospective launch only'
(root/'launch-feature-receipt.json').write_text(json.dumps({'status':'PASS external measured-host CRC32 opt-in attestation','features':feature,'rawRunnerChanged':False,'automaticProductFeatureAdmission':False},indent=2)+'\n')

assert sha(old/'environment/runner')==o['runnerSha256'];assert sha(p/'comparison-matrix.json')==o['matrixSpecSha256'];assert sha(p/'paired-timing-spec.json')==sha(old/'repo/bench/embench/paired-timing-spec.json')
env=dict(os.environ,PYTHONPATH=str(old/'repo/scripts/seed/image'));report={'status':'running','entries':[],'timedGuests':pre['timedGuests'],'changedGuests':pre['changedGuests'],'officialEmbenchScore':False,'productUnchanged':True}
assert not (root/'batch-status.json').exists(),'never overwrite or retry this campaign'
def save():(root/'batch-status.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for name in pre['timedGuests']:
 d=p/name;b=d/'baseline';mf=load(d/'candidate/manifest.json');e=next(x for x in o['entries'] if x['workload']==name);eb=next(x for x in pb['entries'] if x['workload']==name);ec=next(x for x in pc['entries'] if x['workload']==name)
 assert sha(d/'baseline-native.bin')==mf['baselineNativeSha256']==eb['nativeSha256'];assert sha(d/'candidate/native.bin')==mf['nativeSha256']==ec['nativeSha256'];assert ec['runs']==eb['runs'] and ec['fuelTrapReturncode']==eb['fuelTrapReturncode'];assert sha(old/'measurement-2'/name/'c.dylib')==e['cDylibSha256']
 t=b/name;t.mkdir(parents=True);shutil.copyfile(d/'baseline-native.bin',t/'native.bin');shutil.copyfile(old/'measurement-2'/name/'c.dylib',t/'c.dylib')
 descriptor={k:e[k] for k in ['workload','iterationsPerCall','cSymbol','cDylibSha256','cSourceSha256','cCompiler','cCompilerFlags','cCompilerVersion','sourceSha256'] if k in e};descriptor.update(offset=mf['baselineOffset'],nativeSha256=mf['baselineNativeSha256'])
 (b/'results.json').write_text(json.dumps({'status':'complete-provisional-timing','runnerSha256':o['runnerSha256'],'matrixSpecSha256':o['matrixSpecSha256'],'entries':[descriptor],'derivation':'Legacy measurement-input status label; current qualified 761856 scalar DAG product descriptor and immutable original C/runner pins only. All19 three arms freshly sampled. Historical statistics are not used.','nativePreflightSha256':sha(p/'preflight.json'),'officialEmbenchScore':False},indent=2)+'\n')
 print('START',name,flush=True)
 with (d/'timing.log').open('w') as log:q=subprocess.run(['python3',str(p/'measure-native-candidate-v2.py'),str(b),str(d/'candidate'),str(old/'environment/runner'),str(p/'paired-timing-spec.json'),str(d/'timing')],env=env,stdout=log,stderr=subprocess.STDOUT)
 result=load(d/'timing/results.json');row={'workload':name,'exit':q.returncode,'status':result['status'],'acceptedTriples':result.get('acceptedTriples'),'attemptedTriples':result.get('attemptedTriples'),'summary':result.get('summary'),'error':result.get('error',result.get('failure'))};report['entries'].append(row);save();print('FINISH',name,json.dumps(row),flush=True)
report['status']='terminal-all19-guests-attempted';save();print('TERMINAL one prospective full19 performance campaign; raw outcomes retained',flush=True)
