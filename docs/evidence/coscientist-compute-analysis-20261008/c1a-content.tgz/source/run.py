"""Finite3 source-frozen diagnostic, inert on import. Root GO required."""
from pathlib import Path
import os,sys,json,hashlib,re,subprocess,signal
from check import validate
D=Path(__file__).resolve().parent
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(v,m):
 if not v:raise AssertionError(m)
def load(p):return json.loads(Path(p).read_text())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def main():
 need(len(sys.argv)==2,'rootGO path');gp=Path(sys.argv[1]);g=load(gp);gh=H(gp);pr=load(D/'preregistration.json');pins=load(D/'source-pins.json');out=D/'run-outputs';rows=[];immutable={};success=False
 need(g['authorizeToyNativeCodec'] is True and type(g['maximumLoaderCalls']) is int and g['maximumLoaderCalls']==3 and g['noRetry'] is True and g['performanceTiming'] is False,'specificfinite3 rootGO');need(g['driverSHA256']==H(D/'run.py') and g['sourcePinsSHA256']==H(D/'source-pins.json') and len(g['sourceReviews'])==2,'specific source reviews')
 def guard():
  need(H(gp)==gh,'immutableGO')
  for n,v in pins.items():need(H(D/n)==v['sha256'] and (D/n).stat().st_size==v['bytes'],'frozen source '+n)
  for p,v in pr['inputs'].items():need(H(p)==v['sha256'] and Path(p).stat().st_size==v['bytes'],'actual pinned input '+p)
  for v in g['sourceReviews']:
   need(H(v['path'])==v['sha256'],'reviewhash');j=load(v['path']);need(j['status'].startswith('PASS') and j['sourcePinsSHA256']==g['sourcePinsSHA256'],'specificparsedreview')
  for p,v in immutable.items():need(H(p)==v['sha256'] and Path(p).stat().st_size==v['bytes'],'copied source/generatedartifact '+p)
 guard();need(not out.exists(),'fresh output/no retry');out.mkdir();p=out/'codec-fixture.kotoba';p.write_bytes((D/p.name).read_bytes());p.chmod(0o444);immutable[str(p)]={'sha256':H(p),'bytes':p.stat().st_size}
 W=D.parent;loader=W/'vector-emitter-param-native-build-v1-root/kexe-loader';producer=W/'vector-aha-funnel-native-build-plan-v4-root/run-outputs/on-generation1.bin';base={k:v for k,v in os.environ.items() if not k.startswith('KEXE_')}
 def call(label,image,offset,args,build):
  guard();need(len(rows)<3 and label not in [r['label'] for r in rows],'3cap/noRetry');seconds=1800 if build else 60;env={'KEXE_COMMAND':'1','KEXE_CPU_SECONDS':str(seconds),'KEXE_WALL_SECONDS':str(seconds),'KEXE_STRING_POOL':'268435456' if build else'4194304','KEXE_VECTORS':'4194304' if build else'32768','KEXE_VECTOR_ITEMS':'134217728' if build else'1048576','KEXE_PAIRS':'16777216' if build else'65536'}
  if build:env['KEXE_CAP_RESOURCES_35']=str(out)
  caps='35,37,38,39' if build else'3,37,38,39';cmd=[str(loader),str(image),str(offset),'0','aarch64',caps,'--']+args
  r={'index':len(rows)+1,'label':label,'argv':cmd,'kexeEnvironment':env,'removedInheritedKexeKeys':sorted(k for k in os.environ if k.startswith('KEXE_')),'imageSHA256':H(image),'timeoutSeconds':seconds+10,'state':'started'};rows.append(r);save(out/'attempts.json',rows)
  p=subprocess.Popen(cmd,cwd=out,env=base|env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);timed=False
  try:o,e=p.communicate(timeout=seconds+10)
  except subprocess.TimeoutExpired:timed=True;os.killpg(p.pid,signal.SIGKILL);o,e=p.communicate()
  (out/(label+'.stdout')).write_bytes(o);(out/(label+'.stderr')).write_bytes(e);r.update(state='terminal',returncode=p.returncode,timeout=timed,stdoutSHA256=hashlib.sha256(o).hexdigest(),stderrSHA256=hashlib.sha256(e).hexdigest());save(out/'attempts.json',rows);guard();need(not timed and p.returncode==0 and e==b'' and (not build or b':ok true' in o),'firstfailure '+label);return o
 try:
  k=out/'codec.kseed';n=out/'codec.bin';call('compile',producer,0,['compile',str(p),'--target','aarch64-macos','--output',str(k)],True);need(0<k.stat().st_size<=4194560,'boundedcontainer beforeextract');immutable[str(k)]={'sha256':H(k),'bytes':k.stat().st_size};save(out/'artifacts.json',immutable)
  raw=call('extract',producer,0,['extract-native',str(k),'--symbol','main','--output',str(n)],True);xs=re.findall(rb':offset (\d+)\b',raw);need(len(xs)==1,'soleactualoffset');offset=int(xs[0]);blob=n.read_bytes();need(0<len(blob)<=4194304 and 0<=offset<len(blob) and offset%4==0,'actualbounded nativeentry');need(k.read_bytes()==f'KSEED1 {len(blob)} 1\nmain {offset} 0\n\n'.encode()+blob,'exactwhole solemain0 container, literal tail allowed');immutable[str(n)]={'sha256':H(n),'bytes':len(blob)};save(out/'artifacts.json',immutable)
  raw=call('guest',n,offset,[],False);result=validate(raw);guard();need(len(rows)==3,'exact3closed');save(out/'report.json',result);success=True
 except BaseException as e:save(out/'failure.json',{'exception':repr(e),'calls':len(rows),'stopFirstFailure':True,'noRetry':True});raise
 finally:save(out/'terminal.json',{'calls':len(rows),'allCallsClosed':all(r['state']=='terminal' for r in rows),'failure':not success,'noRetry':True})
if __name__=='__main__':main()
