"""Independent stdlib validation of actual native toy bytes/hash/CID outputs."""
import hashlib,base64,re
MASK=(1<<64)-1
TAGS=['REQUEST','RESULT','MUTATED','HASH-REQUEST','HASH-RESULT','HASH-MUTATED','CID-REQUEST','CID-RESULT','CID-MUTATED','HASH-EMPTY','HASH-ABC','HASH-REPEAT','ROUNDTRIP','NEGATIVE','END']
def need(v,m):
 if not v:raise AssertionError(m)
def encode(domain,values):
 need(domain in ['request','result'] and 1<=len(values)<=8 and all(type(x) is int and -(1<<63)<=x<(1<<63) for x in values),'bounded typed schema')
 return ('C1A/'+domain+'/v1|'+format(len(values),'016x')+''.join(format(x&MASK,'016x') for x in values)+'|END').encode('ascii')
def cid(data):return 'b'+base64.b32encode(bytes([1,0x55,0x12,0x20])+hashlib.sha256(data).digest()).decode('ascii').lower().rstrip('=')
def validate(raw):
 need(len(raw)<=8192,'boundedstdout');lines=raw.decode('ascii').splitlines();need(len(lines)==15,'exact15records');rows={}
 for tag,line in zip(TAGS,lines):
  pieces=line.split(' ');need(len(pieces)==2 and pieces[0]==tag and tag not in rows,'ordered unique schema');rows[tag]=pieces[1]
 values={'REQUEST':encode('request',[7,4,0]),'RESULT':encode('result',[4,-1]),'MUTATED':encode('request',[8,4,0])}
 for tag,data in values.items():
  need(rows[tag].encode('ascii')==data,'exactcanonical toy '+tag);need(rows['HASH-'+tag]==hashlib.sha256(data).hexdigest(),'actualSHA bytes '+tag);need(rows['CID-'+tag]==cid(data),'actual rawCID '+tag)
  text=rows['CID-'+tag];need(re.fullmatch(r'b[a-z2-7]{58}',text),'canonicalCID59');body=base64.b32decode(text[1:].upper()+'='*((-len(text[1:]))%8));need(body==bytes([1,85,18,32])+hashlib.sha256(data).digest(),'CID actual version/codec/multihash/digest')
 need(rows['HASH-EMPTY']==hashlib.sha256(b'').hexdigest() and rows['HASH-ABC']==hashlib.sha256(b'abc').hexdigest(),'native actual knownSHA vectors')
 need(rows['HASH-REPEAT']==rows['HASH-REQUEST'] and rows['HASH-MUTATED']!=rows['HASH-REQUEST'],'repeat andmutation')
 need(rows['ROUNDTRIP']=='1' and rows['NEGATIVE']=='1' and rows['END']=='C1A-TOY-ONLY','nativecodec selfchecks')
 return {'status':'PASS_ACTUAL_NATIVE_TOY_CODEC_HASH_RAW_CID_ONLY','records':15,'nativeHashCalls':6,'canonicalRequest':rows['REQUEST'],'canonicalResult':rows['RESULT'],'requestCID':rows['CID-REQUEST'],'resultCID':rows['CID-RESULT'],'shapeC1Qualified':False,'computeResultTrustProven':False,'persistentReuse':False,'performanceQualified':False}
