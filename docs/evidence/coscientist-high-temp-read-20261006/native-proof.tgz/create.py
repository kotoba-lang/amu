from pathlib import Path
import shutil,json,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-high-temp-read-20261006');w.mkdir();b=Path('/private/tmp/amu-affine-reader-20261005');g=(r/'seed/41-a64gen.kotoba').read_text();(w/'baseline-41-a64gen.kotoba').write_text(g)
helper=''';; High-temp read composition. Original prescan stays nonleaf and keeps its
;; frame/register/fuel contract. Preserve original live homes; x0/x1 are free
;; argument scratch under that contract. Every handle/index check stays ordered.
(defn- gn-rt-high-at [M :vector-i64 i :i64 t :i64] :vector-i64
 (-> M (gn-save 0 t) (gn-into 0 t) (gn-into 1 (inc t)) (gn-ctx)
     (gn-hchk 0 312 320) (gn-vidx 1) (gn-emit (gn-e-ldrr 0 16 17 1))
     (gn-take i t 0)))
''';pos=g.index('(defn- gn-op-rt [');g=g[:pos]+helper+g[pos:];needle='        (not (gn-inl slot t n))';assert g.count(needle)==1;g=g.replace(needle,'        (and (= slot RT-VECTOR-AT) (= n 2) (>= t 6) (= (gn-g M gn-f-leaf) 0)) (gn-rt-high-at M i t)\n'+needle)
(w/'41-a64gen-prototype.kotoba').write_text(g);parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];unity=lambda g:''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in parts);(w/'seed-unity.kotoba').write_text(unity(g))
st='"\\n"'
for x in reversed(['i','t']):st='(string-concat (string-from-i64 '+x+') (string-concat " " '+st+'))'
g=g.replace('(-> M (gn-save 0 t) (gn-into 0 t) (gn-into 1 (inc t)) (gn-ctx)','(let [printed (io-out (string-concat "HREAD " '+st+'))]\n (-> M (gn-save 0 t) (gn-into 0 t) (gn-into 1 (inc t)) (gn-ctx)',1).replace('(gn-take i t 0)))\n(defn- gn-op-rt','(gn-take i t 0))))\n(defn- gn-op-rt',1);(w/'observer-unity.kotoba').write_text(unity(g))
for ext in ['bin','offset']:shutil.copyfile(b/('seed-4.'+ext),w/('seed-0.'+ext))
shutil.copyfile(b/'kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['build.py','check-ports.py','observe-admission.py','observer-byte-audit.py']:
 src=Path('/private/tmp/amu-vector-validity-20261006')/name;s=src.read_text().replace('amu-vector-validity-20261006','amu-high-temp-read-20261006').replace('VCHECK ','HREAD ').replace('reusedValiditySites','highTempReadSites');(w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'status':'registered-before-native-build-and-timing','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'hypothesis':'Compose high-temp vector reads with original nonleaf frame/live-home saves, proven-free x0/x1 arguments, restored context, original ordered handle/index checks and original result placement. Keep prescan/gn-inl/fuel contract unchanged. No cache or hoisting.','scope':'All19 canonical original workloads; actualSIR has matmult1 andSHA2565 sites. Count is not time share.','qualification':'Nativefixedpoint, all19admission/quietbytes/result/fuel, highdepth/rawinvalidhandle/index/livehomes/coalescing/effect/resource/import/fullstate proofs, freshquiet30rotatingtriples for everychangedguest unchanged1.05+sumSD rule, thenpermanentregression/gates/integrated3gen/corpus.','exception':'One-off new Kotoba compiler algorithm/diagnostic authoring; no existing mechanical AST rule.'},indent=2)+'\n');shutil.copyfile(Path(__file__),w/'create.py');print('registered high-temp native composition')
