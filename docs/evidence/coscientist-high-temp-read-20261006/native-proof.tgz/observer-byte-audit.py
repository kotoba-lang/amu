from pathlib import Path
import subprocess,os,re,json,hashlib
w=Path('/private/tmp/amu-high-temp-read-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[]
for e in json.loads((r/'bench/embench/comparison-matrix.json').read_text())['entries']:
 d=w/'meta-ports'/e['workload'];q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--','extract-native',str(d/'image.kseed'),'--symbol',e['symbol'],'--output',str(d/'native.bin')],env=env,capture_output=True,text=True);(d/'extract.log').write_text(q.stdout+q.stderr);assert q.returncode==0,(e['workload'],q.stderr)
 assert (d/'native.bin').read_bytes()==(w/'ports-2'/e['workload']/'native.bin').read_bytes(),e['workload'];rows.append({'workload':e['workload'],'diagnosticTargetByteIdentical':True,'sha256':hashlib.sha256((d/'native.bin').read_bytes()).hexdigest()})
(w/'observer-byte-audit.json').write_text(json.dumps({'status':'complete-diagnostic-and-quiet-target-byte-identity','entries':rows},indent=2)+'\n');print('PASS all19 diagnostic/quiet target binary identity')
