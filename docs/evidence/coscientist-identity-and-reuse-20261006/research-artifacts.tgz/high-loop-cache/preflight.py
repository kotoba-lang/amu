from pathlib import Path
import json,hashlib,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-high-loop-cache-20261006');b=Path('/private/tmp/amu-affine-read-direct-20261006');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();g=load(w/'generations.json');assert len(g)==4 and len({x['sha256'] for x in g})==1
for x in g:assert sha(w/f"seed-{x['generation']}.bin")==x['sha256']
counts={};pins={}
for name,key,n in [('permanent-regression-proof.json','runs',9339),('ports-state.json','comparisons',209),('loop-state-proof.json','comparisons',1920),('effect-proof.json','comparisons',24),('import-proof.json','comparisons',72),('resource-proof.json','comparisons',12)]:
 v=load(w/name);assert v[key]==n;rows=v.get('observations',v.get('runs'));assert len(rows)==n;counts[name]=n;pins[name]=sha(w/name)
 for row in rows:
  if name=='ports-state.json':assert row['baseline']==row['candidate']
  if name in ['loop-state-proof.json','resource-proof.json']:assert row['baseline-loop']==row['candidate-loop']
  if name=='effect-proof.json':assert row['baseline-effect']==row['candidate-effect']
  if name=='import-proof.json':assert row['baseline-open']==row['candidate-open']
ob=load(w/'observer-byte-audit.json');assert len(ob['entries'])==19 and all(x['diagnosticTargetByteIdentical'] for x in ob['entries']);assert load(w/'instruction-audit.json')['sites']==2
for name in ['observer-byte-audit.json','instruction-audit.json','hit-coverage.json','hypothesis.json']:pins[name]=sha(w/name)
hc=load(w/'hit-coverage.json');changed=[x['workload'] for x in hc['guestAudit'] if x['changed']];assert changed==['matmult-int'];(w/'code-change.json').write_text(json.dumps(hc['guestAudit'],indent=2)+'\n')
pa=load(w/'ports-correctness.json');pb=load(b/'ports-correctness.json');assert len(pa['entries'])==19
for x,y in zip(pa['entries'],pb['entries']):
 assert x['workload']==y['workload'] and x['runs']==y['runs'] and x['fuelTrapReturncode']==y['fuelTrapReturncode'] and x['sourceSha256']==y['sourceSha256'];assert sha(w/'ports-2'/x['workload']/'native.bin')==x['nativeSha256']
assert (r/'seed/41-a64gen.kotoba').read_bytes()==(w/'baseline-41-a64gen.kotoba').read_bytes()
pre={'status':'complete-native-semantic-proof-before-timing','fixedpointGenerations':[1,2,3,4],'originalWorkloads':19,'changedGuests':changed,'freshNativeCounts':counts,'proofPins':pins,'fullSupervisorComparisons':2237,'productUnchanged':True,'mayPromote':False,'productGatesAndIntegratedProofStillRequired':True,'officialEmbenchScore':False};(w/'preflight-audit.json').write_text(json.dumps(pre,indent=2)+'\n');p=w/'timing-package';p.mkdir();hyp=load(w/'hypothesis.json')
for name in changed:
 d=p/name;c=d/'candidate';c.mkdir(parents=True);x=next(z for z in pa['entries'] if z['workload']==name);y=next(z for z in pb['entries'] if z['workload']==name);shutil.copyfile(w/'ports-2'/name/'native.bin',c/'native.bin');shutil.copyfile(b/'ports-2'/name/'native.bin',d/'baseline-native.bin');mf={'workload':name,'sourceSha256':x['sourceSha256'],'baselineSourceSha256':y['sourceSha256'],'nativeSha256':x['nativeSha256'],'offset':x['offset'],'baselineNativeSha256':y['nativeSha256'],'baselineOffset':y['offset'],'compilerGenerationSha256':{str(x['generation']):x['sha256'] for x in g},'hypothesis':hyp['hypothesis'],'sourceHead':hyp['sourceCommit']};(c/'manifest.json').write_text(json.dumps(mf,indent=2)+'\n')
for src,name in [(b/'ports-correctness.json','product-proof.json'),(w/'ports-correctness.json','candidate-proof.json'),(w/'preflight-audit.json','preflight.json'),(w/'generations.json','generations.json'),(w/'code-change.json','code-change.json')]:shutil.copyfile(src,p/name)
for name in pins:shutil.copyfile(w/name,p/name)
for name in ['comparison-matrix.json','paired-timing-spec.json']:shutil.copyfile(r/'bench/embench'/name,p/name)
shutil.copyfile('/private/tmp/amu-context-call-20261005/measure-native-candidate-v2.py',p/'measure-native-candidate-v2.py')
s=(b/'remote-timing.py').read_text().replace('amu-zebulun-affine-read-direct-20261006','amu-zebulun-high-loop-cache-20261006').replace("pre['fullSupervisorComparisons']==8939","pre['fullSupervisorComparisons']==2237").replace('Current qualified loop-contained high-temp product','Current qualified direct affine-read product');(w/'remote-timing.py').write_text(s)
print('PASS2237 fresh fullstate and9339 existingregressions sealed before prospective timing')
