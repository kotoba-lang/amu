from pathlib import Path
import json,shutil,subprocess,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-high-loop-cache-20261006');b=Path('/private/tmp/amu-affine-read-direct-20261006');g=(r/'seed/41-a64gen.kotoba').read_text();(w/'baseline-41-a64gen.kotoba').write_text(g)
old=Path('/private/tmp/amu-loop-descriptor-20261006/41-a64gen-prototype.kotoba').read_text();st=old.index(';; Experimental loop cache:');en=old.index(';; ---- register assignment',st);h=old[st:en];st=h.index('(defn- gn-vloop-scan');en=h.index('(defn- gn-vclear',st)
h=h[:st]+'''(defn- gn-vhot-scan [M :vector-i64 j :i64 work :i64] :bool
 (if (or (<= work 0) (>= j (vector-at M MM-SIR-N))) false
  (let [op (gn-op M j)]
   (cond (or (= op OP-END) (= op OP-FN)) false
         (and (= op OP-RT) (= (gn-sir M j IF-A) RT-VECTOR-AT)
              (= (gn-sir M j IF-C) 2) (>= (gn-sir M j IF-B) 6)
              (gn-high-loop M j)) true
         :else (gn-vhot-scan M (inc j) (dec work))))))
(defn- gn-vmode [M :vector-i64 i :i64] :vector-i64
 (gn-gs M gn-f-vmode (if (and (= (gn-g M gn-f-leaf) 0)
                            (gn-vhot-scan M (inc i) 8192)) 1 0)))
'''+h[en:]
h=h.replace('(gn-g M 8)','(gn-g M gn-f-vmode)').replace('x3..5 are free only in nonleaf functions or <=3-local leaves.','Only nonleaf functions with actual same-function high-depth loop reads admit;\n;; x3..5 are proven free; field8 is named, state14 remains the scalar-tree flag.')
assert '(gn-g M 8)' not in h
needle='(def gn-f-ctx 7)';at=g.index(needle);lineend=g.index('\n',at);g=g[:lineend+1]+'(def gn-f-vmode 8)    ; experimental descriptor cache mode; unused original state cell\n'+g[lineend+1:]
pos=g.index(';; ---- register assignment');g=g[:pos]+h+'\n'+g[pos:]
replacements=[('M2 (gn-assign M1)','M2 (gn-vmode (gn-assign M1) i)'),('(gn-gs gn-f-h 0) (gn-tree-entry f)','(gn-gs gn-f-h 0) (gn-vclear) (gn-tree-entry f)'),('(gn-hchk rv 312 320) (gn-vidx ri) (gn-emit (gn-e-ldrr d 16 17 1)) (gn-fin t s d)','(gn-vread rv ri d) (gn-fin t s d)'),('(gn-emit (enc-bl 0))\n      (gn-gs gn-f-ctx','(gn-emit (enc-bl 0))\n      (gn-vclear)\n      (gn-gs gn-f-ctx'),('(gn-ctx) (gn-hchk 0 312 320) (gn-vidx 1)\n              (gn-emit (gn-e-ldrr d 16 17 1))','(gn-ctx) (gn-vread 0 1 d)')]
for a,z in replacements:assert g.count(a)==1,a;g=g.replace(a,z,1)
a='(gn-hchk 0 312 320) (gn-vidx 1) (gn-emit (gn-e-ldrr 0 16 17 1))';assert g.count(a)==2;g=g.replace(a,'(gn-vread 0 1 0)')
assert g.count('(gn-emit (enc-blr 16))')==3;g=g.replace('(gn-emit (enc-blr 16))','(gn-emit (enc-blr 16)) (gn-vclear)')
(w/'41-a64gen-prototype.kotoba').write_text(g);parts=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader'),('clobber-full-state-loader','clobber-full-state-loader')]:shutil.copy2(b/src,w/dst)
for n in ['build.py','check-ports.py','permanent-regression.py','ports-state.py']:(w/n).write_text((b/n).read_text().replace('amu-affine-read-direct-20261006','amu-high-loop-cache-20261006'))
(w/'hypothesis.json').write_text(json.dumps({'status':'registered-before-native-build-and-measurement','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'hypothesis':'Dynamic-key descriptor reuse in original nonleaf functions structurally containing validated high-inline loop reads, across low/high/direct-affine reads without their prior C boundary.','priorRegistration':json.loads((r/'docs/evidence/coscientist-affine-read-direct-20261006/next-hypothesis.json').read_text()),'authoringException':'One-off new experimental Kotoba compiler algorithm and independent hand fixtures; no mechanical product rewrite. Product untouched pending full semantics/performance/gates.','baselineSeedSha256':hashlib.sha256((w/'seed-0.bin').read_bytes()).hexdigest(),'timingRule':'Fresh30triples per changed originalguest, load<=4 idle>=90 RSD<=10 ratio>=1.05 gap>sumSD; no identical-machine retiming.','goal':'C-or-better all19 original aligned unchanged workloads, native selfhost; not officialscore.'},indent=2)+'\n');print('PASS high-inline-loop descriptor prototype registered; named state8, original state14 unchanged')
