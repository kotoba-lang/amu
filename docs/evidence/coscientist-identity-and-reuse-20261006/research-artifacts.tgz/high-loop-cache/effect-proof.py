from pathlib import Path
import subprocess,re,os,json,struct
w=Path('/private/tmp/amu-high-loop-cache-20261006');scope={};s=(w/'loop-proof.py').read_text();exec(s[:s.index('env=dict(')],scope);m=scope['m'];r=scope['r'];cs=[]
for mode,value in [('ascii','A'),('unicode','é'),('stdout','probe\n'),('indirect','')]:
 name='lc_effect_'+mode;body=[('FUEL',)]+[('CONST',j,11-3*j) for j in range(8)]+[('VEC',0,8),('LSET',4,0)]
 if mode!='indirect':body += [('STR',0,value),('LSET',5,0)]
 body += [('CONST',0,2),('LSET',7,0),('CONST',0,0),('LSET',8,0),('LABEL',name+'_loop'),('LGET',0,7),('BRZ',0,name+'_end'),('CONST',0,0),('CONST',1,0),('CONST',2,0),('CONST',3,0),('CONST',4,0),('CONST',5,0),('CONST',6,0),('LGET',7,4),('CONST',8,0),('RT','RT-VECTOR-AT',7,2),('LSET',6,7)]
 if mode in ['ascii','unicode']:body += [('LGET',0,5),('CONST',1,0),('RT','RT-STRING-CODE-POINT-AT',0,2),('LSET',9,0)]
 if mode=='stdout':body += [('LGET',0,5),('CAP',37,1,0),('CONST',0,0),('LSET',9,0)]
 if mode=='indirect':body += [('LGET',0,4)]+[('CONST',j,v) for j,v in enumerate([99,98,1,0,1,66],1)]+[('FADDR',7,scope['ids']['lc_clobber']),('CALLI',0,0,7),('LSET',9,0)]
 body += [('LGET',0,4),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('LGET',1,6),('BIN','BOP-ADD',0),('LGET',1,9),('BIN','BOP-ADD',0),('LGET',1,8),('BIN','BOP-ADD',0),('LSET',8,0),('LGET',0,7),('CONST',1,1),('BIN','BOP-SUB',0),('LSET',7,0),('FUEL',),('BR',name+'_loop'),('LABEL',name+'_end'),('LGET',0,8),('LGET',1,1),('BIN','BOP-ADD',0),('RET',0)];m.fx(name,1,9,body);cs.append({'name':name,'mode':mode})
ids={x[0]:j+1 for j,x in enumerate(m.FIX)};env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];images={};audit=[]
for label,gen in [('baseline-effect','baseline-41-a64gen.kotoba'),('candidate-effect','41-a64gen-prototype.kotoba')]:
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/gen).read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+scope['text'](True))
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-400:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0;(w/(label+'.stdout')).write_text(q.stdout);blob,fc=m.blob_from(q.stdout);bp=w/(label+'-fixture.bin');bp.write_bytes(blob);images[label]=(bp,fc)
 if label=='candidate-effect':
  for c in cs:
   f=ids[c['name']];end=fc.get(f+1,int(re.search(r'words (\d+)',q.stdout).group(1))*4);words=struct.unpack('<'+'I'*((end-fc[f])//4),blob[fc[f]:end]);assert words.count(0xb4000065)==2;assert words.count(0xd2800005)>=2;audit.append({**c,'cacheReadSites':2,'cacheClearInstructions':words.count(0xd2800005)})
rows=[]
for c in cs:
 for fuel in [1,2,3,4,5,16777216]:
  cost=5 if c['mode']=='indirect' else 3;answer=37+2*(22+{'ascii':65,'unicode':233,'stdout':0,'indirect':77}[c['mode']]);obs={}
  for label,(bp,fc) in images.items():
   e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(bp),str(fc[ids[c['name']]]),'1','aarch64','37','37'],env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
   assert (q.returncode==0)==(fuel>=cost),(c,fuel,q.stdout,q.stderr)
   if fuel>=cost:assert re.search(r':result '+str(answer)+r'(?:\s|})',q.stdout),(c,fuel,answer,q.stdout)
   assert f':remaining {max(0,fuel-cost)}' in q.stdout and ':vectors {:capacity 4096 :used 1}' in q.stdout and ':vector-items {:capacity 65536 :used 8}' in q.stdout,(c,fuel,q.stdout)
   assert obs[label]['items']==['DIAG_VECTOR_ITEMS 8 11 8 5 2 -1 -4 -7 -10']
   if c['mode']=='stdout':assert q.stdout.startswith('probe\n'*(1 if fuel==1 else 2)),(fuel,q.stdout)
  assert obs['baseline-effect']==obs['candidate-effect'],(c,fuel,obs);rows.append({**c,'fuel':fuel,'expect':answer if fuel>=cost else None,**obs})
(w/'effect-proof.json').write_text(json.dumps({'status':'complete-native-live-cache-ASCII-slowpath-capability-and-indirect-clobber-parity','comparisons':len(rows),'instructionAudit':audit,'wire20Granted':False,'runs':rows},indent=2)+'\n');print('PASS',len(rows),'ASCII/Unicode/capability/indirect actual state comparisons')
