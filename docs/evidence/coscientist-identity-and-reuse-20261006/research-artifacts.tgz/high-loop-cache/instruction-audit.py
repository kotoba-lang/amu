from pathlib import Path
import json,struct
w=Path('/private/tmp/amu-high-loop-cache-20261006');a=json.loads((w/'meta-admission.json').read_text());out=[]
for e in a['entries']:
 blob=(w/'ports-2'/e['workload']/'native.bin').read_bytes();words=struct.unpack('<'+'I'*(len(blob)//4),blob[:len(blob)//4*4]);sites=[]
 for i,x in enumerate(words):
  if x==0xb4000065 and i+18<len(words) and words[i+2]==0x540001a0:
   seq=words[i:i+19];rv=(seq[1]>>5)&31;ri=(seq[18]>>16)&31;d=seq[18]&31;assert not any(x in [3,4,5] for x in [rv,ri,d]);assert seq[1]==0xeb05001f+(rv<<5);assert seq[3]==0xaa0003e5+(rv<<16);assert seq[4:12]==(0xf9409cf0,0xf9400210,0xd10004b1,0xeb10023f,0x54000043,0,0xf940a0f0,0x8b111210);assert seq[12:15]==(0xa9400e11,0xf940a4e4,0x8b110c84);assert seq[15]==0xeb03001f+(ri<<5);assert seq[16:18]==(0x54000043,0);assert seq[18]==0xf8607880+(ri<<16)+d;sites.append(i*4)
 assert len(sites)==e['cachedReadSites'],(e['workload'],len(sites),e['cachedReadSites']);out.append({'workload':e['workload'],'actualMachineCacheSites':len(sites),'byteOffsets':sites})
(w/'instruction-audit.json').write_text(json.dumps({'status':'complete-actual-original19-machine-cache-template-branch-and-register-audit','sites':sum(x['actualMachineCacheSites'] for x in out),'entries':out},indent=2)+'\n');print('PASS all actual cache templates, branch targets and register disjointness')
