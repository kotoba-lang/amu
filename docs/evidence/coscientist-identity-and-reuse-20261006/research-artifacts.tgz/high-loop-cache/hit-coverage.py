from pathlib import Path
import json,hashlib,struct,subprocess,os,re
w=Path('/private/tmp/amu-high-loop-cache-20261006');base=Path('/private/tmp/amu-affine-read-direct-20261006');pc=json.loads((w/'ports-correctness.json').read_text());bc=json.loads((base/'ports-correctness.json').read_text());audit=[]
for e in pc['entries']:
 name=e['workload'];bp=base/'ports-2'/name/'native.bin';np=w/'ports-2'/name/'native.bin';old=next(x for x in bc['entries'] if x['workload']==name);changed=np.read_bytes()!=bp.read_bytes();assert changed==(name=='matmult-int'),(name,changed)
 audit.append({'workload':name,'changed':changed,'baselineSha256':old['nativeSha256'],'candidateSha256':e['nativeSha256'],'baselineBytes':bp.stat().st_size,'candidateBytes':np.stat().st_size})
e=next(x for x in pc['entries'] if x['workload']=='matmult-int');p=w/'ports-2'/'matmult-int'/'native.bin';data=p.read_bytes();words=list(struct.unpack('<'+'I'*(len(data)//4),data));sites=[]
for i,v in enumerate(words[:-19]):
 if v==0xb4000065 and words[i+2]==0x540001a0:
  # Only the cache's exact cbz x5,+3 / cmp / b.eq+13 / mov-key template.
  assert words[i+1]&0xffe0fc1f==0xeb00001f
  sites.append(i)
assert len(sites)==2,sites
trap=len(words);words.append(0xd4200000)
for i in sites:
 delta=trap-(i+2);assert 0<delta<(1<<18);words[i+2]=0x54000000|((delta&0x7ffff)<<5)
patched=w/'matmult-hit-trap-diagnostic.bin';patched.write_bytes(struct.pack('<'+'I'*len(words),*words));rows=[]
for run in e['runs']:
 n=run['n'];env=dict(os.environ,KEXE_FUEL='16777216',KEXE_STRUCTURED_REPORT='1');env.pop('KEXE_COMMAND',None)
 q=subprocess.run([str(w/'clobber-full-state-loader'),str(patched),str(e['offset']),'1','aarch64','-',str(n)],env=env,capture_output=True,text=True)
 if n==0:assert q.returncode==0
 else:assert q.returncode!=0 and 'SIGTRAP' in q.stderr
 rows.append({'n':n,'hitTrapReached':n!=0,'exit':q.returncode,'report':q.stdout,'trap':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)})
(w/'hit-coverage.json').write_text(json.dumps({'status':'complete-native-original-hit-path-reached','diagnosticOnly':True,'notTimingArtifact':True,'method':'Replace only each cache equality-hit branch with a branch to an appended SIGTRAP; original offsets and all other instructions unchanged. Original positive canonical n reaches hit diagnostic; n0 returns unchanged. Diagnostic establishes existence only, no hit count or performance claim.','cacheTemplateWordOffsets':sites,'trapWordOffset':trap,'candidateSha256':hashlib.sha256(data).hexdigest(),'diagnosticSha256':hashlib.sha256(patched.read_bytes()).hexdigest(),'runs':rows,'hypothesisCorrection':'Initially suspected alternating distinct handles from the noncanonical illustrative port. Pinned canonical full batch uses one 2001-item vector with A/B offsets800/1200. Both reads reuse the same validated descriptor. Actual native hit diagnostic falsifies no-hit suspicion.','guestAudit':audit},indent=2)+'\n')
print('PASS only matmult changes; actual cache-hit path reached for all positive canonical n')
