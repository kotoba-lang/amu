from pathlib import Path
w=Path('/private/tmp/amu-multi-cold-20261005');s=(w/'fixture-proof.py').read_text();scope={};exec(s[:s.index('env=dict(')],scope);scope['chunks']={label:(w/(label+'.stdout')).read_text() for label in ['candidate-test','candidate-real','baseline-real']};exec(s[s.index('names=[f[0]'):],scope)
