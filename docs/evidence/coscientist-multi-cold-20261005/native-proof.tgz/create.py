from pathlib import Path
import shutil,json
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-multi-cold-20261005');base=Path('/private/tmp/amu-scalar-tree-20261005');prior=Path('/private/tmp/amu-cold-fuel-20261005')
g=(prior/'41-a64gen-prototype.kotoba').read_text()
helper=''';; Count syntactic charge sites, not dynamic executions. Only charges of
;; already proved inline wrappers are included; unknown calls are not counted.
;; Field15 is private and reset before the existing function prescan.
(defn- gn-cold-count [M :vector-i64 j :i64] :vector-i64
  (let [op (gn-op M j)
        charge (if (= op OP-FUEL) true
                 (if (= op OP-CALL)
                   (let [w (gn-call-wrapper M j (gn-sir M j IF-A) (gn-sir M j IF-B) (gn-sir M j IF-C))]
                     (if (>= w 1024) (>= w 1536) (>= w 256))) false))]
    (if charge (gn-gs M 15 (inc (gn-g M 15))) M)))

'''
a='(defn- gn-pre [M';assert g.count(a)==1;g=g.replace(a,helper+a)
a='(gn-pre (gn-pre-op M j) (inc j))';assert g.count(a)==1;g=g.replace(a,'(gn-pre (gn-cold-count (gn-pre-op M j) j) (inc j))')
a='M1 (if (= (gn-g M gn-f-fuel) 1)';assert g.count(a)==1;g=g.replace(a,'M1 (if (>= (gn-g M 15) 2)')
(w/'41-a64gen-prototype.kotoba').write_text(g);files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
for ext in ['bin','offset']:shutil.copyfile(base/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile(base/'kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['build.py','check-ports.py','bulk-state.py','fixture-proof.py','zero-entry-proof.py','span-proof.py','prepare-timing.py','remote-all.py']:
 s=(prior/name).read_text().replace('amu-cold-fuel-20261005','amu-multi-cold-20261005').replace('amu-zebulun-cold-fuel-20261005','amu-zebulun-multi-cold-20261005').replace('affc8563aabef45bb29167fd1a73d5d065e70890','ca907def12d5c55a826745f8b1a18812829331bf')
 (w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'hypothesis':'Same exact cold layout/span fallback as preceding experiment, but admit only functions with >=2 syntactic charge sites in SIR prescan (explicit FUEL plus charges of exactly admitted inline wrappers). Single-site functions use legacy emission. Field15 reset perfunction; no names, profile hints, body duplication, batching, precharge or changed fuel/commit semantics.','promotion':'Native fixedpoint with actual main offsets; all19 result/exactfuel/exhaustion and Pico state; lowfuel/partial state and single/multiple-site audits; freshquiet30 allchanged originalC triples >=5% and gap>sumSD, no separated regression.','sourceHead':'ca907def12d5c55a826745f8b1a18812829331bf','exception':'One-off compiler algorithm authoring, not mechanical refactoring'},indent=2)+'\n')
