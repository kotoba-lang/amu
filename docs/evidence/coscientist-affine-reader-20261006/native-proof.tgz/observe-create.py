from pathlib import Path
import shutil,json,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-affine-reader-20261005');b=Path('/private/tmp/amu-scalar-mask-reuse-20261005');g=(r/'seed/41-a64gen.kotoba').read_text()
helper=''';; Diagnostic only: actual frontend function metadata and bounded SIR prefix.
(defn- gn-reader-dump [M :vector-i64 f :i64 j :i64 stop :i64] :vector-i64
 (if (>= j stop) M
  (let [printed (io-out (string-concat "READSIR " (string-concat (string-from-i64 f)
   (string-concat " " (string-concat (string-from-i64 j) (string-concat " "
   (string-concat (string-from-i64 (gn-op M j)) (string-concat " "
   (string-concat (string-from-i64 (gn-sir M j IF-A)) (string-concat " "
   (string-concat (string-from-i64 (gn-sir M j IF-B)) (string-concat " "
   (string-concat (string-from-i64 (gn-sir M j IF-C)) "\\n")))))))))))))]
   (gn-reader-dump M f (inc j) stop))))
'''
pos=g.index('(defn- gn-op-fn2 [');g=g[:pos]+helper+g[pos:]
old='                leaf (gn-g M2 gn-f-leaf)]';assert g.count(old)==1
fields=['f','F','leaf','(gn-fnf M2 f FF-NPARAMS)','(gn-fnf M2 f FF-PT0)','(gn-fnf M2 f (inc FF-PT0))','(gn-fnf M2 f FF-RTYPE)','(gn-fnf M2 f FF-NSLOTS)','(gn-fnf M2 f FF-DEPTH)'];s='"\\n"'
for x in reversed(fields):s='(string-concat (string-from-i64 '+x+') (string-concat " " '+s+'))'
g=g.replace(old,'                leaf (gn-g M2 gn-f-leaf)\n                printed (io-out (string-concat "READMETA " '+s+'))\n                dumped (if (= np 2) (gn-reader-dump M2 f i (gn-min (+ i 16) (vector-at M2 MM-SIR-N))) M2)]')
(w/'41-observer.kotoba').write_text(g)
files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')]
(w/'observer-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
for ext in ['bin','offset']:shutil.copyfile(b/('seed-4.'+ext),w/('seed-0.'+ext))
shutil.copyfile(b/'kexe-loader',w/'kexe-loader')
(w/'baseline-41-a64gen.kotoba').write_text((r/'seed/41-a64gen.kotoba').read_text())
(w/'hypothesis.json').write_text(json.dumps({'status':'registered-before-native-build-or-timing','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'hypothesis':'Exact closed frameless vector-i64/i64->i64 affine index reader composition, preserving original caller frame, wrapping index arithmetic, fuel transaction and handle/index checks. No hoisting or computation-result reuse.','qualification':'Actual all19 admission; independent signed/wrapping/invalidhandle/index/fuel/state/open imports; nativefixedpoint; fresh30 quiet rotatingtriples everychangedworkload same1.05+summedSD; fullproductgates/integrated/corpus before promotion.','exception':'One-off new Kotoba compiler algorithm and diagnostic authoring, no existing refactor rule covers it; isolated prototype leaves product unchanged.'},indent=2)+'\n')
old=Path('/private/tmp/amu-scalar-mask-call-20261005/meta-observe.py').read_text().replace('amu-scalar-mask-call-20261005','amu-affine-reader-20261005').replace('meta-unity','observer-unity').replace("['md5sum','nettle-sha256']","['wikisort']")
(w/'observe.py').write_text(old)
