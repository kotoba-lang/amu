from pathlib import Path
import json,subprocess,os,re,importlib.util
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-affine-reader-20261005');spec=importlib.util.spec_from_file_location('fixture',w/'baseline-a64gen-fixtures.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);ids=json.loads((w/'reader-fixture-ids.json').read_text());images={l:(w/(l+'-fixture.bin'),m.blob_from((w/(l+'-reader.stdout')).read_text())[1]) for l in ['baseline','candidate']};rows=[]
for t in [0,1,3,6,7,8]:
 f=ids[f'ar_k6_f1_t{t}_raw']
 for handle in [m.MIN,-1,1,m.MAX]:
  for fuel in [1,2,3]:
   pair={}
   for label,(p,fc) in images.items():
    e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(p),str(fc[f]),'3','aarch64','-',str(handle),'0','37'],env=e,capture_output=True,text=True);assert q.returncode!=0 and ':fuel ' in q.stdout,(label,handle,fuel,q.stdout,q.stderr);pair[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
   assert pair['baseline']==pair['candidate'],(handle,fuel,pair);rows.append({'t':t,'handle':handle,'fuel':fuel,**pair})
(w/'invalid-handles-proof.json').write_text(json.dumps({'status':'complete-native-invalid-handle-extreme-parity','comparisons':len(rows),'runs':rows},indent=2)+'\n');print('PASS',len(rows),'invalid extreme handle and fuel comparisons')
