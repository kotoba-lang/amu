from pathlib import Path
import importlib.util,os,subprocess,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-affine-reader-20261005');spec=importlib.util.spec_from_file_location('fixture',w/'baseline-a64gen-fixtures.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
first=len(m.FIX)+1;targets=[];callers=[];ks=[m.MIN,-7,-2,-1,0,1,2,3,7,m.MAX]
for ki,k in enumerate(ks):
 for charge in [0,1]:
  fn=f'ar_k{ki}_f{charge}';targets.append(fn)
  m.fx(fn,2,2,([('FUEL',)] if charge else [])+[('LABEL',fn+'_entry'),('LGET',0,1),('LGET',1,2),('CONST',2,k),('BIN','BOP-MUL',1),('RT','RT-VECTOR-AT',0,2),('RET',0)])
  for t in [0,1,3,6,7,8]:
   caller=fn+f'_t{t}';body=[('FUEL',)]+[('CONST',j,11-3*j) for j in range(8)]+[('VEC',0,8),('LSET',3,0)]
   body += [('CONST',j,100+j) for j in range(t)]+[('LGET',t,3),('LGET',t+1,1),('CALL',fn,t,2)]
   for j in range(t-1,-1,-1):body += [('BIN','BOP-ADD',j)]
   body += [('LGET',1,2),('BIN','BOP-ADD',0),('RET',0)];m.fx(caller,2,3,body)
   callers.append({'name':caller,'k':k,'charge':charge,'t':t,'nargs':2,'refusal':False})
   raw=caller+'_raw';m.fx(raw,3,3,[('FUEL',)]+[('CONST',j,100+j) for j in range(t)]+[('LGET',t,1),('LGET',t+1,2),('CALL',fn,t,2)]+[('BIN','BOP-ADD',j) for j in range(t-1,-1,-1)]+[('LGET',1,3),('BIN','BOP-ADD',0),('RET',0)])
   callers.append({'name':raw,'k':k,'charge':charge,'t':t,'nargs':3,'refusal':False})
for mode in ['wrong-type','extra','frame','other-op']:
 fn='ar_refuse_'+mode;targets.append(fn);b=[('FUEL',),('LGET',0,1),('LGET',1,2),('CONST',2,2),('BIN','BOP-ADD' if mode=='other-op' else 'BOP-MUL',1),('RT','RT-VECTOR-AT',0,2)]
 if mode=='extra':b += [('CONST',1,1),('BIN','BOP-ADD',0)]
 b += [('RET',0)];m.fx(fn,2,3 if mode=='frame' else 2,b)
 caller=fn+'_call';m.fx(caller,2,3,[('FUEL',)]+[('CONST',j,11-3*j) for j in range(8)]+[('VEC',0,8),('LSET',3,0),('LGET',0,3),('LGET',1,1),('CALL',fn,0,2),('LGET',1,2),('BIN','BOP-ADD',0),('RET',0)]);callers.append({'name':caller,'k':2,'charge':1,'t':0,'nargs':2,'refusal':mode})
ids={x[0]:i+1 for i,x in enumerate(m.FIX)}
# Parameter/result metadata are authoritative inputs to recognition, not inferred from fixture names.
typed='''(defn- ar-types [M :vector-i64 f :i64] :vector-i64
 (if (>= f LAST) M
  (ar-types (-> M (t-put (+ MM-FN-BASE (* f MM-FN-W) FF-PT0) TY-VEC)
                 (t-put (+ MM-FN-BASE (* f MM-FN-W) (+ FF-PT0 1)) TY-I64)
                 (t-put (+ MM-FN-BASE (* f MM-FN-W) FF-RTYPE) TY-I64)) (inc f))))
'''.replace('LAST',str(len(m.FIX)+1))
text=m.kotoba(True).replace('(defn- seed-main [] :i64',typed+'(defn- seed-main [] :i64',1)
needle='        M0 (t-mask-types (t-load (t-init)) %d)'%m.MASK_TYPED_FIRST
assert text.count(needle)==1
text=text.replace(needle,needle.replace('M0','MT')+f'\n        MTyped (ar-types MT {first})\n        M0 (t-put MTyped (+ MM-FN-BASE (* {ids["ar_refuse_wrong-type"]} MM-FN-W) FF-PT0) TY-I64)')
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];images={}
for label in ['baseline','candidate']:
 backend=w/('baseline-41-a64gen.kotoba' if label=='baseline' else '41-a64gen-prototype.kotoba');g=backend.read_text()
 if label=='candidate':
  s='"\\n"'
  for x in reversed(['i','f','t','reader']):s='(string-concat (string-from-i64 '+x+') (string-concat " " '+s+'))'
  g=g.replace('reader (gn-affine-reader M i f n)]','reader (gn-affine-reader M i f n)\n        printed (if (> reader 0) (io-out (string-concat "READCALL " '+s+')) 0)]')
 src=w/(label+'-reader.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+g+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+text)
 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'-reader.kseed'))]),('extract',['extract-native',str(w/(label+'-reader.kseed')),'--symbol','main','--output',str(w/(label+'-reader.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-reader-'+mode+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,mode,q.stdout[-600:],q.stderr)
  if mode=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'-reader.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'-reader.stdout')).write_text(q.stdout);assert q.returncode==0,(label,q.stdout[-300:],q.stderr)
 blob,fc=m.blob_from(q.stdout);path=w/(label+'-fixture.bin');path.write_bytes(blob);images[label]=(path,fc)
 if label=='candidate':
  sites=[list(map(int,l.split()[1:])) for l in q.stdout.splitlines() if l.startswith('READCALL ')];admitted={x[1] for x in sites};expected={ids[x] for x in targets if not x.startswith('ar_refuse')};assert admitted==expected,(admitted,expected);assert len(sites)==480 and len(set(map(tuple,sites)))==240
(w/'reader-fixture-ids.json').write_text(json.dumps(ids,indent=2)+'\n');(w/'reader-callers.json').write_text(json.dumps(callers,indent=2)+'\n')
rows=[];vals=[m.MIN,-(1<<62),-7,-1,0,1,2,3,4,7,8,(1<<62),m.MAX];loader='/private/tmp/amu-context-call-20261005/clobber-state-loader'
for c in callers:
 f=ids[c['name']]
 for idx in vals:
  for live in [m.MIN,37,m.MAX]:
   for fuel in [1,2,3,16777216]:
    args=[idx,live] if c['nargs']==2 else [0,idx,live];observed={};expect=m.s64(idx+c['k']) if c['refusal']=='other-op' else m.s64(idx*c['k']);valid=c['nargs']==2 and 0<=expect<8 and fuel>=1+c['charge']
    answer=m.s64(11-3*expect+sum(100+j for j in range(c['t']))+live+(1 if c['refusal']=='extra' else 0)) if valid else None
    for label,(p,fc) in images.items():
     e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
     q=subprocess.run([loader,str(p),str(fc[f]),str(len(args)),'aarch64','-',*map(str,args)],env=e,capture_output=True,text=True);assert ':fuel ' in q.stdout,(label,c,q.stdout,q.stderr)
     observed[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
     if valid:assert q.returncode==0 and re.search(r':result '+str(answer)+r'(?:\s|})',q.stdout),(label,c,idx,live,fuel,answer,q.stdout,q.stderr)
     else:assert q.returncode!=0,(label,c,idx,fuel,q.stdout)
    assert observed['baseline']==observed['candidate'],(c,idx,live,fuel,observed)
    rows.append({'caller':c['name'],'index':idx,'live':live,'fuel':fuel,'expect':answer,**observed})
 print('PASS hand result/trap and full state',c['name'],flush=True)
(w/'reader-state-proof.json').write_text(json.dumps({'status':'complete-native-reader-hand-oracles-and-supervisor-parity','comparisons':len(rows),'admittedSites':len(set(map(tuple,sites))), 'emissionPasses':2,'fixtures':len(m.FIX),'fields':'exit,result,fuel,heap,stringpool,vectors,vectoritems,diagnosticitems,traps; actual vector allocation and signed wrapping index/invalid handle/lowfuel','runs':rows},indent=2)+'\n');print('PASS',len(rows),'native independent hand-oracle/full supervisor comparisons',flush=True)
