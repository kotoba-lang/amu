from pathlib import Path
import json,re,collections
w=Path('/private/tmp/amu-affine-reader-20261005');j=json.loads((w/'reader-state-proof.json').read_text());cs={x['name']:x for x in json.loads((w/'reader-callers.json').read_text())};assert j['comparisons']==len(j['runs'])==38064 and len(cs)==244;keys=set();success=0
for x in j['runs']:
 c=cs[x['caller']];key=(x['caller'],x['index'],x['live'],x['fuel']);assert key not in keys;keys.add(key);a=x['baseline'];b=x['candidate'];assert a==b
 rem=x['fuel']-1-c['charge'] if x['expect'] is not None else x['fuel']-1
 if c['charge'] and x['fuel']==1:rem=0
 for z in [a,b]:
  report=z['report'];fuel=re.search(r':fuel \{:initial (\d+) :remaining (\d+)\}',report);assert fuel and list(map(int,fuel.groups()))==[x['fuel'],rem],(key,report,rem)
  assert ':heap {:capacity 4096 :used 0}' in report and ':string-pool {:capacity 65536 :used 0}' in report
  v=1 if c['nargs']==2 else 0;n=8 if v else 0;assert f':vectors {{:capacity 4096 :used {v}}}' in report and f':vector-items {{:capacity 65536 :used {n}}}' in report
  expecteditems='DIAG_VECTOR_ITEMS 8 11 8 5 2 -1 -4 -7 -10' if v else 'DIAG_VECTOR_ITEMS 0';assert z['items']==[expecteditems]
  if x['expect'] is not None:assert z['exit']==0 and re.search(r':result '+str(x['expect'])+r'(?:\s|})',report);success+=int(z is a)
  else:assert z['exit']!=0 and z['traps']
for name in cs:assert sum(k[0]==name for k in keys)==156
imp=json.loads((w/'reader-import-proof.json').read_text());assert imp['comparisons']==len(imp['runs'])==96
for x in imp['runs']:
 assert x['baseline-open']==x['candidate-open'];z=x['candidate-open'];f=x['fuel'];rem=max(0,f-2);v=int(f>=2)
 assert f':fuel {{:initial {f} :remaining {rem}}}' in z['report'];assert f':vectors {{:capacity 4096 :used {v}}}' in z['report'];assert f':vector-items {{:capacity 65536 :used {v}}}' in z['report'];assert z['items']==[f'DIAG_VECTOR_ITEMS {v}'+(' 0' if v else '')]
(w/'state-audit.json').write_text(json.dumps({'status':'complete-independent-observation-and-coverage-audit','comparisons':38064,'uniqueCallers':244,'perCallerCases':156,'successfulCases':success,'trappingCases':38064-success,'fuelRemainingAndAllMemoryCountsHandDerived':True,'allAllocatedItemsHandDerived':True,'importFuelAllocationAndItemsHandDerivedComparisons':96},indent=2)+'\n');print('PASS',success,'successful and',38064-success,'trapping observations; fuel/resources/items independently checked')
