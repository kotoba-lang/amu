from pathlib import Path
import os,subprocess,re,json,struct
w=Path('/private/tmp/amu-affine-reader-20261005');scope={};s=(w/'reader-proof.py').read_text();exec(s[:s.index('env=dict(')],scope);m=scope['m'];r=scope['r'];ids=scope['ids'];typed=scope['typed'];target=ids['ar_k6_f1'];m.fx('ar_replacement',2,2,[('FUEL',),('CONST',0,1),('RT','RT-VECTOR-ALLOC',0,1),('CONST',0,77),('RET',0)]);replacement=len(m.FIX)
text=m.kotoba(True).replace('(defn- seed-main [] :i64',typed+'(defn- seed-main [] :i64',1);needle='        M0 (t-mask-types (t-load (t-init)) %d)'%m.MASK_TYPED_FIRST;text=text.replace(needle,needle.replace('M0','MT')+f'\n        MTyped (ar-types MT {scope["first"]})\n        M0 (t-put MTyped (+ MM-FN-BASE (* {ids["ar_refuse_wrong-type"]} MM-FN-W) FF-PT0) TY-I64)')
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];images={}
for label in ['baseline-open','candidate-open','candidate-closed']:
 test=text if label.endswith('closed') else text.replace('(gn-run M0)',f'(gn-run-open M0 {target} 1)',1)
 g=(w/('baseline-41-a64gen.kotoba' if label.startswith('baseline') else '41-a64gen-prototype.kotoba')).read_text();src=w/(label+'-reader-import.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+g+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+test)
 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'-reader-import.kseed'))]),('extract',['extract-native',str(w/(label+'-reader-import.kseed')),'--symbol','main','--output',str(w/(label+'-reader-import.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-reader-import-'+mode+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,mode,q.stdout[-600:],q.stderr)
  if mode=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'-reader-import.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'-reader-import.stdout')).write_text(q.stdout);assert q.returncode==0,(label,q.stdout[-300:],q.stderr)
 blob,fc=m.blob_from(q.stdout);patched=bytearray(blob);struct.pack_into('<I',patched,fc[target],0x14000000|(((fc[replacement]-fc[target])//4)&0x3ffffff));path=w/(label+'-reader-import-linked.bin');path.write_bytes(patched);images[label]=(path,fc)
rows=[]
for t in [0,1,3,6,7,8]:
 caller=f'ar_k6_f1_t{t}_raw';f=ids[caller]
 for idx in [m.MIN,-1,0,m.MAX]:
  for fuel in [1,2,3,16777216]:
   pair={}
   for label,(p,fc) in images.items():
    e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(p),str(fc[f]),'3','aarch64','-','0',str(idx),'37'],env=e,capture_output=True,text=True);assert ':fuel ' in q.stdout,(label,caller,q.stdout,q.stderr);pair[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
   assert pair['baseline-open']==pair['candidate-open'],(caller,idx,fuel,pair)
   if fuel>=2:
    answer=77+37+sum(100+j for j in range(t));assert re.search(r':result '+str(answer)+r'(?:\s|})',pair['candidate-open']['report']);assert pair['candidate-open']!=pair['candidate-closed'],(caller,idx,fuel,pair)
   rows.append({'caller':caller,'idx':idx,'fuel':fuel,**pair})
 print('PASS actual allocating import replacement',caller,flush=True)
(w/'reader-import-proof.json').write_text(json.dumps({'status':'complete-native-reader-open-allocating-import-parity','comparisons':len(rows),'signature':'vector-i64/i64->i64; replacement charges fuel, allocates vector and returns77; diagnostic allocator clobbersx7','closedControlsDiffer':True,'runs':rows},indent=2)+'\n')
