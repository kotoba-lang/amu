from pathlib import Path
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-affine-reader-20261005');g=(w/'baseline-41-a64gen.kotoba').read_text()
proof=''';; Exact closed frameless affine-index vector reader. Preserve caller frame.
;; The callee's entry fuel remains private in x8 until success or exhaustion;
;; invalid handle/index traps retain pre-call published fuel. No check hoisting.
(defn- gn-affine-reader [M :vector-i64 i :i64 f :i64 n :i64] :i64
 (let [p (gn-fnf M f FF-SIR) fuel (if (= (gn-op M (inc p)) OP-FUEL) 1 0)
       q (gn-skiplab M (+ p 1 fuel))]
  (if (and (> f 0) (< f (vector-at M MM-FN-N)) (> p 0)
           (= (gn-g M gn-f-leaf) 0) (not (gn-clamp-open M f)) (= n 2)
           (not= (gn-op M (inc i)) OP-RES2)
           (= (gn-fnf M f FF-NPARAMS) 2) (= (gn-fnf M f FF-PT0) TY-VEC)
           (= (gn-fnf M f (inc FF-PT0)) TY-I64) (= (gn-fnf M f FF-RTYPE) TY-I64)
           (= (gn-fnf M f FF-NSLOTS) 2) (<= (gn-fnf M f FF-DEPTH) 3)
           (= (gn-op M p) OP-FN) (= (gn-sir M p IF-A) f) (= (gn-sir M p IF-B) 2)
           (= (gn-sir M p IF-C) 2)
           (= (gn-op M q) OP-LGET) (= (gn-sir M q IF-A) 0) (= (gn-sir M q IF-B) 1)
           (= (gn-op M (+ q 1)) OP-LGET) (= (gn-sir M (+ q 1) IF-A) 1) (= (gn-sir M (+ q 1) IF-B) 2)
           (= (gn-op M (+ q 2)) OP-CONST) (= (gn-sir M (+ q 2) IF-A) 2)
           (= (gn-op M (+ q 3)) OP-BIN) (= (gn-sir M (+ q 3) IF-A) BOP-MUL)
           (= (gn-sir M (+ q 3) IF-B) 1) (= (gn-sir M (+ q 3) IF-C) 0)
           (= (gn-op M (+ q 4)) OP-RT) (= (gn-sir M (+ q 4) IF-A) RT-VECTOR-AT)
           (= (gn-sir M (+ q 4) IF-B) 0) (= (gn-sir M (+ q 4) IF-C) 2)
           (= (gn-op M (+ q 5)) OP-RET) (= (gn-sir M (+ q 5) IF-A) 0)
           (= (gn-op M (+ q 6)) OP-END) (= (gn-sir M (+ q 6) IF-A) f)) q 0)))
(defn- gn-call-affine-reader [M :vector-i64 i :i64 t :i64 f :i64 q :i64] :vector-i64
 (let [p (gn-fnf M f FF-SIR) charged (= (gn-op M (inc p)) OP-FUEL)
       k (gn-sir M (+ q 2) IF-B) shift (gn-pow2 k)]
  (-> M (gn-into 0 t) (gn-into 1 (inc t)) (gn-ctx)
      (cond-> charged (gn-emit (enc-ldr 8 7 CTX-FUEL)) charged (gn-mask-charge))
      (cond-> (> shift 0) (gn-emit (gn-e-lsl 1 1 shift))
              (<= shift 0) (gn-mov-imm 2 k) (<= shift 0) (gn-emit (enc-mul 1 1 2)))
      (gn-hchk 0 312 320) (gn-vidx 1) (gn-emit (gn-e-ldrr 0 16 17 1))
      (cond-> charged (gn-emit (enc-str 8 7 CTX-FUEL))) (gn-take i t 0))))
'''
pos=g.index('(defn- gn-op-call [');g=g[:pos]+proof+g[pos:]
old='mask (gn-scalar-mask M i f n)]';assert g.count(old)==1;g=g.replace(old,'mask (gn-scalar-mask M i f n) reader (gn-affine-reader M i f n)]')
old='(cond (> mask 0)';assert g.count(old)==1;g=g.replace(old,'(cond (> reader 0) (gn-call-affine-reader M i t f reader) (> mask 0)')
(w/'41-a64gen-prototype.kotoba').write_text(g)
files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')]
(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
for name in ['build.py','check-ports.py']:(w/name).write_text((Path('/private/tmp/amu-scalar-mask-reuse-20261005')/name).read_text().replace('amu-scalar-mask-reuse-20261005','amu-affine-reader-20261005'))
# Diagnostic observer emits receipts without changing emitted guest instructions.
s='"\\n"'
for x in reversed(['i','f','t','reader']):s='(string-concat (string-from-i64 '+x+') (string-concat " " '+s+'))'
g=g.replace('reader (gn-affine-reader M i f n)]','reader (gn-affine-reader M i f n)\n        printed (if (> reader 0) (io-out (string-concat "READCALL " '+s+')) 0)]')
(w/'observer-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
s=(w/'observe.py').read_text().replace(" if x['workload'] in ['wikisort']",'').replace('MASKCALL ','READCALL ').replace('scalarMaskCallSites','affineReaderCallSites');(w/'observe-admission.py').write_text(s)
print('prototype exact body matches observed native value SIR; product untouched')
