from pathlib import Path
import json,hashlib,shutil
w=Path('/private/tmp/amu-affine-join-20261005');base=Path('/private/tmp/amu-clamp-call-20261005');b=json.loads((base/'ports-correctness.json').read_text());c=json.loads((w/'ports-correctness.json').read_text());gen=json.loads((w/'generations.json').read_text());package=w/'timing-package';package.mkdir(exist_ok=True);names=[]
for e in c['entries']:
 old=next(x for x in b['entries'] if x['workload']==e['workload'])
 if e['nativeSha256']==old['nativeSha256']:continue
 name=e['workload'];names.append(name);d=package/name;candidate=d/'candidate';candidate.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/'ports-2'/name/'native.bin',candidate/'native.bin');shutil.copyfile(base/'ports-2'/name/'native.bin',d/'baseline-native.bin')
 (candidate/'manifest.json').write_text(json.dumps({'workload':name,'sourceSha256':e['sourceSha256'],'baselineSourceSha256':old['sourceSha256'],'nativeSha256':e['nativeSha256'],'offset':e['offset'],'baselineNativeSha256':old['nativeSha256'],'baselineOffset':old['offset'],'compilerGenerationSha256':{str(x['generation']):x['sha256'] for x in gen[1:]},'producerCompilerSha256':hashlib.sha256((base/'seed-4.bin').read_bytes()).hexdigest(),'hypothesis':'Bounded constant-dominance proof across labels plus wrapping affine index specialization; closed exact checked-write composition, retained caller frame/fuel transaction.','sourceHead':'83fa3b30ba1c70bf00fed01a0529e1c11e5b8dc2'},indent=2)+'\n')
(package/'workloads.json').write_text(json.dumps(names,indent=2)+'\n')
for src,name in [(base/'ports-correctness.json','product-proof.json'),(w/'ports-correctness.json','candidate-proof.json'),(w/'bulk-state.json','bulk-state.json'),(w/'generations.json','generations.json'),(w/'import-proof.json','import-proof.json')]:shutil.copyfile(src,package/name)
# Only final native hand-oracle evidence permits measurement; fuller state proof
# can run independently, remains mandatory before any product promotion.
proof=json.loads((w/'native-preflight.json').read_text());assert proof['nativeLayoutsByteEqual'] and not proof['mayPromote'];(package/'measurement-preflight.json').write_text(json.dumps(proof,indent=2)+'\n');print('prepared pinned timing package',names)
