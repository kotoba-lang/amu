from pathlib import Path
import importlib.util,subprocess,os,re,json,struct,types,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-affine-join-20261005');base=Path('/private/tmp/amu-clamp-call-20261005')
sp=importlib.util.spec_from_file_location('fx',w/'baseline-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
def aff_sign(name,width,charged):
 mask=(1<<width)-1;half=1<<(width-1)
 m.fx(name,1,2,([('FUEL',)] if charged else [])+[('LGET',0,1),('CONST',1,mask),('BIN','BOP-AND',0),('LSET',2,0),('LGET',0,2),('CONST',1,half),('CMP','CC-GE',0),('BRZ',0,name+'_lo'),('LGET',0,2),('CONST',1,1<<width),('BIN','BOP-SUB',0),('BR',name+'_end'),('LABEL',name+'_lo'),('LGET',0,2),('LABEL',name+'_end'),('RET',0)])
cases=[([1,8,16,32][k%4],(k>>2)&1,(k>>1)&1,k&1,False) for k in range(8)]+[(16,1,0,1,False),(16,1,0,1,True)];targets=[]
GEOMETRY=[(0,0,0),(3,0,m.MAX),(1,1,2),(3,-1,1),(m.MIN,m.MIN,1),(1,m.MAX,m.MAX),(1,m.MIN,2),(3,m.MAX,2),(m.MAX,1,m.MIN),(m.MAX,1,1),(0,-1,m.MIN),(-1,0,0),(4,0,0)]
for k,(width,outer,inner,write,extra) in enumerate(cases):
 s=f'aw_sign{k}';p=f'aw_put{k}';f=f'aw_aff{k}';aff_sign(s,width,inner)
 m.fx(p,3,3,([('FUEL',)] if write else [])+[('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('RET',0)])
 body=([('FUEL',)] if outer else [])+[('LABEL',f+'_entry'),('LGET',0,1),('LGET',1,2),('LGET',2,3),('LGET',3,4),('BIN','BOP-MUL',2)]+([('LABEL',f+'_mid')] if extra else [])+[('BIN','BOP-ADD',1),('LGET',2,5),('CALL',s,2,1),('CALL',p,0,3),('RET',0)];m.fx(f,5,5,body)
 for t in [0,1,2,3,4]:
  c=f'aw_call{k}_{t}';cb=[('FUEL',),('CONST',0,11),('CONST',1,-22),('CONST',2,33),('CONST',3,-44),('VEC',0,4),('LSET',5,0)]
  for ix in [0,1]:
   cb+=[('CONST',j,100+j) for j in range(t)]+[('LGET',t,5)]
   cb+=([('CONST',t+1,0),('CONST',t+2,0),('CONST',t+3,0)] if ix==0 else [('LGET',t+1,1),('LGET',t+2,2),('LGET',t+3,3)])+[('LGET',t+4,4),('CALL',f,t,5),('RT','RT-VECTOR-COUNT',t,1)]
   for j in range(t-1,-1,-1):cb+=[('BIN','BOP-ADD',j)]
   cb+=[('LSET',6,0)]
  cb+=[('LGET',0,5),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('LGET',1,5),('CONST',2,3),('RT','RT-VECTOR-AT',1,2),('BIN','BOP-ADD',0),('LGET',1,6),('BIN','BOP-ADD',0),('RET',0)]
  m.fx(c,4,6,cb);targets.append((c,f,width,outer,inner,write,extra,t,t<=2 and not extra))
  cost=1+2*(outer+inner+write);live=sum(100+j for j in range(t))
  for value in [m.MIN,-65537,-32769,-129,-1,0,1,127,128,255,32767,32768,m.MAX]:
   sv=value&((1<<width)-1);sv=sv-(1<<width) if sv>=(1<<(width-1)) else sv
   for b,st,kk in GEOMETRY[:8]:
    idx=m.s64(b+st*kk);assert 0<=idx<4
    expect=m.s64(sv+(sv if idx==3 else -44)+4+live);m.run(c,[b,st,kk,value],expect,fuel=cost)
  for b,st,kk in GEOMETRY[8:]:m.run(c,[b,st,kk,-1],'trap',fuel=cost)
  for fuel in range(1,cost):m.run(c,[1,1,2,0],'trap',fuel=fuel)
# Explicit constant operands and spilled local operands exercise distinct scratches.
for kind in ['constant','spilled']:
 for t in [0,2]:
  c=f'aw_{kind}_{t}';f='aw_aff8';cb=[('FUEL',),('CONST',0,11),('CONST',1,-22),('CONST',2,33),('CONST',3,-44),('VEC',0,4),('LSET',5,0)]
  if kind=='spilled':
   for slot in range(6,18):cb += [('CONST',0,slot-10),('LSET',slot,0)]
  for ix in [0,1]:
   cb += [('CONST',j,100+j) for j in range(t)]+[('LGET',t,5)]
   if ix==0:cb += [('CONST',t+1,0),('CONST',t+2,0),('CONST',t+3,0)]
   elif kind=='constant':cb += [('CONST',t+1,1),('CONST',t+2,m.MIN),('CONST',t+3,2)]
   else:cb += [('LGET',t+1,1),('LGET',t+2,2),('LGET',t+3,3)]
   cb += ([('CONST',t+4,65535)] if kind=='constant' else [('LGET',t+4,4)])+[('CALL',f,t,5),('RT','RT-VECTOR-COUNT',t,1)]
   for j in range(t-1,-1,-1):cb += [('BIN','BOP-ADD',j)]
   cb += [('LSET',18,0)]
  cb += [('LGET',0,5),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('LGET',1,5),('CONST',2,3),('RT','RT-VECTOR-AT',1,2),('BIN','BOP-ADD',0),('LGET',1,18),('BIN','BOP-ADD',0)]
  if kind=='spilled':
   for z in range(4):
    for slot in range(6,18):cb += [('LGET',1,slot),('BIN','BOP-ADD',0)]
  cb += [('RET',0)];m.fx(c,4,18,cb);targets.append((c,f,16,1,0,1,False,t,True))
  live=sum(100+j for j in range(t));bonus=4*sum(slot-10 for slot in range(6,18)) if kind=='spilled' else 0
  for val in [m.MIN,-65537,-1,0,255,32768,m.MAX]:
   actual=65535 if kind=='constant' else val;sv=actual&65535;sv=sv-65536 if sv>=32768 else sv
   m.run(c,[1,m.MIN,2,val],m.s64(sv-44+4+live+bonus),fuel=5)
  for fuel in range(1,5):m.run(c,[1,m.MIN,2,0],'trap',fuel=fuel)

# Branch-sensitive fixed operands and dominance refusal controls. Both value arms
# execute normally; the proof only recovers an immutable scalar already evaluated.
proof_targets=[]
for axis in ['k','stride']:
 for fixed in [0,1,2,4,8,1<<31,1<<62,3,-1,m.MIN,m.MAX]:
  for t in [0,2]:
   c=f'join_{axis}_{fixed}_{t}'.replace('-','neg');f='aw_aff8';cb=[('FUEL',),('CONST',0,11),('CONST',1,-22),('CONST',2,33),('CONST',3,-44),('VEC',0,4),('LSET',6,0)]
   for ix in [0,1]:
    cb += [('CONST',j,100+j) for j in range(t)]+[('LGET',t,6)]
    cb += ([('CONST',t+1,0),('CONST',t+2,0),('CONST',t+3,0)] if ix==0 else [('LGET',t+1,1),('CONST',t+2,fixed) if axis=='stride' else ('LGET',t+2,2),('CONST',t+3,fixed) if axis=='k' else ('LGET',t+3,3)])
    cb += [('LGET',t+4,4)]
    if ix==1:
     cb += [('LGET',t+5,5),('BRZ',t+5,c+'_false'),('CONST',t+5,1),('BIN','BOP-ADD',t+4),('BR',c+'_join'),('LABEL',c+'_false'),('LGET',t+4,4),('LABEL',c+'_join')]
    cb += [('CALL',f,t,5),('RT','RT-VECTOR-COUNT',t,1)]
    for j in range(t-1,-1,-1):cb += [('BIN','BOP-ADD',j)]
    cb += [('LSET',7,0)]
   cb += [('LGET',0,6),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('LGET',1,6),('CONST',2,3),('RT','RT-VECTOR-AT',1,2),('BIN','BOP-ADD',0),('LGET',1,7),('BIN','BOP-ADD',0),('RET',0)]
   m.fx(c,5,7,cb);targets.append((c,f,16,1,0,1,False,t,True));known=fixed in [0,1,2,4,8,1<<31,1<<62];proof_targets.append((c,t+(3 if axis=='k' else 2),fixed if known else None))
   live=sum(100+j for j in range(t))
   for b,st,k in GEOMETRY:
    idx=m.s64(b+(fixed if axis=='stride' else st)*(fixed if axis=='k' else k))
    for cond in [0,1]:
     for value in [m.MIN,-1,0,m.MAX]:
      v1=value&65535;v1=v1-65536 if v1>=32768 else v1;v2=m.s64(value+cond)&65535;v2=v2-65536 if v2>=32768 else v2
      arr=[v1,-22,33,-44]
      if 0<=idx<4:arr[idx]=v2;expect=m.s64(arr[0]+arr[3]+4+live)
      else:expect='trap'
      m.run(c,[b,st,k,value,cond],expect,fuel=5)
   for fuel in range(1,5):m.run(c,[0,0,0,0,0],'trap',fuel=fuel)
# Unsafe joins: overwrite only one arm, bypass the CONST, a later backedge,
# origin/function-scan work limits, and unknown writer forms. Refusal is explicit.
for shape in ['overwrite','outside','backedge','origin-limit','function-limit','res2']:
 c='join_refuse_'+shape.replace('-','_');f='aw_aff8';t=0
 cb=[('FUEL',),('CONST',0,11),('CONST',1,-22),('CONST',2,33),('CONST',3,-44),('VEC',0,4),('LSET',6,0),('LGET',0,6),('LGET',1,1),('LGET',2,2)]
 if shape=='outside':cb += [('LGET',3,3),('LGET',4,5),('BRZ',4,c+'_join'),('CONST',3,1)]
 else:cb += [('CONST',3,1)]
 if shape=='overwrite':cb += [('LGET',4,5),('BRZ',4,c+'_join'),('CONST',3,2)]
 if shape=='origin-limit':cb += [('LGET',5,5)]*258
 if shape=='function-limit':cb += [('LGET',5,5)]*4100
 if shape=='res2':cb += [('CONST',4,1),('CONST',5,2),('RES2',4)]
 cb += [('LABEL',c+'_join'),('LGET',4,4),('CALL',f,0,5)]
 if shape=='backedge':cb += [('CONST',1,0),('BRNZ',1,c+'_join')]
 cb += [('RT','RT-VECTOR-COUNT',0,1),('RET',0)];m.fx(c,5,6,cb);proof_targets.append((c,3,None))
 for cond in [0,1]:m.run(c,[0,0,0,-1,cond],4,fuel=3)

parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_VECTOR_ITEMS='134217728',KEXE_PAIRS='16777216',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800');chunks={};loader=str(w/'kexe-loader')
for label,real,seed,backend in [('candidate-test',False,w/'seed-4.bin',w/'41-a64gen-prototype.kotoba'),('candidate-real',True,w/'seed-4.bin',w/'41-a64gen-prototype.kotoba'),('baseline-real',True,base/'seed-4.bin',w/'baseline-41-a64gen.kotoba')]:
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+backend.read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real))
 if label.startswith('candidate'):
  fnids,_,_,sirs,_=m.layout_tables();probes=[]
  for c,t,expect in proof_targets:
   fid=fnids[c];p=next(j+1 for j,x in enumerate(sirs) if x[0]==m.C['OP-FN'] and x[1]==fid);end=next(j+1 for j,x in enumerate(sirs) if j+1>p and x[0]==m.C['OP-END']);call=[j+1 for j,x in enumerate(sirs) if p<j+1<end and x[0]==m.C['OP-CALL'] and x[1]==fnids['aw_aff8']][-1]
   # A preceding function's CALL cannot be selected: stop at this fn END.
   end=next(j+1 for j,x in enumerate(sirs) if j+1>p and x[0]==m.C['OP-END']);assert call<end
   probes += [f'        PM{len(probes)} (gn-restore-const (gn-op-fn M3 {p} {fid} 5) {call} {t})',f'        PO{len(probes)} (t-out (string-concat "PROOF {c} " (string-concat (string-from-i64 (gn-dk PM{len(probes)} {t})) (string-concat " " (string-concat (string-from-i64 (gn-dv PM{len(probes)} {t})) "\\n")))))']
  text=src.read_text();needle='        sign_open (gn-clamp MS %d %d 1)]' % (next(i+1 for i,x in enumerate(m.FIX) if x[0]=='clamp_dummy_never') if False else next(i+1 for i,x in enumerate(m.FIX) if x[0]=='cl_sign2'),next(i+1 for i,x in enumerate(sirs) if x[0]==m.C['OP-CALL'] and x[1]==fnids['cl_bound2']))
  # Read the exact final let binding directly; the generated fixture API pins it.
  import re as _re
  matches=list(_re.finditer(r'        sign_open \(gn-clamp MS [0-9]+ [0-9]+ 1\)\]',text));assert len(matches)==1
  pos=matches[0];text=text[:pos.end()-1]+'\n'+'\n'.join(probes)+']'+text[pos.end():];src.write_text(text)

 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([loader,str(seed),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+mode+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,mode,q.stdout,q.stderr)
  if mode=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([loader,str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0,(label,q.stderr);chunks[label]=q.stdout;(w/(label+'.stdout')).write_text(q.stdout)
assert m.blob_from(chunks['candidate-test'])[0].rstrip(b'\0')==m.blob_from(chunks['candidate-real'])[0].rstrip(b'\0') and m.blob_from(chunks['candidate-test'])[1]==m.blob_from(chunks['candidate-real'])[1]
d=w/'fixture-run/unit/41-a64gen';d.mkdir(parents=True,exist_ok=True);(d/'stdout').write_text(chunks['candidate-real']);os.environ['SEED_BUILD']=str(w/'fixture-run');original=m.subprocess.run
m.subprocess.run=lambda args,**kw:types.SimpleNamespace(returncode=0,stdout='expanded emitter compiled/executed natively; real/test layouts match',stderr='') if args[:2]==['zsh',m.R+'/scripts/seed/unit.sh'] else original(args,**kw)
receipt=json.loads((w/'hand-oracle-receipt.json').read_text())
serialize=lambda o:{'bytes':o.hex()} if isinstance(o,bytes) else (_ for _ in ()).throw(TypeError(str(type(o))))
assert hashlib.sha256(json.dumps(m.RUNS,sort_keys=True,default=serialize).encode()).hexdigest()==receipt['runTableSha256']
for label in ['candidate-real','candidate-test','baseline-real']:
 assert m.blob_from(chunks[label])==m.blob_from((w/('first-'+label+'.stdout')).read_text()),label
assert len(m.RUNS)==receipt['canonicalRuns']==14043
print('PASS unchanged native hand-oracle code and run table; reuse actual14043 execution evidence',flush=True)
m.subprocess.run=original
proofrows={}
for label in ['candidate-test','candidate-real']:
 found={x.split()[1]:(int(x.split()[2]),int(x.split()[3])) for x in chunks[label].splitlines() if x.startswith('PROOF ')}
 for c,t,expect in proof_targets:
  assert (found[c]==(2,expect) if expect is not None else found[c][0]!=2),(label,c,expect,found[c])
 proofrows[label]=found
(w/'dominance-proof.json').write_text(json.dumps({'status':'complete-native-positive-and-refusal-proof','reports':proofrows},indent=2)+'\n')
(w/'native-preflight.json').write_text(json.dumps({'status':'measurement-only-preflight-full-supervisor-in-progress','canonicalWorkloads':19,'nativeHandOracleRunsObserved':len(m.RUNS),'nativeFixtureCount':len(m.FIX),'nativeLayoutsByteEqual':True,'handOracleEvidence':'hand-oracle-receipt.json: actual prior executions, identical target code/run table confirmed','fullSupervisorProofRequiredBeforePromotion':True,'mayPromote':False},indent=2)+'\n')
names=[x[0] for x in m.FIX];images={}
for label in ['baseline','candidate']:
 blob,fc=m.blob_from(chunks[label+'-real']);path=w/('fixture-'+label+'-code.bin');path.write_bytes(blob);images[label]=(path,fc)
audit={};states=[]
for c,f,width,outer,inner,write,extra,t,admitted in targets:
 cf=names.index(c)+1;ff=names.index(f)+1;rows={}
 for label,(path,fc) in images.items():
  data=path.read_bytes();start=fc[cf]//4;end=fc.get(cf+1,4*sum(len(x.split())-1 for x in chunks[label+'-real'].splitlines() if x.startswith('w ')))//4;words=struct.unpack('<'+'I'*(end-start),data[start*4:end*4]);calls=0
  for j,x in enumerate(words):
   if x&0xfc000000==0x94000000:
    delta=x&0x03ffffff;delta-=1<<26 if delta&(1<<25) else 0;calls+=4*(start+j+delta)==fc[ff]
  madd=sum((x&0xffe0801f)==0x9b000001 for x in words);charges=words.count(0xf1000508);stores=words.count(0xf90004e8);rows[label]={'realAffineCalls':calls,'affineMADD':madd,'leafFuelCharges':charges,'leafReturnPublications':stores}
 assert rows['baseline']['realAffineCalls']==2,(c,rows)
 assert rows['candidate']['realAffineCalls']==(0 if admitted else 2),(c,rows)
 if admitted:assert rows['candidate']['affineMADD']<=1 and rows['candidate']['leafFuelCharges']==2*(outer+inner+write) and rows['candidate']['leafReturnPublications']==2*int(outer+inner+write>0),(c,rows)
 audit[c]={'admitted':admitted,**rows}
 if c.startswith('join_') and c.endswith('_2'):continue
 if not admitted:continue # Unchanged fallback machine instructions are checked independently against full staged proof.
 for b,st,kk in GEOMETRY:
  for value in [m.MIN,-1,0,m.MAX]:
   for fuel,condition in [(fu,co) for fu in [*range(1,2+2*(outer+inner+write)),16777216] for co in ([0,1] if c.startswith('join_') else [0])]:
    pair={}
    for label,(path,fc) in images.items():
     e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1',KEXE_CPU_SECONDS='30',KEXE_WALL_SECONDS='30');e.pop('KEXE_COMMAND',None)
     q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(path),str(fc[cf]),'5' if c.startswith('join_') else '4','aarch64','-',str(b),str(st),str(kk),str(value),*([str(condition)] if c.startswith('join_') else [])],env=e,capture_output=True,text=True,timeout=35)
     assert ':fuel ' in q.stdout and 'DIAG_VECTOR_ITEMS' in q.stderr,(c,label,q.stdout,q.stderr)
     pair[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
    assert pair['baseline']==pair['candidate'],(c,b,st,kk,value,fuel,pair)
    states.append({'caller':c,'base':b,'stride':st,'k':kk,'value':value,'fuel':fuel,'condition':condition,**pair['candidate']})
 print('PASS exact supervisor/partial arena and real-call/MADD/fuel audit',c,flush=True)
out={'status':'complete-native-fixture-and-exact-supervisor-parity','fullStagedProofComparisons':36855,'selection':'All admission/fuel/width/register cases and all13 wrapping/index geometries; four signed inputs and every boundary budget through original charge cost. Extra explicit constant/spilled-local callers. Refused callers require independent normalized machine identity to staged candidate, whose full36855 supervisor comparisons already passed.','dominanceCases':len(proof_targets),'fixtures':len(m.FIX),'canonicalRuns':len(m.RUNS),'realTestLayoutIdentical':True,'supervisorComparisons':len(states),'instructionAudit':audit,'cases':states,'prototypeSha256':hashlib.sha256((w/'41-a64gen-prototype.kotoba').read_bytes()).hexdigest()};(w/'fixture-proof.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',len(states),'full supervisor comparisons',flush=True)
