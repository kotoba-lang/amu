from pathlib import Path
import json,hashlib,shutil,subprocess
w=Path('/private/tmp/amu-affine-join-20261005');scope={};s=(w/'fixture-proof.py').read_text();exec(s[:s.index("parts=['seed/")],scope);m=scope['m'];serialize=lambda o:{'bytes':o.hex()} if isinstance(o,bytes) else (_ for _ in ()).throw(TypeError(str(type(o))));table=hashlib.sha256(json.dumps(m.RUNS,sort_keys=True,default=serialize).encode()).hexdigest();receipt={'status':'complete-native-hand-oracles-before-diagnostic-target-selection-error','canonicalRuns':len(m.RUNS),'fixtures':len(m.FIX),'runTableSha256':table,'toolSession':81719,'terminalOutput':'a64gen run: 14043/14043 runs pass (421 fixtures, 107998 code bytes incl. pool)','laterDiagnosticFailure':'Probe selected first zero-index call instead of second joined call. Target code and actual hand-derived executions remain valid. Receipt reconstructed after the terminal failure; not a newly executed run.'};assert len(m.RUNS)==14043
(w/'hand-oracle-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
for n in ['candidate-real.stdout','candidate-test.stdout','baseline-real.stdout']:shutil.copyfile(w/n,w/('first-'+n))
p=w/'prepare-proof.py';s=p.read_text();a="call=next(j+1 for j,x in enumerate(sirs) if j+1>p and x[0]==m.C['OP-CALL'] and x[1]==fnids['aw_aff8'])";b="end=next(j+1 for j,x in enumerate(sirs) if j+1>p and x[0]==m.C['OP-END']);call=[j+1 for j,x in enumerate(sirs) if p<j+1<end and x[0]==m.C['OP-CALL'] and x[1]==fnids['aw_aff8']][-1]";assert s.count(a)==1;s=s.replace(a,b);p.write_text(s)
subprocess.run(['python3',str(p)],check=True)
p=w/'fixture-proof.py';s=p.read_text();s=s.replace('d.mkdir(parents=True);','d.mkdir(parents=True,exist_ok=True);');a='assert m.runs(False)==0;m.subprocess.run=original';b="""receipt=json.loads((w/'hand-oracle-receipt.json').read_text())
serialize=lambda o:{'bytes':o.hex()} if isinstance(o,bytes) else (_ for _ in ()).throw(TypeError(str(type(o))))
assert hashlib.sha256(json.dumps(m.RUNS,sort_keys=True,default=serialize).encode()).hexdigest()==receipt['runTableSha256']
for label in ['candidate-real','candidate-test','baseline-real']:
 assert m.blob_from(chunks[label])==m.blob_from((w/('first-'+label+'.stdout')).read_text()),label
assert len(m.RUNS)==receipt['canonicalRuns']==14043
print('PASS unchanged native hand-oracle code and run table; reuse actual14043 execution evidence',flush=True)
m.subprocess.run=original""";assert s.count(a)==1;s=s.replace(a,b)
n="(w/'dominance-proof.json').write_text(json.dumps({'status':'complete-native-positive-and-refusal-proof','reports':proofrows},indent=2)+'\\n')";assert s.count(n)==1;s=s.replace(n,n+"\n(w/'native-preflight.json').write_text(json.dumps({'status':'measurement-only-preflight-full-supervisor-in-progress','canonicalWorkloads':19,'nativeHandOracleRunsObserved':len(m.RUNS),'nativeFixtureCount':len(m.FIX),'nativeLayoutsByteEqual':True,'handOracleEvidence':'hand-oracle-receipt.json: actual prior executions, identical target code/run table confirmed','fullSupervisorProofRequiredBeforePromotion':True,'mayPromote':False},indent=2)+'\\n')");p.write_text(s)
print('receipt preserved; repair targets last affine call; identical target code required')
