from pathlib import Path
import json,shutil,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-affine-join-20261005');old=Path('/private/tmp/amu-affine-index-20261005');g=(old/'41-a64gen-prototype.kotoba').read_text()
helper=''';; Bounded dominance proof of an unchanged integer temporary across labels.
;; Find its nearest textual CONST while every intervening writer starts above t.
;; Then reject ALL edges entering that span from outside, including backedges.
;; The CONST dominates every admitted path; operations still execute unchanged.
;; No CFG edge assumptions based on names, emitted fallthrough or profiling.
(defn- gn-const-origin [M :vector-i64 j :i64 t :i64 work :i64] :i64
  (if (or (<= j 0) (<= work 0)) 0
    (let [op (gn-op M j) a (gn-sir M j IF-A) b (gn-sir M j IF-B) c (gn-sir M j IF-C)]
      (cond (and (= op OP-CONST) (= a t)) j
            (or (= op OP-FN) (= op OP-END) (= op OP-RET) (= op OP-RET2) (= op OP-TRAP) (= op OP-RES2)) 0
            (or (and (or (= op OP-CONST) (= op OP-LGET) (= op OP-STR) (= op OP-VEC) (= op OP-TAB) (= op OP-FADDR) (= op OP-VECP)) (<= a t))
                (and (or (= op OP-BIN) (= op OP-CMP) (= op OP-UN) (= op OP-CALL) (= op OP-CALLI) (= op OP-RT)) (<= b t))
                (and (= op OP-CAP) (<= c t))) 0
            (or (= op OP-CONST) (= op OP-LGET) (= op OP-STR) (= op OP-VEC) (= op OP-TAB) (= op OP-FADDR) (= op OP-VECP)
                (= op OP-BIN) (= op OP-CMP) (= op OP-UN) (= op OP-CALL) (= op OP-CALLI) (= op OP-RT) (= op OP-CAP)
                (= op OP-LSET) (= op OP-LABEL) (= op OP-BR) (= op OP-BRZ) (= op OP-BRNZ) (= op OP-FUEL))
            (gn-const-origin M (dec j) t (dec work))
            :else 0))))
(defn- gn-const-fn [M :vector-i64 j :i64 work :i64] :i64
  (cond (or (<= j 0) (<= work 0)) 0
        (= (gn-op M j) OP-FN) j
        (= (gn-op M j) OP-END) 0
        :else (gn-const-fn M (dec j) (dec work))))
(defn- gn-const-edges [M :vector-i64 j :i64 lo :i64 hi :i64 f :i64 work :i64] :bool
  (if (or (>= j (vector-at M MM-SIR-N)) (<= work 0)) false
    (let [op (gn-op M j) a (gn-sir M j IF-A) b (gn-sir M j IF-B)
          l (cond (= op OP-BR) a (or (= op OP-BRZ) (= op OP-BRNZ)) b :else 0)
          dest (if (> l 0) (gn-lpos M l) 0)]
      (cond (= op OP-END) (= a f)
            (= op OP-FN) false
            (and (> l 0) (= dest 0)) false
            (and (> dest lo) (<= dest hi) (or (< j lo) (> j hi))) false
            :else (gn-const-edges M (inc j) lo hi f (dec work))))))
(defn- gn-restore-const [M :vector-i64 i :i64 t :i64] :vector-i64
  (if (gn-isk M t gn-k-const) M
    (let [origin (gn-const-origin M (dec i) t 256) start (gn-const-fn M (dec i) 4096)
          v (if (> origin 0) (gn-sir M origin IF-B) -1)]
      (if (and (> origin 0) (> start 0) (or (= v 0) (= v 1) (> (gn-pow2 v) 0))
               (gn-const-edges M (inc start) origin (dec i) (gn-sir M start IF-A) 4096))
        (gn-dset M t gn-k-const v) M))))

'''
needle=';; Proven already-evaluated immutable descriptors only.';assert g.count(needle)==1;g=g.replace(needle,helper+needle)
a='        M1 (gn-pin M t) rv (gn-pinned M1 t)\n        kind (gn-affine-index-kind M1 t)';b='        M1 (-> M (gn-restore-const i (+ t 2)) (gn-restore-const i (+ t 3)) (gn-pin t)) rv (gn-pinned M1 t)\n        kind (gn-affine-index-kind M1 t)';assert g.count(a)==1;g=g.replace(a,b)
files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')]
(w/'41-a64gen-prototype.kotoba').write_text(g);(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
dg=(old/'descriptor-observer.kotoba').read_text().replace(needle,helper+needle);assert dg.count(a)==1;dg=dg.replace(a,b);(w/'descriptor-observer.kotoba').write_text(dg);(w/'descriptor-unity.kotoba').write_text(''.join((dg if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
for name in ['seed-0.bin','seed-0.offset','kexe-loader']:shutil.copyfile(old/name,w/name)
(w/'kexe-loader').chmod(0o755)
for name in ['build.py','observe.py','check-ports.py','bulk-state.py','import-proof.py','baseline-a64gen-fixtures.py','baseline-41-a64gen.kotoba','inspected-sir.json']:
 s=(old/name).read_text().replace('amu-affine-index-20261005','amu-affine-join-20261005');(w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'hypothesis':'Restore immutable scalar constants lost at joins only after bounded exact SIR dominance proof: nearest CONST, no temp writer <= target within span, and full-function edge scan rejecting every outside incoming edge. Enable base-only/ADD/shifted ADD in exact closed affine checked-write fusion. Preserve all original evaluation, effects, fuel and branch execution.','priorEvidence':'Native observer on all19:9 affine sites inPico,0 usable constants. gn-op-label discards descriptors. New proof changes generated code, not a timing retry.','bounds':'origin256instructions,function-bound/edge4096instructions; unknown operations/different definitions/external incoming or backward edges fail closed. Only0/1/positivepowers2^1..2^62 recovered.','proof':'All19 aligned exact result/fuel/traps, full8192cells, fixedpoint; explicit join writes/outside edges/backedge/limit refusal plus arithmetic signed/wrapping/constant/home/alias and full supervisor/partialwrite/import proofs. Fresh30triples same1.05+noise threshold then integrated3gen/corpus/gates before promotion.','exception':'One-off new Kotoba compiler algorithm authoring, isolated until qualified'},indent=2)+'\n');print('registered bounded constant-dominance proof variant')
