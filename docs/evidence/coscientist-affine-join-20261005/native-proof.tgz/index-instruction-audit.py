from pathlib import Path
import json,struct
w=Path('/private/tmp/amu-affine-join-20261005');scope={};s=(w/'fixture-proof.py').read_text();exec(s[:s.index("parts=['seed/")],scope);m=scope['m'];names=[x[0] for x in m.FIX];stdout=(w/'candidate-real.stdout').read_text();data,fc=m.blob_from(stdout);fc[len(names)+1]=4*sum(len(x.split())-1 for x in stdout.splitlines() if x.startswith('w '));rows=[]
for c,t,expected in scope['proof_targets']:
 if c.startswith('join_refuse'):continue
 f=names.index(c)+1;a=fc[f]//4;b=fc[f+1]//4;words=struct.unpack('<'+'I'*(b-a),data[a*4:b*4]);madd=sum(x&0xffe0801f==0x9b000001 for x in words);adds=[x for x in words if x&0xffe0001f==0x8b000001];moves=[x for x in words if x&0xffe0ffff==0xaa0003e1]
 assert madd==(1 if expected is None else 0),(c,madd,adds,moves)
 if expected is not None:
  if expected==0:assert len(moves)>=2 and not adds,(c,moves,adds)
  else:assert len(adds)==1 and ((adds[0]>>10)&63)==(expected.bit_length()-1),(c,adds,expected)
 rows.append({'caller':c,'recoveredConstant':expected,'genericMADD':madd,'indexAddWords':[hex(x) for x in adds],'indexMoveWords':[hex(x) for x in moves]})
assert len(rows)==44
(w/'index-instruction-audit.json').write_text(json.dumps({'status':'complete-decoded-native-index-specialization-audit','cases':rows,'lemma':'64-bit shifted-register ADD with shift p equals wrapping base+operand*2^p for every64-bit operand/base and0<=p<=62; shift field and zero/one modes independently decoded.'},indent=2)+'\n');print('PASS all44 joined callers decoded: exact move/add/shift and generic-MADD refusal controls')
