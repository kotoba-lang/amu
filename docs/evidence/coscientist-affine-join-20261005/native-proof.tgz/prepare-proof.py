from pathlib import Path
w=Path('/private/tmp/amu-affine-join-20261005');old=Path('/private/tmp/amu-affine-writer-direct-20261005');s=(old/'fixture-proof.py').read_text().replace('amu-affine-writer-direct-20261005','amu-affine-join-20261005')
insert='''
# Branch-sensitive fixed operands and dominance refusal controls. Both value arms
# execute normally; the proof only recovers an immutable scalar already evaluated.
proof_targets=[]
for axis in ['k','stride']:
 for fixed in [0,1,2,4,8,1<<31,1<<62,3,-1,m.MIN,m.MAX]:
  for t in [0,2]:
   c=f'join_{axis}_{fixed}_{t}'.replace('-','neg');f='aw_aff8';cb=[('FUEL',),('CONST',0,11),('CONST',1,-22),('CONST',2,33),('CONST',3,-44),('VEC',0,4),('LSET',6,0)]
   for ix in [0,1]:
    cb += [('CONST',j,100+j) for j in range(t)]+[('LGET',t,6)]
    cb += ([('CONST',t+1,0),('CONST',t+2,0),('CONST',t+3,0)] if ix==0 else [('LGET',t+1,1),('CONST',t+2,fixed) if axis=='stride' else ('LGET',t+2,2),('CONST',t+3,fixed) if axis=='k' else ('LGET',t+3,3)])
    cb += [('LGET',t+4,4)]
    if ix==1:
     cb += [('LGET',t+5,5),('BRZ',t+5,c+'_false'),('CONST',t+5,1),('BIN','BOP-ADD',t+4),('BR',c+'_join'),('LABEL',c+'_false'),('LGET',t+4,4),('LABEL',c+'_join')]
    cb += [('CALL',f,t,5),('RT','RT-VECTOR-COUNT',t,1)]
    for j in range(t-1,-1,-1):cb += [('BIN','BOP-ADD',j)]
    cb += [('LSET',7,0)]
   cb += [('LGET',0,6),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('LGET',1,6),('CONST',2,3),('RT','RT-VECTOR-AT',1,2),('BIN','BOP-ADD',0),('LGET',1,7),('BIN','BOP-ADD',0),('RET',0)]
   m.fx(c,5,7,cb);targets.append((c,f,16,1,0,1,False,t,True));known=fixed in [0,1,2,4,8,1<<31,1<<62];proof_targets.append((c,t+(3 if axis=='k' else 2),fixed if known else None))
   live=sum(100+j for j in range(t))
   for b,st,k in GEOMETRY:
    idx=m.s64(b+(fixed if axis=='stride' else st)*(fixed if axis=='k' else k))
    for cond in [0,1]:
     for value in [m.MIN,-1,0,m.MAX]:
      v1=value&65535;v1=v1-65536 if v1>=32768 else v1;v2=m.s64(value+cond)&65535;v2=v2-65536 if v2>=32768 else v2
      arr=[v1,-22,33,-44]
      if 0<=idx<4:arr[idx]=v2;expect=m.s64(arr[0]+arr[3]+4+live)
      else:expect='trap'
      m.run(c,[b,st,k,value,cond],expect,fuel=5)
   for fuel in range(1,5):m.run(c,[0,0,0,0,0],'trap',fuel=fuel)
# Unsafe joins: overwrite only one arm, bypass the CONST, a later backedge,
# origin/function-scan work limits, and unknown writer forms. Refusal is explicit.
for shape in ['overwrite','outside','backedge','origin-limit','function-limit','res2']:
 c='join_refuse_'+shape.replace('-','_');f='aw_aff8';t=0
 cb=[('FUEL',),('CONST',0,11),('CONST',1,-22),('CONST',2,33),('CONST',3,-44),('VEC',0,4),('LSET',6,0),('LGET',0,6),('LGET',1,1),('LGET',2,2)]
 if shape=='outside':cb += [('LGET',3,3),('LGET',4,5),('BRZ',4,c+'_join'),('CONST',3,1)]
 else:cb += [('CONST',3,1)]
 if shape=='overwrite':cb += [('LGET',4,5),('BRZ',4,c+'_join'),('CONST',3,2)]
 if shape=='origin-limit':cb += [('LGET',5,5)]*258
 if shape=='function-limit':cb += [('LGET',5,5)]*4100
 if shape=='res2':cb += [('CONST',4,1),('CONST',5,2),('RES2',4)]
 cb += [('LABEL',c+'_join'),('LGET',4,4),('CALL',f,0,5)]
 if shape=='backedge':cb += [('CONST',1,0),('BRNZ',1,c+'_join')]
 cb += [('RT','RT-VECTOR-COUNT',0,1),('RET',0)];m.fx(c,5,6,cb);proof_targets.append((c,3,None))
 for cond in [0,1]:m.run(c,[0,0,0,-1,cond],4,fuel=3)
'''
needle="parts=['seed/";assert s.count(needle)==1;s=s.replace(needle,insert+'\n'+needle)
# Inject pure proof reports after target code/pool output, then assert on them.
needle="+m.kotoba(real))";assert s.count(needle)==1
rep="""+m.kotoba(real))
 if label.startswith('candidate'):
  fnids,_,_,sirs,_=m.layout_tables();probes=[]
  for c,t,expect in proof_targets:
   fid=fnids[c];p=next(j+1 for j,x in enumerate(sirs) if x[0]==m.C['OP-FN'] and x[1]==fid);end=next(j+1 for j,x in enumerate(sirs) if j+1>p and x[0]==m.C['OP-END']);call=[j+1 for j,x in enumerate(sirs) if p<j+1<end and x[0]==m.C['OP-CALL'] and x[1]==fnids['aw_aff8']][-1]
   # A preceding function's CALL cannot be selected: stop at this fn END.
   end=next(j+1 for j,x in enumerate(sirs) if j+1>p and x[0]==m.C['OP-END']);assert call<end
   probes += [f'        PM{len(probes)} (gn-restore-const (gn-op-fn M3 {p} {fid} 5) {call} {t})',f'        PO{len(probes)} (t-out (string-concat "PROOF {c} " (string-concat (string-from-i64 (gn-dk PM{len(probes)} {t})) (string-concat " " (string-concat (string-from-i64 (gn-dv PM{len(probes)} {t})) "\\\\n")))))']
  text=src.read_text();needle='        sign_open (gn-clamp MS %d %d 1)]' % (next(i+1 for i,x in enumerate(m.FIX) if x[0]=='clamp_dummy_never') if False else next(i+1 for i,x in enumerate(m.FIX) if x[0]=='cl_sign2'),next(i+1 for i,x in enumerate(sirs) if x[0]==m.C['OP-CALL'] and x[1]==fnids['cl_bound2']))
  # Read the exact final let binding directly; the generated fixture API pins it.
  import re as _re
  matches=list(_re.finditer(r'        sign_open \\(gn-clamp MS [0-9]+ [0-9]+ 1\\)\\]',text));assert len(matches)==1
  pos=matches[0];text=text[:pos.end()-1]+'\\n'+'\\n'.join(probes)+']'+text[pos.end():];src.write_text(text)
"""
s=s.replace(needle,rep)
# Existing callers first write at constant-zero index, second generic/constant.
s=s.replace("rows['candidate']['affineMADD']==2 and", "rows['candidate']['affineMADD']<=1 and")
# Full supervisor inputs include branch condition; every added join executes both arms.
s=s.replace("for fuel in [*range(1,2+2*(outer+inner+write)),16777216]:", "for fuel,condition in [(fu,co) for fu in [*range(1,2+2*(outer+inner+write)),16777216] for co in ([0,1] if c.startswith('join_') else [0])]:")
s=s.replace("str(fc[cf]),'4','aarch64','-',str(b),str(st),str(kk),str(value)", "str(fc[cf]),'5' if c.startswith('join_') else '4','aarch64','-',str(b),str(st),str(kk),str(value),*([str(condition)] if c.startswith('join_') else [])")
s=s.replace("'fuel':fuel,**pair", "'fuel':fuel,'condition':condition,**pair")
# Avoid adding ~23000 redundant supervisor comparisons; full geometry/exact fuel
# on existing54 callers plus selected joined cases covering every fixed magnitude.
s=s.replace("if not admitted:continue #", "if c.startswith('join_') and c.endswith('_2'):continue\n if not admitted:continue #")
needle="assert m.runs(False)==0;m.subprocess.run=original";assert s.count(needle)==1
s=s.replace(needle,needle+"\nproofrows={}\nfor label in ['candidate-test','candidate-real']:\n found={x.split()[1]:(int(x.split()[2]),int(x.split()[3])) for x in chunks[label].splitlines() if x.startswith('PROOF ')}\n for c,t,expect in proof_targets:\n  assert found[c]==((2,expect) if expect is not None else (0,0)),(label,c,expect,found[c])\n proofrows[label]=found\n(w/'dominance-proof.json').write_text(json.dumps({'status':'complete-native-positive-and-refusal-proof','reports':proofrows},indent=2)+'\\n')")
s=s.replace("'fixtures':len(m.FIX)", "'dominanceCases':len(proof_targets),'fixtures':len(m.FIX)")
(w/'fixture-proof.py').write_text(s);print('prepared native joined-constant and refusal controls')
