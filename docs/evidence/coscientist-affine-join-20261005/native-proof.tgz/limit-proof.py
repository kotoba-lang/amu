from pathlib import Path
import subprocess,os,re,json
w=Path('/private/tmp/amu-affine-join-20261005');scope={};s=(w/'fixture-proof.py').read_text();exec(s[:s.index("parts=['seed/")],scope);m=scope['m'];r=scope['r'];rows=[]
for shape in ['fn-search','edge-scan']:
 name='proof_limit_'+shape.replace('-','_');cb=[('FUEL',),('LGET',0,1),('LGET',1,2),('LGET',2,3)]
 if shape=='fn-search':cb += [('LGET',5,5)]*4100
 cb += [('CONST',3,1),('LABEL',name+'_join'),('LGET',4,4),('CALL','aw_aff8',0,5)]
 if shape=='edge-scan':cb += [('LGET',5,5)]*4100
 cb += [('RET',0)];m.fx(name,5,5,cb);rows.append(name)
fnids,_,_,sirs,_=m.layout_tables();test=m.kotoba(True);probes=[]
for k,name in enumerate(rows):
 fid=fnids[name];p=next(j+1 for j,x in enumerate(sirs) if x[0]==m.C['OP-FN'] and x[1]==fid);call=next(j+1 for j,x in enumerate(sirs) if j+1>p and x[0]==m.C['OP-CALL'] and x[1]==fnids['aw_aff8']);assert call>p
 probes += [f'        LM{k} (gn-op-fn M3 {p} {fid} 5)',f'        origin{k} (gn-const-origin LM{k} {call-1} 3 256)',f'        start{k} (gn-const-fn LM{k} {call-1} 4096)',f'        restored{k} (gn-restore-const LM{k} {call} 3)',f'        output{k} (t-out (string-concat "LIMIT {name} " (string-concat (string-from-i64 origin{k}) (string-concat " " (string-concat (string-from-i64 start{k}) (string-concat " " (string-concat (string-from-i64 (gn-dk restored{k} 3)) "\\n")))))))']
match=re.search(r'        sign_open \(gn-clamp MS [0-9]+ [0-9]+ 1\)\]',test);assert match;test=test[:match.end()-1]+'\n'+'\n'.join(probes)+']'+test[match.end():]
for k in [3,4,5,6]:test=re.sub(r'        o'+str(k)+r' \([^\n]+\)',f'        o{k} 0',test)
src=w/'limit-proof.kotoba';parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+test)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');loader=str(w/'kexe-loader')
for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/'limit-proof.kseed')]),('extract',['extract-native',str(w/'limit-proof.kseed'),'--symbol','main','--output',str(w/'limit-proof.bin')])]:
 q=subprocess.run([loader,str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/('limit-proof-'+label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout,q.stderr)
 if label=='extract':offset=re.search(r':offset (\d+)',q.stdout).group(1)
q=subprocess.run([loader,str(w/'limit-proof.bin'),offset,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/'limit-proof.stdout').write_text(q.stdout);assert q.returncode==0,(q.stdout,q.stderr)
found={x.split()[1]:list(map(int,x.split()[2:])) for x in q.stdout.splitlines() if x.startswith('LIMIT ')};assert len(found)==2
assert found[rows[0]][0]>0 and found[rows[0]][1]==0 and found[rows[0]][2]!=2
assert found[rows[1]][0]>0 and found[rows[1]][1]>0 and found[rows[1]][2]!=2
(w/'limit-proof.json').write_text(json.dumps({'status':'complete-native-independent-origin-function-search-and-edge-scan-bounds','cases':found},indent=2)+'\n');print('PASS both4096 limits refuse with positive nearest origin; independent from256 origin limit',flush=True)
