from pathlib import Path
import struct,json
w=Path('/private/tmp/amu-affine-join-20261005');old=Path('/private/tmp/amu-affine-writer-20261005');scope={};s=(w/'fixture-proof.py').read_text();exec(s[:s.index("parts=['seed/")],scope);m=scope['m'];targets=scope['targets'];names=[x[0] for x in m.FIX];a=m.blob_from((w/'candidate-real.stdout').read_text());other={};s=(old/'fixture-proof.py').read_text();exec(s[:s.index("parts=['seed/")],other);om=other['m'];onames=[x[0] for x in om.FIX];b=om.blob_from((old/'candidate-real.stdout').read_text());oldproof=json.loads((old/'fixture-proof.json').read_text());assert oldproof['supervisorComparisons']==36855
rows=[]
def word_end(path):
 return sum(len(line.split())-1 for line in path.read_text().splitlines() if line.startswith('w '))*4
a[1][len(names)+1]=word_end(w/'candidate-real.stdout')
b[1][len(onames)+1]=word_end(old/'candidate-real.stdout')
def code(data,fc,names,fn):
 f=names.index(fn)+1;start=fc[f]//4;end=fc[f+1]//4;words=struct.unpack('<'+'I'*(end-start),data[start*4:end*4]);rev={off:name for off,name in [(fc[k+1],n) for k,n in enumerate(names)]};out=[]
 for j,x in enumerate(words):
  if x&0xfc000000==0x94000000:
   d=x&0x03ffffff;d-=1<<26 if d&(1<<25) else 0;target=rev[(start+j+d)*4];out.append(('BL',target.replace('aw_aff9','aw_aff8')))
  else:out.append(x)
 return out
for c,f,width,outer,inner,write,extra,t,admitted in targets:
 if admitted:continue
 counterpart=c.replace('aw_call9_','aw_call8_')
 assert code(*a,names,c)==code(*b,onames,counterpart),(c,counterpart)
 rows.append({'directCaller':c,'stagedCaller':counterpart,'normalizedMachineInstructionsIdentical':True})
assert len(rows)==23
# Confirm parameter/local stack loads precede the actual MADD in spilled cases.
spilled=[]
for c in ['aw_spilled_0','aw_spilled_2']:
 f=names.index(c)+1;start=a[1][f]//4;end=a[1][f+1]//4;words=struct.unpack('<'+'I'*(end-start),a[0][start*4:end*4]);madds=[i for i,x in enumerate(words) if x&0xffe0801f==0x9b000001];assert len(madds)==1
 second=madds[0];earlier=words[:second];regs=set(x&31 for x in earlier if x&0xffc003e0==0xf94003e0);assert {0,16,17}<=regs,(c,regs)
 spilled.append({'caller':c,'confirmedOperandLoadsFromCallerStack':[0,16,17]})
(w/'fallback-audit.json').write_text(json.dumps({'status':'complete-direct-fallback-machine-identity-and-stack-operand-audit','stagedFullSupervisorComparisons':36855,'unchangedFallbacks':rows,'spilledOperands':spilled},indent=2)+'\n');print('PASS 23 fallback instruction identities; staged full proof applies; explicit x0/x16/x17 stack operands verified')
