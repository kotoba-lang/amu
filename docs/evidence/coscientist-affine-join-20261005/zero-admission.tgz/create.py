from pathlib import Path
import json,shutil,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-affine-index-20261005');old=Path('/private/tmp/amu-affine-writer-direct-20261005');base=Path('/private/tmp/amu-clamp-call-20261005');g=(old/'41-a64gen-prototype.kotoba').read_text()
needle=';; x0 is the signed value, x1 the wrapping affine index; operands read'
helper=''';; Proven already-evaluated immutable descriptors only. Shifted-register ADD
;; wraps exactly like multiply/add; no flags or resource observations are lost.
;; Modes: base only, stride+k with one operand1, shifted ADD, generic MADD.
(defn- gn-affine-index-kind [M :vector-i64 t :i64] :i64
  (let [ks (gn-isk M (+ t 2) gn-k-const) kk (gn-isk M (+ t 3) gn-k-const)
        vs (gn-dv M (+ t 2)) vk (gn-dv M (+ t 3))]
    (cond (or (and ks (= vs 0)) (and kk (= vk 0))) 1
          (and kk (= vk 1)) 2
          (and ks (= vs 1)) 3
          (and kk (> (gn-pow2 vk) 0)) 4
          (and ks (> (gn-pow2 vs) 0)) 5
          :else 0)))
(defn- gn-affine-index [M :vector-i64 t :i64 kind :i64] :vector-i64
  (let [rb (gn-src M (inc t) 0 1) rs (gn-src M (+ t 2) 16 1)
        rk (gn-src M (+ t 3) 17 1) B (gn-ldt M (inc t) 0 1)]
    (case kind
      1 (gn-mov B 1 rb)
      2 (-> B (gn-ldt (+ t 2) 16 1) (gn-emit (enc-add-r 1 rb rs)))
      3 (-> B (gn-ldt (+ t 3) 17 1) (gn-emit (enc-add-r 1 rb rk)))
      4 (-> B (gn-ldt (+ t 2) 16 1) (gn-emit (gn-e-addsl 1 rb rs (gn-pow2 (gn-dv M (+ t 3))))))
      5 (-> B (gn-ldt (+ t 3) 17 1) (gn-emit (gn-e-addsl 1 rb rk (gn-pow2 (gn-dv M (+ t 2))))))
      (-> B (gn-ldt (+ t 2) 16 1) (gn-ldt (+ t 3) 17 1) (gn-emit (enc-madd 1 rs rk rb))))))

'''
assert g.count(needle)==1;g=g.replace(needle,helper+needle)
a='''        rb (gn-src M1 (inc t) 0 1) rs (gn-src M1 (+ t 2) 16 1)
        rk (gn-src M1 (+ t 3) 17 1) rx (gn-src M1 (+ t 4) 0 1)]
    (-> M1 (gn-ldt (inc t) 0 1) (gn-ldt (+ t 2) 16 1) (gn-ldt (+ t 3) 17 1)
        (gn-ctx)'''
b='''        kind (gn-affine-index-kind M1 t) rx (gn-src M1 (+ t 4) 0 1)]
    (-> M1 (gn-ctx)'''
assert g.count(a)==1;g=g.replace(a,b);assert g.count('(gn-emit (enc-madd 1 rs rk rb))\n        (cond->')==1;g=g.replace('(gn-emit (enc-madd 1 rs rk rb))\n        (cond->','(gn-affine-index t kind)\n        (cond->',1)
files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')]
(w/'41-a64gen-prototype.kotoba').write_text(g);(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
# Observer is diagnostic only: same target emission, explicit descriptor report.
diag='''        kind (gn-affine-index-kind M1 t) rx (gn-src M1 (+ t 4) 0 1)
        observed (io-out (string-concat "AFFIDX " (string-concat (string-from-i64 kind)
          (string-concat " " (string-concat (string-from-i64 (gn-dk M1 (inc t)))
          (string-concat " " (string-concat (string-from-i64 (gn-dv M1 (inc t)))
          (string-concat " " (string-concat (string-from-i64 (gn-dk M1 (+ t 2)))
          (string-concat " " (string-concat (string-from-i64 (gn-dv M1 (+ t 2)))
          (string-concat " " (string-concat (string-from-i64 (gn-dk M1 (+ t 3)))
          (string-concat " " (string-concat (string-from-i64 (gn-dv M1 (+ t 3))) "\\n")))))))))))))))]'''
p='        kind (gn-affine-index-kind M1 t) rx (gn-src M1 (+ t 4) 0 1)]';assert g.count(p)==1;dg=g.replace(p,diag);(w/'descriptor-observer.kotoba').write_text(dg);(w/'descriptor-unity.kotoba').write_text(''.join((dg if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
for ext in ['bin','offset']:shutil.copyfile(base/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile(base/'kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['build.py','check-ports.py','bulk-state.py','import-proof.py','baseline-a64gen-fixtures.py','baseline-41-a64gen.kotoba','inspected-sir.json']:
 s=(old/name).read_text().replace('amu-affine-writer-direct-20261005','amu-affine-index-20261005');(w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'hypothesis':'Fixed affine scalar descriptors permit base-only, wrapping ADD or shifted ADD without materializing ignored constants and MADD. Exact closed affine-write bodies/fuel/caller admission unchanged; no benchmark/name selection. Actual emitted descriptors measured with diagnostic-only native observer before timing.','priorDecision':'Direct-register affine writer ratio1.048076 failed>=1.05. No same-byte rerun or relaxed threshold.','proof':'All19 originals exact result/fuel/exhaustion,8192cells, fixedpoints, all wrapping/signed/fuel/partial-state/register/import tests, and explicit zero/one/powers1..62/MAX/MIN/nonpower guards. Fresh30triples per changed guest with unchanged spec, then integrated3gen/corpus/gates before promotion.','exception':'One-off new Kotoba compiler algorithm authoring; isolated until qualification'},indent=2)+'\n');print('registered immutable-affine-index candidate and diagnostic observer')
