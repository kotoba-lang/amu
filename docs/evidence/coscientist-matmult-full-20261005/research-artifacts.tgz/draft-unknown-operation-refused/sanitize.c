#include "c-bridge.c"
#include <stdio.h>
int main(void){for(int n=1;n<=32;n++)if(bench(n,0,0,0,0,0,0,0)!=1)return 1;for(int n=0;n<=32;n++)for(int i=0;i<=2000;i++)if(observe(n*2048+i,0,0,0,0,0,0,0)==INT64_MIN)return 2;printf("PASS 32 original matrix bodies/verifiers, 66033 initialized observations\n");return 0;}
