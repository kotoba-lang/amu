from pathlib import Path
import hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17'); w=Path('/private/tmp/amu-content-fold-20261005')
old=(r/'seed/30-lower.kotoba').read_text()
start=old.index('(defn- lw-if '); end=old.index('\n;; cond clauses',start)
replacement=''';; Bounded exact-content proof for uniform integer decision trees. Only
;; literal/local scalar comparisons can disappear: no call, allocation,
;; mutable read, division, capability, or fuel-bearing expression is admitted.
(defn- lw-static-scalar? [M :vector-i64 n :i64] :bool
  (or (= (lw-nf M n NF-KIND) ND-INT)
      (and (= (lw-nf M n NF-KIND) ND-SYM) (= (lw-rcls (lw-nf M n NF-RES)) RES-LOCAL))))
(defn- lw-static-test? [M :vector-i64 n :i64] :bool
  (let [hd (lw-nf M n NF-RES)
        a (lw-next M (lw-first M n))
        b (lw-next M a)]
    (and (= (lw-nf M n NF-KIND) ND-LIST)
         (or (= hd HD-EQ) (= hd HD-LT) (= hd HD-GT) (= hd HD-LE) (= hd HD-GE))
         (> a 0) (> b 0) (= (lw-next M b) 0)
         (lw-static-scalar? M a) (lw-static-scalar? M b))))
;; Returns a representative literal node, or zero when equality is unproved.
;; Literal equality is exact (kind + signed i64 value), with no hash collision.
(defn- lw-uniform-int [M :vector-i64 n :i64 depth :i64] :i64
  (cond (= (lw-nf M n NF-KIND) ND-INT) n
        (or (= n 0) (>= depth 32) (not= (lw-nf M n NF-KIND) ND-LIST) (not= (lw-nf M n NF-RES) HD-IF)) 0
        :else
        (let [c (lw-next M (lw-first M n))
              x (lw-next M c) y (lw-next M x)]
          (if (not (lw-static-test? M c)) 0
              (let [a (lw-uniform-int M x (inc depth)) b (lw-uniform-int M y (inc depth))]
                (if (and (> a 0) (> b 0) (= (lw-nf M a NF-AUX) (lw-nf M b NF-AUX))) a 0))))))
(defn- lw-if [M :vector-i64 c :i64 t :i64 k :i64] :vector-i64
  (let [x (lw-next M c)
        y (lw-next M x)
        a (lw-uniform-int M x 0)
        b (if (> a 0) (lw-uniform-int M y 0) 0)
        le (vector-at M MM-LABEL-N)]
    (if (and (> a 0) (> b 0) (= (lw-nf M a NF-AUX) (lw-nf M b NF-AUX)))
      (-> M (cond-> (not (lw-static-test? M c)) (lw-expr c t 0)) (lw-expr a t k))
      (-> M
          (lw-labels 2)
          (lw-expr c t 0)
          (lw-emit OP-BRZ t le)
          (lw-expr x t k)
          (lw-emit OP-BR (inc le))
          (lw-emit OP-LABEL le)
          (lw-expr y t k)
          (lw-emit OP-LABEL (inc le))))))
'''
new=old[:start]+replacement+old[end:]; (w/'30-lower-prototype.kotoba').write_text(new)
u=Path('/private/tmp/amu-wrapper-prototype-20261005/seed-unity.kotoba').read_text();assert u.count(old)==1
u=u.replace(old,new);(w/'seed-unity.kotoba').write_text(u);(w/'seed-unity.kotoba.sha256').write_text(hashlib.sha256(u.encode()).hexdigest()+'\n')
for ext in ['bin','offset']:(w/f'seed-0.{ext}').write_bytes(Path(f'/private/tmp/amu-wrapper-prototype-20261005/seed-4.{ext}').read_bytes())
print('prototype ready; canonical sources unchanged')
