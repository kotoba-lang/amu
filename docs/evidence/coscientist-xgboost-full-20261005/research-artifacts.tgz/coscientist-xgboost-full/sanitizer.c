#include "c-bridge.c"
#include <stdio.h>
int main(void){for(int n=1;n<=32;n++)if(!oracle_selfcheck(n,0,0,0,0,0,0,0)||result(n,0,0,0,0,0,0,0)!=126*n)return 1;int count=0;for(int n=0;n<=32;n++){if(observe(n*2048,0,0,0,0,0,0,0)!=126*n)return 2;count++;for(int i=0;i<128;i++){if(snapshots[i][0]>9)return 3;count++;for(int j=1;j<11;j++){if(snapshots[i][j]>10200)return 4;count++;}}}for(int group=0;group<9889;group++)if(model_observe(group,0,0,0,0,0,0,0)<0)return 5;printf("PASS 32 original xgboost bodies/counts; %d snapshot reads; 9889 model groups\n",count);return 0;}
