from pathlib import Path
import subprocess,os,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-vector-descriptor2-20261005');base=Path('/private/tmp/amu-sign-wrapper-20261005');loader=w/'kexe-loader';runner=Path('/private/tmp/amu-embench-compare-20261004/runner')
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
indices=[-1,0,1,31,32,255,256,1400,4094,4095,4096];symbols=[];forms=[]
for k in indices:
 tag='m1' if k<0 else str(k)
 for op in ['read','write','alias','high']:
  name=op+tag;symbols.append(name)
  body=f'(vector-at (vector-alloc n) {k})'
  if op=='write':body=f'(let [v (vector-alloc n) a (vector-assoc! v {k} (+ n 10))] (vector-at a {k}))'
  if op=='alias':body=f'(let [v (vector-alloc n) a (vector-assoc! v {k} n)] (+ (vector-at v {k}) (vector-at a {k})))'
  if op=='high':
   body=f'(let [v (vector-alloc n)] '+('(+'+' n ')*10+f'(vector-at v {k})'+')'*10+')'
  forms.append(f'(defn {name} [n :i64] :i64 {body})')
for k in [0,4095]:
 symbols.append('handle'+str(k));forms.append(f'(defn handle{k} [v :vector-i64] :i64 (vector-at v {k}))')
src=w/'probe.kotoba';src.write_text('(ns probe (:export ['+' '.join(symbols)+']))\n'+'\n'.join(forms)+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def compile(seed,d):
 d.mkdir();out=d/'image.kseed'
 p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--','compile',str(src),'--target','aarch64-macos','--output',str(out)],env=env,capture_output=True,text=True);(d/'compile.log').write_text(p.stdout+p.stderr);assert p.returncode==0,(p.stdout,p.stderr)
 offsets={}
 for s in symbols:
  p=subprocess.run([str(loader),str(seed),'0','0','aarch64','35,37,38,39','--','extract-native',str(out),'--symbol',s,'--output',str(d/'native.bin')],env=env,capture_output=True,text=True);(d/(s+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(s,p.stderr);offsets[s]=int(re.search(r':offset (\d+)',p.stdout).group(1))
 return offsets
A=w/'probe-baseline';B=w/'probe-candidate';oa=compile(base/'seed-4.bin',A);ob=compile(w/'seed-4.bin',B);rows=[]
def run(d,off,n,fuel):
 p=subprocess.run([str(runner),'raw',str(d/'native.bin'),str(off),'aarch64',str(n),'1','0',str(fuel)],capture_output=True,text=True)
 return p.returncode,(json.loads(p.stdout) if p.returncode==0 else None)
for symbol in symbols:
 inputs=[-9223372036854775808,-1,0,1,9223372036854775807] if symbol.startswith('handle') else [0,1,2,32,256,4095,4096,4097]
 for n in inputs:
  for fuel in [16777216,1,2,3]:
   xa,x=run(A,oa[symbol],n,fuel);ya,y=run(B,ob[symbol],n,fuel);assert xa==ya,(symbol,n,fuel,xa,ya)
   if x is not None:assert x['result']==y['result'] and x['contextFuelConsumed']==y['contextFuelConsumed'],(symbol,n,fuel,x,y)
   if fuel==16777216:
    if symbol.startswith('handle'):assert xa!=0
    else:
     tag=re.search(r'(m1|\d+)$',symbol).group(1);k=-1 if tag=='m1' else int(tag);valid=0<=k<n
     assert (xa==0)==valid,(symbol,n,xa)
     if valid:
      expected=n+10 if symbol.startswith('write') else 2*n if symbol.startswith('alias') else 10*n if symbol.startswith('high') else 0
      assert x['result']==expected,(symbol,n,x,expected)
   rows.append({'symbol':symbol,'n':n,'fuel':fuel,'exit':xa,'result':None if x is None else x['result'],'consumed':None if x is None else x['contextFuelConsumed']})
print('PASS',len(rows),'source probes',flush=True)
(w/'correctness.json').write_text(json.dumps({'status':'complete-result-exact-fuel-and-trap-parity','rows':rows,'sourceSha256':sha(src),'baselineBytes':(A/'native.bin').stat().st_size,'candidateBytes':(B/'native.bin').stat().st_size,'candidateOffsets':ob,'compilerGenerations':{str(n):sha(w/f'seed-{n}.bin') for n in [2,3,4]}},indent=2)+'\n')
