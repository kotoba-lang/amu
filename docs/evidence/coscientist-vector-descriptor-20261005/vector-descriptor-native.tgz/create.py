from pathlib import Path
import hashlib,json,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-vector-descriptor-20261005');old=(r/'seed/41-a64gen.kotoba').read_text();g=old
anchor='(def gn-f-out 12)';assert g.count(anchor)==1;g=g.replace(anchor,'(def gn-f-vkey 13)    ; proven unchanged local handle whose descriptor is in free x6\n'+anchor)
anchor='(defn- gn-vidx [M :vector-i64 ri :i64] :vector-i64'
helper=''';; x6 is unused by locals in non-leaves and in leaves with fewer than seven
;; local slots. Calls/control-flow/unknown effects invalidate this cache.
(defn- gn-vkey [M :vector-i64 t :i64] :i64
  (if (and (gn-isk M t gn-k-local)
           (or (= (gn-g M gn-f-leaf) 0) (< (gn-g M gn-f-ns) 7)))
      (gn-dv M t) 0))
(defn- gn-vhchk [M :vector-i64 rv :i64 key :i64] :vector-i64
  (if (and (> key 0) (= key (gn-g M gn-f-vkey)))
      (gn-mov M 16 6)
      (let [M1 (gn-hchk M rv 312 320)]
        (if (> key 0) (-> M1 (gn-mov 6 16) (gn-gs gn-f-vkey key)) M1))))
'''
assert g.count(anchor)==1;g=g.replace(anchor,helper+anchor)
a='''  (let [M1 (gn-pin M (inc t))
        ri''';b='''  (let [key (gn-vkey M t)
        M1 (gn-pin M (inc t))
        ri''';assert g.count(a)==1;g=g.replace(a,b)
a='(gn-hchk rv 312 320) (gn-vidx ri) (gn-emit (gn-e-ldrr d 16 17 1))';b='(gn-vhchk rv key) (gn-vidx ri) (gn-emit (gn-e-ldrr d 16 17 1))';assert g.count(a)==1;g=g.replace(a,b)
a='''  (let [M1 (-> M (gn-pin t) (gn-pin (inc t)))
        M2''';b='''  (let [key (gn-vkey M t)
        M1 (-> M (gn-pin t) (gn-pin (inc t)))
        M2''';assert g.count(a)==1;g=g.replace(a,b)
a='(gn-hchk rv 312 320) (gn-vidx ri) (gn-emit (gn-e-strr3 rx 16 17))';b='(gn-vhchk rv key) (gn-vidx ri) (gn-emit (gn-e-strr3 rx 16 17))';assert g.count(a)==1;g=g.replace(a,b)
# Result coalescing consumes LSET; invalidate there as well as explicit LSET.
a='(cond (> s 0) (-> M (gn-def t gn-k-local s) (gn-gs gn-f-skip 1))';b='(cond (> s 0) (-> M (cond-> (= s (gn-g M gn-f-vkey)) (gn-gs gn-f-vkey 0)) (gn-def t gn-k-local s) (gn-gs gn-f-skip 1))';assert g.count(a)==1;g=g.replace(a,b)
a='''        c (gn-sir M i IF-C)]
    (if (and (= (gn-g M gn-f-dead) 1)'''
b='''        c (gn-sir M i IF-C)
        safe (or (= op OP-CONST) (= op OP-LGET) (= op OP-BIN) (= op OP-UN) (= op OP-FUEL)
                 (and (= op OP-LSET) (not= a (gn-g M gn-f-vkey)))
                 (and (= op OP-RT) (gn-inl a b c)
                      (or (= a RT-VECTOR-AT) (= a RT-VECTOR-ASSOC-IN-PLACE))))
        M (if safe M (gn-gs M gn-f-vkey 0))]
    (if (and (= (gn-g M gn-f-dead) 1)'''
assert g.count(a)==1;g=g.replace(a,b)
(w/'41-a64gen-prototype.kotoba').write_text(g)
files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];u=''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files);(w/'seed-unity.kotoba').write_text(u);(w/'seed-unity.kotoba.sha256').write_text(hashlib.sha256(u.encode()).hexdigest()+'\n')
for ext in ['bin','offset']:shutil.copyfile(Path('/private/tmp/amu-sign-wrapper-20261005')/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile('/private/tmp/amu-sign-wrapper-20261005/kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['check-ports.py','bulk-state.py']:
 s=Path('/private/tmp/amu-constant-index-20261005',name).read_text().replace('/private/tmp/amu-constant-index-20261005','/private/tmp/amu-vector-descriptor-20261005');(w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'hypothesis':'Reuse checked vector descriptor in free x6 for repeated accesses to same unchanged local handle, keeping each index bound check and fuel.','admission':'non-leaf or leaf with ns<7; exact local descriptor; invalidate calls, labels, branches, comparisons, unknown effects, replacements, and coalesced replacement','promotion':'Fresh 30 rotating baseline/candidate/C triples, >=1.05 speedup and gap>sumSD, existing quiet policy; correctness and fixed-point required','sourceHead':'20116bc27586155eae3289438f26c67ae6f1a253','exception':'One-off new compiler algorithm authoring, no mechanical refactor'},indent=2)+'\n');print('prototype ready')
