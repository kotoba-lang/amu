from pathlib import Path
import importlib.util,subprocess,os,re,json,types,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-vector-descriptor-20261005');sp=importlib.util.spec_from_file_location('fx',r/'scripts/seed/a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
# Cached descriptor validity and x6 ownership probes; expected values are manual.
alloc=[('CONST',0,3),('RT','RT-VECTOR-ALLOC',0,1),('LSET',1,0)]
put=lambda slot,index,value:[('LGET',0,slot),('CONST',1,index),('CONST',2,value),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3)]
read=lambda slot,index,t=0:[('LGET',t,slot),('CONST',t+1,index),('RT','RT-VECTOR-AT',t,2)]
m.fx('desc_reads',0,4,[('FUEL',),('FUEL',)]+alloc+put(1,0,11)+put(1,1,22)+read(1,0)+[('LSET',2,0)]+read(1,1)+[('LSET',3,0)]+read(1,2)+[('LGET',1,2),('BIN','BOP-ADD',0),('LGET',1,3),('BIN','BOP-ADD',0),('RET',0)])
m.run('desc_reads',[],33,fuel=2);m.run('desc_reads',[],'trap',fuel=1)
m.fx('desc_mutate',0,2,[('FUEL',)]+alloc+put(1,0,11)+read(1,0)+[('LSET',2,0)]+put(1,0,99)+read(1,0)+[('LGET',1,2),('BIN','BOP-ADD',0),('RET',0)])
m.run('desc_mutate',[],110,fuel=1)
# Prepare two handles with distinct values before priming the cache.
two=alloc+put(1,0,11)+[('CONST',0,3),('RT','RT-VECTOR-ALLOC',0,1),('LSET',2,0)]+put(2,0,22)
m.fx('desc_replace',0,3,two+read(1,0)+[('LSET',3,0),('LGET',0,2),('LSET',1,0)]+read(1,0)+[('RET',0)])
m.run('desc_replace',[],22)
m.fx('desc_coalesce',0,3,two+read(1,0)+[('LSET',3,0),('LGET',0,1),('CONST',1,1),('BIN','BOP-ADD',0),('LSET',1,0)]+read(1,0)+[('RET',0)])
m.run('desc_coalesce',[],22)
m.fx('desc_target7',7,7,[('FUEL',),('LGET',0,1),('RET',0)])
m.fx('desc_call',0,3,[('FUEL',)]+two+read(1,0)+[('LSET',3,0),('LGET',0,2)]+[('CONST',t,99) for t in range(1,7)]+[('CALL','desc_target7',0,7),('LSET',3,0)]+read(1,0)+[('RET',0)])
m.run('desc_call',[],11,fuel=2);m.run('desc_call',[],'trap',fuel=1)
m.fx('desc_branch',1,4,[('LGET',0,1),('LSET',4,0)]+two+read(1,0)+[('LSET',3,0),('LGET',0,4),('BRZ',0,'desc_b_join'),('LGET',0,2),('LSET',1,0),('LABEL','desc_b_join')]+read(1,0)+[('RET',0)])
m.run('desc_branch',[0],11);m.run('desc_branch',[1],22)
m.fx('desc_leaf7',7,7,[('FUEL',),('LGET',0,1),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('LGET',1,7),('BIN','BOP-ADD',0),('RET',0)])
m.fx('desc_leaf7_caller',0,1,[('FUEL',)]+alloc+put(1,0,11)+[('LGET',0,1)]+[('CONST',t,99) for t in range(1,7)]+[('CALL','desc_leaf7',0,7),('RET',0)])
m.run('desc_leaf7_caller',[],110,fuel=2);m.run('desc_leaf7_caller',[],'trap',fuel=1)
m.fx('desc_bad_second',0,2,alloc+read(1,0)+[('LSET',2,0)]+read(1,3)+[('RET',0)]);m.run('desc_bad_second',[],'trap')
m.fx('desc_high',0,2,alloc+put(1,0,11)+read(1,0)+[('LSET',2,0)]+read(1,0,5)+[('RET',5)]);m.run('desc_high',[],11)
m.fx('desc_loop',1,4,[('LGET',0,1),('LSET',4,0)]+alloc+put(1,0,11)+[('CONST',0,0),('LSET',2,0),('LABEL','desc_loop_start'),('FUEL',),('LGET',0,4),('BRZ',0,'desc_loop_end')]+read(1,0)+[('LSET',3,0),('LGET',0,2),('LGET',1,3),('BIN','BOP-ADD',0),('LSET',2,0),('LGET',0,4),('CONST',1,1),('BIN','BOP-SUB',0),('LSET',4,0),('BR','desc_loop_start'),('LABEL','desc_loop_end'),('LGET',0,2),('RET',0)])
for n in [0,1,3,9]:m.run('desc_loop',[n],11*n,fuel=n+1)
m.run('desc_loop',[3],'trap',fuel=3)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800');loader=str(w/'kexe-loader');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];chunks=[]
for real in [False,True]:
 prefix='fixture-real' if real else 'fixture-test';src=w/(prefix+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real))
 for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(prefix+'.kseed'))]),('extract',['extract-native',str(w/(prefix+'.kseed')),'--symbol','main','--output',str(w/(prefix+'.bin'))])]:
  p=subprocess.run([loader,str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(prefix+'-'+label+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(label,p.stdout,p.stderr)
  if label=='extract':off=re.search(r':offset (\d+)',p.stdout).group(1)
 p=subprocess.run([loader,str(w/(prefix+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(prefix+'.stdout')).write_text(p.stdout);assert p.returncode==0,p.stderr;chunks.append(p.stdout)
assert m.blob_from(chunks[0])[0].rstrip(b'\0')==m.blob_from(chunks[1])[0].rstrip(b'\0') and m.blob_from(chunks[0])[1]==m.blob_from(chunks[1])[1]
d=w/'fixture-run/unit/41-a64gen';d.mkdir(parents=True,exist_ok=True);(d/'stdout').write_text(chunks[1]);os.environ['SEED_BUILD']=str(w/'fixture-run');original=m.subprocess.run

def run(args,**kw):
 if args[:2]==['zsh',m.R+'/scripts/seed/unit.sh']:return types.SimpleNamespace(returncode=0,stdout='native experimental fixture emitter already verified; byte golden untouched',stderr='')
 return original(args,**kw)
m.subprocess.run=run;assert m.runs(False)==0
blob,fns=m.blob_from(chunks[1]);names=[f[0] for f in m.FIX];audit={}
for name in ['desc_reads','desc_leaf7']:
 f=names.index(name)+1;end=fns.get(f+1,int(re.search(r'words (\d+)',chunks[1]).group(1))*4);words=struct.unpack('<'+'I'*((end-fns[f])//4),blob[fns[f]:end]);put=sum(x==0xaa1003e6 for x in words);hit=sum(x==0xaa0603f0 for x in words)
 if name=='desc_reads':assert put>=1 and hit>=2,(name,put,hit)
 else:assert put==hit==0,(name,put,hit)
 audit[name]={'cacheDescriptorMovToX6':put,'reuseDescriptorMovFromX6':hit,'bytes':end-fns[f]}
(w/'fixture-proof.json').write_text(json.dumps({'runs':len(m.RUNS),'fixtures':len(m.FIX),'realTestLayoutIdentical':True,'instructionAudit':audit},indent=2)+'\n');print('PASS descriptor-cache instruction audits',flush=True)
