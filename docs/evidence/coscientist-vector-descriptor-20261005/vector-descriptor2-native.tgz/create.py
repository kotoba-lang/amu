from pathlib import Path
import shutil,hashlib,json
r=Path('/Users/junkawasaki/github/wt/amu-seed17');b=Path('/private/tmp/amu-vector-descriptor-20261005');w=Path('/private/tmp/amu-vector-descriptor2-20261005');g=(b/'41-a64gen-prototype.kotoba').read_text()
a='''                 (and (= op OP-LSET) (not= a (gn-g M gn-f-vkey)))'''
z='''                 (and (= op OP-CALL)
                      (let [wrapper (gn-call-wrapper M i a b c) kind (bit-and wrapper 255)]
                        (or (>= wrapper 1024)
                            (and (> wrapper 0) (or (= kind 1) (= kind RT-VECTOR-AT)
                                                   (= kind RT-VECTOR-ASSOC-IN-PLACE))))))
                 (and (= op OP-LSET) (not= a (gn-g M gn-f-vkey)))'''
assert g.count(a)==1;g=g.replace(a,z);(w/'41-a64gen-prototype.kotoba').write_text(g)
files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];u=''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files);(w/'seed-unity.kotoba').write_text(u);(w/'seed-unity.kotoba.sha256').write_text(hashlib.sha256(u.encode()).hexdigest()+'\n')
for ext in ['bin','offset']:shutil.copyfile(Path('/private/tmp/amu-sign-wrapper-20261005')/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile(b/'kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
for name in ['check-ports.py','bulk-state.py','fixture-proof.py','remote.py']:
 s=(b/name).read_text().replace('/private/tmp/amu-vector-descriptor-20261005','/private/tmp/amu-vector-descriptor2-20261005').replace('/private/tmp/amu-zebulun-vector-descriptor-20261005','/private/tmp/amu-zebulun-vector-descriptor2-20261005');(w/name).write_text(s)
(w/'hypothesis.json').write_text(json.dumps({'hypothesis':'Descriptor reuse across proven inlined sign/identity/vector-at/vector-set wrappers; all genuine/unknown calls still invalidate.','firstExperiment':'Descriptor reuse invalidating every source call gave 0.98944x Picojpeg speedup; not promoted.','promotion':'same prospective 30 triple and >=1.05/summedSD criteria; no repeat of first experiment','sourceHead':'20116bc27586155eae3289438f26c67ae6f1a253','exception':'One-off new compiler algorithm authoring'},indent=2)+'\n')
