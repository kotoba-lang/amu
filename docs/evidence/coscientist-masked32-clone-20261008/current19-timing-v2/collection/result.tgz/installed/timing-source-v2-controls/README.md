# Prospective masked clone current19 timing

SOURCE only. No timing, SSH, native build, guest or official score has been run by this author.

The current remote-v3 19 runners, consumer cb3f, same fresh C cohort, and exact OFF/ON artifacts are preserved. Independent actual285 review d645 is a required parsed prerequisite. Five functional profiles remain mandatory; timing uses original maxN (32, depthconv2000). Every result/fuel/four terminal arenas/C-null receipt must match the accepted per-arm oracle; warmup1 and per-call reset/fuel16777216 remain unchanged.

Calibration has 5 attempts per arm, each bracketed by load queries. The target is300ms, accepted225–450ms, fixed n, calls≤100M. Measurement collects30 whole quiet triples within90 attempts. All six arm orders rotate per deterministic block. Quiet means≥50ms elapsed, load≤4 before/after, enclosing external host idle plus waited child CPU share≥90%. Raw host idle is retained. This is a startup/warmup/process-envelope estimate; current runners do not expose timed-loop CPU telemetry. No fabricated timedCpuWindow field is accepted.

Limits:5415 runner processes +10830 load queries =16245 children;30s/5s timeouts,9000s/workload,172800s campaign. Child interruption kills/reaps its group. Raw bytes and terminal ledgers precede API/parsing/sourceguard failures. Any process/semantic/source failure stops. Quiet/calibration exhaustion records partial and continues once to later workloads; no retry, no history pooling. Source and root GO digests are guarded every time; two distinct parsed source PASS reports are required.

Mean/SD and paired20000 bootstrap draws are separated from qualification. Benefit needs stable relativeSD≤10%, speedup≥1.05, mean gap>sumSD and paired95%lower≥1.05. Aggregate fixed19 C goal and stronger each-workload C goal are distinct. No full19GM or C achievement on a partial cohort. Seventeen identical native programs are neutral for clone attribution; AES/SHA changed programs are the only clone candidates.

`campaign.py` is executable after reviews/root GO at the registered remote child. Installation/launch/collection transport implementation is deliberately a separate future source stage; no transfer is authorized by this source packet. The amendment supersedes copied historical transport counters/domains. No automatic restart or product adoption.
