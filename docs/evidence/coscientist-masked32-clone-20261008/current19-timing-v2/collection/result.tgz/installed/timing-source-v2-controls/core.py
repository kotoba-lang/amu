"""Pure, preregistered gates. No process or CPU API calls on import."""
import hashlib,statistics
from statistics_core import ARMS,order,normalized,descriptive,paired_ci,cohort_gm_ci
IGNORE={'calls','warmupCalls','elapsedNanoseconds','maxRssBytes','timedCpuWindow'}
def semantic(o):return {k:v for k,v in o.items() if k not in IGNORE}
def seed(cohort,workload,direction,global_scope=False):
 domain='MASKED32-current19-fixed19-gm-ci/v1' if global_scope else 'MASKED32-current19-paired-ci/v1'
 return int.from_bytes(hashlib.sha256((domain+'|'+cohort+'|'+workload+'|'+direction).encode('ascii')).digest(),'big')
def quiet(o,before_load,after_load,extb,exta,child_seconds):
 import external_cpu
 if o['elapsedNanoseconds']<50000000:return False,{'reason':'below50ms'}
 try:
  activity=external_cpu.interval(extb,exta)
 except ValueError as ex:
  if str(ex)=='CPU counters did not advance':return False,{'reason':'zeroCPUticks'}
  raise
 if extb['processors']!=exta['processors']:raise ValueError('processor count changed')
 q=external_cpu.background_activity(activity,round(child_seconds*1000000000),extb['processors'])
 ok=before_load<=4 and after_load<=4 and q['estimatedBackgroundIdlePercent']>=90
 return ok,{'reason':'accepted' if ok else 'notQuiet','external':q,'beforeLoad':before_load,'afterLoad':after_load}
def summarize(xs,cohort,name):
 d=descriptive(xs);ci={}
 for den,num in [('candidate','baseline'),('candidate','C')]:
  key=num+'/'+den;ci[key]=paired_ci(xs,den,num,seed(cohort,name,key))
 d['pairedCI95']=ci
 a=d['arms'];d['COrBetter']=d['stable'] and a['C']['meanNsPerBody']>=a['candidate']['meanNsPerBody'] and ci['C/candidate']['lower95']>=1.0
 d['baselineAdoptionBenefit']=d['candidateImprovesBaselineOriginalPredicate'] and ci['baseline/candidate']['lower95']>=1.05
 d['CAdoptionBenefit']=d['candidateImprovesCOriginalPredicate'] and ci['C/candidate']['lower95']>=1.05
 return d
def full_summary(rows,cohort):
 assert len(rows)==19 and all(len(x)==30 for x in rows.values())
 per={n:summarize(x,cohort,n) for n,x in rows.items()}
 gm={num+'/candidate':cohort_gm_ci(rows,'candidate',num,seed(cohort,'FULL19',num+'/candidate',True)) for num in ['baseline','C']}
 return {'workloads':per,'fixed19PairedGM':gm,'all19IndividualCOrBetter':all(x['COrBetter'] for x in per.values()),'full19AggregateCOrBetter':all(x['stable'] for x in per.values()) and gm['C/candidate']['fixed19GM']>=1.0 and gm['C/candidate']['lower95']>=1.0,'individualConfidenceScope':'19 separate marginal95 intervals, no joint95 claim','officialScore':False,'CIDEffectQualified':False,'productAdopted':False,'bootstrap':'paired30 within fixed19, 20000; uncertainty does not replace stability/effect gates'}
