"""Pure proposed analysis; never reads actual timing, spawns a process or qualifies a cohort."""
import hashlib,itertools,math,random,statistics
ARMS=('baseline','candidate','C')
def order(workload,attempt):
 assert type(attempt) is int and 0<=attempt<90
 block,k=divmod(attempt,6);salt='MASKED32-current19-balanced-order/v1|'+workload+'|'+str(block)+'|'
 perms=sorted(itertools.permutations(ARMS),key=lambda p:hashlib.sha256((salt+','.join(p)).encode()).digest())
 return perms[k]
def normalized(triple,n):
 assert type(n) is int and n>0 and set(triple)==set(ARMS)
 result={}
 for a in ARMS:
  t,c=triple[a];assert type(t) is int and t>=50000000 and type(c) is int and 1<=c<=100000000
  result[a]=t/(c*n)
 return result
def paired_ci(xs,denominator,numerator,seed,replicates=20000):
 assert len(xs)==30 and replicates==20000
 logs=[math.log(x[numerator]/x[denominator]) for x in xs];rng=random.Random(seed)
 draws=sorted(math.exp(statistics.mean(logs[rng.randrange(30)] for _ in range(30))) for _ in range(replicates))
 return {'geometricMeanPairedRatio':math.exp(statistics.mean(logs)),'lower95':draws[499],'upper95':draws[19499]}
def descriptive(xs):
 assert len(xs)==30
 z={a:{'meanNsPerBody':statistics.mean(x[a] for x in xs),'sdNs':statistics.stdev(x[a] for x in xs)} for a in ARMS}
 stable=all(v['sdNs']/v['meanNsPerBody']<=.1 for v in z.values())
 def improves(ref,cand):
  a,b=z[ref],z[cand]
  return stable and a['meanNsPerBody']/b['meanNsPerBody']>=1.05 and a['meanNsPerBody']-b['meanNsPerBody']>a['sdNs']+b['sdNs']
 return {'arms':z,'stable':stable,'candidateImprovesBaselineOriginalPredicate':improves('baseline','candidate'),'candidateImprovesCOriginalPredicate':improves('C','candidate')}
def cohort_gm_ci(workloads,denominator,numerator,seed,replicates=20000):
 assert len(workloads)==19 and all(len(xs)==30 for xs in workloads.values()) and replicates==20000
 vectors=[[math.log(x[numerator]/x[denominator]) for x in workloads[n]] for n in sorted(workloads)]
 rng=random.Random(seed);draws=[]
 for _ in range(replicates):draws.append(math.exp(statistics.mean(statistics.mean(v[rng.randrange(30)] for _ in range(30)) for v in vectors)))
 draws.sort();return {'fixed19GM':math.exp(statistics.mean(statistics.mean(v) for v in vectors)),'lower95':draws[499],'upper95':draws[19499],'scope':'fixed workload set, within-workload paired triple resampling only'}
