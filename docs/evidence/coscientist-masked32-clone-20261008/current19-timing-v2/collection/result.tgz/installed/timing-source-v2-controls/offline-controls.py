"""Pure metadata, arithmetic and fake-child tests. Never invokes an OS child."""
from pathlib import Path
import sys,types,json,copy,tempfile
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D));sys.dont_write_bytecode=True
m=types.ModuleType('campaign');m.__file__=str(D/'campaign.py');exec(compile((D/'campaign.py').read_bytes(),str(D/'campaign.py'),'exec'),m.__dict__)
x,d,expected,mapped=m.evidence();assert len(expected)==285 and len(mapped)==57
passed=[]
def rejection(label,f):
 try:f()
 except (AssertionError,ValueError,TypeError,KeyError):passed.append(label);return
 raise AssertionError('accepted mutant '+label)
# All57 actual maximum-profile records must remain accepted under futurecalls/warmup.
for e in d['entries']:
 for arm in m.core.ARMS:
  n=max(e['inputs']);o=dict(next(a['receipt'] for t in x['functionalComparisons'] if t['workload']==e['workload'] and t['n']==n for a in t['arms'] if a['arm']==arm));o.update(calls=3,warmupCalls=1,elapsedNanoseconds=300000000,maxRssBytes=0)
  raw=(json.dumps(o)+'\n').encode();assert m.core.semantic(m.packet(raw,arm,n,3))==expected[(e['workload'],n,arm)]
  if arm=='baseline' and e is d['entries'][0]:sample=o
passed.append('all57maximumProfiles')
for label,path,value in [('boolcalls',['calls'],True),('badfuel',['contextFuelConsumed'],0),('badresult',['result'],0),('boolarena',['nativeArenas','pairs','used'],True),('wrongcapacity',['nativeArenas','pairs','capacity'],1)]:
 z=copy.deepcopy(sample);q=z
 for k in path[:-1]:q=q[k]
 q[path[-1]]=value;rejection(label,lambda z=z:m.packet((json.dumps(z)+'\n').encode(),'baseline',32,3))
rejection('extraCPUfield',lambda:m.packet((json.dumps({**sample,'timedCpuWindow':{}})+'\n').encode(),'baseline',32,3))
rejection('duplicatefield',lambda:m.packet(b'{"calls":3,"calls":3}\n','baseline',32,3))
# External quiet contract keeps raw idle, corrects only waited child CPU within host capacity.
b={'ticks':[0,0,0,0],'monotonicNs':1,'processors':4,'api':'host_processor_info/PROCESSOR_CPU_LOAD_INFO'}
a={**b,'ticks':[2,0,98,0],'monotonicNs':1000000001}
assert m.core.quiet(sample,1,1,b,a,.01)[0]
assert not m.core.quiet(sample,5,1,b,a,.01)[0]
assert not m.core.quiet(sample,1,1,b,{**a,'ticks':[50,0,50,0]},0)[0]
assert not m.core.quiet({**sample,'elapsedNanoseconds':49999999},1,1,b,a,.01)[0]
assert not m.core.quiet(sample,1,1,b,{**a,'ticks':[0,0,0,0]},0)[0]
rejection('CPUcapacityoverflow',lambda:m.core.quiet(sample,1,1,b,a,5))
rejection('processorcountchange',lambda:m.core.quiet(sample,1,1,b,{**a,'processors':8},.01))
passed.append('quietFourRejectsAndRawEstimate')
for name in [e['workload']for e in d['entries']]:
 for block in range(15):assert len({m.core.order(name,block*6+i)for i in range(6)})==6
passed.append('19balancedOrders90')
assert 19*3*(5+90)==5415 and 2*5415==10830 and 5415+10830==16245
# Fake children exercise successful raw-before-return, failure stop, interruption kill+reap.
oldout=m.OUT;oldp=m.subprocess.Popen;oldkill=m.os.killpg
class Fake:
 pid=12345
 def __init__(self,interrupt=False,rc=0):self.returncode=None;self.interrupt=interrupt;self.rc=rc;self.calls=0
 def communicate(self,timeout=None):
  self.calls+=1
  if self.interrupt and self.calls==1:raise KeyboardInterrupt('fake')
  self.returncode=self.rc;return b'raw\n',b''
with tempfile.TemporaryDirectory(dir=D,prefix='pure-fake-') as td:
 m.OUT=Path(td);(m.OUT/'runner').mkdir();(m.OUT/'load').mkdir();k=[];m.os.killpg=lambda *a:k.append(a)
 f=Fake();m.subprocess.Popen=lambda *a,**kw:f;L=m.Ledger();raw,event=L.call('runner','fake',[],{},1);assert raw==b'raw\n'and event['state']=='terminal'and(m.OUT/'runner/1.stdout').read_bytes()==raw
 f=Fake(rc=1);m.subprocess.Popen=lambda *a,**kw:f;rejection('fakeFirstFailureSTOP',lambda:L.call('runner','bad',[],{},1));assert L.rows[-1]['returncode']==1 and L.rows[-1]['state']=='terminal'
 f=Fake(interrupt=True);m.subprocess.Popen=lambda *a,**kw:f;rejection('fakeInterruptReapedSTOP',lambda:L.call('runner','interrupt',[],{},1));assert f.calls==2 and k and L.rows[-1]['state']=='terminal'
 class DrainTimeout(Fake):
  def communicate(self,timeout=None):
   assert timeout==30
   raise m.subprocess.TimeoutExpired('fake',timeout,output=b'partial',stderr=b'')
  def wait(self,timeout=None):assert timeout==30;self.returncode=-9;return -9
 f=DrainTimeout();a,b,e=L.drain(f);assert a==b'partial'and b==b''and f.returncode==-9 and e
 class Unclosed(DrainTimeout):
  def wait(self,timeout=None):assert timeout==30;raise m.subprocess.TimeoutExpired('fake-wait',timeout)
 f=Unclosed();a,b,e=L.drain(f);assert f.returncode is None and e
 passed.append('boundedDrainReapedAndUnclosedHonest')
m.OUT=oldout;m.subprocess.Popen=oldp;m.os.killpg=oldkill
passed.append('noOSChildFakeLifecycle')
# Pure evidence source mutation must fail authoritatively, not accept another arbitrary PASS.
oldload=m.load
for field,val in [('status','PASS'),('closedFunctionalCalls',284),('nativeFuelAndFourTerminalArenaPairExact',False)]:
 def changed(p,field=field,val=val):
  z=oldload(p)
  if Path(p).name=='functionalReview.json':z={**z,field:val}
  return z
 m.load=changed;rejection('functionalProof-'+field,m.evidence)
m.load=oldload
(D/'offline-controls-result.json').write_text(json.dumps({'status':'PASS_PURE_METADATA_CONTROLS_ONLY','controls':passed,'nativeCalls':0,'SSHCalls':0,'OSChildCalls':0},indent=2)+'\n')
print('PURE',len(passed))
