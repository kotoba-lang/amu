"""One finite custom matched-C campaign. Requires root GO; no actions on import."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time,resource,types,math,re
import core
D=Path(__file__).resolve().parent
N=Path('/Users/zebulun/github/workspaces/codex/vector-masked32-original19-remote-v3-root')
OUT=N/'timing-campaign-v2-controls'
def H(b):return hashlib.sha256(b).hexdigest()
def sha(p):return H(Path(p).read_bytes())
def need(v,s):
 if not v:raise AssertionError(s)
def load(p):return json.loads(Path(p).read_text())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def pin(p,e):need(Path(p).is_file() and not Path(p).is_symlink() and Path(p).stat().st_size==e['bytes'] and sha(p)==e['sha256'],'exact file '+str(p))
def source_guard(expected):
 need(sha(D/'source-pins.json')==expected,'source manifest bound to root GO')
 pins=load(D/'source-pins.json')
 for name,e in pins.items():pin(D/name,e)
 for e in load(D/'remote-input-pins.json'):pin(e['path'],e)
 return expected
class Ledger:
 def drain(self,p):
  try:return (*p.communicate(timeout=30),None)
  except subprocess.TimeoutExpired as ex:
   out=ex.output or b'';err=ex.stderr or b''
   try:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    p.wait(timeout=30)
   except BaseException as cleanup:return out,err,'bounded drain/reap failed '+repr(cleanup)
   return out,err,'pipe drain timeout, child reaped without further pipe read'
 def __init__(self):self.rows=[];self.count={'runner':0,'load':0};self.cap={'runner':5415,'load':10830}
 def call(self,kind,label,argv,env,timeout):
  need(self.count[kind]<self.cap[kind],'finite '+kind+' cap');self.count[kind]+=1
  idx=self.count[kind];prefix=kind+'/'+str(idx);r={'kind':kind,'index':idx,'label':label,'argv':argv,'environment':env,'timeoutSeconds':timeout,'state':'started','startedMonotonicNs':time.monotonic_ns()};self.rows.append(r);save(OUT/'attempts.json',self.rows)
  p=None;o=e=b'';timed=False;rc=None;error=None
  try:
   p=subprocess.Popen(argv,cwd=N,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
   try:o,e=p.communicate(timeout=timeout)
   except subprocess.TimeoutExpired:
    timed=True;os.killpg(p.pid,signal.SIGKILL);o,e,error=self.drain(p)
   rc=p.returncode
  except BaseException as ex:
   error=repr(ex)
   if p is not None:
    try:
     try:os.killpg(p.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     o,e,cleanup_error=self.drain(p);rc=p.returncode
     if cleanup_error:error+=';cleanup='+cleanup_error
    except BaseException as cleanup:error+=';cleanup='+repr(cleanup)
  # Persist raw and closure BEFORE parsing, snapshots, guards, or any next process.
  (OUT/(prefix+'.stdout')).write_bytes(o);(OUT/(prefix+'.stderr')).write_bytes(e)
  r.update(state='terminal' if p is None or p.returncode is not None else 'unclosed',returncode=rc,timeout=timed,exception=error,closedMonotonicNs=time.monotonic_ns(),stdoutSHA256=H(o),stderrSHA256=H(e));save(OUT/'attempts.json',self.rows)
  need(error is None and not timed and rc==0 and not e,'first child failure STOP');return o,r

def packet(raw,arm,n,calls):
 def pairs(z):
  x={}
  for k,v in z:need(k not in x,'duplicate JSON');x[k]=v
  return x
 need(len(raw)<=65536 and raw.endswith(b'\n') and raw.count(b'\n')==1,'single bounded JSON');o=json.loads(raw,object_pairs_hook=pairs)
 fields={'format','calls','warmupCalls','elapsedNanoseconds','result','maxRssBytes','fuelPerCall','contextFuelBefore','contextFuelAfter','contextFuelConsumed','nativeArtifactAbi','artifactKind','nativeArenaStatus','nativeArenas'}
 need(type(o) is dict and set(o)==fields and o['format']=='kotoba.runtime-sample/v1','exact runner schema')
 for k in fields-{'format','nativeArtifactAbi','artifactKind','nativeArenaStatus','nativeArenas'}:need(type(o[k]) is int,'exact integer '+k)
 need(o['calls']==calls and o['warmupCalls']==1 and o['fuelPerCall']==o['contextFuelBefore']==16777216,'fixed requested counts/fuel')
 need(o['result']==1 and -(1<<63)<=o['result']<(1<<63) and n>0,'positiveN unchanged source oracle')
 need(o['maxRssBytes']>=0 and 0<o['contextFuelAfter']<=16777216 and o['contextFuelConsumed']==16777216-o['contextFuelAfter'],'final fuel/resource')
 need(o['nativeArtifactAbi']=='kotoba.native-artifact-i64x8-to-i64-indirect/v1','ABI')
 if arm=='C':need(o['artifactKind']=='dylib' and o['nativeArenaStatus']=='unavailable-C' and o['nativeArenas'] is None and o['contextFuelConsumed']==0,'C unavailable/null')
 else:
  need(o['artifactKind']=='raw' and o['nativeArenaStatus']=='available' and type(o['nativeArenas']) is dict and set(o['nativeArenas'])=={'pairs','stringPoolBytes','vectors','vectorItems'},'native arenas')
  for k,cap in {'pairs':2097152,'stringPoolBytes':65536,'vectors':4096,'vectorItems':65536}.items():
   a=o['nativeArenas'][k];need(type(a) is dict and set(a)=={'capacity','used'} and type(a['capacity']) is int and type(a['used']) is int and a['capacity']==cap and 0<=a['used']<=cap,'native exact capacity/used')
 return o

def evidence():
 bindings=load(D/'proof-bindings.json');x={}
 for role,z in bindings.items():pin(D/'proofs'/(role+'.json'),z);x[role]=load(D/'proofs'/(role+'.json'))
 r=x['functionalReview'];ip=x['functionalInputPins']
 need(r['status']=='PASS_INDEPENDENT_FINITE_MASKED32_ORIGINAL19_285_FUNCTIONAL_ONLY' and r['closedFunctionalCalls']==285 and r['comparisons']==95 and r['workloads']==19 and r['allRawHashesArgvEnvAndTypedSemanticRejoined'] is True and r['nativeFuelAndFourTerminalArenaPairExact'] is True and r['CNativeArenasUnavailableNull'] is True and r['inputPinsSHA256']==bindings['functionalInputPins']['sha256'],'specific actual285 review')
 for role in ['functionalReport','functionalTerminal','functionalComparisons','functionalAttempts','buildReport','buildTerminal','identityBefore','identityAfter','matrix']:
  z=bindings[role];need(ip[z['path']]=={'bytes':z['bytes'],'sha256':z['sha256']},'audited raw pin '+role)
 need(x['functionalTerminal']=={'allCallsClosed':True,'calls':285,'failure':False} and x['functionalReport']['status']=='PASS_FINITE_MASKED32_ORIGINAL19_285_FUNCTIONAL_ONLY','accepted285 terminal')
 need(x['functionalReport']['comparisons']==x['functionalComparisons'] and len(x['functionalComparisons'])==95 and len(x['functionalAttempts'])==285,'exact285/95')
 need(x['buildTerminal']=={'allBuildsClosed':True,'allQueriesClosed':True,'builds':19,'identityQueries':14,'failure':False} and x['buildReport']['status']=='PASS_FRESH19_RUNNER_BUILD_IDENTITY_ONLY' and x['buildReport']['clangInvocations']==23,'accepted currentbuild33')
 need(x['identityBefore']==x['identityAfter'],'identity unchanged')
 desc=x['matrix'];need(len(desc['entries'])==19 and len(x['buildReport']['images'])==19,'fixed19')
 expected={(t['workload'],t['n'],a['arm']):core.semantic(a['receipt']) for t in x['functionalComparisons'] for a in t['arms']};need(len(expected)==285,'all285 unique')
 mapped={}
 for e,r in zip(desc['entries'],x['buildReport']['images']):
  need(e['workload']==r['workload'] and r['headerSHA256']==e['header']['sha256'] and r['telemetrySourceSHA256']==desc['telemetrySource']['sha256'],'runner source/header identity')
  need(e['inputs']==([0,1,2,17,2000] if e['workload']=='depthconv' else [0,1,2,17,32]),'original fullprofiles')
  for arm in core.ARMS:
   rows=[z for z in x['functionalAttempts'] if z['label']==e['workload']+'-'+arm+'-n'+str(max(e['inputs']))];need(len(rows)==1,'actual argv unique');z=rows[0]
   need(z['state']=='terminal' and z['returncode']==0 and z['failure'] is None and z['cleanupException'] is None,'actual closure')
   a=e[arm];need(z['logicalArgv']==[r['runner']['path'],'dylib' if arm=='C' else 'raw',a['path'],e['CSymbol'] if arm=='C' else str(a['offset']),'aarch64',str(max(e['inputs'])),'1','0','16777216'],'exact original logical argv')
   need(z['argv'][0]==r['runner']['path'] and z['argv'][2]=='/Users/zebulun/github/workspaces/codex/vector-masked32-original19-remote-v1-root/inputs/'+a['sha256'],'fixed actual path')
   mapped[(e['workload'],arm)]=z['argv'][2]
 return x,desc,expected,mapped

def main():
 need(len(sys.argv)==2,'root timing GO required');gp=Path(sys.argv[1]);g=load(gp)
 need(g['stage']=='timing' and g['timingAuthorized'] is True and g['functionalAuthorized'] is False and g['buildAuthorized'] is False and g['noRerun'] is True and g['outputRoot']==str(OUT) and g['outerExecution']=='require_escalated','separate exact root GO')
 need(g['sourcePinsSHA256']==source_guard(g['sourcePinsSHA256']) and g['maximumRunnerProcesses']==5415 and g['maximumLoadQueries']==10830 and g['maximumTotalChildren']==16245,'exact source/caps root GO')
 need(g['functionalIndependentReviewSHA256']==load(D/'proof-bindings.json')['functionalReview']['sha256'],'specific actual171 acceptance')
 need(type(g['sourceReviews']) is list and len(g['sourceReviews'])==2,'two distinct source reviews')
 need(len({q['sha256'] for q in g['sourceReviews']})==2,'distinct review files')
 for q in g['sourceReviews']:
  pin(q['path'],q);review=load(q['path']);need(review['status']=='PASS_SOURCE_ONLY_MASKED32_CURRENT19_EXTERNAL_TIMING_CAMPAIGN' and review['sourcePinsSHA256']==g['sourcePinsSHA256'],'exact independent source acceptance')
 x,d,expected,mapped=evidence();identity=x['identityBefore'];runners=x['buildReport']['images']
 need([r['workload'] for r in runners]==[r['workload'] for r in d['entries']],'all19 runner identities')
 cohort=H(json.dumps({'entries':d['entries'],'runners':runners,'telemetrySourceSHA256':d['telemetrySource']['sha256'],'functionalAudit':g['functionalIndependentReviewSHA256']},sort_keys=True,separators=(',',':')).encode())
 need(not OUT.exists(),'fresh campaign, no retry');OUT.mkdir();(OUT/'runner').mkdir();(OUT/'load').mkdir();(OUT/'workloads').mkdir();env={'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','LANG':'C','LC_ALL':'C','TZ':'UTC','HOME':'/Users/zebulun','TMPDIR':str(N/'runner-output/tmp'),'DEVELOPER_DIR':'/Library/Developer/CommandLineTools'};ledger=Ledger();accepted={};states=[];start=time.monotonic();goh=sha(gp);ws=None
 def wall_alarm(signum,frame):raise TimeoutError('registered campaign wall limit')
 signal.signal(signal.SIGALRM,wall_alarm);signal.alarm(172800)
 save(OUT/'attempts.json',ledger.rows)
 save(OUT/'effective-environment.json',{'environment':env,'removedNames':sorted(set(os.environ)-set(env)),'allOtherInheritedRemoved':True});save(OUT/'root-go.json',g);save(OUT/'cohort.json',{'sha256':cohort,'identity':identity,'immutableSourceHash':g['sourcePinsSHA256'],'officialScore':False})
 def guard():
  need(time.monotonic()-start<=172800,'campaign wall bound');need(ws is None or time.monotonic()-ws<=9000,'workload wall bound');need(sha(gp)==goh,'GO unchanged');need(source_guard(g['sourcePinsSHA256'])==g['sourcePinsSHA256'],'frozen campaign source manifest unchanged');evidence()
  need(sha(identity['compiler'])==identity['compilerSHA256'] and sha('/usr/bin/clang')==identity['usrBinClangSHA256'],'current toolchain unchanged')
  need({str(p):sha(p) for p in sorted(Path(identity['SDK']).glob('SDKSettings.*')) if p.is_file() and not p.is_symlink()}==identity['SDKSettings'],'SDK settings unchanged')
  for r in runners:pin(r['runner']['path'],r['runner'])
 def load_query(label):
  out,r=ledger.call('load',label,['/usr/sbin/sysctl','-n','vm.loadavg'],env,5)
  text=out.decode('ascii');need(re.fullmatch(r'\{ [0-9]+(?:\.[0-9]+)? [0-9]+(?:\.[0-9]+)? [0-9]+(?:\.[0-9]+)? \}\n',text) is not None,'exact sysctl load grammar');z=text[2:-3].split();v=[float(y) for y in z];need(all(math.isfinite(y) and y>=0 for y in v),'finite load');return v[0]
 def run(row,r,arm,calls,label):
  guard();before=load_query(label+'-before');guard()
  import external_cpu
  extb=external_cpu.snapshot();usageb=resource.getrusage(resource.RUSAGE_CHILDREN)
  a=row[arm];argv=[r['runner']['path'],'dylib' if arm=='C' else 'raw',mapped[(row['workload'],arm)],row['CSymbol'] if arm=='C' else str(a['offset']),'aarch64',str(max(row['inputs'])),str(calls),'1','16777216']
  raw,event=ledger.call('runner',label,argv,env,30)
  # Raw process receipt is already durable before any API/parse/guard.
  exta=external_cpu.snapshot();usagea=resource.getrusage(resource.RUSAGE_CHILDREN)
  save(OUT/'runner'/ (str(event['index'])+'.external.json'),{'before':extb,'after':exta,'childUserSeconds':usagea.ru_utime-usageb.ru_utime,'childSystemSeconds':usagea.ru_stime-usageb.ru_stime,'scope':'external startup/warmup/process envelope; enclosing quiet admission estimate, not timed-loop CPU'})
  guard();o=packet(raw,arm,max(row['inputs']),calls);need(core.semantic(o)==expected[(row['workload'],max(row['inputs']),arm)],'exact accepted285 final result/status/fuel/four arenas')
  after=load_query(label+'-after');guard();q,diagnostic=core.quiet(o,before,after,extb,exta,usagea.ru_utime+usagea.ru_stime-usageb.ru_utime-usageb.ru_stime)
  return o,{'runnerIndex':event['index'],'beforeLoad':before,'afterLoad':after,'quiet':q,'diagnostic':diagnostic}
 try:
  for row,r in zip(d['entries'],runners):
   ws=time.monotonic();state={'workload':row['workload'],'n':max(row['inputs']),'calibration':[],'triples':[],'accepted':[]};states.append(state);sp=OUT/'workloads'/(row['workload']+'.json');save(sp,state);calls={}
   for arm in core.ARMS:
    count=3
    for k in range(5):
     o,z=run(row,r,arm,count,row['workload']+'-cal-'+arm+'-'+str(k));state['calibration'].append({'arm':arm,'attempt':k,'calls':count,'elapsedNanoseconds':o['elapsedNanoseconds'],'receipt':core.semantic(o),**z});save(sp,state)
     if z['quiet'] and 225000000<=o['elapsedNanoseconds']<=450000000:calls[arm]=count;break
     if o['elapsedNanoseconds']==0:count=min(100000000,count*10)
     else:count=max(1,min(100000000,round(count*300000000/o['elapsedNanoseconds'])))
    if arm not in calls:state['status']='PARTIAL_CALIBRATION_CAP';save(sp,state);save(OUT/'report.json',{'status':state['status'],'completedWorkloads':len(accepted),'full19COrBetter':False,'officialScore':False});break
   if len(calls)!=3:continue
   for attempt in range(90):
    need(time.monotonic()-ws<=9000,'workload wall bound');triple={};receipts={};events={}
    for arm in core.order(row['workload'],attempt):
     o,z=run(row,r,arm,calls[arm],row['workload']+'-measure-'+str(attempt)+'-'+arm);triple[arm]=(o['elapsedNanoseconds'],calls[arm]);receipts[arm]=core.semantic(o);events[arm]=z
     if 'baseline' in receipts and 'candidate' in receipts:need(receipts['baseline']==receipts['candidate'],'native pair exact BEFORE next child')
    quiet=all(z['quiet'] for z in events.values());t={'attempt':attempt,'order':list(core.order(row['workload'],attempt)),'arms':events,'elapsedAndCalls':triple,'quietAccepted':quiet};state['triples'].append(t)
    if quiet:state['accepted'].append(core.normalized(triple,state['n']))
    save(sp,state)
    if len(state['accepted'])==30:break
   if len(state['accepted'])!=30:state['status']='PARTIAL_QUIET_TRIPLE_CAP';save(sp,state);save(OUT/'report.json',{'status':state['status'],'completedWorkloads':len(accepted),'full19COrBetter':False,'officialScore':False});continue
   state['status']='COMPLETE_30_QUIET_TRIPLES';accepted[row['workload']]=state['accepted'];save(sp,state)
  ws=None;guard()
  if len(accepted)!=19:
   save(OUT/'report.json',{'status':'PARTIAL_CUSTOM_COHORT_QUIET_OR_CALIBRATION_CAP','completedWorkloads':len(accepted),'all19COrBetter':False,'fixed19GM':None,'officialScore':False,'CIDEffectQualified':False,'productAdopted':False});return
  summary=core.full_summary(accepted,cohort);guard();save(OUT/'report.json',{'status':'COMPLETE_CUSTOM_MATCHED_C_FULL19_EXTERNAL_ENVELOPE_COHORT','completedWorkloads':19,'runnerCalls':ledger.count['runner'],'loadQueries':ledger.count['load'],'full19AggregateCOrBetter':summary['full19AggregateCOrBetter'],'all19IndividualCOrBetter':summary['all19IndividualCOrBetter'],'stabilityAccepted':all(v['stable'] for v in summary['workloads'].values()),'statistics':summary,'timingScope':'>=50ms actual timer; external process envelope idle estimate includes startup/warmup','timedLoopCpuQualified':False,'noHistoricalPooling':True,'officialScore':False,'CIDEffectQualified':False,'productAdopted':False,'codeEqualNativeArmsAttribution':'17 whole-code equal native arms are neutral; only AES/SHA clone preparation changed code'})
 except BaseException as ex:
  failure={'exception':repr(ex),'runnerCalls':ledger.count['runner'],'loadQueries':ledger.count['load'],'completedWorkloads':len(accepted),'policy':'STOP_FIRST_FAILURE_NO_RETRY'}
  save(OUT/'failure.json',failure)
  save(OUT/'report.json',{'status':'FAIL_STOP_FIRST_ERROR_CUSTOM_TIMING_COHORT','runnerCalls':ledger.count['runner'],'loadQueries':ledger.count['load'],'completedWorkloads':len(accepted),'full19AggregateCOrBetter':False,'all19IndividualCOrBetter':False,'fixed19GM':None,'officialScore':False,'CIDEffectQualified':False,'productAdopted':False,'failure':failure})
  raise
 finally:
  signal.alarm(0)
  save(OUT/'terminal.json',{'allChildrenClosed':all(z['state']=='terminal' for z in ledger.rows),'runnerCalls':ledger.count['runner'],'loadQueries':ledger.count['load'],'failure':(OUT/'failure.json').exists(),'partial':len(accepted)!=19})
if __name__=='__main__':main()
