from pathlib import Path
import json
W=Path('/Users/junkawasaki/github/workspaces/codex');D=W/'vector-masked32-current19-timing-source-v1-controls';P=W/'vector-aha-funnel-current19-timed-campaign-v2-native-controls'
s=(P/'campaign.py').read_text();s=s.replace("N=Path('/Users/zebulun/github/workspaces/codex/vector-aha-funnel-remote-runner-v1-root/timed-window19-prep-v1')\nO=N.parent\nOUT=N/'timing-campaign-v2'", "N=Path('/Users/zebulun/github/workspaces/codex/vector-masked32-original19-remote-v3-root')\nOUT=N/'timing-campaign-v1-controls'")
a=s.index('def source_guard():');b=s.index('class Ledger:',a)
s=s[:a]+'''def source_guard(expected):
 need(sha(D/'source-pins.json')==expected,'source manifest bound to root GO')
 pins=load(D/'source-pins.json')
 for name,e in pins.items():pin(D/name,e)
 for e in load(D/'remote-input-pins.json'):pin(e['path'],e)
 return expected
''' +s[b:]
s=s.replace("fields={'timedCpuWindow',", "fields={").replace("fields-{'timedCpuWindow',", "fields-{")
s=s.replace(" core.structural(o['timedCpuWindow'],o['elapsedNanoseconds'])\n",'')
a=s.index('def evidence(c):');b=s.index('\ndef main():',a)
s=s[:a]+'''def evidence():
 bindings=load(D/'proof-bindings.json');x={}
 for role,z in bindings.items():pin(D/'proofs'/(role+'.json'),z);x[role]=load(D/'proofs'/(role+'.json'))
 r=x['functionalReview'];ip=x['functionalInputPins']
 need(r['status']=='PASS_INDEPENDENT_FINITE_MASKED32_ORIGINAL19_285_FUNCTIONAL_ONLY' and r['closedFunctionalCalls']==285 and r['comparisons']==95 and r['workloads']==19 and r['allRawHashesArgvEnvAndTypedSemanticRejoined'] is True and r['nativeFuelAndFourTerminalArenaPairExact'] is True and r['CNativeArenasUnavailableNull'] is True and r['inputPinsSHA256']==bindings['functionalInputPins']['sha256'],'specific actual285 review')
 for role in ['functionalReport','functionalTerminal','functionalComparisons','functionalAttempts','buildReport','buildTerminal','identityBefore','identityAfter','matrix']:
  z=bindings[role];need(ip[z['path']]=={'bytes':z['bytes'],'sha256':z['sha256']},'audited raw pin '+role)
 need(x['functionalTerminal']=={'allCallsClosed':True,'calls':285,'failure':False} and x['functionalReport']['status']=='PASS_FINITE_MASKED32_ORIGINAL19_285_FUNCTIONAL_ONLY','accepted285 terminal')
 need(x['functionalReport']['comparisons']==x['functionalComparisons'] and len(x['functionalComparisons'])==95 and len(x['functionalAttempts'])==285,'exact285/95')
 need(x['buildTerminal']=={'allBuildsClosed':True,'allQueriesClosed':True,'builds':19,'identityQueries':14,'failure':False} and x['buildReport']['status']=='PASS_FRESH19_RUNNER_BUILD_IDENTITY_ONLY' and x['buildReport']['clangInvocations']==23,'accepted currentbuild33')
 need(x['identityBefore']==x['identityAfter'],'identity unchanged')
 desc=x['matrix'];need(len(desc['entries'])==19 and len(x['buildReport']['images'])==19,'fixed19')
 expected={(t['workload'],t['n'],a['arm']):core.semantic(a['receipt']) for t in x['functionalComparisons'] for a in t['arms']};need(len(expected)==285,'all285 unique')
 mapped={}
 for e,r in zip(desc['entries'],x['buildReport']['images']):
  need(e['workload']==r['workload'] and r['headerSHA256']==e['header']['sha256'] and r['telemetrySourceSHA256']==desc['telemetrySource']['sha256'],'runner source/header identity')
  need(e['inputs']==([0,1,2,17,2000] if e['workload']=='depthconv' else [0,1,2,17,32]),'original fullprofiles')
  for arm in core.ARMS:
   rows=[z for z in x['functionalAttempts'] if z['label']==e['workload']+'-'+arm+'-n'+str(max(e['inputs']))];need(len(rows)==1,'actual argv unique');z=rows[0]
   need(z['state']=='terminal' and z['returncode']==0 and z['failure'] is None and z['cleanupException'] is None,'actual closure')
   a=e[arm];need(z['logicalArgv']==[r['runner']['path'],'dylib' if arm=='C' else 'raw',a['path'],e['CSymbol'] if arm=='C' else str(a['offset']),'aarch64',str(max(e['inputs'])),'1','0','16777216'],'exact original logical argv')
   need(z['argv'][0]==r['runner']['path'] and z['argv'][2]=='/Users/zebulun/github/workspaces/codex/vector-masked32-original19-remote-v1-root/inputs/'+a['sha256'],'fixed actual path')
   mapped[(e['workload'],arm)]=z['argv'][2]
 return x,desc,expected,mapped
''' +s[b:]
s=s.replace("g['sourcePinsSHA256']==source_guard()", "g['sourcePinsSHA256']==source_guard(g['sourcePinsSHA256'])")
s=s.replace("load(D/'proof-bindings.json')['functionalIndependentReview']", "load(D/'proof-bindings.json')['functionalReview']")
s=s.replace("c=common();x,d,expected=evidence(c);", "x,d,expected,mapped=evidence();")
s=s.replace("env=c.environment();ledger=Ledger();", "env={'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','LANG':'C','LC_ALL':'C','TZ':'UTC','HOME':'/Users/zebulun','TMPDIR':str(N/'runner-output/tmp'),'DEVELOPER_DIR':'/Library/Developer/CommandLineTools'};ledger=Ledger();")
s=s.replace("source_guard()==g['sourcePinsSHA256']", "source_guard(g['sourcePinsSHA256'])==g['sourcePinsSHA256']").replace('evidence(c)','evidence()')
s=s.replace("for r in runners:c.checked_pin(r['runner'])", "for r in runners:pin(r['runner']['path'],r['runner'])")
s=s.replace("str(c.resolve_file(a['path']))", "mapped[(row['workload'],arm)]")
s=s.replace("scope':'external startup/process/parse envelope diagnostic ONLY; never quiet admission'", "scope':'external startup/warmup/process envelope; enclosing quiet admission estimate, not timed-loop CPU'")
s=s.replace("q,diagnostic=core.quiet(o,before,after)", "q,diagnostic=core.quiet(o,before,after,extb,exta,usagea.ru_utime+usagea.ru_stime-usageb.ru_utime-usageb.ru_stime)")
s=s.replace("COMPLETE_CUSTOM_MATCHED_C_FULL19_TIMED_WINDOW_COHORT", "COMPLETE_CUSTOM_MATCHED_C_FULL19_EXTERNAL_ENVELOPE_COHORT")
s=s.replace("'>=50ms actual timer, timed CPU endpoint bracket overhead; external envelope not used'", "'>=50ms actual timer; external process envelope idle estimate includes startup/warmup'")
s=s.replace("'coldWarmCPUInstrumentedRequalificationOnly':True", "'timedLoopCpuQualified':False")
s=s.replace("18 unchanged workloads are neutral compiler evidence; only Aha has one changed triple", "17 whole-code equal native arms are neutral; only AES/SHA clone preparation changed code")
# Mandatory independent root/second source review gate, manifest cannot self-authorize.
pos=s.index(" c=common()") if " c=common()" in s else s.index(" x,d,expected,mapped=evidence();")
s=s[:pos]+''' need(type(g['sourceReviews']) is list and len(g['sourceReviews'])==2,'two distinct source reviews')
 need(len({q['sha256'] for q in g['sourceReviews']})==2,'distinct review files')
 for q in g['sourceReviews']:
  pin(q['path'],q);review=load(q['path']);need(review['status']=='PASS_SOURCE_ONLY_MASKED32_CURRENT19_EXTERNAL_TIMING_CAMPAIGN' and review['sourcePinsSHA256']==g['sourcePinsSHA256'],'exact independent source acceptance')
''' +s[pos:]
(D/'campaign.py').write_text(s)
core=(P/'core.py').read_text().replace('from validate_window import structural\n','').replace('from decode_window import decode\n','').replace('EXTR-current19-','MASKED32-current19-')
a=core.index('def quiet(');b=core.index('def summarize(',a)
core=core[:a]+'''def quiet(o,before_load,after_load,extb,exta,child_seconds):
 import external_cpu
 if o['elapsedNanoseconds']<50000000:return False,{'reason':'below50ms'}
 try:
  activity=external_cpu.interval(extb,exta)
 except ValueError as ex:
  if str(ex)=='CPU counters did not advance':return False,{'reason':'zeroCPUticks'}
  raise
 if extb['processors']!=exta['processors']:raise ValueError('processor count changed')
 q=external_cpu.background_activity(activity,round(child_seconds*1000000000),extb['processors'])
 ok=before_load<=4 and after_load<=4 and q['estimatedBackgroundIdlePercent']>=90
 return ok,{'reason':'accepted' if ok else 'notQuiet','external':q,'beforeLoad':before_load,'afterLoad':after_load}
''' +core[b:]
(D/'core.py').write_text(core)
