import json,hashlib
H=lambda b:hashlib.sha256(b).hexdigest()
WORKLOADS={'edn', 'nettle-aes', 'wikisort', 'xgboost', 'qrduino', 'ud', 'nsichneu', 'aha-mont64', 'statemate', 'depthconv', 'slre', 'sglib-combined', 'md5sum', 'huffbench', 'crc32', 'picojpeg', 'tarfind', 'matmult-int', 'nettle-sha256'}
def validate(content):
 globalNames={'attempts.json','cohort.json','effective-environment.json','root-go.json','report.json','terminal.json','failure.json'}
 for name in content:
  parts=name.split('/')
  if name in globalNames:continue
  assert len(parts)==2
  if parts[0]=='workloads':assert parts[1].endswith('.json') and parts[1][:-5] in WORKLOADS;continue
  assert parts[0] in {'runner','load'}
  i,suffix=parts[1].split('.',1);assert i.isdigit() and str(int(i))==i and 1<=int(i)<=({'runner':5415,'load':10830}[parts[0]]) and suffix in ({'stdout','stderr','external.json'} if parts[0]=='runner' else {'stdout','stderr'})
 t=json.loads(content['terminal.json']);rows=json.loads(content['attempts.json']);assert set(t)=={'allChildrenClosed','runnerCalls','loadQueries','failure','partial'}
 assert t['allChildrenClosed'] is True and type(t['failure']) is bool and type(t['partial']) is bool
 assert type(t['runnerCalls']) is int and 0<=t['runnerCalls']<=5415 and type(t['loadQueries']) is int and 0<=t['loadQueries']<=10830
 assert len(rows)==t['runnerCalls']+t['loadQueries'];counts={'runner':0,'load':0}
 for r in rows:
  k=r['kind'];assert k in counts and r['state']=='terminal';counts[k]+=1;assert r['index']==counts[k]
  assert type(r['returncode']) is int or (r['returncode'] is None and r['exception'] is not None)
  for suffix,key in [('stdout','stdoutSHA256'),('stderr','stderrSHA256')]:assert H(content[k+'/'+str(r['index'])+'.'+suffix])==r[key]
 expected={k+'/'+str(i)+'.'+suffix for k,cap in counts.items() for i in range(1,cap+1) for suffix in ['stdout','stderr']}
 actual={n for n in content if n.startswith(('runner/','load/')) and not n.endswith('.external.json')}
 assert actual==expected
 assert all(int(n.split('/')[1].split('.')[0])<=counts['runner'] for n in content if n.endswith('.external.json'))
 assert counts=={'runner':t['runnerCalls'],'load':t['loadQueries']}
 assert ('failure.json' in content)==t['failure'];return t

