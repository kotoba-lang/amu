"""Pinned root-only finite installer/launcher/sealer. No actions on import."""
from pathlib import Path
import json,hashlib,base64,sys,os,signal,subprocess,io,tarfile,gzip
N=Path('/Users/zebulun/github/workspaces/codex/vector-masked32-original19-remote-v3-root');C=N/'timing-source-v2-controls';T=N/'timing-transport-v1-controls';O=N/'timing-campaign-v2-controls';S=N/'timing-sealed-v1-controls'
SP='ba1938b6a79086956291109081c82f83b015996038578028d05cf7f8079cc6fd';H=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def safe(name):
 p=Path(name);assert name and not p.is_absolute()and '..'not in p.parts and str(p)==name and len(p.parts)<=4;return p
def pin(p,e):
 p=Path(p);assert p.is_file()and not any(q.is_symlink()for q in [p,*p.parents]);assert p.stat().st_size==e['bytes']and H(p.read_bytes())==e['sha256']
def codeguard(expected=None):
 if expected is not None:assert H((T/'installed-manifest.json').read_bytes())==expected
 inv=load(T/'installed-manifest.json')
 for n,e in inv.items():pin(N/safe(n),e)
 assert H((C/'source-pins.json').read_bytes())==SP
 sys.path.insert(0,str(C));import campaign;campaign.source_guard(SP)
 return campaign
def reviews():
 for r in ['root','width']:
  x=load(T/'reviews'/(r+'.json'));assert x['status']=='PASS_SOURCE_ONLY_MASKED32_CURRENT19_EXTERNAL_TIMING_CAMPAIGN'and x['sourcePinsSHA256']==SP

def install(q):
 assert Path.home()==Path('/Users/zebulun')and N.is_dir()and not any(p.is_symlink()for p in [N,*N.parents]);assert not C.exists()and not T.exists()and not O.exists()and not S.exists()
 assert set(q)=={'files','installGO','campaignSourcePinsSHA256'}and q['campaignSourcePinsSHA256']==SP and q['installGO']['stage']=='install'and q['installGO']['installAuthorized']is True
 files={};total=0
 assert type(q['files'])is dict and len(q['files'])<=64
 for n,e in q['files'].items():
  p=safe(n);assert p.parts[0]in [C.name,T.name];assert set(e)=={'base64','bytes','sha256'}and type(e['bytes'])is int and 0<=e['bytes']<=2097152;total+=e['bytes'];assert total<=2097152
  z=base64.b64decode(e['base64'],validate=True);assert len(z)==e['bytes']and H(z)==e['sha256'];files[n]=z
 pins=json.loads(files[C.name+'/source-pins.json']);assert H(files[C.name+'/source-pins.json'])==SP and len(pins)==26
 assert set(n for n in files if n.startswith(C.name+'/'))=={C.name+'/'+n for n in pins}|{C.name+'/source-pins.json'}
 for n,e in pins.items():assert len(files[C.name+'/'+n])==e['bytes']and H(files[C.name+'/'+n])==e['sha256']
 for r in ['root','width']:
  x=json.loads(files[T.name+'/reviews/'+r+'.json']);assert x['status']=='PASS_SOURCE_ONLY_MASKED32_CURRENT19_EXTERNAL_TIMING_CAMPAIGN'and x['sourcePinsSHA256']==SP
 inv=json.loads(files[C.name+'/remote-input-pins.json'])
 for e in inv:pin(e['path'],e)
 C.mkdir();T.mkdir()
 for n,z in files.items():p=N/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z);p.chmod(0o444)
 save(T/'installed-manifest.json',{n:{'bytes':len(z),'sha256':H(z)}for n,z in files.items()});save(T/'install-go.json',q['installGO']);mh=H((T/'installed-manifest.json').read_bytes());codeguard(mh);reviews()
 for e in inv:pin(e['path'],e)
 r={'status':'INSTALLED_MASKED32_TIMING_SOURCE_ONLY','members':len(files),'bytes':total,'campaignSourcePinsSHA256':SP,'installedManifestSHA256':mh,'nativeCalls':0};save(T/'install-receipt.json',r);print(json.dumps(r))
def launch(q):
 assert set(q)=={'campaignGO','campaignGOSHA256','installedManifestSHA256'};assert H((T/'installed-manifest.json').read_bytes())==q['installedManifestSHA256'];codeguard(q['installedManifestSHA256']);reviews()
 b=(json.dumps(q['campaignGO'],indent=2)+'\n').encode();assert H(b)==q['campaignGOSHA256'];g=q['campaignGO'];assert g['stage']=='timing'and g['sourcePinsSHA256']==SP and g['outputRoot']==str(O)and g['timingAuthorized']is True and g['noRerun']is True
 assert g['maximumRunnerProcesses']==5415 and g['maximumLoadQueries']==10830 and g['maximumTotalChildren']==16245
 assert g['sourceReviews']==[{'path':str(T/'reviews'/(r+'.json')),'bytes':(T/'reviews'/(r+'.json')).stat().st_size,'sha256':H((T/'reviews'/(r+'.json')).read_bytes())}for r in ['root','width']]
 p=T/'campaign-go.json';assert not p.exists()and not O.exists()and not(T/'launch-terminal.json').exists();p.write_bytes(b);p.chmod(0o444)
 child=None;rc=None;error=None
 try:
  child=subprocess.Popen(['/usr/bin/python3',str(C/'campaign.py'),str(p)],cwd=C,env={'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','LANG':'C','LC_ALL':'C','TZ':'UTC','HOME':'/Users/zebulun','PYTHONDONTWRITEBYTECODE':'1'},start_new_session=True)
  rc=child.wait(timeout=172780)
 except BaseException as ex:
  error=repr(ex)
  if child is not None:
   try:
    try:os.killpg(child.pid,signal.SIGINT)
    except ProcessLookupError:pass
    try:rc=child.wait(timeout=60)
    except subprocess.TimeoutExpired:
     try:os.killpg(child.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     rc=child.wait(timeout=10)
   except BaseException as cleanup:error+=';cleanup='+repr(cleanup)
 finally:save(T/'launch-terminal.json',{'closed':child is None or child.returncode is not None,'returncode':rc,'exception':error,'childPID':None if child is None else child.pid,'maximumCampaignChildren':16245,'campaignGOSHA256':H(b)})
 codeguard(q['installedManifestSHA256']);assert error is None and rc==0,'remote child failure retained; no retry';print(json.dumps({'status':'CLOSED_MASKED32_TIMING_CAMPAIGN_PROCESS_ONLY','campaignGOSHA256':H(b),'noTimingQualificationFromSSH0':True}))
def seal(q):
 assert set(q)=={'campaignGOSHA256','installedManifestSHA256'}and H((T/'campaign-go.json').read_bytes())==q['campaignGOSHA256']and H((T/'installed-manifest.json').read_bytes())==q['installedManifestSHA256'];codeguard(q['installedManifestSHA256']);reviews();assert not S.exists()
 assert load(T/'launch-terminal.json')['closed']is True
 if(O/'root-go.json').exists():assert(O/'root-go.json').read_bytes()==(T/'campaign-go.json').read_bytes()
 from result_contract import validate,WORKLOADS
 content={};total=0
 for p in sorted(O.rglob('*')) if O.is_dir() else []:
  assert not p.is_symlink()
  if p.is_dir():assert str(p.relative_to(O))in ['runner','load','workloads'];continue
  assert p.is_file()and p.stat().st_size<=67108864;z=p.read_bytes();total+=len(z);assert total<=536870912;content[str(p.relative_to(O))]=z;assert len(content)<49100
 required={'attempts.json','cohort.json','effective-environment.json','root-go.json','report.json','terminal.json'}
 if required<=set(content):terminal=validate(content);capture='CLOSED_CAMPAIGN_TERMINAL'
 else:
  lt=load(T/'launch-terminal.json');assert lt['closed']is True and(lt['returncode']!=0 or lt['exception']is not None)
  terminal=None;capture='INCOMPLETE_NAMESPACE_FAILURE_ONLY'
  # Validate every existing output path without manufacturing absent campaign receipts.
  for name in content:
   parts=name.split('/')
   if name in required|{'failure.json'}:continue
   assert len(parts)==2
   if parts[0]=='workloads':assert parts[1].endswith('.json')and parts[1][:-5]in WORKLOADS;continue
   assert parts[0]in['runner','load'];idx,suffix=parts[1].split('.',1);assert idx.isdigit()and str(int(idx))==idx and 1<=int(idx)<=(5415 if parts[0]=='runner' else 10830)and suffix in(['stdout','stderr','external.json']if parts[0]=='runner'else['stdout','stderr'])
 files={'results/'+n:z for n,z in content.items()}
 for n,e in load(T/'installed-manifest.json').items():pin(N/n,e);files['installed/'+n]=(N/n).read_bytes()
 for n in ['installed-manifest.json','install-go.json','install-receipt.json','campaign-go.json','launch-terminal.json']:files['transport/'+n]=(T/n).read_bytes()
 assert len(files)+1<=49152 and all(len(z)<=67108864 for z in files.values())and sum(map(len,files.values()))<=536870912
 inv=(json.dumps({'members':[{'name':n,'bytes':len(z),'sha256':H(z)}for n,z in files.items()]},indent=2)+'\n').encode();assert len(inv)<=8388608
 S.mkdir()
 with(S/'result.tgz').open('xb')as out:
  with gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0)as gz:
   with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT)as tar:
    for n,z in [('inventory.json',inv),*files.items()]:ti=tarfile.TarInfo(n);ti.size=len(z);ti.mode=0o444;ti.mtime=0;tar.addfile(ti,io.BytesIO(z))
 for n,z in content.items():assert(O/n).read_bytes()==z
 codeguard(q['installedManifestSHA256']);a=S/'result.tgz';assert a.stat().st_size<=536870912;a.chmod(0o444)
 print(json.dumps({'status':'SEALED_MASKED32_TIMING_RESULTS_ONLY','archiveSHA256':H(a.read_bytes()),'archiveBytes':a.stat().st_size,'inventorySHA256':H(inv),'members':len(files),'expandedBytes':sum(map(len,files.values())),'terminal':terminal,'captureKind':capture,'campaignGOSHA256':q['campaignGOSHA256'],'nativeCalls':0}))
def main():
 assert len(sys.argv)==2 and sys.argv[1]in['install','launch','seal'];b=sys.stdin.buffer.read(4194305);assert len(b)<=4194304;q=json.loads(b);globals()[sys.argv[1]](q)
if __name__=='__main__':main()
