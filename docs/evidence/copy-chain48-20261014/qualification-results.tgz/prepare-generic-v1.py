from pathlib import Path
import json,hashlib
W=Path(__file__).parent;D=W/'generic-controls-v1';D.mkdir(exist_ok=False);(D/'raw').mkdir()
s='''(defn- put [s :vector-i64 i :i64 x :i64] :vector-i64 (vector-assoc! s i x))
(defn- n8 [x :i64] :i64 (let [v (bit-and x 255)] (if (>= v 128) (- v 256) v)))
(defn- n16 [x :i64] :i64 (let [v (bit-and x 65535)] (if (>= v 32768) (- v 65536) v)))
(defn- n32 [x :i64] :i64 (let [v (bit-and x 4294967295)] (if (>= v 2147483648) (- v 4294967296) v)))
(defn- init [s :vector-i64 i :i64 pattern :i64] :vector-i64
 (if (= i 8) s (let [value (case pattern 0 0 1 9223372036854775807 2 -9223372036854775808 3 (- (* i 129) 256) 4 (+ 4294967296 (* i 7919)) 5 (- (* i 32769) 65536) (- (* i 1048577) 2147483648))]
 (init (put s i value) (+ i 1) pattern))))
'''
variants=[]
for family in range(6):
 for count in [3,4,16,32,33,47,48,49,96]:
  ident=len(variants);stages=[];s+=f'(defn- q{ident}e [s :vector-i64] :vector-i64 s)\n';nextfn=f'q{ident}e'
  for i in range(count):
   width=([8,16,32,0][i%4] if family<4 else [32,8,16,0][i%4] if family==4 else 0)
   read=i%4 if family==1 else (i+1)%4 if family==2 else 0
   write=(i+1)%4 if family==1 else i%4 if family==2 else 0
   constant=-(1<<63)+i*65537 if family==3 and i%3==0 else (1<<63)-1 if family==5 and i%3==0 else None
   value=str(constant)if constant is not None else f'(vector-at s {read})'
   if width:value=f'(n{width} {value})'
   fn=f'q{ident}s{i}';s+=f'(defn- {fn} [s :vector-i64] :vector-i64 (let [value {value} index {write}] ({nextfn} (put s index value))))\n';nextfn=fn;stages.insert(0,dict(read=read,write=write,width=width,constant=constant))
  variants.append(dict(id=ident,family=family,count=count,head=nextfn,stages=stages))
cases=' '.join(str(v['id'])+' ('+v['head']+' initial)'for v in variants[:-1]);last=variants[-1]
s+='''(defn probe [id :i64] :i64
 (let [kind (quot id 10000) rest (rem id 10000) pattern (quot rest 1000)
       cell (quot (rem rest 1000) 10) sizekind (rem id 10)
       size (case sizekind 0 8 1 3 2 1 0) allocated (vector-alloc size)
       initial (if (= size 8) (init allocated 0 pattern) allocated)
       result (case kind '''+cases+' ('+last['head']+''' initial))]
  (vector-at result cell)))
'''
S=D/'renamed-copy-chain.kotoba';S.write_text(s)
def pin(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
P=dict(status='PREPARED_NAME_INDEPENDENT_COPY_CHAINS',source=pin(S),loader=pin(W.parent/'embench-pf-twoarg-20261013/protected-host/kexe-loader'),producers={'OFF':pin(W.parent/'seed-copy-chain-forward-20261014/selfbuild-v1/host/G4.bin'),'ON':pin(W/'selfbuild-v1/host/G4.bin')},variants=variants,all8OutputCells=True,patterns=7,adopted=False,performanceMeasured=False)
(D/'preparation.json').write_text(json.dumps(P,indent=2)+'\n');print('PREPARED_GENERIC_COPY_CHAINS',len(variants))
