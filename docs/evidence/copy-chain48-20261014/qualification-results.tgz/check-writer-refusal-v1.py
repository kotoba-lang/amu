from pathlib import Path
import json,os,subprocess,hashlib
W=Path(__file__).parent;D=W/'writer-refusal-v1';D.mkdir(exist_ok=False);(D/'raw').mkdir()
s=(W/'generic-controls-v1/renamed-copy-chain.kotoba').read_text();assert s.count('(vector-assoc! s i x)')==1;s=s.replace('(vector-assoc! s i x)','(vector-assoc s i x)');S=D/'immutable-writer.kotoba';S.write_text(s)
P=json.loads((W/'generic-controls-v1/preparation.json').read_text());L=Path(P['loader']['path']);calls=[];arms={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
E={k:v for k,v in os.environ.items()if not k.startswith('KEXE_')};E.update(KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(D),KEXE_FUEL='off',KEXE_VECTORS='4194304',KEXE_VECTOR_ITEMS='134217728',KEXE_STRING_POOL='268435456',KEXE_PAIRS='16777216',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',TMPDIR=str(D))
for tag,r in P['producers'].items():
 producer=Path(r['path']);assert sha(producer)==r['sha256'];k=D/(tag+'.kseed');b=D/(tag+'.bin')
 for cmd,args in [('compile',['compile',S,'--target','aarch64-macos','--output',k]),('extract',['extract-native',k,'--symbol','probe','--output',b])]:
  z=subprocess.run(list(map(str,[L,producer,'0','0','aarch64','35,37,38,39','--',*args])),cwd=D,env=E,capture_output=True,timeout=1800);(D/'raw'/(tag+'-'+cmd+'.stdout')).write_bytes(z.stdout);(D/'raw'/(tag+'-'+cmd+'.stderr')).write_bytes(z.stderr);calls.append(dict(tag=tag,cmd=cmd,exit=z.returncode));(D/'calls.json').write_text(json.dumps(calls,indent=2)+'\n');assert z.returncode==0 and not z.stderr;assert sha(producer)==r['sha256']
 arms[tag]=(b.read_bytes(),k.read_bytes())
assert arms['OFF']==arms['ON'],'Writer effect mismatch must refuse all CW changes'
(D/'report.json').write_text(json.dumps(dict(status='PASS_IMMUTABLE_WRITER_REFUSAL_WHOLE_NATIVE_CONTAINER_IDENTITY',compilerCalls=4,guestCalls=0,nativeSHA256=sha(b),containerSHA256=sha(k),adopted=False,performanceMeasured=False),indent=2)+'\n');print('PASS_IMMUTABLE_WRITER_REFUSAL_WHOLE_IDENTITIES')
