from pathlib import Path
import json,hashlib,subprocess,os,re
W=Path(__file__).parent;D=W/'generic-controls-v1';P=json.loads((D/'preparation.json').read_text());arms=json.loads((D/'arms.json').read_text());physical=json.loads((D/'physical-review.json').read_text());assert physical['changed']
def pin(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
inputs=[P['source'],P['loader'],*P['producers'].values()]+[r[k]for r in arms.values()for k in ['source','native','container']]
for r in inputs:assert pin(r['path'])==r
def wrap(x):return ((x+(1<<63))%(1<<64))-(1<<63)
def values(pattern):
 return [0 if pattern==0 else(1<<63)-1 if pattern==1 else-(1<<63)if pattern==2 else i*129-256 if pattern==3 else (1<<32)+i*7919 if pattern==4 else i*32769-65536 if pattern==5 else i*1048577-(1<<31)for i in range(8)]
def model(variant,pattern):
 v=values(pattern)
 for s in variant['stages']:
  x=v[s['read']]if s['constant']is None else s['constant'];width=s['width']
  if width:x=((x+(1<<(width-1)))%(1<<width))-(1<<(width-1))
  v[s['write']]=wrap(x)
 return v
tests=[]
for variant in P['variants']:
 for pattern in range(7):
  expected=model(variant,pattern)
  for cell in range(8):tests.append(dict(id=variant['id']*10000+pattern*1000+cell*10,fuel='off',kind='oracle',expected=expected[cell]))
 for fuel in [1,2,3,8,16,32,64,128,256]:tests.append(dict(id=variant['id']*10000+6000,fuel=str(fuel),kind='finiteFuel'))
 for sizekind in [1,2,3]:tests.append(dict(id=variant['id']*10000+6000+sizekind,fuel='off',kind='shortVector'))
assert not(D/'started.json').exists();(D/'started.json').write_text(json.dumps(dict(ownerPID=os.getpid()))+'\n')
E={k:v for k,v in os.environ.items()if not k.startswith('KEXE_')};E.update(KEXE_ARENA_USE='1',KEXE_STRUCTURED_REPORT='1',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',TMPDIR=str(D));rows=[]
for number,test in enumerate(tests):
 actual={}
 for tag,r in arms.items():
  z=subprocess.run(list(map(str,[P['loader']['path'],r['native']['path'],r['exports']['probe'][0],'1','aarch64','37',test['id']])),cwd=D,env=dict(E,KEXE_FUEL=test['fuel']),capture_output=True,timeout=60)
  (D/'raw'/(str(number)+'-'+tag+'.stdout')).write_bytes(z.stdout);(D/'raw'/(str(number)+'-'+tag+'.stderr')).write_bytes(z.stderr);actual[tag]=dict(exit=z.returncode,stdout=z.stdout.decode(),stderr=z.stderr.decode())
 assert actual['OFF']==actual['ON'],(number,test,actual)
 if test['kind']=='oracle':
  m=re.search(r':status :ok :result (-?\d+)',actual['ON']['stdout']);assert actual['ON']['exit']==0 and m and int(m[1])==test['expected'],(number,test,actual)
 rows.append(dict(number=number,test=test,actual=actual['ON']));(D/'progress.json').write_text(json.dumps(dict(completedPairs=len(rows),totalPairs=len(tests)))+'\n')
for r in inputs:assert pin(r['path'])==r
(D/'observations.json').write_text(json.dumps(rows,indent=2)+'\n')
r=dict(status='PASS_GENERIC_COPY_CHAINS_ALL8_OUTPUTS_INDEPENDENT_MODEL_AND_ALLRAW_FUEL_SHORTVECTORS',pairs=len(rows),guests=2*len(rows),oracleCases=sum(x['kind']=='oracle'for x in tests),variants=len(P['variants']),lengths=[3,4,16,32,33,47,48,49,96],signedWidths=[8,16,32,0],constantsAndDifferentIndices=True,full64Extremes=True,patterns=7,all17ArenaFieldsExactRaw=True,compilerCalls=0,adopted=False,performanceMeasured=False)
(D/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
