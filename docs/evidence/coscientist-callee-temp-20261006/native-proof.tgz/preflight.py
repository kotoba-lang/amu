from pathlib import Path
import json,hashlib,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-callee-temp-20261006');b=Path('/private/tmp/amu-loop-high-temp-20261006');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();g=load(w/'generations.json');assert len(g)==4 and len({x['sha256'] for x in g[1:]})==1;assert all(sha(w/f"seed-{x['generation']}.bin")==x['sha256'] for x in g)
counts={};pins={}
for name,key,n in [('permanent-regression-proof.json','runs',7989),('ports-state.json','comparisons',209),('callee-proof.json','comparisons',750),('import-proof.json','comparisons',96),('resource-proof.json','comparisons',40)]:
 v=load(w/name);assert v[key]==n;rows=v.get('observations',v.get('runs'));assert len(rows)==n;counts[name]=n;pins[name]=sha(w/name)
 for row in rows:
  if name=='ports-state.json':assert row['baseline']==row['candidate']
  if name=='callee-proof.json':assert row['baseline-callee']==row['candidate-callee']
  if name=='import-proof.json':assert row['baseline-open']==row['candidate-open']
  if name=='resource-proof.json':assert row['baseline-hand']==row['candidate-hand']
ob=load(w/'register-observation.json');assert len(ob['entries'])==19 and all(x['diagnosticTargetByteIdentical'] for x in ob['entries']);pins['register-observation.json']=sha(w/'register-observation.json');pins['callee-instruction-audit.json']=sha(w/'callee-instruction-audit.json')
pa=load(w/'ports-correctness.json');pb=load(b/'ports-correctness.json');assert len(pa['entries'])==19;ch=load(w/'code-change.json');changed=[x['workload'] for x in ch if x['changed']];assert len(changed)==6
for x,y in zip(pa['entries'],pb['entries']):
 assert x['workload']==y['workload'] and x['runs']==y['runs'] and x['fuelTrapReturncode']==y['fuelTrapReturncode'] and x['sourceSha256']==y['sourceSha256'];assert sha(w/'ports-2'/x['workload']/'native.bin')==x['nativeSha256']
assert (r/'seed/41-a64gen.kotoba').read_bytes()==(w/'baseline-41-a64gen.kotoba').read_bytes()
pre={'status':'complete-native-semantic-proof-before-timing','fixedpointGenerations':[2,3,4],'firstGenerationDiffers':True,'originalWorkloads':19,'changedGuests':changed,'freshNativeCounts':counts,'proofPins':pins,'fullSupervisorComparisons':1095,'productUnchanged':True,'mayPromote':False,'productGatesAndIntegratedProofStillRequired':True,'officialEmbenchScore':False};(w/'preflight-audit.json').write_text(json.dumps(pre,indent=2)+'\n');p=w/'timing-package';p.mkdir();hyp=load(w/'hypothesis.json')
for name in changed:
 d=p/name;c=d/'candidate';c.mkdir(parents=True);x=next(z for z in pa['entries'] if z['workload']==name);y=next(z for z in pb['entries'] if z['workload']==name);shutil.copyfile(w/'ports-2'/name/'native.bin',c/'native.bin');shutil.copyfile(b/'ports-2'/name/'native.bin',d/'baseline-native.bin');mf={'workload':name,'sourceSha256':x['sourceSha256'],'baselineSourceSha256':y['sourceSha256'],'nativeSha256':x['nativeSha256'],'offset':x['offset'],'baselineNativeSha256':y['nativeSha256'],'baselineOffset':y['offset'],'compilerGenerationSha256':{str(x['generation']):x['sha256'] for x in g[1:]},'hypothesis':hyp['hypothesis'],'sourceHead':hyp['sourceCommit']};(c/'manifest.json').write_text(json.dumps(mf,indent=2)+'\n')
for src,name in [(b/'ports-correctness.json','product-proof.json'),(w/'ports-correctness.json','candidate-proof.json'),(w/'preflight-audit.json','preflight.json'),(w/'generations.json','generations.json'),(w/'code-change.json','code-change.json')]:shutil.copyfile(src,p/name)
for name in pins:shutil.copyfile(w/name,p/name)
for name in ['comparison-matrix.json','paired-timing-spec.json']:shutil.copyfile(r/'bench/embench'/name,p/name)
shutil.copyfile('/private/tmp/amu-context-call-20261005/measure-native-candidate-v2.py',p/'measure-native-candidate-v2.py')
s=Path('/private/tmp/amu-high-temp-no-spill-20261006/remote-timing.py').read_text().replace('amu-zebulun-high-temp-no-spill-20261006','amu-zebulun-callee-temp-20261006').replace("pre['fullSupervisorComparisons']==17337 and len(pre['changedGuests'])==2", "pre['fullSupervisorComparisons']==1095 and len(pre['changedGuests'])==6").replace('Current qualified affine-reader product','Current qualified loop-contained high-temp product').replace('terminal both prospective timing experiments','terminal all six prospective timing experiments');(w/'remote-timing.py').write_text(s)
print('PASS1095 fresh fullstate and7989 existingregressions sealed before six prospective timing comparisons')
