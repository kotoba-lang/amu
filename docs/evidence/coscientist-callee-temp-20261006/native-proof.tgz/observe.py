from pathlib import Path
import subprocess,os,re,json,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-callee-temp-20261006');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pc=json.loads((w/'ports-correctness.json').read_text());env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_STRING_POOL='268435456',KEXE_VECTORS='4194304',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for label,args in [('compile',['compile',str(w/'observer-unity.kotoba'),'--target','aarch64-macos','--output',str(w/'meta-seed.kseed')]),('extract',['extract-native',str(w/'meta-seed.kseed'),'--symbol','main','--output',str(w/'meta-seed.bin')])]:
 q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/('meta-'+label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout,q.stderr)
 if label=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
rows=[]
for e in json.loads((r/'bench/embench/comparison-matrix.json').read_text())['entries']:
 name=e['workload'];d=w/'meta-ports'/name;d.mkdir(parents=True);src=r/e['source'];assert sha(src)==e['expectedSourceSha256'];regs=[]
 for label,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(d/'image.kseed')]),('extract',['extract-native',str(d/'image.kseed'),'--symbol',e['symbol'],'--output',str(d/'native.bin')])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'meta-seed.bin'),off,'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(d/(label+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(name,label,q.stdout,q.stderr)
  if label=='compile':regs=[list(map(int,x.split()[1:])) for x in q.stdout.splitlines() if x.startswith('REG ')]
  else:offset=int(re.search(r':offset (\d+)',q.stdout).group(1))
 for f,F,ns,dp,nsv,nt in regs:
  assert nt==min(max(0,dp-7),10-nsv)
  for i in range(nt):
   k=ns+1+7+i;o=F-8*(k+1);assert o>=8*nsv and o+8<=F,(name,f,F,ns,dp,nsv,nt,o)
 eb=next(x for x in pc['entries'] if x['workload']==name);assert sha(d/'native.bin')==eb['nativeSha256'] and offset==eb['offset'];row={'workload':name,'diagnosticTargetByteIdentical':True,'functions':[dict(zip(['fn','frameBytes','locals','depth','localCalleeRegisters','additionalTempRegisters'],x)) for x in regs],'mappedFunctions':sum(x[-1]>0 for x in regs)};rows.append(row);print('PASS actual native temp allocation/observer',name,row['mappedFunctions'],flush=True)
(w/'register-observation.json').write_text(json.dumps({'status':'complete-native-observer-byte-parity-and-register-storage-census','entries':rows},indent=2)+'\n')
