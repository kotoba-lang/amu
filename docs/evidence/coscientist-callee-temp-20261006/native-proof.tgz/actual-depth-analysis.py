from pathlib import Path
import json,re,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-callee-temp-20261006');old=Path('/private/tmp/amu-loop-region-census-20261006');C={}
for n in ['seed/SIR','seed/HEADS','seed/MEMORY-MAP']:
 for m in re.finditer(r'\[:c (\S+) (-?\d+)',(r/n).read_text()):C[m[1]]=int(m[2])
ops={v:k for k,v in C.items() if k.startswith('OP-')}
def need(op,a,b,c):
 if op in ['OP-CONST','OP-LGET','OP-STR','OP-RET','OP-BRZ','OP-BRNZ','OP-TAB','OP-FADDR','OP-VECP','OP-RES2']:return a+1
 if op=='OP-RET2':return a+2
 if op in ['OP-LSET','OP-UN']:return b+1
 if op in ['OP-BIN','OP-CMP']:return b+2
 if op=='OP-CAP':return c+1
 if op in ['OP-CALL','OP-RT']:return b+max(c,1)
 if op=='OP-CALLI':return b+c+1
 if op=='OP-VEC':return a+max(b,1)
 return 0
entries=[]
for e in json.loads((w/'register-observation.json').read_text())['entries']:
 name=e['workload'];log=old/'meta-ports'/name/'compile.log';text=log.read_text();sir={int(x[0]):list(map(int,x[1:])) for x in [y.split()[1:] for y in text.splitlines() if y.startswith('SIR ')]};fn={int(x[0]):list(map(int,x[1:])) for x in [y.split()[1:] for y in text.splitlines() if y.startswith('FN ')]};fs=[]
 for f in e['functions']:
  idx,ns,dp,nsv,leaf=fn[f['fn']];assert [ns,dp,nsv]==[f['locals'],f['depth'],f['localCalleeRegisters']];j=idx+1;n=0
  while j in sir and sir[j][0]!=C['OP-END']:
   op,a,b,c=sir[j];n=max(n,need(ops[op],a,b,c));j+=1
  assert j in sir and sir[j][0]==C['OP-END'];actualnt=min(max(0,n-7),10-nsv)
  if f['additionalTempRegisters']>0:fs.append({**f,'actualNamedTemps':n,'actualNeededCalleeRegisters':actualnt,'unusedSavedRegisters':f['additionalTempRegisters']-actualnt})
 entries.append({'workload':name,'functions':fs,'historicalNativeSIRLogSha256':hashlib.sha256(log.read_bytes()).hexdigest(),'allocationMetadataComparedWithFreshObserver':True});print(name,[(x['fn'],x['depth'],x['actualNamedTemps'],x['unusedSavedRegisters']) for x in fs])
(w/'actual-depth-analysis.json').write_text(json.dumps({'status':'complete-historical-native-SIR-depth-analysis-matched-to-fresh-allocation-metadata','notTimeShares':True,'frontendUnchangedCanonicalSourcePinned':True,'entries':entries},indent=2)+'\n')
