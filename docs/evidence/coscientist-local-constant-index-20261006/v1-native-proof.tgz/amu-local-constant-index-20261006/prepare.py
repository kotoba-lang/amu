from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');b=Path('/private/tmp/amu-static-vector-chain-20261006');w=Path('/private/tmp/amu-local-constant-index-20261006')
h=json.loads((r/'docs/evidence/coscientist-element-reuse-census-20261006/next-hypothesis.json').read_text());h.update(registration='before native candidate build and timing',sourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),authoringException='One-off new bounded compiler fact/lowering algorithm in excluded prototype; product sources unchanged.',proofRecipe=json.loads((r/'docs/evidence/coscientist-rewrite-proof-20261006/summary.json').read_text())['recipeSha256']);(w/'hypothesis.json').write_text(json.dumps(h,indent=2)+'\n')
g=(r/'seed/41-a64gen.kotoba').read_text();layout=(r/'seed/42-layout.kotoba').read_text();assert g==(b/'41-a64gen-prototype.kotoba').read_text()
def rep(a,z):
 global g
 assert g.count(a)==1,(a,g.count(a));g=g.replace(a,z,1)
rep('(def gn-g-open-n (inc gn-g-open))', '(def gn-ix-base (+ gn-a-lp MM-LABEL-CAP 2)) ; three appended local fact cells; do not overwrite sreg16\n(def gn-g-open-n (inc gn-g-open))')
anchor='(defn- gn-lpos ['
helper=''';; Encode only admitted index constants as value+1; zero is unknown.
;; Runtime LOCAL descriptors stay LOCAL; no local store is removed or folded.
(defn- gn-ix-clear [M :vector-i64] :vector-i64
 (-> M (gn-gs gn-ix-base 0) (gn-gs (inc gn-ix-base) 0) (gn-gs (+ gn-ix-base 2) 0)))
(defn- gn-ix-drop [M :vector-i64 s :i64] :vector-i64
 (if (and (>= s 1) (<= s 3)) (gn-gs M (+ gn-ix-base (dec s)) 0) M))
(defn- gn-ix-temp [M :vector-i64 t :i64] :i64
 (if (not= (gn-g M gn-f-vmode) 2) 0
  (let [v (gn-dv M t)]
   (cond (gn-isk M t gn-k-const) (if (and (>= v 0) (<= v 4095)) (inc v) 0)
         (and (gn-isk M t gn-k-local) (>= v 1) (<= v 3)) (gn-g M (+ gn-ix-base (dec v)))
         :else 0))))
(defn- gn-ix-set [M :vector-i64 s :i64 v :i64] :vector-i64
 (if (and (= (gn-g M gn-f-vmode) 2) (>= s 1) (<= s 3))
  (gn-gs M (+ gn-ix-base (dec s)) v) M))
;; Facts never cross a control/unknown/call boundary. Coalesced writes erase in
;; gn-fin; explicit assignments capture a proved old source before protection.
(defn- gn-ix-step [M :vector-i64 op :i64 a :i64] :vector-i64
 (if (not= (gn-g M gn-f-vmode) 2) (gn-ix-clear M)
  (if (or (= op OP-CONST) (= op OP-LGET) (= op OP-LSET) (= op OP-FUEL)
          (and (= op OP-BIN) (< a BOP-F64-ADD))
          (and (= op OP-CMP) (< a CC-F64-EQ))
          (and (= op OP-UN) (< a UOP-F64-NEG))
          (and (= op OP-RT) (or (= a RT-VECTOR-AT) (= a RT-VECTOR-ASSOC-IN-PLACE)))) M
   (gn-ix-clear M))))
'''
rep(anchor,helper+anchor)
rep('(gn-fin-quiet (gn-vdrop M s) t s d)', '(gn-fin-quiet (gn-ix-drop (gn-vdrop M s) s) t s d)')
rep('  (let [M1 (gn-prot M 0 (gn-g M gn-f-h) t s)\n        r (gn-sreg M1 s)]', '  (let [M0 (gn-ix-set M s (gn-ix-temp M t))\n        M1 (gn-prot M0 0 (gn-g M0 gn-f-h) t s)\n        r (gn-sreg M1 s)]')
start=g.index('(defn- gn-rt-at [');end=g.index(';; one-handle reads:',start)
g=g[:start]+'''(defn- gn-rt-at [M :vector-i64 i :i64 t :i64] :vector-i64
 (let [index (gn-ix-temp M (inc t))]
  (if (> index 0) (gn-rt-at-constant M i t (dec index)) (gn-rt-at-dynamic M i t))))
(defn- gn-rt-at-constant [M :vector-i64 i :i64 t :i64 index :i64] :vector-i64
 (let [slot (if (gn-isk M t gn-k-local) (gn-dv M t) 0)
       rv (gn-src M t 17 0) s (gn-co M i t) d (gn-dreg M t s)]
  (-> M (gn-protect t s) (gn-ctx) (gn-ldt t 17 0) (gn-chain-base rv slot)
        (gn-emit (enc-cmp-i 3 index)) (gn-emit (enc-bcond 8 2)) (gn-emit (gn-e-udf))
        (gn-emit (enc-ldr d 4 (* 8 index))) (gn-fin t s d))))
(defn- gn-rt-at-dynamic [M :vector-i64 i :i64 t :i64] :vector-i64
  (let [slot (if (gn-isk M t gn-k-local) (gn-dv M t) 0)
        M1 (gn-pin M (inc t)) ri (gn-pinned M1 (inc t))
        rv (gn-src M1 t 17 0) s (gn-co M1 i t) d (gn-dreg M1 t s)]
    (-> M1 (gn-protect t s) (gn-ctx) (gn-ldt t 17 0) (gn-chain-read rv ri d slot) (gn-fin t s d))))
(defn- gn-rt-set [M :vector-i64 t :i64] :vector-i64
 (let [index (gn-ix-temp M (inc t))]
  (if (> index 0) (gn-rt-set-constant M t (dec index)) (gn-rt-set-dynamic M t))))
(defn- gn-rt-set-constant [M :vector-i64 t :i64 index :i64] :vector-i64
 (let [slot (if (gn-isk M t gn-k-local) (gn-dv M t) 0)
       M1 (gn-pin M t)
       M2 (if (and (gn-isk M1 (+ t 2) gn-k-const) (= (gn-dv M1 (+ t 2)) 0)) M1 (gn-pin M1 (+ t 2)))
       rv (gn-pinned M2 t) rx (if (gn-isk M2 (+ t 2) gn-k-const) 31 (gn-pinned M2 (+ t 2)))]
  (-> M2 (gn-ctx) (gn-chain-base rv slot)
      (gn-emit (enc-cmp-i 3 index)) (gn-emit (enc-bcond 8 2)) (gn-emit (gn-e-udf))
      (gn-emit (enc-str rx 4 (* 8 index))) (gn-gs gn-f-h (inc t)))))
(defn- gn-rt-set-dynamic [M :vector-i64 t :i64] :vector-i64
  (let [slot (if (gn-isk M t gn-k-local) (gn-dv M t) 0)
        M1 (-> M (gn-pin t) (gn-pin (inc t)))
        M2 (if (and (gn-isk M1 (+ t 2) gn-k-const) (= (gn-dv M1 (+ t 2)) 0)) M1 (gn-pin M1 (+ t 2)))
        rv (gn-pinned M2 t) ri (gn-pinned M2 (inc t))
        rx (if (gn-isk M2 (+ t 2) gn-k-const) 31 (gn-pinned M2 (+ t 2)))]
    (-> M2 (gn-ctx) (gn-chain-store rv ri rx slot) (gn-gs gn-f-h (inc t)))))
''' +g[end:]
rep('(gn-ins-quiet (gn-chain-step M i op (gn-sir M i IF-A)) i op)', '(gn-ins-quiet (gn-ix-step (gn-chain-step M i op (gn-sir M i IF-A)) op (gn-sir M i IF-A)) i op)')
rep('(mem-alloc M0 (+ gn-a-lp MM-LABEL-CAP 2))','(mem-alloc M0 (+ gn-a-lp MM-LABEL-CAP 5))')
(w/'41-a64gen-prototype.kotoba').write_text(g);(w/'42-layout-prototype.kotoba').write_text(layout)
for n in ['41-a64gen','42-layout']:shutil.copy2(r/('seed/'+n+'.kotoba'),w/('baseline-'+n+'.kotoba'))
parts=[s.strip() for s in (r/'seed/MANIFEST').read_text().splitlines() if s.strip() and not s.lstrip().startswith('#')];(w/'seed-unity.kotoba').write_text(''.join(g if s=='seed/41-a64gen.kotoba' else layout if s=='seed/42-layout.kotoba' else (r/s).read_text() for s in parts))
for src,dst in [('seed-4.bin','seed-0.bin'),('seed-4.offset','seed-0.offset'),('kexe-loader','kexe-loader'),('full-state-loader','full-state-loader')]:shutil.copy2(b/src,w/dst)
for n in ['build.py','check-ports.py','ports-state.py','permanent-regression.py']:
 s=(b/n).read_text().replace(str(b),str(w))
 if n=='check-ports.py':s=s.replace('/private/tmp/amu-small-tail-frame-20261006/ports-correctness.json',str(b/'ports-correctness.json'))
 if n=='ports-state.py':s=s.replace("b=Path('/private/tmp/amu-small-tail-frame-20261006')", "b=Path('"+str(b)+"')")
 (w/n).write_text(s)
shutil.copy2(r/'scripts/seed/a64gen_vector_chain_fixtures.py',w/'a64gen_vector_chain_fixtures.py')
(w/'source-pins.json').write_text(json.dumps({n:hashlib.sha256((w/n).read_bytes()).hexdigest() for n in ['41-a64gen-prototype.kotoba','42-layout-prototype.kotoba','baseline-41-a64gen.kotoba','baseline-42-layout.kotoba','seed-unity.kotoba']},indent=2)+'\n')
print('PASS prospective local-constant candidate prepared; original assignments retained, product unchanged')
