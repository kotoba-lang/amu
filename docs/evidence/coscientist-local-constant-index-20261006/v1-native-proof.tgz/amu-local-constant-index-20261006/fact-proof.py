from pathlib import Path
import importlib.util,json,os,re,subprocess,struct,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-local-constant-index-20261006');raw=(r/'scripts/seed/a64gen-fixtures.py').read_text();raw=raw.replace("R = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))","R = '/Users/junkawasaki/github/wt/amu-seed17'",1);(w/'fact-fixtures.py').write_text(raw);sp=importlib.util.spec_from_file_location('fx',w/'fact-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);old=len(m.FIX)
const=lambda k:[('CONST',0,k),('LSET',2,0)]
access=[('LGET',0,1),('LGET',1,2),('RT','RT-VECTOR-AT',0,2),('LSET',3,0),('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3)]
unknown=[('LGET',0,1),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('LSET',2,0)]
variants={f'k{k}':const(k)+access for k in [0,1,4,5,4095,4096,-1,m.MIN,m.MAX]}
variants['copy']=const(1)+[('LGET',0,2),('LSET',3,0),('LGET',0,1),('LGET',1,3),('RT','RT-VECTOR-AT',0,2),('LSET',3,0),('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3)]
variants['unknown']=unknown+access
variants['coalesced']=const(1)+unknown+access
variants['held-old']=const(0)+[('LGET',1,2),('CONST',2,1),('LSET',2,2),('LGET',0,1),('RT','RT-VECTOR-AT',0,2),('LSET',3,0),('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3)]
variants['branch']=const(0)+[('LGET',0,1),('CONST',1,0),('RT','RT-VECTOR-AT',0,2),('BRZ',0,'lc_branch_join')]+const(1)+[('LABEL','lc_branch_join')]+access
variants['loop']=const(0)+[('LABEL','lc_loop_head'),('FUEL',),('LGET',0,1),('LGET',1,2),('RT','RT-VECTOR-AT',0,2),('CONST',1,1),('BIN','BOP-ADD',0),('LSET',3,0),('LGET',0,1),('LGET',1,2),('LGET',2,3),('RT','RT-VECTOR-ASSOC-IN-PLACE',0,3),('LGET',0,2),('CONST',1,1),('BIN','BOP-ADD',0),('LSET',2,0),('LGET',0,2),('CONST',1,3),('CMP','CC-LT',0),('BRNZ',0,'lc_loop_head')]
variants['ns4']=const(1)+[('CONST',2,9),('LSET',4,2)]+access
m.fx('lc_sink',1,1,[('LGET',0,1),('LABEL','lc_sink_afterload'),('RET',0)])
for kind,ops in variants.items():
 helper='lc_'+kind;m.fx(helper,1,4 if kind=='ns4' else 3,[('FUEL',)]+ops+[('LGET',0,1),('CALL','lc_sink',0,1),('RET',0)])
 driver=[('FUEL',),('LGET',0,1),('LGET',1,2),('CONST',2,20),('CONST',3,30),('CONST',4,40),('VEC',0,5),('LSET',4,0),('LGET',0,4),('CALL',helper,0,1),('LGET',1,3),('RT','RT-VECTOR-AT',0,2),('RET',0)];m.fx(helper+'_driver',3,4,driver)
fns,labels,lits,sir,frec=m.layout_tables();typeform='(defn- t-lc-types [M :vector-i64] :vector-i64 (-> M '+' '.join('(t-put '+str(m.C['MM-FN-BASE']+fns[name]*m.C['MM-FN-W']+field)+' '+ty+')' for name,np,ns,dp,b in m.FIX[old:] for field,ty in [(m.C['FF-RTYPE'],'TY-I64' if name.endswith('_driver') else 'TY-VEC')]+[(m.C['FF-PT0']+j,'TY-I64' if name.endswith('_driver') else 'TY-VEC') for j in range(np)])+'))\n'
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];images={}
for arm,g in [('baseline','baseline-41-a64gen.kotoba'),('candidate','41-a64gen-prototype.kotoba')]:
 text=m.kotoba(True).replace('(defn- seed-main [] :i64',typeform+'(defn- seed-main [] :i64').replace('M1 (gn-run (t-vector-chain-types (t-small-types M0)))','M1 (gn-run (t-lc-types (t-vector-chain-types (t-small-types M0))))');src=w/(arm+'-fact.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/g).read_text()+'\n'+(w/'42-layout-prototype.kotoba').read_text()+'\n'+text)
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(arm+'-fact.kseed'))]),('extract',['extract-native',str(w/(arm+'-fact.kseed')),'--symbol','main','--output',str(w/(arm+'-fact-generator.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),(w/'seed-4.offset').read_text().strip(),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(arm+'-fact-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(arm,stage,q.stdout[-1000:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout)[1]
 q=subprocess.run([str(w/'kexe-loader'),str(w/(arm+'-fact-generator.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(arm+'-fact.stdout')).write_text(q.stdout+q.stderr);assert q.returncode==0,(arm,q.stdout[-400:],q.stderr);blob,offsets=m.blob_from(q.stdout);p=w/(arm+'-fact.bin');p.write_bytes(blob);images[arm]=(p,offsets);print('PASS native fact generator',arm,len(blob),flush=True)
wrap=lambda x:((x+(1<<63))%(1<<64))-(1<<63)
def oracle(kind,a,b,probe,fuel):
 items=[a,b,20,30,40];remaining=fuel-1;result=None
 if remaining==0:return result,remaining,items
 remaining-=1
 if kind=='loop':
  for index in range(3):
   if remaining==0:return result,remaining,items
   remaining-=1;items[index]=wrap(items[index]+1)
 else:
  if kind.startswith('k'):index=int(kind[1:])
  elif kind in ['unknown','coalesced']:index=a
  elif kind=='branch':index=0 if a==0 else 1
  else:index=1
  readindex=0 if kind=='held-old' else index
  if not 0<=readindex<5:return result,remaining,items
  items[index]=items[readindex]
 if 0<=probe<5:result=items[probe]
 return result,remaining,items
rows=[];regions=[]
for kind in variants:
 name='lc_'+kind
 words={arm:[z[0] for z in struct.iter_unpack('<I',path.read_bytes()[offs[fns[name]]:offs[fns[name]+1]])] for arm,(path,offs) in images.items()}
 static=lambda ww:[((ww[j]>>10)&4095,(ww[j+3]>>10)&4095) for j in range(len(ww)-3) if (ww[j]&0xffc003ff)==0xf100007f and ww[j+1]==0x54000048 and ww[j+2]==0 and (ww[j+3]&0xffc003e0) in [0xf9400080,0xf9000080]]
 scopes={arm:static(ww) for arm,ww in words.items()};assert not scopes['baseline']
 if kind in ['k0','k1','k4','k5','k4095','copy']:assert len(scopes['candidate'])==2,(kind,scopes)
 if kind in ['k4096','k-1','k'+str(m.MIN),'k'+str(m.MAX),'ns4']:assert not scopes['candidate'],(kind,scopes)
 if kind=='coalesced':assert len(scopes['candidate'])==1,(kind,scopes)
 regions.append({'variant':kind,'words':{arm:len(ww) for arm,ww in words.items()},'staticBoundsAndScaledOffsets':scopes})
 for a in [-1,0,1,2,4,5,m.MIN,m.MAX]:
  for b in [0,m.MAX]:
   for probe in [-1,0,1,4,5]:
    for fuel in [1,2,3,4,5,6]:
     want,remaining,items=oracle(kind,a,b,probe,fuel);obs={}
     for arm,(path,offs) in images.items():
      env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');env.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'full-state-loader'),str(path),str(offs[fns[name+'_driver']]),'3','aarch64','-',str(a),str(b),str(probe)],env=env,capture_output=True,text=True);obs[arm]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
      assert (q.returncode==0)==(want is not None),(kind,a,b,probe,fuel,want,arm,q.stdout,q.stderr)
      assert ':remaining '+str(remaining)+'}' in q.stdout,(kind,a,b,probe,fuel,remaining,arm,q.stdout)
      assert obs[arm]['items']==['DIAG_VECTOR_ITEMS 5 '+' '.join(map(str,items))],(kind,a,b,probe,fuel,arm,obs[arm],items)
      if want is not None:assert ':result '+str(want)+' ' in q.stdout,(kind,a,b,probe,fuel,want,arm,q.stdout)
     assert obs['baseline']==obs['candidate'],(kind,a,b,probe,fuel,obs);rows.append({'variant':kind,'args':[a,b,probe],'fuel':fuel,'expectedResult':want,'expectedRemaining':remaining,'expectedItems':items,**obs})
 print('PASS independently modeled constant/local/coalesced/control/loop/full-state',kind,flush=True)
(w/'fact-proof.json').write_text(json.dumps({'status':'complete-independent-native-local-constant-state-oracles','comparisons':len(rows),'variants':len(variants),'originalFixtures':old,'newFixtures':len(m.FIX)-old,'regions':regions,'observations':rows},indent=2)+'\n');print('PASS fact proof',len(rows),flush=True)
