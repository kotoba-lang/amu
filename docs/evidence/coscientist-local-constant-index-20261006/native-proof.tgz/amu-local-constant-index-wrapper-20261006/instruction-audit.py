from pathlib import Path
import json,struct,collections,re
w=Path('/private/tmp/amu-local-constant-index-wrapper-20261006');b=Path('/private/tmp/amu-static-vector-chain-20261006');load=lambda p:json.loads(p.read_text());rows=[];bounds=[];tails=[];charges=0;private=0;closed=0;fuel=[0xf94004f0,0xf1000610,0x54000042,0xd4200000,0xf90004f0]
C={}
for fn in ['seed/SIR','seed/HEADS','seed/MEMORY-MAP']:
 for m in re.finditer(r'\[:c (\S+) (-?\d+)',(Path('/Users/junkawasaki/github/wt/amu-seed17')/fn).read_text()):C[m[1]]=int(m[2])
for e in load(w/'ports-correctness.json')['entries']:
 name=e['workload'];d=w/'observer/meta-ports'/name;a=load(d/'census.json');old=load(b/'observer/meta-ports'/name/'census.json');lines=(d/'compile.log').read_text().splitlines();oldlines=(b/'observer/meta-ports'/name/'compile.log').read_text().splitlines();assert [z for z in lines if z.startswith('SIR ')]==[z for z in oldlines if z.startswith('SIR ')]
 for f,v in a['functions'].items():
  for field in ['start','end','frameBytes','locals','depth','localCalleeRegisters','leaf']:assert v[field]==old['functions'][f][field],(name,f,field)
 oa={v['sir']:v for v in old['events']};cache={int(z.split()[1]):list(map(int,z.split()[2:])) for z in lines if z.startswith('CACHE ')};word=list(struct.unpack('<'+'I'*((d/'native.bin').stat().st_size//4),(d/'native.bin').read_bytes()[:((d/'native.bin').stat().st_size//4)*4]))
 for v in a['events']:
  p=oa[v['sir']]
  if v['op']=='OP-FUEL':assert v['words']==p['words']
  if [int(z,16) for z in p['words']][:5]==fuel:assert [int(z,16) for z in v['words']][:5]==fuel;charges+=1
  if v['op']=='OP-LSET':assert v['words']==p['words'],(name,v,p)
  if v['op']=='OP-FN' and cache[v['sir']][2]==2:
   f=a['functions'][str(v['fn'])];assert f['leaf']==2 and f['frameBytes']==0 and 1<=f['locals']<=3 and 1<=f['depth']<=3 and word[f['codeWordStart']-1]==0xd2800005;closed+=1
 # Independently interpret only straightline literal/local moves. No observed
 # guest values, names or compiler metadata are used to prove an index value.
 sir={int(z.split()[1]):list(map(int,z.split()[2:])) for z in lines if z.startswith('SIR ')};owners={i:int(f) for f,v in a['functions'].items() for i in range(v['start'],v['end']+1)};loc={};temp={};proved={}
 def wrapped(target,n,kind):
  if str(target) not in a['functions']:return False
  p=a['functions'][str(target)]['start'];end=a['functions'][str(target)]['end'];op,f,np,ns=sir[p]
  if op!=1 or f!=target or np!=n:return False
  p+=1
  if sir[p][0]==C['OP-FUEL']:p+=1
  while sir[p][0]==9:p+=1
  for k in range(n):
   if sir[p]!=[4,k,k+1,0]:return False
   p+=1
  return sir[p]==[14,176 if kind==0 else 208,0,n] and sir[p+1]==[C['OP-RET'],0,0,0] and p+2==end and sir[end][0]==2
 for i,(op,x,z,k) in sir.items():
  if op==1:loc={};temp={}
  elif op==3:temp[x]=z if k==0 else None
  elif op==4:temp[x]=loc.get(z)
  elif op==5:loc[x]=temp.get(z)
  elif op in [6,7,8]:temp[z]=None
  elif op in [9,10,11,12]:loc={};temp={}
  elif op in [13,14]:
   if k in [2,3]:proved[i]=temp.get(z+1)
   temp[z]=None
   if op==13 and not (k in [2,3] and wrapped(x,k,0 if k==2 else 1)):loc={};temp={}
  elif op not in [2,C['OP-FUEL'],C['OP-RET']]:loc={};temp={}
 indices=[]
 for z in lines:
  if not z.startswith('INDEX '):continue
  at,kind,t,encoded,dk,dv,f0,f1,f2=map(int,z.split()[1:])
  if encoded<=0:continue
  event=next(v for v in a['events'] if v['firstWord']<=at<v['afterWord']);i=event['sir'];assert cache[i][0]==2 and 1<=encoded<=4096 and proved.get(i)==encoded-1,(name,i,encoded,proved.get(i));op,x,bt,n=sir[i]
  assert op==14 and x==[176,208][kind] or op==13 and wrapped(x,n,kind),(name,i,op,x,n,kind)
  region=word[at-1:event['afterWord']-1];k=encoded-1
  expected=(0xf100007f|(k<<10),0x54000048,0)
  pos=[j for j in range(len(region)-3) if tuple(region[j:j+3])==expected];assert len(pos)==1,(name,i,k,pos)
  mem=region[pos[0]+3];assert (mem&0xffc003e0)==(0xf9400080 if kind==0 else 0xf9000080) and ((mem>>10)&4095)==k,(name,i,k,hex(mem));indices.append((at,kind,encoded))
  bounds.append({'workload':name,'sir':i,'kind':kind,'index':k,'sourceLiteralLocalProved':True,'unsignedHiAndScaledOffsetChecked':True})
 for z in lines:
  if z.startswith('BASE '):
   at,slot,known,hit,conditional,rv=map(int,z.split()[1:]);assert hit==int(slot>0 and slot==known) and conditional==int(known==-1 and slot==1);off=0 if hit else 13 if conditional else 15
   assert any(at>=ix[0] and at<ix[0]+5 for ix in indices),(name,at,indices[:4])
   if conditional:assert word[at-1]==0xb50001a5
   if not hit and not conditional:assert word[at-1]==0xb4000065 and word[at+1]&0xff00001f==0x54000000
   assert word[at+off]==0x54000048 and word[at+off+1]==0
 tw={int(z.split()[1]):list(map(int,z.split()[2:])) for z in lines if z.startswith('TAILWIT ')}
 for z in lines:
  if not z.startswith('FIX '):continue
  fix,at,kind,target,aux=map(int,z.split()[1:]);assert aux in [0,1]
  if kind!=4:assert aux==0;continue
  dest=a['functions'][str(target)]['codeWordStart'];ins=word[at-1];assert ins&0x7c000000==0x14000000;imm=ins&0x3ffffff;imm=imm-(1<<26) if imm&(1<<25) else imm;assert at+imm==dest+aux
  if aux:
   wit=tw[fix];assert wit[0]==target and wit[2]==1 and wit[3]>0 and wit[4]==3 and wit[5]==wit[3] and wit[6]==1;assert ins&0xfc000000==0x14000000 and word[dest-1]==0xd2800005;private+=1;tails.append(wit)
 rows.append({'workload':name,'originalSirFrameLocalDepthLeafExact':True,'originalFuelAndExplicitAssignmentCodeExact':True,'baselineWords':old['codeWords'],'candidateWords':a['codeWords'],'nativeByteExact':e['nativeSha256']==next(z['nativeSha256'] for z in load(b/'ports-correctness.json')['entries'] if z['workload']==name)})
assert len(bounds)==502 and collections.Counter(z['kind'] for z in bounds)=={0:119,1:383};assert private==289 and closed==390 and charges==1806 and sum(z['nativeByteExact'] for z in rows)==18
out={'status':'complete-all19-native-literal-fact-bound-address-original-assignment-SIR-frame-fuel-private-transfer-audit','constantReads':119,'constantWrites':383,'privateTransfers':private,'closedFunctions':closed,'originalFiveWordFuelPrefixes':charges,'rows':rows,'bounds':bounds,'tailWitnesses':tails,'notRuntimeTimeShares':True};(w/'instruction-audit.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS independent machine/source audit',len(bounds),'constant accesses',private,'private transfers',charges,'fuel prefixes')
