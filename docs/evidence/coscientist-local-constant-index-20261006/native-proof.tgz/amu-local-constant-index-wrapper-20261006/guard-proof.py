from pathlib import Path
import subprocess,os,re,json
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-local-constant-index-wrapper-20261006');tests=[]
for val,expected in [(-9223372036854775808,0),(-1,0),(0,1),(1,2),(4095,4096),(4096,0),(9223372036854775807,0)]:tests.append(f'(t-c M {val} {expected})')
for slot,expected in [(0,0),(1,1),(2,2),(3,4096),(4,0)]:tests.append(f'(t-local M {slot} {expected})')
for kind in ['gn-k-reg','gn-k-home','gn-k-lit']:tests.append(f'(t-kind M {kind})')
for mode in [0,1]:tests.append(f'(t-mode M {mode})')
for op in ['OP-LABEL','OP-BR','OP-BRZ','OP-BRNZ','OP-CALLI','OP-CAP','OP-VEC','OP-STR','OP-FN','OP-END','OP-TRAP']:tests.append(f'(t-boundary M {op})')
for slot in [0,2,4]:tests.append(f'(t-drop M {slot})')
tests.append('(t-coalesced M)')
probe='''(defn- t-known [M :vector-i64] :vector-i64
 (-> M (gn-gs gn-f-vmode 2) (gn-gs gn-ix-base 1) (gn-gs (inc gn-ix-base) 2) (gn-gs (+ gn-ix-base 2) 4096)))
(defn- t-c [M :vector-i64 v :i64 expected :i64] :bool
 (= (gn-ix-temp (gn-dset (t-known M) 1 gn-k-const v) 1) expected))
(defn- t-local [M :vector-i64 slot :i64 expected :i64] :bool
 (= (gn-ix-temp (gn-dset (t-known M) 1 gn-k-local slot) 1) expected))
(defn- t-kind [M :vector-i64 kind :i64] :bool
 (= (gn-ix-temp (gn-dset (t-known M) 1 kind 1) 1) 0))
(defn- t-mode [M :vector-i64 mode :i64] :bool
 (= (gn-ix-temp (-> (t-known M) (gn-dset 1 gn-k-const 1) (gn-gs gn-f-vmode mode)) 1) 0))
(defn- t-boundary [M :vector-i64 op :i64] :bool
 (let [q (gn-ix-step (t-known M) 0 op 0)]
  (and (= (gn-g q gn-ix-base) 0) (= (gn-g q (inc gn-ix-base)) 0) (= (gn-g q (+ gn-ix-base 2)) 0))))
(defn- t-drop [M :vector-i64 slot :i64] :bool
 (let [q (gn-ix-drop (t-known M) slot)]
  (and (= (gn-g q gn-ix-base) 1) (= (gn-g q (inc gn-ix-base)) (if (= slot 2) 0 2)) (= (gn-g q (+ gn-ix-base 2)) 4096))))
(defn- t-coalesced [M :vector-i64] :bool
 (let [q (gn-fin (t-known M) 0 2 1)]
  (and (= (gn-g q gn-ix-base) 1) (= (gn-g q (inc gn-ix-base)) 0) (= (gn-g q (+ gn-ix-base 2)) 4096) (= (gn-g q gn-f-skip) 1))))
(defn- seed-main [] :i64
 (let [M (gn-put (mem-new) gn-cell 1000)] (if (and TESTS) 0 1)))
'''.replace('TESTS',' '.join(tests))
src=w/'fact-guards.kotoba';src.write_text('\n'.join((r/p).read_text() for p in ['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'])+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+(w/'42-layout-prototype.kotoba').read_text()+'\n'+probe)
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/'fact-guards.kseed')]),('extract',['extract-native',str(w/'fact-guards.kseed'),'--symbol','main','--output',str(w/'fact-guards.bin')])]:
 q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),(w/'seed-4.offset').read_text().strip(),'0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/('guard-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(stage,q.stdout[-1000:],q.stderr)
 if stage=='extract':off=re.search(r':offset (\d+)',q.stdout)[1]
q=subprocess.run([str(w/'kexe-loader'),str(w/'fact-guards.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/'guard-run.log').write_text(q.stdout+q.stderr);assert q.returncode==0,(q.stdout,q.stderr)
(w/'guard-proof.json').write_text(json.dumps({'status':'complete-native-small-index-kind-mode-control-boundary-and-coalesced-write-guard-controls','controls':len(tests),'conditions':tests,'exit':q.returncode},indent=2)+'\n');print('PASS native fact guard controls',len(tests),flush=True)
