from pathlib import Path
import os,re,json,subprocess,struct
w=Path('/private/tmp/amu-unsigned-less-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');ns={};exec((w/'fixture-proof.py').read_text().split('env=dict(')[0],ns);m=ns['m'];typeform=ns['typeform'];pairs=[(-1,m.MIN),(m.MIN,-1),(0,m.MIN),(m.MIN,0),(m.MAX,m.MIN),(m.MIN,m.MAX)];names=[]
for j,(a,b) in enumerate(pairs):
 name='ul_both'+str(j);names.append(name);m.fx(name,0,0,[('FUEL',),('CONST',0,a),('CONST',1,b),('CALL','ul_helper',0,2),('RET',0)])
fns,*_=m.layout_tables();extra='(defn- t-ul-both-types [M :vector-i64] :vector-i64 (-> (t-ul-types M) '+' '.join('(t-put '+str(m.C['MM-FN-BASE']+fns[n]*m.C['MM-FN-W']+m.C['FF-RTYPE'])+' TY-BOOL)' for n in names)+'))\n';env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');rows=[];images={}
for label,g in [('baseline','baseline-41-a64gen.kotoba'),('candidate','41-a64gen-prototype.kotoba')]:
 text=m.kotoba(True).replace('(defn- seed-main [] :i64',typeform+extra+'(defn- seed-main [] :i64').replace('        M1 (gn-run (t-small-types M0))','        M1 (gn-run (t-ul-both-types (t-small-types M0)))');src=w/(label+'-const.kotoba');src.write_text('\n'.join((r/p).read_text() for p in ['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'])+'\n'+(w/g).read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+text)
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'-const.kseed'))]),('extract',['extract-native',str(w/(label+'-const.kseed')),'--symbol','main','--output',str(w/(label+'-const-generator.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-const-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout,q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'-const-generator.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0;(w/(label+'-const.stdout')).write_text(q.stdout);blob,offsets=m.blob_from(q.stdout);p=w/(label+'-const.bin');p.write_bytes(blob);images[label]=(p,offsets)
for name,(a,b) in zip(names,pairs):
 want=int((a&((1<<64)-1))<(b&((1<<64)-1)))
 for fuel in [1,2,(1<<53)-1]:
  obs={}
  for label,(p,ofs) in images.items():
   env=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');env.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'full-state-loader'),str(p),str(ofs[fns[name]]),'0','aarch64','-'],env=env,capture_output=True,text=True);assert q.returncode==0 and ':result '+str(want)+' ' in q.stdout and ':remaining '+str(fuel-1)+'}' in q.stdout;obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'stderr':q.stderr}
  assert obs['baseline']==obs['candidate'];rows.append({'fixture':name,'args':[a,b],'expected':want,'fuel':fuel,**obs})
(w/'constant-proof.json').write_text(json.dumps({'status':'complete-independent-native-both-constant-unsigned-fold-state','comparisons':len(rows),'observations':rows},indent=2)+'\n');print('PASS',len(rows),'independent constant-fold fullstate comparisons')
