from pathlib import Path
import json,hashlib
w=Path('/private/tmp/amu-unsigned-less-20261006');b=Path('/private/tmp/amu-small-tail-frame-20261006');load=lambda p:json.loads(p.read_text());rows=[];changes=[]
for e in load(w/'ports-correctness.json')['entries']:
 name=e['workload'];a=load(w/'observer/meta-ports'/name/'census.json');old=load(b/'observer/meta-ports'/name/'census.json');raw=lambda root:[z for z in (root/'observer/meta-ports'/name/'compile.log').read_text().splitlines() if z.startswith('SIR ')];assert raw(w)==raw(b);assert a['allEmissionRangesPartitioned'] and old['allEmissionRangesPartitioned'];assert a['functions'].keys()==old['functions'].keys()
 for f,v in a['functions'].items():
  for k in ['start','end','frameBytes','locals','depth','localCalleeRegisters','leaf']:assert v[k]==old['functions'][f][k],(name,f,k)
  assert [[z[k] for k in ['start','backedge','label']] for z in v['loops']]==[[z[k] for k in ['start','backedge','label']] for z in old['functions'][f]['loops']]
 oa={v['sir']:v for v in old['events']};words=lambda v:[int(z,16) for z in v['words']]
 for v in a['events']:
  p=oa[v['sir']]
  if v['op']=='OP-FUEL':assert v['words']==p['words'],(name,v,p)
  if v['op']=='OP-CALL':
   bl=lambda v:sum((z&0xfc000000)==0x94000000 for z in words(v));bb=lambda v:sum((z&0xfc000000)==0x14000000 for z in words(v));before=bl(p)+bb(p);after=bl(v)+bb(v)
   if before>after:
    assert name=='statemate' and before==1 and after==0 and a['functions'][str(v['fn'])]['leaf']==0
    assert any((z&0xffffffe0)==0x9a9f27e0 for z in words(v)),(name,v)
    changes.append({'workload':name,'sir':v['sir'],'function':v['fn'],'baselineWords':p['words'],'candidateWords':v['words']})
 rows.append({'workload':name,'originalSirExact':True,'frameLocalDepthLeafMetadataExact':True,'fuelEventWordsExact':True,'oldCodeWords':old['codeWords'],'newCodeWords':a['codeWords'],'nativeByteExact':e['nativeSha256']==next(z['nativeSha256'] for z in load(b/'ports-correctness.json')['entries'] if z['workload']==name)})
assert len(changes)==5 and sum(z['nativeByteExact'] for z in rows)==18;assert (w/'permanent-regression-fixture.bin').read_bytes()==(b/'permanent-regression-fixture.bin').read_bytes();(w/'instruction-audit.json').write_text(json.dumps({'status':'complete-all19-native-typed-uless-5-sites-and-original-frame-fuel-regression-audit','staticCountsNotTimeShares':True,'original508FixtureBlobByteExact':True,'originalUnitGoldenByteExact':True,'callSites':changes,'rows':rows},indent=2)+'\n');print('PASS 5 unsigned CMP/CSET sites; all19 original frames/SIR/fuel; other18 guest bytes exact')
