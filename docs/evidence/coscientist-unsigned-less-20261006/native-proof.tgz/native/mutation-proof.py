from pathlib import Path
import json,subprocess,re,os
w=Path('/private/tmp/amu-unsigned-less-20261006');r=Path('/Users/junkawasaki/github/wt/amu-seed17');ns={};exec((w/'fixture-proof.py').read_text().split('env=dict(')[0],ns);m=ns['m'];fns=ns['fns'];sir=ns['sir'];typeform=ns['typeform'];f=fns['ul_helper'];owner=fns['ul_plain'];start=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==f);opstart=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==owner);call=next(i for i,x in enumerate(sir,1) if i>opstart and x[0]==m.C['OP-CALL']);sb=m.C['MM-SIR-BASE'];sw=m.C['MM-SIR-W'];fb=m.C['MM-FN-BASE']+f*m.C['MM-FN-W'];cases=[]
for j in range(33):
 for field in range(4):cases.append((sb+(start+j)*sw+field,sir[start+j-1][field]+1))
for field,value in [('FF-SIR',0),('FF-SIR',start+1),('FF-SIR',len(sir)-31),('FF-NPARAMS',1),('FF-NSLOTS',3),('FF-DEPTH',3),('FF-RTYPE',m.C['TY-I64']),('FF-PT0',m.C['TY-BOOL'])]:cases.append((fb+m.C[field],value))
cases.append((fb+m.C['FF-PT0']+1,m.C['TY-F64']))
for field,value in [(0,m.C['OP-CALLI']),(1,0),(2,1),(3,1)]:cases.append((sb+call*sw+field,value))
cases.append((sb+(call+1)*sw,m.C['OP-RES2']))
entry_label=sir[start][1];foreign=next(i for i,x in enumerate(sir,1) if x[0]==m.C['OP-FN'] and x[1]==fns['st_id'])+1
probe=f'''(defn- t-ul-check [M :vector-i64] :bool (gn-uless (gn-gs M gn-f-leaf 0) {call} {f} 0 2))
(defn- t-ul-mut [M :vector-i64 at :i64 value :i64] :bool
 (let [old (vector-at M at) set (t-put M at value) got (t-ul-check set) restore (t-put set at old)] (not got)))
(defn- t-ul-open [M :vector-i64] :bool
 (let [old (gn-g M gn-g-open) old_n (gn-g M gn-g-open-n)
       set (-> M (gn-gs gn-g-open {f}) (gn-gs gn-g-open-n 1)) got (t-ul-check set)
       restore (-> set (gn-gs gn-g-open old) (gn-gs gn-g-open-n old_n))] (not got)))
(defn- t-ul-duplicate [M :vector-i64] :bool
 (let [at (+ MM-SIR-BASE (* {foreign} MM-SIR-W)) old_op (vector-at M at) old_a (vector-at M (+ at 1))
       set (-> M (t-put at OP-LABEL) (t-put (+ at 1) {entry_label})) got (t-ul-check set)
       restore (-> set (t-put at old_op) (t-put (+ at 1) old_a))] (not got)))
(defn- t-ul-guards [M :vector-i64] :bool
 (and (t-ul-check M)
 {' '.join(f'(t-ul-mut M {at} {v})' for at,v in cases)}
 (t-ul-open M) (t-ul-duplicate M)
 (not (gn-uless (gn-gs M gn-f-leaf 1) {call} {f} 0 2))
 (not (gn-uless (gn-gs M gn-f-leaf 2) {call} {f} 0 2))
 (not (gn-uless M {call} 0 0 2))
 (not (gn-uless M {call} (vector-at M MM-FN-N) 0 2))))
'''
text=m.kotoba(True).replace('(defn- seed-main [] :i64',typeform+probe+'(defn- seed-main [] :i64').replace('        M1 (gn-run (t-small-types M0))','        M1 (gn-run (t-ul-types (t-small-types M0)))').replace('(if (and mask_shared','(if (and (t-ul-guards M1) mask_shared')
parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];src=w/'mutation-probe.kotoba';src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+(w/'41-a64gen-prototype.kotoba').read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+text);env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728')
for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/'mutation-probe.kseed')]),('extract',['extract-native',str(w/'mutation-probe.kseed'),'--symbol','main','--output',str(w/'mutation-probe.bin')])]:
 q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/('mutation-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(stage,q.stdout[-300:],q.stderr)
 if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
q=subprocess.run([str(w/'kexe-loader'),str(w/'mutation-probe.bin'),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/'mutation-probe.stdout').write_text(q.stdout+q.stderr);assert q.returncode==0,(q.stdout[-300:],q.stderr);(w/'mutation-proof.json').write_text(json.dumps({'status':'complete-native-exact-uless-all-instruction-field-and-metadata-open-duplicate-mode-refusals','instructionFieldMutations':132,'metadataAndCallMutations':len(cases)-132,'positiveControls':1,'openRefusals':1,'duplicateLabelRefusal':True,'modeRefusals':2,'invalidCalleeControls':2,'mutations':cases},indent=2)+'\n');print('PASS all',len(cases),'native exact-shape mutation refusals')
