from pathlib import Path
import json,shutil,hashlib,tarfile,subprocess
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-unsigned-less-20261006');e=r/'docs/evidence/coscientist-unsigned-less-20261006';e.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());t=load(w/'timing-audit.json');assert t['acceptedTriples']==30 and not t['qualifiedImprovements'] and not t['qualifiedRegressions'] and not t['unstable'];assert (r/'seed/41-a64gen.kotoba').read_bytes()==(w/'baseline-41-a64gen.kotoba').read_bytes();assert sha(w/'41-a64gen-prototype.kotoba')==load(w/'preflight.json')['prototypeSha256'];s=w/'source-snapshot';s.mkdir();names=['seed/MANIFEST','scripts/seed/a64gen-fixtures.py','seed/tests/unit/41-a64gen_t.kotoba','seed/tests/unit/41-a64gen.expected','seed/tests/unit/41-a64gen.fixtures.json'];names += [x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')];names += [x['source'] for x in load(r/'bench/embench/comparison-matrix.json')['entries']]
for name in names:p=s/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/name,p)
failure={'status':'initial-harness-failures-preserved-without-prototype-semantic-change','failures':['Fixture instruction diagnostic assumed BL but plain/swap/high fixtures use original terminal B; all3498 value/state comparisons passed before diagnostic. Corrected diagnostic counts both B/BL; full proof rerun passed.','Mutation probe had one extra closing parenthesis; corrected harness passed146 refusals.','Observer runner template retained old temporary paths. Initial run verified older unrelated candidate instead of new candidate; ignored as new evidence. Corrected explicit paths run all19 byte-parity and native census.','Loop metadata comparison included absolute generated code offsets. These change under shortened code; compare original SIR loop start/backedge/label graph plus exact frame/local/depth/leaf metadata instead.','Direct OP-RT census omitted expanded inline writer CALL accesses. Corrected census counts119 read-plus-writer functions; local read-to-write descriptor witness is the next prospective hypothesis.']};(w/'authoring-corrections.json').write_text(json.dumps(failure,indent=2)+'\n');p=w/'replay-timing-audit.py';p.write_text((w/'timing-audit.py').read_text().replace("w=Path('/private/tmp/amu-unsigned-less-20261006');","w=Path(__file__).resolve().parent;"))
for name,roots in [('native-proof.tgz',[(w,'native')]),('timing-proof.tgz',[(w/'remote-evidence','remote-evidence'),(p,'replay-timing-audit.py')])]:
 with tarfile.open(e/name,'w:gz') as tar:
  for root,label in roots:
   if root.is_file():tar.add(root,arcname=label);continue
   for f in sorted(root.rglob('*')):
    if not f.is_file() or '__pycache__' in f.parts:continue
    rel=f.relative_to(root)
    if root==w and rel.parts[0] in ['remote-evidence','timing-package']:continue
    tar.add(f,arcname=label+'/'+str(rel),recursive=False)
 assert (e/name).stat().st_size<100000000;print('ARCHIVE',name,(e/name).stat().st_size,flush=True)
with tarfile.open(e/'native-proof.tgz') as tar:
 assert tar.extractfile('native/source-snapshot/seed/41-a64gen.kotoba').read()==(r/'seed/41-a64gen.kotoba').read_bytes();assert tar.extractfile('native/41-a64gen-prototype.kotoba').read()==(w/'41-a64gen-prototype.kotoba').read_bytes()
for name in ['hypothesis.json','mathematical-proof.json','generations.json','preflight.json','fixture-proof.json','constant-proof.json','mutation-proof.json','instruction-audit.json','timing-audit.json','chain-census.json','next-hypothesis.json','authoring-corrections.json']:shutil.copy2(w/name,e/name)
s={'status':'rejected-for-no-qualified-performance-improvement-after-complete-native-proof-and-fresh-changed-body-timing','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'originalScope':19,'changedPrototypeGuests':['statemate'],'other18GuestBytesIdentical':True,'fullSupervisorComparisons':3763,'independentUnsignedValueStateOracles':3498,'bothConstantStateOracles':18,'original19PartialFuelStates':209,'resourceStates':38,'instructionFieldMutations':132,'metadataAndCallMutations':14,'openRefusals':1,'duplicateLabelRefusal':True,'modeRefusals':2,'invalidCalleeControls':2,'nativeGenerations1Through4Identical':True,'nativeBytes':(w/'seed-4.bin').stat().st_size,'nativeSeedSha256':sha(w/'seed-4.bin'),'prototypeSha256':sha(w/'41-a64gen-prototype.kotoba'),'original508Fixtures14523RunsAndGoldenUnchanged':True,'actualOriginalFixtureBlobByteExact':True,'originalFrameLocalDepthLeafAndFuelMetadataExact':True,'actualUnsignedCmpCsetCallSites':5,'staticCountsNotDynamicTimeShares':True,'acceptedTriples':30,'unstable':[],'qualifiedImprovements':[],'qualifiedRegressions':[],'qualifiedCOrBetter':[],'timing':t['rows'],'productChanged':False,'productPromoted':False,'productGatesAndIntegratedAdoption':'Not run: performance prerequisite failed; qualified previous product remains unchanged.','nativeDefCIDCacheConnected':False,'resultMemoization':False,'all19GoalAchieved':False,'officialEmbenchScore':False,'next':load(w/'next-hypothesis.json')};(e/'summary.json').write_text(json.dumps(s,indent=2)+'\n');(e/'checksums.sha256').write_text(''.join(sha(f)+'  '+f.name+'\n' for f in sorted(e.iterdir()) if f.name!='checksums.sha256'));row=t['rows'][0]
doc=f'''# Exact unsigned-less specialization: correct native code, no qualified gain

The registered exact uncharged unsigned-less prototype passes native semantic
proof and four byte-identical self-build generations. It removes5 original
statemate returning-call sites, but a fresh same-host product/candidate/C campaign
qualifies **no improvement**. Reject it for performance; the qualified
[small-tail-frame product](coscientist-small-tail-frame-20261006.md) remains unchanged.
Original19 scope and C-or-better goal remain; these are aligned original-body
measurements, not official Embench scores.

## Exact proof and generated code

The helper's signed branches implement unsigned i64 comparison: equal signs
preserve signed order; nonnegative values precede negative bitpatterns. The
[mathematical proof](evidence/coscientist-unsigned-less-20261006/mathematical-proof.json)
records all4 sign cases and the negative-immediate carry equivalence for CMN.
Only an exact33-instruction FN/LABEL/branch/RET/END tree, including every reserved
field, closed i64/i64→bool metadata, exact parameter/local/depth records and
module-unique owned labels qualifies. The pattern contains no fuel, runtime,
capability, allocation or other call. Unknown/malformed/open metadata, changed
branches/charges and multi-result calls retain the original call.

The specialization is separate from prescan leaf classification. Original caller
frames, locals, depths, callee-saved registers and published fuel remain. Existing
comparison/result machinery preserves live operands, result coalescing and homes;
CMP with carry-clear CSET returns exact0/1. It executes actual input comparisons;
no computation-result cache or benchmark-name dispatch is introduced. Both
constant operands use the compiler's independently checked equivalent scalar
fold, with unchanged uncharged helper semantics.

- Native generations1/2/3/4 identical837720 bytes, SHA256
  `{s['nativeSeedSha256']}`.
- 3763 exact full supervisor comparisons:3498 independent unsigned bitpattern,
  parameter swap, live local/temp, high home, result-coalescing, repeated-call,
  negative immediate and fuel oracles;18 both-constant cases;209 original19
  full/partial-fuel states;38 resource/partial states.
- All132 helper instruction-field mutations,14 metadata/call mutations, one
  open refusal, duplicate-label refusal, both other-mode refusals and invalid
  callee controls pass native checks.
- Original508 fixtures/14523 actual native executions pass; expectations and
  generated golden are unchanged. Real/test code and offsets agree; the
  executed fixture blob is byte-identical to the current qualified product.
- Read-only observer/quiet bytes agree for all19. Original SIR/loop graph,
  frame/local/depth/leaf metadata and every FUEL event word are exact. Five
  statemate returning BL sites become unsigned CMP/CSET. Other18 guests are
  byte-identical. Statemate code shrinks21316→21306 words. Counts are static,
  not dynamic time shares.

Initial harness failures/corrections are preserved in
[authoring notes](evidence/coscientist-unsigned-less-20261006/authoring-corrections.json):
a B-versus-BL fixture diagnostic assumption, extra probe parenthesis, observer
runner's stale temporary paths, absolute relocated offsets in loop comparison,
and direct-runtime-only census. None changed the prototype's algorithm or
relaxed a semantic expectation. The stale observer run is excluded from new
candidate evidence; corrected paths produce all19 native census/byte proofs.

## One fresh campaign and rejection

Authorized zebulun Apple M4, unchanged original C/runner/spec.30 accepted
rotating triples from33 attempts; exact fuel checked on every native sample.
All series satisfy10% maximum RSD; improvement still requires1.05x speedup and
mean gap greater than summed SD. Raw admissions/rejections remain; no identical
candidate is retimed to change its decision.

| statemate original body | Mean ns | SD ns | RSD |
| --- | ---: | ---: | ---: |
| Current qualified product | {row['baseline']['meanNsPerBody']:.3f} | {row['baseline']['sdNs']:.3f} | {100*row['baseline']['relativeSd']:.3f}% |
| Unsigned-less prototype | {row['candidate']['meanNsPerBody']:.3f} | {row['candidate']['sdNs']:.3f} | {100*row['candidate']['relativeSd']:.3f}% |
| Pinned C | {row['C']['meanNsPerBody']:.3f} | {row['C']['sdNs']:.3f} | {100*row['C']['relativeSd']:.3f}% |

Candidate/product ratio is{row['candidate']['meanNsPerBody']/row['baseline']['meanNsPerBody']:.6f}x;
its {row['timeReductionPercent']:.3f}% time reduction is negative. This does not
qualify as regression either: the difference is smaller than summed SD. Stable
measurement establishes0 improvements,0 regressions and0 C-or-better cases.
Candidate/C is{row['candidateOverC']:.6f}x. Earlier qualified results are not
replaced or compounded; no new full-suite aggregate is claimed.

Independent raw-row audit verifies every proof/source/native/C/runner/spec/fuel
pin and recomputes all statistics/decisions. Product gates and integrated
adoption were not run because performance failed its prerequisite. Source
snapshot `{s['sourceCommit']}` remains the product; rung/bin/amu/wire20 are
unchanged. PR remains draft. C-or-better across19 and100% selfhost release remain
unachieved. Native DefCID/artifact/result caching remains unconnected.

## Corrected next census and prospective hypothesis

Direct OP-RT counting shows119 runtime accesses in391 small mode2 functions,
with no function having multiple direct runtime operations. That misses expanded
CALL writers and cannot reject a local cache by itself. Counting actual inline
put emissions adds383 writer accesses; **119 functions combine a direct runtime
access with an inline writer**. There are291 observed terminal B edges among
small mode2 functions. These counts prove neither eligibility nor dynamic cost.

The next [registered hypothesis](evidence/coscientist-unsigned-less-20261006/next-hypothesis.json)
therefore targets a **same-local read-to-inline-writer descriptor witness** in
proved spare registers. First validation stays at the original read; a following
exact closed same-handle writer may reuse length/data base while retaining its
original index check, fuel/trap/partial-state ordering. Local replacement,
branches, unknown calls/effects and open/changed writer shapes invalidate the
witness; uncertain register aliases retain the original path. No runtime
key branch or result memoization is assumed. It starts from the qualified
small-tail-frame product, excluding this rejected prototype. It is unimplemented
and unmeasured. Cross-terminal descriptor transfer is a later candidate requiring
a separately proved internal/public-entry ABI, not inferred from a local witness.

## Evidence and replay

[Summary](evidence/coscientist-unsigned-less-20261006/summary.json),
[timing audit](evidence/coscientist-unsigned-less-20261006/timing-audit.json),
[checksums](evidence/coscientist-unsigned-less-20261006/checksums.sha256),
[native proof/source snapshots](evidence/coscientist-unsigned-less-20261006/native-proof.tgz),
[raw timing/C receipts](evidence/coscientist-unsigned-less-20261006/timing-proof.tgz).
Extract timing archive and run replay-timing-audit.py for independent offline
validation. Native archive retains all machine generations, source19 snapshots,
complete supervisor and14523 regression observations, mutation/SIR/machine audits,
initial failures and corrected next census. Bootstrap Python/C authoring is a
one-off research exception; no product host dependency or source refactor was
introduced.
'''
(r/'docs/coscientist-unsigned-less-20261006.md').write_text(doc);print('PASS rejected experiment fully archived; product unchanged',flush=True)
