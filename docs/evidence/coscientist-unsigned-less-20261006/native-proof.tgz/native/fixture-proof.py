from pathlib import Path
import importlib.util,json,re,subprocess,os,hashlib,struct
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-unsigned-less-20261006');raw=(r/'scripts/seed/a64gen-fixtures.py').read_text().replace("R = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))", "R = '/Users/junkawasaki/github/wt/amu-seed17'",1);(w/'frozen-fixtures.py').write_text(raw);sp=importlib.util.spec_from_file_location('fx',w/'frozen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);old=len(m.FIX);T=json.loads((w/'exact-shape.json').read_text());labels={a:'ul_'+str(i) for i,(op,a,b,c) in enumerate(T) if op==m.C['OP-LABEL']};ops={v:k[3:] for k,v in m.C.items() if k.startswith('OP-')};body=[]
for op,a,b,c in T[1:-1]:
 opname=ops[op];a=labels[a] if opname in ['LABEL','BR'] else 'CC-LT' if opname=='CMP' else a;b=labels[b] if opname in ['BRZ','BRNZ'] else b;body.append((opname,a,b,c))
m.fx('ul_helper',2,2,body)
m.fx('ul_plain',2,2,[('FUEL',),('LGET',0,1),('LGET',1,2),('CALL','ul_helper',0,2),('RET',0)])
m.fx('ul_swap',2,2,[('FUEL',),('LGET',0,2),('LGET',1,1),('CALL','ul_helper',0,2),('RET',0)])
m.fx('ul_live',3,3,[('FUEL',),('FUEL',),('LGET',0,3),('LGET',1,2),('LGET',2,1),('CALL','ul_helper',1,2),('BIN','BOP-ADD',0),('RET',0)])
m.fx('ul_coalesce',2,3,[('FUEL',),('LGET',0,1),('LGET',1,2),('CALL','ul_helper',0,2),('LSET',3,0),('LGET',0,1),('LGET',1,2),('BIN','BOP-ADD',0),('LGET',1,3),('BIN','BOP-ADD',0),('RET',0)])
m.fx('ul_high',2,2,[('FUEL',),('LGET',7,1),('LGET',8,2),('CALL','ul_helper',7,2),('RET',7)])
m.fx('ul_repeat',2,3,[('FUEL',),('LGET',0,1),('LGET',1,2),('CALL','ul_helper',0,2),('LSET',3,0),('LGET',0,2),('LGET',1,1),('CALL','ul_helper',0,2),('LGET',1,3),('BIN','BOP-ADD',0),('RET',0)])
CONSTANTS=[-1,0,1,-4095,4095,-4096,4096,m.MIN,m.MAX]
for j,k in enumerate(CONSTANTS):
 for side in ['right','left']:
  b=[('LGET',0,1),('CONST',1,k)] if side=='right' else [('CONST',0,k),('LGET',1,1)]
  m.fx('ul_'+side+str(j),1,1,[('FUEL',)]+b+[('CALL','ul_helper',0,2),('RET',0)])
fns,labels,lits,sir,frec=m.layout_tables();p=fns['ul_helper'];typeform='(defn- t-ul-types [M :vector-i64] :vector-i64\n (-> M '+' '.join('(t-put '+str(m.C['MM-FN-BASE']+fns[name]*m.C['MM-FN-W']+fld)+' '+ty+')' for name,np,ns,dp,b in m.FIX[old:] for fld,ty in [(m.C['FF-RTYPE'],'TY-BOOL' if name not in ['ul_live','ul_coalesce','ul_repeat'] else 'TY-I64')]+[(m.C['FF-PT0']+j,'TY-I64') for j in range(np)])+'))\n'
env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_PAIRS='16777216',KEXE_VECTOR_ITEMS='134217728');images={};parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba']
for label,gen in [('baseline','baseline-41-a64gen.kotoba'),('candidate','41-a64gen-prototype.kotoba')]:
 text=m.kotoba(True).replace('(defn- seed-main [] :i64',typeform+'(defn- seed-main [] :i64').replace('        M1 (gn-run (t-small-types M0))','        M1 (gn-run (t-ul-types (t-small-types M0)))')
 src=w/(label+'-fixture.kotoba');src.write_text('\n'.join((r/q).read_text() for q in parts)+'\n'+(w/gen).read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+text)
 for stage,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'-fixture.kseed'))]),('extract',['extract-native',str(w/(label+'-fixture.kseed')),'--symbol','main','--output',str(w/(label+'-fixture-generator.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-fixture-'+stage+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,stage,q.stdout[-500:],q.stderr)
  if stage=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'-fixture-generator.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);(w/(label+'-fixture.stdout')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,q.stdout[-300:],q.stderr);blob,offsets=m.blob_from(q.stdout);path=w/(label+'-fixture.bin');path.write_bytes(blob);images[label]=(path,offsets);print('PASS actual native fixture',label,flush=True)
wrap=lambda v:((v+(1<<63))%(1<<64))-(1<<63);ul=lambda a,b:int((a&((1<<64)-1))<(b&((1<<64)-1)));values=[m.MIN,m.MIN+1,-65536,-4096,-1,0,1,4095,65536,m.MAX-1,m.MAX];rows=[];cases=[]
for name in ['ul_plain','ul_swap','ul_live','ul_coalesce','ul_high','ul_repeat']:
 for a in values:
  for b in values:
   c=wrap(a-b+19);want=wrap(c+ul(b,a)) if name=='ul_live' else wrap(a+b+ul(a,b)) if name=='ul_coalesce' else ul(a,b)+ul(b,a) if name=='ul_repeat' else ul(b,a) if name=='ul_swap' else ul(a,b);args=[a,b,c] if name=='ul_live' else [a,b];charges=2 if name=='ul_live' else 1
   for fuel in [1,2,3,(1<<53)-1]:cases.append((name,args,want,charges,fuel))
for j,k in enumerate(CONSTANTS):
 for side in ['right','left']:
  for a in values:
   for fuel in [1,2,(1<<53)-1]:cases.append(('ul_'+side+str(j),[a],ul(a,k) if side=='right' else ul(k,a),1,fuel))
for name,args,want,charges,fuel in cases:
 obs={}
 for label,(path,offsets) in images.items():
  e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None);q=subprocess.run([str(w/'full-state-loader'),str(path),str(offsets[fns[name]]),str(len(args)),'aarch64','-']+list(map(str,args)),env=e,capture_output=True,text=True);obs[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)};assert (q.returncode==0)==(fuel>=charges),(name,args,fuel,label,q.stdout,q.stderr)
  if fuel>=charges:assert ':result '+str(want)+' ' in q.stdout and ':remaining '+str(fuel-charges)+'}' in q.stdout,(name,args,fuel,want,label,q.stdout)
 assert obs['baseline']==obs['candidate'],(name,args,fuel,obs);rows.append({'fixture':name,'args':args,'expected':want,'charges':charges,'fuel':fuel,**obs})
 if len(rows)%300==0:print('PASS independent unsigned oracle',len(rows),flush=True)
regions=[]
for name in ['ul_plain','ul_swap','ul_live','ul_coalesce','ul_high','ul_repeat']:
 words={label:[z[0] for z in struct.iter_unpack('<I',path.read_bytes()[offsets[fns[name]]:offsets[fns[name]+1]])] for label,(path,offsets) in images.items()};count=lambda ws:sum((z&0x7c000000)==0x14000000 for z in ws);assert count(words['baseline'])>0 and count(words['candidate'])==0,(name,words)
 regions.append({'fixture':name,'baselineWords':len(words['baseline']),'candidateWords':len(words['candidate']),'baselineDirectTransfers':count(words['baseline']),'candidateDirectTransfers':count(words['candidate'])})
(w/'fixture-proof.json').write_text(json.dumps({'status':'complete-independent-native-unsigned-bitpattern-argument-live-local-home-constant-fuel-fullstate','comparisons':len(rows),'originalFixtures':old,'newFixtures':len(m.FIX)-old,'regions':regions,'images':{label:{'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} for label,(path,_) in images.items()},'observations':rows},indent=2)+'\n');print('PASS all',len(rows),'unsigned fullstate independent oracles',flush=True)
