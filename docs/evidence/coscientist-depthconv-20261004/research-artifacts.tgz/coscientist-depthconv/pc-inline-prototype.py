# BOOTSTRAP-TOOL: Reflect only; preserves every byte offset and checked index.
import pathlib,struct,json
p=pathlib.Path(__file__).resolve().parent;b=bytearray((p/'inline.bin').read_bytes());changes=[]
for at in range(0,len(b)-20,4):
 w=struct.unpack_from('<IIIII',b,at)
 if w[0]!=0xf940c0f1:continue
 add,movz,movk,ldr=w[1:]
 if add&0xffe0ffff!=0x8b000e31 or movz&0xffe0001f!=0xd2800010 or movk&0xffe0001f!=0xf2a00010 or ldr&0xffffffe0!=0xf8706a20:continue
 index=(add>>16)&31;dest=ldr&31;pool=((movz>>5)&65535)|(((movk>>5)&65535)<<16);delta=pool-at
 assert delta%4==0 and -(1<<20)<=delta<(1<<20) and pool<len(b)
 replacement=[0x10000011|(((delta//4)&0x7ffff)<<5),0xf8607800|(index<<16)|(17<<5)|dest,0xd503201f,0xd503201f,0xd503201f]
 struct.pack_into('<IIIII',b,at,*replacement);changes.append(dict(offset=at,old=list(w),new=replacement,pool=pool,index=index,destination=dest))
assert changes,'no table loads found'
(p/'pc-inline.bin').write_bytes(b);(p/'pc-inline-patch.json').write_text(json.dumps(changes,indent=2)+'\n');print('PC-relative table sites',len(changes))
