from pathlib import Path
import json,hashlib,shutil
w=Path('/private/tmp/amu-clamp-call-20261005');base=Path('/private/tmp/amu-context-call-sealed-20261005');b=json.loads((base/'ports-correctness.json').read_text());c=json.loads((w/'ports-correctness.json').read_text());gen=json.loads((w/'generations.json').read_text());package=w/'timing-package';package.mkdir();names=[]
for e in c['entries']:
 old=next(x for x in b['entries'] if x['workload']==e['workload'])
 if e['nativeSha256']==old['nativeSha256']:continue
 name=e['workload'];names.append(name);d=package/name;candidate=d/'candidate';candidate.mkdir(parents=True);shutil.copyfile(w/'ports-2'/name/'native.bin',candidate/'native.bin');shutil.copyfile(base/'ports-2'/name/'native.bin',d/'baseline-native.bin')
 (candidate/'manifest.json').write_text(json.dumps({'workload':name,'sourceSha256':e['sourceSha256'],'baselineSourceSha256':old['sourceSha256'],'nativeSha256':e['nativeSha256'],'offset':e['offset'],'baselineNativeSha256':old['nativeSha256'],'baselineOffset':old['offset'],'compilerGenerationSha256':{str(x['generation']):x['sha256'] for x in gen[1:]},'producerCompilerSha256':hashlib.sha256((base/'seed-4.bin').read_bytes()).hexdigest(),'hypothesis':'Exact signed extension then ordered signed clamp: inline CSELs into retained nonleaf caller, preserve original leaf fuel transaction and refuse open imports.','sourceHead':'e5ed92335fe44d72be11c66507b9c0f16559282d'},indent=2)+'\n')
(package/'workloads.json').write_text(json.dumps(names,indent=2)+'\n')
for src,name in [(base/'ports-correctness.json','product-proof.json'),(w/'ports-correctness.json','candidate-proof.json'),(w/'fixture-proof.json','fixture-proof.json'),(w/'bulk-state.json','bulk-state.json'),(w/'generations.json','generations.json')]:shutil.copyfile(src,package/name)
print('prepared',names,flush=True)
