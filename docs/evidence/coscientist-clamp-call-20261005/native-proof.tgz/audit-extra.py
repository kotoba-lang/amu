from pathlib import Path
import struct,json
w=Path('/private/tmp/amu-clamp-call-20261005');s=(w/'fixture-proof.py').read_text();scope={};exec(s[:s.index("parts=['seed/")],scope);m=scope['m'];targets=scope['targets'];names=[x[0] for x in m.FIX];blob,fc=m.blob_from((w/'candidate-real.stdout').read_text());endcode=4*sum(len(x.split())-1 for x in (w/'candidate-real.stdout').read_text().splitlines() if x.startswith('w '));rows=[]
for c,f,width,outer,inner,lo,hi,t,admitted in targets:
 if not admitted:continue
 cf=names.index(c)+1;a=fc[cf];b=fc.get(cf+1,endcode);words=struct.unpack('<'+'I'*((b-a)//4),blob[a:b]);charges=words.count(0xf1000508);stores=words.count(0xf90004e8)
 assert charges==outer+inner and stores==int(outer+inner>0),(c,charges,stores,outer,inner)
 rows.append({'caller':c,'leafFuelCharges':charges,'leafReturnFuelPublications':stores})
(w/'fuel-instruction-audit.json').write_text(json.dumps({'status':'complete-original-leaf-fuel-charge-and-publication-audit','rows':rows},indent=2)+'\n');print('PASS exact callee x8 charge and publication instruction counts',len(rows))
