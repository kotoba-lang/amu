from pathlib import Path
import subprocess,os,re,json,struct,hashlib
w=Path('/private/tmp/amu-clamp-call-20261005');scope={};s=(w/'fixture-proof.py').read_text();exec(s[:s.index("parts=['seed/")],scope);m=scope['m'];r=scope['r'];m.fx('cl_actual',1,1,[('LGET',0,1),('RT','RT-VECTOR-ALLOC',0,1),('CONST',0,17),('RET',0)]);names=[x[0] for x in m.FIX];sid=names.index('cl_bound2')+1;aid=names.index('cl_actual')+1;parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_VECTOR_ITEMS='134217728',KEXE_STRING_POOL='268435456',KEXE_PAIRS='16777216',KEXE_VECTORS='65536');images={};audits={}
for label in ['baseline-open','candidate-open','candidate-closed']:
 backend=(w/'baseline-41-a64gen.kotoba') if label.startswith('baseline') else w/'41-a64gen-prototype.kotoba';test=m.kotoba(True)
 if label.endswith('open'):test=test.replace('(gn-run M0)',f'(gn-run-open M0 {sid} 1)')
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+backend.read_text()+'\n'+(r/'seed/42-layout.kotoba').read_text()+'\n'+test)
 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([str(w/'kexe-loader'),str(w/'seed-4.bin'),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);assert q.returncode==0,(label,mode,q.stdout,q.stderr);(w/(label+'-'+mode+'.log')).write_text(q.stdout+q.stderr)
  if mode=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([str(w/'kexe-loader'),str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0,(label,q.stdout,q.stderr);(w/(label+'.stdout')).write_text(q.stdout);blob,fc=m.blob_from(q.stdout);mutated=bytearray(blob);struct.pack_into('<I',mutated,fc[sid],0x14000000|(((fc[aid]-fc[sid])//4)&0x03ffffff));path=w/(label+'-linked.bin');path.write_bytes(mutated);images[label]=(path,fc)
rows=[]
for t in [0,3,6,7,8]:
 caller=f'cl_call2_{t}';cf=names.index(caller)+1;per={}
 for label,(path,fc) in images.items():
  data=path.read_bytes();a=fc[cf]//4;b=fc[cf+1]//4;words=struct.unpack('<'+'I'*(b-a),data[a*4:b*4]);calls=0
  for j,x in enumerate(words):
   if x&0xfc000000==0x94000000:
    delta=x&0x03ffffff;delta-=1<<26 if delta&(1<<25) else 0;calls+=4*(a+j+delta)==fc[sid]
  assert calls==(0 if label=='candidate-closed' else 1),(caller,label,calls)
  per[label]=calls
 audits[caller]=per
 for value in [0,1,4]:
  pair={}
  for label,(path,fc) in images.items():
   e=dict(os.environ,KEXE_FUEL='16777216',KEXE_STRUCTURED_REPORT='1');e.pop('KEXE_COMMAND',None)
   q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(path),str(fc[cf]),'2','aarch64','-',str(value),'0'],env=e,capture_output=True,text=True,timeout=35)
   pair[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
  assert pair['baseline-open']==pair['candidate-open'] and pair['candidate-open']['exit']==0,(caller,value,pair)
  assert pair['candidate-open']!=pair['candidate-closed'],(caller,value,pair)
  rows.append({'caller':caller,'value':value,**pair})
out={'status':'complete-clamp-import-substitution-refusal','mechanism':'Link-replace exact scalar clamp body with signature-compatible allocating scalar callee returning17. Its diagnostic allocator clobbers x7. Explicit open-boundary candidate retains real calls and matches baseline; closed-control inlining executes old body and differs. No diagnostic enters timing.','realCalls':audits,'runs':rows};(w/'import-proof.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS 15 typed-signature-compatible imported-body replacements, register and stack temps, closed control differs',flush=True)
