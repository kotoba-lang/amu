from pathlib import Path
import json,shutil
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-clamp-call-20261005');base=Path('/private/tmp/amu-context-call-sealed-20261005')
g=(r/'seed/41-a64gen.kotoba').read_text()
helper=''';; Exact signed-extension followed by an ordered signed clamp tree.
;; Keep the original caller nonleaf. Open link-time bodies cannot prove it.
(defn- gn-clamp-open [M :vector-i64 f :i64] :bool
  (and (>= f (gn-g M gn-g-open)) (< f (+ (gn-g M gn-g-open) (gn-g M gn-g-open-n)))))
(defn- gn-clamp [M :vector-i64 i :i64 f :i64 n :i64] :i64
  (let [p (gn-fnf M f FF-SIR) fuel (if (= (gn-op M (inc p)) OP-FUEL) 1 0)
        q (gn-skiplab M (+ p 1 fuel)) target (gn-sir M (inc q) IF-A)
        slot (gn-sir M (+ q 2) IF-A) low (gn-sir M (+ q 4) IF-B) high (gn-sir M (+ q 11) IF-B)
        le (gn-sir M (+ q 6) IF-B) lx (gn-sir M (+ q 8) IF-A)
        le2 (gn-sir M (+ q 13) IF-B) lx2 (gn-sir M (+ q 15) IF-A)]
    (if (and (> p 0) (= n 1) (= (gn-g M gn-f-leaf) 0)
             (not (gn-clamp-open M f)) (not (gn-clamp-open M target))
             (not= (gn-op M (inc i)) OP-RES2)
             (= (gn-op M p) OP-FN) (= (gn-sir M p IF-A) f) (= (gn-sir M p IF-B) 1)
             (= (gn-op M q) OP-LGET) (= (gn-sir M q IF-A) 0) (= (gn-sir M q IF-B) 1)
             (= (gn-op M (inc q)) OP-CALL) (= (gn-sir M (inc q) IF-B) 0) (= (gn-sir M (inc q) IF-C) 1)
             (> (gn-sign-wrapper M target 1) 0)
             (= (gn-op M (+ q 2)) OP-LSET) (> slot 1) (= (gn-sir M (+ q 2) IF-B) 0)
             (= (gn-op M (+ q 3)) OP-LGET) (= (gn-sir M (+ q 3) IF-A) 0) (= (gn-sir M (+ q 3) IF-B) slot)
             (= (gn-op M (+ q 4)) OP-CONST) (= (gn-sir M (+ q 4) IF-A) 1) (<= low high)
             (= (gn-op M (+ q 5)) OP-CMP) (= (gn-sir M (+ q 5) IF-A) CC-LT) (= (gn-sir M (+ q 5) IF-B) 0)
             (= (gn-op M (+ q 6)) OP-BRZ) (= (gn-sir M (+ q 6) IF-A) 0) (> le 0)
             (= (gn-op M (+ q 7)) OP-CONST) (= (gn-sir M (+ q 7) IF-A) 0) (= (gn-sir M (+ q 7) IF-B) low)
             (= (gn-op M (+ q 8)) OP-BR) (> lx 0)
             (= (gn-op M (+ q 9)) OP-LABEL) (= (gn-sir M (+ q 9) IF-A) le)
             (= (gn-op M (+ q 10)) OP-LGET) (= (gn-sir M (+ q 10) IF-A) 0) (= (gn-sir M (+ q 10) IF-B) slot)
             (= (gn-op M (+ q 11)) OP-CONST) (= (gn-sir M (+ q 11) IF-A) 1)
             (= (gn-op M (+ q 12)) OP-CMP) (= (gn-sir M (+ q 12) IF-A) CC-GT) (= (gn-sir M (+ q 12) IF-B) 0)
             (= (gn-op M (+ q 13)) OP-BRZ) (= (gn-sir M (+ q 13) IF-A) 0) (> le2 0)
             (= (gn-op M (+ q 14)) OP-CONST) (= (gn-sir M (+ q 14) IF-A) 0) (= (gn-sir M (+ q 14) IF-B) high)
             (= (gn-op M (+ q 15)) OP-BR) (> lx2 0)
             (= (gn-op M (+ q 16)) OP-LABEL) (= (gn-sir M (+ q 16) IF-A) le2)
             (= (gn-op M (+ q 17)) OP-LGET) (= (gn-sir M (+ q 17) IF-A) 0) (= (gn-sir M (+ q 17) IF-B) slot)
             (= (gn-op M (+ q 18)) OP-LABEL) (= (gn-sir M (+ q 18) IF-A) lx2)
             (= (gn-op M (+ q 19)) OP-LABEL) (= (gn-sir M (+ q 19) IF-A) lx)
             (not= le lx) (not= le le2) (not= le lx2) (not= lx le2) (not= lx lx2) (not= le2 lx2)
             (= (gn-op M (+ q 20)) OP-RET) (= (gn-sir M (+ q 20) IF-A) 0)
             (= (gn-op M (+ q 21)) OP-END) (= (gn-sir M (+ q 21) IF-A) f)) q 0)))

'''
g=g.replace('(defn- gn-use [M',helper+'(defn- gn-use [M')
emit=''';; x8 reproduces the original leaf's fuel transaction; CSEL comparisons
;; use signed flags and do not subtract bounds in language arithmetic.
(defn- gn-call-clamp [M :vector-i64 i :i64 f :i64 t :i64 q :i64] :vector-i64
  (let [p (gn-fnf M f FF-SIR) fuel (= (gn-op M (inc p)) OP-FUEL)
        w (gn-sign-wrapper M (gn-sir M (inc q) IF-A) 1)
        charged (or fuel (>= w 1536)) width (bit-and w 511)
        low (gn-sir M (+ q 4) IF-B) high (gn-sir M (+ q 11) IF-B)]
    (-> M (gn-into 0 t) (gn-ctx)
        (cond-> charged (gn-emit (enc-ldr 8 7 CTX-FUEL))
                fuel (gn-mask-charge)
                (>= w 1536) (gn-mask-charge))
        (gn-emit (gn-e-bf 0x93400000 0 0 0 (dec width)))
        (gn-mov-imm 16 low) (gn-emit (enc-cmp-r 0 16))
        (gn-emit (enc-csel 0 16 0 (enc-cond-lt)))
        (gn-mov-imm 17 high) (gn-emit (enc-cmp-r 0 17))
        (gn-emit (enc-csel 0 17 0 (enc-cond-gt)))
        (cond-> charged (gn-emit (enc-str 8 7 CTX-FUEL)))
        (gn-take i t 0))))

'''
g=g.replace(';; Bounded structural proof',emit+';; Bounded structural proof')
g=g.replace('(let [w (gn-call-wrapper M i f t n)]\n   (cond', '(let [w (gn-call-wrapper M i f t n) q (gn-clamp M i f n)]\n   (cond (> q 0) (gn-call-clamp M i f t q)')
(w/'41-a64gen-prototype.kotoba').write_text(g)
files=[x.strip() for x in (r/'seed/MANIFEST').read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')]
(w/'seed-unity.kotoba').write_text(''.join((g if x=='seed/41-a64gen.kotoba' else (r/x).read_text())+'\n' for x in files))
for ext in ['bin','offset']:shutil.copyfile(base/f'seed-4.{ext}',w/f'seed-0.{ext}')
shutil.copyfile(base/'kexe-loader',w/'kexe-loader');(w/'kexe-loader').chmod(0o755)
(w/'build.py').write_text((base/'build.py').read_text().replace('amu-context-call-sealed-20261005','amu-clamp-call-20261005'))
(w/'hypothesis.json').write_text(json.dumps({'sourceHead':'e5ed92335fe44d72be11c66507b9c0f16559282d','hypothesis':'Exact width1..32 signed-extension helper followed by ordered signed i64 clamp decision tree can replace direct call with signed bitfield extension and two CSELs. Retain original nonleaf caller and exact callee leaf fuel transaction. Reject open imports, unknown forms and result pairs. No benchmark/function names.','promotion':'Native fixedpoint; all19 original source results/exactfuel/exhaustion, fullPico8192state and full targeted supervisor/trap/live-temp proof plus instruction audits; freshquiet30 triples for every changed workload with original C >=5% speedup and gain>summedSD in at least one, no separated regressions. Then native gates and integrated3gen+percasecorpus.','exception':'One-off new compiler algorithm authoring, not mechanical refactor; no product changes until acceptance'},indent=2)+'\n')
print('registered hypothesis, product untouched',flush=True)
