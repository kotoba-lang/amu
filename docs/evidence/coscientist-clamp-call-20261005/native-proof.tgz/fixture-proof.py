from pathlib import Path
import importlib.util,subprocess,os,re,json,struct,types,hashlib
r=Path('/Users/junkawasaki/github/wt/amu-seed17');w=Path('/private/tmp/amu-clamp-call-20261005');base=Path('/private/tmp/amu-context-call-sealed-20261005')
sp=importlib.util.spec_from_file_location('fx',w/'baseline-a64gen-fixtures.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
def sign(name,width,charged):
 mask=(1<<width)-1;half=1<<(width-1)
 m.fx(name,1,2,([('FUEL',)] if charged else [])+[('LGET',0,1),('CONST',1,mask),('BIN','BOP-AND',0),('LSET',2,0),('LGET',0,2),('CONST',1,half),('CMP','CC-GE',0),('BRZ',0,name+'_lo'),('LGET',0,2),('CONST',1,1<<width),('BIN','BOP-SUB',0),('BR',name+'_end'),('LABEL',name+'_lo'),('LGET',0,2),('LABEL',name+'_end'),('RET',0)])
cases=[(1,0,0,-1,0),(8,1,0,0,127),(16,0,1,0,255),(32,1,1,-7,13),(16,1,1,m.MIN,m.MAX),(8,0,0,-1,-1),(16,1,0,-100000,-99999),(16,1,1,10,-10)]
targets=[]
for k,(width,outer,inner,lo,hi) in enumerate(cases):
 s=f'cl_sign{k}';f=f'cl_bound{k}';sign(s,width,inner)
 body=([('FUEL',)] if outer else [])+[('LABEL',f+'_entry'),('LGET',0,1),('CALL',s,0,1),('LSET',2,0),('LGET',0,2),('CONST',1,lo),('CMP','CC-LT',0),('BRZ',0,f+'_notlo'),('CONST',0,lo),('BR',f+'_done'),('LABEL',f+'_notlo'),('LGET',0,2),('CONST',1,hi),('CMP','CC-GT',0),('BRZ',0,f+'_nothi'),('CONST',0,hi),('BR',f+'_innerdone'),('LABEL',f+'_nothi'),('LGET',0,2),('LABEL',f+'_innerdone'),('LABEL',f+'_done'),('RET',0)]
 m.fx(f,1,2,body)
 for t in [0,3,6,7,8]:
  c=f'cl_call{k}_{t}'
  cb=[('FUEL',),('CONST',0,11),('CONST',1,-22),('VEC',0,2),('LSET',3,0)]+[('CONST',j,100+j) for j in range(t)]+[('LGET',t,1),('CALL',f,t,1)]
  for j in range(t-1,-1,-1):cb+=[('BIN','BOP-ADD',j)]
  cb+=[('LSET',4,0),('LGET',0,3),('LGET',1,2),('RT','RT-VECTOR-AT',0,2),('LGET',1,4),('BIN','BOP-ADD',0),('RET',0)]
  m.fx(c,2,4,cb);targets.append((c,f,width,outer,inner,lo,hi,t,lo<=hi))
  if k<7:
   vals=[m.MIN,-65537,-32769,-32768,-129,-128,-1,0,1,127,128,255,256,32767,32768,65535,m.MAX]
   for v in vals:
    sv=v&((1<<width)-1);sv=sv-(1<<width) if sv>=(1<<(width-1)) else sv
    result=m.s64(min(max(sv,lo),hi)+sum(100+j for j in range(t))+11)
    m.run(c,[v,0],result,fuel=1+outer+inner)
    m.run(c,[v,-1],'trap',fuel=1+outer+inner)
   for fuel in range(1,1+outer+inner):m.run(c,[0,0],'trap',fuel=fuel)
parts=['seed/00-ns.kotoba','seed/01-mem.kotoba','seed/02-io.kotoba','seed/40-a64enc.kotoba'];env=dict(os.environ,KEXE_COMMAND='1',KEXE_CAP_RESOURCES_35=str(r)+':/private/tmp',KEXE_VECTOR_ITEMS='134217728',KEXE_PAIRS='16777216',KEXE_STRING_POOL='268435456',KEXE_VECTORS='65536',KEXE_CPU_SECONDS='1800',KEXE_WALL_SECONDS='1800');chunks={};loader=str(w/'kexe-loader')
for label,real,seed,backend in [('candidate-test',False,w/'seed-4.bin',w/'41-a64gen-prototype.kotoba'),('candidate-real',True,w/'seed-4.bin',w/'41-a64gen-prototype.kotoba'),('baseline-real',True,base/'seed-4.bin',w/'baseline-41-a64gen.kotoba')]:
 src=w/(label+'.kotoba');src.write_text('\n'.join((r/p).read_text() for p in parts)+'\n'+backend.read_text()+'\n'+((r/'seed/42-layout.kotoba').read_text()+'\n' if real else '')+m.kotoba(real))
 for mode,args in [('compile',['compile',str(src),'--target','aarch64-macos','--output',str(w/(label+'.kseed'))]),('extract',['extract-native',str(w/(label+'.kseed')),'--symbol','main','--output',str(w/(label+'.bin'))])]:
  q=subprocess.run([loader,str(seed),'0','0','aarch64','35,37,38,39','--',*args],env=env,capture_output=True,text=True);(w/(label+'-'+mode+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,(label,mode,q.stdout,q.stderr)
  if mode=='extract':off=re.search(r':offset (\d+)',q.stdout).group(1)
 q=subprocess.run([loader,str(w/(label+'.bin')),off,'0','aarch64','37,38','--'],env=env,capture_output=True,text=True);assert q.returncode==0,(label,q.stderr);chunks[label]=q.stdout;(w/(label+'.stdout')).write_text(q.stdout)
assert m.blob_from(chunks['candidate-test'])[0].rstrip(b'\0')==m.blob_from(chunks['candidate-real'])[0].rstrip(b'\0') and m.blob_from(chunks['candidate-test'])[1]==m.blob_from(chunks['candidate-real'])[1]
d=w/'fixture-run/unit/41-a64gen';d.mkdir(parents=True);(d/'stdout').write_text(chunks['candidate-real']);os.environ['SEED_BUILD']=str(w/'fixture-run');original=m.subprocess.run
m.subprocess.run=lambda args,**kw:types.SimpleNamespace(returncode=0,stdout='expanded emitter compiled/executed natively; real/test layouts match',stderr='') if args[:2]==['zsh',m.R+'/scripts/seed/unit.sh'] else original(args,**kw)
assert m.runs(False)==0;m.subprocess.run=original
names=[x[0] for x in m.FIX];images={}
for label in ['baseline','candidate']:
 blob,fc=m.blob_from(chunks[label+'-real']);path=w/('fixture-'+label+'-code.bin');path.write_bytes(blob);images[label]=(path,fc)
audit={};states=[]
for c,f,width,outer,inner,lo,hi,t,admitted in targets:
 cf=names.index(c)+1;ff=names.index(f)+1;rows={}
 for label,(path,fc) in images.items():
  data=path.read_bytes();start=fc[cf]//4;end=fc.get(cf+1,4*sum(len(x.split())-1 for x in chunks[label+'-real'].splitlines() if x.startswith('w ')))//4;words=struct.unpack('<'+'I'*(end-start),data[start*4:end*4]);calls=0
  for j,x in enumerate(words):
   if x&0xfc000000==0x94000000:
    delta=x&0x03ffffff;delta-=1<<26 if delta&(1<<25) else 0
    calls+=4*(start+j+delta)==fc[ff]
  sels=sum(x&0xffe00c00==0x9a800000 for x in words);rows[label]={'realClampCalls':calls,'conditionalSelects':sels}
 assert rows['baseline']['realClampCalls']==1,(c,rows)
 assert rows['candidate']['realClampCalls']==(0 if admitted else 1),(c,rows)
 assert not admitted or rows['candidate']['conditionalSelects']==2,(c,rows)
 audit[c]={'admitted':admitted,**rows}
 for v in [m.MIN,-32769,-32768,-129,-1,0,1,255,32767,32768,m.MAX]:
  for idx in [-1,0,1,2]:
   for fuel in [1,2,3,4,16777216]:
    pair={}
    for label,(path,fc) in images.items():
     e=dict(os.environ,KEXE_FUEL=str(fuel),KEXE_STRUCTURED_REPORT='1',KEXE_CPU_SECONDS='30',KEXE_WALL_SECONDS='30');e.pop('KEXE_COMMAND',None)
     q=subprocess.run(['/private/tmp/amu-context-call-20261005/clobber-state-loader',str(path),str(fc[cf]),'2','aarch64','-',str(v),str(idx)],env=e,capture_output=True,text=True,timeout=35)
     assert ':fuel ' in q.stdout and 'DIAG_VECTOR_ITEMS' in q.stderr,(c,label,q.stdout,q.stderr)
     pair[label]={'exit':q.returncode,'report':q.stdout.strip(),'items':re.findall(r'^DIAG_VECTOR_ITEMS.*$',q.stderr,re.M),'traps':re.findall(r'^KEXE_TRAP.*$',q.stderr,re.M)}
    assert pair['baseline']==pair['candidate'],(c,v,idx,fuel,pair)
    states.append({'caller':c,'value':v,'index':idx,'fuel':fuel,**pair['candidate']})
 print('PASS exact supervisor/clobber and real-call/CSEL audit',c,flush=True)
out={'status':'complete-native-fixture-and-exact-supervisor-parity','fixtures':len(m.FIX),'canonicalRuns':len(m.RUNS),'realTestLayoutIdentical':True,'supervisorComparisons':len(states),'instructionAudit':audit,'cases':states,'prototypeSha256':hashlib.sha256((w/'41-a64gen-prototype.kotoba').read_bytes()).hexdigest()};(w/'fixture-proof.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',len(states),'full supervisor comparisons',flush=True)
